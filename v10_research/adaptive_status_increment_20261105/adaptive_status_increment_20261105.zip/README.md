# Historical adaptive-memory status increment

These three dated status versions supplement the already archived candidate and audit files. Both the pending and subsequently accepted causal-witness status are retained. The weak-composition record identifies candidate v4 as the reviewed exact version while preserving v1–v3 as historical candidates.

The causal witness establishes a structural intersection only, not low prediction risk. The weak composition has a growing anchor set of size b+1; its statistical rate is inherited from the earlier suffix estimator. Neither record establishes a repeated-attention advantage or a general Transformer theorem.

Two public derivatives neutralize coordination or instruction-origin wording only. SOURCE_MAP.json binds each retained original and public derivative; source originals remain unchanged. Historical statements about no upload or execution describe the time of those records, not this later archive. No scientific calculation was run to produce this increment.
