# Weak low-risk anchor composition: reviewed boundary and stopping point

5 November 2026 UTC. Exact candidate LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md passed independent review for its stated conditional scope. Audit: INDEPENDENT_LOW_RISK_WEAK_ANCHOR_COMPOSITION_AUDIT.v1.md. Revisions 1-3 remain historical, not the accepted exact version.

Candidate SHA256: d51e74e89a452411d6eb6ffd6ab393fc3417f95aaed75e8a10dd20f4a970b5cb.
Audit SHA256: d99199b6ecc590d4bdb0e6d877b91354c8919de7d0da452d5f6b1835f15fa3dc.

For known stationary interior binary source class P_c, N>=6, and power-of-two 4<=b<=N-2, the construction has fixed width, three genuinely useful scalar uniform heads, ordinary PreLN/final affine vocabulary softmax, depth O_c(log(N+1)+b), and risk O_c(b^(-1/2)). Full-feature normalization, all-row norm budgets, all arithmetic, padding, restoration and coefficient-description precision are charged.

The first head is the existing suffix estimator. Two added heads implement a small causal anchor interaction. Protected fresh value rails and preserved raw shadows establish exact physical support at the first two reads; before the third read all rows depend on their own token and the anchor set S=suffix_b union {1}. There are b+1 anchors, not a fixed number. Post-third-read broad dependence is allowed because no later useful read occurs.

The logical added probability perturbation is O(log N/(bN^2)); the physical approximation is chosen smaller than its nonzero separation margin. All three single-head ablations use the same physical parameters except the zeroed output matrix. This demonstrates genuine but extremely weak dependence while retaining the existing statistical rate.

This is a composition of established source estimation, normalized simulation, and a small witness, not a statistical improvement or novelty claim. It neither supplies fixed-s consistency nor closes the general evolving-memory frontier. The documented scope stops at this explicit boundary; no stronger useful interaction, PostLN counterpart, or matching frontier is claimed.

No scientific executable, model run, numerical diagnostic, upload, or public repository mutation occurred. Documents and documentary hashes only.
