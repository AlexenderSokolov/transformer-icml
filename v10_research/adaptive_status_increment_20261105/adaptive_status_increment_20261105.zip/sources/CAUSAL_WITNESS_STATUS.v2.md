# Causal PreLN witness: independently accepted

5 November 2026 UTC. Supersedes the pending status in v1 without altering that historical file.

CAUSAL_PRELN_ANCHOR_WITNESS.candidate.v1.md is independently accepted for its stated structural-intersection scope. Audit: INDEPENDENT_CAUSAL_PRELN_ANCHOR_WITNESS_AUDIT.v1.md, PASS with no mathematical revision required.

Candidate SHA256: 1ff194ebc9faad5dd8513efb84863df764277e42906c632b8def9edb35b9d43c.
Audit SHA256: c3b09793a61ef15336385fdd5a396e256f35c891f748134d4c198154e9e7d275.

The exact width-16/depth-7 two-use PreLN construction has ordinary softmax output and genuine causal nonterminal anchor dependence. It is not a low-risk estimator: all outputs have q1>=1/2, so on stationary interior IID p1=c its risk is at least 1/2-c, in addition to the candidate's all-zero-source risk 1/2. State after the final useful read can depend on more tokens; membership constrains banks at reads, and there is no later useful read.

A separate growing-anchor weak-composition candidate has subsequently been written; its review status is separate and must not be inferred from this acceptance.
