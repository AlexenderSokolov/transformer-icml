# Frozen causal PreLN witness: independent review pending

5 November 2026 UTC.

Candidate: CAUSAL_PRELN_ANCHOR_WITNESS.candidate.v1.md.
SHA256: 1ff194ebc9faad5dd8513efb84863df764277e42906c632b8def9edb35b9d43c.

At this historical status version, independent review had NOT been completed because review capacity was unavailable. The candidate remained pending and preserved. This file does not imply mathematical acceptance.

The proposed exact construction has width 16, three genuine PreLN blocks, two useful full-prefix zero-score invocations and counted total depth 7 including embedding, final LN, affine head and ordinary vocabulary softmax. A paired-coordinate ReLU gate selects only raw anchor position 1 when its token is 1. First attention supplies its diluted value to each causal prefix; a local gate combines that value with each row's own token. Second attention reads those anchor-dependent nonterminal values. The proposed output depends strictly on nonanchor x2 when x1=1.

All construction steps, full norm bounds, matrices, complete bias vectors, raw/synthetic input conventions and final probabilities are specified in the candidate. This is a direct PreLN construction and makes no PostLN or compiler-extension assertion.

The intended conclusion is solely a nonempty, genuinely two-use causal PreLN intersection with the previously accepted anchored-memory class. The signal is O(log N/N^2), and deterministic all-zero source risk is exactly 1/2. No low-risk prediction upper or general frontier conclusion is claimed. Existing accepted local-memory and anchored-memory proofs retain their earlier review status; this new candidate is separate and pending.

No scientific executable, numerical diagnostic, parameter generator, model run, upload, or public mutation was performed. Hashing was documentary only.
