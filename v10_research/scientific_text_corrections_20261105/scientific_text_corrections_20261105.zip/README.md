# Scientific wording corrections to the short-text archive

The earlier proofs/scripts/logs archive remains available as an immutable historical export. Its privacy transformation mistakenly treated /workspace inside five scientific phrases as a host path. This supplement restores 11 occurrences in 10 files from exact original-source evidence: bit work/workspace, guard/workspace, activation/workspace, data/workspace, and field/projection/workspace. These phrases describe resource accounting, not machine locations.

Use the files under corrected/ for the corresponding scientific statements. CORRECTIONS.json binds each historical public file, corrected file, and supporting original-source identity. It identifies the prior archive and exact relative paths. Do not interpret the older masked wording as a deliberate omission of workspace costs. The historical archive is not silently replaced.

Each corrected file differs only at the listed wording. Mathematical numbers, equations, obligations, failures, review limits, and all other privacy transformations are unchanged. This is an export correction, not a new theorem, experiment, or proof-validation result. The original research files were not modified.

The review inspected all 1,446 markers across 343 files and recovered 347 original-source identities. That did not mean 343 files were damaged: only the 10 listed files required these scientific wording repairs. Generic operating-system and private host-path transformations remain subject to the earlier script-replay limitations. A successful correction does not restore missing historical execution records or establish self-contained reproducibility.
