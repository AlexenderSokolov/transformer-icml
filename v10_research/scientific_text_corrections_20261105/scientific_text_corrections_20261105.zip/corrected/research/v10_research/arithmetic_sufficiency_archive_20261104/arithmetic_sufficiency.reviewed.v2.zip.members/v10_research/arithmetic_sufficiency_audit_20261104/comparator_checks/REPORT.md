# Independent comparator and count-bridge audit

4 November 2026. Read-only audit of the research candidates; only this scratch directory was written. No upload, source modification, or IEEE certificate.

## Disposition

No blocking mathematical defect was found in Sections 3B/4 or the explicit numerical-quantizer interface of `lemma.v2.md`, SHA256 `6c38fae4362bc4cd9da392a3b77709ca1f27034f97a50c90d310d8e9fbd7de07`. Its distinction between a declared snapping execution rule and an additional affine/ReLU block is essential and is stated correctly. The newly appended exact-zero scratch invariant and clear-cost clarification were inspected. No structured-bridge addendum is reviewed here.

The unmodified comparator has two vulnerable plateau endpoints, not only the equality endpoint. The existing exact-real `proof.v3.md` already warns against arbitrary signed-error exact-bit claims, so this is not a contradiction of that proof. The following exact counterexamples prohibit strengthening it to such a claim without changing semantics or architecture.

## 1. Both vulnerable endpoints

Write delta=1/Q and H(x)=min(1,max(0,Q(x+delta))).

- At an exact negative decision x=-delta, H(-delta)=0. For every 0<epsilon<delta, H(-delta+epsilon)=Q epsilon, strictly between zero and one. An arbitrarily small *positive* perturbation leaves the zero plateau.
- At a tie x=0, H(0)=1. For every 0<epsilon<delta, H(-epsilon)=1-Q epsilon, strictly between zero and one. An arbitrarily small negative perturbation leaves the one plateau.

Thus the lattice separation delta is not a two-sided robustness margin for this particular continuous comparator. Moving its existing width-delta ramp horizontally cannot create positive margins at both adjacent lattice decisions: the ramp width already consumes the entire available gap.

## 2. Exact whole-program counterexamples

These use N=3, K=2, Q=G=8 and run every emitted affine/ReLU primitive with Fraction arithmetic. Register labels below are zero-based. They are perturbed valid terminal encoder states, not random impossible count states. The original exact bank and rails are held fixed except for the named positive perturbation. The scaled overwrite propagates that perturbation consistently into the numerator and denominator.

### Negative endpoint: word 222

The exact selected count vector is (0,1). Initially b1_1_1=1/4 and l1_1=l2_1=1. Replace the zero bank coordinate b1_1_0 by 2a, for any 0<a<=1/64. Then scaled n0=1/8+a and d=3/8+a.

The three division bits become (8a,1,40a), both correction bits are zero, and the emitted first probability is

qhat0=3/8+9a,

where the exact original output is 3/8. The second probability is the exact complement. Therefore arbitrarily small positive bank perturbations spoil both exact bits and exact final quantizer recovery in the unmodified network. The first comparator input is -delta+a.

### Tie endpoint: word 112

The true bank contains b0_0_1=1/4, but the terminal predecessor context is (0,1), whose selected counts are (0,0). The exact rails are l2_0=l1_1=1. Replace the zero bank coordinate b0_1_1 by 2a, for any 0<a<=1/1024. Then n0=1/8 and d=1/4+a.

The division bits become (1-8a,0,0), the correction bits are (1,0), and

qhat0=1/2-4a,

where the exact original output is 1/2. The first comparator input is -a. This is again a positive perturbation of a bank register, even though it induces a negative perturbation of the comparison argument.

The check script verifies both families at a=2^-e for every e=10,...,100. Example e=20 gives first-coordinate errors +9/1048576 and -1/262144 respectively. Their rational identities establish the arbitrary-small-error result; the finite tests are corroboration, not its proof.

## 3. Why the frozen count bridge is sufficient

Before the bridge, a strict all-position/all-register bound E_m<delta/2 is assumed. At the terminal row each ideal n_c and d is on delta Z, so nearest-delta snapping recovers them exactly with no tie. At other rows the ideal endpoints of the stated intervals [delta,1] and [K delta,K] are themselves delta-grid points. A perturbation strictly less than delta/2 cannot round outside these intervals. Independent rounding can break d=sum n at other rows, but the exact-terminal claim does not require that identity there.

After all other registers are cleared, an induction through the actual emitted decoder shows:

1. n,d,remainder and comparison arguments are on delta Z. Clipping [0,K] preserves that lattice.
2. H returns an exact bit on this lattice, including x=0 and x=-delta.
3. The gate is exactly d or zero because 0<=d<=K. Remainders stay bounded by explicit clipping even where n<d fails at a nonterminal row.
4. All terms except probability accumulation have integer coefficients and delta-grid biases. Accumulation multiplies an exact bit by 2^-j, not an arbitrary grid-valued register by that coefficient.
5. Therefore a common binary state grid with p_decoder>=max(h,g) fractional bits suffices for *every position*, not only the terminal row. No finer products are needed after the bridge. Biases and coefficient denominator exponents in this emitted suffix are at most max(h,g).

At the terminal row the recovered n,d are exactly those of the original proof, so restoring division and correction produce precisely the original q. At other rows discreteness and boundedness hold, but equality to the original nonterminal trajectory and simplex semantics are neither needed nor asserted.

The round-once exact-integer arithmetic and no-overflow premises matter. An error budget alone does not make a real implementation obey them. Arbitrary additive error on the last comparator output can turn even a plateau value 0 or 1 into a non-bit. The note explicitly excludes that inference.

## 4. Architectural positive-margin alternative and exact charges

H_star(x)=clip(2Q(x+3 delta/4),0,1) has ramp [-3 delta/4,-delta/4]. For every original lattice point x0 in delta Z and every |e|<=delta/4, H_star(x0+e)=1{x0>=0}. Equality at the two margin endpoints is safe under exact arithmetic.

Implementation: change the initializer bias from delta to 3 delta/4, retain its affine and ReLU, then run h+1 clipped doublings. Compared with the existing comparator this costs exactly one additional three-primitive doubling:

- Old comparator: 3h+2 primitives.
- New comparator: 3h+5 primitives.
- Comparisons in the readout: (K-1)(g+K).
- Extra total: 3(K-1)(g+K) primitives.
- New readout depth: 3K^3+2+(K-1){2+g(3h+13)+K(3h+6)}.
- No extra registers: gc and ex are reused.
- The scalar clipped-doubling kernel has coefficient/bias magnitude <=2. The fused argument initializer may contain the existing fixed-K correction coefficients, so its bound is not asserted to be 2. Full-readout coefficient/bias bound remains K, affine row-l1 bound remains max(3,2K-1).
- The new threshold bias 3/(4Q) has denominator exponent h+2, not h. If using exact-grid arithmetic for this changed comparator, its constants require p>=h+2. Retaining finer approximate input registers can of course require larger p.
- No worse all-row state bound: the new initializer is smaller than the old nonnegative initializer, the first clip still caps at one, and the additional final doubling has t in [0,1] and ex in [0,1]. Existing O_K(1) state bounds remain valid.

This is optional architecture, not part of interfaces A/B. The frozen note does not charge it in their original depth, correctly because those interfaces do not use it. If a future theorem promotes it into the network, the above +3-per-comparison and h+2 exponent charges must be added.

An equivalent post-comparator bit snap is S(t)=clip(2t-1/2,0,1). Applied to H it yields exactly H_star, but a literal appended implementation costs five primitives: affine u=2t-1/2, ReLU(u), affine ex=u-1, ReLU(ex), affine u=u-ex. It reuses the same two registers and preserves all coefficient/row bounds. This costs +5 per comparator if not fused; claiming +3 is justified only by using the changed-bias/extra-doubling implementation above.

For reference, a direct sufficient *input-only* condition for the H_star decoder, with every later primitive exact, is max_c |nhat_c-n_c|<=E and |dhat-d|<=E, where E<=delta/[4(2G+2K-3)]. Assuming previously correct bits, clipping nonexpansiveness gives remainder error E_j<=(2^(j+1)-1)E. Digit argument error is <=(2^(j+1)-1)E, and the largest correction argument error is <=(2G+2K-3)E. Induction therefore keeps every argument within delta/4 of its ideal lattice value and recovers all bits and q exactly. This is a sufficient conditional estimate, not a claim that ordinary floating arithmetic supplies it.

## 5. Numerical snapping costs and scope

The nearest-grid bridge is a different declared numerical semantics, not a free ReLU operation and not a standard IEEE cast. Its affine/ReLU layer count is consequently not silently added to the original model depth; its machine work must instead be charged as the explicit conversion operation. On p-fractional-bit signed codes and target exponent h<=p, its quotient/remainder, midpoint test, increment, and shift cost O(p+log M_K) bit work/workspace per converted coordinate. The bridge applies this to T(K+1) coordinates. For clearing other state, v2 explicitly charges O(T d_model) writes if a second pass is materialized, and observes that its exact-zero invariant makes that extra pass unnecessary. If each full code is physically written and one counts Boolean work, a straightforward refinement is O(T d_model(p+log M_K)) bit writes. The final interface converts only the terminal first K-1 outputs and computes an exact complement, requiring its corresponding additions as well.

The note explicitly disclaims a complete machine/controller certificate. These stated charges are adequate for its present sufficiency claim but cannot be read as a full optimized runtime theorem.

## 6. Reproduction

Run `python v10_research/arithmetic_sufficiency_audit_20261104/comparator_checks/check_comparators.py`.

The script reads source files only, verifies the frozen v1 and v2 proof hashes, records all source hashes in `results.json`, and checks:

- 711 comparator endpoint perturbations;
- 182 whole-program rational counterexample instances;
- 28,497 H_star margin and post-snap equivalence instances, including equality at margin endpoints;
- 640 independently snapped all-position decoder states across K=2,3,4 and G below, equal to, and above Q. Every post-bridge affine product and every retained state is checked for representability on the claimed max(h,g) grid, and every completed comparator is checked to be exactly 0 or 1.

The all-position cases include deliberately unrelated numerator and denominator values. This checks the actual invariant needed outside the terminal row rather than silently relying on terminal count identities. Finite coverage is not an all-length proof; the induction above supplies the mathematical argument.
