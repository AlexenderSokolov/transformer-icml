# Parallel width-depth candidate: norm-controlled lag recovery and exact-real add-one output

2026-11-04. Private candidate, not independently reviewed. No public writes. Formula-level construction, not a compiled dense Transformer implementation or full paid-machine certificate.

## Result and frozen interface

For fixed alphabet K and every public N≥3, set T=N+1, P=2^ceil(log2 T), H=log2 P, and let R be the smallest power of two with R²≥N. Put s=1/R. There is a length-dependent untied affine/ReLU causal-attention family with:

- raw symbol onehots at positions 1,…,N, synthetic zero symbol at T, and public scalar position p_t=t/P;
- self-inclusive full-prefix attention only, all logits identically zero, one head with growing value width sufficient (no growing head count needed);
- width W=O(NK+K³), O_K(log N) actual sequential primitive stages;
- Euclidean operator norms of all positionwise linear maps, Euclidean bias norms, and per-token reachable Euclidean hidden-state norms bounded by constants depending only on K, independently of N;
- exact first/second predecessor rails at every row, and exact actual-terminal add-one probability vector (C_c+1)/(J+K), in ideal exact-real arithmetic;
- norm-one output coordinate projection, not a final vocabulary softmax; no LayerNorm/RMSNorm, no tied-weight or length-independent-parameter assertion.

Norm convention: the hidden-state bound is per token, as in CA001 and the bridge; the all-token Frobenius norm of even the raw onehot input is √N and is not claimed uniformly bounded. A shared positionwise linear map has the same operator norm on the stacked sequence. The zero-score causal attention matrix A_ti=1{i≤t}/t also has a dimension-independent stacked Euclidean operator norm: weighted Schur bounds with weights i^(−1/2) give row bound ≤2, column bound ≤3, hence ||A||₂≤√6 (the sharper Hardy bound is unnecessary). Bias norms refer to each shared layer's parameter vector, not its repeated T-row evaluation.

All pair/count information is computed internally from raw tokens. Horizon N is public compiler information, not a sample-dependent advice string. Exact-real rational arithmetic and finite-grid arithmetic are different contracts. An encoder-only finite-grid certificate is given below; it does not certify the full exact probability readout on ordinary floats or fixed-grid arithmetic.

## 1. Scaled selector, including all fanout and bias norms

For centers c_i=i/P, produce d_i=s|p_t-c_i|, iterate H times d_i←min(s,2d_i), and put g_i=s-d_i. Then g_i=s exactly when t=i and zero otherwise. Centers i+1 and i+2 give the corresponding destination selectors. Out-of-range centers simply never fire. The centers may exceed 1 slightly at the end, but remain bounded by 2.

Crucially, form the replicated positional vector as (s p_t)_i, not (p_t)_i. Its linear-map norm is s√N≤1. The replicated center bias (s c_i)_i has norm ≤2. Absolute value is implemented by two ReLUs, with constant operator-norm expansion. The clipping primitive can be compiled as 2d−ReLU(2d−s): diagonal gains are at most 2 (and the final two-rail combination has a fixed constant norm), while its full bias vector has norm s√N≤1. Each primitive costs a constant number of affine/ReLU stages. Intermediate d_i are O(s), so their whole-vector norm is O(1). Three selector families only change constants. The complete selector's large sensitivity is paid through H sequential stages.

Token fanout is likewise (s x_t)_i, whose operator norm is s√N≤1. Gating it with g_i repeated across K symbols uses only K-dependent operator norms and bias norm s√(NK)≤√K:

b_{t,i,c}=ReLU(s x_t(c)+g_i(t)−s).

Exactly source row i contains the pulse s e_{X_i} in channel i. No sqrt(N)-norm token embedding is used.

## 2. One parallel zero-score broadcast, and paid removal of 1/t

Use a single uniform full-prefix attention head whose values are all NK pulse channels. The identity value/output maps have norm 1. At row t:

a_{t,i,c}=s·1{i≤t}·1{X_i=c}/t.

Apply H actual coordinatewise clipped-doubling stages a←min(s,2a). Since t≤T≤P=2^H, the final result is exactly s e_{X_i} for i≤t and zero for i>t. This is saturation, not division by t, and the unknown row-dependent denominator is not removed for free. Every intermediate coordinate is ≤s. On reachable histories there is one active symbol in each source channel, so the full broadcast vector has norm at most s√N≤1 at every stage. Even the crude all-coordinate bound is √K, independent of N. All cap-bias vectors have norm ≤√K and all primitive matrix norms are constant.

Thus parallelizing the broadcasts does not require N separate attention heads. Using N heads without checking their concatenation/output norms would be an unnecessary loophole; this construction uses one wide value head.

## 3. Destination selection and bounded-norm summation

For ell=1,2 form

v^ell_{t,i,c}=ReLU(a_{t,i,c}+g_{i+ell}(t)−s).

At each row and for each ell, at most one i channel survives. It equals s x_{t−ell} if that predecessor exists, and zero otherwise. Sum the i channels with a balanced binary tree. Each primitive pairwise-sum map has Euclidean operator norm √2, independent of N; NOT one uncharged all-channel sum of norm √N. Because at most one input leaf is nonzero at each row, every tree level has norm ≤s. Padding by zero leaves is free state initialization but charged width. Finally log2 R explicit doublings restore amplitude 1. All intermediates stay norm ≤1.

Keep raw x and p in separate residual rails until no longer needed. Parallel-copying a constant number of rails costs only fixed operator norm. Standard residual attention/FFN compilation can overwrite scratch by bounded cancellation against old rails; each displayed primitive may cost a fixed number of standard residual blocks. This is a compilation recipe, not a claim that actual dense matrices were already emitted or executed.

This proves all-position lag recovery in O(log N) depth, O(NK) width, and bounded per-token state norms. Causality is genuine: only source i≤t appears after broadcast, and lag gates ask for i=t−ell. No future symbol or local-copy mask is introduced.

## 4. Internal triple counts and terminal context

As in bridge v3, form triple onehots

v_t(a,b,c)=ReLU(l2_t(a)+l1_t(b)+x_t(c)−2).

Rows 1,2 and synthetic T contribute zero. A second zero-score full-prefix head gives terminal z_abc=C_abc/T. K-dependent expansion and biases are allowed since K is fixed. Build q_ab=ReLU(l2_T(a)+l1_T(b)−1), the internally recovered actual terminal pair. Then

f_c=Σ_ab ReLU(z_abc+q_ab−1)=C_c/T,
j=Σ_c f_c=J/T.

The sums have norms depending only on K, not N. Here C_c counts observed transitions matching (X_{N−1},X_N), and J=Σ_c C_c≤N−2. No external count or query is supplied.

## 5. Exact-real internal denominator readout, with explicit length-dependent table

This section removes the separately paid division decoder in the exact-real family by paying growing width and a rational parameter table. It is NOT a general division primitive.

For m=0,…,N−2 run the scaled selector of §1 on scalar j with center m/T: start d_m=s|j−m/T|, perform H clipped doublings at cap s, and set h_m=s−d_m. At the terminal j=J/T, h_J=s and every other h_m=0, because distinct centers differ by at least 1/T≥1/P. Input fanout norm is √(N−1)/R≤1; center/cap bias norms are bounded. Thresholds m/T are explicitly paid rational parameters.

For each symbol c form

w_{m,c}=ReLU(s(f_c+1/T)+h_m−s).

At the terminal, exactly m=J survives, with value s(C_c+1)/T. Multiply each m block by the public coefficient A_m=RT/(m+K), but factor this multiplication into O(log N) diagonal maps with norms ≤2. If A_m≥1, use floor(log2 A_m) factors 2 followed by a rational factor in [1,2), with remaining stages identity. If A_m<1, use one factor A_m. Each factor has O(log(N+K)) rational description bits. Different m channels can use different schedules in the same diagonal layers. No unbounded single-layer coefficient occurs.

The surviving terminal block becomes (C_c+1)/(J+K), a positive simplex vector. A balanced binary sum tree over m yields that vector with norm-√2 layers and constant hidden norm. Final norm-one projection outputs it exactly. There is no logarithm, nonlinear division, count ceiling, giant final affine fan-in, or vocabulary softmax hidden in this step.

Reachable-state bounds must also cover nonterminal rows, where j need not lie on the m/T grid. At any row, f_c≥0, Σ_c f_c=j≤1, and f_c+1/T≤1: the triple average has total at most (t−2)/t for t≥3, and earlier totals vanish. The selector support |j−m/T|<1/P implies |Tj−m|<T/P≤1. At most two adjacent m channels can be nonzero. Before amplification 0≤w_{m,c}≤s(f_c+1/T). After full amplification,

A_m w_{m,c}≤(T f_c+1)/(m+K)≤(m+2)/(m+K)≤2.

Partial amplification stages never exceed the larger of their input and this final bound. Thus all rows, not just T, have O_K(1) hidden norms. The binary tree sums at most two nonzero blocks per row, also uniformly bounded. Nonterminal outputs need not be normalized; only terminal prediction is asserted.

The exact output rational denominator need not be a power of two. Exact-real arithmetic permits these rational coefficients. Ordinary fixed-grid rounding cannot be silently inserted and still called exact. A finite rational execution theorem would need an explicit arithmetic/bit-growth implementation; none is claimed here.

## 6. Encoder-only finite-grid endpoint certificate

Take Q=RP and activation grid 1/Q, so h=log2 Q=ceil(log2 T)+ceil(log2 sqrt N) fractional bits. Scaled positional inputs, scaled selector centers, cap s and token pulses lie on this grid. The initial p=t/P also lies on the grid. Exact integer numerator aggregation followed by one downward output rounding in the broadcast gives active integer code floor(P/t)≥1, cap code Qs=P. H exact integer clipped doublings recover cap code P, hence exactly s. Zero channels remain zero. Destination gates, binary sum tree, and R amplification are exact on the grid and give exact unit predecessor rails.

This particular certificate therefore uses about 1.5 log2 N working fractional bits, not half-log-N precision and not the original bridge's log-N bound. The smaller signal s/t is the reason. Accumulation must be exact before aggregate rounding; edgewise rounding is not covered. Integer attention accumulators and denominator t require separately charged O(log N) bits for this sparse-pulse encoder, with conservative O(h+log N) guard/workspace bits. Generic arbitrary values would require the conservative bound rather than source-pulse sparsity.

Even if a final histogram is rounded on this grid, §5's exact-real centers no longer match exact count fractions. No full fixed-grid probability-output theorem follows. Nor is this a float32/float64 certificate: cancellation in affine gates, evaluation order, and rounding errors are not analyzed. The fixed-grid simulator uses exact integer/Fraction logic, not BLAS.

## 7. Resource ledger and comparison

Let W=O(NK+K³), D=O_K(log N), b_par=O(log(N+K)). These are length-dependent networks, not fixed parameters. All source/destination/count selectors and denominator tables are paid. Per-row rolling activations require O(W) real slots, all-row rolling states O(TW), dense untied parameters O(DW²) coefficients or O(DW² b_par) representation bits, and public positions O(T log T) bits. Explicit causal masks cost O(T²) bits if materialized. All these are conservatively charged even for zero matrix entries.

Two useful full-width attention stages cost O(T²W) scalar arithmetic (one parallel source broadcast and one histogram). Dense Q/K/V/output/FF projections over all stages cost O(D T W²). If the syntax evaluates a full dummy attention at every primitive stage, attention cost is O(D T²W). Stage-specific smaller widths or sparse execution can improve these, but must be declared separately. Dense attention storage can be streamed rowwise; materializing a full attention matrix adds O(T²) real slots. Finite encoder rolling states cost O(TW h) bits plus exact accumulators; the exact-real full readout has no asserted finite-word bound.

For fixed K, the conservative dense costs are O(N³ log N) scalar work, O(N² log² N) coefficient-description bits, O(N²) rolling real slots, and O(log N) depth. This is a depth-width tradeoff, not an across-the-board compute improvement: the fixed-width bridge v3 has O(N log N) depth, and the existing block-packing construction has O(N) depth, but much narrower states/parameters. Merely labeling the new depth “optimal” without fixing width, representation and work would be unjustified.

The CA001 full statistical lower theorem assumes fixed width, fixed dimensions and fixed depth, and cannot be imported unchanged. Its elementary influence recurrence is dimension-free when the same per-head Lipschitz/value norms, head count and per-layer constants hold uniformly. Our one-head bounded-norm construction satisfies those primitive bounds. At source i=T−1, exact predecessor output requires sensitivity at least 1, whereas its recurrence gives at most GΔ(a+b)^L(1+log(T/(T−1)))^(L−1)/T. For L=O(log T), the last factor is bounded. Thus L≥c log T−O(1) for constants a,b,G,Δ independent of T (unless a+b≤1, when recovery is impossible). The same argument rules out L=o(log T). This is a lag-extraction lower bound, not a general probability-prediction or precision-risk lower bound, and it is not specific to fixed width. The candidate achieves its logarithmic order by paying linear width.

## Sources and qualification

- `v10_research/strict_full_causal_bridge_20261104/constructive_bridge.v3.md`: raw-input interface, sequential broadcast, final histogram and aggregate-rounding distinction.
- `v10_research/causal_attention/CA001_causal_bounded_softmax_candidate_v3.md`, §§1–3: primitive norm assumptions and influence recurrence; statistical theorem has additional fixed-dimension hypotheses.
- `plan_scope_delivery_20261104/original_plan_scope_audit_20261104.md`: public-length network families permitted when declared, bounded scores/norms required, resource matching and no artificially slow optimal-depth conclusion.

The formula test checks exact rational lag recovery, exact rational terminal add-one output, and the separate finite-grid encoder endpoint on exhaustive short binary histories and seeded longer ternary histories. It is not an independent proof review or an emitted dense-block implementation. No statistical risk theorem is independently reproved; deterministic equality transfers only the already valid comparator theorem with identical source, initialization, horizon and terminal query.
