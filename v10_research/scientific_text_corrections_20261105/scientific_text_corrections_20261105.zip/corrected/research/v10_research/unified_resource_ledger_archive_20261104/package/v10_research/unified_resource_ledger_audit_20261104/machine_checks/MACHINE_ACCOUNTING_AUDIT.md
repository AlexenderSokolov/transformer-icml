# Independent machine-accounting audit

4 November 2026. Local read-only audit of the candidate; this directory contains the auditor's checks and report only. No candidate, network service, or public repository was changed.

## Disposition

**No blocking arithmetic, storage, or asymptotic resource error found in the reviewed scope.** The displayed upper bounds are defensible for the specified special integer evaluator and an explicitly scheduled bit-cost implementation. They do not certify the existing Python/Fraction compiler, dense executor, arbitrary finite-precision Transformer, or a fully specified gate/controller machine.

Two nonblocking specification improvements would make the ledger easier to bind:

1. Candidate lines 54–59 name a multitape implementation but leave the access schedule implicit, then say tape access could instead be charged separately. A RAM arithmetic count is not by itself a multitape time proof. The sequential schedule below establishes that the stated bound is achievable without an extra asymptotic access factor; include such a schedule or scope the headline to the chosen RAM model. Merely adding an unspecified tape-access charge would not prove the displayed multitape bound.
2. Candidate line 71 correctly labels the new compiler bound an implementation proposal. Keep this qualification until a dyadic integer compiler and its emitted format are specified and checked. The bound does not automatically apply to Python Fraction simplification, string-based labels, JSON serialization, or dense matrix execution. This is already substantially disclosed by the candidate, not a newly found contradiction.

Exact encoder counts and the N,K depth simplification are covered by a separate audit. This report takes the displayed layer bound as a premise where used.

## Frozen evidence

Candidate: `[host-path-redacted]`

SHA256: `06b205b7a221b927fe7bb3147f2086bb01234f818a953449a9e4ed4a23f2eb13`

Source roles:
- `v10_research/depth_packing_20261104/layer_execution_20261104_0905/layer_network.py`: actual encoder primitive coefficients, floors, attention aggregation, and geometric slope factorization.
- `v10_research/shallow_readout_audit_20261104_1037/primitive_checks/check_primitives.py`: actual shallow readout emitter. Only its definition prefix is imported, so its historical result-writing test body is not run.
- `v10_research/shallow_readout_audit_20261104_1037/sources/proof.v3.md`: readout magnitude/row-sum/lattice arguments and explicit distinction between emitted stages and compiler bitwork.
- `v10_research/standard_embedding_20261104_0946/embedding_audit.md`: dense residual embedding, FFN dimensions, copy/reset attention scratch, and final-dot-product rounding semantics.
- `v10_research/structured_bridge_archive_20261104/package/v10_research/arithmetic_sufficiency_20261104/{structured_bridge_addendum.md,generalG_clarification.md,lemma.v2.md}`: all-row snap, post-bridge recoding, zero-scratch invariant, and arithmetic limitations.

## Operand and dyadic-description bounds

Let `f=max(hwork,h,g)` be a uniform fractional-exponent ceiling and let `a=max(hwork,g)` be a safe parameter denominator-exponent ceiling. The stored input grid can change at the bridge; this upper bound does not claim a single grid is necessary throughout.

Encoder denominators are controlled as follows:
- Positional biases use exponent at most H; geometric floor uses `(2b+1) beta`.
- A factorized line slope has denominator exponent at most `(k+2) beta+n_k`, with `n_k<=ell`, and therefore at most `(2b+1) beta+ell<=hwork`.
- Square coefficient exponents are `2j<=2m<=H+b beta+11`, below the third term defining h0.
- Halves/eighths and all remaining encoder biases are covered by hwork.
- Readout denominators have exponents at most h or g, from `1/Qd`, `T/Qd`, `2^-j`, and `1/G`.
- The canonical maps use signs, copies, zeros, and `A-I`; these preserve the denominator exponent and increase numerator requirements by at most a constant number of bits.

Magnitude growth is polynomial in K, not exponential in layer depth. `B<8(K+1)`. The encoder's largest displayed hat coefficient is `2 B^3`, while the reached hat intermediates are O(B^3). Classifiers and predecessor rails use the proved exact invariants; the rails do not grow by a factor proportional to the number of source blocks. The square, clip, and positional subcircuits remain bounded. Readout coefficients are O(K), its comparator arguments/scratch are O(K^2), and the clips, bits, accumulators, and final complement have the stated polynomial bounds. The residual embedding creates signed copies and bounded cancellation, not an extra factor exponential in L.

With code `X` representing `x 2^f`, an affine row evaluated over common denominator `2^a` has terms `X*num*2^(a-e)`. Their signed bitlength is at most

`f+a+O(log(K+1))`.

A conservative dense sum adds `O(log(d+1))` guard bits, and attention sums add `O(log T)` guard bits. The exact attention division can use the integer numerator sum and t directly. Even the less economical form containing `sum*Qgrid` and `t*Qstate` has only O(w)-bit operands. ReLU, final flooring, and residual addition do not introduce a new denominator.

Thus the candidate's

`w=C[hwork+h+g+H+beta+log2(d+1)+1]`

with a sufficiently large absolute C covers signed codes, parameter numerators and explicit binary denominators, complete products/dot-product sums, and attention sums. The use of O(w)-bit widened temporaries is essential: w is not merely a floating mantissa or a claim that two w-bit operands have a w-bit product. Schoolbook multiplication and long division on these O(w)-bit operands cost O(w^2); no unit-cost division or hidden rational denominator growth is needed.

## Addresses, input, and control

For `L=O(NK+K^3+K(g+K)h)`, one has

`log L=O(log(N+1)+log(K+1)+log(1+g)+log(1+h))`.

Also `h<=H+O(beta)`, `log d=O(beta)`, and `log(1+g)<=O(g)`. Hence addresses into explicit dense parameters, rolling states, and optional attention materialization have `O(w)` bits. Adding the bit offsets for fixed-length records contributes only `log w`, again absorbed. Loop increments, comparisons, row/column counters, seeks in the schedule below, input initialization, and streamed resets are bounded by the displayed dense work. This is a constructive controller-size argument, not an executed gate certificate.

## A sequential multitape schedule that pays access

A fixed number of work tapes suffices; fixed-length words and row-major arrays permit sequential scans. Parameter tapes may hold all layers, while scratch tapes hold the current layer's matrices and rolling states. None of the following requires a unit-cost arbitrary tape seek.

1. For a dense map on a state row, stream a matrix row alongside the input vector to form one dot product. Rewind the vector by O(dw) tape cells for the next output coordinate. After all output coordinates, rewind the matrix by O(d^2 w) for the next token. A `2d` FFN dimension only changes constants. Matrix copying/rewinding and vector replay total O(Td^2 w) tape movement, beneath O(Td^2 w^2) arithmetic.
2. Keep residual inputs and projection/output rows on separate sequential tapes. Combining residuals and producing the next rolling activation tape takes O(Tdw) scanning. Retain only the current and next layers, projections, and FFN scratch.
3. For attention query t, scan the first t rows of the value tape, maintaining a d-word accumulator on another tape. Scan and rewind that accumulator once per source row. Rewind the value tape after each query. The cost is O(T^2 d w) movements/additions. Divide each completed coordinate numerator by t once and append its output. Query/key dot products, if computed rather than exploiting the known zero projections, also fit O(T^2 d w^2) by row-vector replay. All scores are exactly zero; there is no numerical exponential or irrational scaling subproblem to solve.
4. Initialize/clear attention scratch by sequential scans and use the declared exact copy/reset FFN. Zero data in dummy heads remain exact; computing them is charged, and skipping them must remain an announced optimization.

The total is the candidate's `O(L(Td^2+T^2d)w^2)` bitwork with rolling O(Tdw) activation/workspace bits, plus the separately charged bridge. This is an existence construction, not a statement that the archived executor uses this schedule.

## All heads, all rows, and memory

The useful-edge count distinguishes M scalar recovery heads from one K^3-channel histogram. Multiplying every recovery head by K^3 would overcharge that refined count; omitting dummy heads while calling the result all-block dense would undercharge. The candidate explicitly gives both variants and its final conservative bound pays every block, T rows, dense projections/FFNs, and full causal edges.

There are a constant number of dense parameter matrices per block, including d-by-2d and 2d-by-d FFNs, so explicit untied parameter storage is O(Ld^2 w). The next layer is generated from current-layer activations, so rolling state is O(Tdw), not O(LTdw). A scalar attention-edge matrix requires O(T^2 w) extra workspace per layer. Keeping an entire d-vector per edge would instead require O(T^2 d w), as the candidate warns. Saving full layer traces is an additional O(LTdw) activation allocation. None of these alternatives should be silently interchanged.

## Snapping and very large G

The bridge pays O(TK w) for K+1 nearest-grid conversions at every row (K>=2 absorbs the +1). The step is even, and `(code+step/2)//step` has the specified tie-to-positive-infinity convention. The strict terminal bound excludes ties there. All unneeded data registers are already zeroed by the counted affine overwrite; another whole-state clearing pass is not necessary.

Exact recoding can be performed with shifts and divisibility checks because both grids are powers of two. Its all-coordinate traversal costs O(Td(hwork+max(h,g))), including magnitude bits because hwork already dominates log K. It must not be implemented as a numerical floating cast or left implicit when G>Qwork.

After the snap, every n_c,d,r lies on the Qd lattice at every row. Comparator outputs are exact bits, including equality. Only those bits receive `2^-j` factors. Consequently Qpost suffices despite the false general proposition that arbitrary products of Qpost-grid values remain on that grid. This distinction is correctly made in the candidate. The formula includes growth with g and K; fixed-K O(N) depth/runtime specializations must not be used for unrestricted g or growing K.

## Compiler proposal

A fresh dyadic compiler can retain integer numerator plus denominator exponent during generation, generate powers of two by shifts, and avoid general rational reduction. Public register indexes and loop counters fit the word bound. Coefficients can be generated with O(w)-length operands; filling each dense matrix entry with an exact coefficient or zero costs at most O(w^2), including output. Canonical `A-I` and sign-copy construction adds only constant matrix factors. This yields the proposed O(Ld^2 w^2) bitwork and O(Ld^2 w) binary output size without an exponential table.

This argument assumes an explicitly emitted binary/dyadic representation with O(w) bits per slot. It is not an observed asymptotic result for the existing Python/Fraction/JSON compiler. The output-size statement is an upper bound and a write obligation for the selected padded representation, not a representation-independent storage lower bound: sparse/shared descriptions can be shorter.

## Reproducible checks

Run from repository cwd:

`python v10_research/unified_resource_ledger_audit_20261104/machine_checks/check_machine_bounds.py`

Outputs: `machine_bounds_results.json` in the same directory. The script binds the candidate SHA256 and records both compiler-source SHA256 values.

PASS coverage:
- Five actual coefficient sweeps, including K=10 and g=256, found all dyadic denominator exponents within max(hwork,g) and all coefficient numerator sizes within the stated envelope.
- Ninety public-parameter/address-envelope cases include N or K with 1,025-bit magnitude and g up to 4,096. They challenge word/address growth without compiling infeasibly large networks.
- Nine all-row primitive executions use K=2,3,5, each at minimum G, default G, and G=2^(hwork+17). They check exact integer divisibility outside the declared floors, snap/recode at every row, n/d/remainder Qd-lattice membership, completed comparator bits at every row, and terminal equality with the closed-form quantizer. The largest observed product/accumulator operand was 115 signed bits.

These are finite diagnostics plus the analytical derivation above. They do not execute dense canonical matrices, validate IEEE/GPU kernels, prove all-length correctness by testing, or close the already-disclosed full gate/controller/liveness certificate gap.
