# Dependencies and omissions

All 20 available source files are included unchanged, including physical suffix candidate v1/v2 and all dedicated failed-route records. No absent version was invented or historical scientific content dropped.

External dependencies remain OPEN: earlier local finite-group task folding and type conservation; reset-phase/nuisance and Markov source arguments; existing wide physical statistical estimator and suffix lower comparison; suffix-code/count/readout machinery; full prepared-vector positive-epsilon PreLN compilation, small-amplitude simulation, padding/clearing/restoration and ordinary-softmax output; inherited primitive/full-norm resource contracts and prior literature checks. Their exact external corpus and complete transitive proof graph are not bundled or re-established here.

Not included: third-party full papers/PDFs; unexecuted offline table generation; missing numerical matrix/register certificates; absent training or finite-arithmetic results; unavailable screenshots/visual acceptance; missing prior v10 records. Source-relative references are identifiers, not guaranteed resolvable links. Local appendix hashes establish text identity only, not mathematical validity or dependency closure.
