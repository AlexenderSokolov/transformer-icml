# Two reset-zone phases: direct bounded PreLN reference and physical comparison

6 November 2026 UTC. Analytical candidate v1. No training, scientific execution, upload, or external mutation. Existing candidates are preserved. This is a direct adaptation of the specified IID quadratic circuit and prepared-state compiler, not a new rate or a universal compilation theorem. Independent exact-file audit is required. Numerical matrix-by-matrix envelope certification is not supplied; the inherited finite-envelope dependencies are identified below.

## 1. Frozen family and scope

Fix c in (0,1/2), N divisible by four, power-of-two 4<=b<=N/2, and m=floor((N-b-2)/16)>=1. Write T=N+1, P=2^p with p=ceil(log2 T), and K=P^3. Put (s_1,e_1)=(2,2+8m) and (s_2,e_2)=(2+8m,2+16m). Both endpoints are even. Zones are I_j=(s_j,e_j]. Their lengths are multiples of eight; both lie before the final b symbols.

Use the SAME suffix baseline as IID_QUADRATIC_NUISANCE_HARDNESS v3: q_b is the inherited binary suffix estimator; ell_a is its fixed-floor serial-log approximation at epsilon_log, and d(z)=ell_1(z)-ell_2(z). Set a to the largest negative power of two <=c and epsilon_log to the largest dyadic <=min(1/1000,1/(100b^2)). The reference logs are bounded by log(1/a)+1. Define

 F_j=sum_(k in I_j, k odd) x_k sum_(l in I_j,l<k) x_l mod 2,
 L=(ell_1+rho_1(2F_1-1)+rho_2(2F_2-1),ell_2),
 Q_ref=softmax(L).

For a completely specified nontrivial family choose rho=2^(-max(2,ceil((log2 b)/2))), rho_1=rho, rho_2=rho/2. Then distinct positive amplitudes have sum <=3/8 and O(log b)-bit descriptions. More generally bounded, publicly described dyadic amplitudes are allowed, with description cost charged.

The two INVOCATIONS below have value dimensions (3,2). This is not two scalar heads. An alternative serial schedule has five scalar invocations. In both schedules width is fixed and no suffix, reset-state, phase or source parameter is supplied as an input feature. Inputs remain raw onehots, public i/P, and the inherited synthetic zero-symbol terminal.

## 2. Exact bounded zone selectors

For integer h in [0,P], define at raw row i the paid function

 A_h(i)=clip(2^p(i/P-h/P),0,1).

Implement it by clipping the signed initial difference to [0,1], then p clipped doublings. This equals 1{i>=h+1} on the public position grid. Every intermediate lies in [0,1], each coefficient is at most two, and the threshold h/P has O(log N) bits. Do NOT implement this as a single slope-P matrix.

Compute and preserve

 u_j=A_(s_j)-A_(e_j)=1{s_j<i<=e_j},
 w_j=A_(s_j)-A_(e_j+1)=1{s_j<i<=e_j+1}.

Use independently paid selector scratch and reuse it serially; at most four retained masks are needed. The one-row extension in w_j is essential. At a shared boundary e_1+1=s_2+1, the first zone's retained count excludes that row's raw bit, whereas the second zone includes it. The masks therefore do not confuse the two resets. On exact raw bits, ReLU(x_i+u_j-1)=u_j x_i. At the synthetic row x_T=0. Protected shadows retain x_i, i/P, marker, and masks.

## 3. Two bounded prefix sums with genuine reset semantics

The first Q=K=0 uniform causal invocation reads the three-dimensional vector

 (u_1 x_i,u_2 x_i,v_suffix(i)).

Here v_suffix is precisely the inherited one-head packed-suffix local value, prepared BEFORE this invocation using its paid selector and packing stages. Each component has its own fresh zero destination. At row i the first two answers are

 r_(j,i)=S_(j,i)/i,  S_(j,i)=sum_(l<=i)u_j(l)x_l.

The third answer is exactly the old suffix broadcast; the other components do not change its logical circuit. Preserve both r banks while running suffix decoding/counts/division and ell. All-row suffix validity is inherited from that exact same circuit, not inferred merely from terminal correctness.

Choose L_sq minimal with nu=4^(-L_sq)/4<=1/(128K). Use the explicit bounded square interpolant and product M from IID quadratic v3, Sections 3.1-3.2. At every row set

 zhat_(j,i)=M_(L_sq)(i/P,r_(j,i)),
 fhat_(j,i)=clip((s_(L_sq)(zhat_(j,i))-zhat_(j,i)/P)/2,0,1),
 v_(j,i)=ReLU(fhat_(j,i)+w_j(i)-1).

The last line exactly masks on the logical trajectory. Since all fhat lie in [0,1], the complete second-read values lie in [0,1]. Comparing with z=S_(j,i)/P gives |fhat-binomial(S_(j,i),2)/P^2|<4nu. Thus the second Q=K=0 invocation, with TWO value coordinates and two fresh destinations, has terminal outputs within 4nu of

 U_j/(P^2 T),  U_j=sum_(i=s_j+1)^(e_j+1) binomial(S_(j,i),2).

Multiply by public dyadic T/P. The exact normalized target U_j/K lies in [0,1/2], since there are at most T contributing rows and S<=N<P. No integer U_j is stored. Nonterminal second-read outputs are in [0,1], so multiplying by T/P and applying the inherited synthetic gate ReLU(y+marker-1) leaves terminal values unchanged and sets all other decoder inputs to zero.

Each pair l<k in I_j occurs in U_j exactly e_j-k+2 times. Because e_j is even, this multiplicity has parity k. Consequently

 U_j mod 2=F_j.

This proves the reset-zone statistic directly; it is NOT obtained by discarding cross terms from the original global quadratic phase. Apply 3p tent folds and the fixed plateau to each gated scalar. Their error before plateau is <=4Knu<=1/32, so each exact logical final phase is F_j on EVERY raw Boolean history. Every nonterminal logical phase is zero. All stages are continuous bounded affine/ReLU maps, and no exact lattice assumption is made for their physical perturbed counterparts.

## 4. Physical full-feature PreLN error, including all preparation

Combine all preceding operations into ONE paired logical register machine. References are: the original plus each of the TWO actual single-invocation ablations. Ablating the first invocation zeros both prefix averages AND the suffix average; ablating the second zeros both phases but preserves the suffix. Product identity M(a,0)=0 guarantees the former's zero quadratic values. The inherited zero-code suffix decoder remains legal. Preserve the same shadows and schedule in each run.

Append ALL logit copies, norm padding, products, square-root microsteps and scratch clears before choosing eta. Select a fixed power-of-two C_out large enough that v=L/C_out has Euclidean norm <=1 throughout the three references; e.g. C_out>=4(log(1/a)+3) suffices. The final prepared reference state is

 z_ref=(v,-v,1,-1,r,-r,0,...,0),
 |r-sqrt(3d_phys/2-1-||v||^2)|<=kappa.

Use the specified paid square-root padding routine from STANDARD_PRELN v2 / INTERIOR_SOFTMAX v2. Its complete primitives are a dependency, not a free square-root operation. Let R be the fixed padding bound, Z_ref a fixed complete-reference state bound including this routine, Z=Z_ref+1, C_pad=4R/d_phys, and C_norm=(2Z_ref+1)/d_phys. Freeze one common Euclidean one-unit tube and one per-stage max-row Lipschitz bound L_0>=2 for original and both ablations.

For desired physical comparison delta<=1/1000, choose xi,kappa,tau as largest dyadic values <=delta/[100C_out(1+C_pad+C_norm)] and the inherited restoration small-domain bounds. FIRST fix these tolerances, then append the complete preparation, then define m_pre. For the chosen baseline,

 m_pre=O_c(log N+b+log(1/delta)).

Represent every coordinate with its negative partner; logical affine biases are homogenized against paired preserved anchors. At physical h=eta z, eta=2^(-M), gain-one epsilon-one LN is eta s(z)z, s(z)=(1+eta^2||z||^2/d_phys)^(-1/2). Each primitive's homogeneous residual FFN yields exactly z_new=z+s(z)(F(z)-z). On the tube its error from F(z) is at most C eta^2.

For either vector-valued useful invocation with its fixed selector A and injection B, the exact normalized step is

 z'_t=z_t+B(1/t)sum_(i<=t)A s(z_i)z_i.

Against its logical uniform-read map, local error is at most ||A||||B|| Z^3 eta^2/(2d_phys). Dimensions three and two only change this constant. Critically, s(z_i) depends on ALL coordinates, including masks, suffix banks, the other phase and stale scratch. None are omitted or normalized separately. Choose C as the maximum of this bound and the local FFN error constants over the fixed primitive types. Then

 e_j<=L_0 e_(j-1)+C eta^2,
 e_(m_pre)<=C eta^2 L_0^(m_pre).

Choose the smallest M>=1 satisfying C4^(-M)L_0^(m_pre)<=xi and the tube constraints. This controls the COMPLETE prepared vector, not just incoming logits; approximate clears are included. In particular M=O_c(m_pre+log(1/delta)).

For completeness the inherited paid restoration uses a_j=2^(j-M), dyadic k_j approximating sqrt(1+3a_j^2) to <=tau a_j^2, and M zero-attention blocks h_new=h+k_j LN_(1,1,0)(h). Their full-state direction is preserved and final radial factor obeys |r_M-1|<=3(C_pad kappa+C_norm xi)+tau. Every k_j<=2; no inverse-eta matrix is used. The conventional final full-feature LN_(epsilon=1,gain=2,shift=0), then affine head C_out times positive-logit-bank projection and ordinary vocabulary softmax, yields

 ||L_phys-L||_infinity<=C_out[2xi+7(C_pad kappa+C_norm xi)+2tau]<=delta,
 sup_(all Boolean histories) TV(Q_phys,Q_ref)<=delta.

Finally change EVERY interior LN gain to two and halve its consuming FFN first matrix or attention value matrix. Q/K are identically zero. Trajectories are unchanged. Every block has both ordinary PreLN sublayers, including dummy zero branches. This is a direct two-read recurrence, not physical concatenation or an assumed generic nonlinear compiler.

## 5. Frozen resources and explicit limits of certification

- Normalization: epsilon=1, gain=2, shift=0 everywhere, full-feature statistics; conventional affine vocabulary head plus ordinary final softmax.
- Useful invocation count: exactly two, value dimensions (3,2). One attention head per useful invocation with those value dimensions; no hidden scalar-only interpretation. Serial alternative: five scalar reads, not used in the main schedule.
- Width: choose once enough paired registers for the inherited binary suffix/log/padding machine, four retained masks, two prefix averages, two second-read destinations, two phases, and fixed reused product/tent scratch. This is a fixed c-dependent integer, independent of N,b,delta. FFN hidden width is bounded by twice the paired register count plus the maximum fixed number of selective ReLU forms. The inherited files do NOT specify a universal numerical register count; this note consequently does not certify e.g. width 64 or any other invented numerical width.
- Full states/matrices/biases: freeze the maximum of the inherited fixed-envelope primitive bounds, the selector/product/tent constants, the paired embedding/FFN overhead, C_out, gain two, and the restoration bound (3/2)(Z_ref+1). This is one c-dependent finite envelope before N,b vary. No equality with an externally preassigned numerical norm cap is claimed. A matrix-level numerical envelope requires expanding and auditing the inherited suffix and padding primitive schedule.
- Counted depth: D=O_c(log N+b+log(1/delta)), including full preparation, all dummy blocks and restoration. No square root or log is a free local operation. If delta is inverse polynomial in N and b=Theta(log N), D=O_c(log N).
- Per-coefficient description O_c(log N+b+log(1/delta)), including all zone thresholds, square coefficients, suffix packing, baseline log rounding, eta and restoration coefficients. Untied total description O_c((log N+b+log(1/delta))^2) at fixed width. Public positions i/P are the existing input convention, not an arbitrary N-row embedding table.
- Distributed state O(N); dense useful-head plus local work O(N^2+ND) if dummy zero heads are skipped. Evaluating every dummy head densely costs O(N^2D).
- Semantics: exact-real arithmetic with finitely described coefficients. Finite-word execution and per-operation rounding robustness are NOT certified. This distinction matters because tent folds amplify errors and small amplitudes may underflow in a fixed machine format.

The two invocations really affect output. For the second, choose histories realizing F=(1,0), available using one nonzero phase pattern in zone one and zeros in zone two. Its ablation changes the first logit by 2rho_1. On the common bounded interval the resulting probability difference is at least 2kappa_c rho_1. For the first, use an all-symbol-2 suffix: the inherited true-vs-zero-code baseline logit differences separate by at least 2log 3-4epsilon_log. The two nuisances can reduce that gap by at most 2(rho_1+rho_2)<=3/4. Thus a positive constant gap remains. Take delta also <=kappa_c rho_2/100, with kappa_c the minimum sigmoid derivative on the complete bounded logit interval; the COMMON physical error for the actual ablations preserves both margins. The same eta and restoration parameters are used in every run. This establishes usefulness, not minimality or necessity.

## 6. Consequence for the already-proved orbit comparison

With gamma=1-2c^8, the finite-group v2 result applies to this exact reset reference and SAME d. It gives, for each homogeneous order-two source and arbitrary initial pair law,

 R_P(M)<=R_P(Q_phys)+delta+(rho_1+rho_2)gamma^m/4,
 R_P(Q_base)<=R_P(Q_phys)+delta+delta_base
             +(rho_1+rho_2)gamma^m/4+(rho_1^2+rho_2^2)/8.

Here Q_base must be a separately compiled baseline for precisely the SAME ell and d. M is the four-probability average, not softmax of averaged logits, and is only a suffix evaluator in this statement. No physical architecture for M is silently inferred. These are inherited sourcewise additive comparisons; there is no new estimation rate, minimax lower, or generic resource frontier.

## 7. Read dependencies and audit status

Read: FINITE_GROUP_LOCAL_TASK_FOLDING.candidate.v2 (zone algebra and orbit result); IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3 (square/product/tent circuit and merged suffix read); TWO_READ_PRELN_COMPILATION.candidate.v4 (full-preparation ordering); STANDARD_PRELN.candidate.v2 Sections 3-5 and INTERIOR_SOFTMAX.candidate.v2 Sections 4-5 (homogeneous FFNs, padding contract, restoration and final logits); CONSTANT_WIDTH_CONSISTENCY.candidate.v3 (existing suffix machine).

New exact obligation supplied here: masked-prefix implementation of both reset zones, the indispensable endpoint extension, bounded position selector realization, the (3,2) merged-read schedule, and its two-read full-feature error recurrence. Inherited obligations remain the previously audited suffix and padding modules. A fully numerical frozen-width/full-matrix certificate would require their complete instruction expansion; it is not replaced by the finite-envelope existence argument above. No unconditional claim under a particular numerical norm/width cap or finite arithmetic is made.
