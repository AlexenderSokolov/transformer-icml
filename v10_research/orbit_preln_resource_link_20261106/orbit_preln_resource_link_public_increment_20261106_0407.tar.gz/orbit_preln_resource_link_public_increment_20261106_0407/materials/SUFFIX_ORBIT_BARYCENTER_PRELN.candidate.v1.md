# Compile the suffix orbit barycenter into ordinary-softmax PreLN

6 November 2026 UTC. Analytical candidate v1. No training, scientific execution, numerical check, public upload, or repository mutation. Existing versions and dependencies are unchanged. This is a concrete extension of the inherited one-uniform-head bounded suffix program, not a theorem for arbitrary attention programs. Independent review is required.

## 1. Contract and conclusion

Use the SAME paid logical suffix logit difference d(z)=ell_1(z)-ell_2(z) from IID_QUADRATIC_NUISANCE_HARDNESS v3, Section 5, and SYMMETRIC_QUADRATIC_NUISANCE_REMOVAL v1, Section 9.2. Its raw-input bounded affine/ReLU program has constant width, one scalar zero-score causal full-prefix read, D_d=O_c(log(N+1)+b) stages, and coefficient descriptions B_d=O_c(log(N+1)+b). The inherited all-row legality and its head-ablated default-word program give |d|<=B on both reference trajectories, for a fixed dyadic B>=1 depending only on c. We do not replace its existing finite log approximation by an exact logarithm.

Let rho_j>=0 be public, sum_j rho_j<=R, with R fixed. For H=2^r and u_sigma=sum_j rho_j sigma_j, define

    M(t)=H^(-1) sum_sigma sigmoid(t+u_sigma),
    Q_M(z)=(M(d(z)),1-M(d(z))).

For 0<epsilon<=1/16 there is, conditional only on the precisely cited inherited logical suffix and norm-padding/restoration routines, a fully specified bounded-primitive extension with an actual ordinary final vocabulary softmax satisfying

    sup_raw_histories TV(Q_fold_phys(x),Q_M(suffix(x)))<=epsilon.

All LNs have positive epsilon_LN=1, scalar gain 2 and zero shift. Input remains raw binary symbols plus the original public position coordinates, inclusive causal mask and synthetic terminal. There is one nonzero uniform attention invocation; all added computation is local. Width and full-state/full-matrix/full-bias/primitive-gain bounds are fixed in c,R. Depth is

    D=O_(c,R)(log(N+1)+b+epsilon^(-1/2)).                 (1)

This bound is valid even for growing r as a NONUNIFORM existence/online-network bound through the direct scalar spline below. It does not bound coefficient-construction work independently of r. For fixed r an alternative explicit branchwise circuit has the same order with an r-dependent constant; its growing-r depth is O_(c,R)(D_d+2^r epsilon^(-1/2)). Both costs are paid, and neither circuit treats a mixture of softmaxes as one softmax.

## 2. Explicit direct scalar barycenter spline

On [-B,B], differentiation of the finite sum gives

    0<M'(t)<=1/4, |M''(t)|<=1/4,
    alpha<=M(t)<=1-alpha, alpha=sigmoid(-(B+R)).

These bounds are uniform in r and the particular amplitudes. Choose a fixed dyadic a>0 with a<=alpha/2. The positive lower bound depends on c,R, not epsilon,r,N,b.

Here is a dyadic-coefficient affine/ReLU circuit for M to error delta, for any 0<delta<=1/16. Let J be the smallest power of two with J>=max(1,2B/sqrt(delta)), let h=2B/J and t_j=-B+jh. Let f interpolate the real node values M(t_j). The interpolation error is at most h^2/32<=delta/32. For interval slopes s_j=(M(t_(j+1))-M(t_j))/h,

    f(t)=beta+s_0 t+sum_(j=1)^(J-1) a_j ReLU(t-t_j),
    beta=M(-B)+B s_0, a_j=s_j-s_(j-1).

Bounds: |beta|<=1+B/4, |s_0|<=1/4, and sum_j|a_j|<=B/2. The last inequality follows by comparing adjacent h-interval averages of M', whose Lipschitz constant is 1/4: |a_j|<=h/4. This bounded total variation, not merely bounded individual coefficients, controls every serial partial accumulator.

Round beta,s_0,a_j independently to nearest dyadics on the coarsest power-of-two mesh Delta satisfying

    Delta<=delta/[8(1+B+2BJ)].

For t in [-B,B], the rounding contribution is <=Delta(1+B+2B(J-1))/2<=delta/16. Thus the rounded spline differs from M by less than delta. All knots are dyadic, with O_B(log J) bits. Rounded coefficient descriptions have O_B(log(J/delta)) bits.

Evaluate serially: retain t, initialize the affine accumulator, compute one hinge scratch, add its coefficient times the scratch, and clear/reuse scratch. Each hinge, affine addition, copy and clear is a counted constant-width bounded primitive. The absolute partial sums are bounded by 1+B/2+B^2 plus a fixed rounding allowance. All scratch and preactivations are bounded in B. Consequently complete state norms, full matrices/biases and per-primitive gains are bounded independently of J,r. Finish by the explicit clip

    mhat=a+ReLU(fhat-a)-ReLU(fhat-(1-a)).

This equals projection onto [a,1-a], hence |mhat-M|<=delta. It is not an external probability repair: it is a paid local logical operation inside the stack. The actual physical state may differ from its logical reference, which is handled only by the subsequent full-program error recurrence.

No sigmoid is a network primitive here. Values M(t_j) are used solely in the public offline coefficient definition. Section 7 prices their construction and distinguishes real-parameter existence from certified numerical generation.

## 3. Alternative explicit sigmoid-per-branch program

For fixed r, an alternative avoids invoking a barycenter table as the description of a scalar function. Apply the same uniform-grid, serial-hinge construction to sigmoid on [-C,C], with a fixed dyadic C>=B+R+1. Its derivative and second derivative have the same bounds, so approximation at error delta costs O_C(delta^(-1/2)) stages and fixed width. For each public sign vector sigma in a fixed unrolled order, form d+u_sigma, evaluate the sigmoid spline, clip to [a,1-a], then add H^(-1) times that value to a running accumulator. Each branch error at most delta gives average error at most delta, NOT H delta. Reuse all branch scratch. Partial running averages are in [0,1], so full-state norms remain bounded independently of H; no H-wide fanout is used.

A coefficient H^(-1)=2^(-r) needs r+1 bits. If amplitudes are not finitely representable, replacing each shift u_sigma by a dyadic within delta changes that branch's probability by at most delta/4, by the sigmoid derivative bound. Allocate this error separately, e.g. run every branch spline with delta/2 and use shifts accurate to delta, to obtain average error <delta. More generally an amplitude approximation with sum_j|rhohat_j-rho_j|<=delta suffices for all branches. Exact irrational shifts are not asserted to have finite binary descriptions.

This explicit alternative costs O_(c,R)(H delta^(-1/2)) local stages after computing d once. It uses fixed width and an envelope independent of r, but exponential depth. Amplitudes/branch shifts can be compiled into the unrolled layer coefficients rather than stored as an r-wide runtime state. Offline sign-sum construction costs O(rH) naive real arithmetic, or a separately justified Gray-code alternative. No phase enumeration is communicated between parties.

## 4. Paid log-probability conversion and error budget

For either route, obtain mhat in [a,1-a] with |mhat-M(d)|<=delta. Compute x_1=mhat, x_2=1-mhat. Apply the fixed-floor serial log spline from INTERIOR_SOFTMAX v2, Section 4, on [a,1], to both coordinates, with accuracy lambda:

    |L_i-log x_i|<=lambda.

For clarity the imported circuit uses dyadic knots v_j=a+(1-a)j/K, K the least power of two >=max(1,(1-a)/(2a sqrt(lambda))); interpolation error <=lambda/2, independently rounded hinge coefficients on mesh <=lambda/[2(K+1)], error <=lambda/2, and serial bounded accumulators. It costs O_a(lambda^(-1/2)) primitives, fixed width, full bounds depending only on a. It introduces no executed log primitive. Every L_i is bounded in a fixed a-dependent interval.

Since (x_1,x_2) already sums to one, softmax(log x)=x exactly. For the mathematical comparator Q_ref=softmax(L), the max-logit perturbation bound gives

    TV(Q_ref,Q_M)<=delta+tanh(lambda/2)<=delta+lambda.

Choose delta=lambda=epsilon/4, using largest admissible dyadic tolerances if needed. Compile the whole program with final max-logit error <=nu=epsilon/4 as below. Then

    TV(Q_fold_phys,Q_M)<=delta+lambda+nu<=3epsilon/4<epsilon. (2)

Any branch-shift rounding is included in delta, never added silently. This is the required paid conversion of averaged probabilities back to one ordinary vocabulary softmax. Averaging original logits instead would give sigmoid(d), a different rule.

## 5. Full-state preparation before small amplitude

This paragraph specifies the physical compilation rather than invoking an arbitrary-program compiler. Start from the one-head logical suffix program and append precisely the scalar spline, clip and two log splines above. Include the original head-ablated default-word reference if usefulness is desired. Choose a fixed dyadic C_out large enough for v=L/C_out to satisfy ||v||_2<=1. Reserve paired copies, anchors, and all reused scratch. Width d_phys is a fixed sufficiently large constant.

Choose xi,kappa,tau as the largest dyadics below nu/[100 C_out(1+C_pad+C_norm)] and the fixed small-domain bounds from STANDARD_PRELN v2. Append EVERY scaled-logit copy, norm-padding product/square-root microstep and scratch clear. The reference preparation leaves

    z_ref=(v,-v,1,-1,rpad,-rpad,0,...,0),
    |rpad-sqrt(3d_phys/2-1-||v||^2)|<=kappa.

The imported bounded affine/ReLU padding routine costs O_(c,R)(1+log(1/kappa)) stages. Its complete-state envelope is fixed before tolerance selection; C_pad and C_norm are chosen from that fixed envelope, so there is no circular dependence on eta or a subsequently growing tube. Define m only AFTER this entire preparation is appended. Fix a common tube radius Z and gain L_0>=2 covering every stage of the full reference and its selected ablation.

Represent logical registers by pairs with an unchanged paired anchor, h=eta z, eta=2^(-M). All biases are homogenized through that anchor. In gain-one epsilon-one full-feature LN,

    LN(h)=eta s(z)z, s(z)=(1+eta^2||z||^2/d_phys)^(-1/2).

A local overwrite F is implemented by the ordinary shallow FFN residual F-I, using signed ReLU for affine maps and the usual single-layer selective ReLU overwrite. It gives exactly z_new=z+s(z)(F(z)-z), whose defect is <=C eta^2 on the fixed tube. Every such local stage is a complete block with zero attention. At the SOLE original uniform read, with fresh reference destination,

    z'_t=z_t+B_0 t^(-1)sum_(i<=t) A_0 z_i,
    z'_(t,phys)=z_t+B_0 t^(-1)sum_(i<=t) A_0 s(z_i)z_i.

The local defect is <=||B_0||||A_0|| Z^3 eta^2/(2d_phys), independent of prefix length. This read uses a complete block with zero FFN. Full-feature normalization is accounted for, not assumed bankwise.

Thus max-row error satisfies e_j<=L_0 e_(j-1)+C eta^2. Select the SMALLEST M>=1 meeting C'4^(-M)L_0^m<=xi and the tube constraints. Then the actual FULL prepared vector obeys ||ztilde-z_ref||<=xi, uniformly in all raw histories and the selected ablation, and

    M=O_(c,R)(m+log(1/epsilon)).

Nothing asserts physical decoded digits, clips, or cleared registers are exact. Residual scratch error enters the full-vector norm estimate.

Use the bounded radial restoration from STANDARD_PRELN v2 Section 5: M complete blocks with scalar branch gains k_j approximating sqrt(1+3*2^(2(j-M))) within tau*2^(2(j-M)), with O(M+log(1/tau))-bit dyadic coefficients bounded by 2. It restores h=r_M ztilde with |r_M-1|<=3delta_norm+tau, delta_norm=C_pad kappa+C_norm xi. Final LN_(1,2,0) and affine head C_out times positive output-bank projection yield

    ||logits_phys-L||_infinity
      <=C_out[2xi+7(C_pad kappa+C_norm xi)+2tau]<=nu.

The final operation is actual vocabulary softmax. Make every interior LN gain 2 by halving its consuming FFN first matrix and useful attention value matrix; Q=K=0, so trajectories are unchanged. No inverse-eta matrix, external logarithm, or extra output MLP is hidden.

## 6. Sourcewise risk and useful-head statement

For the reset-zone finite-group family of FINITE_GROUP_LOCAL_TASK_FOLDING v2, let E_j be its first-hit events, m_j its eight-bit trial counts, and gamma=1-2c^8. That exact source-preserving algebra gives, separately for each homogeneous interior order-two source and each arbitrary initial law,

    R_P(Q_M)<=R_P(Q_nuisance_ref)+sum_j (rho_j/4) gamma^(m_j).

If an independently established hard-family physical comparison satisfies sup_x TV(Q_nuisance_phys,Q_nuisance_ref)<=zeta_h, (2) yields

    R_P(Q_fold_phys)<=R_P(Q_nuisance_phys)+zeta_h+epsilon
                         +sum_j (rho_j/4) gamma^(m_j).   (3)

This note supplies the previously missing folded-side physical approximation. It does NOT itself supply the r-phase hard-side physical realization, which remains a separate obligation. No multiplicative/sourcewise ratio, statistical minimax improvement, or new rate follows.

The logical folded map is strictly increasing in d: M'(d)>=k_(B,R)>0, where k_(B,R)=sigmoid'(B+R). The inherited all-symbol-2 suffix versus suffix-head ablation has a q_0=sigmoid(d) gap at least 1/2 minus its already paid log errors. Since sigmoid is 1/4-Lipschitz, this gives a positive fixed d-gap and hence a positive fixed folded gap. With epsilon below a sufficiently small c,R-dependent threshold, the SAME common preparation/eta/restoration/head approximates both references closely enough to preserve a nonzero physical gap. Then the one invocation is genuinely useful. Without imposing this smallness threshold, claim only one nonzero attention invocation, not an unproved ablation margin. No necessity of any read is inferred.

## 7. Full computation and description ledger

Direct scalar route: J=O_(c,R)(epsilon^(-1/2)) barycenter knots and the same order of paid log stages. Full reference length and physical depth obey (1). Per-coefficient bits are O_(c,R)(B_d+D+log(1/epsilon))=O_(c,R)(log(N+1)+b+epsilon^(-1/2)); the small-amplitude exponent/restoration, not only spline rounding, dominates this conservative bound. Untied total parameter bits are O_(c,R)(D(B_d+D+log(1/epsilon))), hence O_(c,R)(D^2). Rounded scalar-spline coefficients themselves cost only O_(c,R)(log(1/epsilon)) bits each.

The direct table is public preprocessing tied to the supplied amplitude list, not an oracle or learned population statistic. Its naive exact-real construction evaluates H=2^r sigmoids at each of J+1 nodes: O(HJ) sigmoid evaluations, plus O(rH) sign-sum arithmetic and O(HJ) summation arithmetic. Streaming construction need not retain all branch values. The amplitude description/read cost is additional. Offline coefficients can mathematically be defined from exact real constants and rounded; this proves finite network descriptions but does not certify a finite numerical generator. If node values are computed approximately, errors amplified by division by h when forming slopes and hinge differences must be budgeted (sufficient node error O(delta*h/J), conservatively O(delta/J^2) for fixed B), or node values may first be rounded with a separate proof. Arbitrary real amplitudes require an input oracle or a finite approximation guarantee; sum_j|rhohat_j-rho_j|<=e changes M uniformly by <=e/4. No bit-time bound follows without specifying such input and transcendental-evaluation algorithms.

Branchwise route: online depth O_(c,R)(D_d+H epsilon^(-1/2)); per-coefficient descriptions additionally include r for H^(-1), and finite branch/amplitude-approximation precision. General formula is B_param=O_(c,R)(B_d+D+log(1/epsilon)+r), total O(D B_param). Neither exponential route proves that exponential preprocessing or online cost is necessary. The direct scalar route shows why group cardinality alone cannot justify an online architecture lower bound for this one-dimensional special family.

Both routes have N+1 physical rows, O_(c,R)(N) rolling real registers, useful-dense-head plus local work O_(c,R)(N^2+ND), and O(N^2D) if all dummy attention slots are evaluated densely. A materialized attention matrix costs O(N^2) additional storage. All arithmetic guarantees here use exact-real architecture semantics. Tiny eta and length-dependent coefficient descriptions are not certified finite-execution reliability.

For the aligned AA/BB comparison, Alice sends exactly b/2 suffix bits and Bob reconstructs z; arbitrary alignment costs at most b bits. The direct logical spline/log evaluator has local work O_(c,R)(b+epsilon^(-1/2)), after any original O_c(b) logical d evaluator, with fixed real workspace plus the supplied coefficient stream; use the original exact d evaluator to preserve its intended identity. Parameter/input descriptions and public preprocessing are not communication. No assertion is made that the PHYSICAL normalized network is exactly suffix-only: its uniform approximation is what transfers risk.

If r grows with balanced zones m_j approximately (N-b)/(8r), the exceptional term deteriorates at that scale; bounded R alone does not imply exp(-a_c N) uniformly in r. The online folded compiler can remain efficient while the hard-side construction, source exceptional probability, and table-generation costs change.

## 8. Read provenance and remaining boundaries

Directly read relevant sections of: FINITE_GROUP_LOCAL_TASK_FOLDING.candidate.v2.md; TWO_READ_PRELN_COMPILATION.candidate.v4.md; SYMMETRIC_QUADRATIC_NUISANCE_REMOVAL.candidate.v1.md Sections 9 and 12; INTERIOR_SOFTMAX.candidate.v2.md Sections 4-5; STANDARD_PRELN.candidate.v2.md Sections 3-8; LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md; CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md; IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md Sections 5 and 8. These live in their dated sibling directories. The suffix count/readout and logical padding arithmetic remain inherited reviewed dependencies rather than new proofs here.

New work here is the explicit bounded serial barycenter/sigmoid spline, paid log conversion, one-head full-program compilation application with ordered precision choice, uniform-history folded bound, sourcewise transfer, and separate online/offline growing-r ledger. No arbitrary attention compiler, mandatory PostLN theorem, optimality, finite-word execution, or physical r-phase hard family is asserted.
