from pathlib import Path
import html,hashlib,json
D=Path(__file__).parent
items=[('双区域相位的真实 PreLN', 'TWO_RESET_PHASE_PRELN.candidate.v1.md'), ('后缀轨道重心的真实 PreLN', 'SUFFIX_ORBIT_BARYCENTER_PRELN.candidate.v1.md'), ('真实宽网络的后缀路线反例', 'PHYSICAL_TYPE_SUFFIX_OBSTRUCTION.candidate.v2.md'), ('双相位失败记录', 'TWO_RESET_PHASE_FAILED_ROUTES.v1.md'), ('重心编译失败记录', 'SUFFIX_ORBIT_BARYCENTER_FAILED_ROUTES.v1.md'), ('证明义务与范围', 'PROOF_OBLIGATIONS_AND_FAILED_ROUTES.v1.md'), ('先行工作与模型合同对照', 'PRIOR_AND_MODEL_COMPARISON.v1.md')]
for p in sorted(D.glob("INDEPENDENT*.md")):
 if "REPORT" not in p.name:items.append(("精确版本独立审阅",p.name))
items.append(("保留旧版：后缀定理定义域措辞", "PHYSICAL_TYPE_SUFFIX_OBSTRUCTION.candidate.v1.md"))
assert len(list(D.glob("INDEPENDENT*.md")))>=3
body=(D/'REPORT_BODY.zh.v1.html').read_text()+'<section id="appendix"><h2>八 完整证明与独立审阅原文</h2><p>候选创建时的待审状态以对应精确版本审阅为准。下列原文可离线核对，哈希仅用于版本绑定，不是科学执行或机器证明。</p>'
bind={}
for title,name in items:
 data=(D/name).read_bytes();h=hashlib.sha256(data).hexdigest();bind[name]=h
 body+=f'<details><summary>{title} · {html.escape(name)}</summary><p class="hash">SHA-256 {h}</p><pre>{html.escape(data.decode())}</pre></details>'
body+='</section><footer><p>中文报告 v1 · 2026 年 11 月 6 日 UTC。本增量无数学枚举、模型执行或训练；未完成视觉渲染验收。</p></footer>'
style='''body{font-family:system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;color:#171717;max-width:980px;margin:auto;padding:40px 24px;line-height:1.8}h1{font-size:2rem;line-height:1.4}h2{font-size:1.5rem;margin-top:2.6rem}h3{font-size:1.15rem;margin-top:1.8rem}nav{margin:24px 0}a{color:#145a88}.eq{font-family:Cambria,Georgia,serif;padding:12px 0;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%}td,th{border:1px solid #d9d9d9;padding:12px;text-align:left;vertical-align:top}th{background:#e8edf1}tr:nth-child(even){background:#f8f9fa}details{margin:22px 0}summary{cursor:pointer;font-weight:600;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.65 ui-monospace,monospace}.hash{overflow-wrap:anywhere;font-size:.85rem}footer{color:#555;margin-top:40px}@media(max-width:600px){body{padding:20px 16px}h1{font-size:1.6rem}td,th{padding:8px}}@media print{body{max-width:none;padding:0}nav{display:none}h2{break-after:avoid}tr{break-inside:avoid}a{color:inherit}}'''
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>轨道重心与真实 PreLN：资源桥接和后缀路线反例</title><style>'+style+'</style></head><body>'+body+'</body></html>'
(D/'RESEARCH_REPORT.zh.v1.html').write_text(page)
(D/'REPORT_SOURCE_BINDINGS.v1.json').write_text(json.dumps(bind,indent=2,ensure_ascii=False)+'\n')
print(len(page.encode()),hashlib.sha256(page.encode()).hexdigest(),len(items))
