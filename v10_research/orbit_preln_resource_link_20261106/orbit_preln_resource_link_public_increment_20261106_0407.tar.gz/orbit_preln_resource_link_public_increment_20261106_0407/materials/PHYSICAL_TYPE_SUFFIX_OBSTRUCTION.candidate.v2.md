# Physical growing-width type-invariant approximation forbids suffix-only domination

6 November 2026 UTC. Private analytical candidate v2. Version 1 is preserved; this revision corrects an out-of-domain b=N remark in Section 7.4. No upload, experiment, parameter generation, numerical model execution, training, or finite-arithmetic certificate. This is a theorem composition and a scope clarification, not a new estimator or statistical rate. Independent review is required before treating this exact file as accepted.

## 1. Architectural and statistical scope

Fix c in (0,1/2). Let P_c be all homogeneous binary order-two kernels with every transition probability in [c,1-c], with arbitrary initial-pair law. The prediction target is the kernel at the actual final context (X_(N-1),X_N); risk is expected total variation of the reported binary distribution from that target.

Use EXACTLY the network family Q_N of the reviewed WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md, not a purported compilation of the different clipped-MLE predictor in CONSISTENT_TYPE_ESTIMATOR_SUFFIX_OBSTRUCTION.candidate.v1.md. Q_N is source-independent and length-dependent. It receives N raw symbols, public positions and one synthetic terminal, not supplied counts, pairs, suffix statistics or source parameters.

The family obeys the same positive-epsilon ordered-causal PreLN/ordinary-output/full-norm conventions as the reviewed two-read ordered-suffix model: self-inclusive causal softmax attention; actual complete PreLN residual blocks; epsilon one, gain two, shift zero at every LN; bounded affine/ReLU FFNs; final actual LN, bounded affine vocabulary head and ordinary vocabulary softmax. It buys d=O_c(N) width, rather than remaining inside the ordered-suffix theorem's fixed-width subclass. A sufficiently large c-dependent envelope is fixed once for every N; it is not an unchecked prescribed numerical norm budget. Gain is bounded as an operator, not as the Euclidean norm of its d stored diagonal entries.

All statements below use exact-real execution semantics. Approximate invariance is an all-history output assertion, not exact invariance of physical row states or attention values.

## 2. The precise reference estimator already compiled

For each context v and j in {0,1}, let

 C_(v,j)(x) = sum_(i=3)^N 1{(x_(i-2),x_(i-1),x_i)=(v,j)}.

For v=(x_(N-1),x_N), set J=C_(v,0)+C_(v,1), and

 B_j(x)=(C_(v,j)+1)/(J+2).

Choose the fixed dyadic a used in the wide theorem, with 0<a<=min(c,1/4). Define the mathematical reference

 F_N(x)_j=max(B_j(x),a) / [max(B_0(x),a)+max(B_1(x),a)].

This is the actual wide theorem's ideal floored reference, not clipped MLE and not the intermediate rounded piecewise-linear-log output. Sections 3–5 of that theorem prove, uniformly over ALL binary histories,

 TV(Q_N(x),F_N(x)) <= epsilon_N := N^(-1/2)/64.          (1)

Indeed its log interpolation contributes at most N^(-1/2)/128 and its physical final-logit error contributes at most N^(-1/2)/128. The ordinary binary-softmax TV Lipschitz bound gives (1). No expectation, typical-history qualification, or physical exact decoding is inserted here.

The inherited full-history add-one theorem and binary flooring contraction give

 sup_(P,mu in P_c) R_(P,mu)(Q_N)
 <= U_N := min{1, 13 sqrt(32/(N-1)) + epsilon_N}
 = O_c(N^(-1/2)).                                      (2)

This risk controls the actual terminal context, including its dependence on the observed counts. The constant displayed in (2) is conservative and inherited. For N>=4, U_N<=K/sqrt(N), for example K=100 suffices. Constants in architecture and the fixed envelope still depend on c.

## 3. All-history approximate type invariance

Write x~y if their eight triple counts agree and their final ordered pair agrees. Then B(x)=B(y), hence F_N(x)=F_N(y) exactly. By (1),

 sup_(x~y) TV(Q_N(x),Q_N(y)) <= 2 epsilon_N
                                        = N^(-1/2)/32. (3)

Thus Q_N is an actual physical network with vanishing diameter on every such type class. This includes every orbit of the reviewed endpoint-preserving local type moves. The bound is for ANY two members of an orbit and does not accumulate with the number of moves, because each output is compared to the same exact F_N.

Triple counts alone without terminal-context preservation are insufficient for this inference. No claim is made that all universal source-preserving maps necessarily preserve that terminal context. Nor does this approximation create exact invariance of the physical network.

## 4. Fixed-source logarithmic-suffix obstruction

A suffix-b predictor means any source-independent measurable rule S_(N,b)(X_(N-b+1):N,U) reporting a probability vector, where U is independent private randomness. It may depend on public c,N,b, use unlimited computation, and use the final context when b>=2, but receives no earlier data, source parameter, or correlated advice. A program that looks at the full history and merely rewrites it into a short string is NOT covered by this information restriction.

Take the two fixed sources P_-=IID Bernoulli(c) and P_+=IID Bernoulli(1-c), including their IID initial laws. Both belong to P_c. Let Delta=1-2c. For the two suffix laws with masses f_-,f_+, the pointwise triangle inequality gives

 [R_-(S)+R_+(S)]/2
 >= (Delta/2) sum_z min(f_-(z),f_+(z))
 = Delta e_b,                                         (4)

where e_b is the equal-prior optimal binary testing error. Randomization does not help: apply the inequality for each U, then integrate. The all-zero and all-one suffixes together contribute 2c^b to the overlap, so e_b>=c^b. This avoids any tie-handling assumption in majority testing.

For every integer 1<=b<=log N/[4 log(1/c)],

 [R_-(S)+R_+(S)]/2 >= Delta N^(-1/4).                  (5)

Combining (2) and (5), some one of these same two sources satisfies

 R_sigma(S)-R_sigma(Q_N) >= Delta N^(-1/4)-U_N.         (6)

The right side is positive for all sufficiently large N. Therefore no suffix-b predictor sourcewise dominates Q_N, even on this fixed two-source subclass. The assertion quantifies over every suffix predictor, not merely another network with comparable resources. Arbitrary randomized output replacements are included.

If an additive domination slack tau_N is permitted, (6) still rules it out whenever tau_N<Delta N^(-1/4)-U_N. The lower is on task risk, not on reproducing Q_N's outputs.

## 5. Stronger classical source-varying corollary: every sublinear suffix

The restriction b=O(log N) above comes from insisting on the SAME separated pair c and 1-c. It is not a fundamental limit of suffix information. Here is a separate, elementary minimax calculation; it adds no new statistical-rate claim.

For 1<=b<=N put

 delta_b=min{(1/2-c)/2, 1/(8sqrt(b))},
 theta_-=1/2-delta_b, theta_+=1/2+delta_b.

These IID kernels lie in P_c and delta_b<=1/8. The Bernoulli KL upper bound KL(p||q)<=(p-q)^2/[q(1-q)] gives

 KL(Ber(theta_+) || Ber(theta_-)) <=32 delta_b^2.

Consequently the product suffix laws satisfy KL<=32b delta_b^2<=1/2. Pinsker gives TV<=1/2 and hence overlap >=1/2. The same integrated triangle inequality, now with target separation 2delta_b, yields

 [R_(theta_-)(S)+R_(theta_+)(S)]/2 >=delta_b/2
 >= k_c/sqrt(b),
 k_c := (1/2) min{(1/2-c)/2,1/8}>0.                   (7)

Thus, for every suffix rule, one admissible IID source satisfies

 R_theta(S)-R_theta(Q_N) >= k_c/sqrt(b)-U_N.            (8)

If b=b_N=o(N), then sqrt(b)U_N ->0, so eventually this is strictly positive, and in fact the excess is at least k_c/(2sqrt(b)). This applies to any integer sequence b_N>=1. For b=0 there is already a constant two-source lower with no observations. For b sufficiently large that delta_b=1/(8sqrt(b)), the explicit lower in (7) improves to 1/(16sqrt(b)).

Unlike Section 4, the two witness parameters here can depend on b. The source-selection quantifier is minimax: for each N,b and predictor there is an offending source. It does NOT exhibit a single fixed IID source that defeats every member of an arbitrary b_N-growing predictor sequence. It DOES rule out uniform sourcewise domination over P_c by any sublinear-suffix sequence.

This is a direct observation-information lower, not circular use of an old architecture depth-risk theorem. Combining a full-history risk with a suffix sample lower establishes the restriction on suffix replacements, but cannot establish an arbitrary-message communication lower or an optimal architectural resource frontier.

## 6. Full resource ledger imported without alteration

For fixed c, the actual Q_N uses the following resources.

- Complete model width d=O_c(N), with inert coordinates charged; FFN intermediate width O_c(N).
- Actual paid complete-block depth D=O_c(log N), including all positional selection, predecessor extraction, count decoding, parallel logarithm, scratch clearing and amplitude restoration.
- One head per block, exactly TWO pathwise useful uniform-attention invocations. The first has a wide value bank; the second aggregates triple histograms. Zero dummy-attention blocks remain part of D. Two useful reads are not a necessity lower.
- Uniformly bounded complete per-token state/value norms, full matrix operator norms, full bias-vector norms and primitive Lipschitz constants. Full all-token Frobenius norm and total distributed memory are NOT bounded independently of N.
- O_c(log N) bits per coefficient description, exact rationals/dyadics as specified by the wide theorem. An optional all-dyadic approximation exists with the same orders, but is not needed here. The displayed constant in (1) refers to the theorem's stated parameter choice, not an arbitrary additional rounding.
- Conservative dense untied parameter storage O(N^2 log N) coefficients and O_c(N^2 log^2 N) description bits. Explicit LN gain/shift storage O(N log N) is included and dominated.
- Rolling all-row real activation storage O(N^2); materialized attention scores O(N^2) extra slots. These are real-number slots, not a finite-bit memory theorem.
- Dense local projection/FFN work O(N^3 log N). Two useful full-width attention products cost O(N^3). Evaluating every dummy attention slot densely instead yields O(N^3 log N) attention work.
- An explicitly sparse representation stores O(N log N) nonzero coefficients, or O_c(N log^2 N) bits including O(log N)-bit indices and coefficients. Sparse local work is O(N^2 log N). Naive wide attention remains O(N^3); exploiting the exactly uniform prefix weights permits O(N^2) prefix-sum arithmetic for the useful reads. These are separate execution conventions.
- Public-position descriptions cost O(N log N) bits. An explicitly materialized full causal mask costs O(N^2) bits.
- Neither coefficient generation nor the LN square roots/ordinary softmax evaluation has an executed finite-word stability certificate. No training or learned-parameter assertion is made.

The lower comparator in Sections 4–5 has unlimited computational resources after receiving the suffix; its limitation is access to samples. The resource ledger prevents presenting this growing-width witness as cheap under fixed-width, scalar-value, total-work, parameter-bit, or distributed-memory budgets.

## 7. Failed shortcuts and unresolved gap

1. Compiling the clipped empirical MLE from the symbolic consistent-obstruction note by citing the wide add-one compiler would substitute a different estimator without proof. This file uses the exact add-one/floor reference already compiled. The two estimators need not agree.
2. Exact type invariance of the add-one reference does not imply exact physical invariance after nonlinear PreLN approximation. Only the uniform O(N^(-1/2)) orbit diameter (3) is proved.
3. The network is in the same broad architectural/norm contract, but NOT the same fixed-width resource class. Calling this a fixed-width counterexample would be false.
4. The fixed-width ordered-suffix theorem permits powers of two 4<=b<=N-2. Choosing an admissible b=Theta(N) provides inherited O(N^(-1/2)) risk at separately paid O(N) depth. That is not the logarithmic-depth wide witness, and its suffix statistic does not by itself prove the all-history full-type invariance in (3). Version 1 incorrectly suggested b=N, outside that theorem's domain; the mistake is preserved there and corrected here.
5. A fixed-separated-source lower decays exponentially with b; it cannot alone prove all b=o(N). Section 5 explicitly changes to local alternatives and labels its minimax quantifiers.
6. No suffix-only lower forbids an arbitrary short message summarizing the whole history. Such a message can contain empirical counts or another useful statistic, and the acquisition/communication/precision costs require their own analysis.
7. A canonical orbit representative computed from all of x need not be suffix-computable. Thus (3) does not settle a general finite-group task-folding theorem; it rules out the additional conclusion that a risk-preserving replacement can discard all but a sublinear raw suffix.
8. The O(N^(-1/2)) rate and classical two-point inequalities are inherited standard ingredients. The useful closure here is an explicit physically normalized, all-history approximately invariant, resource-honest counterexample to an overbroad suffix-domination assertion.
9. No fixed-width, O(log N)-depth analogue is proved. No lower for arbitrary nonlinear evolving-memory networks or arbitrary interactive protocols is proved. These gaps remain open.

## 8. Exact source bindings

- ../nonlinear_statistical_frontier_20261106/WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md; SHA256 28d7230b9b6b131daa05f6d5a58b3a26d562ca54845e09db13ff9785f5d39e0e. Core physical family, uniform reference approximation, risk and resources.
- ../nonlinear_statistical_frontier_20261106/INDEPENDENT_WIDE_PRELN_AUDIT.v1.md; SHA256 e1d63353f82226ff15de75372c4e428a41780411e5d7b6a62ee5d439c4390d7b. Exact-file review accepting the growing-width physical construction under its stated assumptions.
- ../local_orbit_task_folding_20261106/CONSISTENT_TYPE_ESTIMATOR_SUFFIX_OBSTRUCTION.candidate.v1.md; SHA256 83b42f71263b46a22e462b808bde2344dbd68c3938e970847074175653e857d9. Symbolic clipped-MLE precedent and fixed-source suffix obstruction; NOT the estimator being compiled here.
- ../ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md; SHA256 a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2. Reviewed fixed-width architectural comparison; not a width-equivalence claim.

Historical dependencies of the wide theorem remain dependencies; this note is not an independent reproof or a closed reproduction bundle.
