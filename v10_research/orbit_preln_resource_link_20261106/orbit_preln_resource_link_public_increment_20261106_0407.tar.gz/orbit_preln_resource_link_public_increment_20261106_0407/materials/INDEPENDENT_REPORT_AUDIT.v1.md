# Final semantic and document-integrity audit

6 November 2026 UTC.

## Exact deliverable

`RESEARCH_REPORT.zh.v1.html`

- Bytes: 107222.
- SHA-256: `577e9bb97ba9b7f738ac48bbc4e60294154fd3a7477079659b244034668d8b5d`.
- Body: `REPORT_BODY.zh.v1.html`, embedded exactly.
- Independent static results: `INDEPENDENT_REPORT_INTEGRITY.v1.json`.

PASS for semantic fidelity, exact source embedding and version bindings, and scoped static privacy checks. No visual-render acceptance or finite-arithmetic scientific validation is supplied.

## Mathematical summary and composition

The report accurately presents the reviewed two-reset construction as an actual fixed-width PreLN extension under its identified inherited suffix and output modules. It preserves the necessary endpoint-extension identity, pays selector and arithmetic stages, and labels invocation value dimensions (3,2), not two scalar reads. The sufficiently large fixed envelope is distinguished from an arbitrary prescribed numerical cap.

The folded-side compiler pays for a serial probability barycenter spline and log-probability conversion before the ordinary final softmax. Its total slope variation, coefficient rounding and complete-state preparation explain the claimed fixed-width bound. The report correctly separates nonuniform online depth independent of r from exponential naive offline table construction, and does not claim a certified numerical parameter generator or learned realization.

The combined sourcewise inequality is correct because both physical references use the same suffix d and reset phases. Hard-side uniform error delta and folded-side uniform error epsilon add to the previously proved exceptional term. For b=Theta(log N), delta,epsilon=Theta(b^−2), hard-side depth is O_c(log N+b+log(1/delta)) and folded-side depth is O_c(log N+b+epsilon^−1/2), both O_c(log N). The excess is O_c(b^−2) plus the displayed exception. The older single-sigmoid Taylor penalty need not be paid because this construction approximates the probability barycenter itself. This is a risk comparison, not an improved estimation rate. Useful-read assertions remain subject to the candidates' common ablation schedules and sufficiently small error budgets.

The physical suffix-obstruction summary uses the actual compiled add-one/floor reference, not the preceding clipped estimator. The all-history error, approximate endpoint-preserving type modulus and terminal risk constants match its audited source. The report explicitly purchases O(N) width and large storage/work, and distinguishes source-varying local alternatives from a single fixed source. Its sublinear-suffix impossibility is an observation restriction, not a lower bound for arbitrary summaries or interactive communication.

Classical interpolation, group averaging, testing inequalities and inherited compilation routines are not claimed novel. External comparisons remain labeled abstract-level, and no theorem-level acceptance of those external papers is supplied by this audit. Historical compiler dependencies are not transitively re-proved.

## Preserved failures and versions

Read the two additional failed-route companions in full. They correctly retain cross-zone and endpoint mistakes, full-feature normalization, pre-amplitude preparation, scalar-versus-vector costs, offline table precision, physical approximate invariance, and finite-word caveats. The two-reset companion's absence of a numerical expanded matrix certificate does not negate its finite-envelope existence theorem, but prevents claiming a particular unverified numerical width/norm cap.

The old physical-type candidate v1 is visibly preserved as historical material. Accepted version 2 explicitly corrects its inadmissible b=N aside to an admissible linear-size suffix, without asserting full-history type invariance for that alternate suffix construction. The report's principal proof and summary use version 2.

## Independent integrity and privacy checks

Parsed the assembled HTML independently, decoded all 11 preformatted appendix blocks and compared each to its named source file. Each source is embedded exactly once, every on-disk SHA-256 equals its manifest value, and every declared hash occurs in the report. The complete Chinese body is an exact substring.

No script, iframe, object, embed, form, input, event-handler attribute or javascript URL was found. Review and targeted pattern scans found no private absolute workspace paths, coordination identifiers, credentials or sensitive personal records. Content consists of research prose, formulas, research-source filenames, hashes and public literature references. Relative research-document paths serve provenance; they are not private machine paths. These are scoped checks, not a guarantee against every conceivable privacy issue.

No visual rendering, mathematical enumeration, numerical diagnostics, model execution, parameter generation, training or upload was performed. File reads, hashing and HTML parsing were document checks only. This audit binds the exact report hash above; later modifications require a new integrity binding.
