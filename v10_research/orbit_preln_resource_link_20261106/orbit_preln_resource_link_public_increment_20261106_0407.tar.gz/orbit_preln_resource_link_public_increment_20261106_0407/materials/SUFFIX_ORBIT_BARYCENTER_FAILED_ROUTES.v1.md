# Suffix barycenter compiler: failed shortcuts and exact obligations

6 November 2026 UTC. Companion to SUFFIX_ORBIT_BARYCENTER_PRELN.candidate.v1.md. Analytical record only; no scientific execution, training or upload.

1. Averaging logits is not averaging probabilities. The symmetric sign sum has mean zero, so averaged logits produce sigmoid(d), not M(d). Replacing M by sigmoid(d) requires the separate variance penalty (1/8)sum_j rho_j^2. The candidate instead pays for approximating M and log(M),log(1-M).

2. An external average of ordinary-softmax networks is not an ordinary-softmax network in the frozen model. Concatenating normalized branches also changes full-feature LN. The candidate builds one logical circuit and compiles the entire enlarged state once.

3. An arbitrary-MLP compiler claim would hide the actual attention and output obligations. The candidate only uses the existing one-uniform-head suffix program, rederives its sole-read local defect, and gives the exact local homogeneous update. Padding/restoration are identified inherited routines, not a new general-attention theorem.

4. Precision chosen at the pre-padding logit bank is insufficient. Later approximate arithmetic/clears change the full norm seen by LN. All output copies, padding and clears must precede the definition of m and the choice of eta. Original and head-ablated references need common parameters if usefulness is asserted.

5. A wide hinge layer is not free under bounded full-state and matrix norms. The compiler serializes hinges. A bound on individual coefficients alone would not bound serial partial sums; bounded total slope variation supplies that missing bound.

6. Counting 2^r branches does not establish an exponential online lower bound. This family depends on the suffix only through one bounded scalar d. Its average has uniform first/second derivative bounds, so a precomputed scalar spline has O(epsilon^-1/2) online stages independent of r. What remains expensive in the naive method is coefficient preprocessing, not the compiled online network. This does not prove optimal preprocessing or a general finite-group compiler.

7. Public coefficients are not costless certified computation. The table's naive generation uses O(2^r epsilon^-1/2) sigmoid evaluations. Defining rounded constants proves an existence/description statement, not finite-time generation or numerical correctness. Arbitrary real amplitudes need a representation or approximation oracle. Rounding table nodes and then dividing by a shrinking mesh can amplify error; the candidate records a sufficient conservative error budget rather than ignoring it.

8. Exact lattice decoding and exact scratch clearing do not hold physically merely because the reference has them. The uniform continuous-stage error recurrence covers actual perturbed states and all residual scratch. The candidate does not use a physical exact-support or exact suffix-only assertion.

9. The folded-side compiler does not compile the hard r-phase family. Sourcewise comparison with a physical nuisance model remains conditional on its separate uniform error zeta_h. The finite-group measure-preserving theorem itself is exact and does not need a physical implementation of the proof-device group average.

10. Constant width is not constant total work. There are N+1 rows, O(N) rolling storage, one dense useful read costing O(N^2), and ND local work. Tiny eta also entails growing coefficient precision; bounded coefficients do not imply stable finite-word execution.

11. Bounded total amplitude does not remove the source exceptional-event dependence on r. Balanced banks shorten as r grows, giving decay on the (N-b)/r scale. The direct scalar approximation cannot repair that separate probabilistic loss.

12. Fixed c alone does not control an unbounded total-amplitude R. The interior floor for log conversion is sigmoid(-(B+R)); constants are fixed only when R is bounded in advance. Claim O_c rather than O_(c,R) only if R is a prescribed c-dependent constant.

13. An arbitrary tolerance does not automatically preserve useful-head ablation separation. The monotone barycenter derivative has a positive c,R-dependent lower bound, but the physical error must be smaller than the inherited reference margin. The candidate states that threshold and otherwise claims only one nonzero attention invocation.

14. The direct spline does not create a better estimator or a risk lower bound. It removes the implementation gap on the folded side of an existing task-risk inequality. It neither improves the old suffix statistical rate nor establishes optimal depth, novelty, trained realization, or a general evolving-memory frontier.
