# Audit: two reset-zone physical PreLN phases

6 November 2026 UTC.

PASS for `TWO_RESET_PHASE_PRELN.candidate.v1.md`, SHA-256 `d7b96c268272ffc3405550241a5ff5c89fdf45e7e98a78d511c729c728412b76`, as an explicit new reference program composed with its stated inherited suffix and padding routines under the sufficiently large fixed-envelope contract. No numerical width cap, arbitrary prescribed small norm budget, finite-word reliability, or statistical optimality is certified.

## Reset identities and local stages

The paid position selector clips the signed grid difference before repeated doubling. Negative differences remain zero and the smallest positive grid difference reaches one after p doublings. This exactly realizes A_h without an unbounded slope-P matrix. The differences defining u_j and w_j are the stated Boolean masks on raw positions. The latter includes the indispensable extra row e_j+1.

Masked prefix sums count only bits in their own zones. At a shared boundary, the first prefix remains frozen while the second starts, so no cross-zone pair is introduced. For a pair l<k in one zone, the summation over i=s_j+1,...,e_j+1 counts it e_j−k+2 times. Since e_j is even, this multiplicity has parity k, giving precisely the reset quadratic phase. Without the endpoint extension it would have the opposite parity.

The product/square/tent construction matches Sections 3.1–3.2 of the inspected IID quadratic v3 source. Inputs i/P and r are in [0,1]; product clipping keeps the square input in that interval. The second-read values are clipped to [0,1], and exact Boolean masking cannot enlarge error against the masked target. The terminal average and multiplication by T/P preserve the less-than-4nu error. U_j/P^3 lies in [0,1/2]. The terminal gate clears other rows before folding, and 3p folds amplify by at most P^3. The plateau recovers the exact logical parity on every Boolean history. No physical trajectory is assumed to retain those exact lattice values.

## Invocation and state accounting

The first invocation has three values: two masked prefix averages and the unchanged packed-suffix value. The second has two values, one per zone. Fresh destinations, protected raw shadows, retained masks, and serially reused scratch are explicit. This is two vector-valued invocations with dimensions (3,2), not two scalar reads. The stated five-scalar-read alternative is a different schedule.

The first ablation zeros both prefix and suffix averages. The exact identity M(a,0)=0 keeps quadratic values zero, and the inherited zero-code suffix path stays legal. The second ablation zeros phase inputs only. Both are included in the common reference envelope and tube before amplitude selection.

## Physical compilation and output

Reviewed the cited square/product/tent source, the fixed-floor ordinary-softmax source, and the relevant padding/restoration formulas in STANDARD_PRELN v2. The new candidate applies those routines to one combined paired program rather than concatenating separately normalized networks.

Logit copies, padding arithmetic, square-root approximation and all scratch clears precede m_pre and eta selection. The two uniform-read defects include the source normalization factor s(z_i) on the entire vector. Fixed value dimensions change only constants. The max-row full-vector recurrence propagates these and local FFN errors, so approximate clears and off-grid selectors are not silently treated as exact.

The restored norm deviation and final ordinary-LN/affine/softmax error formula match the inherited output routine. The displayed dyadic tolerance allocation bounds the error by delta; selecting the smallest adequate amplitude exponent gives the stated depth and coefficient orders. Gain-two reparameterization halves the appropriate consuming matrix and preserves trajectories. Full per-token states and operator/bias norms have an existential fixed c-dependent envelope; no matrix-by-matrix numerical envelope is claimed.

The two usefulness witnesses are valid for the specified positive unequal amplitudes and the additional small-delta condition. A zone-one parity-one history exists with zone two zero, and second-read ablation changes its nuisance by 2rho_1. The first-read ablation has the inherited baseline gap on an all-symbol-2 suffix; the maximum nuisance loss is bounded by 2(rho_1+rho_2). Common physical approximation preserves these gaps. If general amplitudes include zeros, or delta is not sufficiently small, an unqualified two-useful-invocation claim should not be inferred; the candidate supplies the needed nontrivial family and smallness condition.

## Task comparison and limits

The exact finite-group result applies to this same reset-phase reference and same d. Triangle inequality adds the hard-side delta and independently compiled baseline error. The four-probability barycenter is not identified with softmax of mean logits. This file does not compile that barycenter; the separate folded-side candidate does so. No sourcewise multiplicative risk ratio, output-simulation lower, or generic frontier follows.

The fixed-width result is conditional on the explicit inherited finite-envelope suffix/padding modules, not on a desired resource lower bound. Those historical modules are not re-proved in full here. Administrative reads and hashes are not scientific execution; no experiment, training, rendering or upload was performed.
