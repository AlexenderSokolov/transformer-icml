# Audit: physical type approximation versus suffix-only replacement

6 November 2026 UTC. Symbolic composition and scope review; no model execution.

## Exact bindings and verdict

PASS for `PHYSICAL_TYPE_SUFFIX_OBSTRUCTION.candidate.v2.md`, SHA-256 `ca075a815144da5a8911703687ec696e8151d8143af78ecc12c084489025fb80`, as a composition with its explicitly inherited physical theorem.

Read the full `WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md` (SHA-256 `28d7230b9b6b131daa05f6d5a58b3a26d562ca54845e09db13ff9785f5d39e0e`) and its exact-file `INDEPENDENT_WIDE_PRELN_AUDIT.v1.md` (SHA-256 `e1d63353f82226ff15de75372c4e428a41780411e5d7b6a62ee5d439c4390d7b`). Their historical dependencies remain dependencies, not independently re-proved by this review.

The accepted conclusion is an actual growing-width physical family with all-history approximate endpoint-preserving type invariance and uniform full-history risk, not exactly physically invariant or fixed-width. It rules out uniform sourcewise domination by sublinear raw-suffix observation rules, not arbitrary short-message or interactive task simulation.

## Reference, risk and constants

The reference is precisely the wide theorem's add-one transition estimator followed by lower flooring and binary renormalization. It is not the different clipped empirical estimator from the preceding symbolic round. At terminal inputs the add-one output is a probability vector; upper clipping used by the compiler at other rows therefore does not change this reference.

The wide source gives interpolation-logit infinity error at most N^(-1/2)/128 and physical final-logit error at most N^(-1/2)/128. Binary softmax TV is at most the logit infinity error, so their sum gives epsilon_N=N^(-1/2)/64 uniformly over all histories. The binary flooring contraction is valid because the true probability coordinates exceed the chosen floor. Combining the actual-terminal add-one risk with this uniform approximation proves the displayed U_N. In particular 13 sqrt(32N/(N−1))+1/64<100 for N≥4, so U_N≤100/sqrt(N). Dependence between empirical counts and final context is already covered by the inherited statistical bound, not replaced by an independent query.

Equal eight triple counts and equal terminal context imply equal reference output. Two applications of the uniform epsilon bound give the diameter 2epsilon_N for any pair in such a class, independently of orbit path length. This does not establish exact physical invariance or intermediate-state invariance.

## Observation lower bounds

For two source laws with suffix masses f_-,f_+ and target separation Delta, pointwise triangle inequality weighted by their minimum mass gives mixture risk at least (Delta/2) times their overlap. The same bound holds after integrating independent predictor randomness. Under fixed IID parameters c and 1−c, the two constant suffixes contribute 2c^b overlap for b≥1, establishing the logarithmic-suffix result with its stated quantifiers.

For the source-varying result, delta_b≤1/8 implies theta_-(1−theta_-)≥15/64. The Bernoulli KL bound is therefore at most (256/15)delta_b², and the stated looser 32delta_b² is valid. Product KL is at most 1/2, Pinsker gives TV≤1/2, overlap is at least 1/2, and mixture risk is at least delta_b/2. The inequality delta_b/2≥k_c/sqrt(b) holds for all integers b≥1. Combining with U_N=O(N^(-1/2)) makes the excess positive eventually for every b_N=o(N), including bounded sequences. No fixed-source witness for the entire varying sequence is inferred; the alternatives may vary with b.

No desired depth lower bound is used in either observation argument. Unlimited suffix-local computation and arbitrary output distributions are permitted, so this is actual task risk rather than output reconstruction.

## Resource fidelity and revision

The width, depth, invocation counts, value-width caution, full per-row norms, dense and sparse storage/work, and exact-real coefficient-description ledger match the cited wide theorem. Explicit LN gain storage is charged. Bounded gain operator does not mean bounded Euclidean gain-parameter vector when width grows. All-row storage and total work are not confused with per-token norms.

Version 1 (SHA-256 `67bf9e61193db15e3d6915c2165fe012ee3f33c6fa1b289990a249266faa646d`) had an out-of-domain b=N aside about the separate ordered-suffix theorem. Version 2 corrects it to admissible b=Theta(N), pays linear depth, and no longer infers full-history type invariance from that suffix route. The main wide-family proof is unchanged. Only version 2 is accepted here.

## Companion scope review

`PRIOR_AND_MODEL_COMPARISON.v1.md`, SHA-256 `54979f0dac88c2493bef90b48c677f31d625febace2fce641c221b639b1d6d41`, correctly labels its external checks as primary-abstract comparisons rather than full-theorem audits. Its comparisons distinguish smooth approximation, low-precision/CoT expressivity, padded circuit characterizations, and the frozen exact-real statistical task. No external novelty or theorem-level validation is certified by this review; the cited external abstracts were not independently re-fetched here.

`PROOF_OBLIGATIONS_AND_FAILED_ROUTES.v1.md`, SHA-256 `299f0371937b091e170d9773212d0bd1a076b0264bd67648668f00075404455d`, correctly retains obligations for probability-to-logit conversion, offline interpolation costs, full-state normalization, reset-zone multiplicities, value dimensions, width purchase, and approximate invariance. It neither turns an unfinished compiler into an accepted theorem nor claims a general frontier.
