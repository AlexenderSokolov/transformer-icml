# Audit: ordinary-softmax physical suffix barycenter

6 November 2026 UTC.

PASS for `SUFFIX_ORBIT_BARYCENTER_PRELN.candidate.v1.md`, SHA-256 `ed69fb1d16fc7f6fb3de55995a1f6ab3701deca92e18a0f6fb8e863e8bf7509f`, under its explicit inherited suffix and norm-padding/restoration dependencies and exact-real, sufficiently large fixed-envelope contract.

## Scalar spline and bounded states

For bounded total amplitude R, all arguments lie in [−B−R,B+R]. Uniform derivative bounds M'≤1/4 and |M''|≤1/4 follow termwise. The common output floor is independent of the number of phases. Grid spacing h≤sqrt(delta) gives interpolation error at most delta/32.

Each secant slope is an interval average of M'. Adjacent intervals differ by a shift h; their averages differ by at most h/4. Thus the absolute slope-jump sum is at most B/2. Together with |beta|≤1+B/4 and |s_0|≤1/4, this bounds every serial accumulator by 1+B/2+B² before rounding. This total-variation argument is sufficient for a full-state bound independent of grid size; bounding individual coefficients alone would not suffice.

Independent nearest-dyadic coefficient errors contribute at most Delta[1+B+2B(J−1)]/2, below delta/16 under the stated mesh. Rounded coefficient total error is also bounded uniformly, preserving partial-state and primitive bounds. Dyadic knots have logarithmic descriptions. Serial hinges use fixed scratch and pay O(J) stages, rather than hiding a J-wide matrix or uncharged output layer. Clipping to [a,1−a] is a paid projection and cannot increase error to the true M.

## Log conversion and error budget

The two log splines use coordinates already in [a,1−a]. Their interpolation-grid and rounding bounds match the inspected INTERIOR_SOFTMAX v2 serial log construction. The resulting normalized exponential of the exact log probabilities equals the desired probability vector. For two logits, an infinity perturbation lambda gives probability error at most tanh(lambda/2); the coarser lambda bound used in the budget is valid. Adding delta, lambda and physical final-logit nu, each at most epsilon/4, proves the claimed uniform error below epsilon. A mixture of softmaxes is never equated with softmax of averaged logits.

## Physical program and useful read

The sole read remains the inherited scalar packed-suffix invocation. All appended computation is an explicit bounded serial affine/ReLU program. The reference includes all copied logits, paid padding/root stages and cleared scratch before its length and amplitude exponent are fixed. The whole-vector tube and normalized-read defect include all feature coordinates. The inherited restoration and final gain-two LN plus bounded affine vocabulary head then yield the displayed final-logit bound. Actual intermediate decoded symbols and cleared registers need not be exact.

The gain-two interior conversion is exact after halving its consuming matrices. The specified fixed envelope may depend on c and R but not N,b,r or epsilon. This is a model-contained extension of the particular inherited suffix machine, not an arbitrary-attention compiler. Historical count/readout and padding modules remain explicit dependencies.

Strict positivity of M' on the bounded interval transfers the inherited head-ablation d-gap to a positive folded-output gap. The candidate correctly requires sufficiently small epsilon and a common original/ablated physical schedule before calling the one nonzero invocation useful. No necessity lower is claimed.

## Resource and construction quantifiers

Online direct-spline depth O_(c,R)(log(N+1)+b+epsilon^(−1/2)) is justified, including final amplitude restoration. Its independence of r is a nonuniform network-existence result: the scalar coefficients encode the amplitude-specific barycenter. Offline table definition costs 2^r sigmoid evaluations per node, and the candidate charges sign sums, summations, amplitude descriptions and their precision. It provides no finite transcendental-evaluation or parameter-generation algorithm.

For approximate node computations, forming slopes divides by h and summing hinge errors can cost another J. The stated sufficient node tolerance O(delta h/J) therefore controls this amplification. Arbitrary real amplitudes require an oracle or an explicit approximation promise; summed amplitude error e changes M by at most e/4. Neither such data nor the true source parameter is free runtime input.

The branchwise alternative has exponential online depth, and its averaging errors do not accumulate by 2^r because branch weights sum to one. Runtime storage can remain fixed by unrolling the coefficient stream. The network depth, coefficient bits, dense row work and real-state storage are separately charged. No finite-word stability follows from their finite descriptions.

## Sourcewise composition

The orbit argument supplies the expected excess sum_j rho_j gamma^(m_j)/4. Uniform hard-side approximation zeta_h and folded-side approximation epsilon add by triangle inequality, giving exactly the displayed sourcewise risk comparison. For the separately certified two-reset physical family, its delta may serve as zeta_h because the reference and d agree. For arbitrary growing r, the hard-side physical realization remains a separate obligation. Exceptional probabilities degrade as zones shorten; bounded total amplitude alone does not restore an r-independent exponential-in-N failure rate.

No new statistical rate, universal task-folding theorem, interactive lower, trained realization, or finite-precision execution is certified. No scientific computation, rendering, or upload was performed.
