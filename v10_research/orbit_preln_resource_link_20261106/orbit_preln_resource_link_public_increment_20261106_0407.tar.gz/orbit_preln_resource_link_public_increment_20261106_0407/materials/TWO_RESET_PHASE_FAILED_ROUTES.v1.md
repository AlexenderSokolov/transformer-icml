# Failed shortcuts and exact remaining certificate gap

6 November 2026 UTC. Companion to TWO_RESET_PHASE_PRELN.candidate.v1.md.

1. Summing binomial zone-prefix counts only through even endpoint e gives pair multiplicity e-k+1, hence the EVEN-k quadratic phase. That is not the requested reset phase. The selected second-read interval must extend to e+1 while first-read bit inclusion stops at e.
2. A global prefix count restricted only at the second read retains pre-zone bits and creates cross-zone quadratic terms. Each first-read value must itself mask the raw bit to its own zone.
3. A selector with a direct slope P violates the fixed matrix envelope. Paid clipped doublings implement public-grid comparisons with all intermediate states bounded.
4. Two invocations here carry (3,2) values. Calling them two scalar reads is false. Scalar serialization consumes five useful invocations. Fixed value dimension still enters full matrix norms.
5. Direct concatenation of existing physical normalized parity and suffix networks does not establish correctness: every LN sees all banks. Build one combined logical program and use the actual two-head scalar-normalization recurrence on its enlarged full-state tube.
6. Choosing eta before appending norm padding, scaled-logit copies and clears does not control the final normalized output. All these operations enter m_pre before amplitude precision is selected.
7. Exact logical phase plateaus do not license treating physical phases as exact bits. Their errors must propagate through the paid continuous program and be measured at the final vocabulary probabilities.
8. Serial log accuracy and physical comparison accuracy are different costs. For arbitrarily tiny delta, keep the baseline serial log tolerance at O(b^-2); shrinking that log tolerance to delta could introduce delta^-1/2 depth. Only preparation/restoration and amplitude precision need log(1/delta).
9. The four-branch orbit mean is an average of probabilities, not the softmax of mean logits. The separate baseline comparison pays the quadratic Taylor remainder; no internal network averaging theorem is claimed.
10. Exact-real coefficient precision is not a finite-word execution guarantee. LN arithmetic, exponential softmax, rounding accumulation and underflow require an additional concrete arithmetic model and error proof.
11. Existing dependency documents provide fixed finite envelopes and fixed register-machine constructions but not a complete numerical expanded matrix certificate. The new candidate therefore certifies the direct algebraic adaptation under those stated module contracts, not membership in a particular numerical width/head-dimension/matrix-norm cap. To remove that last gap, expand the inherited binary suffix decoder/count/division and norm-padding square-root programs into an instruction inventory, allocate registers once, and calculate every full matrix, bias, state and Lipschitz bound. Do not fill this gap with an arbitrary claimed number.
