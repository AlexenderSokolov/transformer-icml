# Architecture bridge: proof obligations and retained failed routes

6 November 2026 UTC. Work-in-progress scope record. This round seeks explicit physical examples and conditional resource links, not a general T1/T2 theorem.

1. Averaging probabilities is not averaging logits. A usual final softmax needs a paid conversion from the desired orbit barycenter to bounded logits. A symbolic mixture alone is not a physical realization.
2. Exponentially many branches need not force exponentially large ONLINE neural depth: a one-dimensional smooth barycenter may be tabulated and interpolated. However offline node construction, public coefficients, description length and approximation error remain paid. This is a standard approximation mechanism, not proof of efficient learning.
3. All-row boundedness, fresh attention destinations, scratch registers, norm-padding and clears must be included BEFORE choosing the small physical amplitude. Normalization changes every nonterminal value; exact logical phase identities need not hold in the physical intermediate states.
4. A new multi-zone parity formula must count prefix-pair multiplicities with the actual region boundaries. Simply copying the old full-history parity identity can leave cross-zone terms or the wrong parity. Any fixed region mask is a public position-dependent constant, not an input-dependent oracle.
5. Full matrix norms and value dimensions matter. Two vector-valued attention invocations are not two scalar reads when the value dimensions exceed one. Head count, summed value dimensions, width and total per-layer work must all be recorded.
6. The existing full-history growing-width PreLN estimator can obstruct suffix-only replacement. This does not contradict a fixed-width theorem and cannot be called a general communication lower. Width O(N), distributed state O(N^2), and coefficient storage are part of the witness.
7. Exact reference type invariance transfers only to an approximate physical rewrite modulus through the uniform end-to-end error. It does not yield exact physical invariance.
8. Classical empirical transition rates, IID two-point testing, smooth interpolation, invariant convex-risk averaging and inherited PreLN output routines are prior tools. A composition must not be presented as a new estimation rate or priority-certified general principle.
9. A generic O(risk^-2) suffix estimator does not become O(depth) without a separate model argument. The earlier equivalence remains in force.

No training, numerical model validation, finite-operation arithmetic guarantee, repository upload, publication or purchase is authorized or performed in this round. Scientific claims are analytical; document construction is not a scientific experiment. Any incomplete physical obligation must remain explicitly open rather than being filled by a generic compiler assertion.
