# Orbit barycenter and actual PreLN resource bridge

This new additive local package preserves all 20 available source files byte-for-byte, including all candidate versions, scoped audits, failed routes, report/body, scripts and historical QA. No source was overwritten and no GitHub action occurred. Open materials/RESEARCH_REPORT.zh.v1.html directly for the complete Chinese report, with 11 exact local appendices and its separate report audit.

## Theorem scope and resource accounting

The two-region reset-phase construction uses two uniform reads with value dimensions (3,2), not two scalar heads. It has fixed width/full norm envelope and all-history TV error at most delta at paid depth O_c(log N+b+log(1/delta)). Copies, padding and clearing are fixed before selecting the small-amplitude precision. This is an analytical actual PreLN construction, not executed matrix/register or finite-arithmetic validation.

The smooth scalar orbit barycenter is converted to ordinary final softmax using one scalar read, fixed width and depth O_(c,R)(log N+b+epsilon^(-1/2)), with all-history TV error at most epsilon. Direct-table online resources can be independent of phase count r, but naive offline table generation still costs a factor 2^r. This is neither free learning nor an executed parameter generator. Fixed R and other declared smoothness/domain conditions must remain explicit.

Combining the two sides gives sourcewise risk increment at most delta+epsilon+(rho_1+rho_2)(1-2c^8)^m/4. At the stated logarithmic suffix and b^(-2) tolerances, both paid depths are O_c(log N), without the old single-sigmoid quadratic-amplitude penalty. This is a conditional task comparison, not a new statistical estimation rate or a universal resource lower bound.

The physical approximate-type-invariance example reuses an existing O(N)-width/O(log N)-depth estimator. It rules out sourcewise domination by a raw suffix of length b=o(N) in its stated setting; it is not a fixed-width counterexample or a lower bound against arbitrary short interactive messages. Width, state, precision and work must remain charged. General T1/T2 resource questions remain open.

## Status, privacy and use

No scientific execution, mathematical enumeration, numerical model diagnostic, parameter-generation run or training occurred in this increment or packaging. Numerical matrix/register certificates and finite-arithmetic execution remain incomplete. Visual acceptance is NOT COMPLETED. Exact-version analytical reviews are not formal verification, external peer review or novelty certification. Group averaging, smooth interpolation, prior compilation tools and classical rates are not claimed as new principles.

External compiler/estimator proof dependency closure remains OPEN and was not transitively reproved. This is not recovery of a complete v10 corpus. Privacy/copyright inspection found no secrets, sensitive personal information, private conversations or machine paths requiring redaction. Third-party papers are cited/summarized rather than redistributed in full. No new license or rights grant is introduced; this is not legal clearance.

SOURCE_DERIVATION_MAP.json records every source/public file and exact size/hash. PACKAGING_QA.json separates new static checks from preserved historical QA. Independent package review and historical audit index are under independent_review/. SHA256SUMS and python verify_package.py provide read-only integrity checks. Existing report scripts write documents; run only in a disposable copy. Relative dependency references retain original-source meaning and may not resolve after relocation.
