# Independent pre-seal public-package review

6 November 2026 UTC. **PASS for faithful packaging, exact source bindings, scoped privacy review and preservation of scientific limitations.** Final checksum sealing remains pending; no source files were modified.

- All 20 source files are present under materials/ and byte-identical. Every source/public size and SHA-256 in SOURCE_DERIVATION_MAP.json matches independently calculated values.
- All 11 HTML appendices decode to their named source text exactly once, with matching manifest hashes. The report body is embedded exactly.
- Report identity: 107222 bytes; SHA-256 577e9bb97ba9b7f738ac48bbc4e60294154fd3a7477079659b244034668d8b5d.
- Historical audit-index bindings match. Both physical suffix candidate versions and all failed-route records are preserved, including the explicit correction of the older inadmissible b=N aside.
- The package preserves two-reset value dimensions (3,2), fixed-width/full-envelope conditions, paid preparation and depth. It does not relabel these as two scalar reads.
- The barycenter account distinguishes fixed-width online scalar approximation from naive 2^r offline table-generation costs, retaining bounded-amplitude/domain conditions and the absence of a certified numerical parameter generator.
- The approximate-type-invariance counterexample explicitly purchases O(N) width and remains a raw-suffix observation obstruction, not a fixed-width or arbitrary-message communication lower bound.
- Dependency closure remains OPEN. No executed training, parameter generation, numerical matrix/register certificate, finite-arithmetic validation or visual acceptance is asserted.
- Content inspection and targeted scans found no credentials, sensitive personal records, private conversations or private absolute machine paths. External papers are cited and summarized; no third-party full papers or PDFs are redistributed. This is scoped inspection, not legal clearance.
- No active HTML elements were detected. Python files parse successfully; preserved report-building scripts were inspected, not executed.

Remaining packaging step: create SHA256SUMS after adding the final review, then run the read-only verifier against the sealed inventory. At review time the seal did not yet exist. No scientific reruns, source writes or GitHub actions were performed.
