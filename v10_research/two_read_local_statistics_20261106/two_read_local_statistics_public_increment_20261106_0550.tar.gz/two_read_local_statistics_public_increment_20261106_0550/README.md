# Two-read local statistics: public research increment

All 44 source files are represented: 41 exact copies and three neutral prior-audit derivatives. Only operational retrieval/coordination wording changes; failures, provisional status and all scientific content remain. All proof/report versions, rare-entropy checks, separate QK audits, old static extraction, scripts and registry records are retained. Source originals remain untouched. No GitHub write occurred.

Open materials/RESEARCH_REPORT.zh.v3.html for the unchanged final report with five adapted appendices. These are documented adaptations, not raw-byte source embeddings. Prior-audit sections 7/8 are omitted by the original report adapter; public neutralization there does not change the adapted report. Historical source-match records bind original audit hashes; the public mapping gives derivative hashes, and PACKAGING_QA verifies identical adaptation. Report v1/v2 are byte-identical historical snapshots: their difference is an external QA correction to a false event-handler detection, not a scientific revision.

## What is proved and what is not

The source-average entropy inequalities concern accurate local reconstruction: robust all-lag errors require order-N transcript entropy; rare local-context error at most u/256 requires order N*u*log(1/u). These are not general terminal prediction-risk or unknown-parameter estimation lower bounds. Even knowing transition parameters does not reveal realized local symbols. Accurate aggregate terminal prediction need not reconstruct all individual local features.

The bounded-QK extension is under its stated one-head-per-read, fixed full Q/K/V norm and key-dimension conditions, with paid stabilized polynomial-feature suffix replay. Its A(d+1)(D+1)^(k+1) charge is tied to the local task entropy and explicit exact-real versus finite-grid ledgers. It must not be silently promoted to a matching unrestricted repeated-attention terminal-risk frontier.

The u-blind suffix result rules out every sublinear public suffix budget against the declared triangular rare-source full-history conditional benchmark. Source-independent budgets and the overall output-range floor remain explicit. Physical implementation transfers through uniform pathwise comparison error, not assumed exact suffix measurability. A globally chosen suffix is not every row's moving suffix. Rare indicators do not carry full symbol entropy, and additional earlier-prefix conditioning invalidates the naive rare reverse-entropy identity.

All these failed shortcuts and corrections remain available. Direct aggregate computation, cancellation or another evolving-memory algorithm remains possible. No missing reduction from terminal risk to local reconstruction is supplied by the package. Standard entropy/Fano inequalities, feature maps and approximation methods are credited; no novelty or publication-readiness certificate is asserted.

## Validation, privacy and use

No scientific execution, enumeration, model run, parameter generation or training occurred. Visual acceptance is NOT COMPLETED. Finite-arithmetic reliability, formal verification, external peer review and external proof dependency closure remain unestablished. This is not complete v10 recovery.

Scoped privacy/copyright review found no secrets, personal sensitive records, private correspondence or machine paths. The public prior-audit derivatives preserve retrieval failure facts without tool/account details. Builder string filters are code, not disclosures of actual private events. 'Parent transcript lemma' is a mathematical dependency reference. Papers are cited/summarized rather than redistributed in full; no new license is added and this is not legal clearance.

SOURCE_DERIVATION_MAP.json records every original/public hash, size and exact edit. PACKAGING_QA.json separates new checks from immutable historical records. independent_review/ holds audit index and packaging review. SHA256SUMS and python verify_package.py supply read-only integrity checks. Builders write files and must run only in disposable copies. Source-relative dependencies may not resolve from this relocated snapshot.
