# Source-average local reconstruction barrier for repeated uniform reads

6 November 2026 UTC. Private analytical candidate, pending independent exact-file review. No mathematical executable, numerical diagnostic, source simulation, model execution, upload, or public write was performed. This note applies standard binary Fano/entropy inequalities to the existing global-transcript suffix reconstruction lemma. It makes no novelty claim.

**Result:** the former all-word local-lag obstruction strengthens to a genuine expected-fraction-of-local-errors lower bound under the actual stationary rare source. It also extends to multiple full-prefix **uniform** reads. It is still a representation-specific result, not a terminal statistical-risk lower bound.

## 1. Frozen source and its nonvanishing entropy rate

The binary second-order source has pair states A=00, B=01, C=10, D=11 and

    pi=(u,w,w,w),  w=(1-u)/3,  q_src=ut/w,
    P=[[1-t,t,0,0],[0,0,1/2,1/2],
       [q_src,1-q_src,0,0],[0,0,1/2,1/2]],
    0<u<=1/100,  1/2<=t<=3/4.

The history X_1:N starts in stationarity. All entropies and logarithms below are in bits. Write h_2 for binary entropy and

    h_* = u h_2(t)+w h_2(q_src)+2w >= 2w >= 33/50.       (1)

This is exactly H(X_i | X_1:i-1) for every i>=3, averaged under the stationary law. Consequently, for any m>=2,

    H(X_(m+1):N | X_1:m)=(N-m)h_*.                     (2)

Also H(X_1:N)>=N h_* for N>=2: stationarity and conditioning give both H(X_1)>=h_* and H(X_2|X_1)>=h_*. No independence of the raw symbols, no iid transition-count assumption, and no terminal conditioning are being asserted.

The source has high symbol entropy even when A is rare, because the B and D rows supply fair transitions. This fact will obstruct recovering most raw local lags. It does not itself say that estimating the one rare-row parameter requires recovering those lags.

## 2. Actual network contract and the error criterion

There are T=N+1 physical rows, the final row a fixed, source-independent sentinel. Initial row states depend only on the row's own raw symbol and public position/length. The model has D counted synchronous primitives, of which A are useful full-inclusive-prefix uniform attention invocations. Positionwise computation may precede, separate, and follow the invocations. Every readout is row-local and is included among the counted primitives.

At invocation ell the value vector is

    v_i^ell = V_(ell,i)(h_i),  dimension r_ell,
    a_i^ell = (1/i) sum_(s<=i) v_s^ell.

All relevant local maps and value maps are C-Lipschitz in full Euclidean norms, with a fixed C>=1; ||v_i^ell||<=M on actual reachable states. Attention's local residual/output update is C-Lipschitz in the joint pair consisting of its local state and its received average. All constants are uniform in N, source parameters, width, depth, and positions. These bounds cover the frozen positive-epsilon/gain-bounded PreLN, bounded complete affine maps, residuals, and paid ReLUs. They exclude singular normalization and uncharged readout gain.

For convenience the maps are globally Lipschitz, as the stated ordinary primitives are. Equivalently, one may use fixed same-Lipschitz extensions of the restrictions to reachable input sets for the proof-only simulation. The simulated points need not be actual reachable network states. This is not a modification or a finite-precision execution of the actual network.

Let r_(j+1) be its numerical predecessor rail, targeting X_j, for j=1,...,N. Fix eta<1/2 and define

    e_j = Pr{|r_(j+1)-X_j|>eta},
    epsilon = (1/N) sum_(j=1)^N e_j.                  (3)

Thus epsilon is the source expectation of the fraction of bad rows. Different histories may fail at different rows; no single history need have every rail correct. The fixed numerical margin is essential. Bare correctness of the sign of a vanishing-amplitude score is not the hypothesis.

The effective exact-real transcript dimension is

    Q=sum_(ell=1)^A r_ell.

For several same-mask uniform heads, either concatenate the actual value messages with their full norm budget, or collapse exact linear output mixing into one effective value map. The latter is legitimate only when it has a uniform full-map/full-value bound. If r_ell<=W, then Q<=AW. This effective exact-real dimension will not automatically be the finite-arithmetic dimension in Section 7.

## 3. Quantized global transcript and causal suffix replay

Define the proof-only global averages and transcript

    z_ell(X)=(1/T) sum_(i=1)^T v_i^ell(X),
    Z(X)=(z_1,...,z_A) in R^Q,
    ||Z(X)||<=M sqrt(A).                              (4)

Later values may depend on their entire causal prefixes. No assumption that they remain functions of their own raw symbols is made.

Let m=floor(N/2), n=N-m, and assume N>=4. Fix a target bit j in {m+1,...,N}. A proof-only decoder receives a quantized transcript Zhat and the **true** future raw symbols X_(j+1):N. It initializes exactly the suffix rows i>j, including the fixed sentinel, and replays the network's primitives on those rows only.

At a uniform-read stage it computes, from the already simulated pre-read suffix states,

    vhat_i^ell = V_(ell,i)(hhat_i),
    ahat_i^ell = (T/i) zhat_ell
                -(1/i) sum_(s>i) vhat_s^ell,  i>j.    (5)

All values on the right of (5) are from the pre-read layer, so there is no circular dependency. The exact execution satisfies the same complement identity with hats removed. Values from unknown earlier rows are absorbed into the global average.

If Delta is the maximum suffix-state error before the stage and delta_ell=||zhat_ell-z_ell||, then T/i<=2 and (T-i)/i<=1 for every i>j. Therefore

    ||ahat_i^ell-a_i^ell|| <=2 delta_ell+C Delta,
    Delta_new <=C(1+C)Delta+2C delta_ell.              (6)

A local stage multiplies Delta by at most C. The initial error is zero. Take a fixed

    B>=max{2,C,C(1+C),2C}.

Iterating the at most D primitives, including the row-local output, gives the deliberately loose bound

    max_(i>j) ||outputhat_i-output_i||
       <=D B^D ||Zhat-Z||.                            (7)

This construction is different from recursively guessing the history backwards. Every bit has its own genie-aided decoder with the true suffix supplied. There are no propagated token-decoding errors. The only propagated errors are bounded numerical replay errors in (6).

## 4. Source-average Fano bound

Put g=1/2-eta>0 and choose a Euclidean covering of the radius-M sqrt(A) transcript ball with radius

    delta=g/(2D B^D).

A maximal delta-separated set gives such a finite cover with cardinality at most

    L <= (1+2M sqrt(A)/delta)^Q
       = (1+4M sqrt(A)D B^D/g)^Q.                    (8)

Let K(X) be the deterministic index of a covering center and Zhat its center. This quantization occurs only in the proof; the exact actual network is not rounded. Equation (7) makes the simulated scalar rail differ from the actual rail by at most g/2. On the event |r_(j+1)-X_j|<=eta, its distance to X_j is at most eta+g/2<1/2. Thresholding the simulated rail at 1/2 therefore correctly predicts X_j on that event.

Let p_j denote the error probability of this genie decoder. Then p_j<=e_j. Give the first half X_1:m as additional side information, although the decoder above ignores it. Binary Fano and the reverse conditional entropy chain imply

    H(X_(m+1):N | X_1:m,K)
      =sum_(j=m+1)^N H(X_j | X_1:m,K,X_(j+1):N)
      <=sum_(j=m+1)^N h_2(p_j)
      <=n h_2(pbar),                                (9)

where pbar is the mean p_j over these n target indices. No conditional independence is used. If

    epsilon_tail=(1/n)sum_(j=m+1)^N e_j <=1/2,

then pbar<=epsilon_tail and monotonicity on [0,1/2] gives

    H(X_(m+1):N | X_1:m,K)<=n h_2(epsilon_tail).

Combining (2), I(X_(m+1):N;K|X_1:m)<=H(K)<=log_2 L, and (8) proves

    Q log_2(1+4M sqrt(A)D B^D/g)
       >= n [h_*-h_2(epsilon_tail)].                 (10)

For the all-row expectation epsilon in (3), epsilon_tail<=N epsilon/n<=2epsilon. Thus, whenever epsilon<=1/4,

    Q log_2(1+4M sqrt(A)D B^D/g)
       >= n [h_*-h_2(2epsilon)].                     (11)

In particular, any fixed epsilon with h_2(2epsilon)<33/50 forces a linear-in-N transcript-bit budget. A concrete convenient condition is epsilon<=1/32. Since h_2(1/16)<3/8, the right side is at least (57/200)n, and therefore exceeds N/8. This constant is intentionally nonoptimal.

For an expected scalar absolute error criterion

    R=(1/N)sum_j E|r_(j+1)-X_j|,

take eta=1/4. Markov's inequality gives epsilon<=4R. Therefore R<=1/128 also implies the same N/8 lower bound in (11), with g=1/4. More generally retain the actual entropy gap instead of these convenient constants.

When A=0, Q=0, or all value messages are identically zero, the transcript is a single point and exact suffix replay uses no quantization error. Equations (9)-(10) then directly forbid the same small-error hypothesis. No division by a zero resource is intended.

## 5. Paid width, invocation, and depth consequences

For fixed C,M,eta, and 1<=A<=D,

    log_2(1+4M sqrt(A)D B^D/g)
       =O(D+log(A+1)+log(D+1)).

Under a fixed positive entropy gap in (11), this yields

    Q [D+log(A+1)+log(D+1)] = Omega(N).              (12)

If every effective message dimension is at most W,

    AW [D+log(A+1)+log(D+1)] = Omega(N).             (13)

Since A<=D and D>=1, one may absorb the displayed logarithms into D and write AW D=Omega(N), with the frozen constants understood.

Consequences for the numerical local-rail representation, and only that representation:

- Fixed W and a fixed number of useful uniform reads require D=Omega(N).
- Fixed W with A<=D requires D=Omega(sqrt(N)).
- If both A and D are O(log N), W=Omega(N/log^2 N).
- If A=O(1) and D=O(log N), W=Omega(N/log N).

Thus a fixed-width polylogarithmic-depth uniform-read pipeline cannot form mostly correct fixed-margin local predecessor rails, even merely on average under this rare source. The statement allows evolving memory and values that already depend on earlier attention; this is the substantive repeated-read improvement over a one-read additive code.

The depth and all attention/readout computation remain charged. There are still T physical row states, so fixed per-row width is not fixed total memory. Usual dense full-prefix attention has O(AT^2 W) arithmetic work, with the actual value/head dimensions substituted as appropriate; pointwise work adds O(TD) at fixed width. A global transcript used in a proof is not an extra network input, a free implementation, or a communication protocol supplied to the model.

## 6. Sharper one-read specialization

For one uniform read with values v_i(X_i) of dimension d and norm at most V, followed only by local continuation of Lipschitz constant Lambda, the entire history can be used, without discarding the first half.

Let Z=(1/T)sum_i v_i(X_i). For each j, t=j+1, knowledge of the true future gives the local current-row state and all values after t. Reconstruct

    otilde_t=(T/t)Zhat-(1/t)sum_(i>t)v_i(X_i).

Its error is at most T||Zhat-Z||, and the rail error is at most Lambda T||Zhat-Z||. Cover the radius-V ball with radius g/(2Lambda T). The same reverse entropy chain over all N bits gives, for epsilon<=1/2,

    d log_2(1+4V Lambda T/g)
       >= H(X_1:N)-N h_2(epsilon)
       >= N[h_*-h_2(epsilon)].                       (14)

The sentinel is necessary here to supply the last bit's receiving row with fixed local input. If it is absent, give X_N as a free boundary symbol and lose at most one entropy bit and one lag target. This changes no linear-order consequence.

Under Lambda<=A_0^D with fixed A_0>1, fixed d,V,g and a fixed positive entropy gap, (14) gives D=Omega(N). This is a genuine source-average strengthening of the earlier all-word zero-score packing statement, rather than the invalid assertion that every history has to be reconstructed simultaneously.

## 7. Finite-grid counterpart, with a different dimension ledger

This is a separate arithmetic theorem, not a precision assumption silently imposed on the exact-real network.

At every stage/head, each actual value coordinate immediately before accumulation lies on the common grid 2^(-p) Z and has absolute value at most M_f. Each head forms its exact prefix sum, then applies deterministic division/rounding based only on that sum and public row index. Head mixing and all local updates/readouts may be arbitrary deterministic maps. There are no other cross-row operations. Let

    Q_f=sum_(ell,head) r_(ell,head)

be the total **actual pre-rounding head dimension**. Record the exact unnormalized global sum of every such coordinate in a transcript S. Each scalar sum has at most

    L_f=2 floor(T M_f 2^p)+1

possible values, so H(S)<=Q_f log_2 L_f.

Given S and a true future suffix, replay the suffix states exactly: at every head subtract the suffix value sum from the global sum, then use precisely that head's declared deterministic division and rounding. This reproduces every receiving-row output exactly. No Lipschitz hypothesis, robustness margin, or approximate replay is needed.

If a fixed row-local binary decoder of each actual output has expected tail classification-error fraction e_tail<=1/2, the same conditional entropy argument gives

    Q_f log_2(2 floor(T M_f 2^p)+1)
       >=n[h_*-h_2(e_tail)].                         (15)

An all-row classification-error fraction epsilon gives e_tail<=2epsilon. Numerical eta-accurate rails with eta<1/2 are a sufficient special case, but here a discontinuous local binary decoder is allowed because the transcript replay is exact and finite-valued.

For fixed M_f and a fixed entropy gap, (15) implies

    Q_f [p+log_2 T+O_(M_f)(1)] = Omega(N).            (16)

To substitute Q_f<=AW, one must separately assume the **total pre-rounding dimensions over all heads** at each invocation are at most W. H heads each with W coordinates instead give Q_f<=AHW. Exact-real algebraic collapse of head outputs does not justify collapsing this finite transcript after independent headwise rounding. Order-dependent/edgewise rounded accumulation and unspecified floating-point formats are not covered.

## 8. Full triple-onehot features, versus rare-only features

The same repeated-uniform-read proof covers numerical full local triple-onehot features F_i targeting e_(X_(i-2),X_(i-1),X_i), i=3,...,N. Use the Euclidean error threshold eta_tri<sqrt(2)/2 and define its source-expected bad fraction over these N-2 rows. Include the complete eight-dimensional output in the Lipschitz/depth budget.

For j=m+1,...,N-1, the true future and replayed output at row j+1 identify X_j whenever that output is within sqrt(2)/2 of its correct onehot. Quantize tightly enough that replay contributes at most half of sqrt(2)/2-eta_tri. The nearest-onehot decision is only a mathematical decoder for the entropy argument, not an unpaid network primitive.

Give X_N as an extra boundary symbol. With ell=N-m-1 target bits,

    H(X_(m+1):(N-1) | X_1:m,X_N)
       >=(N-m)h_*-1.

For N>=6 the tail bad fraction is at most twice the all-triple bad fraction epsilon_tri. Therefore the analogue of (11), with g replaced by sqrt(2)/2-eta_tri, has right side

    (N-m)h_*-1-ell h_2(2epsilon_tri).                (17)

This is again Omega(N) for a fixed sufficiently small bad fraction. It excludes a pipeline that first forms almost all accurate full local triples and then pools them, including one that never names explicit lag rails.

This corollary does **not** cover only the two rare-A indicators 1{triple=000},1{triple=001}. Returning zero for both already has error only on the O(u) fraction of A departures. Such rare-only features do not determine the raw symbols needed by the entropy chain. Nor does a lower bound on per-row feature errors imply a lower bound on an aggregate count: correlated errors, cancellation, or an entirely different decomposition can still make a useful aggregate. No inference of terminal prediction risk is licensed by (17).

## 9. What was strengthened, and what remains unavailable

Established here, subject to independent review:

1. The old all-word lag requirement can be relaxed to small expected fraction of fixed-margin numerical lag errors under the actual stationary rare source.
2. Multiple uniform reads are covered by a transcript of all global means plus genie-aided suffix replay. Later values are allowed to depend on earlier reads.
3. Standard Fano converts source entropy, rather than worst-word cardinality, into the resource bound.
4. An explicit common-grid finite evaluator admits the analogous source-average bit bound without a Lipschitz assumption.

Not established:

- Any lower bound for actual-terminal conditional-A TV risk or overall next-token TV/KL risk. A good terminal estimator need not reconstruct many raw lags, and the bounded-final-logit rare-C floor remains a separate issue.
- Necessity of an increasing invocation count for rare-parameter estimation. The known wide one-read estimator is compatible with the bound and pays width.
- A repeated **nonuniform**-attention bound. The exact complement identity (5) is specific to uniform prefix weights. A possible global feature-code approximation for bounded bilinear QK requires a separate checked replay argument, including all approximation and stability errors; it is not proved in this file.
- A bound from exact-real mutual information alone. The exact PreLN scalar injection still retains the full history law. The present proof instead quantizes only as accurately as fixed-margin, bounded-sensitivity local decoding requires.
- A bare sign-error lower without a fixed numerical margin in the exact-real theorem. Quantization can reverse arbitrarily tiny signed outputs; such an extension is not justified by this proof.
- A direct count-approximation lower, a rare-only feature lower, a universal two-read obstruction, or an equal-total-resource statistical separation.

Preserved failed approach: sequentially decode an entire word backwards from a quantized code, then claim small original per-row error prevents propagation. That claim is false without further control. The proof here avoids it by conditioning each entropy term on the true future separately. It also does not transfer worst-history packing to source-average risk without this entropy argument.

## 10. Sources and attribution

Local proof dependencies inspected:

- `../parallel_terminal_estimator_20261105/ALLROW_SINGLE_INVOCATION_OBSTRUCTION.candidate.v1.md` and its independent audit, for the one-read zero-score packing setup and fixed-margin limitation.
- `../transcript_width_lower_audit_20261104/sources/transcript_packing_candidate.v3.md`, for the existing repeated-uniform global-transcript lemma and distinction between effective exact-real dimensions and pre-rounding finite dimensions.
- `../rare_statistical_resource_reset_20261106/RARE_PARITY_INFORMATION.candidate.v1.md`, for the exact stationary rare family.
- `../rare_attention_information_bridge_20261106/PROBLEM_CARD_AND_FAILED_TARGETS.v1.md`, `EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md`, and `ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md`, for the mother contract and the already documented separation between exact information, useful decoding, width, and terminal risk.

The entropy chain rule, binary Fano inequality, concavity of binary entropy, and Euclidean covering bound are standard. The repeated-read suffix recurrence is reused from the existing transcript note. This file's derived step is their application to source-average robust local reconstruction under the specified rare law. No prior-art novelty or priority assertion is made.
