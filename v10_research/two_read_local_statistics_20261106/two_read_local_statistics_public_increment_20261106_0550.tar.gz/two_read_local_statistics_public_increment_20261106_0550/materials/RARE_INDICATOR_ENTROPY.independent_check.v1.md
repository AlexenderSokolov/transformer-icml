# Independent check: the rare local-pair indicator entropy term

6 November 2026 UTC. Mathematical check of a proposed extension to `SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v1.md`, not an exact-file audit of a later extension. No scientific execution, simulation, training, parameter generation, upload or public write.

## Verdict

The proposed rare-indicator extension is valid under the SAME fixed-margin numerical local-output and uniform-read suffix-replay contract. The necessary change from the raw-lag proof is to use the unconditioned reverse raw-symbol information chain. Giving the entire first half as additional side information would change the claimed per-term entropy and is unnecessary.

Let K be the finite covering code of the exact global uniform-read transcript. Let

    Z_j=1{X_j=X_(j+1)=0},
    F_j=X_(j+1):N,
    j in J={floor(N/2)+1,...,N-2},
    n=|J|=N-floor(N/2)-2.

Use N>=8 below. The decoder for Z_j may inspect the true suffix F_j and replay all physical rows greater than j, exactly as in the parent transcript lemma. Its relevant output may be at row j+1 or at a later row in that suffix.

## 1. Exact conditional entropy

Stationary time reversal with pair reversal leaves the rare binary symbol kernel unchanged. Conditional on the first two future symbols, the distribution of X_j is the corresponding reversed transition law. Later future symbols add no information about X_j once those first two are fixed.

- If (X_(j+1),X_(j+2))=(0,0), of probability u, then Pr(X_j=0 | future)=1-t and H(Z_j | future pair)=h_2(t).
- If that pair is (0,1), of probability w, then Pr(X_j=0 | future)=q=ut/w and H(Z_j | future pair)=h_2(q).
- If X_(j+1)=1, then Z_j=0 deterministically, irrespective of X_j.

Therefore the EXACT common entropy for all j in J is

    h_rare=H(Z_j | F_j)=u h_2(t)+w h_2(q).            (1)

The j<=N-2 restriction ensures the observed future contains two symbols. No conditional iid count premise is used.

## 2. Correct information-chain inequality

Because Z_j is a function of X_j and F_j, conditional data processing gives

    I(Z_j;K | F_j) <= I(X_j;K | F_j).

Summing only a subset of the nonnegative terms in the reverse raw-symbol chain gives

    H(K) >= I(X_1:N;K)
         >= sum_(j in J) I(X_j;K | F_j)
         >= sum_(j in J) I(Z_j;K | F_j).

For deterministic covering K, the first inequality is equality. The resulting bound is

    H(K) >= n h_rare - sum_(j in J) H(Z_j | K,F_j).   (2)

It is not necessary, and would generally be unjustified, to replace a conditional entropy of a vector of overlapping Z_j by a sum of their entropies. Equation (2) avoids that error by chaining the raw symbols first.

Suppose the fixed-margin numerical replay yields a binary decoder with errors p_j, where the original robust output failure probabilities are e_j and p_j<=e_j. Let e_tail=(1/n)sum_(j in J)e_j<=1/2. Binary Fano, concavity and monotonicity imply

    sum_j H(Z_j | K,F_j) <=sum_j h_2(p_j)
                            <=n h_2(e_tail).

Thus

    H(K) >= n[h_rare-h_2(e_tail)].                   (3)

Insert the same covering-cardinality upper bound from the repeated-uniform-read proof to obtain the resource inequality. Only the source entropy/error term has changed.

## 3. Explicit u-uniform constants

For 0<u<=1/100 and t in [1/2,3/4],

    q=ut/w <= (25/11)u < (5/2)u,
    h_2(t)>=3/4,
    log_2(5/2)<4/3.

Since h_2(q)>=q log_2(1/q) and the relevant logarithms are positive,

    h_rare
      >=(3u/4)+(u/2)[log_2(1/u)-4/3]
      >=(u/2)log_2(1/u).                            (4)

Write L=log_2(1/u). The usual elementary bound

    h_2(x)<=x[log_2(1/x)+log_2(e)]

and L>=log_2(100)>3+log_2(e) give

    h_2(u/8)<=(u/8)[L+3+log_2(e)]<=(u/4)L.          (5)

Consequently e_tail<=u/8 yields

    h_rare-h_2(e_tail)>=(u/4)log_2(1/u),
    H(K)>=(n u/4)log_2(1/u).                        (6)

For N>=8, n>=N/4. If the mean robust failure probability over all N-1 adjacent-pair outputs is at most u/32, then the tail mean is at most

    ((N-1)/n)(u/32)<=u/8.

Hence a simple global criterion implies

    H(K)>=Nu log_2(1/u)/16.                         (7)

The small constant multiplying u matters. An all-zero feature has error probability u and is NOT excluded by a requirement merely described as O(u) with an unspecified large constant.

## 4. Rare departure features and the remaining boundary

If a network forms numerical features for triples 000 and 001 at row j+2, their sum targets Z_j. A fixed bounded linear sum and the correct numerical-margin conversion therefore reduce sufficiently accurate rare-A departure features to this theorem. For example, an Euclidean two-feature error eta gives sum error at most sqrt(2)eta; include this factor in the declared margin and in the replay tolerance. All needed rows lie in the supplied future suffix, so the replay argument is unchanged.

This extends the representation barrier from full local triples to sufficiently accurate rare-only local indicators. It still does not prove a lower bound for approximating a pooled count, an aggregate ratio, or actual-terminal prediction risk. Per-row errors can be correlated, cancel in a sum, or be avoided by a different statistic. No terminal-risk conclusion follows without an additional reduction.

The result is also restricted to uniform full-prefix reads with the existing complete Lipschitz and value budgets. No nonuniform QK extension has been checked here.
