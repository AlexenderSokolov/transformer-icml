# Exact-file audit of the rarity-scaled local-indicator extension

6 November 2026 UTC. Independent mathematical review. No scientific execution, simulation, model run, parameter generation, training, upload, or public write.

## Verdict and binding

**PASS for Section 9 of `SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v2.md` under its stated repeated-uniform-read and fixed-margin local-output contract.** Its conservative constants are valid and need no optimization.

Reviewed source SHA256:

    8c966282ce5369531e3bac3cf729bece4bdd8aa60694d1675295568f5ba1008a

Revision 1 was read in full and the complete revision 1-to-2 diff was checked. The repeated-uniform-read suffix replay, covering/Fano framework, source rectangle, and effective exact-real versus actual finite-grid dimension distinction are preserved. The present audit specifically binds the new rare-indicator statements and their integration with that framework. It does not certify a future bounded-QK extension.

## Checks

1. **Correct target and suffix location.** For Y_j=1{X_j=X_(j+1)=0}, a rail at row j+2 is the local transition-context indicator. A rail at j+1 is equally admissible. Both lie strictly after j, so the true-future replay applies. For N>=8, J={floor(N/2)+1,...,N-2} has ell>=N/4. Therefore the selected mean error is at most 4epsilon_A when epsilon_A is averaged over all N-2 transition contexts.

2. **Exact reverse conditional entropy.** With two future symbols available, reverse conditional probability of X_j=0 is 1-t after future pair 00 and q_src after future pair 01. These events have stationary probabilities u and w, respectively. When X_(j+1)=1, Y_j is deterministically zero. This proves exactly h_A=u h_2(t)+w h_2(q_src). Extra future factors cancel by the second-order Markov factorization. No iid or terminal-conditioning premise is substituted.

3. **Correct chain rule.** Equation (21) chains the RAW symbols in reverse without a first-half genie, then applies conditional data processing to the function Y_j of X_j and its known future. Hence the sum over J is bounded by H(K). This avoids both possible invalid shortcuts: summing entropies of overlapping indicators as if independent, or keeping the raw-lag proof's extra prefix conditioning while claiming the unconditioned reverse entropy h_A.

4. **Robust replay and Fano.** The same cover at margin g_A makes a binary threshold decoder correct whenever the original numerical rail is eta_A-accurate. Mean classification error is no greater than the selected robust-error mean. Binary Fano, concavity and monotonicity on [0,1/2] establish (22)-(23). The stated epsilon_A<=1/8 condition suffices when replacing the selected mean by 4epsilon_A; the later u/256 condition is much stronger.

5. **Constants.** q_src<=25u/11<4u, wq_src=ut>=u/2, and L_u=log_2(1/u)>=6 give

       h_A >=(u/2)(L_u-2)>=(u/3)L_u.

   If e_A,tail<=u/64, then h_2(e_A,tail)<=h_2(u/64), and

       h_2(u/64)<(u/64)(L_u+8)<=(7u/192)L_u.

   The resulting gap is at least (1/3-7/192)uL_u=(19/64)uL_u, which is stronger than the claimed uL_u/4. epsilon_A<=u/256 implies the required selected error, so ell>=N/4 yields the stated Nu log_2(1/u)/16 lower. The conditions are uniform over the declared u,t rectangle.

6. **Resource translation.** The left side in (23) is the existing bounded-radius transcript-cover bit upper. With r_ell<=W, replacing Q by its upper bound AW is valid. Frozen norm/Lipschitz/margin constants yield the displayed AW[D+log(A+1)+log(D+1)] lower. This is an inequality for robust local-feature formation, not an assertion that this feature representation is necessary for terminal estimation.

7. **Finite version.** Replacing the covering bound by the exact global-sum cardinality is valid only under Section 7's common-grid, exact-accumulation and deterministic head-rounding assumptions, with Q_f equal to actual pre-rounding dimensions. Those assumptions and their head-count caveat remain attached. The extension does not imply an instantiated floating-point certificate.

8. **Rare triple features.** Summing the two coordinates for 000 and 001 exactly yields the 00 context indicator. Its operator norm is sqrt(2); Euclidean error eta_A/sqrt(2) gives scalar error eta_A. Section 9.4 explicitly charges that factor and retains the bad-row probability criterion.

## Required interpretation

The all-zero rare indicator has error u, so it does not satisfy the sufficient u/256 condition. Merely saying that an algorithm has error O(u), without its constant, would not imply the bound's positive entropy gap.

The result establishes a rarity-scaled obstruction for forming sufficiently accurate INDIVIDUAL local indicators. It does not lower-bound error in a pooled count, a count ratio, or an actual-terminal conditional/unconditional prediction. Those gaps are explicitly retained in Section 9.4 and the conclusion. No repeated nonuniform-attention theorem or universal rare-risk gap is claimed by this audited file.
