# Independent exact-file audit of the repeated bounded-QK extension

6 November 2026 UTC. Independent mathematical review. No scientific executable, numerical diagnostic, source simulation, model execution, parameter generation, training, upload or public write. This is not formal verification or a literature-priority claim.

## Verdict and binding

**PASS for the exact-real source-average local-reconstruction and rare-indicator inequalities in the stated bounded-bilinear-QK model.**

Reviewed source:

    BOUNDED_QK_SOURCE_AVERAGE_EXTENSION.candidate.v1.md
    SHA256 2fab21861d074f60642648fb560bc081f0be46f3da4b8ae4b5d872213a7b9b12

The complete proof was read, not only its theorem statement. The source-law/Fano dependency `SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v2.md` was also read, including its rare-indicator extension, bound separately to SHA256 8c966282ce5369531e3bac3cf729bece4bdd8aa60694d1675295568f5ba1008a.

No new revision is required for the stated mathematical result. The bound is not a terminal statistical-risk lower, a general bounded-score theorem, or an executed finite-machine result.

## 1. Model and complete resource premises

The theorem fixes one bilinear-QK head per useful invocation, k-dimensional queries/keys with k bounded independently of N and D, value dimension d, fixed full-vector query/key/value norm envelopes, and fixed complete local-map Lipschitz envelopes. Conventional dimension scaling may be absorbed into those envelopes. No arbitrary pairwise positional score or additional cross-row primitive is allowed.

The suffix simulator needs the stated global Lipschitz maps, or the same-Lipschitz proof extensions allowed by the inherited contract. Ordinary positive-epsilon fixed-gain PreLN, bounded matrices and ReLUs satisfy the needed local bounds. Actual reachable query/key/value norm bounds alone do not bound simulated off-manifold values, which is why the explicit projections in Section 4 matter.

## 2. Fock feature norm and derivative are genuinely degree-independent

For phi_m(z) indexed by multi-indices of total degree at most m,

    ||phi_m(z)||^2=sum_(r=0)^m ||z||^(2r)/r! <= exp(||z||^2).

The inner product is exactly the degree-m Taylor polynomial of exp(q dot k), with feature count binom(m+k,k). The remainder bound exp(S)S^(m+1)/(m+1)! is valid uniformly for q dot k in [-S,S], including negative scores.

The mixed directional derivative of the full kernel exp(x dot y), evaluated at x=y=z, equals

    exp(||z||^2)(||v||^2+<z,v>^2).

It is the sum of squared coordinate derivatives of the full feature vector. Taking only the coordinates of degree at most m decreases that nonnegative sum. The full series and its derivatives converge uniformly on bounded balls, legitimizing differentiation. Integrating the derivative along a segment inside the convex ball proves the stated L_phi(R)=exp(R^2/2)sqrt(1+R^2), with no m factor.

The augmented value feature xi_m(k,v)=phi_m(k) tensor (v,1) then has norm at most R_*=exp(R_k^2/2)sqrt(V^2+1). Decomposing its difference into the key-feature difference times the bounded augmented value, and the value difference times the bounded key feature, gives the displayed L_xi. It also has no m dependence.

This is the essential noncircularity check: the replay constant B can be frozen BEFORE choosing the Taylor degree m.

## 3. Global transcript and suffix reconstruction

Every transcript block is a global average of ACTUAL per-stage features. Later keys and values may already depend on earlier causal prefixes; this does not change the complement identity at that stage.

Projecting a chosen covering center's blocks separately onto their R_* balls fixes each true block and contracts the total squared error. It therefore preserves the covering guarantee and does not add codewords.

For a target j in the second half, all suffix rows i>j are initially known from the true raw future and sentinel. At each attention stage the suffix simulator computes all projected query/key/value vectors from the old simulated states before updating any row. Thus there is no circular in-layer dependence.

The complement formula in Section 4 applies to the FEATURE SUM, not to the actual nonuniform attention output. It yields

    ||Uhat_i-U_i|| <=2delta_ell+L_xi Delta,
    ||U_i||<=R_*.

The contraction difference is correctly split as

    phi(qhat_i)(Uhat_i-U_i) + [phi(qhat_i)-phi(q_i)]U_i.

Using the TRUE prefix tensor in the second term avoids a spurious degree-, depth-, or approximate-state-norm factor. It proves equation (11) with frozen constants. The kernel remainder is averaged over i terms, so equation (12) correctly has no N multiplier.

## 4. Proof-only ratio stabilization

The true numerator is inside the radius V exp(S) ball and the true denominator is at least exp(-S). Consequently the numerator projection and denominator floor exp(-S)/2 leave every true ratio unchanged.

Let c=exp(-S)/2 and M=V exp(S). For projected numerators and clamped denominators, subtracting ratios gives

    ||R_stab(a,b)-R_stab(a',b')||
      <=c^(-1)||a-a'|| + M c^(-2)|b-b'|.

This is the claimed sufficient joint Lipschitz constant 2exp(S)+4V exp(3S). It holds globally, including negative or near-zero approximate denominators. The actual network is not modified: these operations only define the proof's decoder.

An additional output projection is unnecessary here. The stabilized ratio is already bounded by 2V exp(2S), and the inherited local-update maps are globally Lipschitz. Applying their fixed constant to the state and received-output differences gives equation (14) with B independent of m. Recurrence (15) is a safe loose consequence over D stages.

## 5. Degree, quantization and cardinality

With both the net radius and Taylor error at most g/(4D B^D), the final replay error is at most g/2. For the used numerical margins g=1/2-eta or 1/2-eta_A, this keeps a good numerical output strictly on the correct side of the binary threshold.

For fixed S and n=m+1 sufficiently larger than S, n!>=(n/e)^n makes the Taylor tail at most exp(S)2^(-n), after increasing the fixed degree offset if needed. Therefore n of order

    D + log(D+1) + log(1/g) + 1

suffices. No degree-dependent replay constant is concealed inside this choice. With fixed positive g and fixed k, m=O(D+1), so the feature dimension and covering-cardinality upper in equations (1)-(2) follow.

The cover is proof-only and may have dimension polynomial in D. It is not actual added network width, an input feature, or a claim that the original attention computes its Taylor approximation.

## 6. Source-average entropy transfer

The replay construction provides exactly the local binary-decoder property used in the already checked uniform theorem.

- For full lags, giving the first half as additional side information is compatible with the raw-symbol conditional entropy chain, which supplies n h_* source entropy. Fano subtracts n h_2(2epsilon).
- For rare indicators, the proof correctly does NOT give that extra prefix information. The unconditional reverse raw-symbol information chain, conditional data processing, and the exact h_A=u h_2(t)+w h_2(q_src) produce equation (4).

Thus the N/8 and Nu log_2(1/u)/16 convenient regimes transfer without a new source assumption. This is a source-average argument with a true-future genie for each individual target, not a sequential history decoder whose classification mistakes propagate.

Using A<=D and fixed k,g,budgets yields the stated A(d+1)(D+1)^(k+1) resource inequalities. For the rare variant, the strength continues to depend on Nu log(1/u) and on the stringent local-error fraction relative to u. No all-u constant raw-entropy lower is silently substituted into that variant.

## 7. Scope that must remain attached

The audited result covers accurate fixed-margin INDIVIDUAL local rails or rare indicators. It does not imply that a terminal estimator must construct those features, and it does not lower-bound a pooled count's error or actual-terminal prediction risk. Correlated local errors or a different aggregation representation remain outside its conclusion.

The fixed bounded query/key dimension, complete query/key norms, one-head accounting, absence of arbitrary pairwise positional bias, and complete Lipschitz budgets are material. Merely bounding scores is insufficient to invoke this proof. A fixed number of heads can be considered only with their dimensions, full norms and aggregate update sensitivity charged.

The uniform finite-grid theorem does not automatically extend to nonuniform softmax evaluation. This source expressly makes no such finite-arithmetic claim. Exact-real injective scalar encodings remain compatible with the result because this lower concerns a bounded-sensitivity fixed-margin use of the information, rather than its unregularized exact mutual information.
