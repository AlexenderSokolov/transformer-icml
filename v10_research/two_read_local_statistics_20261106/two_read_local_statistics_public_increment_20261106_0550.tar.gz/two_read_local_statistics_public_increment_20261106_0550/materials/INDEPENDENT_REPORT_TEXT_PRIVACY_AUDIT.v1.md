# Independent report text, scope, and privacy audit

6 November 2026 UTC. Analytical/static review only. No scientific executable, model evaluation, parameter generation, training, external upload, or public write. HTML layout/rendering is not covered by this text-only audit.

## Exact reviewed report

`REPORT_MAIN.zh.v2.md`, SHA256 `6bae69044f1940538a2a68359fea6ff848c9e9ce94490e1aa60dfd8fd1df1d6e`.

Read its complete text, the u-blind suffix candidate v1, the old fixed-width rare-softmax candidate v2 and relevant independent review, the source-average candidate v2, and the separate independent source-average audit v2. The report does not include the proposed repeated-QK theorem and is not certified to include it later without further review.

**Verdict: PASS for the present mathematical summary, claim scope, and text privacy.** Two nonblocking domain/presentation clarifications were sent to the author: make 3<=b<=N explicit in the Section 4 KL application, and write the physical transfer as conditional lower 1/128−delta and overall excess lower u(1/128−delta). These clarify assumptions already present in the source arguments and remove ambiguity about the loss of accuracy on the rare event.

## Mathematical and scope checks

1. The source probabilities, stationary law, actual-terminal target, synthetic terminal, and fixed-alpha output contract agree with the accepted source material. The report distinguishes conditional-A risk from total expected terminal TV.

2. The range floor F=w(alpha−q)_+ is a genuine lower bound in the exact output-range contract. Its u→0 limit is alpha/3, so comparing raw overall risks could hide the rare estimation task. Subtracting this same source-dependent floor is appropriate.

3. The old upper uses suffix sample size b−2, and its depth includes b, quotient and logarithm costs. The report labels it inherited, does not substitute N for b without paying full-history decoding, and distinguishes per-row width from O(N) distributed state and dense O(DN²) work.

4. The global fixed suffix is correctly distinguished from each row’s moving local suffix. The cited one-read zero-score linear-depth obstruction and bounded-QK inequality have the correct quantifiers and exponent. The repeated-uniform transcript consequence concerns local predecessor recovery; it is not advertised as a terminal-risk lower. The abandoned linear-depth two-read construction is not portrayed as an improvement over the existing serial one-read alternative.

5. The u-blind test uses a valid fixed separation h=1/32. With bu<=1, the inherited conditional KL upper is at most 120/1024<1/2. Pinsker and the common-part two-point argument yield a conditional minimax lower at least 1/128. The overall excess lower multiplies that conditional error by u while retaining the disjoint C-event range floor.

6. For b_N=o(N), u_N=(Nb_N)^(-1/2) is eventually legal, b_Nu_N→0, and Nu_N→infinity. The full-history statistical rate then vanishes conditionally while the suffix lower stays constant. The excess-risk ratio has scale (N/b_N)^(1/4). This does not impose a depth lower on arbitrary algorithms or make a source-dependent budget choice: G and epsilon can be chosen publicly from N.

7. The report correctly refuses to call the actual normalized model strictly suffix measurable. The old fixed-width candidate Eq.(8) proves pathwise distance from its strict-suffix clipped reference at most 3mu/2<=3epsilon/4. Hence conditional error transfers with loss delta, and exact physical alpha range still supplies the same total-risk floor. Merely unconditional approximation would not suffice without a 1/u factor, which the final section explicitly states.

8. The suggested alpha threshold under known u>=rho follows from min q=3rho/[2(1−rho)]. Allowing alpha to decrease changes the range/norm contract and requires logit contrast at least logarithmic in 1/rho. No one frozen positive alpha is claimed to eliminate the C floor for all u>0.

9. The average local-feature theorem is described as an entropy/Fano composition with prior suffix replay. Full symbol entropy is at least 0.66 bits per step because of common fair rows. The report does not infer that terminal parameter estimation needs all of that symbol information.

10. The rare-indicator version uses the correct reverse conditional entropy h_A=u h_2(t)+w h_2(q), and explicitly omits a prefix genie. With average robust indicator failure at most u/256, its Nu log_2(1/u)/16 transcript-bit bound matches the independently reviewed v2 proof. The report preserves the smaller rarity-scaled scope and explains why the all-zero indicator does not contradict it.

11. The finite-grid discussion retains Q_f as the actual pre-rounding total head dimension. It does not silently identify it with W, activation perturbation radius, or coefficient-description bits. Its exact accumulation/deterministic local-operation contract and lack of generic floating-point coverage are explicit.

12. The remaining opening is accurately stated: terminal statistical risk need not imply accurate local lags or indicators, and useful aggregates might be computed through another decomposition. Neither the worst-history terminal-simulation obstruction nor the current entropy argument closes that missing implication.

## Privacy and presentation

The reviewed body contains mathematical parameters, public paper-author names, research statuses, and scope qualifications only. No credentials, private service URLs, user identifiers/contact data, local workspace paths, private conversation quotes, internal task-routing metadata, or unrelated personal information were found. It does not claim any scientific run, numerical reproduction, or training was completed.

Appendices, embedded files, outgoing links, attachment metadata, and generated HTML must be checked independently after their final versions exist. This PASS is tied to the exact Markdown hash above, not an unreviewed future report or publication bundle.
