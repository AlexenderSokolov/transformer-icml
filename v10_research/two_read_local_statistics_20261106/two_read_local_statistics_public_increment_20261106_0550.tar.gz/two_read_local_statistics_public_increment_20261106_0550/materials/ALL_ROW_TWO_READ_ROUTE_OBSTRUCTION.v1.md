# Why a first uniform read cannot cheaply supply every row's last three tokens

6 November 2026 UTC. Private analytical route audit v1. This note records a failed shortcut, an applicable existing lower bound, and a deliberately stopped redundant fallback. No scientific diagnostic, model execution, parameter-generation run, training, upload, or public write was performed. Reading and writing mathematical notes are the only operations behind this report.

## Verdict

The proposed construction

1. one fixed-width uniform full-prefix read;
2. O(log N), or any polylogarithmic, bounded-gain local decoding of each row's own last three raw tokens;
3. a second uniform read of the resulting triple indicators;
4. the already paid mixed-estimator and ordinary-softmax output,

fails at step 2. This is not merely an incomplete positional-packing implementation. Under the frozen bounded-state/bounded-primitive-gain model, a first uniform read of constant effective value dimension needs linear paid local depth to recover even the predecessor at every row with constant separation. The old fixed-width suffix theorem does not provide that operation.

This does NOT establish a lower bound for terminal rare-risk estimation. A terminal estimator may use evolving history summaries without reconstructing all local tokens. That remains the relevant open algorithmic route.

## 1. Exact source mismatch

In `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`, Section 3 fixes

    i = N-b+1,
    S_t = sum_{s=i}^{min(t,N)} d_s B^{-(s-i+1)}.

The one read broadcasts S_t/t. The paid decoder processes b positions starting at this SAME globally fixed i at every physical row. Consequently:

- t<i: all b decoded digits are unavailable zeros, then replaced by the declared default for the count program;
- i<=t<N: the virtual word is the available prefix X_i,...,X_t followed by defaults;
- t=T=N+1: the virtual word is the actual last b observations.

The virtual word is legal at every row, but is NOT the last b observations of that row. In particular, its final three virtual symbols at early rows may be defaults even when three genuine local observations exist. The exact all-row legality argument supports quotient domains and the full-vector compiler. It does not establish all-row physical lag acquisition.

Making i depend on the destination row cannot be substituted into this source value: before the first read, a row's value can depend on its OWN token and public position, not on a different receiving row's desired interval. A shared scalar uniform read cannot be silently turned into destination-specific local-window reads.

## 2. A short direct lower bound for the first read

The following is a specialization of the already audited transcript argument in `../allrow_frontier_audit_20261104/INDEPENDENT_ALLROW_FRONTIER_AUDIT.md`, Sections 1 and 5. Its proof is included to identify exactly which premise fails.

Let T=N+1. Suppose all computation before the first useful read is pointwise, and the read has a q-dimensional effective value vector v_s with norm at most V. Assume every charged local primitive is C-Lipschitz, after enlarging the frozen bound once so C>=2. The raw initialization is pointwise in the current symbol and public position. After the read, let a paid local continuation of d primitives output a predecessor onehot with Euclidean error at most epsilon<sqrt(2)/2 at every row, for every word. Put

    c = sqrt(2)-2epsilon > 0.

Fix the first floor(N/2) symbols and vary the remaining n=ceil(N/2) binary symbols. For a word x define the global value transcript

    Z(x) = (1/T) sum_{s=1}^{T} v_s(x),
    ||Z(x)|| <= V.

For any two different words x,y, let j be their LAST differing index and take row r=j+1. Their raw symbols, positions, and pre-read states at every row s>j agree. The attention outputs at r therefore satisfy the EXACT identity

    a_r(x)-a_r(y) = (T/r)[Z(x)-Z(y)],

because all source values with s>r agree and cancel. Since r>T/2, the multiplier is at most two. The receiving row's other retained pre-read state is identical in the two cases. Thus the local continuation obeys

    ||out_r(x)-out_r(y)|| <= 2 C^d ||Z(x)-Z(y)||.

The target predecessor symbols are different at r, so their approximate outputs are separated by at least c. Hence all 2^n transcripts are pairwise separated by

    s = c/(2 C^d).

Packing disjoint balls of radius s/2 inside a q-dimensional ball of radius V+s/2 gives

    2^n <= (1+4 V C^d/c)^q,
    n log 2 <= q log(1+4 V C^d/c).                 (A)

For fixed q,V,C,epsilon, this forces d=Omega(N). In particular it excludes O(log N) and every polylogarithmic d. The bound does not assume finite activation precision, rational activations, bounded parameter-description length, or a limited number of exact distinct read values. An injective scalar read does not evade it: the obstruction is the PAID separated decoder.

Recovering each row's ordered last three symbols supplies the predecessor by a bounded coordinate projection, and therefore satisfies the hypothesis. A fixed-dimensional exact triple-onehot at every eligible real row has the same obstruction: for that variant keep X_N fixed and vary an interior suffix of Theta(N) symbols, so the last-difference successor is a real row at most N rather than the excluded synthetic row. Its triple contains the changed token and hence has constant output separation. The packing numerator remains Theta(N).

## 3. Actual PreLN and small-amplitude qualifications

Full-feature LayerNorm with epsilon=1 and scalar gain two is globally two-Lipschitz. A standard residual FFN with bounded matrices, ReLU, and that LN has a frozen local Lipschitz envelope, for example 1+2||W_2||||W_1||. Positionwise residual and final affine extraction maps do not invalidate (A). Uniform averaging is precisely the communication operation used there.

The old bounded affine/ReLU reference program is already inside the lower-bound class. Therefore a claimed bounded reference program with exact all-row lags at fixed width and polylogarithmic depth is impossible before invoking its PreLN compiler.

One must not apply a constant-separation statement blindly to a physical register deliberately scaled by an N-dependent amplitude eta. For target separation sigma_N, replace c in (A) by the actual positive output separation. A tiny coded register, without a paid way of using or restoring it, is not a constant-separation lag output. Two useful cases still inherit the obstruction:

- If both the value radius and lag amplitude are homothetically scaled by eta, the scale cancels in the ratio V/c.
- If a paid bounded continuation restores the lag or forms fixed-scale triple indicators, include that continuation in d. The existing small-amplitude compiler uses M=O(m+log(1/xi)) paid restoration stages; a polylogarithmic reference with polynomially small target error would still lead to polylogarithmic total depth, contradicting (A).

Thus exponentially small amplitudes or coefficient descriptions do not supply a FREE usable all-row decoder. Conversely, this note does not claim that arbitrary tiny hidden representations are forbidden merely because their exact information is rich.

## 4. Many uniform reads do not make this all-row plan polylogarithmic

For A useful uniform stages let q=sum_l q_l be the total effective value dimension and let

    Z=(Z_1,...,Z_A),  ||Z||<=V sqrt(A).

At the last differing position j, every later row begins equal. At a later useful read, source states beyond the receiving row may now differ, but subtracting the global transcript leaves exactly that suffix discrepancy. The audited induction bounds the final discrepancy at a row i>j by

    D beta^D ||Z(x)-Z(y)||,

for a frozen beta>=2, after at most D charged primitives. Therefore constant-separated all-row recovery requires

    n log 2 <= q log(1+2 V sqrt(A) D beta^D/c).      (B)

When the total useful value dimension at a stage is at most W, q<=AW. As A<=D under the counted-layer model, the logarithm in (B) is O(D) and

    A W D = Omega(N),
    D = Omega(sqrt(N/W)).                          (C)

For constant A and constant W this strengthens to D=Omega(N). For fixed W, (C) excludes a polylogarithmic-depth all-row decoder even if it uses polylogarithmically many uniform reads and evolves values between them.

This is an existing all-row transcript lower specialized to the present question, not a new terminal-risk lower. It requires uniform full-prefix communication and aggregate effective dimensions. It does not cover genuinely nonuniform bounded-score attention, an added local mask, a hidden predecessor port, or an unbounded/different communication resource.

## 5. The old sequential-block construction and the stopped fallback

`../depth_packing_20261104/packing_candidate.v2.md` is an actual all-row predecessor construction. It partitions the raw history into L=O(N/log N) blocks of b=Theta(log N) symbols, processes the blocks SEQUENTIALLY, and gates each recovered digit to its destination rows. Each block pays O(log N+b+log^2 b)=O(log N) depth and one uniform read. The total is O(N) depth and O(N/log N) useful reads. A width-growing parallel superbatch is a different budget; the audited constant-read/log-depth all-row upper has W=Theta(N/log N), not constant W.

A conceivable two-read fixed-width fallback instead packs the entire prefix, decodes O(N) digits while skipping unavailable zero digits so that each row retains its own actual last three symbols, and then reads the triple indicators. This requires a fresh source-domain proof because choosing i=1 and b=P>=N is outside the old theorem's b<=N statement. Recovering and discretizing the second average also needs paid bounded arithmetic; one cannot treat C/t as the exact dyadic C/Q lattice.

We deliberately stop this fallback before claiming a completed composite theorem. It pays linear first-stage decoding, exactly as (A) requires, and is redundant: the existing one-read full-history suffix decoder can accumulate the counts WHILE decoding and already attains the full-history statistical envelope at the same linear depth order. A second read therefore supplies neither a better sample-depth order nor a necessary communication count. No new implementation, parameter family, exact physical-output ledger, or two-read usefulness certificate is claimed for this stopped attempt.

## 6. Resource and risk ledger at this stopping point

- Width/head/value dimension: fixed in the rejected shortcut; q=O(1) at the first read. A growing parallel lane bank is a different width budget.
- Useful reads: exactly one before the all-row local decoder; a later second read cannot repair an impossible first-stage specification. For general uniform stages, (B)-(C) apply.
- Depth: d=Omega(N) for one-read constant-width constant-separated all-row recovery. The known suffix decoder's O(N) full-history choice is consistent with this fact, but the lower does not require every terminal estimator to decode N digits.
- Norms, matrices, biases and primitive Lipschitz constants: frozen before N; positive-epsilon fixed-gain PreLN fits a fixed local envelope. Moving an N-dependent gain into an uncounted decoder changes the model.
- Coefficient descriptions: unrestricted by the lower. The existing linear suffix upper pays O_alpha(D) maximum description bits and O_alpha(D^2) conservative dense parameter bits. No bit lower for task risk follows here.
- Activation precision: exact real in (A)-(C). Finite grid/rounding remains a separate conditional evaluator contract; the paper argument performs no numerical execution.
- Output: no new output head is constructed here. The existing full-history upper has the already specified genuine gain-two/zero-shift final LN, bounded affine vocabulary head, ordinary softmax, and exact [alpha,1-alpha] physical range after paid log/padding/restoration.
- Risk: the existing one-read full-history choice b_full=largest power of two <=N has conditional-A upper 157/sqrt(1+(b_full-2)u)+1/G+epsilon and overall upper 1300u/sqrt(1+(b_full-2)u)+w(alpha-q)_++(u+w)/G+epsilon. Budgets b_full,G,epsilon are public and u-blind. These are OLD upper bounds. Neither (A) nor (C) supplies a lower on these risks for arbitrary terminal estimators.

## Conclusion

The direct first-read/all-row-last-three/second-read route is closed under its stated fixed-width polylogarithmic uniform-attention budget. The failure is specific and mathematically certified. A different fixed-width evolving-memory terminal statistic, particularly one that does not expose all-row lags, is not ruled out by this argument and remains the appropriate target for a stronger construction.
