# Independent final report review

Date: 6 November 2026.

Verdict: PASS for mathematical scope, source correspondence, static document structure, public-source links, and content privacy. This is not a visual-rendering certification or a scientific execution certificate.

## Exact artifact binding

- Artifact: `RESEARCH_REPORT.zh.v3.html`.
- Size: 89,799 bytes.
- SHA256: `d5d7111d5d4a78e601e6d32b919ea77e422a611b2860528a7131e75b76df5108`.
- Main text: `REPORT_MAIN.zh.v4.md`, SHA256 `8bc58942f4a7d88c0cb56e63c19e34752328f8a94d26176c208f1f796b35e2d8`.
- Static inspection: `INDEPENDENT_REPORT_STATIC_CHECK.final.json`.
- Full adapted-source correspondence: `INDEPENDENT_REPORT_SOURCE_MATCH.final.json`.

The final HTML was read and parsed without executing its builder or using a browser. An independent HTML parser confirmed one body, five appendices, six external links, no executable/interactive tags, no event-handler attributes, and no unexpected URL destinations. Static scanning found no private filesystem locations, internal coordination references, credential patterns, or private download links. This is a content review, not an assertion that arbitrary hidden information can be detected by pattern matching alone.

The extracted main text and all five appendix bodies match their declared sources after the builder's explicitly inspected adaptations, heading conversion, and whitespace normalization. All equations and proof text outside those declared adaptations are retained. The final revision removes the stale pending-review lines and the dangling reference to omitted prior-audit Section 8. The historical statement that a preserved earlier version was unreviewed is accurate and not a current pending status.

## Mathematical and claim-scope review

1. The old global fixed-suffix decoder is not a moving-window decoder. The known fixed-width one-uniform-read all-row predecessor obstruction excludes the proposed logarithmic-depth first stage. The bounded-QK predecessor rate is correctly stated as polynomial, not the previously overquoted near-linear rate. Failed and corrected routes remain recorded.

2. The suffix-budget two-point argument is explicitly limited to a strict last-b-symbol reference, with `3 <= b <= N` and `bu <= 1`. Its conditional-A lower is separated from the overall excess above the same alpha-range floor. The physical PreLN implementation is compared by a pathwise delta guarantee, giving `1/128-delta` conditionally and `u(1/128-delta)` above the floor. It is not falsely declared exactly suffix-measurable. Conditional amplification of merely unconditional implementation error is disclosed.

3. The source-average uniform transcript result uses a fixed numerical recovery margin and the actual source's entropy. It is a lower bound for accurate intermediate local representations, not for an arbitrary terminal predictor. The rare-indicator strengthening uses the unconditional reverse mutual-information chain. It does not incorrectly reuse the first-half-conditioned stationary reverse law.

4. The explicit F3 counterexample was checked algebraically: with `u=1/100`, `t=3/4`, `w=33/100`, `q=1/44`, the two compatible strings have probabilities `3/1600` and `258/1600`. Consequently the bridge-conditioned probability is `1/87`, whereas the unconditioned-prefix reverse probability is `1/44`. Both conditioning events have positive probability.

5. The bounded-QK extension is bound to candidate v2, SHA256 `bb4aa0697fc097eb25e7c03e37a9e9a43163550abb2dd646d66f01ecdf94c746`. Its complete proof has been separately reviewed in `INDEPENDENT_QK_PRIOR_REVIEW.final.md`. The report correctly accounts for degree-independent feature derivatives, proof-only Q/K/V ball projections, stabilized ratio, all-read Taylor and quantization errors, and total feature dimension. The displayed polynomial depth consequences use fixed key/query dimension, fixed margins and budgets, and `A <= D`. Arbitrary pairwise positional bias and a general nonuniform finite-grid execution theorem are excluded.

6. The uniform finite-grid claim uses the actual total pre-rounding head dimension `Q_f`, an explicit common grid, exact prefix accumulation, and deterministic local arithmetic. It is not presented as a generic floating-point guarantee or an exact-real rank collapse after headwise rounding. Full-lag and rare-indicator entropy scales are kept distinct.

7. The report consistently preserves the missing implication from small terminal statistical risk to the hypothesized rowwise representation accuracy. No new terminal-risk main theorem, matching resource frontier, or improved fixed-width complete estimator is claimed. Taylor features, Fano/entropy chains, two-point testing, and prior Markov counting constructions are identified as existing mechanisms rather than new architecture principles.

## Sources and links

The six HTML links are unchanged from the previously inspected version and point only to the specific publicly read arXiv sources: Rajaraman `2407.17686v1`; Ekbote PDF and HTML `2508.07208v2`; D'Angelo `2607.02800v1`; Alman and Song `2302.13214v1`; and Chen et al. `2606.07205v1`. Their relevant theorem/section restrictions are retained in the adapted prior audit. This review does not infer exhaustive novelty from absence in these searches.

The prior audit included here is v3, SHA256 `ab99a066284c0072c3a35824ad83c864a49da69d13bba5a1d237350aab4e2a19`. It preserves the full comparison obligations and updates the separately checked QK proof status. Earlier candidate and audit versions remain available, rather than being silently overwritten.

## Remaining limitations and actions

No mathematical or privacy blocker was found for delivery of this exact HTML as a scoped research report. Visual rendering was not performed and must not be represented as completed. No model run, training, scientific numerical experiment, public repository mutation, or external publication was performed during this audit. Existing rendering restrictions were respected; no denied renderer was retried.
