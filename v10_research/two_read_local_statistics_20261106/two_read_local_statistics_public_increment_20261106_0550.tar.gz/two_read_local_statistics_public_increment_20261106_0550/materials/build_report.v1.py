from pathlib import Path
import html,re,hashlib,json
p=Path(__file__).parent

def inline(s):
 s=html.escape(s)
 return re.sub(r'https://[^\s<>]+',lambda m:'<a href="'+m[0]+'">'+m[0]+'</a>',s)
def md(s):
 out=[];para=[];code=[]
 def flush():
  if para:out.append('<p>'+inline(' '.join(para))+'</p>');para.clear()
  if code:out.append('<pre>'+html.escape('\n'.join(code))+'</pre>');code.clear()
 for line in s.splitlines():
  if line.startswith('    '):
   if para:flush()
   code.append(line[4:]);continue
  if code:flush()
  if not line.strip():flush();continue
  if line.startswith('#'):
   flush();n=min(5,len(line)-len(line.lstrip('#')));out.append(f'<h{n}>'+inline(line[n:].strip())+f'</h{n}>')
  else:para.append(line)
 flush();return '\n'.join(out)
def adapt(s,prior=False):
 lines=[];skip=False
 for line in s.splitlines():
  if prior and re.match(r'## [78]\. ',line):skip=True;continue
  if prior and re.match(r'## 9\. ',line):skip=False
  if skip:continue
  if line.startswith('6 November 2026') or line.startswith('Date:') or 'Private analytical candidate' in line:continue
  if 'coordinating researcher' in line or 'Firecrawl' in line:continue
  line=line.replace('subject to independent review of this separate replay argument','with the separate replay argument reviewed independently')
  line=re.sub(r'`(?:\.\./|v10_research/)[^`]+/([^/`]+)`',r'`\1`',line)
  lines.append(line)
 return '\n'.join(lines)
main='REPORT_MAIN.zh.v4.md'
files=[('A 后缀预算反例与物理实现转移','U_BLIND_SUFFIX_TEST.candidate.v2.md'),('B 多次 uniform reads 的源平均局部障碍','SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v2.md'),('C 有界 QK 多次调用扩展','BOUNDED_QK_SOURCE_AVERAGE_EXTENSION.candidate.v2.md'),('D 先行工作与范围审计','PRIOR_AND_OBSTRUCTION_AUDIT.v2.md'),('E 失败路线与错误修订','FAILED_ROUTES_AND_CORRECTIONS.v1.md')]
body=md((p/main).read_text())
for title,f in files:body+='<section class="appendix"><h2>'+html.escape('附录 '+title)+'</h2>'+md(adapt((p/f).read_text(),prior=f.startswith('PRIOR_')))+'</section>'
style='body{max-width:980px;margin:48px auto;padding:0 24px;font:17px/1.8 system-ui,"Noto Sans CJK SC",sans-serif;color:#17202b;background:#fff}h1{font-size:32px;line-height:1.35;margin:36px 0 24px}h2{font-size:25px;margin:42px 0 18px}h3{font-size:20px;margin:28px 0 12px}p{margin:14px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:15px/1.7 ui-monospace,monospace;padding:16px;background:#f5f7f9}a{color:#145c9e;overflow-wrap:anywhere}.appendix{margin-top:64px}@media(max-width:600px){body{padding:0 16px;font-size:16px;margin:24px auto}h1{font-size:27px}pre{font-size:13px}}@media print{body{max-width:none;margin:0;font-size:11pt}.appendix{break-before:page}h1,h2,h3{break-after:avoid}}'
out='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>rare-u 固定宽度资源差距检验</title><style>'+style+'</style></head><body>'+body+'</body></html>'
f=p/'RESEARCH_REPORT.zh.v1.html';f.write_text(out)
qa={'file':f.name,'bytes':len(out.encode()),'sha256':hashlib.sha256(out.encode()).hexdigest(),'main':main,'appendices':files,'active_content':bool(re.search(r'<(?:script|iframe|form)|\bon\w+=',out,re.I)),'private_paths':bool(re.search(r'/workspace/|/home/|collaboration\.|/root/|Firecrawl|coordinating researcher',out)),'links':re.findall(r'href="([^"]+)"',out),'rendered':False}
(p/'STATIC_QA.v1.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2));print(json.dumps(qa,ensure_ascii=False,indent=2))
