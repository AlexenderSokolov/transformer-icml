# A decisive u-blind test for the suffix route, not for all transformers

6 November 2026. Analytical candidate v2; v1 preserved. Independent review of v1 found the main proposition valid and required the physical-compiler transfer below; exact-file v2 review pending. No model, scientific diagnostic, training, numerical experiment, upload, or public write was performed.

## Contract

Use the same stationary binary order-two rare family as `../fixed_width_rare_risk_frontier_20261106/FIXED_WIDTH_RARE_RISK_FRONTIER.candidate.v2.md`: A=00, B=01, C=10, D=11; pi=(u,w,w,w), w=(1-u)/3; t in [1/2,3/4], 0<u<=1/100; A next-one=t, C next-zero=q=ut/w, B,D fair. The actual terminal context is A on E_A. History length is N. A suffix-b predictor is any randomized function of only the actual last b observations and public N,b; even known u is allowed for the lower bound. It has no further history-dependent state, cached statistics, or parameters. Randomness is independent of the source. This is an information restriction, not a definition of all fixed-width models.

Fix the same exact physical output range [alpha,1-alpha], 0<alpha<=1/4. Define total expected TV R_t, the unavoidable range floor F_t=w(alpha-q)_+, and excess-over-range-floor E_t=R_t-F_t. The floor follows solely from terminal C. Since A and C are disjoint events and B,D losses are nonnegative,

    E_t >= u E_t[|Q(1)-t| | E_A].                         (1)

This notation E_t for excess is not conditional expectation; expectations are written explicitly below. The known full-history construction supplies

    R_t <= F_t + 1300u/sqrt(1+(N-2)u)
                    +(u+w)/G + epsilon                 (2)

when its suffix budget is the full history (or a power-of-two suffix at least N/2 with the corresponding constant-factor statistical bound). The depth of that construction includes linear suffix decoding. Equation (2) is an existing upper, not a new rate.

## Proposition: every sublinear suffix budget fails a uniform full-history conditional test

For b>=3 and bu<=1, there exist t0,t1 in [1/2,3/4], separated by h=1/32, such that every suffix-b predictor satisfies

    max_i E_{t_i}[|Q(1)-t_i| | E_A] >= 1/128,
    max_i (R_{t_i}-F_{t_i}) >= u/128.                    (3)

The pair can be fixed as t0=1/2, t1=17/32. The predictor may know u; no u-blind assumption is needed for this lower.

### Proof

Stationarity implies the last b observations conditional on their final pair A have exactly the b-observation conditional law used by the existing full-history conditional KL lemma. That lemma, already proved for this family, gives

    KL(P_t0^(b)(.|E_A),P_t1^(b)(.|E_A))
       <=60(1+bu) h^2 <=120/1024 <1/2.                 (4)

This is the full-history conditional KL estimate with its length set to b, not the smaller parity-side estimate. The terminal event has probability u independent of t. Independent randomness and the predictor do not increase TV. Pinsker therefore gives input-law TV <1/2. Integrating the triangle inequality |z-t0|+|z-t1|>=h against the common part of the two laws proves that the sum of the two expected absolute errors is at least h(1-TV)>h/2. The larger is at least h/4=1/128. Equation (1) proves the excess-risk statement. No claims of independence between the final pair and past were used.

Now let b_N be any public, u-blind integer budget with 3<=b_N<=N and b_N/N ->0. Set

    u_N=(N b_N)^(-1/2).

Eventually u_N<=1/100, b_N u_N=sqrt(b_N/N)<=1, while N u_N=sqrt(N/b_N)->infinity. Thus (3) remains bounded away from zero conditionally on A, although the full-history conditional rate 157/sqrt(1+(N-2)u_N) tends to zero. Moreover the ratio of the suffix excess lower to the known full-history statistical term diverges as a constant times (N/b_N)^(1/4). Choose public G>=N^2 and epsilon<=N^(-2) to make the existing quantization and compilation errors negligible relative to that statistical term. Since u_N>=1/N, this comparison is valid. For the legal power-of-two b used in the prior implementation choose b_full as the largest power of two <=N; b_full>N/2 and the conclusion is unchanged.

## Robust transfer to the physical PreLN implementation

The physical compiled predictor need not be exactly suffix-measurable: normalization and approximation can retain tiny dependencies on earlier rows. Do not apply the suffix-only theorem to it by measurability assertion. Instead suppose a strictly suffix-measurable reference Q_ref satisfies a uniform pathwise TV bound TV(Q_phys,Q_ref)<=delta. The triangle inequality gives

    max_i E_{t_i}[|Q_phys(1)-t_i| | E_A] >=1/128-delta.

If Q_phys has the declared exact alpha range, (1) then gives

    max_i (R_phys,t_i-F_t_i)>=u(1/128-delta).

For the existing construction Q_ref is the alpha-projected quantized suffix estimator and delta<=3epsilon/4 by its explicit margin/compilation lemma. Thus epsilon tending to zero transfers the triangular lower. This is not a lower for arbitrary physical models; an independently justified uniformly small suffix-reference approximation is required. An actual finite evaluator adds its certified pathwise error nu to delta; retaining the same F_t also requires the finite output to retain the alpha range, for example under the previous sufficient nu<=mu/2 inward-margin condition.

## What the test does and does not decide

1. It rules out presenting b=Theta(log N) or any sublinear public suffix budget as uniformly matching the full-history rare conditional rate, even though it is consistent at every fixed u>0. Pointwise-in-u convergence and a triangular rare-u family are different quantifiers.
2. It also makes a meaningful comparison in overall risk by subtracting the unavoidable declared output-range floor. Comparing raw overall risk ratios at fixed alpha is misleading as u tends to zero, because both algorithms can be dominated by a positive C-context floor.
3. It does not impose D>=b on arbitrary algorithms or prove a multiple-attention lower bound. The old one-read suffix construction has paid D=O_alpha(log N+b+log^2 b+log b log G+log^2(1/epsilon)); the lower above concerns its information choice, not the computational necessity of sequential decoding.
4. u-blind schedules G>=N^2, epsilon<=N^(-2), and b_full>N/2 need no knowledge of u. Choosing b proportional to 1/(u r^2) does need known u or a declared lower rarity bound. If u>=rho is declared, b=O(1/(rho r^2)) suffices for the conditional statistical term, subject to N>=b and the existing large constants. This is not adaptive unknown-u learning.
5. alpha can be lowered only by paying the changed output/norm envelope. Uniformly eliminating the C-floor for u>=rho requires alpha<=3rho/[2(1-rho)] (the minimum q at t=1/2). A sufficient smaller choice is the previously used alpha=3rho/[4(1-rho)]. The corresponding logit range grows like log(1/rho). For arbitrary u>0 no fixed positive alpha eliminates the floor.
6. Finite evaluation is an additional contract. Exact-real coefficient descriptions do not imply execution precision. Under the separately stated conditional evaluator contract from the preceding report, if its conditions are met, total output error nu adds nu to R and to the A-conditional error if the guarantee is uniform pathwise; if only an unconditional implementation error epsilon_global is known, conditioning costs epsilon_global/u. This distinction cannot be omitted in a rare-event comparison.

## Existing proof dependencies and claim boundary

- `../rare_attention_information_bridge_20261106/EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md`: terminal-A full-history conditional KL <=60(1+Nu)h^2.
- `../fixed_width_rare_risk_frontier_20261106/TASK_DIRECTED_PRECISION_AND_COVERAGE.candidate.v2.md`: existing full-history Le Cam application and output floor.
- `../fixed_width_rare_risk_frontier_20261106/FIXED_WIDTH_RARE_RISK_FRONTIER.candidate.v2.md`: paid ordinary-softmax upper and finite execution certificate contract.

The proposition is a direct reuse of a proved KL lemma and standard two-point testing. It is a diagnostic of an insufficient proposed algorithmic route, not a claimed new statistical theorem or general depth lower bound. The next potentially decisive question is whether a different fixed-width evolving-memory algorithm can use full-history statistics without all-row lag reconstruction or a linear suffix decoder; this remains unresolved here.
