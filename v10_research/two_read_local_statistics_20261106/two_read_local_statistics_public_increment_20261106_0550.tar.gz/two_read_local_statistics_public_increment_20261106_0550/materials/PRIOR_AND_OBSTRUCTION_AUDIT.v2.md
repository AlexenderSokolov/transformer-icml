# Prior art and obstruction audit: two-read local statistics

6 November 2026 UTC. Independent analytical/source audit. No scientific program, enumeration, parameter generation, training, numerical evaluation, upload, or public repository write was performed. Existing sources and failure versions remain unchanged.

## Verdict

**STOP the proposed fixed-width logarithmic-depth first-read last-three-symbol route.** The needed intermediate representation is not available in the old terminal-suffix program. An already independently reviewed all-row obstruction directly contradicts uniformly correct local predecessor or triple features after one full-prefix uniform read at fixed width and O(log N) paid depth.

This does **not** prove a lower bound against every two-read rare-family predictor or direct approximate count scheme. It rejects the specific local-recover-then-pool route. A different statistical route must avoid demanding uniformly accurate local triples after its first read, or pay larger width/depth, or explicitly change its access/score contract.

No same-contract fixed-width, O(log N)-depth, two-useful-uniform-read full-history type/count construction was located in the inspected repository. This is a bounded search result, not an exhaustive absence or novelty claim. Existing full-history two-read constructions buy growing width; the accepted fixed-width two-read construction still estimates a chosen terminal suffix.

## 1. The exact first-stage obstruction

Directly read:

- `../parallel_terminal_estimator_20261105/ALLROW_SINGLE_INVOCATION_OBSTRUCTION.candidate.v1.md`, Sections 1–7.
- Its `ALLROW_SINGLE_INVOCATION_OBSTRUCTION.independent_audit.v1.md`, especially Sections 1, 3, 4. Verdict: PASS for its representation-specific contract.

Hypotheses match the proposed first stage: raw binary symbols plus public positions; token-local preprocessing before the first useful head; one full inclusive causal prefix read; only positionwise computation between that read and the claimed triple representation; fixed value dimension and full value radius; frozen per-primitive Lipschitz constants; every local stage charged.

For predecessor error eta<1/2 on every row and every word, gamma=1−2 eta, continuation Lipschitz constant Lambda, value dimension d and radius V, the candidate proves

    N ln 2 <= d ln(1 + 2 V (N+1) Lambda/gamma).

With Lambda<=A^D and fixed d,V,A,gamma, this gives D=Omega(N). The proof uses the last differing input position j and receiving row j+1. At that row the current token and local side information agree. The global average of the token-local values must therefore distinguish all binary words with a margin of order 1/[(N+1)Lambda]. Euclidean packing gives the inequality. Exact-real weights and arbitrarily fine descriptions do not escape the paid-Lipschitz premise.

The separately checked Section 7 corollary **already covers local triple onehots**, not just explicit predecessor rails. Fix the final raw bit and vary the first N−1 bits. At t=max(3,j+1), the receiver’s own token agrees while its triple differs. Distinct triple onehots have Euclidean separation sqrt(2), so any uniform vector error eta<sqrt(2)/2 yields the same argument with (N−1) ln 2 and gamma=sqrt(2)−2 eta. Thus replacing a last-three-symbol decoder by direct triple indicators does not avoid the obstruction.

For standard bounded full-norm bilinear QK attention, the same source proves the weaker but still excluding bound

    N <= C(D+1)^k [D+log(N+1)+1],
    D = Omega(N^(1/(k+1)))

for fixed query/key dimension k. It does not cover arbitrary nonseparable relative-position score tables. A rapid preliminary message in this audit misstated the QK rate; the formula here and the immediate correction are authoritative. The zero-score linear-depth conclusion was never changed.

### Why positive-epsilon PreLN and rarity do not repair this step

With fixed alpha and frozen C_alpha, epsilon-one full-feature LN, bounded gains/maps, ReLU, and residual updates have an N-independent per-stage Lipschitz envelope. Token-local preprocessing remains token-local until the first useful read. Zero Q/K makes the first physical head a uniform mean of token-local normalized values. Therefore the same first-stage packing argument applies if the physical stage promises fixed-margin accurate triples. Small-amplitude compilation is not a means of creating a nonexistent logical reference.

For every fixed admissible u>0 and t in [1/2,3/4], the rare family has positive stationary mass and positive transition probabilities. Every finite binary word has positive probability. Hence an exact or uniformly bounded-error all-history claim cannot be weakened merely by saying “on the rare source support.” An expected local-feature error statement would be materially weaker and is not ruled out by this theorem. No source-average reduction is supplied here.

## 2. What the old all-row suffix assertion actually means

Direct source: `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`, Sections 3–6; independent audit v2. Its fixed selected interval is i=N−b+1 through N, shared by every row.

At receiving row t the read contains only the available part of this **same global interval**, with packed sum

    S_t = sum_(s=i)^min(t,N) d_s B^(-(s-i+1)).

The row decodes b digits, replacing absent digits by a declared default only for statistical counting. Therefore every row has a legal virtual b-word and bounded count/readout state. At T=N+1 this virtual word is the actual last-b suffix. At an early row t<i it is all defaults, regardless of the true preceding raw symbols.

This is an all-row **validity and boundedness invariant**, not an assertion that row t receives the moving raw suffix ending at t. The latest fixed-width rare-softmax audit says the same explicitly in Section 1. Substituting i=t−2 changes a common token-local source-value function into a receiver-dependent selector; one uniform head cannot quietly perform that substitution. Reusing b=3 is not justified either: the old theorem’s declared general domain is power-of-two integer b>=4. Using b=4 avoids that minor domain error but not the moving-window obstruction.

The older `../depth_packing_20261104/packing_candidate.v2.md` really does recover all-row predecessor rails by geometric destination gates, but processes O(N/log N) source blocks sequentially. It pays O(N) depth and O(N/log N) useful reads before the histogram. Taking a single block only supplies the rows belonging to that block; it does not recover all local triples in the history.

## 3. Actual internal antecedents and exact resource differences

### A. Full-history two-read logical construction: growing width

`../parallel_width_depth_20261104/CANDIDATE.v2.md`, Sections 1–5, constructs scaled source lanes, one wide uniform broadcast, all-row lags, then a second uniform triple-histogram read. It recovers full-history counts and the actual terminal pair and gives an internal add-one readout.

Its width is O(NK+K^3), depth O_K(log N), useful reads two, and the first value bank is wide. It has frozen full-vector norms but no mandatory LN and ends with coordinate probability projection. It is not a fixed-width antecedent. Its headline statement in Section 7 that a different fixed-width logarithmic construction is not excluded predates the narrower all-row obstruction; interpret that openness as about alternative representations, not this pipeline.

### B. Packing improves the all-row width, not to a constant

`../allrow_frontier_audit_20261104/INDEPENDENT_ALLROW_FRONTIER_AUDIT.md`, Sections 1–5, binds `sources/MATCHING_THEOREM.v2.md`. For exact all-row lag recovery, fixed useful uniform-read count and paid D=O(log N), its accepted endpoint is W=Theta_K(N/log N). Parallel packed lanes share one wide head. A subsequent count histogram is an additional read, not present in the lag-only endpoint statement.

The corresponding lower concerns all-row representation, not terminal statistical prediction. Its repeated-uniform transcript argument also warns against assuming that a constant number of extra uniform reads makes exact all-row lag reconstruction free.

### C. Actual PreLN/softmax full-history two-read witness: still growing width

`../nonlinear_statistical_frontier_20261106/WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md`, Sections 1–3 and independent wide audit, already supplies actual positive-epsilon full-feature PreLN, ordinary final softmax, fixed full-norm envelope, two useful uniform reads, O(log N) depth, and a full-history O_c(N^−1/2) expected-TV bound on an interior binary order-two class. It explicitly buys model/FFN/value width O_c(N).

`../orbit_preln_resource_link_20261106/PHYSICAL_TYPE_SUFFIX_OBSTRUCTION.candidate.v1.md` Sections 2, 3, 6 uses that same family and its uniformly approximated full-count/terminal-pair reference. It is not a fixed-width compiler. The interior floor c is also not a fixed lower bound for the rare-family C probability as u→0, so its statistical theorem cannot be transferred unchanged to the entire rare family.

### D. Accepted fixed-width two-read PreLN witness: old suffix estimator

`../ordered_causal_memory_20261106/TWO_READ_ORDERED_SUFFIX.candidate.v3.md` and `TWO_READ_PRELN_COMPILATION.candidate.v4.md`, accepted by `INDEPENDENT_TWO_READ_PRELN_AUDIT.v1.md`, use two genuinely useful reads with evolving nonterminal values. Their logical second read is a public-linear weighted sum of one selected terminal block. A synthetic-terminal gate then zeros decoder input at nonterminal rows. The terminal decoder reconstructs only that block’s counts and final pair.

The normalization/ordinary-softmax theorem is real, not merely pending, but its statistical order is the same O(b^−1/2) suffix order as the one-read predecessor. Setting b comparable to log N gives logarithmic depth; extending to a full-history-sized block pays linear decoding depth (with endpoint/domain adjustments if needed). This is not a previously proved full-type improvement.

### E. Existing one-read wide rare-A witness prevents a two-read necessity claim

`../rare_attention_information_bridge_20261106/ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md` Sections 1–4 stores the full ordered history in a wide terminal bank, binds triples locally, and estimates rare-A from all N−2 transitions with one useful read. Its width is O(N), not fixed. It shows why read count must be compared jointly with width, work and precision, rather than called necessary from an implementation’s ablation usefulness.

## 4. Existing terminal/type obstructions: what they do and do not settle

`../repeated_terminal_obstruction_20261105/TERMINAL_SIMULATION_OBSTRUCTION.candidate.v2.md` and independent terminal audit v2 give a fixed-width, two-uniform-read, O(log N)-depth prefix-energy network whose terminal output needs Omega(N) worst-case interactive communication at fixed error. The second-read values are nonlinear functions of prefix sums. This defeats a universal cheap terminal simulator even without reconstructing intermediate rows.

Its accepted output convention is probability-coordinate projection, not mandatory final PreLN/softmax. Its hard encoded histories are a worst-case family; positive Markov support does not transfer the lower to source-average statistical prediction. It therefore neither proves the proposed rare-risk upper impossible nor supplies a rare-task lower. Its lesson is to avoid assuming that two reads always collapse into one cheap terminal message.

`../task_oriented_simulation_20261106/UNIVERSAL_MARKOV_TYPE_PROJECTION.candidate.v1.md` Sections 2–4, 7 proves classical source-independent type projection and an Omega(N) distributed acquisition lower for the exact full type despite its O(log N)-bit description. The theorem explicitly does not preserve neural architecture or depth. It cannot be used as a free full-count input port, or as a risk-specific two-read lower.

## 5. Primary Markov-transformer comparison

Freshly reopened the following primary bodies with the web tool in this audit; theorem/construction passages were read, not inferred from abstracts. Prior detailed execution-contract audits were used as navigation and cross-checks. This is a targeted comparison, not exhaustive citation/version research.

### Rajaraman et al., Transformers on Markov Data: Constant Depth Suffices

Primary: https://arxiv.org/html/2407.17686v1 . Direct locators: Theorem 5.1 / Remark 5.2 (lines 218–223), Architecture 0.2 (209–216), Appendix C.1 (529–535).

The theorem already represents same-history conditional k-grams with three layers, one head per layer, relative positions, LN and O(S) embedding. Their normalization is not the fixed epsilon-one full-feature contract; C.1 converts it to Euclidean normalization through paired signs. The paper says its theorem also holds for its original architecture, so it is wrong to dismiss it as “no normalization.” Remark 5.2 explicitly leaves finite-bit approximation unbounded in the proof while suggesting logarithmic length/order parameter bits. These are strong estimator/architecture antecedents, not the present bounded-score execution certificate.

### Ekbote et al., What One Cannot, Two Can

Primary: https://arxiv.org/pdf/2508.07208v2 and https://arxiv.org/html/2508.07208v2 . Direct locators: printed p.7 Theorem 3 / Remark 2; Section 2.2, HTML line 154; Appendix A.2.2, lines 476–482.

Theorem 3 already gives two layers, one head per layer, MLPs, LN, relative positions and dimension 6S+3 for the conditional k-gram. Remark 2 gives a parameter count containing T and a sufficient parameter-precision statement, not an execution-noise or lower-bound theorem. The output is ReLU rather than ordinary vocabulary softmax. The reviewed appendix normalizes projected keys/queries and sends a temperature parameter to infinity; that is not frozen full-norm positive-epsilon PreLN. Its two-layer result prevents broad claims of first two-read Markov estimation, while leaving the exact current frozen contract unverified.

### D’Angelo et al., Induction Heads Interpolate N-Grams

Primary: https://arxiv.org/html/2607.02800v1 . Direct locators: Proposition 3.1 / Eq.(8), lines 201–207; Section 3.2.1, lines 213–228.

The pathwise two-layer disentangled construction uses k heads then one, recovers local contexts, and aggregates mask-conditioned counts; BOS supplies pseudo-count smoothing. Fixed alphabet/order has constant representation dimension. Its first-layer copying explicitly takes positional sharpening to infinity. Consequently finite context-match beta does not mean all scores are uniformly bounded. Counting, same-history conditioning and smoothing are established mechanisms; the blocked local-copy step cannot be imported into the proposed uniform-head contract.

Two targeted additional searches for bounded/two-layer Markov and uniform-attention fixed-width counts returned these known families plus length-generalization and unrelated attention papers. No theorem found in those results was established to supply the missing uniform-head local-triple stage. Negative search results are not priority evidence. Other external comparisons in the latest rare-risk prior-art file, including Akman et al., were read through the existing audited summaries but not newly fulltext-checked here.

## 6. Go/no-go decision and precise remaining opening

1. **No-go:** one uniform first read + fixed-width O(log N) pointwise decoder yields all rows’ last three raw symbols or uniformly accurate local triple onehots. The obstruction is a theorem already present, not a missing citation.
2. **No-go:** interpret legal virtual suffix words at all physical rows as their individual moving suffixes; silently change source gates by receiving row; import hard positional-copy limits; or insert precomputed pairs/counts.
3. **No-go:** call a growing-width two-read or one-read construction a fixed-width result; treat two ablation-useful paths as a necessity of two reads.
4. **Not excluded:** weaker distributed features whose aggregated terminal error is controlled directly in the rare source law, without uniformly decoding local triples. Any such candidate needs its own statistical/bias proof and complete all-row resource accounting. This audit supplies no such construction.
5. **Not solved by output compilation:** paid quotient/logs, norm padding, zero-shift final LN, exact alpha-range margin and u-blind budgets can be reused only after a valid logical first/second-read estimator exists. They do not supply its missing information-acquisition stage.
6. **Rate/range discipline:** replacing suffix sample size b by full history N in the rare-A bound requires actual full-history estimator equality or a proved comparison. An overall rare-family bound must still pay its fixed-alpha C-row floor. Budget choice cannot depend on unknown u.

## 7. Evidence, failures, and source bindings

All results above were established through text inspection, symbolic checking, repository search and primary-page reading. No earlier diagnostic was rerun or attributed to this audit. The failed first-stage route is preserved here rather than repaired by changing the contract.

Primary retrieval: two initial extraction attempts (Rajaraman HTML and Ekbote HTML) failed without retrieving content. No further attempt through that route was made. The available web reader successfully retrieved the primary HTML/PDF passages. Thus the audit has no unresolved access blocker for its three fresh primary comparisons; the provider failure is retained as provenance. Broad latest-version/citation exhaustiveness remains unclaimed.

Fresh checksum bindings:

- `ALLROW_SINGLE_INVOCATION_OBSTRUCTION.candidate.v1.md`: `da963f532403a2123668ed57c8d30840687e791f03f61bfaf4caea9195f4ae66`.
- Companion all-row audit v1: `9942af3cfd73753c403ef9ade362ff96cbb597e8ab101a347b8553d7b55dcdea`.
- `CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`: `ea1c3788f4eed06ccba9e19db3ee0d9a3e792bda7d3d620c0326cc4a07cecbb6`.
- `TWO_READ_PRELN_COMPILATION.candidate.v4.md`: `a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2`.
- `WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md`: `28d7230b9b6b131daa05f6d5a58b3a26d562ca54845e09db13ff9785f5d39e0e`.

This audit rejects a specific proposed route. It is not an independent theorem proving an architecture-wide rare-risk frontier, a novelty certificate, a finite-evaluator guarantee, or an authorization to run/publish anything.

## 8. Provisional follow-on, not a reviewed result

After this audit was drafted, a separate source-average local-feature obstruction was proposed using the rare source’s entropy rate, quantized global uniform-attention transcripts, the old suffix-reconstruction argument, reverse entropy chain rules, and binary Fano. Its exact candidate was not yet available at this writing. The report is not treated as a proved dependency or as evidence that this audit reviewed the result.

If the detailed proof closes its conditioning, quantization, reconstruction and error-conversion obligations, its proper attribution is a standard information-theoretic composition with the existing uniform-transcript reconstruction, potentially a useful distributional strengthening of the local-representation obstruction. It must not be described as a new main statistical-risk theorem. Small average local-feature error is a stronger/different requirement than small terminal prediction risk; no terminal-risk consequence follows without a separate reduction. The currently verified source-average scope in Sections 1 and 6 refers to the older all-history obstruction alone. A later exact-file review must identify which additional statements are accepted.

## 9. Follow-on status after exact-file review

The provisional report in Section 8 has now been replaced by an actual reviewed candidate: `SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v2.md`, SHA256 `8c966282ce5369531e3bac3cf729bece4bdd8aa60694d1675295568f5ba1008a`. `INDEPENDENT_SOURCE_AVERAGE_LOCAL_AUDIT.v2.md` records independent PASS for its scoped equations.

In addition to the source-average full-lag/triple bound, candidate v2 proves a separate rare-context indicator bound. If fixed-margin local 00-indicator failure fraction is at most u/256, the proof-only transcript requires at least Nu log_2(1/u)/16 bits. This uses the exact reverse conditional indicator entropy u h_2(t)+w h_2(q_src), unconditional reverse mutual-information chain, conditional data processing and Fano. It does not use a prefix genie in that rare entropy calculation. It does not prove an unconditional Omega(N) rare-only-feature bound, an aggregate-count bound, or terminal statistical-risk necessity.

Thus the older Sections 1 and 6 intentionally describe only the preexisting worst-case theorem. The current additional accepted scope is the new candidate’s explicit average local-feature hypotheses, not an architecture-wide rare prediction theorem. The proposal “rare indicators are never covered” would now be too strong: they are covered at a small relative-to-u error level, with a smaller rarity-scaled lower.

## 10. Bounded-QK follow-on: established kernel ingredients and unreviewed obligations

A proposed next lemma extends suffix replay to repeated bounded bilinear QK heads using finite Taylor feature codes. At this audit’s completion its exact proof had not been reviewed. No outcome for that proposed lemma is included in the PASS above.

The intended elementary feature map is already present in the older one-read QK obstruction, Sections 4–6:

    phi_m(z)=(z^a/sqrt(a!))_(|a|<=m),
    dim phi_m=binom(m+k,k),
    ||phi_m(z)||^2<=exp(||z||^2),
    <phi_m(q),phi_m(k)>=sum_(r=0)^m (q·k)^r/r!.

Value-weighted feature summaries and a separate denominator coordinate yield dimension (d_v+1)binom(m+k,k). These are established polynomial-kernel mechanisms; the one-read code is a direct internal predecessor. Their use is not itself a new attention representation.

Two narrow primary checks were performed specifically for this follow-on, without broad searching:

1. **Alman and Song, Fast Attention Requires Bounded Entries.** https://arxiv.org/html/2302.13214v1 . Freshly read Lemma 2.1 / Corollary 2.2 (lines 137–164), Lemma 3.2 (180–239), and the surrounding normalized-attention approximation sections. These construct polynomial approximations to exp, factor polynomial inner-product kernels into low-rank features, and relate those approximations to attention. Their main results are runtime statements under entry/dimension regimes, not this fixed-width paid-depth source-average local reconstruction theorem. The primary paper itself credits earlier exponential approximation theory. Do not present Taylor expansion or polynomial feature factorization as new.

2. **Chen, Feng, Indyk, Kapralov, Kochetkova and Prokhorov, Towards Tight Bounds for Streaming Attention.** https://arxiv.org/html/2606.07205v1 . Freshly read Section 2.1 (especially lines 198–199, 231–233) and Lemma 7.3 with its proof (1307–1348). The paper explicitly describes the classical fixed-dimensional Taylor/moment method, and proves a weighted polynomial-kernel sketch needed for value-weighted attention. Its stored-bit and main space theorems have their own parameter regimes. They are not a free black-box proof of a growing-depth causal replay; the feature identity is the relevant established ingredient.

A repeated-read argument still must establish, on its exact stated contract: global transcript radius; feature dimension per actual head; bounded variation of the feature map as simulated keys change; a stable denominator floor; control of approximate queries and keys at every replay stage; the total Taylor tail after D-stage amplification; a feature degree m=O(D) with constants fixed independently of m,N; all required error margins; and the correct Fano conditioning. Proof-only ball projections and denominator clamps may be legitimate tools, but need their own identity-on-reference and Lipschitz/error checks. Arbitrary pairwise relative-position score tables are not covered by a finite-dimensional dot-product kernel argument.

If these obligations close, standard Fano composition with the existing local-representation entropy targets may rule out broader polylogarithmic local-feature pipelines. It must still not be called a new main terminal-risk theorem, a universal cheap simulator, a finite-arithmetic hardware guarantee, or evidence of a matching rare prediction frontier. The open aggregate/terminal-risk implication remains separate.
