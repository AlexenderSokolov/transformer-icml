# Independent audit: repeated bounded-QK local reconstruction barrier

6 November 2026 UTC. Read the entire `BOUNDED_QK_SOURCE_AVERAGE_EXTENSION.candidate.v1.md`, its complete v1-to-v2 diff, the independently reviewed uniform candidate v2, the old one-read QK feature-code proof, and the old repeated-uniform transcript proof. Analytical/static work only; no scientific program, model run, enumeration, parameter generation, training, upload, or public write.

**Verdict: PASS for candidate v2's exact-real local-reconstruction statements and their stated lag/rare-indicator corollaries.** This does not certify terminal-risk, arbitrary relative-position scores, unbounded head count, or nonuniform finite-grid execution. Revision 2 explicitly states 0<g<=1/2, N>=4 for lag claims, N>=8 for rare indicators, D>=1 and 1<=A<=D for the quantized proof, and handles zero-read/depth cases separately. These are valid scope clarifications without changing the reviewed core proof.

Reviewed candidate v2 SHA256: `bb4aa0697fc097eb25e7c03e37a9e9a43163550abb2dd646d66f01ecdf94c746`.

Preserved candidate v1 SHA256: `2fab21861d074f60642648fb560bc081f0be46f3da4b8ae4b5d872213a7b9b12`. Audit v1 remains unchanged.

## 1. Feature geometry

The multinomial identities give the displayed truncated exponential kernel and feature dimension binom(m+k,k). The degree-independent norm bound follows by extending the squared feature norm to the full exponential series.

The derivative calculation is correct: applying a mixed directional derivative to exp(x·y) at x=y=z produces exp(||z||²)(||v||²+(z·v)²). This equals the squared Hilbert norm of the full coordinate-derivative vector. Truncating the feature index truncates a sum of nonnegative squares, so cannot increase it. Uniform derivative convergence on compact balls justifies the calculation. Integrating along a segment in the convex radius-R ball gives L_phi(R)=exp(R²/2)sqrt(1+R²), independently of m.

For xi=phi_m(k) tensor (v,1), split a two-input difference into feature variation and value variation. The resulting row-state Lipschitz constant is exactly bounded by the stated C[L_phi(R_k)sqrt(V²+1)+F_k]. Its full norm is at most R_*=F_k sqrt(V²+1), without a hidden factor from feature or value dimension.

## 2. Quantized transcript and suffix reconstruction

The actual concatenated feature means have norm at most R_*sqrt(A). Projecting each chosen covering-center block onto its radius-R_* ball is nonexpansive relative to the corresponding actual block, so preserves the cover accuracy and does not add codewords.

For each target j in the second half, genuine future raw tokens initialize every suffix row exactly. The feature-prefix complement is an exact identity for the auxiliary feature sums, not for the actual nonuniform attention outputs. Its use is legitimate because queries are not included in the globally summed key/value features.

Simulated queries, keys and values are projected onto their fixed balls. Projections leave true vectors unchanged and preserve the C-times-state-error estimate. At each read all suffix features are computed from pre-read states, preventing circular dependence.

The complement-error bound uses T/i<=2 and (T−i)/i<=1. Equation (11) correctly splits the query-difference term against the true prefix tensor U_i, whose norm is bounded by R_*. The other term uses the simulated query norm F_q. Thus no uncontrolled norm of the approximate tensor or factor of sqrt(feature dimension) enters.

## 3. Taylor remainder and stabilized ratio

The tail exp(S)S^(m+1)/(m+1)! is valid on the complete frozen dot-product interval. Averaging residuals times (v,1) gives joint numerator/denominator error at most sqrt(V²+1)epsilon_m. The attention numerator and denominator are averages, so no extra N factor is needed.

The true numerator belongs to the radius-V exp(S) ball and the true denominator is at least exp(−S). Consequently the numerator projection and denominator floor exp(−S)/2 leave the true ratio unchanged.

For approximate pairs, the projected numerator contributes Lipschitz constant 2exp(S). The denominator reciprocal on the floored domain has constant 4exp(2S), multiplied by the numerator radius V exp(S). Their sum 2exp(S)+4V exp(3S) is a sufficient joint Euclidean bound. This handles negative approximate denominators globally, not only on a vaguely presumed near-reference tube.

Combining feature contraction, Taylor error, ratio stabilization and the local residual update gives Delta_new<=B Delta+B delta_ell+B epsilon_m with B depending only on the declared fixed budgets. The same B can dominate every local-only primitive. Induction yields D B^D times transcript error plus Taylor error. This is the central repeated-QK step, and it closes without m-dependent amplification.

## 4. Cover size, degree, and source entropy

Taking transcript radius error and Taylor error each at most g/(4D B^D) gives total output error at most g/2. The covering-number formula in Eq.(1) then follows with factor 8. Factorial decay, after degree exceeds a fixed multiple of S, permits m=O(D+log(D+1)+log(1/g)+1). At fixed intended g this is O(D+1).

Hence Q_m<=A(d+1)C_k(D+1)^k, and the log of the covering factor is O(D+log(A+1)+log(D+1)+1). Since A<=D, the polynomial resource expressions in Eq.(5) follow. Constants depend on fixed key dimension and frozen norms, not on N, feature degree, or source rarity.

The entropy proof needs only a good genie decoder, not an implemented feature-network. The previously verified conditional reverse Fano argument for full lags therefore transfers unchanged. For rare indicators, the proof properly uses the unconditional reverse mutual-information chain, exact h_A, and conditional data processing, without adding a prefix genie. The earlier N/8 and Nu log_2(1/u)/16 constants remain valid under their respective error thresholds.

## 5. Model qualifications and attribution

Global Lipschitz local primitives, or fixed same-Lipschitz extensions as in the inherited uniform contract, are needed for off-trajectory replay. The proof-only projections and denominator clamps are analytic decoder devices, not uncharged operations supplied to the actual network.

The one-head-per-invocation and fixed full Q/K norm assumptions are substantive. Merely bounded scalar scores do not supply the claimed finite-dimensional separable kernel model. Multiple heads require their actual feature dimensions and aggregate bounds to be charged. The proof does not extend the uniform finite-grid theorem to nonuniform attention arithmetic.

This composes established Taylor/polynomial kernel features, the existing one-read feature code, existing suffix replay, and standard entropy/Fano. The degree-independent derivative and stabilized replay make this particular composition work; no priority claim or new general kernel principle is certified. Accurate local features remain stronger than accurate aggregate counts or terminal prediction risk, and the missing reduction is not supplied.
