# Result registry

6 November 2026. This round does not establish a general terminal-risk T1/T2 frontier.

Accepted exact files:

1. `U_BLIND_SUFFIX_TEST.candidate.v2.md`, SHA256 5b21f29c9e76135deb3a4f09804acd27030612fd93d3ac0049aafdf4afd9ef52. Every sublinear public suffix budget fails the triangular rare-source full-history conditional benchmark; comparison after subtracting the declared output-range floor is valid. Physical compiler transfer is through uniform pathwise error, not assumed suffix measurability. Independent review: `U_BLIND_SUFFIX_TEST.independent_audit.v2.md`.
2. `SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v2.md`, SHA256 8c966282ce5369531e3bac3cf729bece4bdd8aa60694d1675295568f5ba1008a. Repeated uniform attention with evolving values: source-average robust all-lag error yields transcript entropy Omega(N); rare local-context error <=u/256 yields Omega(Nu log(1/u)). Exact-real and explicit finite-grid transcripts have distinct dimension/precision ledgers. Independent reviews: `INDEPENDENT_SOURCE_AVERAGE_LOCAL_AUDIT.v2.md`, `INDEPENDENT_RARE_INDICATOR_V2_AUDIT.v1.md`.
3. `BOUNDED_QK_SOURCE_AVERAGE_EXTENSION.candidate.v2.md`, SHA256 bb4aa0697fc097eb25e7c03e37a9e9a43163550abb2dd646d66f01ecdf94c746. One head per read, fixed full Q/K/V bounds and key dimension: stabilized truncated-feature suffix replay gives A(d+1)(D+1)^(k+1) >= constant times the applicable local-task entropy. Independent review: `INDEPENDENT_BOUNDED_QK_AUDIT.v2.md`; second reviewer also checked the proof independently.

Failed routes retained: `ALL_ROW_TWO_READ_ROUTE_OBSTRUCTION.v1.md`, `FAILED_ROUTES_AND_CORRECTIONS.v1.md`, every candidate/report version. In particular a globally selected suffix is not each row's moving suffix; rare-only indicators cannot be assigned the full symbol entropy; extra earlier-prefix conditioning invalidates the simple reverse rare-entropy identity; a compiled physical output need not be exactly suffix-measurable.

Prior comparisons: `PRIOR_AND_OBSTRUCTION_AUDIT.v2.md`, including direct primary-paper checks of Markov estimators and exponential-kernel approximation. All information inequalities/feature maps are standard ingredients; this round makes no novelty or publication-readiness claim.

Delivery draft: `RESEARCH_REPORT.zh.v2.html`, 89478 bytes, SHA256 bca4c9c1e9af93a66a90bc2868cd74e9ce0fb6cb3dd8b48b0b4b4b4a3545632d. Main `REPORT_MAIN.zh.v4.md`, five adapted complete appendices. Static QA has no active content/private workspace paths; independent final HTML review pending. No visual rendering, training, scientific run, model execution, or public write. HTML v1 and v2 bytes are identical; the version changes only the external QA rule that had falsely interpreted the text `next-one=t` as an HTML event handler.

Remaining gap: terminal-risk accuracy need not imply accurate individual local features. Direct computation of sufficient aggregated statistics, cancellation, or another evolving-memory algorithm remains possible. Neither the local-feature entropy nor the source-specific suffix KL bound supplies the missing terminal-risk reduction.
