# Exact-file review addendum for bounded-QK revision 2

6 November 2026 UTC. Independent mathematical review, with no scientific execution, upload or public write.

**PASS.** The complete revision 1-to-2 diff was read and the source hash checked:

    BOUNDED_QK_SOURCE_AVERAGE_EXTENSION.candidate.v2.md
    SHA256 bb4aa0697fc097eb25e7c03e37a9e9a43163550abb2dd646d66f01ecdf94c746

The substantive proof audited in `INDEPENDENT_BOUNDED_QK_AUDIT.v1.md` is unchanged. Revision 2 makes its nondegenerate quantization domain D>=1 and 1<=A<=D explicit, states N>=4 for lags and N>=8 for rare indicators, restricts the used numerical margin to 0<g<=1/2, and handles A=0 (including D=0) by a one-point transcript and exact row-local suffix replay.

The zero-read treatment is correct: with pointwise raw initialization and only row-local operations, the true future determines all suffix outputs without a message. The same entropy/Fano inequalities prohibit the positive-entropy-gap error regimes. No division by D, undefined covering radius, or positive-dimensional net is needed.

Accordingly the v1 audit's PASS transfers to this exact v2 file, including its improved boundary statements. All original scope limits remain: fixed bounded bilinear QK dimension and full norms, one-head accounting, no arbitrary pairwise positional scores, robust individual local outputs, and no terminal-risk or finite-QK execution theorem.
