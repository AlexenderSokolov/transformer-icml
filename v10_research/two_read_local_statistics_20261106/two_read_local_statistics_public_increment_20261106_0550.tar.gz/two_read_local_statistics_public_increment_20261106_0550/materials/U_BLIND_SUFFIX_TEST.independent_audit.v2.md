# Independent audit of the u-blind suffix test

6 November 2026 UTC. Independent mathematical source review, not a numerical execution, formal verification, novelty certification, trained-model result, or instantiated finite-machine certificate. No scientific diagnostic, model execution, parameter generation, upload or public write was performed.

## Verdict and exact-file binding

**PASS for the exact-real suffix-only proposition, its triangular u-blind comparison, and revision 2's explicit transfer to uniformly close physical PreLN outputs.**

Reviewed file:

    U_BLIND_SUFFIX_TEST.candidate.v2.md
    SHA256 5b21f29c9e76135deb3a4f09804acd27030612fd93d3ac0049aafdf4afd9ef52

The preceding revision was separately read:

    U_BLIND_SUFFIX_TEST.candidate.v1.md
    SHA256 61b4497488200faa9b36133573ddd3693bfec584a19e4b8e83cb99f6e6f0909c

Its strict suffix-only proposition was valid. Its application to the physical compiled predictor needed an explicit approximation transfer, because the actual normalized network need not be exactly suffix-measurable. Revision 2 supplies that transfer and repairs the finite-evaluator wording. This audit binds revision 2, not future changes.

## 1. Same-source KL and quantifiers

The direct source `../rare_attention_information_bridge_20261106/EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md`, Section 4.1, was read. Its terminal-A conditional bound is

    KL(P_t^(X|E_A) || P_s^(X|E_A)) <= 60(1+Nu)(t-s)^2.

The proof is a genuine conditional-law argument, not stationary KL divided by u: reversing a stationary symbol path ending at A gives the same symbol kernel initialized at pair A. The common two-step atom at D yields an A-occupation bound of (N-2)u+8. The A-row KL is at most (16/3)(t-s)^2 and the C-row KL is at most 7u(t-s)^2, which imply the stated conservative constant 60.

The last b observations of a stationary length-N history have the stationary length-b marginal. Conditioning on their own final pair A is exactly the same event as the full history's terminal A. Substituting b for N in this KL bound is therefore valid; no conditional iid assertion or independent terminal query is inserted.

For t0=1/2, t1=17/32 and h=1/32, bu<=1 gives

    KL <=120/1024,
    TV <=sqrt(60/1024) < 1/2.

The reference uses the same predictor under both t values. It may know the common u, but it does not receive the unknown parameter t as advice. Independent randomization is a common Markov kernel and cannot increase TV. The common-part inequality gives sum of the two absolute risks at least h(1-TV), hence maximum at least h/4=1/128. The fixed pair works for every predictor; the proof does not require choosing a new pair after inspecting its output.

## 2. Exact range-floor subtraction

For each fixed t and every output whose next-zero probability lies in [alpha,1-alpha], terminal C contributes at least

    w(alpha-q_t)_+ = F_t.

The disjoint terminal-A contribution is exactly u times its conditional next-one absolute error, while B,D contributions are nonnegative. Thus

    R_t-F_t >= u E_t[|Q(1)-t| | E_A]

holds pointwise in t before maximizing. The possible difference between F_t0 and F_t1 does not affect the argument: it subtracts each source's own floor before taking the maximum. No subtraction of a supremum floor or false factorization of a maximum is used.

It is essential that the range condition holds for the ACTUAL predictor. A mere approximate equality of probabilities or a reference-only clipping statement would not suffice. Revision 2 respects this requirement in its physical and finite extensions.

## 3. The triangular source sequence and public budgets

For every public schedule 3<=b_N<=N with b_N/N->0,

    u_N=(N b_N)^(-1/2),
    b_N u_N=sqrt(b_N/N)->0,
    N u_N=sqrt(N/b_N)->infinity.

Eventually u_N<=1/100 and the two-point condition holds. The suffix conditional error remains at least 1/128, while the full-history conditional upper tends to zero. This is a uniform-in-u failure witness; it does not deny pointwise consistency at fixed u>0.

The suffix excess lower is u_N/128. Dividing it by the existing full-history statistical term 1300u_N/sqrt(1+(N-2)u_N) grows at order (N/b_N)^(1/4). For a legal power-of-two full-history suffix b_full>N/2, only fixed constants change.

Public dyadic G of order N^2 and epsilon of order N^(-2) suffice without knowledge of u. More generally the stated inequalities G>=N^2 and epsilon<=N^(-2) make the errors no larger. To see their negligibility directly, write x=N u_N>=1. Then

    u_N/sqrt(1+N u_N) = x/[N sqrt(1+x)] >=1/(sqrt(2)N).

Consequently O(N^(-2)) quantization/compilation error is negligible relative to that statistical term. These choices do not make the full-history decoder polylogarithmic: its b_full=Theta(N) decoding depth remains paid. The candidate expressly preserves that boundary.

## 4. Physical approximation transfer

A physical PreLN implementation can retain tiny earlier-history dependencies through normalization and approximation. Revision 2 correctly avoids calling it strictly suffix-measurable.

If TV(Q_phys,Q_ref)<=delta on every legal history and Q_ref is suffix-measurable, then at each source

    E_t[|Q_phys(1)-t| | E_A]
      >= E_t[|Q_ref(1)-t| | E_A]-delta.

Applying the two-point maximum therefore yields 1/128-delta. If Q_phys itself has the exact alpha range, the excess lower is u(1/128-delta). The supremum/pathwise guarantee is what allows conditioning without an additional 1/u loss.

The inherited ordinary-softmax construction proves the appropriate comparator statement with Q_ref equal to the alpha-projected quantized suffix estimator and delta<=3epsilon/4. This was checked against Section 4, equation (8), of `../fixed_width_rare_risk_frontier_20261106/FIXED_WIDTH_RARE_RISK_FRONTIER.candidate.v2.md`. Thus the claimed extension applies to that implementation, not merely to an imaginary exact compiler.

The same transfer applies to a finite evaluator only if its independently established uniform pathwise error is added to delta. Retaining the same floor additionally requires the finite output range. The inherited sufficient condition nu<=mu/2 is now stated. An unconditional error bound alone can cost a factor 1/u under terminal-A conditioning, as the candidate explicitly warns.

## 5. Norm/range and finite-contract boundaries

For a known lower rarity bound u>=rho within the source domain, q_t is minimized at u=rho,t=1/2 and equals 3rho/[2(1-rho)]. Therefore the stated alpha criterion and the smaller sufficient alpha are correct. Changing alpha changes the permitted output/logit/norm envelope; no uniform fixed-positive-alpha removal of the floor over all u>0 follows.

Revision 2 now says that the finite evaluator is a separately stated CONDITIONAL contract whose conditions must be met. No evaluator was instantiated or executed by this candidate or by this audit. Exact-real coefficient descriptions remain distinct from activation precision and concrete implementation certification.

## 6. Scope that must remain attached

The result rejects strict suffix-only information choices, and uniformly close implementations, as a uniform full-history rare-rate solution when b_N=o(N). It is not a lower bound for arbitrary fixed-width transformers, arbitrary evolving-memory summaries, general depth, useful attention count, or data-dependent adaptive sample selection. It does not prove D>=b for arbitrary architectures. It adds no new statistical rate or literature-priority claim.

The numerical constants are conservative inherited bounds. The core proposition, floor subtraction, u-blind triangular quantifiers, and revision 2's physical-error accounting are mathematically consistent with the exact frozen output contract.
