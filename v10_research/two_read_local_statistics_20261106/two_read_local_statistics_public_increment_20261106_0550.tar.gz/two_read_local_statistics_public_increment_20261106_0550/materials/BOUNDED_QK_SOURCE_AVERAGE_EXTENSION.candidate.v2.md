# Repeated bounded-QK extension of the source-average local barrier

6 November 2026 UTC. Separate private analytical candidate v2, pending independent exact-file review. Version 1 is preserved; this revision explicitly handles zero-read/zero-depth boundary cases before using the quantization formulas and states the actual margin domain. The reviewed uniform-read argument is retained in `SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v2.md`; this file must not inherit its review status. No mathematical executable, numerical test, source simulation, model execution, upload, or public write was performed. No novelty claim is made.

## 1. Statement and scope

Take the same raw binary source, row-local input/readout, N raw rows plus fixed sentinel, and D paid synchronous primitives as in `SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v2.md`. There are A<=D useful full-inclusive-prefix attention invocations, with one ordinary bilinear-QK head at each invocation. Query/key dimension is at most a fixed k and value dimension at most d. The actual complete query/key/value vectors satisfy fixed bounds

    ||q_i||<=R_q,  ||k_i||<=R_k,  ||v_i||<=V.

Their row-local maps, all other local primitives, and the local attention residual/output update have uniformly bounded full-vector Lipschitz constants C>=1. Scores are q_i dot k_s, with the conventional dimension scaling absorbed into these fixed bounds. There is no arbitrary pairwise positional bias or extra cross-row primitive. All output gains and readout operations are counted.

Later keys, queries and values may depend on earlier attention. The theorem does not assume that later values are raw-symbol-local.

For the nondegenerate transcript and quantization formulas assume D>=1 and 1<=A<=D. If A=0 (including D=0), use a one-point transcript and exact row-local suffix replay instead. The same Fano inequalities then directly prohibit either stipulated positive-entropy-gap error regime; no division by zero or zero-dimensional covering calculation is required. The lag statement uses N>=4; the rare-indicator statement uses N>=8.

For any fixed numerical margin 0<g<=1/2, there are constants B>=2 and R_*>0 depending only on the frozen norm/Lipschitz budgets, and a degree

    m=O(D+log(D+1)+log(1/g)+1),

such that a proof-only quantized global-feature transcript has at most

    B_code = Q_m log_2(1+8R_* sqrt(A)D B^D/g)
    Q_m=sum_(ell=1)^A (d_ell+1) binom(m+k_ell,k_ell)    (1)

bits of log-cardinality and supports the same genie-aided local decoders as the uniform theorem. Here k_ell<=k and d_ell<=d. For fixed g, k and the frozen budgets,

    B_code <= C_0 A(d+1)(D+1)^k
                      [D+log(A+1)+log(D+1)+1].        (2)

Therefore the standard entropy arguments give:

- For numerical predecessor rails at all rows, with source-expected bad fraction epsilon at threshold eta<1/2 and g=1/2-eta,

      B_code >= n[h_*-h_2(2epsilon)],  epsilon<=1/4,
      n=N-floor(N/2),  h_*>=33/50.                    (3)

- For numerical rare-context indicators at transition row j+2, with threshold eta_A<1/2, g=1/2-eta_A and source-expected bad fraction epsilon_A over j=1,...,N-2,

      B_code >=ell[h_A-h_2(4epsilon_A)],
      ell=N-floor(N/2)-2,  N>=8,  epsilon_A<=1/8,
      h_A=u h_2(t)+w h_2(q_src).                      (4)

In particular epsilon<=1/32 implies B_code>=N/8; epsilon_A<=u/256 implies B_code>=(Nu/16)log_2(1/u). For fixed budgets and fixed key dimension, these imply respectively

    A(d+1)(D+1)^(k+1)=Omega(N),
    A(d+1)(D+1)^(k+1)=Omega(Nu log(1/u)).             (5)

The first excludes fixed-width polylogarithmic-depth/call schemes that reconstruct most fixed-margin raw local lags. The second is the more task-aligned but weaker bound for very accurate rare indicators. Neither is a terminal prediction-risk lower. In particular, (5)'s first line is not necessary merely because the desired terminal estimator uses rare counts.

## 2. Degree-independent feature bounds

For multi-indices alpha in N^k define the truncated exponential features

    phi_m(z)=(z^alpha/sqrt(alpha!))_(|alpha|<=m),
    L_m=binom(m+k,k).

The standard identities give

    ||phi_m(z)||^2<=exp(||z||^2),
    <phi_m(q),phi_m(k)>=sum_(r=0)^m (q dot k)^r/r!.

Put S=R_q R_k. Uniformly over the frozen query/key balls,

    |exp(q dot k)-<phi_m(q),phi_m(k)>|
       <=epsilon_m:=exp(S)S^(m+1)/(m+1)!.             (6)

If S=0 the degree-zero formula is exact.

The important additional fact for repeated reads is a derivative bound independent of m:

    ||D phi_m(z)[v]||^2
       <=exp(||z||^2)(||v||^2+<z,v>^2)
       <=exp(R^2)(1+R^2)||v||^2,  ||z||<=R.           (7)

To verify (7), use the full exponential-feature kernel <phi_infty(x),phi_infty(y)>=exp(x dot y). Its mixed directional derivative at x=y=z is exp(||z||^2)(||v||^2+<z,v>^2), the sum of the squared coordinate derivatives of the full feature vector. Truncating this sum of nonnegative squares only decreases it. The entire series and its derivatives converge on bounded balls. Integrating along a segment inside the ball gives the Lipschitz constant

    L_phi(R)=exp(R^2/2)sqrt(1+R^2),

also independent of m. Thus increasing the polynomial degree increases transcript dimension without increasing these feature norm and Lipschitz budgets.

For one source value define

    xi_m(k,v)=phi_m(k) tensor (v,1).

On the query/key/value balls set

    F_k=exp(R_k^2/2),  F_q=exp(R_q^2/2),
    R_*=F_k sqrt(V^2+1),
    L_xi=C[L_phi(R_k)sqrt(V^2+1)+F_k].               (8)

Then ||xi_m(k,v)||<=R_* and its dependence on a row state is L_xi-Lipschitz, as long as its key and value maps are C-Lipschitz. Bounds (7)-(8) are independent of m, N and D.

## 3. Global feature transcript

At every actual read ell form the auxiliary mean

    z_ell=(1/T)sum_(s=1)^T xi_m(k_s^ell,v_s^ell),
    Z=(z_1,...,z_A),  ||Z||<=R_* sqrt(A).             (9)

All quantities in (9) are computed from the actual states at that invocation. This is a proof device, not an added network feature, attention channel, or uncharged computation.

Cover the radius-R_* sqrt(A) ball at some radius delta and use a finite center index K. After choosing a center, project each of its blocks onto its radius-R_* Euclidean ball. Each such projection leaves the true block fixed and is nonexpansive, so the resulting transcript Zhat still satisfies

    ||Zhat-Z||<=delta,

with no increase in the number of codewords. The block projections are only convenient proof stabilization.

## 4. Stable suffix replay for a query-dependent head

Fix j>floor(N/2) and supply the true future X_(j+1):N. Initialize exactly all suffix row states i>j, including the sentinel. Replay local primitives as usual. At a head stage compute simulated queries, keys and values from simulated states, then project them separately onto the frozen balls of radii R_q,R_k,V. These projections leave all corresponding true vectors unchanged, are 1-Lipschitz, and preserve the C-times-state-error bounds. They only define the proof's approximate decoder; no clipping operation is being added to the actual network.

Write Delta for the maximum suffix-state error before the head. Compute

    Uhat_i=(T/i)zhat_ell
           -(1/i)sum_(s>i) xi_m(khat_s,vhat_s),
    (ahat_i,bhat_i)=<phi_m(qhat_i),Uhat_i>.            (10)

Contraction in (10) is along the feature index, leaving d_ell numerator coordinates and one denominator coordinate. The exact feature prefix tensor is

    U_i=(1/i)sum_(s<=i)xi_m(k_s,v_s)
       =(T/i)z_ell-(1/i)sum_(s>i)xi_m(k_s,v_s).

Since T/i<=2 and (T-i)/i<=1,

    ||Uhat_i-U_i||<=2||zhat_ell-z_ell||+L_xi Delta,
    ||U_i||<=R_*.

Using the true U_i for the query-difference term avoids an uncontrolled tensor norm. The projected query map has error at most C Delta, so

    ||(ahat_i,bhat_i)-<phi_m(q_i),U_i>||
      <=2F_q||zhat_ell-z_ell||
        +[F_q L_xi+L_phi(R_q)C R_*]Delta.             (11)

The true averaged softmax numerator and denominator are

    a_i=(1/i)sum_(s<=i)exp(q_i dot k_s)v_s,
    b_i=(1/i)sum_(s<=i)exp(q_i dot k_s),
    o_i=a_i/b_i.

They satisfy ||a_i||<=V exp(S), b_i>=exp(-S). Averaging the Taylor remainder, rather than summing it without normalization, gives

    ||<phi_m(q_i),U_i>-(a_i,b_i)||
       <=sqrt(V^2+1)epsilon_m.                       (12)

There is no extra factor N in (12).

### 4.1 A globally stable proof-only ratio

Approximate denominators need not be positive. Define Pi_R as Euclidean projection onto the radius-R ball and set

    R_stab(a,b)=Pi_(V exp(S))(a)/max{b,exp(-S)/2}.

It agrees with the true attention ratio on every actual pair (a_i,b_i). It is globally Lipschitz in the joint numerator/denominator pair, with a sufficient constant

    L_R=2exp(S)+4V exp(3S).                           (13)

Indeed, subtracting ratios gives a numerator difference divided by a denominator at least exp(-S)/2, plus a bounded numerator times the difference of reciprocal denominators. Projection and the denominator clamp are nonexpansive. The two coordinate-wise constants are respectively 2exp(S) and 4V exp(3S); their sum bounds the joint Euclidean Lipschitz constant.

Use ohat_i=R_stab(ahat_i,bhat_i) in the simulated local residual/output update. Combining (11)-(13), then applying that update's C-Lipschitz bound, yields a fixed constant B>=2 such that

    Delta_new<=B Delta+B||zhat_ell-z_ell||+B epsilon_m. (14)

B depends only on C,R_q,R_k,V, not on m. Local-only primitives multiply Delta by at most C, which can also be absorbed into B. Induction through the D counted primitives, including the row-local numerical output, gives

    max_(i>j)||outputhat_i-output_i||
       <=D B^D (||Zhat-Z||+epsilon_m).               (15)

Every target bit/indicator again uses its own decoder supplied with the genuine suffix. No raw tokens are guessed or recycled between decoders. Query dependence and evolving prefix-dependent keys/values are paid through the explicit recurrence (14), not assumed away.

## 5. Precision, feature degree, and entropy conversion

Take

    delta=g/(4D B^D),
    epsilon_m<=g/(4D B^D).                           (16)

Then (15) bounds numerical output error by g/2. A good original eta-accurate scalar output with g=1/2-eta remains strictly on the correct side of the threshold 1/2. The same holds for eta_A-accurate rare indicators.

The radius-R_* sqrt(A) cover has at most

    (1+2R_* sqrt(A)/delta)^Q_m
       =(1+8R_* sqrt(A)D B^D/g)^Q_m

centers, proving (1). The factorial tail (6), using n!>=(n/e)^n after n exceeds a fixed multiple of S, permits

    m<=C_1[D+log(D+1)+log(1/g)+1]

with C_1 depending only on the frozen budgets. For fixed g and D>=1 this is m=O(D+1). The dimension and log-cardinality bounds in (2) follow. Using A<=D, the displayed logarithmic factors can be absorbed into D+1 for (5).

At this point the proof needs only the decoder error property, so the unchanged standard entropy conversions in the uniform source-average candidate apply:

1. For all lags, condition on the first half and use the reverse entropy chain over the second half. Equation (2) of that candidate gives n h_* source entropy, and binary Fano subtracts n h_2(2epsilon).
2. For rare indicators, do **not** condition additionally on the first half. Use the unconditional reverse information chain and drop the unused nonnegative terms. The selected j<=N-2 satisfy H(1{X_j=X_(j+1)=0}|X_(j+1):N)=h_A exactly. Conditional data processing and Fano give (4).

The numerical constants and source-law calculations for the two convenient error regimes are unchanged. This completes the claimed exact-real source-average inequalities, subject to independent review of this separate replay argument.

## 6. Limits and attribution

- A uniform-read complement identity is used here only for the auxiliary **feature sums**, not falsely for the actual nonuniform attention outputs. The Taylor approximation and ratio stabilization are explicit.
- Fixed bounded query/key dimension and frozen full query/key norms are essential to the stated polynomial-degree dimension bound. Merely saying that scores are bounded, or supplying an arbitrary pairwise positional score, is not the model proved here.
- One head per useful invocation is the stated model. A fixed number of independently norm-bounded heads can be treated by separate feature blocks with charged dimensions and aggregate local Lipschitz budgets; no unbounded-head extension is claimed without that accounting.
- The proof-only code may have dimension polynomial in D even when the actual network width is fixed. It is a compression device for a lower bound, not hidden actual width.
- Exact-real injection remains possible. Fixed-margin local reconstruction, bounded continuation sensitivity, and the finite proof code are what connect to Fano here.
- No common-grid finite-arithmetic QK theorem is inferred from this argument. Section 7 of the uniform candidate has separate arithmetic semantics; it does not automatically extend to nonuniform softmax evaluation.
- The rare-indicator result does not require all raw lags, but it still requires accurate individual local indicators. Aggregate statistical counts and actual-terminal risk may avoid that representation. Neither (3) nor (4) closes the terminal-risk problem.
- The standard Fano/data-processing argument and truncated exponential feature map are not claimed as new. This candidate composes the earlier one-read bounded-QK feature code with the earlier repeated-uniform transcript replay, supplying the degree-independent derivative and stabilized approximate-ratio steps needed for repeated QK reads.

Local dependencies: `SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v2.md`; `../parallel_terminal_estimator_20261105/ALLROW_SINGLE_INVOCATION_OBSTRUCTION.candidate.v1.md`, Sections 4-6; and `../transcript_width_lower_audit_20261104/sources/transcript_packing_candidate.v3.md`.
