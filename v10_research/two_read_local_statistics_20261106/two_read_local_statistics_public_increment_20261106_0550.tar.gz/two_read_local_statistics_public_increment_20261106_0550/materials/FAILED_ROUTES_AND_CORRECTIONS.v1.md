# Failed routes and corrections retained

6 November 2026. This record preserves logical failures, not numerical experiments. No model or diagnostic was run.

## F1: the moving-window shortcut is false

Attempt: use the old constant-width one-read suffix decoder at every row, claim each row gets its own final three raw symbols in O(log N), and pool triples in a second read.

Failure: its source gate is the single public interval [N-b+1,N], independent of the receiving row. A row before that interval sees no selected values; a row inside it sees a prefix of this same interval, then defaults. Its legal virtual word is not its own moving window. The already-proved all-row one-uniform-read lower requires D=Omega(N) for fixed-width, constant-margin predecessor recovery. The all-row QK bound is N<=C(D+1)^k[D+log(N+1)+1], not N/polylog N. A rapid preliminary quotation of the latter stronger rate was corrected before using it in any theorem.

A valid linear-depth construction could decode the entire public prefix, skip missing digits, retain each row's last three symbols, and pool them. This is redundant with the existing one-read linear-depth terminal decoder and does not improve the frontier. It was not expanded into another claimed algorithm.

## F2: whole-symbol entropy cannot be assigned to rare-only features

Attempt: the source has entropy rate at least .66 bits per symbol, so every rare-statistics pipeline must communicate Omega(N) effective bits.

Failure: an all-zero 00-indicator estimate has absolute average error u. The rare indicator has much less information than all raw lags, and terminal parameter estimation has a still different information target. The valid rare-feature theorem uses h_A=u h_2(t)+w h_2(q), small error relative to u, and a weaker Omega(Nu log(1/u)) resource term. It does not imply a terminal-risk lower.

## F3: first-half conditioning invalidates the simple reverse-entropy identity

Attempt: reuse the full-lag entropy proof conditioned on the first half, but substitute H(1{X_j=X_(j+1)=0}|future)=u h_2(t)+w h_2(q) without changing that conditioning.

Failure: a bridge conditioned on earlier observations need not have the stationary reversed transition law. An explicit four-symbol example in the same allowed source demonstrates the change. Set u=1/100, t=3/4, w=33/100, q=1/44. Then

    Pr(X_2=0 | X_3=0,X_4=1)=q=1/44,
    Pr(X_2=0 | X_1=0,X_3=0,X_4=1)=1/87.

Indeed the two possible strings are 0001 and 0101. Their stationary probabilities are respectively

    u(1-t)t=3/1600,
    w(1/2)(1-q)=258/1600,

so the second conditional probability is 3/(3+258)=1/87. All conditioning events have positive probability.

Correction: use the UNCONDITIONAL reverse mutual-information chain I(X_1:N;K)=sum_j I(X_j;K|X_(j+1):N), discard unselected nonnegative terms, then apply conditional data processing to the rare indicator. Do not give the earlier prefix as extra information in this rare-entropy identity. The full-lag theorem's separate first-half-conditioned argument remains valid because it uses the forward chain to compute its entropy budget, not this reversed bridge identity.

## F4: a physical compiler is not exactly suffix-measurable

Attempt: apply the strict suffix-information Le Cam lower directly to the final physical PreLN output.

Failure: approximate arithmetic and LayerNorm may preserve tiny dependencies on non-suffix rows. The reference is suffix-measurable; the physical output need not be.

Correction in U_BLIND_SUFFIX_TEST v2: a uniform pathwise TV distance delta to a suffix reference transfers the conditional lower as 1/128-delta. The excess-over-range-floor lower additionally requires the physical output's exact alpha range. A finite evaluator adds its pathwise error and must separately preserve the range; an unconditional implementation error cannot be conditioned for free.

## F5: the floor cannot be ignored, and precision is conditional

A fixed alpha gives F=w(alpha-q)_+ tending to alpha/3 as u tends to zero. Raw overall risk ratios can therefore hide a large rare-parameter gap. This round compares conditional A risk or R-F, with F identical for the compared predictors at the same source. Eliminating F by changing alpha changes the logit/norm budget.

No implemented evaluator has been certified. The preceding finite-execution theorem is conditional on explicit operation errors, nonoverflow and arithmetic certificates. Its use does not establish an IEEE implementation, runtime bit complexity, or numerical reproducibility. The phrase 'separately certified evaluator' in the initial suffix note was corrected to 'separately stated conditional evaluator contract, if its conditions are met.'

## F6: no return to the empty generic message/grid route

The preceding result that a generic total-message bound minus Lipschitz grid error is nonpositive is retained. The current transcript quantization has a different target: constant-margin local reconstruction (or rare-indicator error at a fixed small fraction of u) and an explicit source entropy lower. It is not a repaired relative-terminal-risk simulation. Any later attempt to infer the main T1/T2 statistical bound still needs a new reduction from terminal risk to the stated local task.
