# Independent audit: source-average local reconstruction obstruction

6 November 2026 UTC. Analytical review only. No scientific executable, numerical test, parameter generation, enumeration, model execution, upload, or public write.

## Review target and verdict

Read the complete `SOURCE_AVERAGE_LOCAL_BARRIER.candidate.v1.md`, its prior repeated-uniform transcript proof, and the complete v1-to-v2 diff, including the new Section 9. The main exact-real lag result, one-read specialization, finite-grid counterpart, full-triple result, and rarity-scaled local-indicator result are mathematically sound under their stated contracts.

**Verdict: PASS for candidate v2's scoped mathematical claims.** The requested epsilon_tri<=1/4 condition is now explicit beside Eq.(17). Section 9's smaller rare-indicator lower was independently checked as described below. No new construction, terminal statistical-risk consequence, or novelty claim is certified. Candidate v1 and audit v1 are preserved.

Reviewed candidate v2 SHA256: `8c966282ce5369531e3bac3cf729bece4bdd8aa60694d1675295568f5ba1008a`.

Initial v1 SHA256: `12b8efd6d4b0cdede9de12beb2c121592d6c9835079b3244c3892b19a300833f`.

Direct dependency read: `../transcript_width_lower_audit_20261104/sources/transcript_packing_candidate.v3.md`, SHA256 `67408bfe9d28f2bef99361bd846cf96ee7644b0c6e45b64e343ed8284a1ec741`.

## 1. Entropy calculations

The stationary entropy rate is exactly u h_2(t)+w h_2(q_src)+2w. The two fair rows supply 2w>=33/50 throughout 0<u<=1/100. For m>=2 the conditional entropy of the remaining n=N−m symbols given the complete first m symbols is n h_*. This follows by the forward conditional chain rule and order-two Markov property, not an independence assumption.

The claimed H(X_1:N)>=N h_* also holds. Stationarity gives H(X_1)=H(X_3)>=h_* and H(X_2|X_1)=H(X_3|X_2)>=H(X_3|X_1,X_2)=h_*. The remaining N−2 conditional entropy terms equal h_*.

High entropy here primarily concerns common B/D transitions. It cannot alone establish a lower for learning the rare A transition parameter. The candidate explicitly retains this distinction.

## 2. Repeated-uniform suffix replay

At every stage, the actual global average satisfies

    a_i=(T/i)z_ell−(1/i)sum_(s>i)v_s.

For any target j in the last half, initializing only rows i>j requires exactly the true future symbols and the known sentinel. All local preprocessing is therefore reproducible. Every term used at an attention stage comes from the preceding layer, avoiding a circular definition.

For simulated suffix-state error Delta and transcript-block error delta_ell, T/i<=2 and (T−i)/i<=1 imply average error at most 2delta_ell+C Delta. Applying the joint local update gives C(1+C)Delta+2C delta_ell. This is valid even though later actual values depend on their complete prefixes: that unknown dependence enters through the global transcript. It is not assumed token-local after the first attention.

With fixed B dominating the listed local constants, the D B^D norm-error bound follows by a geometric recurrence and max(delta_ell)<=||Zhat−Z||. The complete final row-local readout is correctly included in D and C.

The proof-only trajectory can be off the reachable manifold. The global-Lipschitz hypothesis, or fixed same-Lipschitz Euclidean extensions stated in the candidate, is sufficient for this issue. Bounded values are needed only on actual executions to cover the actual transcript set. No claim that the simulator is itself a legal paid network is required or made.

## 3. Covering and Fano

The concatenated transcript lies in a Q-dimensional ball of radius M sqrt(A). A maximal delta-separated set covers that ball and has at most (1+2M sqrt(A)/delta)^Q centers. Choosing delta=g/(2D B^D), g=1/2−eta, yields Eq.(8) exactly.

Replay error at most g/2 leaves any eta-good original rail strictly within 1/2 of its target bit. Thus thresholding the simulated rail has bit-error probability p_j<=e_j. This is a mathematical decoding rule for the information proof, not an unpaid network threshold.

Giving the decoder the true suffix separately for every target j is valid in the reverse conditional entropy chain. The extra first-half side information may be ignored by the decoder. Binary Fano bounds each conditional entropy by h_2(p_j), Jensen bounds their sum by n h_2(pbar), and monotonicity applies because pbar<=epsilon_tail<=1/2. This yields Eq.(10). Since n>=N/2, epsilon_tail<=2epsilon, and Eq.(11) follows for epsilon<=1/4.

This proof does not reconstruct the history by substituting earlier guesses for true future symbols. It therefore avoids the error-propagation problem explicitly preserved in the failure log.

For epsilon<=1/32, h_2(1/16)<3/8 can be verified symbolically: its first contribution is 1/4 and its second is less than 1/(16 ln 2)<1/8. Consequently 33/50−3/8=57/200, and multiplying by n>=N/2 gives more than N/8. The Markov conversion R<=1/128 with eta=1/4 gives epsilon<=4R<=1/32, as claimed.

## 4. Consequences and one-read variant

For fixed constants and 1<=A<=D, the logarithm of the covering number per coordinate is O(D+log(A+1)+log(D+1)). Thus Q times this quantity is Omega(N). With the separately declared Q<=AW, the stated width/read/depth consequences follow; in particular fixed W,A forces linear depth, and fixed W with A<=D forces D=Omega(sqrt(N)). They are consequences for robust local reconstruction only.

The one-read proof can retain all N bits because, with true future supplied, all values later than receiving row t=j+1 are known before any communication. The factor T/t<=T gives output error Lambda T delta. The selected cover and the unconditional reverse entropy chain then give Eq.(14). Its continuation is local, and the sentinel supplies a fixed receiving row for X_N. This specialization is correct without the repeated-read last-half trick.

Degenerate zero-message cases are handled separately, rather than dividing by zero in a covering radius or claiming information from an empty transcript.

## 5. Finite arithmetic

Each actual pre-rounding coordinate is an integer multiple of 2^(−p) with magnitude at most M_f. Its exact global sum consequently has no more than 2 floor(T M_f 2^p)+1 possible values. This loose cardinality bound is valid even when M_f 2^p is not an integer.

Given those exact sums and a true suffix, all suffix values and exact prefix sums can be recovered inductively, and the same head-specific deterministic division/rounding is then replayed. Arbitrary deterministic local maps do not break this exact equality. Binary Fano gives Eq.(15); a margin is unnecessary in this separate exact-replay theorem.

The distinction Q_f versus exact-real effective Q is necessary and correctly stated. Independent headwise rounding does not commute with later linear mixing, so a real-algebraic collapse cannot reduce Q_f for free. Edgewise rounded or order-dependent accumulation, unsupported floating formats, and unbounded integer magnitudes are outside the theorem.

## 6. Full triples and its boundary

For j=m+1,...,N−1, a correctly reconstructed full triple at row j+1 contains X_j. A Euclidean error strictly below sqrt(2)/2 identifies the correct triple by nearest onehot. Adding at most half of the remaining margin through replay preserves that condition.

Conditioning additionally on X_N costs at most one bit:

    H(X_(m+1):(N−1)|X_1:m,X_N)>=n h_*−1.

There are ell=n−1 target bits. For N>=6, the ratio (N−2)/ell is at most two, so target-tail bad fraction is at most 2epsilon_tri. Under epsilon_tri<=1/4, the same entropy monotonicity proves Eq.(17). The right side is linear for fixed sufficiently small epsilon_tri and large N; no all-small-N positive lower is needed.

Only the complete triple onehot has the bit-recovery property. The two rare-A triple indicators alone do not: the identically zero map is already correct except on an O(u) fraction of rows. Aggregate errors can also cancel or use another decomposition. These limitations are central, not optional disclaimers.

## 7. New v2 rare-context indicator bound

For Y_j=1{X_j=X_(j+1)=0}, the true future contains the next pair because j<=N−2. The reverse conditional probabilities are (1−t) given future pair 00 and q_src=ut/w given future pair 01. Direct stationary triple/pair ratios verify both, and later future likelihood factors cancel. For future first symbol 1, Y_j is deterministic zero. Consequently H(Y_j|X_(j+1):N)=u h_2(t)+w h_2(q_src)=h_A exactly. This is entropy about the local indicator, not parameter t.

The new proof correctly omits the first-half genie here. The unconditional reverse identity I(K;X_1:N)=sum_j I(K;X_j|X_(j+1):N), nonnegativity of all terms, and conditional data processing to Y_j justify Eq.(21). It would be incorrect to replace those terms with the same reverse-law entropy after adding an arbitrary conditioned past, but v2 explicitly avoids that mistake. Applying binary Fano to the actual replay decoder and then concavity/monotonicity gives Eq.(23) for e_A,tail<=1/2.

For N>=8, ell=N−floor(N/2)−2>=N/4 and the selected-target mean error is at most 4epsilon_A. The same suffix replay works for receiving row j+2 because it is strictly after j; supplying the entire true future is allowed in this information bound even if it is more than the physical receiver knows.

The constants in Eqs.(24)–(26) are valid. Throughout the source rectangle q_src<=25u/11<4u, wq_src=ut>=u/2, and L_u=log_2(1/u)>=6. Therefore h_A>=u(L_u−2)/2>=uL_u/3. For e_A,tail<=u/64, the increasing bound p log_2(e/p) gives h_2(e_A,tail)<=u(L_u+8)/64<=7uL_u/192. The entropy gap is thus at least 57uL_u/192, larger than uL_u/4. Combining ell>=N/4 with epsilon_A<=u/256 proves the advertised Nu log_2(1/u)/16 lower on transcript bits. The corresponding AW depth expression uses the same previously verified covering logarithm.

The finite-grid version is a direct substitution of its exact-replay transcript cardinality. Summing two rare-triple coordinates has norm sqrt(2), so a vector-error tolerance eta_A/sqrt(2) indeed implies context-indicator rail error at most eta_A; that fixed gain is correctly charged.

This is not an Omega(N) rare-only-feature lower uniformly in u, nor a count-estimation lower. The hypothesis requires errors smaller than a specified fraction of u and excludes the all-zero baseline, whose failure mass is u. Correlated errors or an alternative aggregate computation remain outside the argument.

## 8. Attribution and accepted scope

This is standard entropy chain rule, binary Fano, Euclidean covering and Markov inequality composed with the already proved global-transcript suffix recurrence. It is a useful source-average strengthening of a representation obstruction, not a new standalone information principle, a new prediction-rate theorem, or a novelty certification.

It does not establish rare-A terminal risk, total terminal TV/KL risk, necessity of multiple reads for estimation, arbitrary nonuniform-attention barriers, aggregate count-error bounds, an unconditional Omega(N) rare-only-feature lower, or finite hardware robustness. It does establish the separate rarity-scaled local-feature bound under Section 9's small-relative-error hypothesis. The source parameter may be rare while its common-symbol entropy remains bounded away from zero; those are different information tasks.
