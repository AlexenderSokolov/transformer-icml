# Dependencies and omissions

All 44 available files are represented, including old proof/report/static-QA versions and separate final QK derivation/prior reviews. Three prior-audit files are exact scientific-content-preserving neutral derivatives; original hashes remain in the map. No scientific failure or provisional review boundary is dropped.

External dependencies remain OPEN: earlier all-row/suffix reconstruction, rare source/statistical risk and range-floor results, uniform pathwise compiler transfer, normalized-network/paid primitive contracts, feature approximation and information-inequality inputs, and referenced prior research. The terminal-risk-to-local-reconstruction reduction is NOT established. Source relative references identify evidence, not a bundled transitive proof graph.

Third-party full papers, absent numerical/training runs, unproved general terminal-risk bounds, unavailable visual acceptance and missing prior v10 files are not included. Historical source-match hashes refer to original prior audits; neutral derivatives adapt to the same unchanged report because the original adapter already omits their operational sections. Exact byte identity is not mathematical proof or dependency closure.
