# Independent packaging review

6 November 2026 UTC. PASS for scoped public release.

- Independently counted 44 source files, 687,769 bytes. All represented: 41 exact copies and three neutral prior-audit derivatives.
- Verified every source/public size and SHA256. Reconstructed all three derivatives from their original files using exactly the six mapped replacement occurrences. No unlisted changes.
- Mapping SHA256: 898e32dbdaea49c19627a9b9459d719cd24344552c40a1d4ec55f25eab1d02ba.
- Independently reconstructed the final HTML body in memory from the public main text and all five adapted appendices; exact match. Final HTML remains 89,799 bytes, SHA256 d5d7111d5d4a78e601e6d32b919ea77e422a611b2860528a7131e75b76df5108.
- Historical versions, failed routes, corrections, distinct audits, static extraction, registries, and three builder versions remain present. Retrieval failure and provisional scientific status survive neutralization.
- README correctly limits the results to local reconstruction, distinguishes strict-suffix failure and the output-range floor, and disclaims general terminal-risk or unknown-parameter estimation lower bounds. One-head/fixed-QKV/fixed-key-dimension, paid replay, and finite-grid limitations are retained.
- No substantive privacy/copyright blocker found. Provider/account details and coordination attribution are removed from public prior audits. “Parent transcript lemma” is a mathematical dependency reference. Builder scan-pattern literals are not disclosures. Third-party papers are cited and summarized, not redistributed.
- Dependency closure, visual acceptance, scientific execution, training, machine-arithmetic certification, and complete v10 recovery remain expressly unestablished.

Review was read-only: no source writes, scientific reruns, builder output generation, or GitHub action. Final package checksum inventory remains for the packager to create after adding this review.
