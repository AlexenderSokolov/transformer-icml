# Restricted memory architecture increment

This is a five-file research increment retained after the earlier short-text snapshot. Original files are unchanged; SOURCE_MAP.json binds exact bytes.

The anchored-memory extension assumes a finite public anchor bank and the stated separable-rank/communication contracts. Its abstract counterexample is only within that specified model. The causal pre-layer-normalization anchor witness establishes a structural intersection with the causal construction; it does not establish low prediction risk. These statements are not general results for arbitrary repeated attention.

The historical README.v3 and candidate versions retain their original pending descriptions. A later independent audit is a separate artifact, not an in-place change to those records. Audit acceptance applies to the exact source version and declared mathematical contracts. It does not establish experiment execution, general architectural universality, or a self-contained public dependency closure.

This package includes no numerical experiment run. The referenced earlier proofs, contracts and larger data collection remain separate.
