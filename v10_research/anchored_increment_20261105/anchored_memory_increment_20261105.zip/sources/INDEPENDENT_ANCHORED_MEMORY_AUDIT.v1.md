# Independent exact-version audit: anchored memory extension v1

5 November 2026 UTC. Exact reviewed file: `ANCHORED_MEMORY_EXTENSION.candidate.v1.md`.

SHA-256: `b805fe74f02bbd61f2f27a59506aff98bf3ebf8942c90acb1d0521f898d71acb`.

**Verdict: PASS, conditional on the stated uniform terminal stability/norm contract and the imported source-average testing theorem. No mathematical correction is required.** This is an independent paper audit, not formal verification, a neural realization certificate, or a novelty certification. The candidate was not edited.

## 1. Reviewed material and conventions

The candidate, `LOCAL_MEMORY_ADAPTIVE_READS.candidate.v3.md`, its exact v3 audit, `../source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md`, and its v2 audit were read in full. Relevant normalized resource and global-continuation sections of `../normalized_stationary_frontier_20261105/NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md` were also inspected.

Communication is interpreted in the imported source-average theorem's standard binary protocol-tree convention, with padding permitted. Thus a cost-C message has conditional entropy at most C bits. An uncharged variable-string length or termination signal is not permitted. This convention is particularly relevant to the exact constant in the INDEX inequality. The external entropy-tensorization theorem behind the source-average lower remains an imported dependency; no primary-source re-verification was performed.

## 2. Finite branching and consistent conditional inputs

Alice sends her own anchor bits, followed by one fixed-format summary table for every possible Bob anchor assignment. She knows each full conditional anchor tuple while constructing the corresponding branch. Bob needs to send nothing: he selects his true branch after receiving the message. Hence the protocol is genuinely one-way and source-independent.

An Alice anchor row is evaluated only at its already fixed anchor symbol. An Alice nonanchor row is disjoint from all Bob anchors, so its actual token and every enumerated Bob-anchor assignment have a consistent complete raw history. The same property holds for every row evaluated on the selected branch. Original all-history bounds therefore control each evaluated local bank entry; no norm guarantee on inconsistent anchor/token pairs is needed. Conditioning does not imply a new probabilistic independence assumption.

Uniform budgets across anchor assignments give one precision schedule and branch length. The inherited uniform-query summary bound consequently yields the factor 2^(s_B), with s_A bits charged separately. Sending all owned raw symbols provides the safe N cap. H=0 needs only Alice's anchor bits. Public queries after fixing anchors support exponent one in each separate branch, even when different branches have different queries. The two-way comparison is correct but cannot be substituted into the one-way statistical argument.

## 3. Separable lifting, adaptive queries, and self contribution

The lifted key dimension is r_k k and lifted value dimension r_v d. Their bounds are the stipulated stacked-vector bounds, not r_k or r_v independent per-coordinate bounds. The query Q=a(z) tensor q has norm at most A_k R_q and exactly reproduces each original nonterminal score. Uniform polynomial approximation over this entire query ball permits adaptive q without changing the fact that every transmitted moment is token-local and independent of z.

A direct mixed-bank proof avoids any need to decompose the synthetic terminal self entry. Form lifted nonterminal augmented moments, contract the value numerator by b(z), retain their denominator, and then add the original self numerator and denominator computed at the same simulated terminal state. The joint numerator/denominator error grows by at most max(A_v,1) under contraction. The nonterminal Taylor tail and quantization error have constants controlled by R_*, V_*, A_k, A_v, and the declared ranks. They remain independent of N and polynomial degree.

The true complete denominator is still the original full-prefix denominator, bounded below by exp(-R_q R_k), including its original self term. The true complete value average has the original radius V. Thus the inherited ratio estimate and projection to the original answer ball apply. Perturbation propagation compares to the original exact conditional terminal map, whose uniform projected stage stability is assumed; no artificial neural computation of the lifted representation is required. Degree and precision of order D+log(1/epsilon)+1 yield exactly the exponent r_k k+1 and factor H(r_v d+1) in (S). Constants may depend on all displayed decomposition resources.

Knowing z only at Bob does not allow Alice to precompute one exact weighted sum for an arbitrary z-dependent public query. The candidate correctly withholds the exponent-one shortcut in that setting. Finite dictionaries or branching can supply other bounds, but are not tacitly assumed here.

## 4. Statistical inference and changing resources

Worst-history simulation implies the imported source-average guarantee under every relevant source. With epsilon=r, the hypothesis becomes 0<2r<=1/128 and the lower becomes 4r^2 min(C+1,N)>=1/(16384 ln 2). Since actual cost is at most C_upper, monotonicity yields exactly (R). This remains valid if the exact raw-history fallback is selected, since its error is zero and the sample cap remains N. The horizon N>=3 is explicitly retained.

With fixed anchors, ranks, dimensions, and all norm/stability budgets, the inherited advertised-envelope inversion works: the additive anchor cost is constant, and the polynomial degree in D is fixed. For changing s, ranks, or decomposition bounds, those quantities cannot be discarded from C_upper or its constant. The text appropriately keeps (R) as the safe conclusion and does not infer a logarithmic risk term from depth alone without a resource relation. The stationary interior restriction changes constants by restricting the testing amplitude, not the communication construction.

## 5. IID INDEX, randomness, and exact scope

The payload and address can occupy disjoint Alice/Bob positions in a sufficiently long AA/BB split under the homogeneous fair IID source. Unused Alice symbols may influence Alice's message but are independent of the address and Bob's unused symbols. Alice private coins are independent as well. Therefore J is independent of (U,M,R), and Bob's unused symbols and private coins give no additional payload information conditional on (M,R,J).

A wrong threshold decision costs at least 1/4 in TV. Thus epsilon<=1/16 gives average bit error at most 1/4. For each fixed index i, replace the possibly randomized decoder by the Bayes-optimal decoder based on (M,R). Its error p_i is no larger than the original conditional error and at most 1/2. Binary Fano, conditional entropy subadditivity, and concavity/monotonicity of binary entropy on [0,1/2] give

    H(U|M,R) <= sum_i h_2(p_i) <= n h_2(1/4).

Public coins are independent of U, so H(U|R)=n. With the inherited protocol-tree convention, I(U;M|R)<=H(M|R)<=C even when Alice randomizes. This proves (I). Bob randomization cannot improve on the optimal decoder. The interactive s+1-bit upper is also correct.

The INDEX family establishes hardness for abstract anchored dependence and a scalar real encoding of its address. It does not establish a fixed-norm, fixed-depth, bounded-gain causal neural realization. In particular, conditional selection and subsequent aggregation/amplification cannot be supplied as free operations. The text explicitly preserves these obligations and does not confuse the example's fair-source prediction risk 1/4 with a vanishing-risk prediction counterexample. It consequently does not resolve general risk-scale source-average compression.

## 6. Causality and evidence boundary

An earlier causal row cannot depend on a future anchor unless that nominal dependence cancels identically. Anchor-external information can enter through softmax scores and denominators even when the corresponding values are zero. The candidate explicitly records both constraints, and requires actual network computation and distribution of anchor information within paid depth. A semantic dependence certificate is sufficient here; verbal head names, a count of nonterminal invocations, or scalar state dimension are not certificates.

The accepted result is a conditional extension of token locality, not the unrestricted repeated-self-attention frontier. Only local text inspection, a checksum, paper derivation, and writing this audit were performed. No scientific script, numerical experiment, model evaluation, upload, or external mutation was performed.
