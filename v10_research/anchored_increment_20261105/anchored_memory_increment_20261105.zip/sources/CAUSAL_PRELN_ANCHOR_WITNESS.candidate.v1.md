# An explicit causal PreLN intersection witness for anchored memory

Private analytical candidate v1, 5 November 2026 UTC. Frozen for independent paper review. This is a concrete nonempty-intersection witness with two genuinely useful attention invocations, not a useful minimax predictor or an extension of the one-use frontier. No scientific program, numerical check, model run, parameter-generation code, upload, or public mutation was performed.

## 1. Exact model and result

For every N>=3, set T=N+1 and P=2^ceil(log2 T). There is an exact-real causal PreLN Transformer with:

- only raw binary symbol onehots and public position t/P, plus a zero-symbol synthetic row T;
- width 16, FFN hidden width at most one per block, one physical scalar-value head;
- three standard PreLN blocks, with exactly two useful full-prefix inclusive softmax invocations;
- full-feature LN(h)=2(h-mean(h)1)/sqrt(1+||h-mean(h)1||^2/16), including all anchors and scratch;
- a counted final full-feature LN, ordinary affine two-symbol head, and ordinary vocabulary softmax;
- one finite frozen norm/Lipschitz tuple independent of N and all histories;
- counted depth 7: embedding, three blocks, final LN, affine head, vocabulary softmax.

Its second useful invocation reads nonterminal banks that depend genuinely on both x_i and anchor x_1. Every such bank depends on no other raw token. Both useful invocations affect the actual terminal probability output. The anchor set S={1} therefore satisfies the accepted anchored-memory condition, and the network lies in the genuine normalized raw-token causal model with repeated attention permitted.

This is not a PostLN construction. It is not in the at-most-one-useful-invocation subclass of the earlier normalized frontier. Exact membership in the enlarged repeated PreLN model is established directly, not by assuming that a one-head compiler extends to multiple heads.

## 2. Paired physical coordinates and embedding

Use eight physical coordinate pairs with scalar names

    (a,p,s0,s1,g,r,b,o).

A scalar y occupies the physical pair (y,-y). Thus every row is exactly mean zero, and every LN scales every scalar by the same positive factor

    lambda(h)=2/sqrt(1+||h||^2/16).

Embed raw input into

    a=1, p=t/P, (s0,s1)=raw binary onehot, g=r=b=o=0.

At the synthetic row s0=s1=0. The embedding is one bounded affine map, with no sample-dependent feature beyond the original onehot. In paired states ||h||^2=2 sum y^2. Initially ||h||^2<=6, so lambda<=2 and is bounded below by a fixed positive constant. Pairs remain exact because every residual output below is paired; there is no cancellation error in exact-real semantics.

Extracting a named scalar after LN means taking its positive physical coordinate. All attention/FFN maps specified below are ordinary linear matrices on physical coordinates. No ratio, custom normalization, hard mask, position lookup, or uncounted nonlinear operation is used.

## 3. Block 1: an exact paid anchor gate

Set its attention output identically zero; its mandatory PreLN operations are still evaluated. Let tau=3/(2P). Its one-ReLU FFN writes only to the initially zero g pair:

    g := ReLU((tau-1)LN(h)_a - LN(h)_p + LN(h)_s1).

This is a standard W2 ReLU(W1 LN(h)+b1)+b2 residual update, with b1=b2=0 and W2 writing the positive and negative copies into g. Since LN supplies one common positive factor,

    g_t=lambda(h_t) ReLU(tau-t/P+s1_t-1).

For N>=3 and P>=4 this is positive exactly when t=1 and x_1=1. In that case

    g_1=lambda(h_1)/(2P),   0<g_1<=1/P.

Every other row, including the synthetic row, has g_t=0 exactly. The gate uses a tiny coefficient tau rather than a huge slope. Its amplitude is correspondingly small; no free gain or sharp classification is hidden. All gating work is paid in this first block.

## 4. Block 2: first useful causal head and a local interaction gate

Set W_Q=W_K=0, so every full-prefix coefficient is exactly 1/t. Let W_V extract LN(h)_g and let W_O put one quarter of the resulting scalar into the r pair. The residual state u then has

    r_t=v_1/(4t),   v_1=LN(h_1)_g,

because only row 1 has nonzero g. We have 0<=v_1<=2/P and hence 0<=r_t<=1/(2P)<=1/8. All other scalar registers are unchanged.

The same block's one-ReLU FFN writes only to the initially zero b pair:

    b_t=ReLU(LN(u_t)_r+LN(u_t)_s1-LN(u_t)_a)
       =lambda(u_t) ReLU(r_t+s1_t-1).

Consequently b_t=lambda(u_t)r_t for observed token x_t=1, and b_t=0 for token x_t=0 and for the synthetic row. This gate is exact because r_t<1. It is ordinary positionwise computation, not token multiplication inserted as an extra primitive.

After this block, every row i depends only on its original token x_i, public position, and x_1. This is causally valid since the sole anchor is the first row. At row 2, changing x_1 changes r_2. For x_1=1, changing x_2 from 0 to 1 changes b_2 from zero to strictly positive. This is a genuine nonterminal update, not merely feedback to the terminal row.

## 5. Block 3: second useful read and ordinary output

Again set W_Q=W_K=0. Let W_V extract LN(h)_b and W_O put one quarter of the uniform causal average into the initially zero o pair. Set the FFN output identically zero. At the terminal row,

    o_T=(1/(4T)) sum_(i=1)^T LN(h_i)_b.

All summands are nonnegative, and the synthetic summand is zero. Apply the required final full-feature LN to h_T and form ordinary affine logits

    z0=-LN(h_T)_o, z1=LN(h_T)_o.

Then apply ordinary binary softmax. These are counted operations with fixed bounded matrices.

Both useful heads are necessary for this particular computation: zeroing the first head makes r=b=o=0, and zeroing the second makes o=0. Either change produces the constant fair output.

The actual output also depends nontrivially on a nonanchor token. Fix x_1=1 and all tokens except x_2. Before the second head, changing x_2 preserves the squared norm of its original onehot rails. At row 2 it changes b_2 from zero to a positive value; LN(h_2)_b thus changes from zero to positive. Other rows before the second head are unchanged, because their only nonlocal dependence is x_1. Therefore o_T strictly increases. At T all registers other than o remain fixed between the two histories. The function o -> 2o/sqrt(C+o^2/8), with C>0 fixed for that comparison, is strictly increasing. The final logit gap and softmax probability of symbol 1 therefore strictly increase.

If x_1=0, the complete output is fair regardless of all other tokens. This proves genuine anchor-token interaction in the realized terminal function, not just a syntactic dependency that cancels in the output.

## 6. Uniform resource ledger

Width is exactly 16 physical features. Query/key/value dimensions are one. Hidden FFN width is one in each nonzero FFN, and zero-output FFNs can be implemented with one inactive hidden unit. Two useful scalar heads share the same physical head slot across layers.

Bounds on all histories and physical rows:

    0<=g<=1/P<=1/4,
    0<=r<=1/(2P)<=1/8,
    0<=b<=2r<=1/P<=1/4,
    0<=LN(h)_b<=2b<=2/P,
    0<=o<=1/(2P)<=1/8.

Every complete residual/pre-normalization state therefore has squared norm at most

    2[1+1+1+(1/4)^2+(1/8)^2+(1/4)^2+(1/8)^2] < 7.

The bound also covers intermediate u states, omitting not-yet-written rails. Thus raw complete state norms are below 3, and all LN output norms below 6. All scalar attention values are at most 1/2. Each full FFN hidden vector has one coordinate and is at most 1/4. Query/key norms and score spans are zero.

Embedding spectral norm is at most sqrt(2), and its full bias norm is sqrt(2). Gate W1 norms are at most sqrt(3), gate W2 norms sqrt(2), attention output matrices have norm sqrt(2)/4, attention value matrices norm one, and final affine-head matrix norm sqrt(2). All other biases are zero. One scalar budget 8 bounds these norms and all displayed state/value/logit vectors. Global LN Lipschitz is 2. For example, 16 is a conservative frozen bound for each local residual/FFN Lipschitz gain; zero-score averaging has its usual bounded causal linear mixing. No bound on the entire composed network is imposed for free.

The only N-dependent coefficient is tau=3/(2P), with O(log N) bits of rational description. No execution-precision or floating-point guarantee follows. Dense evaluation of the two useful heads costs O(N^2) real operations; positionwise work is O(N), and rolling state uses O(N) real slots. Evaluating the dummy head densely changes only the constant in the same O(N^2) total. The three blocks and all output operations are explicitly counted in depth 7.

## 7. Communication interpretation and statistical limitation

This is an actual normalized causal member of the anchored class with s=1, H=2, D=7. The first bank is token-local; the second bank has exact dependency (x_i,x_1). Under the AA/BB split anchor position 1 is Alice-owned, so s_A=1 and s_B=0. The anchored theorem gives a single-branch one-way simulation after Alice sends x_1; no exponential enumeration is needed. The relevant conditional maps are public once x_1 is known. This claim uses only the anchor theorem; no finite-separable algebraic rank is inferred through the nonlinear LNs.

The signal is deliberately small. From the bounds above,

    LN(h_i)_b <= 4r_i = v_1/i <= 2/(P i),
    o_T <= H_N/(2PT),

where H_N=sum_(i=1)^N 1/i. The final probability shift from 1/2 is at most o_T because sigmoid has derivative at most 1/4 and the logit gap is at most 4o_T. Hence the output tends uniformly to the fair distribution, at rate O(log N/N^2).

On the deterministic all-zero source the anchor gate is zero and the predicted distribution is exactly fair, while the true next symbol is zero. Its risk is exactly 1/2 on that source. Therefore this network does not provide a low-risk upper, a rate improvement, a matching anchored construction, or evidence that boundedly many anchors suffice for second-order estimation.

The content of the witness is precise: the anchored class has a nontrivial intersection with the original raw-token bounded-norm causal PreLN model, even with two useful attentions and genuine nonterminal history dependence. This does not imply a nontrivial statistical frontier inside that intersection.

## 8. Prior work and scope of the claim

Read local dependencies:

- NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md in ../normalized_stationary_frontier_20261105/: exact PreLN syntax, shared LN constants, global primitive stability and paid standard output convention.
- MATCHING_ORDER.v2.md in ../logdepth_matching_private_20261104/: original raw-token/public-position contract, full-prefix inclusive masks and resource accounting.
- ANCHORED_MEMORY_EXTENSION.candidate.v1.md and INDEPENDENT_ANCHORED_MEMORY_AUDIT.v1.md in this directory: the accepted conditional dependency theorem and its causal caveats.
- ALLROW_SINGLE_INVOCATION_PRIMARY_COMPARISON.v1.md in ../closest_literature_comparison_20261105_0157/: recorded primary-source comparison of bounded attention, local selectors and representation obstructions.

Positionwise ReLU selectors, uniform softmax aggregation, paired-coordinate normalization control, and small bounded-attention influences are existing ingredients in this project and the cited literature. Hahn (2020), https://aclanthology.org/2020.tacl-1.11/, is an established bounded-attention sensitivity antecedent. The present small-signal construction is fully consistent with that phenomenon. It does not claim a new copying mechanism, a sharp normalized construction, or novelty. No new live literature search was undertaken; the derivation is self-contained and uses the existing checked primary-source record.

No global-token mask, uncharged anchor tags, input-side lags, external decoder, future-to-past broadcast, or compiler generalization is used. The exact construction and ledger are the deliverable; no experiment or training result is implied.
