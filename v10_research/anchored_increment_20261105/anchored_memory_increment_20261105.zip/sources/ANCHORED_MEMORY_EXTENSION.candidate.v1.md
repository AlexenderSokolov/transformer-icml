# Anchored and finite-separable memory: controlled relaxations of token locality

Private analytical candidate v1, 5 November 2026 UTC. Frozen for independent paper review. Extends the accepted LOCAL_MEMORY_ADAPTIVE_READS.candidate.v3.md; its audit is INDEPENDENT_ADAPTIVE_READS_AUDIT.v3.md. No scientific executable, numerical test, model run, upload, or external mutation was performed. All results below are conditional structural statements, not a theorem for arbitrary evolving causal self-attention.

## 1. The dependency condition, including causality

Fix a public set S of s raw-token positions, called anchors. For a public Alice/Bob split let s_A and s_B be the numbers of anchors owned by each party. The binary anchor tuple is Z=X_S. At each of H useful terminal reads, require every nonterminal K/V bank to have the form

    k_(j,i)=k_(j,i)(X_i,Z), v_(j,i)=v_(j,i)(X_i,Z).

Thus a nonterminal row may have undergone several nonlocal updates, but its entire nonlocal raw-input dependence is contained in S. There is no separate history-dependent terminal input channel outside the H reads and the anchor-dependent local terminal computation. The latter may be evaluated exactly once Z is known.

All query/key/value full norm bounds, terminal stability, primitive accounting, exact-real semantics and probability output conventions are those of the accepted local-memory theorem. In particular H<=D and the decoder has fixed stage gains after proof-side norm projections. Conditioning on any anchor assignment must preserve these uniform budgets. The actual network must compute its own anchors and all row updates within its paid depth: the condition does not add supplied features to its input.

This is a semantic dependency condition that can be certified syntactically by dataflow. A sufficient syntactic check is that each useful nonterminal update reads only paths whose nonlocal raw-token dependencies belong to S. It is stronger than merely bounding the number of nonterminal attention invocations.

For a causal implementation, row i cannot actually depend on anchors after i. The notation using the full tuple is bookkeeping: dependence on future anchors must be absent, or cancel identically. A global summary broadcast backwards in time is NOT licensed. Full-prefix unmasked attention also does not automatically satisfy the condition: even zero nonanchor values can leave anchor-external information in the softmax denominator. One must trace both scores/denominators and values. The theorem applies only after this check, not because a head is verbally called an anchor head.

## 2. General anchor theorem: finite branching

For every epsilon in (0,1], one source-independent deterministic ONE-WAY protocol has worst-history simulation TV error at most epsilon and communication

    C <= min{N, s_A + 2^(s_B) K H(d+1)[D+log(1/epsilon)+1]^(k+1)},       (A)

for H>=1. For public queries AFTER fixing Z, replace exponent k+1 by one. Public fixed means no dependence on nonanchor raw data after conditioning; the fixed query may vary across anchor assignments. If H=0, sending the s_A Alice anchor bits suffices.

Proof: Alice first sends her anchor bits. For each of the 2^(s_B) candidate Bob anchor tuples, fix the full anchor assignment. All nonterminal K/V are now token-local, so Alice computes the summaries of the accepted theorem for that conditional model. She sends the summaries for every Bob assignment in a public order. Bob selects the branch matching his own anchor bits, adds his conditional partial moments, and simulates exactly as before. Correct-branch error is at most epsilon; other branches need not be accurate for the actual input. On the selected branch, every anchor symbol agrees with its assigned value. Uniform frozen budgets allow the same precision and bit allocation for all branches. Message construction and branch order are source-independent. If the displayed cost exceeds N, send all Alice raw symbols instead.

For completeness, a branch can contain inconsistency between a candidate Bob anchor and Alice's nonanchor row only if those positions overlap; they do not. Alice's own anchors are fixed first. Every evaluated conditional local row function therefore has a consistent completion, so original all-history norm budgets suffice. Exponential tables are computation-side protocol work, not a proposed efficient neural construction.

This permits arbitrarily many paid nonterminal updates preserving the anchor dependency set. It does not provide a polynomial-in-s bound. A two-way protocol could first send Bob's anchor bits to Alice and then only one summary, with cost s_A+s_B+the single-branch bound; this comparison is NOT usable with the binary one-way testing theorem.

## 3. Finite-separable anchor dependence avoids branch enumeration

A stronger algebraic certificate can be much cheaper. Suppose the nonterminal banks factor as

    k_(j,i)(x,z)=sum_(l=1)^(r_k) a_(j,l)(z) k_(j,i,l)(x),
    v_(j,i)(x,z)=sum_(l=1)^(r_v) b_(j,l)(z) v_(j,i,l)(x).

The coefficient functions a_j,b_j are common across rows. All local coefficient vectors are public functions of own token and position. Require uniform full-vector bounds

    ||a_j(z)||<=A_k, ||b_j(z)||<=A_v,
    ||(k_(j,i,l)(x))_l||<=R_*,
    ||(v_(j,i,l)(x))_l||<=V_*.

These are stacked-vector bounds, not per-coordinate replacements. Ranks and constants are declared resources. This is a finite separable dependence certificate, not matrix rank of one realized attention matrix. Also retain the original fixed-Lipschitz terminal trajectory assumptions.

Then for H>=1,

    C <= min{N, s_A + K_* H(r_v d+1)[D+log(1/epsilon)+1]^(r_k k+1)}.     (S)

K_* depends on the declared ranks and full-vector bounds, and on the accepted theorem's frozen stability constants. No dimension-uniform or polynomial-in-rank constant is claimed.

Proof: Alice sends her anchor bits, so Bob knows z exactly. Define token-local lifted key/value banks

    K_(j,i)(x)=(k_(j,i,l)(x))_l in R^(r_k k),
    V_(j,i)(x)=(v_(j,i,l)(x))_l in R^(r_v d).

Bob uses the adaptive lifted query Q_j=a_j(z) tensor q_j. Its norm is at most A_k R_q, and

    Q_j dot K_(j,i) = q_j dot k_(j,i)(x,z).

The softmax denominator is unchanged. Contract the lifted weighted-average value by b_j(z) to recover the original value average, with operator norm at most A_v. Apply the accepted uniform polynomial-moment construction to the local lifted banks; Bob handles the original synthetic self contribution separately, so it need not have a decomposition. Equivalently, use the lifted moments only for nonterminal numerator/denominator, contract the numerator by b_j(z), then add the original self numerator/denominator. Original denominator positivity gives ratio stability. The extra fixed contraction changes constants but not the precision order. All moments are independent of z and can be sent in one message, even though Alice does not know Bob's anchors.

There is no requirement that a_j or b_j be efficiently invertible. They are evaluated by the communication-side decoder once z is known. The actual network remains subject to paid-depth restrictions and causal availability. Uniform norm control of the lifted decomposition is essential: a formally low-rank representation with exploding coefficient norms does not give (S) with fixed constants.

If queries are public after conditioning on z but take arbitrary z-dependent values, that does NOT in general give the exponent-one shortcut without branching or a public finite dictionary. Alice cannot form a single exact exponential-weighted sum at an unknown q(z). The lifted uniform polynomial construction is the correct bound in (S).

For fixed s and ranks, this is a genuine extension of token locality without changing the qualitative polynomial-in-depth communication form. If s grows but ranks and all displayed bounds remain fixed, (S) charges the Alice anchor bits linearly and retains fixed polynomial exponent. An affine dependence on anchor signs gives an elementary certificate by including the constant coefficient and one coefficient per anchor, but then r_k and r_v can grow with s and must remain visible.

## 4. Statistical consequence: preserve all changing resources

For N>=3 and advertised worst-source binary prediction risk r with 0<2r<=1/128, set epsilon=r in (A) or (S). The accepted source-average theorem yields

    4 r^2 min(C_upper(r)+1,N) >= 1/(16384 ln 2),           (R)

where C_upper(r) is the displayed non-minimized branch or separable upper. This follows because the actual protocol cost is at most C_upper, and its worst-history simulation guarantee implies its source-average guarantee. If the full-history fallback is selected, it has zero error and still meets the advertised epsilon.

For fixed anchor count and fixed ranks, the corresponding inverse-polynomial depth-risk conclusions follow by exactly the advertised-envelope inversion in the accepted local-memory theorem. For nonconstant s or ranks, (R), with their actual dependence, is the safe conclusion. In particular 2^(s_B) cannot be silently absorbed in a constant, and no claim that log(1/r)=O(log D) is allowed without a corresponding resource relation. The stationary interior restriction is available by shrinking the testing amplitude as in the accepted theorem; the statistical horizon remains N>=3.

## 5. Why low-dimensional summary alone is insufficient: an exact abstract counterexample

This section concerns the dependency condition alone, NOT a constructed raw-token causal transformer and NOT a uniformly low-risk predictor. It demonstrates that finite anchor dependence or a scalar summary cannot justify replacing the exponential factor in (A) by polynomial(s) without further structure.

Let n=2^s. Alice has n independent fair payload bits U_1,...,U_n. Bob has s independent fair anchor bits defining J uniform on {1,...,n}. Any additional Bob observations and unused Alice bits are independent fair bits and give no relevant information. All of this can be embedded in the AA/BB ownership pattern under the homogeneous fair IID binary source by reserving enough positions for Alice payload and Bob anchors; unused positions remain IID. Set

    Q_U,J=(3/4,1/4) if U_J=0, and (1/4,3/4) if U_J=1.

This function is an anchored-memory dependency: conditioned on J, each row needs only its own token and the anchor tuple to contribute its selected bit. A one-dimensional real summary z=J/n contains the whole anchor tuple. Merely counting its scalar dimension therefore says nothing about its information content or stability budget.

Suppose any randomized one-way protocol outputs a probability vector Qhat with expected TV(Qhat,Q)<=epsilon under this one IID source. Threshold its first coordinate at 1/2. On a wrong bit decision, TV error is at least 1/4, so average decoding error p_e<=4epsilon. For epsilon<=1/16, p_e<=1/4.

Write R for public coins and M for Alice's at-most-C-bit message. Bob's unused bits are independent of U,M,R,J and can serve only as private randomness. Since J is independent of U,M,R, the average per-coordinate decoding errors p_i obey n^(-1)sum p_i<=1/4. Binary Fano and entropy subadditivity give, in bits,

    H(U|M,R) <= sum_i H(U_i|M,R)
                <= sum_i h_2(p_i)
                <= n h_2(1/4).

If a supplied decoder has p_i>1/2, replace it for analysis by the optimal decoder, whose error is at most min(p_i,1/2); this only strengthens the average bound. Consequently

    C >= I(U;M|R) >= n[1-h_2(1/4)].                       (I)

Private randomness at Alice does not change H(M|R)<=C; randomized output at Bob cannot beat optimal decoding. Hence even IID-average one-way simulation requires Omega(2^s) bits for this abstract family. The same function has an O(s+1)-bit interactive protocol: Bob sends J and Alice returns U_J.

This is the standard random-access/INDEX information argument, included in full, not claimed as new. It does not contradict (S): the selected-bit bank does not possess a fixed-rank uniformly bounded separable certificate of the required kind merely because J/n is one scalar. It also does not establish a lower bound for a constant-depth normalized transformer. An actual realization would need to generate and causally distribute the anchor information, compute selection with bounded primitive gains, and pay for terminal amplification. Those obligations are deliberately not assumed away.

Under the fair IID source this Q has prediction risk 1/4 relative to the fair next-symbol law, so it is expressly not the missing low-risk counterexample. No conclusion about general vanishing-risk source-average compression follows from it.

## 6. Provenance and exact remaining gap

The token-local theorem and its exact audit are in this directory. Its Sections 3-4 already verify uniform polynomial kernel summaries, adaptive-query error propagation and normalization. Those steps are reused here, not rediscovered. The source-average testing dependency is ../source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md and its accepted audit. The earlier README.v3.md in that directory identifies the unrestricted missing step. The normalized contract is ../normalized_stationary_frontier_20261105/NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md.

The existing primary-literature comparison ../closest_literature_comparison_20261105_0157/ALLROW_SINGLE_INVOCATION_PRIMARY_COMPARISON.v1.md records polynomial attention-summary precedents, including Alman and Song (2023), https://arxiv.org/html/2302.13214v1, and Chen et al. (2026), https://arxiv.org/html/2606.07205v1. No new live literature search or novelty certification was performed. Finite branching, separable lifting and the explicit INDEX information proof are elementary reductions; this manuscript claims their local scope and accounting, not novelty of those ingredients.

The unsolved task remains: certify a small dependency tuple or uniformly bounded separable representation for useful evolving nonterminal banks of general full-prefix causal self-attention, or prove an appropriate source-average alternative directly. A small count of nonterminal updates, a fixed state dimension, bounded scores, or one scalar global summary does not by itself provide such a certificate. The present note neither proves nor disproves the desired general architecture-controlled risk-scale bound.
