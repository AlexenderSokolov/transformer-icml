# Reviewed local-memory and anchored-memory simulation results

5 November 2026 UTC. Restricted structural results only; the general repeated full-row self-attention frontier remains open.

## Accepted exact artifacts

1. LOCAL_MEMORY_ADAPTIVE_READS.candidate.v3.md. Audit: INDEPENDENT_ADAPTIVE_READS_AUDIT.v3.md, PASS. SHA256: 18a9be386641c2831e3f8cb7559c018a34451e7421772029fdf6005a5750c703.
2. ANCHORED_MEMORY_EXTENSION.candidate.v1.md. Audit: INDEPENDENT_ANCHORED_MEMORY_AUDIT.v1.md, PASS. SHA256: b805fe74f02bbd61f2f27a59506aff98bf3ebf8942c90acb1d0521f898d71acb.

Older candidates, audits, and READMEs remain preserved.

## Result 1: token-local banks, adaptive terminal reads

For H<=D reads into token-local nonterminal K/V banks with fixed bounded norms and key/value dimensions k,d, one-way worst-history simulation at error epsilon costs

    min{N, O(H(d+1)[D+log(1/epsilon)+1]^(k+1))}.

Public fixed queries reduce the exponent to one. Identical banks can reuse one moment summary. The accepted source-average theorem gives corresponding conditional risk lower bounds for N>=3. Uniform polynomial features, projected off-trajectory stability, and normalized simulator output are explicit.

## Result 2: anchor-conditioned nonlocal banks

Allow each nonterminal bank to depend on its own raw token plus s public raw-token anchor positions. With s_A anchors owned by Alice and s_B by Bob, arbitrary such dependence admits

    min{N, s_A+2^(s_B) times the single-branch summary cost}.

This allows many paid nonterminal updates provided their dependency set stays within the anchors. It does not assume a backward global broadcast: actual causal rows must be independent of future anchors, and scores/denominators as well as values must pass the dependency check.

A bounded finite-separable K/V decomposition of ranks r_k,r_v removes branch enumeration and gives

    min{N, s_A+O(H(r_v d+1)[D+log(1/epsilon)+1]^(r_k k+1))}.

All ranks and stacked-vector bounds are explicit resources. This is not a dimension-uniform estimate and not a rank bound on one realized attention matrix. For varying anchors/ranks the accepted manuscript retains the implicit risk inequality instead of hiding their costs in constants.

## Boundary result

An elementary IID INDEX construction shows that the anchor-dependency condition alone, or encoding its index in one scalar, cannot justify replacing the exponential branching dependence by polynomial(s): expected one-way simulation needs Omega(2^s) bits at fixed error. The argument includes public/private coins.

This is an abstract dependency counterexample, not an implemented bounded-depth causal transformer. Its fair-IID prediction risk is 1/4, not vanishing risk. No general low-risk source-average obstruction follows from it.

## Limits and provenance

No claim of logically minimal conditions, sharp adaptive-query exponent, matching normalized anchor construction, general finite-update theorem, unrestricted self-attention frontier, or novelty certification is made. Mandatory nonlinear normalization can break a proposed low-rank algebraic certificate even when anchor dependence survives; verify each claimed certificate rather than infer it from width.

Polynomial summary machinery and statistical testing are attributed to earlier local accepted work and its recorded primary-literature comparison. Work comprised paper derivation, source reading, local documents, and documentary hashes only. No scientific program, model execution, upload, or public repository mutation occurred.
