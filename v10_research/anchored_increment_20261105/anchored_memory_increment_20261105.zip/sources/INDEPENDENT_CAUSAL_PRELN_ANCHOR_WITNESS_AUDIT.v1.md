# Independent exact-file audit: causal PreLN anchored witness

5 November 2026 UTC. New analytical review; the candidate and earlier status record are preserved unchanged.

## Verdict and binding

**PASS for the explicit nonempty structural intersection, with no mathematical revision required.** The candidate implements an actual causal, full-feature, positive-epsilon PreLN network with two useful attention invocations and genuine anchor-dependent nonterminal memory. It does not establish a low-risk predictor, a statistical frontier, or a result for general repeated self-attention.

Exact reviewed source: `CAUSAL_PRELN_ANCHOR_WITNESS.candidate.v1.md`.

SHA-256: `1ff194ebc9faad5dd8513efb84863df764277e42906c632b8def9edb35b9d43c`.

This reviewer did not author the candidate. The full candidate, anchored-memory theorem and its audit, and local-memory theorem v3 and its audit were read. The displayed matrices, gates, normalization, dependence, output monotonicity, and norm/depth ledger were checked on paper. The earlier `CAUSAL_WITNESS_STATUS.v1.md` accurately records the prior pending state; this new review supplies the subsequently completed independent examination without rewriting that history.

Only source reading, paper derivation, file-integrity hashing, and writing this new local review were performed. No scientific program, numerical assertion run, parameter generation, model execution, training, upload, or public mutation was performed. This is not formal verification, external peer review, finite-execution certification, or a novelty assessment.

## 1. Ordinary PreLN syntax and the raw interface

Eight sign-paired scalars give exactly 16 physical coordinates. The raw embedding creates pairs for the public position and the two raw onehot coordinates, a constant anchor pair (1,-1), and zero scratch. It is a bounded affine map of the allowed input, not a supplied lag, context, anchor-symbol tag, or sample-dependent preprocessing channel.

All residual injections preserve sign pairing, so the complete feature mean is exactly zero on the exact trajectory. Full-feature LN with epsilon one and scalar gain two therefore scales all scalar registers by the same positive lambda=2/sqrt(1+||h||^2/16). Every physical coordinate, including scratch, enters the norm. There is no masked normalization or division by an anchor.

Each nonzero FFN uses one affine form, one ReLU, and a paired output injection. The destination is zero before its unique write, so the displayed assignment is exactly a standard residual update. FFN biases are zero. The three blocks retain both mandatory PreLN branch-input normalizations, including zero-output branches. The last block's zero FFN does not alter the residual state; its normalization is still evaluated as a branch input.

The construction has one scalar query/key/value head slot in each block, used usefully in blocks 2 and 3. It is outside an at-most-one-useful-invocation class even though it has only one head per layer. All attention masks are the full inclusive causal prefix, including self, without special anchor masking.

## 2. The first gate is exact and paid

For P>=4, tau=3/(2P). At a real row whose symbol is one, the unnormalized gate argument is tau-t/P=(3/2-t)/P. It equals 1/(2P)>0 at t=1 and is strictly negative for every integer t>=2. For symbol zero the argument is smaller by one and is negative at every real row. The synthetic zero-symbol row also has a negative argument.

Positive homogeneity of ReLU under the common row LN factor therefore yields exactly

    g_1=lambda(h_1)/(2P) if x_1=1,
    g_t=0 otherwise.

No large slope or discontinuous classifier is inserted. The input coefficients remain bounded while the positive signal shrinks with P. This pays for the selective computation in the first standard block and is compatible with the fixed-resource contract.

## 3. Both useful heads are causal and the second bank is anchored

All queries and keys are zero, so every eligible prefix weight is exactly 1/t. In block 2 only row 1 has a possibly nonzero value v_1=LN(h_1)_g. The paired output projection scaled by one quarter gives

    r_t=v_1/(4t), 0<=r_t<=1/(2P)<=1/8.

Because scores are identically zero, neither scores nor the normalizing denominator carry hidden information from other rows. A zero g at a nonanchor row stays a zero attention value regardless of the other coordinates used in that row's LN.

The same block's FFN has unnormalized scalar argument r_t+s1_t-1. Since r_t<1, its ReLU is r_t when the observed symbol is one and zero when the symbol is zero or the row is synthetic. Thus b_t=lambda(u_t)r_t exactly on one-symbol rows and zero otherwise.

Before the second useful invocation, the complete state at row i is a function only of public position, x_i, and x_1. No future symbol is involved because the sole anchor is the first row. For each nonanchor i>=2, its second-read value can depend genuinely on both variables: x_1=0 makes it zero for either own token, while x_1=1 and x_i=1 make it positive, and x_i=0 makes it zero. Keys remain constant; the genuine two-variable dependence is in the value bank. At row 1 the own token and anchor are the same raw variable, as they should be.

The second invocation subsequently updates all rows, and those later nonterminal states can contain wider prefix dependence. That is harmless for this membership claim: there is no later useful read of those states, and only the synthetic terminal is externally read. The relevant anchored condition concerns the banks entering each useful read, not an assertion that every later unused state remains anchored forever.

## 4. Real terminal softmax and noncancellation

The third block writes the positive scalar

    o_T=(1/(4T)) sum_(i=1)^T LN(h_i)_b

into a previously zero paired bank. The synthetic summand is zero. A counted final full-feature LN, the affine logits z0=-LN(h_T)_o and z1=LN(h_T)_o, and actual vocabulary softmax produce a strictly positive normalized binary output on every history.

Deleting the first useful output makes r=b=o=0, while deleting the second useful output makes o=0. Either deletion therefore gives identically equal logits and fair output. Conversely, an anchor-one history has a positive contribution from row 1 and hence a nonfair output. Both invocations affect the realized terminal function.

For strict nonanchor dependence, fix x_1=1 and all symbols other than x_2. Changing x_2 changes no row before the second read except row 2: its original onehot squared norm is preserved, r_2 is unchanged, and b_2 changes from zero to positive. Its second-read value consequently changes from zero to positive. Thus o_T strictly increases. Every other terminal register is fixed between these histories. The final scalar map is

    f(o)=2o/sqrt(C+o^2/8), C>0,
    f'(o)=2C/(C+o^2/8)^(3/2)>0.

The final logit gap and symbol-one probability strictly increase. If x_1=0, every history instead gives exactly fair output. These facts verify actual anchor/own-token interaction, not merely syntactic wiring that cancels before output.

## 5. Width, depth, full norms, and stability

The layer count is literal: embedding + three complete blocks + final LN + affine head + vocabulary softmax = seven counted stages. No selector, decoder, repair, or deeper MLP is hidden inside one FFN. Model width is 16, hidden FFN width is at most one, and query/key/value dimensions are one.

For the raw paired registers, a=1, p<=1, and s0^2+s1^2<=1. The remaining bounds are g<=1/4, r<=1/8, b<=1/4, o<=1/8. Hence

    ||h||^2 <= 2[3+1/16+1/64+1/16+1/64]=101/16<7.

This includes intermediate attention-residual states by omitting rails not yet written. Complete reached model/pre-LN norms are below three, LN output norms below six, useful scalar value norms at most one half, and activated one-coordinate FFN hidden norms at most one quarter. Signed FFN preactivations are also bounded: the first is at most four in absolute value and the second at most two, so the scalar norm budget eight covers them as well. The one-quarter hidden claim is interpreted as the usual post-ReLU hidden activation, not as an absolute bound on a negative preactivation.

The embedding has spectral norm sqrt(2) and full bias norm sqrt(2). Each gate input matrix has norm at most sqrt(3), paired gate output has norm sqrt(2), each useful output projection has norm sqrt(2)/4, each value selector has norm one, and the final vocabulary matrix has norm sqrt(2). Other biases are zero. These are full-vector/operator bounds rather than coordinatewise substitutes. All score spans and query/key norms are zero. A scalar budget eight therefore covers the claimed states, matrices, biases, values, and logits.

Off the exact paired trajectory, standard gain-two positive-epsilon LN remains globally 2-Lipschitz. Each residual FFN has global gain at most 1+2sqrt(6). In max-row Euclidean norm, the zero-score attention-residual map has global gain at most 1+sqrt(2)/2, since uniform causal averaging is nonexpansive in that norm. Their product is below 16. Thus even a full useful attention-plus-FFN block admits a fixed global gain below 16; the candidate's conservative local stability allowance is sufficient. Final LN, affine head, and binary softmax have fixed global gains too.

Proof-side Euclidean projections in the imported simulator are nonexpansive and fix the exact bounded trajectory. They therefore do not create a stability gap on perturbed states. No unbounded bilinear score issue arises here because both query and key maps are exactly zero. The only length-dependent learned coefficient is the bounded tau-derived gate coefficient, whose rational description has O(log N) bits. This is not a guarantee of finite-word evaluation reliability.

## 6. Exact intersection with the anchored theorem

Take S={1}. At the first useful read, nonterminal K/V are token-local. At the second, they are functions of (x_i,x_1), with no additional raw-token dependence. Terminal computation has no separate history-dependent input outside the two reads and the allowed anchor-dependent local state. The physical construction computes and distributes the anchor information itself; the condition supplies no extra neural input.

The uniform norm and projected terminal-stage stability hypotheses hold under either anchor assignment by the explicit bounds above. Queries are public zero vectors even before conditioning. Under the AA/BB split, position 1 is Alice-owned, so s_A=1, s_B=0. After Alice sends x_1, one conditional token-local branch suffices. There is no exponential Bob-anchor table and no unproved finite-separable-rank claim through LN.

Accordingly this is an actual member of the anchored-memory class with s=1, H=2, and the stated block-depth convention D=7. If the imported theorem instead counts every shallow primitive separately, D changes only by a fixed constant factor; membership and all fixed-resource conclusions are unchanged. The communication theorem remains conditional on its stated assumptions and its imported proof chain; this audit independently verifies those architectural hypotheses for this particular witness, not the full general communication or statistical theorem anew.

## 7. Small signal and statistical limits

The candidate's bounds give LN(h_i)_b<=4r_i=v_1/i<=2/(Pi), hence

    o_T<=H_N/(2PT).

The final logit gap is at most 4o_T. Binary sigmoid has derivative at most one quarter, giving a probability shift at most o_T. Therefore the output converges uniformly to the fair law at O(log N/N^2).

On the deterministic all-zero source the prediction is exactly fair and risk is one half, as claimed. An additional scope check holds even within every fixed interior P_c with c<1/2: all outputs have symbol-one probability at least one half, so the stationary IID source p(1)=c incurs TV risk at least 1/2-c at every N. Thus this witness cannot be used as a vanishing-risk upper even after an interior restriction.

The accepted content is solely a nonempty causal normalized intersection with genuine nonterminal anchor dependence and two useful attentions. It establishes neither general anchored prediction sufficiency nor compression of arbitrary evolving self-attention. It provides no new rate frontier, matching low-risk construction, PostLN result, arbitrary compiler extension, finite-execution evidence, or novelty certification.

## 8. Source bindings and imported scope

Fresh bindings for the central sources read in this audit:

- `ANCHORED_MEMORY_EXTENSION.candidate.v1.md`: `b805fe74f02bbd61f2f27a59506aff98bf3ebf8942c90acb1d0521f898d71acb`.
- `INDEPENDENT_ANCHORED_MEMORY_AUDIT.v1.md`: `4b0bcaeed443e7fa2346935f254ef2410a258e46119915eee76bae66dd10bd29`.
- `LOCAL_MEMORY_ADAPTIVE_READS.candidate.v3.md`: `18a9be386641c2831e3f8cb7559c018a34451e7421772029fdf6005a5750c703`.
- `INDEPENDENT_ADAPTIVE_READS_AUDIT.v3.md`: `954d6a8199a2004521e06066268b593ee8f4724fbff6668dd7c0b06a89155e15`.

The current candidate digest matches its preserved pending-status digest. The anchored and local-memory source digests match their existing exact-version reviews. The normalized PreLN/raw-token contracts were also previously reviewed by this reviewer at `NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md` hash `624219c736392dc9fc755f9d6e32e33b40cf13005436589b85df0a6e4ac90770` and `MATCHING_ORDER.v2.md` hash `518cb4544ed227bfdb1e808c5d685a669a0d7ba6fe81632e847175af024eb82a`; the present construction was checked directly against their relevant syntax rather than importing a compiler.

The prior-literature record is `../closest_literature_comparison_20261105_0157/ALLROW_SINGLE_INVOCATION_PRIMARY_COMPARISON.v1.md`, current hash `06082575cdd04e92ce3bf53c76347f9cf7c61bed204ba0b144e19d1e5e36f0be`. Its bibliographic conclusions and underlying primary publications were not independently rechecked in this review. The constructive algebra above does not rely on a novelty or literature-priority assertion.

No new independent proof of the source-average testing theorem or its external entropy-tensorization dependency is claimed. Neither is needed to establish the explicit causal network's structural membership or the directly calculated risk counterexamples in this review. Later edits require a fresh exact-file review; any scientific execution remains subject to its separate pre-run and complete-capture requirements.
