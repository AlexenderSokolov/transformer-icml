# Source-independent task simulation by cancelling the quadratic nuisance

6 November 2026 UTC. Private analytical candidate v1, frozen for independent exact-file review. This is a structure-specific task-risk theorem, not a general simulator for repeated-attention networks and not a new estimator or statistical rate. No scientific executable, numerical diagnostic, model execution, training, upload, or public mutation was performed. The finite word certificates below are derived symbolically. File inspection, writing, and hashes are administrative only. No literature-priority claim is made.

## 1. Result and the distinction it establishes

The reviewed quadratic-nuisance construction has a source-independent reference output whose first probability is

    Q_ref(1 | x) = sigmoid(d(s) + rho(2F(x)-1)),
    s = x_(N-b+1:N),
    F(x) = sum_(odd k <= N) x_k sum_(j<k) x_j  (mod 2).       (1)

Here N is divisible by four, b is a power of two with 4<=b<=N/2, rho>0 is public, and the public function d depends only on the final b raw symbols. The source kernel is not an input to d. The actual physical network satisfies

    sup_x TV(Q_phys(x),Q_ref(x)) <= zeta_h.                  (2)

Define one deterministic source-independent task predictor by averaging the two branch probability vectors, not their logits:

    q_sym(1 | s) = [sigmoid(d(s)+rho)+sigmoid(d(s)-rho)]/2,
    q_sym(0 | s) = 1-q_sym(1 | s).                         (3)

For every homogeneous binary second-order source whose two next-bit probabilities at every context are at least c>0, and for every initial-pair law separately,

    R_P(q_sym) <= R_P(Q_ref) + (rho/4) B_(N,b,c),
    R_P(q_sym) <= R_P(Q_phys) + zeta_h + (rho/4) B_(N,b,c), (4)

where R_P is expected next-symbol total-variation loss on the same history, and either of the following explicit bounds is valid:

    B8 = (1-2c^8)^floor((N-b-2)/8),
    B5 = (1-2c^5)^floor((N-b-2)/5),
    B_(N,b,c) = min(B8,B5).                                (5)

The eight-symbol certificate is the proposed route. A shorter five-symbol certificate strengthens it and works in either starting time parity. Both proofs appear below. The constants are deliberately conservative; no optimal contraction rate is asserted.

Under the original AA/BB ownership, Bob obtains the full suffix when Alice sends her suffix bits. This costs exactly b/2 bits for the displayed N,b domain, and at most b bits without using the alignment. He then evaluates (3) locally. This is a task simulator: it nearly preserves the original predictor's statistical risk, but need not approximate its output. In fact, for the reviewed nuisance amplitude and logit interval, its distance from that output is of order rho on every history.

There is also a replacement inside the same neural model, rather than merely a communication protocol. Let q_0(1 | s)=sigmoid(d(s)). The existing one-read suffix reference, with the same bounded-log circuit and a separately correct PreLN compilation, gives a one-useful-scalar-head physical predictor Q_base with uniform error zeta_b from q_0 and

    R_P(Q_base) <= R_P(Q_phys)
                   + zeta_h + zeta_b
                   + (rho/4) B_(N,b,c) + rho^2/8.         (6)

For b=Theta(log N), rho=Theta(b^(-1/2)), and zeta_h,zeta_b=O_c(b^(-2)), the excess in (6) is O_c(b^(-1))=o(rho). The old hard predictor has worst-source risk Theta_c(rho), so this old one-head baseline is no worse than (1+o(1)) times that worst-source risk. No source-wise multiplicative comparison is asserted: the lower risk bound used for this ratio holds for the worst-source risk, via fair IID, rather than for every source individually.

Thus the known output-simulation obstruction survives while a cheap, architecture-contained task replacement is certified. The certification uses the explicit nuisance structure and source positivity, not an assumed risk/depth lower bound.

## 2. Source, input, target, and risk contract

Fix c in (0,1/2). Let M_c be the family of all laws with arbitrary initial-pair distribution mu on {0,1}^2 and a homogeneous order-two kernel p satisfying

    c <= p(y | a,b) <= 1-c

for every a,b,y in {0,1}. The stationary interior class P_c from the prior nuisance theorem is a subclass. Here initial-pair probabilities may be zero, and no mixing or stationary initial law is assumed.

The raw input is the actual length-N sample X. No communication-specific encoding is inserted. The next-symbol target on history x is

    tau_p(x) = p(. | x_(N-1),x_N).

Because b>=2, this target is a function of the retained suffix s for each fixed p. Its value is unknown to the task predictor, and neither p nor mu is supplied to the simulator or network.

For a possibly randomized prediction rule A, define

    R_(p,mu)(A) = E_X E_U TV(A(X,U), tau_p(X)),             (7)

where U is independent predictor randomness and TV is inside both expectations. The construction (3) is deterministic. Sampling one of its two branches would be a different prediction rule under (7), and would not obtain the Jensen improvement claimed here.

The phase and cancellation proofs only need N-b>=2 and b>=2. The more restrictive N=4n and power-of-two b are retained when importing the reviewed network and its AA/BB communication lower. Nothing in the cancellation step uses stationarity. The old suffix statistical guarantee itself holds for arbitrary initial-pair laws, so its standard O(b^(-1/2)) upper can also be used on M_c; the all-history physical approximation is independent of the sample law.

## 3. Signed state recursion

All parities in this section are in F_2. For t>=2 let

    S_t = sum_(j<=t) X_j (mod 2),
    F_t = sum_(odd k <= t) X_k sum_(j<k) X_j (mod 2),
    A_t = (X_(t-1),X_t,S_t) in {0,1}^3.

The eight-state signed row vector

    v_t(a) = E[(-1)^F_t 1{A_t=a}]                         (8)

has l1 norm at most one. At t=2, F_2=0 and S_2 is determined by the initial pair, so in fact ||v_2||_1=1 for every mu.

When a new bit y is appended after time t, the state and phase updates are

    (a,b,s) -> (b,y,s+y),
    F_(t+1)-F_t = 1{t+1 is odd} y s.                     (9)

The probability of this transition is p(y | a,b). Thus the one-step signed kernel K_t has entries

    K_t((a,b,s),(b,y,s+y))
        = p(y | a,b) (-1)^[1{t+1 odd} y s],              (10)

and zero elsewhere. If destinations ever coincide their contributions are summed; for the one-step binary update the two destinations are distinct. Equation (9), the order-two Markov property, and conditioning on the present state give

    v_(t+1) = v_t K_t.

Every row has absolute sum one, so ||v K_t||_1<=||v||_1 for any signed row vector v. The same holds for any product of one-step kernels. The prefix parity S_t is essential: conditioning on the last pair alone would not determine the future contribution to F.

For a fixed length-l future word w=(w_1,...,w_l), its phase increment from a start with prefix parity s is

    Delta_(t,s)(w)
      = sum_(j: t+j odd) w_j [s+sum_(i<j) w_i] (mod 2). (11)

Its endpoint state is determined by the old state and w. Because every transition probability is at least c, its conditional probability from every starting state is at least c^l. This remains true for starting states not reachable under a particular mu; those states can harmlessly be retained in the matrix norm bound.

## 4. The eight-symbol cancellation certificate

At an even starting time t, take the two future words

    w  = 00110000,
    w' = 00011000.                                      (12)

Both end in the last pair 00, both contain two ones, and therefore both end in state (0,0,s), independently of the starting pair. In w the ones occupy local positions 3 and 4. Its only odd-position one is at position 3, with no preceding one, so

    Delta_(t,s)(w) = s.

In w' the ones occupy local positions 4 and 5. Its only odd-position one is at position 5, with exactly one preceding one, so

    Delta_(t,s)(w') = s+1.                              (13)

Their contributions to the same signed-kernel entry have opposite signs. Each path has probability at least c^8.

For completeness, at an odd starting time the selected local positions are even. Then w contributes s+1 and w' contributes s. Thus the cancellation actually works in either starting phase, although the eight-step blocks starting at 2+8j are all even and need only (13).

Let K be the signed eight-step kernel from any one block. Fix a starting state a. All 2^8 path masses sum to one before signs. If the two paths in (12) have probabilities alpha,beta, replace their signed contributions at their common destination by their sum, whose absolute value is |alpha-beta|. Apply the triangle inequality to every remaining contribution. Therefore

    sum_z |K(a,z)|
        <= 1-alpha-beta+|alpha-beta|
         = 1-2 min(alpha,beta)
        <= 1-2c^8 = gamma8.                            (14)

Additional cancellations can only decrease this bound. For every signed row vector,

    ||v K||_1 <= gamma8 ||v||_1.                         (15)

Put t_*=N-b and k8=floor((t_*-2)/8). Starting at time 2, apply k8 complete eight-step blocks and then the fewer than eight remaining one-step kernels. The latter are nonexpansive. Consequently

    ||v_(t_*)||_1 <= gamma8^k8 = B8.                    (16)

This is a signed-phase cancellation estimate, not merely an ordinary Markov-context mixing estimate.

## 5. A five-symbol improvement

A shorter certificate uses

    u  = 11000,
    u' = 01100.                                        (17)

Again both words have two ones, both end in pair 00, and both end in the same full state (0,0,s). If t is even, the selected local positions are 1,3,5. Word u contributes s at its first position; word u' contributes s+1 at its third position. If t is odd, the selected positions are 2,4. Word u contributes s+1 at its second position, whereas u' contributes s there. In both cases the increments differ by one, independently of the starting pair and s.

Each path probability is at least c^5. The argument in (14) now gives row absolute sum at most

    gamma5 = 1-2c^5.                                    (18)

A five-step block flips the time parity, so its signed kernel need not be the same as the preceding block's kernel. This causes no problem: each of the two phase-specific kernels obeys the same induced-l1 contraction bound. A product of k5=floor((N-b-2)/5) such kernels, followed by fewer than five nonexpansive steps, gives

    ||v_(N-b)||_1 <= gamma5^k5 = B5.                    (19)

The proof does not incorrectly identify these alternating matrices as a single time-homogeneous signed kernel. Taking the smaller of the two independently established bounds yields (5).

## 6. Retaining the full suffix without losing the estimate

A bound on the unconditional phase mean alone would not be enough, because the baseline and target depend on the suffix. The needed quantity is the average absolute conditional phase bias.

For each suffix word z in {0,1}^b, let H_z be the signed kernel that appends exactly z after time t_*=N-b, including its full contribution to F. From each starting state there is one deterministic state path for that fixed word. Its nonzero signed entry has absolute value equal to that word's conditional probability. Hence for every starting state a,

    sum_z sum_e |H_z(a,e)| = 1.                         (20)

Let

    B(z) = E[(-1)^F_N 1{X_(N-b+1:N)=z}].

Tracking the signed mass through the specified suffix gives

    B(z) = v_(t_*) H_z 1.

Using (20) and the triangle inequality,

    sum_z |B(z)|
      <= sum_z ||v_(t_*) H_z||_1
      <= ||v_(t_*)||_1
      <= B_(N,b,c).                                    (21)

For every positive-probability suffix define beta(z)=E[(-1)^F | suffix=z]. Set beta arbitrarily on null suffixes, which contribute nothing. Equation (21) is exactly

    E_suffix |beta(suffix)| <= B_(N,b,c).              (22)

This is an average over suffixes. It does not assert the same bound for every individual suffix, and no division by a possibly tiny suffix probability is used. In the present positive-transition class every suffix has positive probability once enough transitions precede it, but that observation is unnecessary for the proof or the null-event convention.

The argument accounts for every term of F, including terms involving one prefix bit and one suffix bit. Those terms are handled by the retained S_t state and the signs in H_z. Simply dropping the suffix's phase contribution would be invalid.

## 7. Convex loss comparison, with all constants

For a fixed suffix z, write

    a_+(z)=sigmoid(d(z)+rho),
    a_-(z)=sigmoid(d(z)-rho),
    m(z)=(a_+(z)+a_-(z))/2,
    p_z=p(1 | final pair of z),
    L_+(z)=|a_+(z)-p_z|,
    L_-(z)=|a_-(z)-p_z|.

Since (-1)^F is +1 on F=0 and -1 on F=1,

    Pr(F=1 | z)=(1-beta(z))/2,
    Pr(F=0 | z)=(1+beta(z))/2.

The reference conditional risk is therefore

    E[|Q_ref(1)-p_z| | z]
      = (L_+(z)+L_-(z))/2
        + beta(z)(L_-(z)-L_+(z))/2.                    (23)

Convexity of absolute value gives

    |m(z)-p_z| <= (L_+(z)+L_-(z))/2.

The reverse triangle inequality and sigmoid derivative bound give

    |L_+(z)-L_-(z)| <= a_+(z)-a_-(z) <= rho/2.          (24)

Combining these inequalities,

    |m(z)-p_z|
      <= E[|Q_ref(1)-p_z| | z] + (rho/4)|beta(z)|.

Averaging and applying (22) proves the first inequality in (4). In fact the proof establishes the slightly sharper source-specific bound

    R_P(q_sym)-R_P(Q_ref)
       <= (1/2) sum_z |B(z)| [a_+(z)-a_-(z)].           (25)

Since TV between binary distributions equals the absolute difference of their first probabilities, the notation in (7) agrees exactly with these calculations. Finally (2) and the triangle inequality yield

    R_P(Q_ref) <= R_P(Q_phys)+zeta_h,

which proves the second inequality in (4). All these statements hold for each p,mu separately with the same function q_sym; taking a supremum over any chosen source subclass preserves them.

### General two-branch form

The decision-theoretic step does not depend on logits. Suppose a target tau_P is measurable with respect to a retained statistic Z, and Q(x) selects either of two source-independent probability vectors A_+(Z), A_-(Z) according to a sign variable. If

    E_P |E_P[sign | Z]| <= delta_P,

then the deterministic midpoint M(Z)=(A_+(Z)+A_-(Z))/2 satisfies

    R_P(M) <= R_P(Q)
               + (1/2) E_P[|E_P[sign | Z]|
                              TV(A_+(Z),A_-(Z))].     (26)

To prove it, apply convexity of TV and the reverse triangle inequality for a metric exactly as in (23)-(24). A uniform branch gap G gives excess at most G delta_P/2. This is a source-wise comparison for a source-independent map. A certifiable source-uniform bias bound, not knowledge of the actual source, is what makes it useful here.

A finite paired-path certificate is a sufficient way to obtain such a bias bound: augment the source context by the finite state needed to update the sign; exhibit, from every starting state and relevant time phase, two fixed-length positive-probability paths with the same augmented endpoint and opposite sign increment. If each path has probability at least a>0, every block contracts signed l1 mass by at most 1-2a. The explicit words above provide that certificate for this particular quadratic phase. This is not a claim that arbitrary nuisances have such a certificate.

## 8. Communication and local computation

Retain the original raw AA/BB split: Alice owns positions 4i-3,4i-2 and Bob owns 4i-1,4i. Public data include N,b,rho, the fixed baseline circuit and its coefficients; neither party is given p or mu.

1. Alice sends her bits in the final b positions, in their public order.
2. Bob interleaves them with his own suffix bits.
3. Bob evaluates the same public d(s), both sigmoid values, and their deterministic midpoint.

For b a power of two with b>=4 and N divisible by four, the suffix consists of complete ownership blocks. Alice sends exactly b/2 bits. The universal loose bound is b. The protocol is deterministic, one-way, and has this worst-case bit cost on every history. There is no free timing/silence channel, no exchange of a source estimate, and no communication of real-valued branch probabilities.

For the reviewed baseline d, Bob need not execute the full N-row physical network. Its LOGICAL suffix function can be evaluated by computing the eight triple counts and final pair from the b-bit suffix, applying the exact old count/readout rule, and evaluating the same public floor/log circuit. Equivalently he can evaluate the certified terminal suffix decoder; the source independence and exact equality to d come from the reference program, not from an assertion that the full-feature normalized physical baseline has exactly the same suffix dependence.

A direct counter implementation uses O(b) counter updates and O(log b) bits for each of a constant number of counters. The old bounded-log evaluator has O_c(b) exact-real primitive stages for its specified O_c(b^(-2)) tolerance. Thus one explicit local evaluation has O_c(b) exact-real arithmetic/ReLU work plus two sigmoid evaluations, assuming integer/readout arithmetic in the usual unit-cost local-computation model. The protocol can instead use the old paid restoring divider; its O(log^2 b) stages are included in O(b) for b>=4. Its input transfer is b/2 bits, independent of local arithmetic precision.

This exact-real local runtime is not a bit-complexity theorem for evaluating exp, LN, or arbitrary real circuit gates. Classical communication complexity does not charge local computation. If an implementable local evaluator returns q_sym within TV error eta on every suffix, its risk upper gains only eta and its bit communication does not change. No finite-arithmetic implementation or execution certificate is supplied here.

Although (3) is a short computation, it is an average of TWO softmax outputs. It has not itself been compiled into the frozen neural model with one ordinary final vocabulary softmax. The next section gives a different, genuine one-head model-contained replacement using the old baseline.

## 9. Same-model replacement by the old one-head baseline

### 9.1 The symmetric midpoint is close to the unperturbed sigmoid

Put q_0(1 | z)=sigmoid(d(z)). The elementary identities

    sigmoid'(u)=sigmoid(u)(1-sigmoid(u)),
    sigmoid''(u)=sigmoid'(u)(1-2sigmoid(u))

give |sigmoid''(u)|<=1/4 on the real line. Taylor's theorem with integral remainder, applied at d to both d+rho and d-rho, cancels the first derivative. Each remainder is at most rho^2/8 in absolute value, so their average satisfies

    |q_sym(1 | z)-q_0(1 | z)| <= rho^2/8.              (27)

Equivalently, each expansion has a remainder bounded by (1/2)(1/4)rho^2, and averaging the two remainders retains that bound. This is a global bound; no additional bounded-logit assumption is needed.

Combining (4) and (27),

    R_P(q_0) <= R_P(Q_phys)
                   +zeta_h+(rho/4)B_(N,b,c)+rho^2/8.  (28)

Averaging the LOGITS would give q_0, rather than q_sym. Equation (27) is the explicit second-order error that allows this substitution; they are not generally equal.

### 9.2 Compile the baseline reference, not two normalized physical branches

Use the old single-scalar-head suffix reference from CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md and append exactly the same public fixed-floor/log circuit used to define d in (1). Its terminal reference softmax is q_0. The logical program has fixed width, bounded complete states and full primitive norms, and O_c(log N+b) paid stages. The log tolerance is the nuisance construction's existing public tolerance, not a newly tightened value dependent on an uncharged simulator precision.

Apply the existing paired-register positive-epsilon PreLN/output compiler to THIS one-head reference. This is not literal deletion of banks from the old physical nuisance network: full-feature LN couples all banks, so a separate correct compilation with its own fixed full-state envelope is required. The relevant one-head calculation is the specialization of the reviewed uniform-head recurrence:

    z'_t = z_t+B(1/t)sum_(i<=t) A z_i,
    z'_t,phys = z_t+B(1/t)sum_(i<=t) A s(z_i)z_i,
    s(z)=(1+eta^2||z||^2/dim)^(-1/2).

On a common fixed state tube, local error is O_c(eta^2) for this read and for each local homogeneous overwrite. With L>=2 bounding every prepared-stage gain,

    e_j <= L e_(j-1)+C eta^2,
    e_m <= C' eta^2 L^m.                               (29)

Choose a desired dyadic zeta_b within a fixed factor of min{1/1000,1/(100b^2)}. Choose padding, full-vector, and restoration tolerances as largest admissible fixed dyadic multiples of zeta_b. Append ALL logit copies, norm-padding square/product/root stages, and scratch clears before defining the complete prepared length m. Choose a common tube and stage constants for the original baseline and its single-head ablation. Only then select the smallest integer M with eta=2^(-M) making (29) meet the full-vector tolerance. All original/ablated runs use identical eta, padding, restoration, and final affine head.

The inherited bounded radial restoration and ordinary final vocabulary head give

    sup_x TV(Q_base(x),q_0(suffix(x))) <= zeta_b.       (30)

Depth, per-coefficient description, and useful-head counts are

    W=O_c(1),   D=O_c(log N+b),
    one useful zero-score scalar-value full-prefix head,
    per-coefficient description O_c(log N+b),
    untied total parameter description O_c((log N+b)^2).

Every LN can use epsilon=1, gain=2, shift=0 through the already-reviewed exact gain reparameterization. All state/full-matrix/full-bias/primitive-gain bounds fit one sufficiently large fixed c-dependent envelope, independent of N,b. No containment in a smaller externally preassigned numerical envelope is asserted without a separate calculation. The raw binary input, public normalized positions, inclusive causal mask, synthetic terminal row, and conventional final vocabulary softmax are unchanged.

The head is genuinely useful. In the old all-symbol-2 suffix example the original count/readout and the head-ablated all-default readout have opposite endpoint probabilities. After flooring at a<=1/4 their exact normalized first probabilities differ by at least 1/2. Two log-approximation errors and two physical errors reduce this gap by at most 2 zeta_h+2 zeta_b, which is still strictly below 1/2 under the displayed tolerances. The common ablation compilation in the preceding paragraph is needed for this conclusion.

Equation (30) added to (28) proves (6). This uses the existing suffix algorithm and the existing output compiler; the new statement is their task-risk comparison against the nuisance network. It is not a new network architecture, statistical rate, normalization theorem, or claim that one read is necessary.

### 9.3 Physical work and precision remain visible

The one-head network has N+1 physical rows and O(N) rolling state at fixed width. Skipping identically zero dummy attention slots, its one dense useful head plus local stages cost O(N^2+ND); evaluating every dummy attention sublayer densely gives O(N^2 D). Constant width does not mean constant distributed memory or constant total computation.

Coefficient descriptions and exact-real primitive semantics are the same kind of guarantee as in the imported construction. Finite-precision execution, trained realization, parameter-generation runtime, and numerical stability are not supplied. The communication task predictor may use the logical q_0 directly with b/2 bits; no exact suffix-only dependency of the full-feature normalized physical Q_base is required for the model-contained risk comparison.

## 10. Coexistence with the linear output-simulation lower

In the main nuisance construction,

    rho = 2^(-ceil((log2 b)/2)),
    1/(2sqrt(b)) < rho <= 1/sqrt(b),
    zeta_h <= min{1/1000,1/(100b^2),kappa_c rho/100}.    (31)

The prior bounded logit interval has positive minimum sigmoid derivative kappa_c, so for every suffix

    a_+(z)-a_-(z) >= 2 kappa_c rho.                    (32)

Because q_sym is the exact midpoint, on EVERY history

    TV(q_sym,Q_ref) = [a_+(z)-a_-(z)]/2
                    in [kappa_c rho, rho/4].           (33)

Together with (2),

    TV(q_sym,Q_phys) >= kappa_c rho-zeta_h.             (34)

Thus the task predictor is deliberately not a close simulator at the old tolerance kappa_c rho/100, even though its risk is nearly no larger. These inequalities do not need the phase-mixing argument: the mixture midpoint lies equally far from its two branch outputs.

The prior fair-IID rectangle reduction remains unchanged. For any randomized interactive simulator approximating the COMPLETE physical output with mean TV at most kappa_c rho/100 and worst-case communication C,

    C+b >= (N/2-1)/2-2.                                (35)

The same source family contains fair IID, so widening the allowed initial-pair laws cannot invalidate that lower. The task predictor (3) and the baseline replacement (6) do not satisfy its output-approximation premise, and therefore do not contradict (35).

Taking b=Theta(log N), the prior worst-source hard-network risk obeys

    kappa_c rho/2 <= R_hard <= 200rho.

The old suffix arbitrary-initial guarantee and all-history physical comparison also give this order over M_c. For fixed c, (5) decreases exponentially in N-b, while the compiler tolerances in (31) are O_c(b^(-2)). Hence

    R_sym <= R_hard + O_c(b^(-2))
                         + O(rho exp(-a_c(N-b))),
    R_base <= R_hard + O_c(b^(-1))
                         + O(rho exp(-a_c(N-b)))       (36)

for an explicit possible a_c>0, e.g. a_c=-(1/5)log(1-2c^5), after absorbing the fixed floor/initial-two-symbol factor into the leading constant. Dividing by R_hard>=kappa_c rho/2 gives a vanishing relative excess for both replacements.

The exponential term belongs to the logical comparison. The physical comparison also contains zeta_h, and for the one-head replacement zeta_b and rho^2/8. It would be wrong to call the whole physical excess exponentially small at the original logarithmic-depth tolerances. Exponentially tightening physical output precision would require recharging the compiler's depth and coefficient description.

## 11. What this proves, and what remains open

1. A source-independent, explicit suffix predictor has nearly no larger risk than this particular hard-output predictor, uniformly over all positive order-two kernels and arbitrary initial-pair laws. It uses no source-specific conditional expectation in its definition.
2. The finite cancellation certificate is structural and checkable. The exact words and phase calculations, rather than a desired statistical rate or a generic risk-scale simulation equivalence, certify the comparison.
3. Task simulation can be much cheaper than whole-output simulation under the SAME raw input ownership and source class. The communication upper is O(b); the old sufficiently accurate output-simulation lower is Omega(N).
4. A nearby one-head physical suffix network in the same positive-epsilon PreLN/ordinary-softmax model is an asymptotically equal-risk task replacement for the known hard family. It is the old estimator, not an improved estimation method.
5. The statement is not universal over low-risk networks. It assumes a specific suffix-dependent two-branch decomposition and a certifiable phase-bias decay. No theorem that arbitrary evolving-memory networks admit such a decomposition is supplied.
6. An average absolute conditional-bias estimate is sufficient for expected risk; a pointwise conditional-bias estimate has NOT been proved. The source's transition lower bound c controls the contraction. For c tending to zero, these constants need not give useful decay on the displayed horizon.
7. The midpoint is deterministic. Randomly selecting a branch, comparing only unconditional marginal output laws, or moving TV outside the predictor-randomness expectation changes the task and does not prove (4).
8. This note does not close the general fixed-width risk/depth frontier, prove a new minimax lower or rate, preserve architecture under arbitrary Rao-Blackwellization, or certify finite-arithmetic execution. It does not transfer a worst-history encoded communication law to a Markov sample law.

## 12. Exact read dependencies and provenance

Primary read files and administrative SHA-256 bindings:

- ../nonlinear_statistical_frontier_20261106/IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md
  SHA-256: ef9ce668cd9815e45501194198177c7acdc369894a50e3b31aebb5baaa340767
  Supplies F, the suffix-only logical d, the physical uniform comparison, bounded logit interval, output-simulation lower, and hard-network risk/resource ledger. The phase-contraction proof here is new local analysis, not imported from that note.
- ../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md
  SHA-256: ea1c3788f4eed06ccba9e19db3ee0d9a3e792bda7d3d620c0326cc4a07cecbb6
  Supplies the old one-head bounded logical suffix estimator, its exact readout and arbitrary-initial risk guarantee.
- ../ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md
  Read for the complete-preparation-before-amplitude correction and the inherited physical output compiler; this note uses its explicit one-head specialization, not the two-read architecture.
- ../local_memory_adaptive_reads_20261105/LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md
  Read for the bounded serial-log extension, uniform-head small-amplitude recurrence, gain reparameterization and common-ablation requirement.
- UNIVERSAL_MARKOV_TYPE_PROJECTION.candidate.v1.md
  SHA-256: a67b7ef4f38334013c5f82728ce5e26ac9517df4229e2b9dee042853c952ffe6
  Read for the task-oriented source quantifiers and distinction from whole-output simulation. Its type-class averaging theorem is not used in the cancellation proof. In particular, the present cheap replacement does not require distributed acquisition of the full Markov type.

The INTERIOR_SOFTMAX v2 and STANDARD_PRELN v2 output routines cited by the reviewed compiler remain inherited dependencies. This file does not re-prove their norm-padding and radial-restoration lemmas. All new phase, suffix-channel, convex-risk, and midpoint-to-baseline claims are proved explicitly above. Independent review must separate those new claims from the imported neural-compiler guarantees.
