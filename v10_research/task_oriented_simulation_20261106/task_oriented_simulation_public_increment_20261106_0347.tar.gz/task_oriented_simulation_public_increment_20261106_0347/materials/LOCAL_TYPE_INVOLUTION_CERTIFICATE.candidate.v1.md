# A local type-preserving involution and a nonvacuous nuisance-exclusion certificate

6 November 2026 UTC. Candidate v1. Symbolic proof only, with no executable, experiment, training or upload. This complements the signed-kernel proof in SYMMETRIC_QUADRATIC_NUISANCE_REMOVAL v1. It does not overwrite that frozen source or claim a general statistical frontier.

## 1. Same process, retained suffix, and explicit rewrite

Use the reviewed nuisance reference Q_ref with first probability sigmoid(d(s)+rho(2F-1)), where s is the final b-bit suffix, b>=2, and F=sum_(odd k<=N) x_k sum_(j<k)x_j mod2. The target is the unknown homogeneous binary second-order next law at the actual terminal pair. For the imported physical family keep N divisible by four, b a power of two, 4<=b<=N/2. The physical comparison is sup_x TV(Q_hard(x),Q_ref(x))<=zeta_h.

Partition the first 8k raw symbols AFTER the initial pair into k disjoint blocks of length eight, where

 k=floor((N-b-2)/8).

Every such block lies entirely before the retained suffix. Let w=00110000 and w'=00011000. Their internal triple-count vectors agree: 001,011,110,100 occur once each, 000 occurs twice, and the other triples occur zero times. Both start with 00, end with 00, and contain two ones.

Let G be the event that at least one of these disjoint blocks is either w or w'. Define a deterministic map iota on all N-bit words: on G, interchange w and w' in the FIRST such block; on G complement, leave the word unchanged.

This is an involution. The selected block's membership in {w,w'} is unchanged, so the same block is selected on the second application. Earlier and later blocks are untouched. The initial pair and the complete final b-bit suffix are preserved.

## 2. Exact preservation of every homogeneous Markov law

Changing the selected block preserves all internal triple counts. The first two and last two block symbols are identical in w,w', so every triple crossing either boundary is also unchanged. Therefore the whole word's initial pair, eight triple counts and final pair are unchanged by iota.

For any homogeneous binary order-two kernel p and any initial law mu, including zero probabilities,

 P_(p,mu)(x)=mu(x_1,x_2) product_(a,b,c) p(c|a,b)^(C_abc(x))
           =P_(p,mu)(iota x).

Thus iota preserves EVERY source measure in this model, not merely a selected IID law. This equality uses homogeneity; it is not inferred merely from positivity. The signed-kernel proof separately gives a cancellation estimate without relying on equal word probabilities.

The selected block starts after an even time 2+8j. If the incoming prefix parity is S, w contributes S to F while w' contributes S+1. The two ones leave the outgoing prefix parity unchanged. Consequently later contributions to F are unchanged, and

 F(iota x)=F(x)+1 mod2 on G.

This is a full-history phase identity, not just a comparison of the block's isolated polynomial. The retained suffix, and hence d(s) and the true terminal context, remain unchanged.

## 3. Exact risk domination on rewrite orbits

Define the public source-independent predictor

 Q_orbit(x)=[Q_ref(x)+Q_ref(iota x)]/2.

For any fixed source, the target law is identical at x and iota x because their terminal pairs agree. Convexity of TV and source-measure preservation therefore give

 R_(p,mu)(Q_orbit) <= R_(p,mu)(Q_ref)

for every kernel and initial law separately. No risk envelope, unknown parameter, statistical rate lower, or source-specific conditional expectation is needed. This is a small explicit orbit projection, not averaging over an exponentially large full Markov type class.

On G, the two branches have opposite F and the same d, so Q_orbit equals the suffix-only midpoint q_sym. On G complement, iota is the identity and Q_orbit equals Q_ref. Thus

 TV(q_sym(x),Q_orbit(x)) <= (rho/4) 1_(G complement).

The factor follows from sigmoid's derivative bound: the gap of the two branches is at most rho/2, and the midpoint is half that gap from either branch.

If all transitions have both probabilities at least c>0, conditional on any past each next eight-bit block has probability at least c^8 of being w and at least c^8 of being w'. These are disjoint words. Repeated conditioning, without assuming independent blocks, gives

 P_(p,mu)(G complement) <= (1-2c^8)^k.

Therefore

 R_P(q_sym) <= R_P(Q_ref)+(rho/4)(1-2c^8)^k
             <= R_P(Q_hard)+zeta_h+(rho/4)(1-2c^8)^k.

This independently proves the eight-word part of the signed-state result. It also explains why task averaging can help while complete-output approximation stays hard: typical rewrite orbits contain both separated output branches, and their midpoint has no worse averaged loss even though it remains far from either original output.

Q_orbit itself is not claimed to be a cheap neural or communication implementation. It still evaluates the original reference on unmatched histories. The cheap task predictor is q_sym, which needs only the suffix and tolerates the explicitly bounded exceptional set. This distinction prevents moving an unproved expensive computation into the simulator.

## 4. A checkable restriction that excludes the specific nuisance

Consider the output-rewrite modulus

 J_N(Q)=sup_(x in G) TV(Q(x),Q(iota x)).

For fixed N this is a finite, precisely specified property of the complete input-output function. An explicit invariance proof or exhaustive finite evaluation can verify it; no efficient generic neural verifier is provided. Defining J_N is not a resource bound and computing it is not free.

Every LOGICAL suffix-only predictor has J_N=0, because iota fixes the suffix. In particular q_0=sigmoid(d(s)) is exactly invariant. A correctly compiled physical one-head baseline Q_base with uniform error zeta_b from q_0 obeys

 J_N(Q_base)<=2zeta_b.

This is approximate physical invariance, not an assertion that full-feature PreLN has exact suffix support.

For the hard reference, the bounded-logit derivative constant kappa_c gives on every x in G

 TV(Q_ref(x),Q_ref(iota x)) >=2kappa_c rho.

Hence the actual physical nuisance predictor satisfies

 J_N(Q_hard)>=2kappa_c rho-2zeta_h

whenever G is nonempty, as it is for k>=1. Indeed the same lower holds for each matched pair. For zeta_h,zeta_b=O_c(b^-2) and rho=Theta(b^-1/2), a declared tolerance delta_N=o(rho) satisfying delta_N>=2zeta_b includes the old physical one-head baseline but excludes this nuisance family for all sufficiently large N.

The constraint is therefore nonvacuous relative to the shared model: it retains an already-proved consistent predictor and rules out the specific phase perturbation. It is NOT a necessity theorem for statistically good predictors. Other nuisance functions can be invariant under this one rewrite, and invariance alone has not been proved to yield cheap communication, a source-average resource inequality, or a sharp statistical rate. It must not be advertised as the weakest possible useful constraint.

## 5. Scope, dependencies and retained failures

- Exact orbit-risk domination is asserted for Q_orbit versus Q_ref; the cheap q_sym comparison has an additive exceptional-event term, and the physical comparison adds zeta_h. Calling all of these exact domination would be false.
- The finite word identity requires a homogeneous order-two likelihood for source-measure preservation. The positive lower bound c is needed for the exponentially rare unmatched event; with c=0 the orbit identity remains valid but the displayed decay can be useless.
- Target invariance uses the preserved terminal suffix. The same argument would not follow for a target that changes along the rewrite orbit.
- The physical modulus is bounded through end-to-end approximation, not by assuming exact invariance of every normalized intermediate state.
- The source of the hard family and kappa_c comparison is IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md. The source of q_sym, its single-head physical replacement and the stronger five-word signed bound is SYMMETRIC_QUADRATIC_NUISANCE_REMOVAL.candidate.v1.md. Full-type sufficiency and its limitations are in UNIVERSAL_MARKOV_TYPE_PROJECTION.candidate.v1.md.
- No model run, finite-word execution, training, novelty certification or universal architecture-preserving Rao-Blackwell theorem is supplied.
