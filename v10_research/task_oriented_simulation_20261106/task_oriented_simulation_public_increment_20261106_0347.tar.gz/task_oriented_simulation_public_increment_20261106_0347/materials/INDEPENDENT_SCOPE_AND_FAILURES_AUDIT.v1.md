# Independent exact-file audit: scope and failed routes

6 November 2026 UTC. Symbolic/provenance review only. No scientific executable, experiment, model run, training, external literature retrieval, upload, or public mutation was performed in this review.

Reviewed source: `RESEARCH_SCOPE_AND_FAILED_ROUTES.v1.md`.

SHA-256: `742879ccfdcfd35e3cdd11aced408d8e074829e5514c883469e76f57160283d4`.

**ACCEPT.** The consolidated ledger accurately separates the new symbolic comparisons from inherited statistical and neural ingredients, and it does not upgrade them into a general frontier result.

## Material checks

- The old output-equivalence result remains the provenance for the anti-circularity warning. The task-only result's lambda=1 endpoint is an equivalence endpoint, not an already-proved cheap exact dominating replacement for arbitrary architectures.
- Full-type and local-orbit projections have exact sourcewise risk domination. Their acquisition/evaluation costs are not made free. The inexpensive q_sym and physical baseline retain explicit additive penalties.
- The type-statistic communication lower concerns specially encoded worst-case histories. It is not presented as a Markov- or IID-source-average lower.
- The signed-state proof controls the average absolute conditional bias given the entire suffix, rather than only an unconditional sign mean or a pointwise conditional bound.
- The deterministic midpoint and averaged logits differ by the explicitly bounded second-order term. Random branch selection would be a different expected-TV experiment.
- The phase penalty is exponential, while the physical approximation errors and rho^2/8 substitution term are not. The source correctly refuses to describe the entire physical risk discrepancy as exponentially small.
- The five-word certificate is not automatically type preserving. For example, from starting pair 01, appending 11000 generates triples `011,111,110,100,000`, while appending 01100 generates `010,101,011,110,100`. Their boundary-conditioned homogeneous likelihoods need not be equal. The signed proof needs only common augmented endpoint, opposite phase, and lower-bounded path probabilities. In contrast, the eight-word pair has matching initial/final pair and internal triple counts, validating the separate exact orbit proof.
- The approximate physical rewrite modulus uses two end-to-end approximation errors. It does not assert exact suffix-only dependence for the fully normalized network.
- The binary one-way task-testing lower and the IID interactive whole-output lower are different arguments. No interactive binary Markov task theorem is inferred by mixing them.
- The shared physical model statement is for a sufficiently large fixed c-dependent envelope containing both constructed families, not every previously imposed smaller numerical budget. The old one-head estimator, its paid local stages, and the inherited final-output compiler remain explicit.
- No new external retrieval or statistical-theory novelty claim is made. The statement retains the transitive entropy-tensorization and output-compiler dependencies; packaging the local notes is not represented as independently closing those proofs.

The open general task remains explicit: no theorem covers every low-risk fixed-width nonlinear-memory network, and no new optimum, better estimator, finite-precision realization, training result, mandatory PostLN extension, or generic automatic verifier is supplied. No blocking scope or provenance error was found.
