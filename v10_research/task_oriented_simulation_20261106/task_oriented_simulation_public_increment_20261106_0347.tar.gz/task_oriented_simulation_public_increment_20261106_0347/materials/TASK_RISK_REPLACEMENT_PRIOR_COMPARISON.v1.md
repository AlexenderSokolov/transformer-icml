# Exact comparison with the earlier risk-scale and evolving-memory results

6 November 2026 UTC. Local analytical provenance comparison for `TASK_RISK_REPLACEMENT_EQUIVALENCE.candidate.v1.md`. This is not an independent audit, a new external literature search, or a priority certification. No experiment or upload was performed.

## 1. The old output-simulation equivalence

Source: `../source_average_simulation_20261105/RISK_SCALE_SIMULATION_EQUIVALENCE.candidate.v1.md`.

The earlier property asks a source-independent one-way protocol to approximate the particular Q's output in source-average TV:

    sup_P E TV(Qhat,Q(X)) <= kappa r,  kappa>1,
    C<=K min(D+1,N), for every positive advertised r>=R(Q).

Its direct upper compares Q to a generic suffix estimator through the true next law. The original prediction risk consumes r of the error budget, leaving (kappa-1)r for the suffix estimator. This explains the strict kappa>1 assumption. If the certified suffix does not fit, the full word is sent and Q is evaluated exactly.

The old converse supplies a predictor of task risk at most (1+kappa)r and applies the one-way task-testing lower. The equivalence was written for the full homogeneous second-order binary source class and arbitrary initial pairs.

## 2. What changes in the task-only formulation

New property:

    sup_(P in P_c) E TV(Qhat,P_actual) <= lambda r,  lambda>=1,
    C<=K S, for every positive advertised r>=R(Q).

The source class is now explicitly the SAME fixed stationary interior binary P_c throughout, and S can be any public resource scale in [1,N]. S=min(D+1,N) is the important special case, not the only admissible one.

There is no requirement to reconstruct Q, its terminal output, or its hidden computation. The generic suffix estimator spends the entire lambda r on its own prediction task. In the full-word fallback, evaluating Q preserves risk r<=lambda r. Hence the endpoint lambda=1 is valid, with no division by lambda-1.

The converse applies testing directly at delta=lambda r, not delta=(1+lambda)r. Its explicit coefficient is

    a_c=(1/(2lambda)) min{ min(1/128,(1-2c)/8),
                          sqrt(1/[16384 ln(2)(K+1)]) }.

This coefficient is deliberately conservative. No sharp constant is claimed.

The important all-N fallback is retained. A suffix length chosen from the generic upper may exceed N even though the particular Q's advertised risk is feasible. Sending all of Q's raw input and evaluating Q handles that case; merely truncating the suffix estimator to N would not justify the requested risk envelope.

## 3. Different fidelity, but not a new constant-factor lower-bound shortcut

For any Q with R(Q)<=r, triangle inequality gives both conversions:

- Output approximation error at most kappa r implies task risk at most (1+kappa)r.
- Task risk at most lambda r implies source-average output approximation error at most (1+lambda)r.

These are supremum/expectation bounds for one source-independent protocol over the SAME source class. Consequently, at unspecified fixed constant multiples of r, the two kinds of communication theorem are mutually reducible. Task-only replacement removes unnecessary matching of Q's particular decisions, and allows the exact task-risk multiplier lambda=1 in the generic upper, but does not supply an independent architecture-controlled communication theorem.

The present proof is therefore a sharper formulation and anti-circularity check, not evidence that a generic suffix estimator has solved the repeated-attention frontier. Its O(r^(-2)) cost becomes O(S) only after using the target lower r>=a_c/sqrt(S). Conversely, a new structural O(S) task replacement would indeed prove that target.

For lambda<1 the stated fallback is insufficient: evaluating Q need not improve its risk. No equivalence for lambda<1 is claimed. There is likewise no conclusion about old output-simulation tolerance exactly r or smaller; the new lambda=1 task result gives output discrepancy at most 2r, not r.

## 4. The common interior class and the corrected witness amplitude

Sources:

- `../source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md`, Sections 3-5 and independent v2 audit.
- `../evolving_common_control_20261106/AVERAGE_DEFECT_TRANSFER.candidate.v3.md`, Section 3 and independent v3 audit.

The binary AA/BB test uses lag-two correlations theta=+h and -h, with h=8 delta. The older source-average statement imposed delta<=1/128 so h<=1/16. When its witnesses are restricted to the common interior class with row probabilities in [c,1-c], membership additionally requires h<=1-2c.

Therefore the direct task-testing lemma here explicitly imposes

    0<delta<=min{1/128,(1-2c)/8}.

This dependence matters as c approaches 1/2. The statement does not import an all-kernel lower as if it automatically held on every restricted source class. It exhibits the actual witnesses inside P_c. The add-one suffix upper, by contrast, restricts legitimately from a larger arbitrary-initial source class.

The direct testing proof retains public/private coins, actual-terminal-context recovery by one reserved bit, the common comparison measure, and the finite-sample cap min(C+1,N). Its information inequality is an imported reviewed statistical ingredient, not a newly proved contraction theorem.

## 5. Relation to the evolving-memory surrogate certificate

Sources:

- `../evolving_common_control_20261106/COMMON_CONTROL_SIMULATION.candidate.v2.md`.
- `../evolving_common_control_20261106/AVERAGE_DEFECT_TRANSFER.candidate.v3.md`.

The common-control theorem imposes a checkable fixed-lift factorization of all nonterminal K/V through a closed, reconstructible control state. A one-way moment summary then approximates the surrogate's output uniformly over raw histories. The defect transfer compares the actual and surrogate output with a source-average weighted error Delta, charging subsequent amplification.

Those are sufficient structural output-simulation conditions. A task-only approach could in principle bypass their need to reproduce the actual evolving rows or bound their output defects. It would instead have to build one source-independent communication-limited predictor with the required task risk. The new equivalence identifies the strength of that missing obligation; it does not produce it.

In particular, none of the following alone is supplied as a task-replacement certificate: constant hidden width, bounded scores, rank on one realized memory matrix, stationary mixing, small unweighted average row defect, or an attention trace known only after seeing the full word. Neither the common-control theorem nor the new equivalence certifies general evolving causal memory.

## 6. Per-source domination is not the minimax property

Per-source domination asks one replacement to satisfy

    risk(Q_s;P)<=R_Q(P) for every P in P_c.

It implies the minimax replacement guarantee, but the minimax guarantee for a chosen replacement does not imply it. The candidate's two constant forecasts c and 1-c have equal minimax risk 1-2c, yet each is worse at the other's exactly matched iid source. This is a same-class, source-independent, zero-communication counterexample to the reverse implication between guarantees.

The example is deliberately not described as an existential separation: the original constant forecast itself is a cheap dominating alternative. A theorem claiming that EVERY architecture member admits a cheap source-by-source dominating surrogate would need an additional proof; the present existential minimax equivalence does not establish it.

## 7. An important architecture sanity check: growing width

Source: `../logdepth_matching_private_20261104/MATCHING_ORDER.v2.md`, Sections 2-3, importing the reviewed wide add-one construction.

Under that frozen bounded-norm raw-token contract, the existing growing-width construction has counted depth O(log N), width O(N) for fixed binary alphabet, and worst-source risk O(N^(-1/2)). Restricting its source class to P_c preserves the upper.

Therefore, if C_index includes that growing-width family, the uniform assertion

    R(Q)>=a_c/sqrt(min(D+1,N))

is FALSE: O(N^(-1/2)) is asymptotically smaller than every fixed positive multiple of (log N)^(-1/2). By the new equivalence, a uniform one-way O(D+1) task-replacement theorem is also false for that broad class. Dropping output fidelity does not remove this counterexample.

The intended unresolved inverse-square-root depth target must therefore retain its fixed-width or other stated architectural restriction. The new theorem permits any class as a logical equivalence, but it does not make the lower true for every class. The already established logarithmic depth lower at fixed error is a different statement and remains consistent with the wide upper.

## 8. Source-known and interactive boundaries

A source-specific oracle protocol is excluded. On horizons divisible by four, Bob already owns the terminal pair, so supplying the kernel yields zero task risk with zero communication. The same-protocol-for-all-sources quantifier is essential even though the requested task fidelity is weak.

The information inequality used by the one-way proof cannot be applied to interactive transcripts. The checked local interactive reference is

    ../source_average_simulation_20261105/INTERACTIVE_IID_FALLBACK_AND_MARKOV_GAP.candidate.v2.md.

It imports Hadar, Liu, Polyanskiy and Shayevitz, *Communication Complexity of Estimating Correlations*, STOC 2019: https://doi.org/10.1145/3313276.3316332 and https://arxiv.org/abs/1901.09100 . That checked result covers iid binary-symmetric or Gaussian pairs. Its independent-coordinate tensorization does not by itself cover the interleaved binary lag-two Markov source used here. The separate four-symbol construction is not the same alphabet/source class. No new primary-source inspection was performed for this comparison, and no interactive binary theorem is asserted.

## 9. Scope of the increment

Established by this candidate, conditional on its imported reviewed ingredients and pending separate review of the written composition:

- Exact equivalence between the capped resource lower and source-independent one-way task replacement at every advertised risk envelope.
- Valid endpoint lambda=1, explicit uniform coefficients, and the necessary full-word fallback.
- A common stationary interior P_c throughout, with the corrected witness cutoff.
- The distinction from source-by-source domination, output simulation, source-known protocols, and interaction.
- An explicit guard against applying the fixed-width target to the already successful growing-width class.

Not established: an O(D) replacement for arbitrary fixed-width evolving causal attention, an unconditional new inverse-square-root risk theorem, per-source domination for general predictors, an interactive binary Markov lower, a new neural realization, training behavior, finite-precision performance, or novelty in statistical decision theory or communication complexity.
