# Independent exact-file audit: symmetric quadratic nuisance removal

6 November 2026 UTC. Independent skeptical paper review. No numerical experiment, mathematical search executable, source simulation, model run, training, upload, or public mutation was used. Reading, writing, and hashes are administrative. Author files were not edited.

## Reviewed file and verdict

`SYMMETRIC_QUADRATIC_NUISANCE_REMOVAL.candidate.v1.md`

SHA-256: `2ae96bbacc29eb53dd5657ed00dba5f342d6fb296810fb44f193e90d1f56d2a1`

**ACCEPT for its stated main-family scope.** The signed cancellation, full-suffix conditional-bias estimate, sourcewise additive risk comparison, AA/BB communication bound, and midpoint-to-baseline comparison are valid. The separate one-head physical replacement is a valid specialization of the explicitly imported compiler, with its preparation order and common ablation parameters retained. No general architecture-controlled task replacement or exact sourcewise domination theorem follows.

## 1. Phase, state, and initial-law checks

The phase in the reviewed hard reference is `F_t=sum_(odd k<=t) X_k sum_(j<k)X_j mod 2`. Its future update depends on the last two bits, running bit parity, and public time parity. The eight-state augmentation `A_t=(X_(t-1),X_t,S_t)` is therefore sufficient. At t=2, F_2=0 for every initial pair, so the signed vector has l1 norm exactly one even when mu has zero entries. No stationary initialization is needed.

For an appended word, the phase increment is `sum_(j:t+j odd) w_j(s+sum_(i<j)w_i) mod 2`, exactly as displayed. Each path of length l has probability at least c^l from every starting context. Uniform matrix bounds over unreachable augmented states are harmless.

The explicit phase certificates check as follows:

| Word pair | Starting time even | Starting time odd | Common endpoint |
| --- | --- | --- | --- |
| 00110000 / 00011000 | s / s+1 | s+1 / s | (0,0,s) |
| 11000 / 01100 | s / s+1 | s+1 / s | (0,0,s) |

The equal endpoints use both the common final pair 00 and the fact that each word has exactly two ones. An argument tracking only the source pair would not by itself justify the future phase calculation. The source correctly retains S_t.

## 2. Signed-kernel contraction

For two opposite-signed paths of masses alpha and beta to one endpoint, grouping those paths first and using triangle inequality for every remaining path gives row absolute sum at most `1-alpha-beta+|alpha-beta|=1-2min(alpha,beta)`. Thus the eight- and five-step factors `1-2c^8` and `1-2c^5` are correct. Equality of the two path probabilities is not required for this proof.

The five-step block flips time parity. The source correctly uses two possible phase-specific kernels, each with the same induced-l1 bound, instead of falsely treating the product as a single time-homogeneous signed kernel. Starting from t=2, taking the stated floor number of complete blocks and then fewer than one block of nonexpansive single steps yields the displayed B8 and B5. Taking their minimum is valid.

## 3. Full retained suffix and the actual target

For every fixed suffix z, its signed continuation kernel H_z includes all phase increments through the end of the word, including every prefix-suffix cross term. From each start state there is a unique path for z, and the sum over all suffix words of the absolute path masses is one. Hence

`sum_z |v_(N-b) H_z 1| <= ||v_(N-b)||_1`.

This is exactly `E_suffix |E[(-1)^F | suffix]|<=B`, after assigning arbitrary values on null suffix events. It is an expected absolute conditional-bias bound, not a pointwise bound for every suffix. No division by a small suffix probability occurs.

The prediction target is the transition law at the actual last pair. Since b>=2, that pair is determined by the retained suffix. Therefore conditioning on the suffix keeps the correct target fixed while applying Jensen. The same map q_sym works for every kernel and every initial law, rather than using a source-specific conditional expectation as its definition.

## 4. Risk comparison and constants

The source's sign convention is consistent: `(-1)^F=+1` selects F=0 and the negative-rho branch. Thus the conditional loss identity has the correction `beta(L_- - L_+)/2`, as written. Convexity of absolute value bounds the midpoint loss by the unweighted average of branch losses. Reverse triangle inequality bounds their loss difference by the branch TV gap. Since `sup sigmoid'=1/4`, that gap is at most rho/2, giving exactly the excess `(rho/4) E|beta|`.

The source-specific sharpened bound and general two-branch metric version are both valid. These require averaging probability vectors before evaluating TV. Random branch selection would retain the original average branch loss and would not give the same guarantee.

The uniform physical comparison loses zeta_h once when replacing reference risk by actual-network risk. No expectation or supremum exchange is used incorrectly. The resulting relation is additive almost-domination, not exact domination or a sourcewise multiplicative comparison.

The midpoint-to-unperturbed-sigmoid bound follows from `sup|sigmoid''|<=1/4`: each Taylor remainder is at most rho^2/8, and the first derivatives cancel. Averaging the two remainders retains, rather than doubles, this bound. Adding a separate physical baseline error zeta_b gives exactly the claimed sum in equation (6).

## 5. Communication and output-simulation separation

For N divisible by four and power-of-two b>=4, the final b symbols consist of complete AA/BB blocks. Alice owns exactly b/2 of them, so the displayed bit cost is correct. Bob's local calculation uses the same logical suffix d, not an assumed suffix-only physical PreLN trajectory. The unknown kernel and initial law are never supplied. Local exact-real evaluation and bit complexity are correctly distinguished.

The midpoint is not claimed to be a one-softmax neural output. The source explicitly keeps its communication-side evaluator separate from the separately compiled one-head baseline.

At the main construction's bounded logit range, the branch gap is at least `2 kappa_c rho`. The midpoint is therefore at distance at least `kappa_c rho` from either reference output on every history, and at least `kappa_c rho-zeta_h` from the physical hard output. Consequently the cheap task protocol does not meet the premise of the older small-error whole-output lower. That lower remains valid and is not contradicted.

## 6. Separate one-head compiler and asymptotic scope

The old one-head suffix reference has legal bounded states at every physical row and a valid all-default word under attention ablation. Appending the existing fixed-floor/log circuit preserves constant width and O_c(log N+b) paid depth. The one-uniform-head error formula is the direct specialization of the imported formula, with full-feature normalization included in the local O_c(eta^2) error.

The candidate includes all logit copies, padding primitives, and scratch clears before defining prepared length and choosing the small amplitude. It chooses one tube and one parameter set for the original baseline and its head ablation. The final radial-restoration/ordinary-softmax claim is therefore a valid use of the imported compiler rather than an unsupported deletion of banks from a normalized physical network.

The useful-head margin uses the old all-symbol-2 versus all-default example. Before log approximation, flooring at a<=1/4 preserves probability separation at least 1/2. The small log and physical errors leave a positive gap. In the **main IID nuisance construction**, the log-error tolerance and hard physical-error tolerance are the same zeta_h, so the written `2zeta_h+2zeta_b` margin is valid. This notation should not be transplanted unchanged to the older optional small-amplitude variant, which has a separate epsilon_log; in that variant the corresponding margin would use `2epsilon_log+2zeta_b`.

For fixed c, b=Theta(log N), rho=Theta(b^-1/2), and both physical errors O_c(b^-2), the midpoint penalty is O_c(b^-2) plus an exponentially small logical term, while the baseline penalty is O_c(b^-1) plus that term. The known fair-IID lower `R_hard>=kappa_c rho/2` makes both relative excesses vanish after taking worst-source risk. It does not imply a sourcewise multiplicative bound or exact lambda=1 replacement. The whole physical error is not exponentially small, and the candidate correctly says so.

## 7. Exact dependency bindings and remaining limits

Read inputs and relevant compiler passages:

- `../nonlinear_statistical_frontier_20261106/IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md`: SHA-256 `ef9ce668cd9815e45501194198177c7acdc369894a50e3b31aebb5baaa340767`.
- `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`: SHA-256 `ea1c3788f4eed06ccba9e19db3ee0d9a3e792bda7d3d620c0326cc4a07cecbb6`.
- `../ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md`: SHA-256 `a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2`.
- `../local_memory_adaptive_reads_20261105/LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md`: SHA-256 `d51e74e89a452411d6eb6ffd6ab393fc3417f95aaed75e8a10dd20f4a970b5cb`.

The core cancellation and decision-theoretic claims are explicit independent derivations. The physical replacement remains conditional on the named accepted output-compiler machinery; this review checks its specialization and use, not a new proof of every inherited padding/restoration lemma. There is no result for arbitrary evolving-memory networks, mandatory PostLN, finite-arithmetic execution, trained realization, or an improved statistical estimation rate.

No blocking mathematical flaw was found in this exact file for the stated main-family scope.
