# Independent exact-file audit: task-risk replacement equivalence

6 November 2026 UTC. Independent skeptical paper review. No mathematical executable, numerical experiment, source simulation, model run, training, upload, or public mutation was used. Author sources were not edited.

## Reviewed file and verdict

`TASK_RISK_REPLACEMENT_EQUIVALENCE.candidate.v1.md`

SHA-256: `05d904b18bfebe84a4c6a01bf1bd43ef83f0c08ef032c7483d78846f646d669a`

**ACCEPT, conditional on the explicitly imported reviewed one-way information inequality and terminal-TV statistical lemma.** The new direct-task formulation, lambda=1 endpoint, common interior-source quantifiers, all-horizon fallback, and two equivalence directions are correct. No blocking mathematical flaw was found.

## Independently checked derivations

1. **Common source class.** The stationary binary class with all probabilities in `[c,1-c]` has a unique stationary pair law: two transitions give positive probability to every pair. The lag-two witnesses with theta=`+/-8 delta` lie in this same class whenever `delta<=min(1/128,(1-2c)/8)`. Both restrictions are needed and both are present.
2. **Direct-risk testing.** If the output has terminal TV risk at most delta, its signed probability difference, multiplied by the revealed penultimate sign, estimates theta in absolute expected error at most `2 delta`. Setting `h=8 delta` gives testing error at most 1/4 under each source. There is no extra original-predictor risk to add in this direct task experiment.
3. **Public randomness and bit cap.** Conditional on public coins, the full message, including the reserved bit, is still an Alice-generated channel. Its marginal is common under both witness signs. The common product comparison law and the imported information inequality therefore give KL at most `32 h^2 min(C+1,N) ln 2`. Bob's independent private coins do not change the comparison. Two applications of Pinsker through this common law give `TV<=8 h sqrt(min(C+1,N) ln 2)` and hence `delta^2 min(C+1,N)>=1/(16384 ln 2)`.
4. **Generic suffix branch.** `b*=max(3,ceil(1+(A/(lambda r))^2))` ensures `A/sqrt(b*-1)<=lambda r`. The suffix shares the actual terminal pair. Its induced initial law is covered by the imported arbitrary-initial estimator theorem, with no independence of the terminal context required.
5. **All-N fallback.** When b*>N, sending all owned raw bits and evaluating the actual public Q preserves task risk at most r. This meets lambda r exactly when lambda>=1. Replacing this branch with a length-N generic estimator would not necessarily meet the advertised envelope, so the explicit Q fallback is essential and correct.
6. **Cost bound.** The piecewise protocol has cost at most `min(N,b*)<=3+A^2/(lambda^2 r^2)`. Under the lower-rate premise `r>=a_c/sqrt(S)` and S>=1, this is at most `[3+A^2/(lambda^2 a_c^2)]S`. No epsilon-minus-r term occurs, so lambda=1 is valid.
7. **Reverse implication.** The displayed choice `a_c=(1/(2lambda))min(delta_c,sqrt(gamma/(K+1)))` gives `lambda a_c<=delta_c/2` and `lambda^2 a_c^2(K+1)<=gamma/4`. If R(Q)<=a_c/sqrt(S), that positive value is a permitted advertised envelope. Its replacement contradicts the testing lemma. The proof does not assume that arbitrary risk envelopes are statistically attainable or substitute an unknown exact risk into a complexity expression.
8. **Quantifiers.** The replacement is allowed to depend on Q and the advertised envelope, but it must precede and work for every unknown source. S is public and sample independent. The constants are uniform over all members and indices. The proof is an equivalence of existence statements, not an algorithm to compute risk or to discover an architecture-specific replacement.
9. **Domination distinction.** The constant predictors c and 1-c each have worst-source risk exactly `1-2c`, attained by opposite stationary iid endpoints. The latter is therefore a valid minimax replacement of the former but fails per-source domination on iid Bernoulli(c), where the former has zero risk. The text correctly limits this to the chosen pair and does not mistake it for an existential separation, since the original constant predictor itself is a cheap dominating replacement.
10. **No interactive transfer.** The proof uses an Alice-generated message and cannot be reapplied to a transcript containing Bob's input. The explicit one-bit counterexample and the statement of the remaining binary interactive gap preserve the necessary limitation. The forward construction is one-way, but this alone does not prove the reverse direction for interactive replacements.

## Dependencies and scope

The task-risk lemma still depends on the previously accepted one-way contraction inequality for correlated same-party Markov paths. This audit checks the new theorem's use of that ingredient, not a new proof of approximate entropy tensorization or its literature applicability. The generic upper similarly imports the reviewed arbitrary-initial terminal-TV estimator bound. Both dependencies are explicit in the source.

Read bindings:

- `../source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md`: SHA-256 `a16d5fbfa684efd32b75cfe3112acc501360cab67b82bbb01a78d56ec1d0cca4`.
- `../source_average_simulation_20261105/RISK_SCALE_SIMULATION_EQUIVALENCE.candidate.v1.md`: SHA-256 `7f596744187faf0d5dcd2625d85dff7522f3019557aa4822ee867bf8745ce7f6`.
- The interior-cutoff passage of `../evolving_common_control_20261106/AVERAGE_DEFECT_TRANSFER.candidate.v3.md`: SHA-256 `b5635587be993ddb209c5f0ea54c72ca7d362c13a57cc0b35b25dd654e92cd29`.
- `../source_average_simulation_20261105/INTERACTIVE_IID_FALLBACK_AND_MARKOV_GAP.candidate.v2.md`: SHA-256 `15419adfac7395e0300233b9420f7af25584de9717df788f4bdee2be730a4e7c`.

The result identifies a legitimate task-only route and its exact equivalence to the target lower. It does not supply the missing architecture-controlled O(S) replacement theorem, infer it from generic O(r^-2) estimation, preserve neural implementation resources, or close the general evolving-memory frontier.
