# Task-risk replacement and the inverse-square-root resource lower are equivalent

6 November 2026 UTC. Author candidate v1, awaiting a separate exact-file independent review. Analytical theorem composition under a common fixed source class. No experiment, training, numerical diagnostic, public upload or public repository mutation was performed. This is not a claim of statistical-theory novelty or an unconditional theorem for general evolving causal attention.

## 1. Main conclusion and why it differs from output simulation

Fix a stationary interior binary second-order source class and the AA/BB one-way raw-input ownership described below. For any source-independent architecture class and any public resource scale S in [1,N], the following are equivalent, up to constants uniform over the class:

- Every predictor has minimax terminal prediction risk at least a_c/sqrt(S).
- At EVERY valid positive advertised risk envelope r, each predictor can be replaced by a source-independent one-way distributed predictor with communication at most K S and minimax prediction risk at most lambda r.

Here lambda is any fixed number at least one, INCLUDING lambda=1. A replacement need not approximate the original predictor's output, hidden states, attention answers, or source-by-source risk. Its only fidelity requirement is the displayed minimax task risk.

This is an equivalence of existence statements. It does not establish either statement for an unrestricted architecture class. In particular, proving the proposed O(S) task-replacement property would already prove the desired architecture-dependent risk lower. Generic statistical estimation alone provides O(r^(-2)) communication, not O(S) without the lower-rate information.

## 2. One common experiment and frozen quantifiers

Fix c in (0,1/2). Let P_c consist of homogeneous binary second-order Markov sources with symbols {-1,+1}, every next-symbol probability in [c,1-c], and the source's stationary initial-pair law. The four-state pair chain has a unique stationary law under this positivity condition. The SAME class P_c is used for network risk, replacement risk, generic upper, and testing lower. No source-dependent architecture or source-dependent choice of protocol is permitted.

For N>=3 and a deterministic source-independent normalized binary predictor Q, define

    R_Q(P) = E_P TV(Q(X_1:N), P(.|X_(N-1),X_N)),
    R(Q)   = sup_(P in P_c) R_Q(P).

Architecture constants and syntax are frozen before N varies. For the intended application, Q is the synthetic-terminal probability output of a raw-token network in the frozen model: all data-carrying operations and probability-readout work remain charged to that network. This note grants no additional network readout, terminal-symbol port, hidden aggregate, source-specific weights, causal broadcast, or uncounted decoder. It uses only that Q is a public, fixed, normalized, source-independent map. The communication-side decoder, in contrast, has the usual unrestricted mathematical local computation. Exact evaluation of a public Q after full raw-input reconstruction is legitimate in THAT protocol model and is not a new neural implementation theorem.

For each public index (for example N,D and fixed architecture parameters), let C_index be any class of such Q. Assign a public, nonrandom, source-independent scale

    1 <= S = S(index,Q) <= N.

The usual target is S=min(D+1,N). More general publicly specified resource scales are allowed. S cannot depend on the observed sample or unknown source. To use this as an architecture theorem, its relationship to paid architecture resources must be justified independently; naming a risk-dependent quantity a resource is not such a justification.

Alice owns raw positions 1,2 modulo four; Bob owns positions 3,0 modulo four. The split, N, Q, S, architecture constants, and advertised r are public. Alice sends one finite binary message to Bob. Communication C is the maximum number of bits over all raw histories and random tapes, in the standard binary protocol-tree model; padding is allowed and timing or message boundaries convey no uncharged information. Public coins are independent of the sample and source. Independent private coins are permitted. Bob outputs a normalized probability vector.

For a fixed finite lambda>=1, define:

(L_S) There is a constant a_c>0 such that, for every public index and every Q in its class,

    R(Q) >= a_c/sqrt(S).

(T_S(lambda)) There is a constant K<infinity such that, for every public index, every Q in its class, and EVERY real r>0 satisfying r>=R(Q), there exists ONE source-independent one-way protocol Pi_(Q,r) satisfying

    C(Pi_(Q,r)) <= K S,
    sup_(P in P_c) E_(P,coins)
       TV(Pi_(Q,r)(X), P(.|X_(N-1),X_N)) <= lambda r.

The same Pi_(Q,r) must work for every P in P_c. The existence quantifier is AFTER Q and r but BEFORE P. The protocol can depend on the numerical advertised envelope r; no algorithm for computing R(Q) or checking r>=R(Q) is claimed. Constants a_c and K may depend on c, lambda and the class's frozen budgets, but not on N,D,Q,S,r or P. Empty classes cause no problem: both statements are then vacuous at those indices.

Positive envelopes suffice, including in the converse if a hypothetical predictor had R(Q)=0. No step assumes that an arbitrary small numerical r is attainable by a predictor. The premise r>=R(Q) is always retained.

## 3. Direct one-way task-risk testing lemma

Set

    gamma = 1/(16384 ln 2),
    delta_c = min{1/128, (1-2c)/8}.

**Imported-ingredient lemma.** Let a single source-independent one-way distributed predictor have communication at most C and uniform task risk at most an advertised delta with 0<delta<=delta_c. Then

    delta^2 min(C+1,N) >= gamma.                         (1)

This is the direct-prediction form of the reviewed source-average testing argument in `../source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md`, Sections 3-4. Here there is no network-to-simulator triangle inequality, so delta is the replacement's own risk envelope rather than a sum of original and simulation errors. The interior cutoff is the correction explicitly present in `../evolving_common_control_20261106/AVERAGE_DEFECT_TRANSFER.candidate.v3.md`.

### Proof from the previously reviewed one-way information inequality

Use the stationary lag-two witnesses

    p_theta(z|a,b) = (1+theta a z)/2,
    (X_1,X_2) uniform on {-1,+1}^2,
    theta in {+h,-h}, h=8 delta.

The two restrictions on delta ensure h<=1/16 and h<=1-2c. Thus both witnesses lie in the SAME P_c. Under the two signs, Alice's marginal law P_U is common, and Bob's marginal law P_V is common. The separately reviewed information inequality states, for every Alice-generated finite message M,

    I_theta(M;V) <= 32 h^2 I_theta(M;U).                 (2)

It applies to the correlated same-party marginal paths; their coordinates need not be independent. Its approximate-entropy-tensorization dependency is imported from the reviewed binary lag-two one-way result, not reproved here.

Append one reserved Alice-to-Bob bit revealing X_(N-1) if Alice owns it, and a dummy bit otherwise. Bob therefore knows Z=X_(N-1) on every horizon. If qhat is his probability output, put

    thetahat = clip(Z(qhat(+1)-qhat(-1)), -1,1).

The expected absolute estimation error is at most 2 delta under each witness. Testing the sign of thetahat therefore errs with probability at most 2 delta/h=1/4 under each alternative; an arbitrary fixed tie rule is valid. Consequently the total variation distance between the two complete observation laws is at least 1/2.

Let R be public randomness and M the message including the reserved bit. Conditional on R, M is an Alice-generated source-independent channel from U. Its marginal conditional on R is the same for both signs. With the common comparison law

    Lambda(dR,dM,dV)=P_R(dR)P_(M|R)(dM|R)P_V(dV),

inequality (2) and the binary entropy cap give

    D(P_theta^(R,M,V) || Lambda)
       <=32 h^2 min(C+1,N) ln 2.

Both the C+1 message cap and H(U)<=N ln 2 are used. Bob's independent private coins can be appended without changing this comparison. Pinsker and triangle inequality imply

    1/2 <= TV(P_+h,P_-h)
        <=8h sqrt(min(C+1,N) ln 2).

Substituting h=8 delta proves (1). The source is unknown throughout. This is a ONE-WAY lemma, not an interactive-transcript theorem.

## 4. The generic task replacement, including its all-N fallback

The reviewed arbitrary-initial terminal-TV lemma supplies a source-independent add-one predictor B_b from any final b>=3 consecutive raw observations with

    sup_(P in P_c) E_P TV(B_b, P(.|X_(N-1),X_N))
       <=min{1,A/sqrt(b-1)},  A=13 sqrt(32).             (3)

The imported lemma is valid on a larger arbitrary-initial, arbitrary-kernel source class, so restriction to P_c is valid. The suffix and complete sample share their actual terminal pair. No terminal-context independence or source mixing argument is needed. In the more schematic A'/sqrt(b) notation, one may take A'=13 sqrt(48), since b>=3. We retain (3) for its existing explicit constant.

For a valid r>0 define

    b_star=max{3,ceil(1+(A/(lambda r))^2)}.

If b_star<=N, Alice sends her owned bits in that suffix, in their public order. Bob reconstructs the suffix and outputs B_b_star. The cost is at most b_star bits and task risk is at most lambda r.

If b_star>N, Alice instead sends ALL her raw bits, at cost at most N. Bob reconstructs the full word and evaluates the public Q exactly. Its task risk is at most r, hence at most lambda r because lambda>=1.

Thus the single source-independent piecewise rule has

    C <=min{N,b_star}
      <=3+A^2/(lambda^2 r^2),                           (4)

and task risk at most lambda r. The branch is determined only by public N,r,lambda. Importantly, the second branch is NOT an add-one estimator truncated to N: that truncated estimator need not meet an arbitrarily advertised feasible r. The fallback inherits the guarantee of the actual Q whose risk envelope was advertised.

The protocol can ignore Q in its suffix branch. This is permitted because it is a task replacement, not an approximation of Q. It cannot generally be described as simulating the network's output.

## 5. Lower rate implies O(S) task replacement

Assume (L_S). For every Q and every valid r>=R(Q),

    r>=a_c/sqrt(S).

Applying (4) gives

    C <=3+A^2/(lambda^2 r^2)
      <=[3+A^2/(lambda^2 a_c^2)] S.

The inequality uses S>=1. Therefore T_S(lambda) holds with the uniform explicit choice

    K=3+A^2/(lambda^2 a_c^2).                            (5)

The fallback covers b_star>N without weakening the task-risk guarantee. This direction works at lambda=1. The old OUTPUT-simulation argument needed tolerance epsilon>r because it spent r in a triangle inequality comparing Q to the true law. No such subtraction is needed for direct task risk.

## 6. O(S) task replacement implies the lower rate

Assume T_S(lambda) with coefficient K>=0. Choose, explicitly,

    a_c=(1/(2 lambda)) min{delta_c, sqrt(gamma/(K+1))}.   (6)

Suppose some Q had R(Q)<=r_bar=a_c/sqrt(S). This positive r_bar is then a valid advertised envelope, irrespective of how much smaller the true risk may be. By T_S(lambda), its replacement has C<=K S and task risk at most

    delta=lambda r_bar=lambda a_c/sqrt(S)<=delta_c/2.

Apply (1) to this direct task predictor:

    gamma <=delta^2 min(C+1,N)
          <=(lambda^2 a_c^2/S)(K S+1)
          <=lambda^2 a_c^2(K+1)
          <=gamma/4,

a contradiction. Therefore R(Q)>a_c/sqrt(S), which in particular implies L_S. This proof also excludes a hypothetical zero-risk member by using a positive advertised envelope. There is no substitution of an unknown exact risk into a resource expression and no feasibility assertion for arbitrary r.

For S=min(D+1,N), Sections 5-6 establish precisely the requested equivalence with the capped inverse-square-root depth rate. For any other public S in [1,N], the same proof and constants apply. The statistical finite-N cap is retained in (1); the converse above only relaxes that cap to C+1 when convenient.

## 7. Per-source domination is a stronger certificate

A source-independent candidate replacement Q_s would satisfy per-source task domination if

    for EVERY P in P_c,
    E_(P,coins) TV(Q_s(X),P_actual) <= R_Q(P).             (7)

If the SAME communication guarantee C<=K S also holds, (7) implies

    sup_P risk(Q_s;P)<=sup_P R_Q(P)=R(Q)<=r<=lambda r,

so it supplies T_S(lambda) for every lambda>=1, without needing r to design the protocol.

The reverse implication is false for the guarantee of a particular replacement. A concrete example on this very class is Q^-(x)(+1)=c and Q^+(x)(+1)=1-c, both constant zero-message predictors. Each has minimax risk exactly 1-2c over P_c, attained respectively by iid Bernoulli(1-c) and iid Bernoulli(c) sources. Consequently Q^+ is a valid lambda=1 minimax replacement for Q^- at r=R(Q^-)=1-2c, and hence at every larger advertised r. But at the stationary iid Bernoulli(c) source,

    R_(Q^-)(P)=0,
    R_(Q^+)(P)=1-2c>0.

It fails (7). Thus equality of worst-source performance does not imply source-by-source domination. This example separates the two certificates for a chosen pair of predictors; it does NOT claim that no OTHER cheap dominating replacement exists for this constant Q^- (Q^- itself is one), or prove a new existential lower for every domination problem. The rigorous implication needed here is that an architecture-wide domination theorem would be stronger input than the minimax replacement theorem. The equivalence above does not supply such a theorem.

There is likewise no output-closeness guarantee hidden in minimax task replacement. Triangle inequality only gives a coarse bound E_P TV(Q_s,Q)<=risk(Q_s;P)+R_Q(P), and a small value of either supremum does not impose exact preservation of the other predictor's decisions on each history.

## 8. Source-dependent kernels and interaction cannot be silently allowed

### Source-known zero-message replacement is the wrong quantifier

For N divisible by four, Bob owns both terminal raw symbols. If a separately chosen protocol is supplied with each source kernel P, it can output P(.|X_(N-1),X_N) with zero messages and zero task risk. That construction would make task replacement trivial for every Q and r; it is excluded by the quantifier order in Section 2. Public knowledge of c, the source class, or the frozen Q is not knowledge of the unknown kernel. The meaningful statement is one protocol for all P, not one oracle protocol per P.

### No interactive extension is established

The lower uses that M is generated from Alice's view alone, conditional on public coins. A transcript containing Bob's data does not satisfy that Markov condition. For example Bob sending one fair owned sign produces a transcript with I(transcript;V)=ln 2, contradicting the naively substituted one-way inequality at small h. The binary interleaved-Markov interactive task-testing lower remains open in the checked local research. The known iid interactive correlation theorem and a separate four-symbol embedding do not prove it for the stationary binary P_c experiment.

Accordingly the proven implication is T_S^(one-way)(lambda) => L_S. No claim T_S^(interactive)(lambda) => L_S follows from this argument. The forward construction is one-way and therefore also permissible interactively, but that isolated fact is not an interactive equivalence.

## 9. Anti-circularity, dependencies, and precise remaining task

A proposed general causal-attention proof may aim to construct a cheap replacement without reproducing evolving attention states. This could avoid the stronger output-approximation and closed-memory-factorization obligations. It is a legitimate proof strategy, but an O(S) guarantee is itself equivalent, in the present experiment, to the target resource lower. It is not an established corollary of generic suffix statistics.

The proof supplies no missing architecture mechanism. In particular it does not prove that low-dimensional rows, bounded scores, constant width, or stationary mixing yield a source-independent O(D) one-way task replacement for arbitrary evolving causal memory. A valid theorem must construct or certify such a replacement without assuming the conclusion R(Q)>=a_c/sqrt(S). If it only cites the generic O(r^(-2)) suffix method and then equates r^(-2) with S, it has used the desired lower-rate information rather than proved it.

Imported analytical dependencies:

1. `../source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md`, Sections 3-5, with its independent v2 audit: binary AA/BB one-way information inequality, public-coin testing argument, and suffix add-one risk bound.
2. `../source_average_simulation_20261105/RISK_SCALE_SIMULATION_EQUIVALENCE.candidate.v1.md`: the earlier output-approximation equivalence; reused only as a comparison, not as a substitute for the direct-risk proof.
3. `../evolving_common_control_20261106/AVERAGE_DEFECT_TRANSFER.candidate.v3.md` and its independent v3 audit: the explicit witness restriction 8 delta<=1-2c when the common class is P_c.
4. `../source_average_simulation_20261105/INTERACTIVE_IID_FALLBACK_AND_MARKOV_GAP.candidate.v2.md`: checked scope of the remaining binary interactive gap.
5. `../logdepth_matching_private_20261104/MATCHING_ORDER.v2.md`: frozen raw-token network contract and the distinction between charged neural computation and unrestricted communication-side mathematical local computation.

All statistical ingredients are inherited. The present increment is the task-only formulation, its lambda=1 endpoint, the direct lambda coefficient, the explicit all-N fallback, the common interior-class quantifiers, and the distinction from per-source domination. Independent review of this candidate remains necessary. No new trained model, finite-precision result, optimality theorem outside the stated one-way equivalence, or literature-priority claim is made.
