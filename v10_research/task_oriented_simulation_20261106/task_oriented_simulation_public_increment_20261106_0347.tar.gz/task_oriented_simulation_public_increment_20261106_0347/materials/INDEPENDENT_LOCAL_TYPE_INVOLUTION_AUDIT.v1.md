# Independent exact-file audit: local type-preserving involution

6 November 2026 UTC. Symbolic paper review only. No scientific executable, numerical experiment, model run, training, upload, or public mutation was used. Author files were not edited.

## Reviewed versions and verdict

Final reviewed source: `LOCAL_TYPE_INVOLUTION_CERTIFICATE.candidate.v2.md`.

SHA-256: `f4b32672380d8bd8c724248bd8c1ddbb43f0904668537f1f534d362e8c2db784`.

**ACCEPT for its stated scope.** The exact source-preserving orbit projection, exceptional-set approximation, and nonvacuous nuisance-exclusion condition are valid.

Preserved earlier source: `LOCAL_TYPE_INVOLUTION_CERTIFICATE.candidate.v1.md`, SHA-256 `760d02ed979960dd6a2489de0e757068de3ba3fcd8124ead9a7187ffb5710e3f`. Its substantive proof was already correct, but its abstract prefix domain and empty-event modulus convention were incomplete. Revision 2 explicitly imposes N-b>=2 and defines J_N=0 when G is empty. A direct text comparison confirms that these are the only mathematical clarifications; v1 is not overwritten.

## Checked proof details

1. **Local type identity.** Each eight-bit word has exactly the six internal triples `001,011,110,100,000,000`, with order varying. Their first two and last two bits are both 00. Every triple crossing either block boundary is consequently unchanged. Rewriting preserves the full initial pair, all eight complete-history transition counts, and the terminal pair.
2. **First-match rule.** The first selected disjoint block remains a member of the same two-word set after switching it. All earlier blocks and all later blocks are unchanged. The same block is therefore selected on the second application, proving that iota is an involution on the entire sample space, including its identity action off G.
3. **Every homogeneous source law.** The complete-history likelihood depends only on the initial pair and transition counts. Thus x and iota(x) have exactly equal probabilities for every kernel and initial law, including zero-support cases. A finite bijection pairing equal masses preserves the whole source measure. Homogeneity is essential to this conclusion and is explicitly retained.
4. **Global phase flip.** Selected blocks begin after even time 2+8j. The two local phase increments are S and S+1 for any incoming running parity S. Both words have two ones, so all later running parities and later phase contributions are unchanged. Hence the full F flips exactly on G, including all prefix-suffix cross terms.
5. **Exact orbit risk domination.** The target is constant on each orbit because the terminal suffix is preserved. Convexity gives the orbit-average loss at x at most half the sum of the two original losses. Integrating and using source-measure preservation gives exact sourcewise domination of Q_ref by Q_orbit, with no unknown-source input to the projection.
6. **Cheap midpoint only after approximation.** On G, the orbit average equals q_sym exactly. Off G, it equals Q_ref, so its difference from q_sym is half the branch gap, at most rho/4. Conditional on every past, either designated eight-word block occurs with probability at least 2c^8. Repeated conditioning gives `P(G complement)<=(1-2c^8)^k` without independence. This proves the stated additive expected-risk penalty. Q_orbit itself is not asserted to be cheap.
7. **Empty-event boundary.** When k=0, G is empty, iota is the identity, and the probability bound is the valid trivial bound 1. Revision 2's explicit J_N=0 convention makes every modulus claim well defined. The nuisance-exclusion lower is correctly restricted to nonempty G, in particular k>=1.
8. **Physical exclusion modulus.** A suffix-only logical predictor is exactly invariant. Uniform physical approximation within zeta_b gives modulus at most 2zeta_b by triangle inequality. The hard reference has gap at least 2kappa_c rho on every matched pair; two physical errors yield at least `2kappa_c rho-2zeta_h`. A declared o(rho) threshold above 2zeta_b consequently includes the baseline and excludes the hard family in the intended growing-b regime. This is a complete-output condition, not a claim of exact intermediate-state invariance.

## Necessary interpretation

The certificate excludes this particular parity perturbation, not every nuisance or communication-hard function. It provides no general implication from rewrite invariance to cheap distributed computation, no efficient verifier for arbitrary exact-real networks, and no necessity condition for statistical optimality. Exact domination belongs to the orbit projection versus Q_ref; the suffix-only and physical comparisons retain their explicit additive terms.

The physical and branch-gap dependencies are the already reviewed main IID nuisance family and `SYMMETRIC_QUADRATIC_NUISANCE_REMOVAL.candidate.v1.md`, whose exact source hash is `2ae96bbacc29eb53dd5657ed00dba5f342d6fb296810fb44f193e90d1f56d2a1`. Their separate audits state the compiler dependence. No blocking mathematical flaw remains in revision 2.
