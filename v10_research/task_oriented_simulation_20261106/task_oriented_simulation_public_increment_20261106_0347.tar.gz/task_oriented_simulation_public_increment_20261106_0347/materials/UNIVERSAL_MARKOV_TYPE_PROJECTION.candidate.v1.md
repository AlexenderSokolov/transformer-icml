# Universal Markov-type projection and the communication cost of the statistic

6 November 2026 UTC. Private analytical candidate v1. No scientific executable, numerical diagnostic, model execution, training, upload, or public mutation was performed. All examples and reductions below are derived symbolically. This is a task-oriented alternative to reproducing a predictor's complete output. The sufficiency and Rao–Blackwell ingredients are classical; no novelty claim is made. Independent mathematical review is still needed.

## 1. Outcome and exact limits

For an arbitrary source-independent predictor of the next symbol of an unknown homogeneous binary second-order Markov source, averaging its outputs uniformly over each full Markov type class produces one source-independent predictor whose expected terminal total-variation risk is no larger under **every** source kernel and initial-pair law separately.

This is a simultaneous risk-domination theorem, not a statement that the new predictor approximates the old predictor's output. It needs no advertised risk bound, no known source parameter, and no inference of the desired depth-risk rate. It therefore does not repeat the risk-scale simulation equivalence in the prior work.

The projection has three important limitations:

1. The sufficient statistic has an O(log N)-bit description, but computing it from the original distributed AA/BB raw-input ownership requires Omega(N) worst-case communication, even with arbitrary interaction and bounded error. A low-dimensional statistic is not thereby a cheap distributed statistic.
2. Computing the projected predictor from the statistic can require an exponential type-class average. No efficient evaluation algorithm is supplied for an arbitrary predictor.
3. The projection is not proved to preserve a frozen neural architecture, width, paid depth, parameter precision, or normalization contract. It does not show that a fixed-depth architecture contains its own risk-improved projections.

An exact type-invariance requirement excludes the specific raw-history quadratic parity nuisance from the reviewed construction. It does not by itself imply cheap communication, remove all possible nuisance, or prove a statistical depth lower.

## 2. Model and statistic

Fix N >= 3 and alphabet {0,1}. Let p(c | a,b) be any homogeneous second-order transition kernel and let mu(a,b) be any initial-pair law. No stationarity, mixing, positivity, or relation between p and mu is needed for the theorem. A stationary interior class P_c is a permitted subclass.

For a word x=(x_1,...,x_N), define its eight triple counts

    C_abc(x) = sum_(i=3)^N 1{(x_(i-2),x_(i-1),x_i)=(a,b,c)},

its initial pair I(x)=(x_1,x_2), and its final pair E(x)=(x_(N-1),x_N). Keep both endpoint pairs explicitly and set

    T(x) = (I(x), (C_abc(x))_(a,b,c in {0,1}), E(x)).       (1)

Let H_t={x in {0,1}^N : T(x)=t}. Only nonempty H_t are used. The statistic has at most 16(N-1)^8 possible encodings, and can be represented by

    4 + 8 ceil(log2(N-1))

bits using fixed-width integer counters. This is a deliberately loose encoding bound. The eight counts have sum N-2 and obey additional flow constraints.

The next-symbol target distribution is

    tau_p(x) = p(. | E(x)),

and is constant on each H_t for every fixed p. The pair remains unknown only in the usual sense that it must be obtained from the sample; the source kernel is never given to the predictor or its projection.

### Endpoint redundancy, without a degenerate exception

Regard each triple abc as a directed edge ab -> bc on the four pair states. For every valid word and every pair v,

    out_C(v) - in_C(v) = 1{I=v} - 1{E=v}.                (2)

Consequently the vector 1{E=v} is recovered exactly as

    1{E=v} = 1{I=v} - out_C(v) + in_C(v).

Thus the initial pair and all eight counts already determine the final pair for every valid word. In the balanced case the final pair equals the initial pair; there is no exceptional valid-word degeneracy. Keeping the final pair in (1) makes target measurability explicit and does not change the type partition. Arbitrary integer tuples not arising from a word are outside the definition.

## 3. Uniform conditional law within each type

The probability of a history is

    P_(p,mu)(X=x)
      = mu(I(x)) product_(a,b,c) p(c | a,b)^(C_abc(x)).  (3)

Use the usual convention that a factor with exponent zero is one, including when its base is zero. For fixed t, the right side has a common value lambda_(p,mu)(t) for every x in H_t. Therefore

    P_(p,mu)(T=t) = |H_t| lambda_(p,mu)(t).

Whenever this probability is positive,

    P_(p,mu)(X=x | T=t) = 1/|H_t|,  x in H_t.           (4)

The conditional kernel in (4) is the **same** for all p and mu. If a source assigns probability zero to H_t, the conditional law there need not be defined probabilistically; the uniform law on that nonempty combinatorial fiber still defines the projection below. Such fibers contribute zero to that source's risk. This handles zero transition probabilities and zero initial-pair probabilities without conditioning on null events.

In a strictly positive transition class, an initial-pair law can still have zero entries. The same null-fiber treatment applies. If the class also requires a stationary full-support initial law, every nonempty type has positive probability, but this stronger property is unnecessary.

Equation (4) is a sufficiency statement for the family of complete sample laws, including the unknown initial-pair law. It remains true when mu is constrained to depend on p, such as under stationarity: within a type, that factor remains constant.

## 4. Source-independent projection and simultaneous risk domination

Let Q:{0,1}^N -> Delta({0,1}) be any fixed source-independent predictor. Define

    (Pi Q)(x) = qbar(T(x)),
    qbar(t) = (1/|H_t|) sum_(y in H_t) Q(y).             (5)

This is a normalized binary distribution and is source independent. Its definition uses only Q and the combinatorial type classes, not p, mu, their likelihood values, or an advertised risk envelope.

For each source, each positive-probability type t, and its final pair e(t), convexity of total variation in its first argument gives

    TV(qbar(t), p(. | e(t)))
       <= (1/|H_t|) sum_(y in H_t)
                      TV(Q(y), p(. | e(t))).           (6)

Using (4), this is exactly the conditional risk inequality. Averaging over T yields

    E_(p,mu) TV((Pi Q)(X), p(. | E(X)))
       <= E_(p,mu) TV(Q(X), p(. | E(X))).               (7)

The same Pi Q obeys (7) simultaneously for all kernels and initial laws. In particular, for any chosen family P,

    sup_(P in P) R_P(Pi Q) <= sup_(P in P) R_P(Q).      (8)

For a randomized predictor Q(X,U) whose private/public randomness U is independent of the source and sample, first average its output over U in (5). Jensen over both U and the uniform type fiber proves (7), with the original risk including expectation over U. The result concerns the average probability vector, not a random draw from the mixture with TV measured after that draw.

The argument extends to any prediction loss convex in the predicted distribution, provided the true target is constant within the type for each parameter. No strict improvement is guaranteed, because TV is not strictly convex.

### Projection identity and statistical completeness

Pi is idempotent: Pi(Pi Q)=Pi Q. Its fixed points are exactly the type-invariant maps

    T(x)=T(y) implies Q(x)=Q(y).                         (9)

Hence, with no architectural or computational constraint, restricting predictors to type-invariant ones does not change the minimax risk over any source subfamily: this follows from (8) and from inclusion of the restricted class in the full class. This statement is not asserted for a fixed neural architecture, which may fail to contain Pi Q.

A formal implementation of (5), given T and public access to Q, enumerates binary words in the fiber and averages their outputs. Enumerating all 2^N words and testing their types suffices. This is an existence construction with potentially exponential local computation, not an efficient compiler.

## 5. This need not approximate Q at all

There is no conclusion of the form

    TV(Pi Q(x),Q(x)) is small,

pointwise or on average at a prescribed fraction of Q's risk. Projection can discard information on which Q deliberately depends. A type-invariant output is identical for every member of a fiber even when Q has separated outputs on that fiber.

Thus (7) is a task-oriented domination relation. It is distinct from the earlier requirement to simulate the complete predictor at error kappa times its risk. Neither direction in RISK_SCALE_SIMULATION_EQUIVALENCE.candidate.v1.md is invoked here, and (7) contains no hidden assumption that the desired risk/depth lower already holds.

To use the projection to prove a depth lower, one would still need an independent architecture-controlled communication procedure for a risk-dominating output, or a different suitable statistical argument. The theorem supplies the domination, not the communication procedure.

## 6. Explicit same-type, same-suffix parity separation

Use the quadratic nuisance from IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md. For N divisible by four it is

    F(x) = sum_(odd k) x_k sum_(j<k) x_j  (mod 2).      (10)

Take any N divisible by four, N>=8, and define

    x = 0011 followed by N-4 zeros,
    y = 00011 followed by N-5 zeros.                   (11)

Both words start at pair 00 and end at pair 00. Their identical triple counts are

    C_001=C_011=C_110=C_100=1,
    C_000=N-6,
    C_010=C_101=C_111=0.                               (12)

One can check (12) directly: in either word the only nonzero block is two adjacent ones; the four transitions into, within, and out of that block are 001,011,110,100, and all remaining triples are 000. Thus T(x)=T(y).

There is only one pair of ones. In x its second position is 4, which is even, so F(x)=0. In y its second position is 5, which is odd, so F(y)=1. This is an exact analytic certificate that F does not factor through T. No enumeration or computational search was used.

If N>=12 and b<=N/2, the last b symbols of both histories are all zero, because their last nonzero positions are at most 5 and N-b>=N/2>=6. Therefore the reviewed suffix-only baseline logit difference d_s is identical on both histories. Its nuisance-perturbed reference first probability differs by

    sigmoid(d_s+rho) - sigmoid(d_s-rho)
       >= 2 kappa_c rho > 0.                           (13)

The reviewed physical approximation has uniform TV error at most zeta <= kappa_c rho/100. Its first-coordinate separation on this pair is consequently at least

    2 kappa_c rho - 2 zeta > 0.                        (14)

Thus not only F but also the specific reviewed low-risk reference predictor, and its sufficiently accurate physical predictor, violates exact type invariance under the main construction's horizon/suffix restrictions. This statement uses that dependency's physical error theorem; it is not a new normalization proof.

An alternative independently derived certificate uses ones at positions (3,6) versus (3,7), all other bits zero, N>=12. Its common counts are C_001=C_010=C_100=2 and C_000=N-8; the same parity flip holds. It is not needed for (11)-(14).

### What a type-invariance restriction does and does not certify

The condition (9) is finite and mathematically checkable for a fixed N by comparing outputs on all fibers. That check can be exponential and equality of arbitrary real-valued circuit outputs can require an appropriate symbolic certificate. An explicit factorization Q=phi composed with T is a direct structural certificate, but no same-width/same-depth realization of that factorization is supplied.

Condition (9) excludes the particular within-type parity variation just exhibited. It does not imply that every nuisance vanishes after projection, that the conditional average of the parity sign is zero on every type, or that all type-dependent perturbations improve risk. In particular, the nonlinear softmax and a suffix baseline may vary together across other members of a type. The correct universal claim is the risk inequality (7), not an exact deletion formula for the nuisance branch.

## 7. An O(log N)-bit statistic with Omega(N) distributed communication

Retain the original raw AA/BB ownership: for N=4n, Alice owns positions 4i-3 and 4i-2, and Bob owns 4i-1 and 4i. Consider a protocol that, on every binary history, outputs the exact full statistic T at Bob with probability at least 2/3, using at most C bits in the worst case over inputs and coin tapes. Arbitrary interaction and local computation are allowed; communication is a standard binary protocol tree, with no free timing/silence channel.

Given independent communication inputs a,b in {0,1}^n, form the raw history blockwise as

    (x_(4i-3),x_(4i-2),x_(4i-1),x_(4i))
       = (a_i,a_i,b_i,0).                              (15)

Each party can generate exactly its own owned raw positions using only its local input. Every triple ending or crossing through a zero at position 4i fails to be 111. The sole possible 111 triple associated with block i starts at 4i-3 and equals (a_i,a_i,b_i). Hence

    C_111(x) = sum_(i=1)^n a_i b_i,                    (16)

including the first and last blocks, with no boundary correction. Computing T therefore computes binary inner product

    IP_n(a,b) = C_111(x) mod 2.

This reduction does not change the raw input alphabet or the ownership split. It merely selects a set of worst-case raw histories.

### Elementary interactive lower bound

Let H_(a,b)=(-1)^(a dot b) for a,b in {0,1}^n. Orthogonality of binary characters gives

    H H^T = 2^n I,    ||H||_op = 2^(n/2).

For a rectangle R=A times B, under uniform independent a,b,

    |E[1_R (-1)^IP_n]|
      = 2^(-2n) |1_A^T H 1_B|
      <= 2^(-3n/2) sqrt(|A||B|)
      <= 2^(-n/2).                                    (17)

A deterministic C-bit interactive protocol has at most 2^C transcript rectangles. If Bob's last answer depends on his own input within a transcript rectangle, split that rectangle according to his output bit, producing at most 2^(C+1) constant-answer rectangles. Its correlation with the correct sign is therefore at most

    2^(C+1-n/2).

If its distributional error under uniform independent a,b is at most 1/3, this correlation is at least 1/3. Thus

    C >= n/2 - 1 - log2(3) = N/8 - 1 - log2(3).        (18)

A randomized protocol with worst-case success at least 2/3 has average error at most 1/3 under that input law. Fixing all public/private coins yields a deterministic protocol with no larger average error and the same worst-case bit cap. Therefore (18) applies to the randomized protocol too.

The standard exact-computation upper is for Alice to send all her N/2 raw bits, after which Bob reconstructs the history and computes T. Thus the worst-case communication complexity of this task is Theta(N), despite the O(log N)-bit size of its output. The same lower applies to a protocol estimating C_111 to absolute error strictly below 1/2 with the displayed success guarantee, because rounding recovers it.

### Scope of this lower

Equation (18) is **not** a source-average lower under the unknown Markov model, nor under fair IID raw histories. The distribution generated by independent a,b in (15) imposes duplicate Alice bits and fixed zeros. It need not be the law of a homogeneous binary second-order source, and it is not the fair-IID raw law. Positivity/full support of an admissible Markov source would make each encoded word possible but does not give the encoded set enough mass to transfer this lower to average loss.

The lower also does not say that every function phi(T), or a risk-dominating output depending on T, requires linear communication. Computing the full statistic can be harder than producing a useful estimate. It rules out the shortcut “T has logarithmic description length, so both parties can obtain it with logarithmic communication.”

## 8. Failure log and boundaries

1. **Discarded: treat the O(log N)-bit type as a free shared input.** The AA/BB reduction (15)-(18) proves that its exact distributed acquisition has linear worst-case cost. The original raw ownership must remain visible.
2. **Discarded: claim projection is a close simulator of Q.** Jensen only controls prediction loss against a type-measurable target. The same-type parity pair explicitly allows separated Q outputs to collapse.
3. **Discarded: claim type invariance removes every nuisance.** It removes within-type variation. A type-dependent perturbation can remain, and conditional parity averages need not be zero.
4. **Discarded: infer a source-average type-computation lower from full support.** The communication encoding induces a special history law. No such distributional transfer is made.
5. **Discarded: claim architecture preservation from decision-theoretic sufficiency.** Averaging over many histories is not shown to fit the original paid neural resources or parameter description.
6. **Discarded: recover final pair from counts alone without endpoint information.** Counts plus one endpoint suffice by (2); the theorem deliberately retains both endpoints. No assertion that counts alone always fix the terminal context is made.
7. **Discarded: use the prior risk-scale simulation equivalence to call the problem solved.** The present theorem is an independent domination statement, but communication tied to paid depth remains missing.
8. **No numerical evidence is needed here.** The parity certificates, flow identity, likelihood factorization, and communication reduction are explicit symbolic arguments. No model or mathematical search executable was run.

## 9. Sources and research status

Read before derivation:

- ../source_average_simulation_20261105/RISK_SCALE_SIMULATION_EQUIVALENCE.candidate.v1.md: distinguishes whole-output risk-scale simulation from an independent architecture theorem; explicitly not used as an implication here.
- ../source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md: raw AA/BB ownership, source-independent quantifiers, terminal target, and one-way-vs-interactive distinction.
- ../nonlinear_statistical_frontier_20261106/IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md: exact parity F, suffix-only logical baseline, and uniform physical approximation used only for (13)-(14).

The core type-projection and full-type communication proofs are self-contained. Equation (14) imports the reviewed construction's compiler guarantee. This candidate supplies a valid way to discard predictor-specific within-type nuisance at the level of statistical decisions, plus a precise obstruction to treating the sufficient statistic as a cheap distributed message. It does not close the original fixed-width repeated-attention risk/depth frontier.
