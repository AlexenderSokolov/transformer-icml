# Task-oriented route: dependencies, failed shortcuts and remaining target

6 November 2026 UTC. This increment used local source reading and symbolic derivation only. No mathematical enumeration, numerical diagnostic, model execution, training, parameter generation or upload occurred. No new external literature retrieval or novelty certification was performed.

## What is established versus inherited

The old RISK_SCALE_SIMULATION_EQUIVALENCE already states that a generic O(S) one-way OUTPUT approximation at a sufficiently large constant multiple of advertised risk is equivalent to the desired inverse-square-root risk lower. TASK_RISK_REPLACEMENT_EQUIVALENCE retains that warning for task-only risk, and adds the endpoint lambda=1 with the same interior source class and fully stated fallback. It is a logical sharpening, not a new unconditional architecture lower.

UNIVERSAL_MARKOV_TYPE_PROJECTION applies classical likelihood sufficiency and Rao-Blackwell convexity. Its simultaneous sourcewise risk domination is exact, but neither acquisition of the statistic nor representation of the projected function is free. Its worst-history count-recovery lower uses encoded inputs only for that explicitly worst-history question.

SYMMETRIC_QUADRATIC_NUISANCE_REMOVAL supplies a new local structural comparison against the already-reviewed quadratic nuisance. The five/eight-word path cancellation and suffix-channel bound control averaged absolute conditional phase bias. The midpoint predictor is cheap in communication and nearly risk-dominating, but remains far from the original output. Its neural-model-contained replacement is the OLD one-head baseline, not a new estimator or statistical rate.

LOCAL_TYPE_INVOLUTION_CERTIFICATE gives an independent eight-word orbit proof and a finite output-rewrite condition. It connects to type sufficiency without requiring acquisition of the whole type. Its exact orbit average can retain expensive behavior on unmatched histories; the suffix-only midpoint is a further approximation with a quantified exceptional-event cost.

## Rejected routes retained explicitly

1. Rename output simulation as task prediction and assert O(D) communication from the generic O(r^-2) estimator. Failure: obtaining O(D) this way uses precisely the desired r>=a/sqrt(D) bound. The equivalence proof retains all quantifiers and exhibits the circle.
2. Replace the full-input fallback by an N-truncated generic suffix when its chosen length exceeds N. Failure: that estimator need not meet a feasible advertised risk attained by Q; evaluating Q after sending the full word is the valid fallback.
3. Treat the O(log N)-bit type encoding as an O(log N)-communication protocol. Failure: the parties do not already possess the joint counts; exact acquisition can require Omega(N) worst-history communication.
4. Apply full Markov-type projection inside the fixed neural budget for free. Failure: a uniform type-class average may require exponential evaluation, and no architecture closure theorem is supplied.
5. Bound only E[(-1)^F] and ignore that the baseline/target depend on the suffix. Failure: unconditional phase balance need not survive conditioning. The proved statement controls E_suffix |E[(-1)^F|suffix]|, by retaining the running parity and suffix channel.
6. Divide by a possibly tiny suffix probability to claim the same bias bound pointwise. Failure: only the weighted average conditional bias is established; null suffixes are handled explicitly.
7. Average logits and call it averaging predictions. Failure: sigmoid(d) is not generally [sigmoid(d+rho)+sigmoid(d-rho)]/2. The replacement by the old baseline pays rho^2/8 using a second-derivative bound.
8. Sample one branch at random and apply Jensen as if returning the deterministic midpoint. Failure: expected TV is inside the prediction-randomness expectation. The actual returned probability vector matters.
9. Call the cheap physical comparison exponentially accurate in task risk. Failure: the source-phase contribution is exponential, but physical errors zeta_h,zeta_b and baseline substitution rho^2/8 remain. Making physical error exponential would require new depth/precision accounting.
10. Use exact suffix invariance for a compiled physical baseline. Failure: full-feature LN can induce small dependencies outside the suffix. Uniform approximation supplies the correct modulus 2zeta_b, which is enough for exclusion at o(rho).
11. Use the shorter five-word pair as an exact type-preserving orbit without checking likelihood equality. Failure: 11000 and 01100 need not have the same boundary-conditioned Markov likelihood. Their signed-kernel cancellation only needs common endpoint, opposite signs, and lower-bounded probabilities. The separate eight-word pair has matching first/last pairs and internal triple counts, so its orbit argument is exact for homogeneous kernels.
12. Generalize the binary one-way testing argument to interactive task transcripts. Failure: the previously recorded binary Markov interactive contraction gap remains open. The cheap positive protocol is one-way, while the earlier negative output-simulation theorem was valid for arbitrary interaction for a different reason.
13. Infer from one rewrite-invariance constraint that all statistically irrelevant or communication-hard components are excluded. Failure: other functions may be invariant under this rewrite. No general cheapness or necessity theorem follows.
14. Treat sourcewise domination, minimax domination and multiplicative versus additive guarantees as interchangeable. Failure: they have different quantifiers. The type/orbit projections dominate exactly; the cheap midpoint and physical baseline pay explicit additive errors. Only for the reviewed hard family's worst-source risk lower can these errors be converted into a vanishing relative excess.

## Shared model and proof dependencies

Both the hard family and the one-head replacement use raw inputs, normalized public positions, synthetic terminal, full-prefix masks, fixed width, positive-epsilon gain-two PreLN, ordinary final vocabulary softmax, and paid local stages. A common sufficiently large c-dependent norm/primitive envelope is fixed before N varies; no claim is made for an arbitrary smaller numerical budget. The replacement inherits old suffix counts, exact readout, bounded-log routine and full prepared-vector compiler.

The phase/orbit/type arguments are proved explicitly here. The one-way equivalence imports the reviewed lag-two information inequality and its external approximate-entropy-tensorization dependency; that transitive theorem is not independently re-proved by this increment. Neural realization imports the already-reviewed normalization/output lemmas. No attachment bundle alone closes that transitive graph.

## What remains open

There is no theorem that every low-risk fixed-width nonlinear-memory network admits a short retained statistic plus a finite-state nuisance with the displayed certificate. There is no new general risk-depth lower, better estimator, minimum head count, fixed-width optimum, efficient automatic verifier, training claim, finite-arithmetic certificate or PostLN extension. The positive lesson is a concrete noncircular structural task comparison; the unrestricted T1/T2 frontier remains an additional research problem.
