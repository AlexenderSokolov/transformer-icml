# Independent exact-file audit: universal Markov-type projection

6 November 2026 UTC. Independent skeptical paper review. No numerical experiment, mathematical search, source simulation, model run, training, upload, or public mutation was used. Author sources were not edited.

## Reviewed file and verdict

`UNIVERSAL_MARKOV_TYPE_PROJECTION.candidate.v1.md`

SHA-256: `a67b7ef4f38334013c5f82728ce5e26ac9517df4229e2b9dee042853c952ffe6`

**ACCEPT for its stated mathematical scope.** The source-independent risk domination, endpoint recovery, explicit parity separation, and worst-case full-type communication lower are valid. No unsupported architecture-controlled communication, source-average lower, or exact nuisance-deletion conclusion is claimed.

## Independently checked derivations

1. **Finite encoding.** Each of the eight counts lies in `{0,...,N-2}`, so `ceil(log2(N-1))` bits per count suffice. The displayed encoding bound is deliberately loose and valid, including N=3.
2. **Endpoint identity.** Summing the path edge incidences gives `out(v)-in(v)=1{I=v}-1{E=v}`. Therefore counts plus the initial pair determine the final pair even when the path is balanced. There is no missing endpoint degeneracy.
3. **Unknown source and initial law.** The full word likelihood factors as `mu(I) product p(c|ab)^C_abc`. It is constant on every nonempty fiber. Positive-probability fibers therefore have the same uniform conditional law for all kernels and initial laws. On null fibers the uniform combinatorial definition remains well defined and makes no probabilistic conditioning claim.
4. **Risk domination.** The actual terminal transition law is constant on each fiber, not merely its unconditional average. Jensen applies to TV against that same target. Averaging over fibers proves one simultaneous source-independent domination inequality. The extension to independent randomized predictors averages probability vectors before evaluating the new loss and correctly retains expectation over the original coins.
5. **Projection and minimax statement.** The type average is idempotent and its fixed points are exactly the type-invariant predictors. Unrestricted minimax risk is unchanged because every original predictor has a type-invariant competitor with no larger risk under every source. This does not extend to an architecture that may not contain the average.
6. **Explicit main parity witness.** The words with their only ones at positions `(3,4)` and `(4,5)` have initial and final pair `00`; both have one copy of each of `001,011,110,100` and `N-6` copies of `000`. The only pair-of-ones contribution to F is selected by the parity of its second position, so their F values are 0 and 1. For N>=12 and b<=N/2, their b-suffixes are both all zero. Thus the common suffix baseline cannot cancel their reference output difference. The imported uniform physical approximation loses at most `2 zeta`, as stated.
7. **Alternative witness.** Ones at `(3,6)` or `(3,7)` give two copies of each of `001,010,100` and `N-8` copies of `000`, with opposite F values. The N>=12 condition is sufficient.
8. **Distributed statistic reduction.** In raw AA/BB blocks `(a_i,a_i,b_i,0)`, the only possible `111` triple is the first three bits of a block. Every other triple contains a forced zero. Hence `C_111=sum a_i b_i` with no endpoint correction. The construction respects each party's existing raw-input ownership.
9. **Interactive lower constant.** The inner-product sign matrix has operator norm `2^(n/2)`. Each rectangle has uniform correlation at most `2^(-n/2)`. At most `2^(C+1)` constant-output rectangles result after appending Bob's final output bit. Error at most 1/3 implies correlation at least 1/3, giving exactly `C>=n/2-1-log2(3)`. Fixing public and private coins under the selected input distribution preserves the worst-case communication cap and yields the randomized conclusion.

## Boundaries that must remain attached to the result

- The type computation lower is worst case over raw histories. Its special encoding law is not the fair-IID or a proved admissible Markov law. The source explicitly preserves this distinction.
- Obtaining the full sufficient statistic can be harder than producing a statistically useful decision. The reduction does not lower-bound every function of the statistic.
- The projection need not approximate the original output and does not generally make the conditional parity sign exactly zero. It need not preserve the suffix baseline, architecture, depth, width, or efficient local evaluation.
- The physical-output separation imports the older compiler theorem; this audit checks its use and constants, not a new independent proof of that full compiler.

## Read dependency bindings

- `../source_average_simulation_20261105/RISK_SCALE_SIMULATION_EQUIVALENCE.candidate.v1.md`: SHA-256 `7f596744187faf0d5dcd2625d85dff7522f3019557aa4822ee867bf8745ce7f6`.
- `../source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md`: SHA-256 `a16d5fbfa684efd32b75cfe3112acc501360cab67b82bbb01a78d56ec1d0cca4`.
- `../nonlinear_statistical_frontier_20261106/IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md`: SHA-256 `ef9ce668cd9815e45501194198177c7acdc369894a50e3b31aebb5baaa340767`.

The core projection and communication arguments are self-contained; no desired depth-risk rate is assumed or inferred. No blocking mathematical flaw was found.
