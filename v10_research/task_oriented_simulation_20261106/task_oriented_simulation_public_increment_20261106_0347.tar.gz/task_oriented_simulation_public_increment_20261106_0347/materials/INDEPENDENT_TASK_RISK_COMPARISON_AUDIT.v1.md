# Independent exact-file audit: task-risk prior comparison

6 November 2026 UTC. Paper-only review. No numerical experiment, model run, upload, or public mutation occurred. Author files were not edited.

Reviewed source: `TASK_RISK_REPLACEMENT_PRIOR_COMPARISON.v1.md`.

SHA-256: `6c890fe52269c25c3dfa29edc99c4dbc9514155a306645043aea99eb9051c1be`.

**ACCEPT for its stated provenance and scope comparison.** The comparison does not assert a new statistical lower, independent literature check, or new architecture realization.

## Specific checks

- The old whole-output theorem uses kappa>1, a suffix accuracy budget `(kappa-1)r`, and testing budget `(1+kappa)r`. The new task-only formulation correctly uses lambda>=1, suffix accuracy `lambda r`, and testing budget `lambda r`.
- On the same source class, triangle inequality converts whole-output error kappa r to task risk `(1+kappa)r`, and task risk lambda r to whole-output error `(1+lambda)r`. Thus the changed fidelity does not alone create a new architecture-controlled communication theorem at unspecified constant factors. The exact lambda=1 endpoint is nevertheless a genuine formulation difference.
- The interior witness cutoff and all-N exact-Q fallback match the accepted candidate audited in `INDEPENDENT_TASK_RISK_EQUIVALENCE_AUDIT.v1.md`.
- The two constant forecasts separate the minimax and sourcewise guarantees for a particular replacement. The text expressly does not claim an existential separation.
- The common-control and weighted-defect discussion preserves them as sufficient surrogate-output certificates, not universal facts about evolving rows. No general cheap task replacement is inferred from their existence.
- **Growing-width check:** `MATCHING_ORDER.v2.md`, Sections 1-3, explicitly supplies a growing-width O(N) binary family with counted depth O(log N) and arbitrary-source risk at most `13 sqrt(32/(N-1))`. Restriction to P_c preserves that upper. If a class contains this family, every fixed positive lower coefficient times `1/sqrt(min(D+1,N))` is contradicted as N grows. The equivalent uniform O(D+1) one-way task-replacement claim is therefore false for such a class. This inference is mathematically valid.
- The growing-width construction is used only **under its own stated frozen contract and for a class that includes it**. Its source explicitly excludes an automatic final-vocabulary-softmax, mandatory-normalization, or other syntax extension. The comparison must not be paraphrased as proving that this unmodified network belongs to every later PreLN/softmax class. The written conditional inclusion is sufficient.
- The source-known and interactive limitations agree with the theorem. No iid independent-coordinate result is misapplied to the binary interleaved-Markov distribution.

Additional read binding: `../logdepth_matching_private_20261104/MATCHING_ORDER.v2.md`, SHA-256 `518cb4544ed227bfdb1e808c5d685a669a0d7ba6fe81632e847175af024eb82a`. Other dependency bindings appear in the companion equivalence audit. No blocking flaw was found.
