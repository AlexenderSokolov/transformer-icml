# Task-oriented nuisance removal: public research increment

This additive local package preserves all 28 available source files byte-for-byte: every candidate version, independent review, scope/failure record, report v1/v2, source binding, QA and build/check script. No source was overwritten and no GitHub action occurred. Open materials/RESEARCH_REPORT.zh.v2.html directly for the final Chinese report; its 13 local appendices are exact bound texts. Report v1 remains historical; v2 corrects the positive risk-envelope quantifier of the equivalence proposition.

## Scientific scope

Complete order-two Markov type conditional averaging does not increase sourcewise terminal TV risk, but a short type description does not imply cheap communication or preservation of network architecture.

For the specific previously constructed quadratic-phase nuisance, signed finite-state kernels and local type involutions provide source-average conditional-bias certificates. The probability-midpoint predictor communicates b/2 suffix bits and has risk increment at most zeta_h+(rho/4)B, with the minimum of the stated five-step/eight-step certificate bounds. This is average conditional bias, not a uniform bound for every suffix. The old actual PreLN/ordinary-softmax one-read baseline additionally pays zeta_b+rho^2/8. At the stated scales these increments are o(rho), not a new statistical estimation rate. The existing linear complete-output simulation obstruction remains valid.

The local rewrite output-modulus condition excludes this particular nuisance and accommodates its approximately compiled baseline; it does not rule out every hard function or supply an efficient universal verifier. General cheap task-risk replacement remains equivalent to the corresponding resource-risk lower bound under the full stated quantifiers and fixed lambda>=1, including lambda=1. The concrete de-noising example does not establish universal cheap replacement for low-risk networks.

## Status and limits

All mathematical PASS labels are exact-version scoped analytical text reviews, not formal verification, external peer review or novelty certification. Historical candidates, local-involution domain correction, failed routes and pending labels are preserved. No source sampling, finite enumeration, numerical diagnostic, model execution, parameter-generation run or training occurred in this increment. Document parsing/hashing is not scientific reproduction. Physical finite-precision reliability is not certified. Visual acceptance is NOT COMPLETED.

External communication inequalities, estimator machinery and actual-network compilation dependencies remain inherited and OPEN, not transitively reproved here. This is not a recovered full v10 corpus or a standalone proof-dependency release.

## Privacy, rights and use

Scoped inspection found no secrets, sensitive personal information, private conversations or machine paths requiring redaction. Third-party literature appears as attributed references/comparisons, not redistributed full papers. No new license or rights grant is introduced; this is not legal clearance.

SOURCE_DERIVATION_MAP.json records every source/public file, byte count and SHA-256. PACKAGING_QA.json separates new checks from immutable historical QA. independent_review/ contains historical audit index and independent packaging review. SHA256SUMS and python verify_package.py provide read-only integrity checks. Existing report build/check scripts write outputs; run only in a disposable copy, not against this frozen package. Source-relative dependencies retain original-location meaning and may not resolve from materials/.
