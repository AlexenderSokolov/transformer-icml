# Dependencies and omissions

All 28 source files are included unchanged, including report versions v1/v2, local type certificate v1/v2, failures, independent audits, HTML bodies, scripts and QA. No available historical version was suppressed or missing artifact invented.

External dependencies remain OPEN: prior quadratic-nuisance hard predictor and AA/BB complete-output simulation reduction; prior suffix estimator and statistical risk theorem; source-average communication/testing inequalities; actual positive-epsilon PreLN/full-prepared-vector/ordinary-softmax compilation and inherited one-read baseline; earlier Markov source definitions and primary literature comparisons. Precise relative references remain in original texts but do not imply files are bundled or accessible from relocated materials. This is not an exhaustive certified transitive proof graph.

Not included: third-party paper full texts/PDFs, external prior proof corpus, unperformed scientific numerical/training runs, unavailable visual screenshots or rendering acceptance, or missing earlier v10 records. Local appendix hashes establish exact text identity only, not scientific correctness or dependency closure.
