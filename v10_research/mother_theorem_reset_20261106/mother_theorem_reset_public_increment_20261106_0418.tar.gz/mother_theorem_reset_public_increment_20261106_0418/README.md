# Mother-theorem reset: public research increment

All 20 available source files are represented, including all candidate versions, failed arguments, audits, strategy/prior evidence, report, scripts and historical QA. Eighteen files are exact copies; JOINT_PRECISION_BARRIER_AND_ROBUSTNESS v1/v2 have only declared process-attribution phrases neutralized in public derivatives. No formula, hypothesis, proof status or historical uncertainty changed. Source originals remain untouched outside this package, with their exact hashes/sizes mapped. No GitHub write occurred.

Open materials/RESEARCH_REPORT.zh.v1.html directly for the unchanged final report with seven exact appendices. It embeds the already neutral joint v3, not v1/v2, so its original source bindings and QA remain valid. Original README's statement that old v1/v2 are preserved unchanged refers to the source archive; public copies are explicitly mapped derivatives. Historical audit references to original hashes retain their original-byte scope.

## Execution contract is not coefficient precision or floating point

The fixed-risk matching statement ADDS a worst-case adaptive additive execution-error contract to the same PreLN/softmax architecture. Inputs and coefficients are exact, the final output head is ideal, and input-aware/adaptive vector errors of magnitude 2^(-p) occur at the declared residual boundaries. For fixed c and fixed 0<r<c(1-2c)/2, a sufficiently large once-frozen fixed-width/full-norm envelope yields necessary D=Omega(log N), p>=log2 N-O(1), with matching D,p=O(log N) under the inherited construction and complete-program stability hypotheses.

This is not a theorem about coefficient-description bits, ordinary rounding-to-nearest, realistic floating-point hardware, risk tending to zero, or a sharp depth/precision exchange. A constant finite coefficient alphabet can yield N+1 distinct actual PreLN outputs. A genuine M-state terminal cut alone gives an order-1/M quantization floor, not inverse-square-root risk from state bits. All-row simulation must charge the N rows rather than a terminal-only summary.

The all-depth underflow obstruction applies to the specified per-edge fixed-grid rounding without renormalization. Aggregate rounding, exponent/range, fallback strategies and normalization conventions can change it. Those assumptions must not be dropped when citing the result.

## Evidence and remaining gate

Novelty/publication readiness is UNDETERMINED. Prior primary checks were limited to identified abstracts and inherited records, not full theorem-by-theorem arithmetic-contract comparison. Existing influence, uniform-attention precision and generic stability results remain credited. The exact-real architecture-sensitive statistical decision lower-bound route is still open; no new estimator or statistical rate follows.

No scientific execution, numerical experiment, model run, parameter generation or training occurred. Visual acceptance is NOT COMPLETED. Finite-arithmetic reliability, formal verification and external peer review are not established. External proof dependencies remain OPEN. This is not recovery of a complete v10 corpus.

## Privacy and verification

Scoped privacy review found no secrets, sensitive personal information, private conversations or machine paths. The two historical process-attribution derivatives are fully mapped, without reprinting removed phrases in public edit logs. Third-party works are cited/summarized rather than redistributed in full. No new license is added; review is not legal clearance.

SOURCE_DERIVATION_MAP.json records every original/public size/hash and each replacement. PACKAGING_QA.json separates new checks from immutable historical QA. Independent packaging review and historical audit index are under independent_review/. SHA256SUMS and python verify_package.py provide read-only integrity checks. Existing scripts write reports; run only in a disposable copy. Relative dependencies may not resolve from relocated materials/.
