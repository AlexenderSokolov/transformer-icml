# Dependencies and omissions

All 20 source files are represented. Original joint v1/v2 attribution wording is not redistributed; precise public derivatives retain all mathematics, failed arguments, unverified-prior qualifications and original-source hashes. Every other source file is exact. No version or failure was dropped and no missing evidence invented.

External dependencies remain OPEN: prior constant-width suffix estimator and risk proof; fixed positive-epsilon PreLN compilation, full prepared-vector/ablation tube stability, padding/restoration and ordinary-softmax modules; lag-two terminal-context sensitivity and testing; finite-execution contract definitions and prior all-row resource examples; earlier primary literature comparisons. Their full external proof graph and corpus are not established by this package.

Not included: third-party full papers/PDFs; absent full arithmetic-contract priority comparison; unexecuted hardware/floating-point/numerical validation; nonexistent training/parameter generation; unavailable screenshots/visual acceptance; missing earlier v10 files. Exact appendix hashes bind documentary versions, not scientific truth or dependency closure. No complete recovery is claimed.
