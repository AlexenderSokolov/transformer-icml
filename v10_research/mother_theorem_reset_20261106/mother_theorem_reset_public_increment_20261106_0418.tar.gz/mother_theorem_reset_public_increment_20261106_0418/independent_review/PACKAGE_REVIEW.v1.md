# Independent public research packaging review

6 November 2026 UTC. PASS, with stated scientific limits.

- All 20 available source files are represented: 18 byte-exact copies and two explicitly mapped editorial derivatives. Original/public sizes and SHA-256 hashes independently match.
- Reconstructed both derivatives using precisely the declared hashed fragments and replacements: one replacement in JOINT v1, three in v2. No other bytes changed.
- All seven HTML appendix bindings match their files; each exact escaped source appears once. The final report remains unchanged at SHA-256 d5560594ea84dc72cc77a02ece44e87e26dfe42aadc24e87469d1ee947bd32b4.
- Scientific qualifications remain intact: adaptive additive execution errors are not coefficient bits or ordinary floating-point rounding; logarithmic depth/precision matching is fixed-risk and conditional on the inherited compiler; the M-state floor is order 1/M; edgewise underflow requires its explicit fixed-grid/no-renormalization assumptions.
- No scoped scan findings for credentials, personal contact information, private absolute machine paths, or removed attribution phrases. Literature is attributed and summarized rather than redistributed as full papers. This is not legal clearance.
- Packaging documents correctly leave external dependencies, finite-hardware validation, visual acceptance, novelty, and publication readiness unresolved. Historical versions and uncertainties remain available.

No source edits, GitHub actions, scientific execution, or training were performed. Final package sealing/checksum generation remains the packager’s step.
