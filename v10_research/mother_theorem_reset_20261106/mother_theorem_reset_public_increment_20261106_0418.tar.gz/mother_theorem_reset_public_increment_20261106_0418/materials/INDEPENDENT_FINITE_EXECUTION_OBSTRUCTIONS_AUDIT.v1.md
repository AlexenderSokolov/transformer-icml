# Audit: finite-state, rounding and distributed-state obstructions

6 November 2026 UTC.

PASS for the self-contained obstruction and conditional perturbation arguments in `FINITE_EXECUTION_RESET_AND_OBSTRUCTIONS.v2.md`, SHA-256 `58e15e0a5c756f83e1881cdf412a36d9b0d332eecdb266c4934dce9c29ae75c8`. Strategic research targets remain proposals, not established general theorems.

## Finite decoder state

Fixing every source-independent random tape produces at most M decoder reconstruction values. This remains true if encoder and decoder share the tape. The pointwise nearest-codeword loss lower is independent of how a sample chooses its state. Intersecting scalar Voronoi cells with [c,1−c] gives intervals of total length L. On an interval of length l, any reconstruction point has integrated absolute error at least l²/4. Cauchy–Schwarz therefore yields L²/(4M), and averaging over tapes then over a uniform parameter prior gives the stated worst-parameter lower L/(4M).

The cut must include all history-dependent input to the final decoder. A later reread or history-bearing skip connection invalidates a terminal-only alphabet bound. Fixed positions and source-independent parameters do not. The statement requires an actual M-state execution interface; coefficient precision alone supplies none.

The IID empirical-mean upper follows from variance at most 1/(4N) and nearest-grid error at most 1/[2(M−1)]. It demonstrates the sharp exponential-in-bit-budget information scale, up to constants, without claiming an architectural realization. Consequently a universal inverse-square-root-in-bW lower cannot be obtained from state cardinality alone. The separate sample-size lower is compatible with the maximum of the two bounds.

## Edgewise rounding underflow

With terminal score span at most B, every unrounded weight is at most exp(B)/(N+1). Under the explicit fixed-point, nearest-edgewise, no-renormalization convention, N+1>2exp(B)2^b makes every terminal weight zero. This holds at every layer on the actual finite-execution trajectories by hypothesis. All remaining terminal operations are row-local, and its initial content is source-independent. Induction proves history independence despite arbitrary evolving nonterminal memories, width or depth.

The proposed lag-two sign kernel is stationary with uniform pair distribution: summing its two predecessor probabilities gives each successor pair probability one quarter. Its actual terminal target equals 1/2±theta with equal probability. Any independent decoder prediction, including randomization, has expected absolute error at least theta. The precision/score-span inequality follows by negating the strict-zero condition; integer and tie boundaries are explicitly excluded from an overprecise claim.

The exclusions are substantive: aggregate rounding, a nonzero renormalization fallback, floating exponent range, different masks, growing score span or an external history-bearing readout change the proof. This is not a universal statement about all low-precision attention implementations.

## Conditional numerical reduction

At identical inputs, independently rounded edge weights perturb one head's aggregate by at most (N+1)delta V/2. Output projection and summing heads conservatively multiply by HA. Coordinatewise storage rounding contributes at most sqrt(W)delta/2. The stated u bound is valid for the attention stage boundary made explicit in revision 2: aggregation, projection, residual addition, then stored-coordinate rounding. Subsequent FFNs/local maps are separate paid stages; otherwise their downstream Lipschitz constants must amplify the defect.

Using exact-stage Lipschitzness in maximum row norm yields e_(j+1)≤L e_j+u by a hybrid exact-map comparison. No Lipschitz property of the discontinuous rounding map is needed. Geometric accumulation gives the displayed D L^(D−1) bound, including L=1. Final-output Lipschitzness and the separate tube-margin requirement justify the sufficient bit budget. Initial quantization and exp/LN/division errors remain separate charges rather than being hidden inside coefficient precision.

The existing suffix-family substitution is expressly conditional on checking its actual full physical-stage tube constants. It is a sufficient precision upper, not a matching lower for the additional target-risk/depth dependence. The edgewise arithmetic contract also remains different from the adaptive residual-error robustness contract of the companion note.

## Distributed simulation and research scope

The general raw-split simulation can exchange every owned Wb-bit row state at each layer, costing O(NWbD). Both parties then know the global previous state and can reproduce deterministic updates. An O(WbD) claim would need another invariant or communication cut; terminal state alone does not reconstruct evolving K/V rows. The assertion is an upper simulator cost, not a proof that every instance needs that many bits.

The two proposed main directions do not claim success: a fully specified finite-execution implementation with matched obstructions, or an estimator-relevant lower that ignores removable output nuisance. Width-free depth frontiers and generic small-relative-error output simulation retain their known counterexamples. Novelty remains unverified; scalar quantization, perturbation propagation and the underflow calculation are elementary mechanisms.

Revision 1 is preserved at SHA-256 `3c3b8344f8628d3164812f3edcddf81fcabe4f97044bdf2245aff4e4c4fc2a0b`. Its stage-boundary ambiguity is explicitly corrected in accepted revision 2. No numerical execution, training, rendering or upload was performed.
