# Final audit: mother-problem reset report

6 November 2026 UTC.

## Exact report binding

`RESEARCH_REPORT.zh.v1.html`, 70051 bytes.
SHA-256: `d5560594ea84dc72cc77a02ece44e87e26dfe42aadc24e87469d1ee947bd32b4`.

PASS for semantic fidelity to the audited mathematical claims, scope and strategic qualifications, exact appendix integrity, and scoped static privacy review. No rendering or publication-readiness certification is supplied.

## Semantic and model-contract review

The Chinese body and `STRATEGIC_DECISION_AND_PRIOR_GATE.v1.md` consistently distinguish the original exact-real model from the added execution-error contract. They do not convert coefficient descriptions into activation precision, or equate adaptive residual perturbations with deterministic rounding. The error sites, all-row Euclidean error budget, input-aware adaptive policies, exact inputs/parameters/interior operations, and ideal final head are explicit.

The fixed-risk matching statement correctly concerns fixed c,r and a sufficiently large fixed width/full-norm envelope chosen once after c,r. Logarithmic depth and execution precision are necessary and jointly sufficient in that contract. The coefficient-description upper does not become a lower. No vanishing-risk region, optimized exchange curve, trained realization, or complete hardware implementation follows. The N≥3 arbitrary-initial condition is retained. The lower's hybrid coupling uses clean bounded nonterminal states and a canonical clean terminal; arbitrary-error upper trajectories are controlled separately by full-program tube induction.

The coefficient/state alphabet counterexample is summarized accurately, including its fixed-larger-width adaptation if public registers must be retained. The actual M-state lower is exponential in the state-bit budget, not inverse-square-root in bits. The distributed simulator retains its N factor. Edgewise fixed-point rounding is explicitly a different contract, and renormalization, aggregate rounding, exponent range, sparse masks and score-span changes are correctly identified as exclusions.

Only one priority route and one reserved route are proposed. The first is a deliberately changed finite-execution/robustness program; the second retains the original exact-real statistical-decision objective without claiming an established resource function. Local orbit constructions are positioned as supporting technical lemmas rather than a solved general frontier. Stop conditions reject further artifact expansion absent a genuine architectural/statistical invariant or a distinct arithmetic threshold.

## Literature and novelty gate

The strategy document is bound at SHA-256 `c5222773e58f32f73563e8b9ae69770b64d55fb85392b137b1755f57995fe555`. It labels the recent primary-source checks as abstract-level and requires full theorem-contract comparison before judging originality. The report does not claim that logarithmic precision, underflow, sensitivity or generic stability is new. It expressly declines to certify publication readiness and permits downgrading the robust result to a technical proposition if it adds no substantive gap closure.

This audit checks that those claims and cautions are represented faithfully; it does not independently certify external literature theorem scope or priority. The target's mathematical review remains the exact source audits embedded in the report.

## Independent source integrity and privacy

An independent HTML parser decoded all seven appendix blocks. Each equals its named source file exactly, each occurs once, every source-file SHA-256 equals the manifest binding, and each declared hash appears in the report. The complete body source is embedded as an exact substring. Superseded joint-note versions 1 and 2 are not embedded; only accepted version 3 is included.

No script, iframe, object, embed, form, input, event-handler attribute or javascript URL was found. Review and targeted scans found no private absolute workspace paths, coordination identifiers, credentials or sensitive personal records. The content comprises research material, source filenames/hashes, and public literature links. Relative research references are provenance, not private machine paths. These are scoped checks rather than an unlimited privacy guarantee.

Detailed results are saved in `INDEPENDENT_REPORT_INTEGRITY.v1.json`. Static parsing and hashes are document checks, not scientific evidence. No mathematical enumeration, numerical diagnostic, model execution, parameter generation, training, upload, or visual rendering was performed. Any later report modification requires a new hash binding.
