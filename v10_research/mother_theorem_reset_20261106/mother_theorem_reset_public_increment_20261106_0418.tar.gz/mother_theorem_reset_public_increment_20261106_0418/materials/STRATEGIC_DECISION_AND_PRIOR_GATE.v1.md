# Strategic decision: one active route and one reserved mother-problem route

6 November 2026 UTC. This is an assessment, not a publication-readiness or novelty certification. Local orbit variants are paused. Their sourcewise risk comparisons, exact phase certificates and physical compilers remain useful technical lemmas and counterexample hygiene; they have not established the arbitrary-memory T1/T2 frontier.

## Route 1: explicit execution robustness, with a proved fixed-risk starting point

Priority: first, because it has a fully falsifiable model and a completed analytical core. It preserves the actual PreLN/softmax architecture and Markov prediction task, but ADDS a worst-case execution-error contract. Do not quietly substitute it for the original exact-real/coefficient-precision problem.

Target already proved in the candidate, subject to exact independent review: for fixed c and 0<r<c(1-2c)/2, with perturbation magnitude 2^(-p) after each attention and FFN residual, and a sufficiently large once-frozen fixed-width/full-norm envelope, low robust risk requires D=Omega(log N) and p>=log2 N-O(1); an inherited suffix estimator plus full-program tube stability achieves D,p=O(log N). Inputs and coefficients are exact; final output head is ideal; errors are input-aware/adaptive vectors. The model is not deterministic round-to-nearest hardware.

The potentially meaningful new obligation is all-depth terminal erasure despite evolving nonterminal memory. Its proof cancels each O(1/N) access to the final raw token, preserving a canonical terminal trajectory. The depth lower and numerical upper use old sensitivity/stability tools. Matching orders at fixed risk is a sound result but may be too elementary or too close to prior precision work to serve alone as a leading conference main theorem.

Next gate, not another synthetic variant: inspect the precise arithmetic contracts in the primary finite-precision papers below and determine whether a canonical rounded execution implementation has a genuinely distinct statistical threshold. A full finite implementation must charge LN, exp, division, accumulation, storage, initial small-amplitude embeddings and exponent/range, not only coefficient bits. If the result reduces to known uniform-attention underflow plus generic stability, retain it as a technical proposition and do not expand it into a claimed novel main result. A stronger target would resolve risk tending to zero or a sharp depth–precision exchange under one realistic, fixed arithmetic contract; neither is currently proved.

## Route 2: exact-real, estimator-relevant lower bound (reserved, higher risk)

Keep the original exact-real model and fixed width, full norms, raw source and arbitrary evolving K/V. The only viable lower-bound objective is directly on statistical decisions or target risk, not reconstructing every output perturbation. A proposed source testing contraction must survive the known nuisance counterexample, account for all N evolving rows and arbitrary head/depth schedules, and yield something beyond the existing D=Omega(log N) constant-risk threshold.

Concrete proof target before any further artifact expansion: for the lag-two local-alternative experiment, derive an architecture-sensitive bound on the distinguishability of the final bounded decision as a function of paid depth and width, with no imposed post-read finite summary. No justified function F(D,W,B) is presently available for a proposed risk>=const/sqrt(min(N,F)) theorem. Do not assign a conjectured exponent merely because the old suffix estimator uses depth proportional to inverse risk squared.

Stop condition: an argument based only on (i) coefficient-description cardinality, (ii) terminal state bit count, (iii) exact-output communication, or (iv) a mandatory sublinear suffix is already blocked by explicit results. No more local orbit constructions are warranted unless they prove the missing architecture-sensitive contraction for a genuinely broader class.

## Proved barriers that change route selection

- Fixed coefficient precision does not bound the number of reachable outputs: a genuine constant-width one-block PreLN network with a fixed finite coefficient set produces N+1 distinct outputs. Mandatory public registers can be retained in a larger fixed width.
- Even a real M-state terminal cut gives only the scalar quantization floor (1-2c)/(4M), tight in order for IID estimation plus sampling error. It cannot alone imply inverse-square-root risk in the number of state bits.
- A general all-row simulator charges O(N W p D), not O(W p D). Removing N needs a real structural theorem.
- The existing growing-width actual network blocks universal sublinear-suffix replacement. It does not resolve the fixed-width original problem.

## Fresh primary-source checks and remaining priority gate

The following primary abstract pages were opened during this reset. Claims are limited to their abstracts; no complete theorem-by-theorem novelty comparison is asserted.

1. Merrill and Sabharwal, A Logic for Expressing Log-Precision Transformers, arXiv:2210.02671v7, corrected September 2025: https://arxiv.org/abs/2210.02671 . The abstract explicitly states that its finite-precision variant cannot represent uniform attention and studies log-n forward precision. Thus the broad slogan “uniform attention needs logarithmic precision” is prior work. Exact numerical conventions must be compared to the new adversarial residual-error certificate.
2. Chakrabarti, Pitassi and Alman, Every Bit Counts, February 2026: https://arxiv.org/abs/2602.02707 . Its primary abstract states a one-layer equality-inspired p-versus-p−1 expressivity threshold using finite-precision constructions and communication lower bounds. This prevents broad precision-frontier novelty claims; it does not itself establish the present unknown-Markov multi-layer task bound.
3. Chiang and Cholak, Overcoming a Theoretical Limitation of Self-Attention, ACL 2022: https://aclanthology.org/2022.acl-long.527/ . The abstract uses layer normalization to improve cross-entropy on PARITY/FIRST and discusses length generalization. The exact epsilon and bounded-gain assumptions must be read from its proof before comparison, not inferred from the abstract.
4. Izzo, Nichani and Lee, Quantitative Bounds for Length Generalization in Transformers, October 2025: https://arxiv.org/abs/2510.27015 . The abstract distinguishes average versus uniform error, finite versus infinite precision, and one versus two layers in shorter-sequence simulation. This is a close simulation neighbor, not permission to assume arbitrary evolving-memory task folding.
5. Hahn's fixed-depth token influence lineage is already identified in the archived primary comparison; the accessible primary paper is https://nlp.stanford.edu/pubs/hahn2020theoretical.pdf . Its O(1/N) influence mechanism must remain credited rather than relabeled as a new depth theorem.

The prior orbit-resource comparison additionally records 2026 low-precision CoT and padded-transformer results. No claim is made that these searches are exhaustive. Publication potential remains an open judgment contingent on the primary-contract comparison and a genuinely nontrivial extension, not on the number of accumulated lemmas.

No training, model execution, numerical experiment, upload, purchase or submission was performed. Old failed versions are preserved. This reset prioritizes one bounded proof program instead of indefinitely expanding removable-nuisance constructions.
