# Joint history–depth–precision: an exact-model barrier and a changed-model candidate

6 November 2026 UTC. Analytical research note v3. Preserves v1 and v2 and retains the correction of the arbitrary-initial-pair condition to N>=3. Includes the fixed-risk matching robustness candidate in Section 5. No upload, training, numerical experiment, priority claim, or new statistical rate. These results distinguish coefficient description length B from execution precision b. They are not interchangeable.

## Finding

In the existing exact-real bounded-norm positive-epsilon PreLN model, the established last-token sensitivity argument supplies a history–depth lower bound, with NO coefficient-bit term. A finite coefficient alphabet does not supply a finite activation alphabet. The explicit construction below rules out importing fixed-summary quantization bounds by merely substituting coefficient bits for master-word bits.

A potentially useful genuinely three-resource extension requires a new execution-error contract. Under worst-case bounded per-layer execution errors, b=Omega(log N) is necessary regardless of depth. This is a changed-model theorem, not an answer already proved in the current model. It may be worth pursuing only if a finite-execution theorem is a deliberate research objective.

## 1. Exact same-model coefficient/activation obstruction

Take width d sufficiently large to contain the prescribed input registers, two paired symbol coordinates, and a fresh paired destination. Embed binary raw symbols as (s,-s) with s in {-1,+1}, with coefficient entries in {0,+1,-1}. Retain public positional/constant coordinates if required, as orthogonal source-independent registers. The synthetic terminal row has zero symbol pair. All initial row norms are bounded. Pair public registers too, so row means are zero; public register values may depend on i and N, as allowed by the current public-position input convention.

Use one genuine causal PreLN attention block, epsilon=1, gain=2, zero shift, Q=K=0. Use V and O to copy the symbol pair to the fresh destination pair, with fixed entries 0 or 1. Set its FFN to zero. If the source-independent squared norm of the public registers at row i is r_i^2, LayerNorm sends its symbol pair to

    a_i (s_i,-s_i),  a_i=2/sqrt(1+(2+r_i^2)/d)>0.

The terminal destination is therefore exactly

    (u,-u),  u=(1/T) sum_(i=1)^N a_i s_i, T=N+1.

Every coefficient of the embedding, attention, and FFN has constant description length, all complete operator/state norms are bounded, and there is one head and constant depth. Public position precision is part of the input contract, not coefficient storage. All arithmetic is exact-real.

Start with all s_i=-1 and flip them to +1 one at a time in a fixed order. The terminal u increases strictly at every flip. There are at least N+1 different terminal states at constant coefficient precision and fixed width. With no position registers, all a_i are equal, and these are exactly the N+1 count values. Public registers do not invalidate the strict monotonicity argument.

An ordinary final epsilon-one/gain-two LN and a fixed affine logit projection onto u preserve distinguishability: the relevant scalar is

    g(u)=2u/sqrt(1+(r_T^2+2u^2)/d),

whose derivative is strictly positive for all u. Binary softmax with logits (g(u),0) is also strictly increasing. Thus this is an output-level obstruction, not merely inaccessible hidden information.

Conclusion: no bound of the form "the terminal message has at most 2^{O(d B)} labels" follows from per-coefficient B bits. The example does NOT prove that constant B achieves vanishing uniform Markov prediction risk; its nonlinear readout is not an accurate count-to-probability estimator. It specifically disproves the proposed finite-message inference. Nor does it exclude every conceivable B-dependent lower bound proved by a different mechanism.

## 2. The exact-model raw-tail lower bound that does follow

Freeze the actual model's width/head and full-norm/primitive-Lipschitz envelope so each terminal block obeys the usual bounded-score sensitivity constants. More generally allow any fixed bounded head count; constants may depend on that count and envelope. For histories differing only in raw token N, rows 1,...,N-1 agree at every layer by causality. Their terminal inputs agree. Every reachable row is bounded, including row N.

At each layer, changing row N while keeping the terminal query and other rows fixed changes terminal attention by at most C/T. This follows directly from score bounds |score|<=S: each weight is at most exp(2S)/T, and changing one score/value changes the normalized weighted sum by O(1/T). Changes in the terminal row itself contribute at most A times its old difference, including the query, its own key/value, LN, residual and local FFN. Consequently, for suitable frozen A>1,C,

    e_0=0, e_(l+1)<=A e_l+C/T,
    TV(Q(x_1:N),Q(x_1:N-1,x'_N))
        <= C_out C (A^D-1)/((A-1)T) =: Delta_D.

Here D counts actual blocks; any equivalent constant-factor primitive-depth convention changes A only. This is an architecture bound and holds regardless of coefficient description precision.

For a concrete statistical witness, choose the binary first-order chain (also an order-two kernel) with

    P(X_(t+1)=1 | X_t=0)=c,
    P(X_(t+1)=1 | X_t=1)=1-c,

for fixed 0<c<1/2, with any permissible initial law. At N>=3 (allowing an arbitrary initial-pair law) each conditional final-symbol probability given the prefix is at least c. The two next-symbol target laws have TV distance 1-2c. For each prefix, the triangle inequality and min{conditional weights}>=c give

    E[TV(Q,p_actual) | prefix] >= c(1-2c-Delta_D)_+.

The same holds after averaging prefixes. Thus risk below c(1-2c)/2 forces D>=Omega(log N), with constants fixed by the model envelope. Together with the known parametric sample lower one can state a maximum of that sample lower and this architectural floor, but this is old mechanism/composition, not a new three-resource mother theorem.

The chain is strictly positive and belongs to the source class used by the current statistical witness. This argument does not need deterministic target rows, an externally supplied suffix, or a cut restricting history access.

## 3. Changed-model theorem: adversarial execution errors after every read

This section deliberately changes exact-real execution. Declare that immediately after EACH attention sublayer, an adversary may add an arbitrary vector of Euclidean norm at most delta to the terminal residual state. Error-free execution remains admissible. Raw observations, weights, and nonterminal rows are not changed. Analyze robust risk, the supremum over allowed errors of expected terminal TV. Require the same fixed reachable-state envelope, or a bounded tube large enough to contain the coupled executions.

For any two histories sharing X_1:N-1 but differing in X_N, construct their execution as follows. Use the X_N=0 run without errors as reference. In the X_N=1 run, maintain the same terminal state as reference before every read. Earlier rows coincide by causality, row N may differ but remains bounded, and the terminal queries are identical. The terminal outputs of that attention sublayer differ by at most C/T, by the single-key/value replacement estimate above. Choose the allowed terminal error to cancel this difference exactly. Subsequent deterministic terminal-local computations agree. Repeat at every attention read, irrespective of how many reads/depth stages there are.

Hence, if delta>=C/T, a legal error policy makes the final prediction identical for both final-symbol branches for each prefix. On the same fixed positive binary chain,

    robust risk >= c(1-2c).

This construction works with actual PreLN, nonlinear evolved nonterminal states, and a conventional final softmax. It does not assume a stale memory bank or a one-read decoder. The adversary may depend on the whole input and reference run, as permitted by worst-case execution error. This is not a stochastic roundoff theorem.

If the execution contract has delta=kappa*2^(-b), this yields the necessary condition b>log2(T)-O(1) for robust risk below c(1-2c). Depth cannot recover a final token whose O(1/N) contribution is erased at every access. Separately, setting all errors to zero retains Section 2's logarithmic depth necessity. Therefore a robust low-risk realization needs BOTH D=Omega(log N) and b=Omega(log N). Section 5 supplies a matching fixed-risk upper for the source class under an explicitly declared compatible stronger error contract.

This result cannot be claimed for ordinary correctly rounded arithmetic without further work: a malicious cancelling vector is not necessarily a realizable rounding error, rounding-cell boundaries can preserve tiny changes, and random/unbiased errors have different quantifiers. It also cannot be claimed from finite coefficient descriptions. Width/head growth or a growing score/norm envelope changes C and requires explicit accounting.

## 4. Failed routes and what to do next

1. Count model descriptions to count messages: invalid. The same fixed program yields arbitrarily many exact-real outputs, as Section 1 proves.
2. Treat eta=2^(-M) in existing compiler as a necessary M-bit coefficient: invalid as a lower-bound inference. It proves one sufficient implementation's precision cost, not a requirement of every architecture; paid repeated contractions can manufacture small signals from simple constants, although an exact full PreLN constant-alphabet compiler has not been established here.
3. Use a quantized-summary lower after the first attention read: changes the model because raw rows remain accessible and future layers can read them again.
4. Infer arithmetic robustness from O(log N)-bit dyadic weights: invalid. LN square roots and attention divisions are still exact operations in the current results.
5. Claim no B lower of any sort: not proved. The actual conclusion is narrower: the current statistical/quantization argument supplies none, and there is a concrete counterexample to its required finite-message premise.

Recommended strategic decision: keep exact-real coefficient descriptions in the resource ledger, not as a claimed precision frontier. Either pursue a truly same-model evolving-memory lower by a different structural invariant, or explicitly announce a finite-execution branch and attempt matching robust upper/lower bounds. Do not dress the old log-depth sensitivity lower as a new joint theorem.

## Local dependencies inspected

- ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md: exact-real semantics; small-amplitude precision is a sufficient construction cost; total parameter bits differ from per-coefficient bits.
- nonlinear_statistical_frontier_20261106/WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md: genuine growing-width PreLN/full-norm contract and explicit arithmetic caveat.
- prior_art/precision_frontier_followup.md: fixed-master quantization interface differs from optimized encoders, streaming memory, and coefficient precision; established finite-message/half-log threshold mechanisms are not new.
- prior_art/two_resource_targeted_comparison.md: communication/statistic quantization sources do not establish an architecture-wide bit frontier.

## 5. Matching fixed-risk robust certificate (candidate extension)

The existing constant-width suffix compilation supplies a matching upper at fixed target risk, without proving new estimation rates. Here is the compatible precise contract.

Fix 0<c<1/2 and 0<r<c(1-2c)/2. After EACH attention residual sublayer and EACH FFN residual sublayer, allow additive errors at EVERY row, independently chosen with Euclidean norm at most u=2^(-p). The error policy may be adaptive and input-dependent. All supplied input symbols/positions and coefficients are exact; LN, softmax and affine computation are ideal before the declared additive perturbation. Final output LN/affine/softmax is ideal. This last convention is harmless for extension to a final additive error, but fixes the theorem unambiguously. Risk is sup over sources and admissible policies of expected TV from the actual terminal transition law. This is a robust execution certificate, not a specified hardware quantizer.

Choose one sufficiently large fixed width and parameter/state envelope, depending on c and r, that contains the existing fixed-suffix PreLN construction and a radius-one tube around all of its reachable exact states. The same envelope is used in the lower statements. With source-independent length-dependent weights, there exist D_N<=C_(c,r) log(N+1) and p_N<=C_(c,r) log(N+1), and per-coefficient description length B_N=O_(c,r)(log(N+1)), such that robust risk is at most r for all sufficiently large N. Conversely, within this frozen bounded-head/full-norm model, robust risk <=r forces D>=a_(c,r) log(N+1)-b_(c,r) and p>=log2(N+1)-b'_(c,r).

Upper proof. Choose a fixed power-of-two suffix length b sufficiently large that the reviewed TWO_READ_PRELN_COMPILATION v4 bound

    13 sqrt(32/(b-1)) + 1/b + O_c(b^(-2))

is at most r/2. All constants and b now depend only on c,r. That construction has fixed width, D_N=O_(c,r)(log N), and a fixed full-state/full-parameter norm envelope. It already includes the bounded conventional terminal readout and all amplitude-restoration/padding stages. No new learning argument is needed.

On the fixed tube each complete sublayer map is Lambda-Lipschitz in the maximum-over-rows Euclidean norm, for one Lambda>=2 independent of N. For causal softmax this follows by bounding score differences in sup norm from bounded Q/K and LN, using ||softmax(s)-softmax(s')||_1<=2||s-s'||_infinity, and using the bounded value-row envelope; no factor N appears. FFN/LN/residual bounds are direct. Let G>=1 be a terminal output TV Lipschitz constant on the tube. For L=2D_N perturbed sublayers,

    E_j <= Lambda E_(j-1)+u,
    E_L <= u (Lambda^L-1)/(Lambda-1).

Choose p so that this last bound is at most min{1/2,r/(2G)}. Tube induction is then valid at every preceding stage because the bound is increasing in j. Final TV changes by at most r/2, uniformly over input words and adversaries, giving robust risk <=r. The needed p is O_(c,r)(L+log(1/r))=O_(c,r)(log N). This treats all normalizing and restoration stages, rather than supposing their cancellation is exact under perturbations.

Lower proof. Zero errors are admissible, so Section 2 gives logarithmic depth. For the precision lower, the Section 3 erasure policy is a legal subset of this stronger all-row/two-sublayer error contract: set every FFN error and every nonterminal error to zero, and use only terminal post-attention errors. If 2^(-p)>=C/(N+1), robust risk is at least c(1-2c)>r, independent of depth. Therefore p>log2(N+1)-log2 C.

What this establishes, conditional on the cited compiler's audited theorem: matching logarithmic ORDERS of two necessary resources at fixed risk, jointly achievable by the same actual PreLN architecture. It does not prove an exact depth–precision exchange curve, optimized coefficient precision, vanishing-risk dependence, stochastic roundoff behavior, or a guarantee for any particular arithmetic implementation. The shared norm envelope must be frozen after choosing c,r and the upper construction; it is not a claim for an arbitrarily prescribed too-small numerical envelope. Treat this as a proposed extension to the model, not a result already inside the exact-real paper.


## 6. Construction cross-check and prior-art caution

The companion note COEFFICIENT_BITS_NOT_STATE_BITS.candidate.v1.md was independently checked symbolically: its width-two one-block formula, monotonicity, bounded states, and constant coefficient alphabet are correct when unused positional inputs need not occupy hidden coordinates. If the declared contract requires retaining position/anchor registers, Section 1 here supplies the same argument with paired public registers in a larger fixed width. This is an input-contract caveat, not a failure of the coefficient/activation distinction.

A targeted literature screen reports the following prior finding: Merrill–Sabharwal, arXiv:2210.02671v7 (2025 correction), explicitly notes a constant-precision obstruction to uniform attention. This report has not been independently checked here. Consequently, do not claim that p=Omega(log N), the constant-precision failure of 1/N averaging, or the sensitivity-to-precision link is new. A careful primary-source theorem comparison must distinguish their arithmetic convention from the adaptive terminal-error robust minimax convention here before judging whether Section 5 adds anything worth pursuing. No publication-readiness or priority conclusion follows from this note.
