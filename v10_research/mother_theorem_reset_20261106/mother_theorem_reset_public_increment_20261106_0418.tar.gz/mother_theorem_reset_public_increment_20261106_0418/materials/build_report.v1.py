from pathlib import Path
import html,hashlib,json
D=Path(__file__).parent
items=[('战略路线与先行工作门槛', 'STRATEGIC_DECISION_AND_PRIOR_GATE.v1.md'), ('系数位宽不等于状态位宽', 'COEFFICIENT_BITS_NOT_STATE_BITS.candidate.v1.md'), ('固定风险的执行鲁棒性联合界', 'JOINT_PRECISION_BARRIER_AND_ROBUSTNESS.v3.md'), ('有限执行障碍与未成路线', 'FINITE_EXECUTION_RESET_AND_OBSTRUCTIONS.v2.md')]
for name in ["INDEPENDENT_COEFFICIENT_STATE_BITS_AUDIT.v1.md","INDEPENDENT_ROBUST_MATCHING_AUDIT.v1.md","INDEPENDENT_FINITE_EXECUTION_OBSTRUCTIONS_AUDIT.v1.md"]:items.append(("精确版本独立审阅",name))
body=(D/'REPORT_BODY.zh.v1.html').read_text()+'<section id="appendix"><h2>七 完整证明与独立审阅原文</h2><p>候选创建时的待审状态以对应精确版本审阅为准。下列原文可离线核对，哈希仅用于版本绑定，不是科学执行或机器证明。</p>'
bind={}
for title,name in items:
 data=(D/name).read_bytes();h=hashlib.sha256(data).hexdigest();bind[name]=h
 body+=f'<details><summary>{title} · {html.escape(name)}</summary><p class="hash">SHA-256 {h}</p><pre>{html.escape(data.decode())}</pre></details>'
body+='</section><footer><p>中文报告 v1 · 2026 年 11 月 6 日 UTC。本增量无数学枚举、模型执行或训练；未完成视觉渲染验收。</p></footer>'
style='''body{font-family:system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;color:#171717;max-width:980px;margin:auto;padding:40px 24px;line-height:1.8}h1{font-size:2rem;line-height:1.4}h2{font-size:1.5rem;margin-top:2.6rem}h3{font-size:1.15rem;margin-top:1.8rem}nav{margin:24px 0}a{color:#145a88}.eq{font-family:Cambria,Georgia,serif;padding:12px 0;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%}td,th{border:1px solid #d9d9d9;padding:12px;text-align:left;vertical-align:top}th{background:#e8edf1}tr:nth-child(even){background:#f8f9fa}details{margin:22px 0}summary{cursor:pointer;font-weight:600;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.65 ui-monospace,monospace}.hash{overflow-wrap:anywhere;font-size:.85rem}footer{color:#555;margin-top:40px}@media(max-width:600px){body{padding:20px 16px}h1{font-size:1.6rem}td,th{padding:8px}}@media print{body{max-width:none;padding:0}nav{display:none}h2{break-after:avoid}tr{break-inside:avoid}a{color:inherit}}'''
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>回到母问题：两条路线、已证障碍与执行鲁棒性起点</title><style>'+style+'</style></head><body>'+body+'</body></html>'
(D/'RESEARCH_REPORT.zh.v1.html').write_text(page)
(D/'REPORT_SOURCE_BINDINGS.v1.json').write_text(json.dumps(bind,indent=2,ensure_ascii=False)+'\n')
print(len(page.encode()),hashlib.sha256(page.encode()).hexdigest(),len(items))
