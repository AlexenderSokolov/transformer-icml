# Mother-theorem reset: finite execution, not another orbit lemma

6 November 2026 UTC. Independent strategic assessment and self-contained obstruction proofs. No training, scientific executable, upload or external mutation. These are analytical results, not an independent certification of the existing compilers. External comparisons below use the already recorded primary-source audit rather than a fresh literature search.

## 1. Freeze what remains unproved

The common statistical experiment is one unknown stationary interior binary order-two source, a raw N-symbol history, public source-independent positional features, a synthetic terminal, causal evolving all-row memory, fixed positive-epsilon full-feature PreLN, bounded complete norms, and ordinary terminal affine-softmax prediction. The target is the conditional next-symbol law at the actual terminal context, on the same history. Width, total paid primitive depth, number/dimension of reads, arithmetic precision, and N-row storage are separate resources.

The old suffix estimator already gives O(b_suffix^(-1/2)) risk with O(log N+b_suffix) depth and constant width, under exact-real execution. The wide witness already achieves O(N^(-1/2)) with O(N) width and O(log N) depth. These are not new statistical exponents. The accepted orbit bridges and scalar evaluators are supporting compatibility results. The quadratic IID nuisance already blocks uniformly simulating EVERY low-risk output at a small risk-relative tolerance with polylogarithmic communication. Any purported universal output simulator must confront that counterexample first.

Two directions remain defensible: an explicit finite-execution theorem with joint history/depth/width/precision accounting, or a genuinely architecture-sensitive statistical lower bound that works modulo statistically irrelevant output nuisance. Neither is currently proved. Below are proved obstructions that sharply constrain both directions.

## 2. Proved obstruction A: a terminal bit budget gives an exponential floor, not an inverse-square-root floor

Let c in (0,1/2), L=1-2c, and suppose a predictor's only history-dependent input to its final decoder is a state S with at most M values. Positions, N and source-independent fixed parameters may be supplied freely. The decoder may use source-independent randomness. All earlier N rows may contain arbitrary distributed state. On the IID subclass p in [c,1-c],

    sup_p E_p |q-p| >= L/(4M).

Proof. First fix every source-independent random tape, including decoder randomness. Each possible state s then produces one number q_s. For every sample, |q-p| >= min_s |q_s-p|. For any M real reconstruction points, partition [c,1-c] into their Voronoi cells of lengths l_s (empty cells allowed). The integral of absolute distance to a point over a cell of length l is at least l^2/4. Consequently

    integral_c^(1-c) min_s |q_s-p| dp >= sum_s l_s^2/4 >= L^2/(4M).

Average over all tapes, divide by L, and then take the supremum over p. Conditioning on tapes is valid even if the encoder also uses them: the pointwise nearest-codeword lower does not depend on the conditional distribution of S. This proves the result.

If the terminal state has W coordinates of b bits each, M<=2^(bW), giving risk >= L·2^(-bW)/4. Combine with the existing IID two-point sample lower to obtain

    risk >= max{ c_0/sqrt(N), L·2^(-bW)/4 }.

No all-row storage assumption is needed for this theorem because the cut is immediately before the final decoder. But all history-dependent skip connections or outputs from other rows crossing that cut must be included in S. A decoder with additional history access invalidates the cut. A source-specific trained parameter that identifies p also invalidates the experiment. Randomized codebooks do not invalidate the proof.

### Sharpness of the information-only argument

On IID Bernoulli(p), compute the empirical mean p_hat and quantize it to the nearest of M equally spaced points in [0,1], M>=2. Its risk is at most

    E|p_hat-p| + 1/[2(M-1)] <= 1/(2sqrt(N)) + 1/[2(M-1)].

The final state needs only ceil(log2 M) bits. This is an abstract computation, NOT a claimed constant-depth PreLN realization. It proves that no lower bound stronger in M follows merely from the size of the terminal state and the IID experiment. In particular, a purported universal risk >= const/sqrt(bW), derived only by counting final states or using I(history;S)<=bW, is false. Parameter estimation encodes an estimate, not the N sample bits. For the full fixed-order source class, the relevant statistical object also has fixed dimension, reinforcing the need for an architectural restriction rather than a state-count slogan.

This distinction prevents a misleading route to T2: precision cannot be converted into a sample budget without a theorem about which sufficient statistics the architecture can compute.

## 3. Proved obstruction B: bounded-score attention can be annihilated by actual edgewise rounding

Fix the following explicit finite-execution semantics. At every attention head, compute the ordinary softmax weights, then independently round each weight to the nearest multiple of delta=2^(-b), without renormalizing. Subsequent local computations may have arbitrary depth, width and precision. The terminal attends to all T=N+1 prefix positions, including itself, at every useful head. All pre-rounding score spans are at most B, uniformly over all rows, layers and actual finite-execution trajectories. There is no separate terminal raw-history access.

If

    T > 2 e^B 2^b,

then every terminal attention weight is zero at every layer. Therefore the terminal output is independent of the raw history, even though nonterminal memory evolves arbitrarily.

Proof. For a softmax vector of length T and score span at most B, every weight is at most e^B/T < delta/2. Nearest rounding gives zero. The synthetic terminal initial state and public features are source independent. Inductively, every local terminal update depends only on its previous source-independent state, and every attention contribution is zero. PreLN does not change this induction: full-feature normalization is row-local. Additional layers cannot restore a missing history channel.

For an explicit stationary interior order-two witness, use signs Y_t in {-1,+1} with

    P(Y_(t+1)=+1 | history)=1/2 + theta Y_(t-1),
    0<theta<=1/2-c.

The uniform distribution on the four consecutive-sign pairs is invariant: summing the two possible predecessor signs gives probability 1/4 for each successor pair. Thus Y_(N-1) is uniform and the terminal target takes 1/2±theta equally often. Any history-independent (possibly randomized) prediction q has risk at least theta, by

    (|q-(1/2+theta)|+|q-(1/2-theta)|)/2 >= theta.

Hence risk below theta requires

    b >= log2(N+1) - B/log(2) - 1

(up to the integer/tie boundary). This is a true all-depth/all-width obstruction under the stated arithmetic convention, not an information bound imported from one-use attention. Source-independent positional features and distributed N-row memory do not defeat it: they cannot cross the zero terminal edge channel.

### Essential exclusions and counterexamples

- Rounding the aggregate attention output instead of individual weights is a different model. Uniform averaging can survive with constant accumulator resolution even though 1/T is below that resolution.
- Renormalizing rounded weights with a uniform fallback defeats the proof: a zero vector can be replaced with a functioning average. A zero-preserving fallback does not.
- Floating-point precision is not the same as a fixed-point grid. Exponent range can represent 1/T with few mantissa bits; the theorem must charge exponent range, not claim a mantissa lower.
- A sparse mask with m accessible rows replaces T by m. Cropping to a suffix for free changes the raw-access contract.
- Growing score span B can concentrate a terminal edge. The lower becomes a precision-versus-score-span tradeoff rather than a precision-only claim.
- A history-bearing terminal token or an external readout over every row defeats the induction.

This is a strict warning against advertising exact-real small-amplitude compilation as an implemented low-precision theorem. It is not alone a publication-level statistical frontier, and no priority claim is made.

## 4. A constructive formal reduction: exact reference circuits to edgewise-rounded execution

The following deterministic reduction supplies a falsifiable upper-proof obligation rather than assuming numerical execution is harmless.

Take an exact reference circuit of D paid stages. In a fixed enlarged reachable-state tube, suppose each exact stage is L-Lipschitz in the maximum row Euclidean norm, L>=1, and the final probability map is K-Lipschitz in that norm. Use at most H heads in one stage, at most N+1 incoming rows, value norm at most V, and bounded output projection norm A. Round each attention weight to nearest delta=2^(-b) without renormalization and round stored row coordinates to that same grid. All other errors can be included in the stage error budget explicitly.

At identical inputs, edgewise weight rounding changes a single head output by at most (N+1)delta V/2. Summing head projections conservatively gives stage defect

    u <= delta [HA(N+1)V + sqrt(W)]/2 = delta C_NW.

The sqrt(W) term is the Euclidean error of coordinatewise storage rounding. If the usual concatenation uses a tighter square-root-H bound, that is an optional sharpening. With exact initial inputs,

    e_(j+1) <= L e_j + u,
    e_D <= delta C_NW sum_(j=0)^(D-1) L^j <= delta C_NW D L^(D-1).

Thus terminal TV error <= epsilon is guaranteed by

    b >= log2(K C_NW D/epsilon) + (D-1)log2 L.

Also require delta C_NW D L^(D-1) below the enlarged-tube margin to justify every local bound. Quantized initial states contribute L^D e_0. Approximate LN, exp, division and scalar arithmetic require their own certified local errors; the formula does NOT hide them. Strict exact-real transcendentals in a rounded-attention model do not yet constitute a completely finite implementation.

The proof is induction plus the triangle inequality. It allows arbitrary evolving all-row memory and costs no communication simulation. For constant complete norms and fixed positive-epsilon LN, an N-independent stage Lipschitz envelope is plausible and can be derived directly, but it must be checked for the actual full compiler and arithmetic, not inferred from a logical circuit alone.

For the existing constant-width suffix family, D=O(log N+b_suffix), epsilon of order b_suffix^(-1/2), and constant L would yield sufficient fixed-point precision O(log N+b_suffix). Inserting b_suffix≈risk^(-2) gives a genuine joint *upper* resource statement. The matching lower supplied by Section 3 only requires log N bits; the additional risk/depth dependence is NOT proved necessary.

## 5. Why the raw split does not automatically repair T2

Let every row state have at most Wb bits, with Alice/Bob owning alternating AA/BB raw blocks. A completely general layer simulator can exchange the previous states of all owned rows, compute the next layer locally, and repeat. This costs at most O(NWbD) bits, independent of nonlinear interactions, with public parameters and deterministic arithmetic. It does not cost O(WbD).

The reason is concrete: raw ownership assigns O(N) changing row states, not one terminal register. Every later K/V bank may depend on both parties' previous messages. Exchanging only the terminal state does not allow either party to reconstruct those banks. Local, static, separable or bounded-anchor assumptions can lower the cost, but each is a substantive model restriction. The existing quadratic nuisance example already forbids a generic polylogarithmic exact-output surrogate at the relevant tolerance under exact-real semantics with logarithmic coefficient descriptions. It must not be silently regarded as finite-execution certified, but it makes the missing logical cut unmistakable.

## 6. Two falsifiable main-theorem targets

### T1: a common-model finite-execution resource region

Specify arithmetic first, including exponent/range, accumulator bits, when weights are rounded, renormalization, LN/exp implementation, and rounding of the small-amplitude input embedding. Prove an actual finite-implementation upper for the old statistical estimator, with the full tuple (N,D,W,H,b), not another exact-real compiler. Combine it with a universal precision/score-span obstruction such as Section 3 under that SAME arithmetic. A compelling result would characterize when arbitrarily deep bounded-score attention remains statistically blind and when a bounded-norm PreLN construction crosses to consistent prediction, with no uncharged high-precision accumulator or positional table.

Falsification tests: uniform averaging under aggregate rounding; weight renormalization fallback; floating exponents; enlarged sparse masks; quantization erasing the compiler amplitude eta before the first stage. Any one invalidates an overbroad version. To rise beyond a technical numerical corollary, close a real gap (for example necessary and sufficient precision for consistency under a canonical execution contract), rather than merely inserting the generic O(D) stability budget.

### T2: an estimator-relevant architecture lower bound, not exact-output simulation

For fixed W, complete norms and score span, arbitrary evolving causal memory and unrestricted useful reads, target a lower bound on minimax terminal TV risk that distinguishes paid depth from the sample-size floor. It must remain valid after adding and discarding the known low-amplitude high-communication nuisance. A potential route is a *decision-specific* testing or correlation contraction directly for the lag-two source experiment, or a reduction to an alternative statistically comparable predictor whose error is measured against the target, not against every detail of the original output.

Required formal deliverable: derive a bound on source distinguishability of the final decision under the actual architecture, with all-row evolution explicitly included. Merely knowing final state size gives Section 2 and no more. A theorem of the form risk>=const/sqrt(min{N,F(D,W,b)}) is currently a conjectural target; no particular F is justified by this note. Width-free F is refuted by the wide O(log N)-depth estimator. A universal small-relative-error simulator is refuted by the IID nuisance. Fixed-depth sensitivity supplies only the existing constant-error/log N threshold, not a vanishing-risk rate.

T2 is the stronger scientific objective but is currently less mature. T1 has a concrete arithmetic obstruction and a constructive reduction now, at the cost of studying an explicit finite-execution subclass rather than claiming that the exact-real general frontier is solved.

## 7. Literature overlap and classification

The existing current-frontier primary audit already identifies Hahn's token-sensitivity lineage; Chen et al. and Alman–Song for bounded-kernel summaries; Kozachinskiy for decoder-sensitive exact-real lower bounds; Rajaraman et al., Ekbote et al. and D'Angelo et al. for Markov/ngram representation. None supports marketing the old estimator or a new scalar orbit evaluator as a new main statistical theorem.

The orbit-resource prior comparison records Brösamle–Eckstein (ICML 2026) on rounded activations/attention and Svete et al. (ICML 2026) on padding, precision and looping. Their full theorem contracts must be inspected before claiming any finite-execution novelty. The state-quantization argument here is elementary scalar quantization, the stability reduction is standard numerical perturbation propagation, and the edge-annihilation obstruction is elementary underflow. Their value is to rule out invalid T1/T2 formulations and specify a genuinely testable research target, not to claim a new general technique.

Sources read: CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md; STATISTICAL_SCOPE_AND_SAMPLE_FLOOR.candidate.v1.md; IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md; orbit_preln_resource_link_20261106/PRIOR_AND_MODEL_COMPARISON.v1.md. The wide witness and compiler consequences above are explicitly inherited/conditional, not re-proved or newly audited here.
