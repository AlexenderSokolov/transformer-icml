# Audit: coefficient descriptions versus reachable state alphabets

6 November 2026 UTC.

PASS for `COEFFICIENT_BITS_NOT_STATE_BITS.candidate.v1.md`, SHA-256 `77abb0004cd4ce7895a392f7e778d9336d8ffbd8f42ad3a668b93a1cf78a2649`, under the stated exact-real PreLN contract with unused public-position inputs.

## Direct calculation

For raw h=(s,−s), s in {−1,+1}, full-feature mean is zero and variance is one. Epsilon-one/gain-two LN therefore gives (sqrt(2)s,−sqrt(2)s). The synthetic initial row is zero. Zero queries and keys give ordinary self-inclusive uniform weights 1/(N+1). The scalar value read and paired output projection produce the displayed terminal u=sqrt(2)(2S−N)/(N+1).

The zero FFN leaves this residual intact. Final full-feature LN maps its first coordinate to 2u/sqrt(1+u²), with derivative 2/(1+u²)^(3/2)>0. Ordinary binary softmax is strictly increasing in that logit. Every count S=0,...,N is attained, proving N+1 distinct terminal outputs without finite-word approximations.

The raw embedding matrix with columns (−1,+1) and (+1,−1) has operator norm two. The scalar value map has norm one and paired output projection has norm sqrt(2). Raw residual states have norm at most sqrt(2)(1+sqrt(2)); the terminal has an even smaller bound. All intermediate LNs and primitive Lipschitz constants have fixed bounds at epsilon one. The coefficient alphabet, width and depth are independent of N. Attention denominators and LN square roots are exact architecture operations, not secretly growing coefficient descriptions.

## Scope

This refutes an N-independent finite-state or finite-output alphabet bound deduced solely from W,D and coefficient bit length B. It also refutes pricing an exact transmitted activation coordinate at B bits merely because its generating parameters have B-bit descriptions. The example itself needs only O(log N) bits to identify its count output, and supplies no stronger communication lower.

It neither predicts every Markov source accurately nor contradicts statistical terminal-context depth lower bounds. It does not exclude all possible coefficient-precision lower bounds established by other mechanisms. An explicit finite retained-coordinate alphabet would yield a finite-state count, but that is an additional execution contract, not coefficient rounding.

If a model requires explicit retained public positional/anchor registers rather than allowing the embedding to ignore them, the exact width-two instance must be enlarged by a fixed number of paired registers. The companion joint note supplies this adaptation: source-independent rowwise LN weights remain positive, so flipping raw symbols in a fixed order still yields N+1 strictly increasing terminal values. This is a constant-width variant, not a width-two claim under mandatory-register requirements.

No numerical execution, training, upload, or parameter generation was performed.
