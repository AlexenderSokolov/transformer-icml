# Constant coefficient precision does not bound output alphabet size

6 November 2026 UTC. Symbolic candidate v1; independent review pending. This is an exact-real PreLN obstruction to a proposed precision proof, not a statistical lower or a consistency theorem.

## 1. One-block construction in the actual architecture

Use width d=2. For raw binary symbol x_i set h_i^0=(2x_i-1,-(2x_i-1)); initialize the synthetic terminal T=N+1 to (0,0). Public positions may remain unused. All input embeddings and trainable coefficients below are drawn from the fixed finite set {0,+1,-1,2}. Every LayerNorm has epsilon=1, gain=2 and zero shift.

Use one standard causal self-inclusive attention block with Q=K=0, one scalar value head W_V=(1,0), and output projection W_O=(1,-1)^T. The attention residual is retained. Set the FFN branch identically zero. Finish with a final full-feature LayerNorm and vocabulary logits (first coordinate,0), followed by ordinary binary softmax.

At a raw row the input is mean zero with variance one, so its normalized first coordinate equals sqrt(2)(2x_i-1). The synthetic input value is zero. Thus, if S=sum_i x_i, the terminal after attention is (u,-u), where

 u=sqrt(2)(2S-N)/(N+1).

The final LayerNorm maps this to (2u/sqrt(1+u^2),-2u/sqrt(1+u^2)). Its probability of the first vocabulary symbol is

 q_N(S)=sigmoid(2u/sqrt(1+u^2)).

The derivative of 2u/sqrt(1+u^2) is 2/(1+u^2)^(3/2)>0. Therefore q_N(S) takes N+1 distinct values as S ranges from 0 to N.

All full per-row hidden norms are bounded by sqrt(2)(1+sqrt(2)) before the final LayerNorm: each uniform average of scalar values is at most sqrt(2) in magnitude. Every full matrix/operator and bias norm is bounded by two, and all primitive Lipschitz constants have a fixed finite bound. Width, depth, head count and per-coefficient binary description length are independent of N. The ordinary causal denominator 1/t and normalization square roots are operations of the stipulated exact-real model, not learned coefficients.

## 2. What this rigorously rules out

A proposed argument saying that a terminal real state or output has at most 2^(C W D B) possible values merely because every parameter has B bits is false in this model. Here W,D,B are fixed while the output alphabet grows without bound. A communication simulation that sends one terminal coordinate exactly cannot price that coordinate as B bits solely from coefficient precision.

The same observation applies to counting distinguishable reachable states before the final output. Arithmetic precision and coefficient precision are separate resource axes. Input length and exact attention averaging can generate increasingly fine real values from a finite coefficient set.

This does NOT show that statistically meaningful prediction risk can be arbitrarily small at fixed depth: the constructed q_N is not a universal Markov predictor, and the established terminal-context depth lower still applies. It does not refute lower bounds that explicitly charge an approximation tolerance, output dynamic range, or actual quantization of activations/attention arithmetic. It also does not show an N+1 alphabet needs more than O(log N) bits to communicate; it only rejects an N-independent B-based cap.

## 3. Alternative contract that would be needed

If one explicitly rounds every retained coordinate to a known p-bit finite set, a width-W terminal state has at most 2^(pW) possibilities. A final deterministic decoder has no more output codewords. That finite-alphabet fact is correct under the changed execution model, but does not apply to the current exact-real PreLN model. Rounding every coefficient alone is not such a change.

This candidate supplies a strict obstacle to a tempting joint precision theorem, and helps delimit the remaining targets. It is not a new attention expressivity principle or a substitute for the mother problem's statistical resource analysis. No numerical execution, training, upload or parameter-generation experiment was performed.
