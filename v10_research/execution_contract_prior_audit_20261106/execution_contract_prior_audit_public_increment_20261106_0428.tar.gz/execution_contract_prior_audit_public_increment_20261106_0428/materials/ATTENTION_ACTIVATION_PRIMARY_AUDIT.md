# Primary full-text audit: sensitivity and all-layer robustness

Audit date: 2026-11-06 UTC. Target: mother_theorem_reset_20261106/JOINT_PRECISION_BARRIER_AND_ROBUSTNESS.v3.md, especially Sections 2, 3 and 5. This is a coverage comparison, not a novelty certificate. No external state was changed and no upload was made.

## Result

The old component is substantial: single-token dilution under bounded-score smooth attention is Hahn's mechanism; positive-epsilon LN preserves the smooth regime; all-layer adversarial activation perturbations already have a general mathematical formulation in Wei–Ma; and generic sublayer Lipschitz composition supplies the upper execution-error estimate. These ingredients must not be presented as inventions.

The precise additional statement to audit in v3 is the repeatedly refreshed causal terminal coupling: after every attention read an input-aware adversary cancels the O(1/N) final-raw-token contribution, uniformly in depth, then a fixed positive Markov source turns indistinguishability into expected-TV risk. None of the theorem statements inspected below states that complete result. This is only an affirmative comparison of these inspected results, not evidence that no other result covers it. The matching upper additionally depends on the local compiler; the sources below do not certify that construction.

The mathematical implication is narrow: the depth bound is a quantitative adaptation of an established mechanism; the p upper bound is a routine stability corollary conditional on the compiler and an N-independent Lipschitz tube. The repeated-erasure argument is the only locally identifiable extra lemma here, and it is elementary once the per-read O(1/N) bound and adversary contract are fixed. Novelty/publication strength does not follow from this observation.

## Source ledger and access

All downloaded PDFs and layout-preserving extracted text are in `primary_attention_robustness/` next to this report. Each basename below has `.pdf` and `.txt`. Page references below are the printed paper pages, not necessarily PDF viewer indices.

- `hahn`: Michael Hahn, Theoretical Limitations of Self-Attention in Neural Sequence Models, TACL 2020, pp156–171. https://aclanthology.org/2020.tacl-1.11.pdf . Retrieved full text.
- `hahn-supp`: author's Supplement, dated May 5, 2021. https://mhahn.info/files/transformers-proof.pdf . Retrieved full text. The soft-attention calculation following p8 is printed with a restarted page number 1; it is PDF page9.
- `chiang`: David Chiang and Peter Cholak, Overcoming a Theoretical Limitation of Self-Attention, ACL2022, pp7654–7664. https://aclanthology.org/2022.acl-long.527.pdf . Retrieved full text.
- `weima`: Colin Wei and Tengyu Ma, Improved Sample Complexities for Deep Networks and Robust Classification via an All-Layer Margin, arXiv:1910.04284v5, 16 June2021, associated with ICLR2020. https://arxiv.org/pdf/1910.04284 . Retrieved full text. https://openreview.net/pdf?id=HJe_yR4Fwr returned HTTP403/browser verification, so the exact conference snapshot was not inspected. Claims below identify the arXiv version.
- `weightnoise`: Yu-Lin Tsai, Chia-Yi Hsu, Chia-Mu Yu, Pin-Yu Chen, Formalizing Generalization and Adversarial Robustness of Neural Networks to Weight Perturbations, NeurIPS2021. https://proceedings.neurips.cc/paper_files/paper/2021/file/a3ab4ff8fa4deed2e3bae3a5077675f0-Paper.pdf . Retrieved full main paper; separately hosted supplement not fetched.
- `smoothattn`: Valérie Castin, Pierre Ablin, Gabriel Peyré, How Smooth Is Attention?, arXiv:2312.14820v2, 4 June2024 / ICML2024. https://arxiv.org/pdf/2312.14820 . Retrieved full text and appendices. Published entry https://proceedings.mlr.press/v235/castin24a.html .
- `noisetrans`: Themistoklis Haris, Zihan Zhang, Yuichi Yoshida, Noise Stability of Transformer Models, arXiv:2602.08287, PDF headed ICLR2026. https://arxiv.org/pdf/2602.08287 . Retrieved full text including appendices. Indexed conference PDF: https://openreview.net/pdf/088a9df8d976c7303f9895eeb5e0af883541bf0e.pdf .

## 1. Hahn2020 and the correction

### Actual definitions and claims

Section3 p158 uses a finite-alphabet sequence ending in a fixed end-of-sequence symbol, source-independent positional embeddings, attention heads which take weighted sums of previous activations, and a positionwise map f_act incorporating skip/FFN operations. The last activation determines the label probability. Attention is unmasked in the displayed definition. The framework is not explicitly the exact current causal PreLN execution contract.

Lemma5 p165: exchange one symbol x_i, i<n; the terminal activation changes by O(1/n), with constants depending on parameter matrices. Proof pp166–167 uses Euclidean activation norms and induction: the changed position can change O(1), all other positions O(1/n). It explicitly treats L fixed independently of n. The proof bounds states via input/position norms and depth, bounds attention logits by A, and then individual weights by exp(2A)/(n−1). Thus quoting the printed expression while letting depth grow requires checking uniformity: its state and score constants can themselves depend on L. V3's separately frozen full reachable-state/primitive envelope is a meaningful extra hypothesis for obtaining a fixed-base A^D/N estimate.

Theorem6 p165 is a next-symbol cross-entropy statement for a specified parity-generating two-state automaton and a 2Dyck PCFG. It is not an expected-TV minimax theorem for an unknown positive Markov transition class. The parity automaton has termination depending on parity; this must not be relabeled as v3's strictly positive last-symbol chain.

### Correction that must be included

Supplement §S2 p8, eqs34–35, explicitly says the original attention difference estimate omitted the term from changes in weights. The needed decomposition is a sum of old weights times value differences PLUS a sum of weight differences times bounded comparison values. PDF p9 derives total attention-weight change O(1/n) (ordinary unchanged entries have O(1/n²) change). The correction explicitly requires bounded positional embeddings and Lipschitz attention/activation functions. Dot-product attention is Lipschitz on the bounded reachable domain; it is not globally Lipschitz on unrestricted Euclidean space.

V3's per-read single-key/value replacement bound should be proved directly from normalized exponentials and bounded states, including denominator change. The corrected Hahn proof supports the mechanism; the original one-term display is not a valid proof to copy.

### Coverage judgment

- The clean dilution idea: directly established prior mechanism.
- Frozen-envelope logarithmic depth necessity: quantitative adaptation with a separate causal-tail recurrence, not literally Lemma5's fixed-network asymptotic statement.
- Repeated, input-adaptive post-attention cancellation: not in Lemma5/Theorem6 or §S2.
- Precision p or hardware roundoff: not a variable in those claims.

## 2. Chiang–Cholak2022

Section2 pp7655–7656 uses a transformer encoder, prepended CLS readout, full scaled-dot-product attention, and post-residual layer normalization. Footnote2 p7658 explicitly notes PreLN is common but follows original post-LN instead. PE is an arbitrary source-independent position function.

Proposition1 p7656 constructs exact PARITY classification for every length. The relevant acceptance criterion is probability strictly greater than 1/2, not a margin bounded away from 1/2 or low probability-estimation risk. FIRST's displayed logit (Eq1 p7658) is exp(c)/(exp(c)+n−1) times (indicator−1/2), so exact signs can coexist with decaying confidence. This reinforces the coefficient/state precision distinction and shows why exact-real classification cannot be substituted for TV accuracy.

Section4 p7658 defines LN(x;γ,β)=(x−mean(x))/sqrt(var(x)+ε) elementwise multiplied by γ, plus β; their construction fixes γ=1, β=0. Proposition2 p7659 explicitly assumes ε=0. Paired coordinates (s,−s,0,...) are converted by exact LN into constant-amplitude signs, followed by an output scale depending on target cross-entropy η. Immediately below its proof, the authors explicitly state that ε>0 makes LN Lipschitz and Hahn's lemma still applies. Thus this proposition does not invalidate v3's fixed positive-epsilon lower bound. Paired-coordinate centering tricks themselves are prior construction material, not new.

Proposition3 p7661 achieves arbitrarily low FIRST cross-entropy using attention logits multiplied by log n, including a positive-epsilon LN variant. This escapes v3's fixed bounded-score envelope; it is not a counterexample within that envelope. Neither proposition claims all-row post-attention/post-FFN robust execution.

## 3. Wei–Ma all-layer activation margin

Section2 p5, Eq2.1: h_1=f_1(x)+δ_1||x||_2 and h_i=f_i(h_(i−1))+δ_i||h_(i−1)||_2. Eq2.2 minimizes sqrt(sum_i ||δ_i||_2²) over perturbations making the classification wrong. Perturbations are chosen for a particular input/label and may be simultaneous at all layers; this is genuine hidden-state adversarial perturbation, not merely input or weight noise.

Crucial generality: AppendixA p16 permits arbitrary normed spaces at each layer, not only Euclidean spaces, and defines a mixed budget ||(α_i||δ_i||)_i||_p. Consequently the sequence-row-max Euclidean norm can be selected in its general formalism. It would be wrong to dismiss coverage simply because a sequence is a matrix or because the main-text norm is Euclidean. Taking large p and using the standard norm equivalence also links aggregate and maximum budgets.

The actual differences from v3 are:

1. The injected vector is scaled by the current preceding-state norm. V3 has an absolute radius u at each row/substep. If a positive lower bound and upper bound on those state norms are available, the contracts can be compared up to constants; upper boundedness alone does not establish the needed two-way comparison near a zero state. A protected public coordinate could help but itself must respect the stated error model. Thus a robust claim cannot rest on the norm-name mismatch.
2. The event is crossing a classification decision boundary; v3 measures expected total variation to a nondegenerate transition distribution. Correct classification does not control calibration/TV.
3. Theorem2.3 p5 and generalized TheoremA.2 p16 are sample generalization bounds controlled by all-layer margins and function-class covering complexity. They are not architecture-wide execution-precision necessities as a function of input length.
4. Theorem4.1 p9 studies robust test classification over an input neighborhood, using the infimum of all-layer margins over that neighborhood. It does not assert the same robust Markov estimator theorem.

Its all-layer setup is relevant prior art and a suitable formal framework for an adapted certificate; its stated theorems do not by direct substitution yield the depth-independent p≥log N repeated-erasure lower. Adaptivity is not by itself a novelty distinction: for deterministic execution, an input-specific collection of perturbations can reproduce the realized path of an adaptive strategy.

## 4. Tsai et al2021 weight robustness

Section3.1 p5 (continuation of preliminaries) assumes a feed-forward network W_L ρ(...ρ(W_1x)), nonnegative monotone 1-Lipschitz activation, and independent elementwise ℓ∞ matrix perturbation budgets ε_k. Theorem1 p5 treats a single weight layer. Theorem2 §3.3.1 p6 bounds pairwise-logit-margin changes under all-layer weight perturbations, with propagated error terms involving hidden ℓ1 norms and products of matrix (1,∞) norms. Theorem3 extends to selected layers.

This is useful prior art for telescoping/propagating local errors, but arbitrary additive activation vectors after softmax attention and FFN residual sublayers are not guaranteed to be realizable by those weight changes. Softmax/LN residual attention is not the stipulated monotone scalar-activation feed-forward chain. Therefore no direct contract identity should be asserted. Supplement proofs were not independently inspected; the theorem statement and proof description in the full main paper suffice for this scope distinction.

## 5. Castin–Ablin–Peyré2024: do not stop at sqrtN

Section3.1 pp4–5 defines finite-sequence input/output norm as Frobenius, and local Lipschitz constant as the induced Jacobian operator norm. On rowwise bounded B_R^n, Theorem3.3 p5 gives a bound growing as sqrt(n) for unmasked attention. Theorem4.3 p7 gives the masked counterpart. Proposition3.4 explains a regime in which sqrt(n) is tight.

But the same paper also proves an N-independent bound: Theorem3.5 pp5–6 bounds the W2 Lipschitz constant of mean-field attention by ||V|| (1+3||A||R²) exp(2||A||R²), and Lemma3.2 connects this to the finite-sequence Frobenius constant. Theorem4.4 p7 gives the same-form N-independent bound for masked mean-field attention in the conditional-transport metric d_p, with equal positional marginals. These are important positive prior bounds, not a mere unrelated sqrtN story. Its LN discussion §2.4 p4 is about bounding attention inputs and uses the displayed unregularized normalization; it is not a proof of robustness for the entire positive-epsilon PreLN network.

V3's convenient norm is max_i ||h_i||_2 because every row has an independent radius u. Converting a Frobenius estimate naively incurs sqrt(n) since ||E||_F≤sqrt(n)u. This does not contradict its N-independent row-max proof, and the conditional-transport bounds may offer a more direct route. In either case the elementary row-max estimate is readily proved from bounded logits/values and softmax's sup-to-ℓ1 continuity. Existing Lipschitz theory substantially covers the upper mechanism. It does not provide the lower repeated-erasure/source-risk statement.

## 6. Haris–Zhang–Yoshida2026 noise stability

Definition4.1 p5: X is standard Gaussian and Y=ρX+sqrt(1−ρ²)Z with Z independent standard Gaussian; Stab_ρ(f)=E[f(X)f(Y)]. It is an input-pair covariance statistic, not a supremum over bounded activation errors, and not itself expected-TV target risk.

Theorem5.1 p6 is the standard correlated-Gaussian ReLU moment formula. Theorem5.2 p7 studies f(X)=softmax(XXᵀ)XW_V as d→∞, with identity query-key product and Gaussian inputs. It derives per-coordinate stability proportional to ρ times a value-column squared norm. Section5.2 then discusses random low-rank and random Gaussian query-key products; Theorem5.3 p7 and AppendixG concern matching selected attention indices in the unstructured high-dimensional regime. The displayed main-text Theorem5.3 repeats the identity-case f(X) formula despite surrounding unstructured discussion; do not silently fix it when citing a literal theorem. The exact typography issue does not affect the scope comparison.

Section5.3 p8 explicitly calls its simple multilayer recurrence a thought experiment ignoring inter-layer distributional shifts. AppendixH p31 reports a mismatch between the proxy recurrence and observed full dampening. AppendixI pp32–35 adds distribution-dependent stability interval lemmas; Lemma11 requires Gaussian marginals and a scaled coordinatewise Bonami–Beckner resampling process. These are not new independent bounded post-sublayer perturbations at each layer. They do not establish v3's uniform guarantee or lower bound. The full text was accessible; no full-text gap remains for this paper.

## Recommended technically safe positioning

State the intended theorem as a changed execution-model corollary/extension of bounded-attention sensitivity plus a separate causal repeated-erasure lemma, with a conditional matching construction. Cite corrected Hahn, Chiang–Cholak's epsilon distinction, all-layer margins, and attention Lipschitz work. Do not claim novelty for layerwise perturbations, log precision for resolving 1/N signals, paired-coordinate LN cancellation, or geometric error accumulation. Do not infer ordinary floating-point behavior or realizable rounding trajectories from a freely chosen additive adversary.

For any novelty or theorem-cover decision still needed, compare other precision papers and the local compiler separately; this report does not substitute for those audits.
