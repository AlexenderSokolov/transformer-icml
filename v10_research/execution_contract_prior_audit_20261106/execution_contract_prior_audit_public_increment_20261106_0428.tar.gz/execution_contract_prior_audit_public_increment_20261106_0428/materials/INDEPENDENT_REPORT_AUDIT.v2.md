# Independent final report audit, revision 2

6 November 2026 UTC.

## Verdict and exact artifact

The specified report passes this targeted semantic, source-binding and static privacy review. No blocking correction was identified. This is not a novelty certification, complete re-proof of every cited paper, or visual-layout acceptance.

- Report: `RESEARCH_REPORT.zh.v2.html`.
- Size: 77,754 bytes.
- SHA-256: `56fb0fed5684a9c58614cda94ff901bb155426e81625e10e0f51ef0bed2a4d5b`.
- Body: `REPORT_BODY.zh.v1.html`, SHA-256 `2f506dccb41ac84dc61ea85cf971d2efdbcef11475a7a27facb3f5a95999846c`.
- Corrections: `CORRECTIONS_AND_CLAIM_LIMITS.v1.md`, SHA-256 `8f50673b475b692abdfc705c888d121bd0987d30392548a66076da7802cd467a`.
- Detailed independent primary checks: `INDEPENDENT_PRIMARY_COVERAGE_AUDIT.v2.md`, SHA-256 `89f702f926f52d8346c894483ca8f91d9504ff4e0661468d056b6c735851f206`.

## Semantic review

Read the complete Chinese body and correction ledger. Their principal claims agree with the exact-version targeted primary audit:

1. Precision p remains the exponent of an absolute adversarial residual-error radius. It is explicitly not a proved storage-bit, coefficient-bit or mantissa-bit requirement. The frozen architecture, disturbance sites and worst-case quantifiers are stated, including positive-epsilon PreLN, exact internal arithmetic and actual terminal-context TV.
2. Merrill–Sabharwal Proposition 1 is correctly identified as a double-logarithmic threshold in total floating bits. The later logarithmic precision class is not misrepresented as that proposition's necessity result.
3. Every Bit Counts is described as having independently checked printed statement/proof inconsistencies in the floating appendix. Neither the report nor correction ledger supplies an invented repaired theorem or declares the entire paper incorrect. The fixed-point result remains separate.
4. Brösamle–Eckstein's omission of normalization is retained alongside its substantive denoising and perturbation machinery. Wei–Ma's arbitrary normed spaces and prior all-layer perturbations are acknowledged; adaptivity is not presented as a novel framework. Castin's N-independent results are not hidden behind its Frobenius bounds. Chiang–Cholak's epsilon-zero construction is not transferred to fixed positive epsilon.
5. Same-history n-gram expression, smoothing, normalization and precision discussion are recognized as prior mechanisms. Akman's layerwise quantization is explicitly acknowledged. Izzo's thresholded exponentials and IID-average theorem are not conflated with adversarial residual errors or a Markov-average theorem.
6. The repeated-erasure argument is properly positioned as a short context-access argument: it survives a known fixed source kernel and therefore is not an unknown-transition estimation lower bound. The matching upper is described as ordinary stability composed with an inherited compiler. The rounding-cell and floating-exponent examples are valid barriers to changing precision contracts.
7. The conclusion does not promote an unmatched combination into novelty, publishability or the original exact-real coefficient theorem. It expressly limits the search and proof coverage. These limitations should remain in any short summary accompanying delivery.

The correction ledger changes earlier comparisons rather than silently replacing mathematical proofs. Its statements are consistent with the current body and the independently verified primary passages. Detailed external claims outside those targeted passages retain the verification limits of the accompanying audits.

## Exact embedding and static integrity

An independent HTML parser extracted eight preformatted appendix payloads. Each decoded payload equals its named UTF-8 source byte-for-byte after re-encoding; each occurs exactly once. All eight disk hashes match `REPORT_SOURCE_BINDINGS.v2.json`, and the displayed report includes each corresponding hash. The complete body is an exact substring of the assembled report.

The locator appendix is the v2 TSV, which omits internal reference identifiers. Primary PDFs are not embedded. The eight source bindings, report hash, body hash and results are recorded in `INDEPENDENT_REPORT_INTEGRITY.v2.json`.

No executable script, iframe, object, embed, form, input, event-handler attribute or JavaScript URL was found. Static checks found no private absolute workspace paths, internal retrieval-reference identifiers, private-key markers or secret-key patterns. Manual review of the body and correction ledger found no personal sensitive information or internal coordination language requiring removal. Pattern checks are a targeted privacy review, not a universal secret-detection guarantee.

No scientific experiment, upload or visual rendering was performed. The result approves the specified static artifact within these stated limits; it does not approve any changed bytes or substitute report version.
