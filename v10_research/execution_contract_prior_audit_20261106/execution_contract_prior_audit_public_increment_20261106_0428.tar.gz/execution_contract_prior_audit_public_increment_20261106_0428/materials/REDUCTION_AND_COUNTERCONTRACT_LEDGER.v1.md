# Reduction ledger and counterexamples to contract substitution

6 November 2026 UTC. Analytical assessment tied to the frozen comparison contract. This is not a new novelty claim. Full primary-theorem audits are separate.

## 1. What the fixed-risk matching actually measures

The precision lower uses a single fixed copy/flip source with probabilities c and 1-c. It continues to hold even if that kernel is supplied to the network designer: the missing information is the last raw context bit. Thus it is a CONTEXT-ACCESS robustness bound, not a lower bound on learning the unknown transition probabilities. Unknown-source estimation enters only through the reused upper construction.

Likewise the logarithmic depth lower is the established bounded-attention terminal-context mechanism. The current matching theorem does not distinguish sophisticated estimation from recovery of a single relevant final bit, and supplies no sharp vanishing-risk resource dependence. This is an essential limitation when evaluating whether it can carry the T1/T2 main result.

## 2. Four proof ingredients, with honest attribution level

A. Single-source-row softmax influence. Suppose terminal query and all but one source row agree, values have norm <=V, each score range <=B, and there are T attended rows. For a single head, write the output as (1-a)v_rest+a v_special. The shared rest distribution is unchanged; both special weights a,a'<=e^B/T. Triangle inequality gives output change <=4Ve^B/T. A fixed full output projection and bounded head count multiply only a fixed constant. This is the elementary local normalized-attention bound underlying the older sensitivity literature, not a new attention principle.

B. Repeated terminal erasure. Causality ensures that changing only raw row N changes no earlier raw row. If an input-aware post-attention error resets the synthetic terminal to the canonical final-bit-zero execution after every read, its query remains identical. Ingredient A therefore applies afresh at every depth, despite changed row-N memory. Required error is <=C/T per attention residual. This coupling is a short additional argument under the deliberately strong adversary; a fixed-depth sensitivity theorem alone does not literally state it.

C. Statistical conversion. Conditional final-bit probabilities are at least c and the two target distributions differ by 1-2c. If both terminal outputs coincide, triangle inequality gives conditional expected TV at least c(1-2c). This is elementary binary decision geometry. No novel Markov estimation lower is involved.

D. Robust upper. A previously proved predictor has exact risk <=r/2 and paid depth O(log N) at fixed r. Standard layerwise Lipschitz propagation in a max-row bounded tube yields error <=G u sum_j Lambda^j. Selecting u=2^(-p) with p=O(log N) gives risk <=r. This is an ordinary stability corollary of the existing predictor and layer bounds, not a new learning algorithm.

The full combination may have a useful precise contract, but mere absence of its exact wording in a paper is insufficient to call it a new main theorem. Assess proof distance as well as literal statement overlap.

## 3. Counterexample: arbitrary error budgets do not imply a deterministic-rounding lower

Let round_delta be nearest-grid rounding with grid delta. Inputs 0.49delta and 0.51delta differ by only 0.02delta, yet round_delta returns 0 and delta. An admissible additive-error adversary with radius 0.01delta could instead map both to 0.50delta. Therefore the existence of a small cancelling perturbation does not imply that a specified correctly rounded operation erases the difference. Conversely a robust upper against every error in a budget covers any implementation whose local error is actually proved to lie in that budget.

This example concerns quantifiers, not a full transformer counterexample. It explains why an adversarial lower cannot be transferred to round-to-nearest merely by naming the same error radius.

## 4. Counterexample: fractional-grid bits differ from total floating bits

For N=2^k, the value 1/N=2^(-k) can be represented with a constant-length normalized mantissa and an exponent whose binary length is O(log k)=O(log log N). On a fixed fractional grid 2^(-p), nonzero representation of 1/N instead requires p of order log N. Exponent range, mantissa precision, fractional bits and absolute error radius are separate quantities. Neither may be renamed “precision bits” without its definition.

This elementary distinction is concretely reflected in Merrill–Sabharwal's full-text Proposition 1 and is why an abstract-level constant-precision limitation cannot be read as a log-N total-floating-bit lower.

## 5. Other non-equivalences to preserve

- Random or unbiased errors do not include every input-aware cancellation policy. A worst-case lower does not establish expected-roundoff behavior.
- Parameter perturbations apply the same altered weights across histories/layers when the definition says so; independently chosen rowwise activation errors have much more freedom.
- Source-average loss is not worst-history output approximation; classification margin is not TV risk of a probability vector.
- An epsilon-zero normalization can amplify vanishing signals without the fixed positive-epsilon Lipschitz envelope. It is a different architectural hypothesis, not a contradiction.
- A Frobenius/Euclidean whole-sequence norm cannot be silently identified with maximum row Euclidean norm. Some prior results explicitly allow general norms, so norm mismatch must be checked, not presumed.
- Perturbation stability in a compact domain requires an actual tube or global bound. No assumption that arbitrary large-error trajectories remain bounded should be inserted into the upper without proof.

## 6. Current research verdict

Keep the matching robustness statement as a precise technical proposition pending full primary-contract comparison. Do not yet promote it to the original coefficient-precision T2 frontier or a publication-level statistical novelty. A genuinely stronger next target would need a canonical execution model with a nontrivial risk-dependent boundary, or an original-model statistical contraction beyond last-bit context access. Further local symmetry variants do not address this gap.
