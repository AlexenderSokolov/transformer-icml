# Primary full-text audit: three finite-precision transformer papers

6 November 2026 UTC. Scope: comparison to JOINT_PRECISION_BARRIER_AND_ROBUSTNESS.v3, especially its Section 5. This is a theorem/model comparison, not a novelty or priority certification. No external upload was performed.

## Executive finding

None of the three inspected results supplies the target theorem by direct substitution of its parameters. The obstruction is a mismatch of quantified execution models, architecture envelopes, or tasks, not merely a different theorem title. The broad ideas that finite precision limits attention, logarithmic precision can suffice, and errors propagate through layers are already present. In particular, Brösamle–Eckstein contains explicit layerwise perturbation recurrences and a stronger corrective-denoising strategy. The proposed generic Lipschitz upper is not a new numerical-analysis mechanism.

A necessary correction to any earlier comparison: Merrill–Sabharwal v7 Proposition 1 gives a **log log n total-floating-bit** threshold for representing uniform attention, not a log n threshold. The target's p is the negative logarithm of an **absolute adversarial error radius**, not their total floating-point storage bits.

## Target being compared

Frozen sufficiently large constant width/head and complete parameter/state norm envelope; actual causal PreLN with positive epsilon 1 and gain 2; N raw observations and a synthetic terminal. Inputs, coefficients, all internal computations, and final head are ideal. After every attention residual and every FFN residual, independently at every row, an input-aware adaptive adversary may add any Euclidean vector of norm at most 2^(-p). Risk is a supremum over source laws and these policies of expected terminal TV error for positive finite-state Markov prediction. At fixed sufficiently small risk, target claims necessary D=Omega(log N), p=Omega(log N) and a joint D,p=O(log N) construction conditional on the separate suffix compiler.

This is a continuous disturbance-ball contract. It does not by itself specify a finite state alphabet, floating-point implementation, rounding schedule inside matrix arithmetic, or storage-bit budget.

## 1. Merrill and Sabharwal, arXiv:2210.02671v7

Primary version: [A Logic for Expressing Log-Precision Transformers, v7](https://arxiv.org/pdf/2210.02671v7), dated 10 September 2025. Local complete PDF and text: sources/merrill.pdf and sources/merrill.txt. HTML corroboration: https://arxiv.org/html/2210.02671v7 .

### Exact loci and arithmetic

- Section 2.1, Definitions 1–2 (PDF pp.3–4): p-precision floats are pairs of signed integers (mantissa, exponent), together taking p bits. Their value uses a normalized binary mantissa convention. p may depend on n; the main log-precision class uses a simple O(log n)-time-computable p(n)=O(log n). Weights are fixed across lengths, with a log-uniform-weight extension in footnote 13.
- All embeddings, hidden states, head similarity/value outputs, activation outputs, and classifier input inhabit the p-float datatype. Truncated addition, iterated sum, multiplication and division are imported from the cited 2023 paper Appendix A. This audit did not independently re-audit that external appendix's implementation details; do not infer ordinary sequential IEEE accumulation from the word truncated.
- Appendix C.2–C.4 (pp.15–16) explicitly places normalization before attention and FFN, supplies residual connections, exponentiated scaled-dot-product similarity and a final normalized affine-sign classifier.
- Appendix D.2 (p.16) uses a(x−mean)/||x−mean||+b, with no positive epsilon in the displayed formula. It is not the target's epsilon-one LN. No frozen full-state/operator norm hypothesis matching the target is imposed.

### Exact statements and quantifiers

Section 3, Proposition 1 (p.5): for a normalized attention vector, its nearest p-float approximation has at most 2^(2^p) nonzero coordinates. If it is uniform and p<log2 log2 n, every coordinate rounds to zero. The proof uses the minimum positive representable float and nearest-rounding threshold. Attention's nonnegativity is necessary for the counting argument (the printed proposition only explicitly displays the sum condition, but its intended domain is attention probabilities).

This is a coordinatewise nearest-rounding statement about the normalized weights themselves. It is neither a result quantifying over arbitrary bounded additive disturbances nor a Markov-risk theorem. Its mechanism is float underflow, with a doubly exponential representable range in total bit count. Bfloat16 and float16 examples on that page explicitly emphasize their enormous uniform-attention context range.

Section 4, Theorem 2 (p.6): a log-precision transformer with parameters fixed across context lengths can be expressed by an FO(M) sentence computing exactly the same Boolean function. This is a logical expressivity upper bound for a fixed transformer architecture, not a matching depth/precision accuracy theorem with depth growing as log n. Footnote 5 allows causal attention and larger fixed output arity but explicitly excludes autoregressively generated tokens appended to the input.

### Comparison verdict

Direct coverage: **No**. Proposition 1 does not imply target p=Omega(log N), and Theorem 2 does not supply the target's statistical risk or log-depth construction. The target's exact-real uniform attention remains representable internally even at small p because only residual-output errors are permitted. Conversely, an arbitrary cancelling residual disturbance need not be realizable by nearest rounding of attention weights. The conceptual finite-precision/attention limitation is definitely prior art; the numerical thresholds must not be conflated.

## 2. Chakrabarti, Pitassi and Alman, Every Bit Counts

Primary version: [arXiv:2602.02707v1](https://arxiv.org/pdf/2602.02707v1), 2 February 2026. Complete local PDF/text: sources/bits.pdf and sources/bits.txt. HTML: https://arxiv.org/html/2602.02707v1 . PDF numbering is used below; HTML has inconsistent appendix numbering for the floating-point definition.

### Exact loci and model

- Appendix A.1, Definitions A.1–A.4 (pp.14–15): embeddings, attention followed by an MLP, and final output; one-layer theorem has one head and value dimension d_v=1. This is not an actual fixed-epsilon PreLN residual architecture. No frozen full operator/state norm envelope is imposed.
- Definition A.7 (p.15) defines signed fixed-point values with total p=1+|a|+|b|. Crucially the integral and fractional lengths need not be fixed separately. Discussion gives a scaled representable interval ±lambda(2^(p−1)−1). This p is not simply the number of fractional bits of a fixed bounded-range uniform grid.
- Appendix A.3 (pp.15–16): binary operations are computed exactly then rounded to a nearest permitted value, with ties allowed to truncate. Iterated sums/products are left-associated and rounded at intermediate steps. Definition A.10 (p.16) defines floating point with total budget 2+mantissa-length+exponent-length.
- Appendix A.4 (p.16) fixes arithmetic order: finite-precision Q,K, then QK^T, then exponentiation A, normalizer D, and numerator (AX)W^V followed by normalization. It is not equivalent in finite precision to arbitrary reassociation or to first rounding every normalized softmax coefficient. Exact overflow and exponential conventions should not be silently replaced by an IEEE implementation.

### Theorem and task

Theorem 2.4 (pp.6–7), backed by Lemmas 2.5–2.6 and Appendix B.2 (pp.20–22): for each p and n>4p, m=2p−1, a special encoding of an equality problem cannot be computed with p−1 bits by a one-layer, one-head, d_v=1 transformer, but can be with p bits of their fixed-point precision. Encoding T_m^1 includes special padding and complements; the underlying comparison has promises described in Section 2 and Appendix B. Lower bounds communicate numerator/denominator information; the construction intentionally uses their overflow/rounding behavior. This is exact Boolean computation on specially represented inputs, not expected TV risk over positive Markov sources.

The text itself says a corresponding multilayer tradeoff remains elusive (Conclusion, PDF p.9 / HTML Section 4). One cannot carry its one-shot communication bound unchanged through repeated access to evolved raw rows.

### Material internal inconsistencies in floating-point appendix

Printed Theorem C.2 (p.23), titled softmax, says m=p, calls both models linear, and claims an exact p versus p−1 threshold. Its proof (p.30) instead sets m=2p−1 and obtains an upper of p+log p+2. Lemma C.7 (p.27) states p>=m, while its proof gives ceil(m/2). Lemma C.8 supports the latter near-matching, logarithmic-gap construction. These are actual text inconsistencies, not a corrected theorem established by this audit. Cite the fixed-point Theorem 2.4 cleanly; qualify any claim about the floating softmax result and do not report its printed one-bit version as verified.

### Comparison verdict

Direct coverage: **No**. Precision-dependent expressivity and one-bit equality separations are prior. The theorem lacks the target's multilayer adaptive error quantifier, fixed positive-epsilon PreLN/full-norm envelope and Markov-TV objective. Neither its lower nor upper is a direct corollary route to the target.

## 3. Brösamle and Eckstein, ICML 2026 / PMLR 306

Primary landing page: https://proceedings.mlr.press/v306/brosamle26a.html . Audited proceedings PDF: https://raw.githubusercontent.com/mlresearch/v306/main/assets/brosamle26a/brosamle26a.pdf . Complete local files: sources/brosamle.pdf and sources/brosamle.txt. PDF page numbers below are internal 1–68, not proceedings pagination 9933–10000.

### Architecture and quantized objects

Section 2.2 (p.3) explicitly omits LayerNorm and RMSNorm; it remarks constructions could be modified to ignore normalization, but does not establish the target's epsilon-one/gain-two/full-norm theorem. Decoder layers have causal softmax, residual attention and ReLU MLP residuals. Output is an argmax token, not TV-calibrated softmax prediction. Proposition 3.1 recognizes regular languages; Theorems 3.2–3.3 simulate multitape Turing machines using ordinary/summarized CoT. Width and depth grow logarithmically in an input/time/space bound. Summarized CoT discards previous context in favor of a generated summary, unlike the target's single forward computation over all raw observations.

Definition B.18 (p.24) specifies normal floats and subnormals. With b_m mantissa and b_e exponent bits, E_min=2−2^(b_e−1), E_max=2^(b_e−1)−1, minimum positive subnormal is 2^(E_min−b_m), and maximum is (2−2^(−b_m))2^E_max. Rounding is nearest in that finite set. Lemma B.19 gives relative error <=2^(−b_m−1) on the normal range.

Definition D.4 and Remark D.5 (pp.48–49) are the key execution contract. Round q,k,v, individual attention-head outputs, multihead outputs, residuals, MLP hidden activations and MLP outputs to F_act; round normalized attention weights to F_att. Between these locations arithmetic is ideal. Scores and softmax computation are not rounded; high-precision accumulation errors are explicitly excluded. Errors are measured using maximum-over-rows coordinate infinity norms and attention-weight l1 differences. These are nearest-rounding errors, not arbitrary adversarial choices at every residual.

### Exact robust-conversion theorems

Lemma D.15 (pp.52–53) requires specialized hardmax constructions: sparse projection rows, disjoint output writes, tie-invariant values, ternary activations (raw MLP outputs may be ±2), and a unique output argmax margin >=1. Its MLP infinity norms are bounded by d and d_ff, not constant full Euclidean norm independent of growing width.

Theorem D.16 (p.53) converts such hardmax models to softmax, scaling Q/K by c sufficiently large in terms of width, depth and N, rounding activations but keeping attention weights exact. Its proof explicitly uses a recurrence epsilon_l<=A epsilon_(l−1)+B. Theorem 4.1 (p.7) specializes c_0=O_M((log ell)^(3/4)(log log ell)^(1/2)), requiring representability of c; activation exponent bits can be O(log log log ell).

Theorem D.17 (p.56) adds denoising: for c>=d_k^(1/4)*sqrt(log(96N)), activation format containing c with b_m>=1,b_e>=3, and attention format with b_m>=4 and 1/N>=2^E_min, a depth-2L softmax model with FF width max(d_ff,6d) exactly matches the hardmax output on the prescribed input set. Weight entries belong to {0,±1,±2,±c}. Lemma D.18 (pp.57–58) constructs a residual ReLU correction returning coordinate errors within 1/4 of ternary values to those values. Thus there is an explicit local error-correction mechanism, not only accumulated Lipschitz stability.

Theorem 4.2 (p.7) gives c_0=O((log ell)^(3/4)), same asymptotic model-size bounds, constant mantissa requirements, attention exponent bits O(log log ell), and activation exponent bits O(log log log ell). This low bit count relies on growing range, growing width, and growing Q/K scale. Complete state Euclidean norms and parameter norms are not frozen constants as in the target.

### Comparison verdict

Direct coverage: **No**. The conversion theorem is substantial robustness prior art, but its hardmax/ternary invariant, nonconstant width/score scale, absent mandatory positive-epsilon normalization, nearest-rounding execution, argmax task and optional CoT all matter. In particular the target cannot invoke D.17 without proving an admissible bounded-norm fixed-width PreLN compiler satisfying its hypotheses, which the current theorem does not supply.

## Consequences for the proposed research claim

1. Use p as an error-radius index, not a total arithmetic/storage-bit budget. An implementation theorem would need explicit range, overflow, rounded primitives and accumulated-error accounting.
2. The target erasure argument is a minimax disturbance argument; the papers' deterministic rounding results neither prove nor refute it.
3. Logarithmic-order matching at fixed risk is a possible narrower theorem statement only conditional on a verified suffix compiler. It is not a new general depth–precision frontier or a new roundoff law.
4. Existing prior already contains layerwise error recurrences and denoising. Strong novelty language needs more than the fact that these three sources do not state the exact target contract.
5. No search-negative inference is made. This audit is restricted to the three primary fulltexts and does not rule out other direct or indirect prior results.
