# Frozen comparison contract for the literature audit

6 November 2026 UTC. This document freezes the exact candidate being compared; it is not a novelty claim or a new theorem.

Target source: `../mother_theorem_reset_20261106/JOINT_PRECISION_BARRIER_AND_ROBUSTNESS.v3.md`, especially Sections 3 and 5. Its independently accepted result is conditional on the previously reviewed actual-network suffix compiler.

## Statistical object

- One raw binary history X_1,...,X_N from an unknown homogeneous second-order kernel with every transition in [c,1-c], fixed 0<c<1/2; arbitrary initial-pair law. The stationary subclass is included.
- Target: next-symbol law at the actual random terminal pair of this same history. Loss: TV of a probability vector, averaged over the source history.
- Fixed target risk 0<r<c(1-2c)/2. No vanishing-risk sharpness theorem. Weights are source-independent, may depend on N,c,r, and are not learned in the theorem.
- Robust risk: supremum over source AND admissible adaptive input-aware error policies of expected loss. Lower witness is a fixed positive first-order copy/flip chain, which is a member of the order-two class. Under arbitrary initial pairs require N>=3.

## Architecture

- N raw rows plus one source-independent synthetic terminal. No supplied suffix, counts or external raw-history readout.
- Full self-inclusive causal softmax attention; bounded head count and full value dimensions; positive-epsilon full-feature PreLN, epsilon=1, gain=2, zero shift; ordinary terminal affine-softmax readout.
- Width and sufficiently large complete state/matrix/bias/Lipschitz envelope fixed after c,r and the upper construction are chosen, before N varies. Not an assertion for arbitrary prescribed tiny norm budgets.
- Depth counts actual paid blocks. No polynomial padding, CoT tokens, sparse free suffix mask or discontinuous decoder.

## Error/precision contract

- Additive Euclidean perturbation of norm at most u=2^(-p) in each row after EACH attention residual sublayer and EACH FFN residual sublayer.
- Error can be adaptive, correlated across layers/rows, and input-aware. No zero-mean, independence, noise distribution or unbiasedness assumption.
- Raw inputs/positions and coefficients are exact. LN/softmax/affine operations inside the ideal sublayer are exact before the prescribed additive perturbation. Final output head is ideal.
- p is minus the log of an allowed error radius. It is NOT established as machine word length, mantissa bits, coefficient bits, quantized-state entropy, or a complete finite arithmetic implementation.
- Upper theorem proves a bounded-tube induction for every admissible error policy at its chosen p. Lower uses only terminal post-attention errors, leaving every other error zero; its hybrid trajectories stay bounded by clean executions.

## Exact conclusions to compare

1. Old exact execution sensitivity implies D>=Omega(log N) for the stated nontrivial fixed risk; no new sensitivity theorem claimed.
2. Repeated terminal erasure: when u>=C/(N+1), an admissible policy makes terminal prediction insensitive to the final raw token at every layer, giving robust risk at least c(1-2c), independent of depth.
3. Existing suffix compiler at fixed suffix length plus standard Lipschitz perturbation propagation gives D,p=O_(c,r)(log N), with B_coefficient=O_(c,r)(log N) only as an upper-construction cost.
4. Therefore matching logarithmic orders of D and p under this contract. No depth–precision exchange curve, coefficient-precision lower, deterministic rounding theorem, training theorem or universal novel frontier.

## Audit classification

For every primary theorem, record: exact source version/date; definition/theorem locator; perturbation object and injection point; adversarial/random/rounding quantifiers; norm and bounded-domain assumptions; precision exponent/range/accumulator semantics; architecture including LN epsilon, readout, masking, width and depth; probability/source and risk; relation to each conclusion above.

Use four distinct labels: exact coverage; direct mathematical consequence with explicit extra assumptions; related mechanism but materially different contract; unresolved because full text or hypothesis check is missing. A failed search or absent phrase is never evidence of novelty.
