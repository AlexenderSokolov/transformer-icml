# Independent targeted primary-coverage audit (revision 2)

6 November 2026 UTC. This checks selected consequential comparisons against primary passages and reviews the reduction ledger. It is neither an exhaustive literature search nor a novelty certification.

## Exact local bindings

- `FROZEN_COMPARISON_CONTRACT.v1.md`: `f43a535767380607be4be632554ceea8d34dc46314326b9d923609d41048b068`.
- `FINITE_PRECISION_PRIMARY_FULLTEXT_AUDIT.v1.md`: `79bbf0c4f29434ccdcecdbe9da9f175293ebde0dccd330eb0145d94cd325249f`.
- `MARKOV_NGRAM_EXECUTION_CONTRACT_AUDIT.v1.md`: `3685201f6c988550fd744bfec41938f55eaf628de013a1054387f321aad3e440`.
- `REDUCTION_AND_COUNTERCONTRACT_LEDGER.v1.md`: `0da5733122ca6be5fad09cac61744434db1cc2d5f67288fb1715124e8f1886f0`.

- `ATTENTION_ACTIVATION_PRIMARY_AUDIT.md`: `49010c8c9fdcd394c245b48ef5e960b169e63385aa050b33194cd565e4867ff2`.

Verdict: the key distinctions and reduction conclusions below are supported. Do not strengthen “not supplied by direct substitution of the inspected theorem” into a universal non-subsumption or novelty claim. Other detailed external statements in the companion audits retain their own stated verification scope.

## 1. Merrill–Sabharwal: verified correction

Inspected complete local primary PDF text, Section 2.1 and Section 3 Proposition 1, corresponding to [arXiv:2210.02671v7](https://arxiv.org/pdf/2210.02671v7). Precision p totals mantissa and exponent storage. Proposition 1 gives at most 2^(2^p) nonzero rounded attention entries and zero uniform attention when p<log2 log2 n. Thus the threshold from this proposition is double logarithmic in total floating bits. The O(log n) precision class studied later is not its necessary threshold.

The audit properly notes that attention nonnegativity is needed for the counting argument even though the printed proposition displays only the sum constraint. This issue does not affect application to attention probability vectors. Neither float underflow nor the logical expressivity theorem implies the candidate's logarithmic inverse-adversarial-radius threshold by renaming p.

## 2. Every Bit Counts: discrepancy independently confirmed

Inspected local primary PDF text for [arXiv:2602.02707v1](https://arxiv.org/pdf/2602.02707v1), Theorem C.2, Lemmas C.7–C.8, and the proof of C.2. The discrepancy is directly visible: the printed C.2 has m=p and a p versus p−1 statement, while its proof chooses m=2p−1 and cites a p+log p+2 upper. C.7 prints a p≥m bound but its proof yields ceil(m/2). These are textual statement/proof inconsistencies, not an independently established corrected theorem. The floating-softmax exact one-bit conclusion must remain qualified. The clean fixed-point result is a different cited result.

No conclusion that the entire paper or every theorem is false follows. Nor can its one-layer equality task establish the target's all-depth Markov-TV robust necessity without another reduction.

## 3. Brösamle–Eckstein: actual normalization and rounding scope

Inspected proceedings primary text Section 2.2, Remark D.5 and Theorem D.17. Section 2.2 explicitly omits LayerNorm/RMSNorm; an informal possible adaptation does not prove the target's fixed positive-epsilon normalization contract. Remark D.5 lists multiple rounded activation locations and rounded attention weights, while excluding higher-precision accumulation and softmax-operation errors. It is not an all-operation finite implementation.

D.17 really provides denoising conversion from its specialized hardmax class, with depth doubling, representability conditions and a Q/K scale growing with the context bound. Thus “only generic Lipschitz propagation exists in prior work” would be false. The companion audit correctly treats this as substantive nearby robustness machinery, while preserving its different invariant, task, range, width/score and normalization assumptions.

## 4. Hahn, Chiang–Cholak and all-layer margins

Independently inspected Hahn's Lemma 5 in the primary text and Chiang–Cholak Section 4, Proposition 2 (printed p.7659). Hahn's token-influence estimate is the inherited mechanism. Chiang–Cholak's arbitrary-small-cross-entropy normalization claim explicitly uses epsilon zero; the following paragraph says positive epsilon makes normalization Lipschitz and restores applicability of Hahn's lemma. It is incorrect to cite that epsilon-zero mechanism as a contradiction to the target's frozen positive-epsilon envelope.

Also inspected Wei–Ma Appendix A, printed p.16, equation (A.1): it allows arbitrary normed layer spaces and mixed norms over layer perturbations. Therefore a Euclidean-versus-maximum-row norm contrast alone is not a valid exclusion. Its perturbations are scaled by the preceding activation norm and its objective is a classification margin; translating to absolute rowwise disturbance balls and statistical TV requires explicit assumptions and a decision conversion. Prior all-layer adversarial perturbations must be acknowledged.

Inspected Castin et al. Theorem 3.5: an N-independent bounded-domain mean-field Lipschitz bound is present. A comparison mentioning only the earlier sqrt(N) Frobenius estimate would be incomplete. Whether such a bound transfers to an aligned causal max-row contract requires the appropriate metric and causal hypotheses; “no N-independent prior bound” is not supported.

## 5. Izzo–Nichani–Lee: primary checked

Opened [arXiv:2510.27015v1](https://arxiv.org/html/2510.27015v1), Sections 3.1–3.3, Theorem 4.2 and its following discussion, and Definition 5.1/Theorem 5.2. Section 3.2 thresholds small max-shifted exponentials before normalization. Combined with logarithmic score scaling, this produces hardmax at sufficient length; it is not the candidate's bounded-score residual perturbation model. Theorem 4.2 averages IID tokens under a Dirichlet categorical draw, and the following paragraph treats Markov average generalization as future work. The two-layer theorem uses infinite precision and restricted positional structure.

The Markov audit is correct on these central distinctions. Its warning is also sound: a pathwise empirical-conditional representation can be combined with a risk theorem, so “representation versus risk” alone is not a robust novelty boundary. The other Markov papers' detailed theorem locators were reviewed in the companion document, not independently re-fetched in this targeted audit.

## 6. Reduction ledger: independent proof check

For one changed source row and fixed terminal query, the common-rest decomposition gives output change at most 4V exp(B)/T: each special-row weight is at most exp(B)/T and each row differs from the common-rest average by at most 2V. Reapplying this after terminal reset produces the stated all-depth erasure coupling under an input-aware adversary. The statistical conversion is ordinary conditional binary geometry. The upper is standard full-program bounded-tube stability composed with the existing predictor.

Crucially, the erasure lower still holds if the fixed copy/flip source is known to the designer. Its obstruction is access to the last context bit, not estimation of an unknown transition matrix. The report's short-technical-combination assessment is therefore justified; it does not establish a new estimation frontier merely by including an estimator in the upper.

The nearest-rounding example is valid: 0.49delta and 0.51delta round differently, although allowed errors of magnitude 0.01delta can make both equal 0.50delta. Thus arbitrary-error erasure is not a deterministic-rounding lower. Conversely, an upper against every bounded error covers a concrete implementation only after its local errors are proved to fit that budget.

For N=2^k, 1/N has a constant-length normalized mantissa and an exponent with O(log k) bits. This supports the distinction between fractional grid resolution, exponent range, total floats and absolute error radius. None is interchangeable by terminology alone.

## Limits

No absence-of-phrase or failed-search argument was used as novelty evidence. Exact coverage, direct consequence with extra hypotheses, related mechanism under a different contract, and unresolved comparisons remain distinct classifications. This review supplies no publication or priority certification. No scientific model execution, training, upload, or visual report rendering was performed.

## 7. Completed attention-robustness companion review

Read `ATTENTION_ACTIVATION_PRIMARY_AUDIT.md` in full after the initial independent checks. Its distinctions for Hahn, Chiang–Cholak, Wei–Ma and Castin agree with the primary passages inspected here. Additionally checked Hahn's supplement Section S2, equations (34)–(35): it explicitly identifies the omitted attention-weight-change term, requires bounded positional embeddings and Lipschitz maps, and supplies its O(1/n) correction. A one-term value-only proof should not be reused.

Also independently checked Castin Theorem 4.4 and Definition 4.1: the masked mean-field result is N-independent in its conditional-transport metric and compares equal positional marginals. This confirms that both unmasked and masked positive bounds must be represented in the comparison. It does not by itself identify that metric with the target max-row norm.

Wei–Ma's norm generality and input-specific perturbations mean neither “non-Euclidean” nor “adaptive” alone establishes a new perturbation framework. The report correctly retains the state-norm scaling and classification/TV conversion obligations. The remaining Tsai and Haris theorem details were read in the companion audit but not independently re-proved here; their original verification and stated limits remain applicable. Any reported Haris display inconsistency should likewise remain a literal statement comparison, not an inferred corrected theorem.

The companion's recommended technical positioning is justified: generic sensitivity, all-layer perturbations and stability are substantial prior mechanisms. A separately formulated repeated-erasure lemma is not automatically a publication-strength contribution merely because no identical statement was located in this targeted collection.
