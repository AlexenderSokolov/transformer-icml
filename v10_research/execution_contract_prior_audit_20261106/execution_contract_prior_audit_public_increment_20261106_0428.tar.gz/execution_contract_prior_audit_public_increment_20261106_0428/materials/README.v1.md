# 执行误差合同的逐定理先行审计

2026-11-06 UTC。交付报告：`RESEARCH_REPORT.zh.v2.html`，77754 bytes，SHA256 `56fb0fed5684a9c58614cda94ff901bb155426e81625e10e0f51ef0bed2a4d5b`。8 个审计／定位／修订附录与来源哈希已嵌入。正文为中文，完整技术审计为英文。

## 结论

所查原文未直接给出完全相同的正 ε PreLN、有界范数、固定宽度、逐子层对抗误差和 Markov 终端 TV 组合；这不证明创新。单行敏感度、逐层扰动稳定性、精度表达界、同历史 n-gram 与量化预测已有重要先行成果。当前联合界应作为上下文访问鲁棒性的技术组合，而非已确认的母问题主创新。

## 重要修订

- Merrill–Sabharwal Prop.1 阈值为 log log N 总浮点位数，不是 log N；候选 p 为绝对误差半径指数。
- Brösamle–Eckstein 省略 LN/RMSNorm，但已有逐层误差递推与去噪。
- Wei–Ma 允许一般范数空间；Castin 同时有与 N 无关的 mean-field 结论，不能只引用 Frobenius √N 界。
- 同历史末端 n-gram、归一化和参数精度已有先行；Akman 明确包含逐层量化。
- Every Bit Counts 的浮点附录陈述／证明不一致已交叉核对；仅谨慎引用清楚的定点 Thm.2.4，不自行修复论文。

## 原文及版本

`FINITE_PRECISION_PRIMARY_FULLTEXT_AUDIT.v1.md`、`ATTENTION_ACTIVATION_PRIMARY_AUDIT.md`、`MARKOV_NGRAM_EXECUTION_CONTRACT_AUDIT.v1.md` 给出精确原文版本和定义／定理／页码定位。已获取的 PDF、提取文本与哈希在 `sources/` 和 `primary_attention_robustness/`；报告未嵌入整篇论文。

报告 v1 和定位表 v1 是被替代的过程记录，不是交付版本；定位表 v2 删除了非必要的内部引用编号，保留公开 URL 和可读定位。所有旧记录不覆写。最终报告 v2 使用净化后的定位表。

这是定向正文审计，不是穷尽检索或逐行证明复核。Wei–Ma 的特定 OpenReview 快照未访问成功，使用明确标注的 arXiv v5；其余访问边界见各审计。没有上传、购买、投稿或科学实验，未做视觉渲染验收。
