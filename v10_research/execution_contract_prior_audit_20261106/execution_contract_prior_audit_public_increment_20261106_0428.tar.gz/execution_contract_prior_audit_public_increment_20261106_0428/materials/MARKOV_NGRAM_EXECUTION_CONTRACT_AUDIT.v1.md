# Markov / n-gram primary-contract audit

6 November 2026 UTC. Read-only primary-body comparison against `mother_theorem_reset_20261106/JOINT_PRECISION_BARRIER_AND_ROBUSTNESS.v3.md`, especially Sections 3 and 5. No uploads, repository changes, numerical experiments, or priority claim.

## Target and conclusion

The candidate fixes an unknown homogeneous binary order-two source class with an interior transition floor, same-history actual-terminal expected TV, a synthetic terminal row, actual positive-epsilon PreLN, frozen full-state/operator/head envelope, and adaptive additive execution errors after each attention/FFN residual at every row. At fixed risk it proposes joint achievable logarithmic depth and execution precision, with separate necessities. Coefficient-description bits are explicitly different.

The checked Markov representation results already cover the important broad ideas: common source-independent same-history n-gram estimation, final realized suffix conditioning, constant width for fixed alphabet/order, normalized implementations, and logarithmic parameter precision remarks. These are not defensible novelty axes. The full candidate is not a verified direct corollary of the checked statements, because their architecture and execution/error quantifiers differ materially. This is not a novelty certification: the candidate's upper perturbation recurrence is generic stability bookkeeping once its noiseless compiler is accepted. The source-class/risk conjunction alone cannot establish new technique or priority.

## 1. Rajaraman et al., Transformers on Markov Data: Constant Depth Suffices

Primary checked: https://arxiv.org/html/2407.17686v1 . Locators: Section 2.1; Theorems 4.4, 4.5, 5.1; Remark 5.2; Architecture 0.2; Appendix C.1–C.3.

Theorem 5.1 represents conditional k-grams with three layers, one head each, relative positions and O(S) embedding dimension. The empirical distribution conditions on the final k symbols of the SAME input, not an independent suffix. This representation is pathwise rather than an expected-TV minimax theorem, so stationary versus nonstationary initialization is not a restriction of that representation claim. Appendix C.1 duplicates signs and replaces normalization by Euclidean normalization. Architecture 0.2's denominator has no fixed positive epsilon. The text also says Theorem 5.1 holds for their original architecture, so saying merely “not normalized” is wrong.

Remark 5.2 explicitly says its proof does not bound finite-bit approximation error; it suggests logarithmic-in-length plus order bits per parameter for O(1/T) error. Concentration uses an unbounded sharpening limit (e.g. Appendix A equations (10)–(13)); it is not frozen-score execution robustness. Thus it supplies estimator/normalization ancestry, not the candidate's adversarial-noise fixed-risk certificate.

## 2. Ekbote et al., What One Cannot, Two Can

Primaries: https://arxiv.org/pdf/2508.07208v2 and https://arxiv.org/html/2508.07208v2 . Locators: PDF printed p.7 Theorem 3 and Remark 2; Sections 2.1–2.2, 4; Appendices A.1, A.2.2, B, H.3–H.4.

Theorem 3 gives two layers, one head per layer, relative positions, MLP and layer normalization, dimension 6S+3. It computes the same-history empirical conditional k-gram at the actual final suffix. Representation is not a uniform minimax TV risk theorem. Experimental generation uses Dirichlet transition rows and uniform initial k tokens, not stationary initialization. Section 2.2 specifies ReLU output rather than ordinary vocabulary softmax. Appendix A.2.2 applies LN to projected keys/queries and sharpens cosine scores toward infinity; this is not positive-epsilon full-feature PreLN with frozen score envelope.

Remark 2 asserts sufficient parameter precision, written Ω(log T+k), with O(1/T) approximation error. Its wording must not be upgraded to a lower bound or to arbitrary after-every-sublayer execution-error certification. H.3 concerns input/dynamics noise, and H.4 empirical bit precision. Neither changes the theorem's error quantifiers into the candidate's adaptive all-row errors. Full PDF was essential: theorem text is missing from the HTML rendering around Section 4.

## 3. D’Angelo et al., Induction Heads Interpolate N-Grams

Primary: https://arxiv.org/html/2607.02800v1 . Locators: Sections 2.1–2.2; Definition 3.1; Proposition 3.1, equation (8); Sections 3.2.1–3.2.3; Corollary 4.1, equation (10).

Proposition 3.1 is explicitly for any input string: two disentangled layers with k heads then one head compute weighted mask-count probabilities. The final query context is that input's realized suffix. Source-independence and same-history prediction are genuine overlap. Fixed alphabet/order gives constant representation dimension. Section 2.2 uses uniform initial k tokens and Dirichlet or hierarchical priors; this does not restrict the pathwise proposition. Its probabilistic evaluation is not the candidate's supremum-over-interior-kernels TV guarantee.

Section 3.2.1 copies preceding symbols in an infinite positional-sharpening limit, and Section 3.2.2 suppresses early positions by another infinite limit. Finite context-matching beta therefore does not imply globally bounded scores. The architecture concatenates registers and selects output coordinates rather than imposing the candidate's full PreLN/softmax contract. Corollary 4.1 already implements additive smoothing through a BOS token in a hard-matching limit. No execution-noise theorem is supplied by these checked statements; this is a statement about their scope, not an exhaustive absence claim.

## 4. Izzo, Nichani and Lee, Quantitative Bounds for Length Generalization in Transformers

Primary: https://arxiv.org/html/2510.27015v1 . Locators: Sections 3.1–3.3; Theorems 4.1–4.2; Definition 5.1; Theorem 5.2; Lemma 5.3; Definition 5.4; Appendix B.3.

Section 3.2 specifies rounding small exponentials after max-shifting; with log-length score scaling, N≥2^(p/γ) gives hardmax. This differs from bounded-score adaptive additive residual errors. Section 3.1 has residual MLPs and linear unembedding, without candidate PreLN. Theorem 4.2 averages IID tokens under a Dirichlet-drawn categorical distribution; the following discussion leaves Markov-source average generalization open. Theorem 5.2 is worst-string agreement transfer for restricted two-layer infinite-precision transformers, not statistical next-token risk.

Lemma 5.3 compresses suffix-and-prefix-histogram averages; its proof's Markov chain selects a subsequence, not the prediction source. Definition 5.4 conditions empirical counts on the realized terminal suffix. The following paragraph expressly calls Appendix B.3's complexity estimate heuristic. Thus there is strong simulation/precision ancestry but no verified direct robust-minimax implication. The missing reduction would need to preserve the candidate's frozen scores, arbitrary growing depth, actual normalization, and error policy class, not just its n-gram target.

## 5. Akman, Feldman Starosta, Saldi and Yüksel

Primary: https://arxiv.org/html/2610.41038v1 . Locators: Sections 4.1.1–4.1.3, equations (17)–(21); Section 5 preamble; Theorems 26–27, equations (24)–(25); Appendix C.6, Definition 32 and Lemma 33.

Theorem 26 trains on one trajectory but explicitly tests independently. Theorem 27's expected-TV bound likewise uses an independent test history. The architecture has M gatherer layers plus an interpolator, dimension 2M+R(s)+1, supplied unmasked M-token windows, and ordinary final softmax. Its gatherers read protected token/position coordinates. This does overlap genuine TV prediction and bounded-window sufficiency; stationarity/interiority do not establish source disjointness.

Important precision overlap: Section 5 explicitly applies state quantizer Q_n and measure quantizer R_l after every layer. Theorem 27 includes quantization/training/architecture error; Lemma 33 uses aligning grids to preserve selected coordinates. This is NOT merely an exact-real predecessor. However, this specified quantized trained architecture does not yield the candidate's adversarial all-row, two-sublayer residual error model, nor its unknown-source common same-history predictor. Its actual update (19) is not candidate PreLN. A source-independent cost-preserving compilation would be additional work, not theorem substitution.

## Risk and implication checks

1. A pathwise approximation to empirical terminal counts can be composed with an estimator-risk theorem, so “representation rather than risk” alone is a weak separation. The essential remaining obligations are a uniform source-risk estimate plus the exact architecture/resource/execution compilation.
2. Uniform initialization in experimental/Bayesian sections does not restrict a theorem valid on every input string. Do not use it to claim a source-class separation.
3. An independent test trajectory is a substantive distinction for source-trained results; it does not apply to the common n-gram constructions.
4. None of these comparisons establishes a precision lower bound in the candidate model. In particular sufficient parameter bits cannot be substituted for execution precision or bounded-message cardinality.
5. Candidate Section 5’s stability upper is a generic consequence of an O(log N)-depth noiseless implementation with N-uniform sublayer Lipschitz constants: error ≤u·(Λ^L−1)/(Λ−1). Its scientific value must rest on a genuinely justified complete compiler and matching architecture-wide necessity, not presenting this recurrence as a new Markov theorem.
6. Candidate Section 3's erasure adversary has access to the input and cancels each terminal read. This is much stronger than deterministic hardware rounding. A comparison to threshold arithmetic cannot erase this distinction, and an upper for arbitrary errors does not make its lower hardware-realizable.

## Access and audit limits

All five linked primary HTML bodies were accessible. Ekbote's PDF was also opened and its theorem/precision statement verified directly. HTML math/cross-references sometimes fail; missing theorem rendering was repaired with the PDF rather than guessed. This was a targeted full-text-body/theorem-and-construction audit, not a line-by-line verification of every external proof, an exhaustive version/citation search, or a universal non-subsumption proof. Earlier local `CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md` supplied candidates only; conclusions above use fresh primary passages. No abstract-only theorem claims.
