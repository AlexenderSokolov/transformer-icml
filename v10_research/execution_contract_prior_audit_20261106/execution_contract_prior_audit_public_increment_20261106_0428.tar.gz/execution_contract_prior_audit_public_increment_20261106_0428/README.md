# Execution-contract prior audit: public research increment

This local additive package preserves all available original-authored audits, per-theorem locators, quoted passages, corrections, old report versions, independent reviews, scripts and QA. It does NOT redistribute fetched third-party paper PDFs or extracted full texts. Those are inventoried by original path, byte count and SHA-256, with public source/version locators retained in the audits and manifests. Original local sources were not changed; no GitHub write occurred.

Open materials/RESEARCH_REPORT.zh.v2.html for the unchanged final report with eight exact appendices. Locator table v1 and historical HTML v1 are neutral public derivatives: internal retrieval IDs are replaced by a neutral status field, preserving public URLs and readable locators. Only the corresponding HTML appendix and displayed hash change. Source/public maps disclose exact identities and transformations.

Original v1 bindings/QA remain unchanged historical records of original bytes, not validations of the neutral derivative. HISTORICAL_V1_PUBLIC_BINDINGS.json binds current public v1. The old v1 checker is not directly compatible with the neutral locator. Final v2 and its bindings remain exact. The original README's local PDF/text availability refers to the source archive, not this public package.

## Findings and uncertainty

The audited papers did not directly supply the exact combined positive-epsilon PreLN, bounded norms, fixed width, adversarial per-sublayer execution-error and Markov terminal-TV contract. This does not prove novelty or absence of relevant prior work. The joint bound remains a technical composition of context-access robustness, not a certified mother-problem innovation. Literature coverage is targeted, incomplete and version-specific; some access limitations and inherited checks remain explicit.

Precision definitions must not be conflated: Merrill-Sabharwal Proposition 1 uses a log-log-N total floating-point-bit threshold; the local p is the exponent of an absolute adaptive error radius. Row sensitivity, normed-space perturbation recurrences, mean-field versus Frobenius bounds, same-history n-gram estimation and layerwise quantization have material prior art. The Every Bit Counts floating-point statement/proof discrepancy remains an unresolved source inconsistency; only clearly stated fixed-point Theorem 2.4 is relied on cautiously. No external paper is silently repaired. The unavailable specified Wei-Ma OpenReview snapshot is not claimed inspected; the explicitly identified arXiv v5 substitute remains documented.

Inputs, coefficients, internal sublayer arithmetic and final output remain ideal under the local contract. Execution error is not automatically storage bits, coefficient bits or floating-point mantissa precision. No new statistical rate, trained model, complete mathematical reproof, formal verification, external peer review or novelty certification is supplied.

## Rights, validation and use

Original analytical comparisons and short attributed quotations are preserved as documentary evidence; complete third-party papers/extractions are omitted. This scoped copyright review is not legal clearance and adds no license. Privacy review removes internal retrieval identifiers and checks for secrets, personal data and private machine paths. Remaining relative research locators are documentary identifiers, not guaranteed live links.

No scientific experiment, model execution or training occurred. Document parsing is not numerical scientific acceptance. Visual acceptance is NOT COMPLETED. External proof and full primary-contract coverage remain OPEN. This is not a recovered complete v10 corpus.

SOURCE_DERIVATION_MAP.json covers included and omitted sources; THIRD_PARTY_SOURCE_INVENTORY.json records non-redistributed evidence. PACKAGING_QA.json separates fresh checks from immutable historical QA. independent_review/ contains review records. SHA256SUMS and python verify_package.py provide read-only integrity checks. Existing build/check scripts write outputs and must only run in a disposable copy with the historical v1 caveat understood.
