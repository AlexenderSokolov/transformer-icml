# Independent exact-file audit: weak-anchor low-risk PreLN composition

5 November 2026 UTC. This new review preserves all candidate revisions and prior artifacts.

## Verdict and exact accepted version

**PASS for candidate v4, conditional on the specified imported suffix/statistical and normalized padding/restoration lemmas. No blocking mathematical gap remains in the composition.**

Accepted source: `LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md`.

SHA-256: `d51e74e89a452411d6eb6ffd6ab393fc3417f95aaed75e8a10dd20f4a970b5cb`.

This reviewer did not author the candidate. Candidate v2 was read in full. The exact v2-to-v3 and v3-to-v4 changes were then inspected; together they cover the complete accepted v4 text. The relevant source construction, PreLN compiler, ordinary-softmax conversion, normalized frontier, causal witness, and anchored-dependence theorem had also been directly read and audited or checked by this reviewer. Their current bindings are recorded below.

The accepted content is a growing-anchor, three-useful-read, exact-real PreLN construction that preserves the existing suffix statistical rate while adding a deliberately negligible but genuinely detectable interaction. It is not a theorem about arbitrary repeated self-attention, fixed-anchor consistency, statistical improvement, or novelty.

Only source reading, exact textual comparison, paper derivation, documentary integrity hashes, and writing this new review were performed. No scientific program, numerical assertion script, parameter generation, model execution, training, upload, or public repository mutation was performed.

## 1. Corrections required and verified during this review

The initial v2 ablation paragraph contained two inaccurate justifications. They were reported and corrected before acceptance:

1. Zeroing the suffix attention output need not make the subsequently reconstructed code exactly zero. The approximate square/polarization circuit may leave a nonzero residual. The correct argument compares against target code zero, uses the existing error bound `3 B^(-b)/1024`, and applies the exact digit-plateau induction. This proves that all decoded digits are zero/default, which is the property actually needed. Candidate v3 and retained v4 make this distinction.
2. Fixed-floor clipping can reduce the separation of the two extreme suffix estimates when a>1/b. The correct lower bound uses u=max(1/b,a)<=1/4 and v=1-1/b>=3/4. Their clipped-and-normalized separation is (v-u)/(v+u)>=1/2. Subtracting the stated log-approximation and weak-perturbation allowances leaves more than 1/4. Candidate v3 and v4 use this bound instead of claiming no reduction.

Candidate v4 additionally makes the resource choices and ablation comparison explicit: maximal admissible dyadic accuracies, the least admissible amplitude exponent M, and one joint fixed tube/envelope chosen before parameters. Original and all three single-head-ablated runs use the same physical parameters, padding circuit/accuracy, restoration coefficient sequence, and final head; only one specified attention output matrix is zeroed. This prevents an ablation comparison from silently retuning the network.

Preserved revision bindings:

- v2: `adcdb9ead2e570bc0ce284ed5aebe07993059f41ec054a4258328e37455d7300`.
- v3: `b36abca84cf3ce7989e7b2a7d5c982df29cd59c38ec6ada228148979595cfd08`.

This verdict binds v4, not the superseded v2 justifications.

## 2. Quantifiers, interface, and allowed anchors

Fix a known c in (0,1/2). For N>=6 and each power-of-two b with 4<=b<=N-2, the construction may depend on N,b,c and its frozen resource constants, but not on the unknown transition kernel, stationary distribution, or sample. The source class is exactly the stationary binary second-order P_c with both output probabilities at least c in every context.

Its input consists only of raw binary onehots, public t/P, and the synthetic zero-symbol row T=N+1. Initial paired shadow copies duplicate only those permitted local inputs and a public constant. They do not supply suffix counts, context labels, observed anchors, or prior-token features.

The public anchor set is

    S={1} union {N-b+1,...,N}.

Because b<=N-2, the suffix begins at position at least three. Therefore the two sets are disjoint, |S|=b+1, and x2 is a genuine nonanchor. This includes the smallest permitted case N=6,b=4. The anchor cardinality grows with b; it is not a fixed-s consistency theorem. In particular the finite-branch communication cost may grow exponentially in the Bob-owned portion of this anchor set.

## 3. One logical program, not parallel normalized subnetworks

The candidate correctly rejects direct parallel concatenation of independently normalized physical networks. Full-feature LN would couple their means and norms, and approximate residual overwrites would not by themselves preserve exact zero support.

Instead, it defines one enlarged bounded affine/ReLU/uniform-attention reference program. The existing general-b suffix estimator supplies q. Paired raw shadows are kept unchanged. Two subsequent reference averages and local gates compute the weak witness while leaving the q bank unchanged. A serial clip/log circuit, a paid addition to one logit, and final preparation complete the same logical program.

All these registers coexist within a fixed binary-width allowance. The number of registers does not grow with b, N, or c. Serial source/readout/logarithm/arithmetic repetitions are paid as depth rather than simultaneous lanes. Values, complete logical states, and all per-step matrices remain uniformly bounded; constants may depend on c once logarithm and output scaling are included.

The reference witness formulas are correct. With tau=3/(2P), the fresh g gate equals 1/(2P) only at row 1 with x1=1. Uniform averaging gives r_t=1/(2Pt) in that case. The local gate produces bw_i=r_i for observed binary-one tokens and zero otherwise, including at the synthetic row. Consequently

    f_T=(1/(2PT)) sum_(i<=N:x_i=1) 1/i

when x1=1, and zero when x1=0. In all cases f_T<=H_N/(2PT). These are logical reference formulas; the candidate does not incorrectly assert their exact numerical values for the later physical PreLN simulation.

## 4. Three-read small-amplitude compilation is justified

The physical computational state is h=eta z with complete sign pairing. Biases are homogenized against a preserved anchor, and all fresh/shadow registers are included in the recomputed full-state norm. With interior gain one, LN(h)=eta s(z)z, where s(z)=(1+eta^2||z||^2/d)^(-1/2).

A standard shallow residual FFN for homogeneous F-I gives the exact analytical-coordinate update

    z_new=z+s(z)(F(z)-z).

Its deviation from the reference F(z), on a fixed one-unit tube, is bounded by C eta^2. Logical shadow/anchor coordinates whose residual injections are zero remain physically unchanged exactly, not just within the error tolerance.

For each of the three uniform attention stages, the actual update replaces each source z_i by s(z_i)z_i inside its value average. The resulting max-row local error is at most

    ||B|| ||A|| Z^3 eta^2/(2d).

Uniform averaging has norm at most one in max-row Euclidean norm, independently of prefix length. Thus the same fixed L and C give e_l<=L e_(l-1)+C eta^2 and e_l<=C eta^2 L^m through the full reference program. There is no step in this recurrence that requires only one attention invocation. The three occurrences are explicitly counted in m; no hidden invocation or exponentially growing per-step constant is introduced.

Each local primitive is compiled as a complete PreLN block with zero attention; each useful average is a complete block with zero FFN. Copies, clears, the two-ReLU suffix-value injection, serial spline terms, and preparation all use counted shallow operations. Useful attention destinations are fresh zero banks.

The joint reference envelope can include the three single-head-ablated programs. Suppressing either witness head only removes bounded witness values. Suppressing the suffix head yields the valid default-word decoding described below, so its source trajectory also remains within a fixed bounded reference envelope. This justifies one common tube and parameter choice for all four programs.

The final logit-bank scaling and full-vector padding/restoration lemmas depend on the bounded paired output bank, not on the number of preceding attention calls. Recomputing their constants for the enlarged physical dimension is therefore legitimate. Approximate final clearing is harmless because its residual garbage is included in the full-vector error estimate and there are no remaining useful reads.

Finally, gain-two interior LN with halved consuming FFN first matrices and value matrices exactly reproduces the gain-one physical trajectory. Queries and keys are zero. Final LN already has gain two. This verifies the declared genuine all-feature epsilon-one/gain-two/zero-shift PreLN syntax and ordinary final affine vocabulary head, without an external inverse normalization or probability-repair tail.

## 5. Exact support must be proved physically, and is proved here

### First useful read

The dedicated suffix-value bank begins at zero and is never approximately cleared for reuse before injection. The raw symbol shadow and anchor are exact physical coordinates. In analytical coordinates, qweight and interval-gate coordinates differ from their reference values by at most xi<=1/16. Outside the suffix, each value ReLU argument is therefore at most

    1/B-1+2xi<0.

Both ReLU contributions are exactly zero there. The fresh destination stays exactly zero, while sign-paired output injection preserves the complete mean-zero identity. Its subsequent full-feature LN preserves the zero value coordinate. This is an exact support invariant, not an assertion that an approximately zero value is zero.

All states before this read are token-local, and all score weights are exactly uniform. Thus only suffix-token-dependent values communicate, with no token-dependent denominator leakage. After the read, each physical row depends only on its own token and the suffix anchors. The preserved outside-token shadows can affect their own row's local norm, but cannot introduce communication through an exactly zero value or a public uniform denominator.

### Second useful read

The g destination is fresh. Its injection uses only preserved raw shadows, public position, and the constant anchor. Hence its sign is determined exactly by the public-grid gate, even though its positive LN amplitude may depend on the rest of the row. It is zero except at row 1 with x1=1. Pairing and the next normalization again preserve these zeros.

The nonzero row-1 value can have no forbidden dependence. It is already a function of its own token plus permitted anchors; causality in fact prevents future suffix dependence at that row. Uniform scores again prevent denominator leakage. Consequently the second read adds only the anchor x1 to the allowed dependence set.

### Third useful read and subsequent states

Before the third read, every physical state, including full-LN scaling factors, is a function only of (x_i,X_S) and public quantities. Its values need not be sparsely supported; that same dependence is exactly the anchored condition. The third read can introduce other nonanchor information into later states, but there is no fourth useful read. Only the terminal row is used by the remaining positionwise output computation. No future-to-past broadcast, nonstandard mask, cropped input, or exact residual clearing is assumed.

## 6. Strict usefulness survives the physical approximation

The reference suffix output at T is unchanged when x2 is toggled, because the suffix excludes position 2. Its clipped/logarithmic outputs are consequently unchanged. At x1=1, the witness changes f_T by exactly 1/(4PT), so the one-logit perturbation changes the reference logit difference by delta/(4PT), where delta=1/b.

All relevant reference logit differences and the intervening segment lie in the fixed interval [-M_c,M_c], with M_c=log(1/a)+3. Therefore the logistic derivative has the stated positive lower bound nu_c. Reference probability separation is at least nu_c delta/(4PT).

The final per-coordinate physical logit error at most zeta implies output TV error at most zeta, conservatively. Choosing zeta<=nu_c delta/(32PT) leaves a strictly positive separation after subtracting two such errors. Thus x2 has real, noncanceling influence in the physical terminal function, not just in the reference arithmetic.

The same common physical parameters also certify each witness head's usefulness. Zeroing either corresponding output matrix makes f_T=0 in the matching reference program. With x1=1 the original reference f_T is at least 1/(2PT), so its probability separation is at least nu_c delta/(2PT). The same two-zeta allowance preserves a strict difference. Neither ablated network is separately recompiled or retuned.

For the suffix head, use the all-binary-one history and identify source symbol 1 with default binary zero. The original suffix count/readout formula at G=b gives q1=1-1/b. The ablated average is zero. The existing product-recovery bound applies relative to target code zero even if its computed intermediate is not exactly zero. Digit plateaus then recover b exact zero/default digits, yielding q1=1/b by the same restoring-readout formula. This also establishes the bounded reference envelope for that ablated source program.

The corrected clipping margin is at least one half. Each serial-log approximation changes probability by at most 1/64, and the weak added logit changes each by at most 1/16 under the candidate's loose bounds. Thus reference separation exceeds one quarter. The zeta allowance is much smaller: nu_c<=1/4, delta<=1/4, and PT>=56. The common physical approximation preserves this separation. All three invocations are therefore useful in the stated ablation sense.

## 7. Depth, precision, width, norms, and probability risk

The source, serial logarithm, and witness reference program has depth O_c(log(N+1)+b), before final accuracy-dependent padding. The largest-admissible-dyadic choices make log(1/xi), log(1/kappa), and log(1/tau_restore) all O_c(log(1/zeta)). Least-admissible M then has order m+log(1/xi). Padding and restoration are paid with this same order, rather than being free or multiplied together without accounting.

Taking zeta within a factor two of nu_c/(32bPT) gives

    log(1/zeta)=O_c(log(N+1)+log b).

Hence total depth, including embedding, all complete blocks, final LN, affine head, and softmax, is O_c(log(N+1)+b). Maximum coefficient-description length is of that same order, and fixed-width dense untied descriptions cost its square. These are exact-real parameter descriptions, not finite-word execution precision.

The finite union of source, witness, logarithm, padding, and restoration envelopes supplies one c-dependent norm/Lipschitz tuple before N and b vary. Complete physical states, pre-normalization states, FFN hidden vectors, individual matrices, full biases, values, and logits are covered. Fixed shadows and fresh banks add constant width and norm overhead, not b- or N-dependent fanout. No c-dependent number of registers is needed: scaling constants and envelopes can depend on c while width stays an absolute binary constant.

There are exactly three useful scalar-value zero-score heads, with one head per useful block. Dense useful attention is O(N^2) up to this fixed factor three; paid local work and the more conservative dense-dummy ledger are as stated. Rolling storage remains O(N) real slots at fixed width.

The imported q risk is uniform over arbitrary initial laws, hence covers the induced suffix initial law under every stationary source in P_c. Clipping cannot increase error against an interior target. The serial-log error, weak perturbation, and physical output error then give

    sup_(P_c) E TV(Q_N,p_actual)
      <=13 sqrt(32/(b-1))+1/b+1/(4b^2)+H_N/(8bPT)+zeta
      <=C_c/sqrt(b).

All added approximation bounds are all-history bounds, so no independence of terminal context, counts, anchors, or perturbation is required for this expectation. Actual final softmax gives exact probability mass and strict positivity. The bounded-logit restriction is intentional: the claimed risk class has known fixed interior c, not unrestricted deterministic boundary sources.

## 8. Exact source bindings and evidence limits

Current bindings checked for the imported construction and reviews:

- `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`: `ea1c3788f4eed06ccba9e19db3ee0d9a3e792bda7d3d620c0326cc4a07cecbb6`.
- Its `INDEPENDENT_CONSTANT_WIDTH_AUDIT.v2.md`: `a2e2cde83de80f166f8fbd0002ad226a10a11c5219eaf90e0932ef533256be55`.
- `../standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md`: `b71f919d6ad1f9c5038270090a3ca724b4e7cb7f9074ecf060433a1961b737e5`.
- `../softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md`: `6d61e56d8e9ecea7c1a4a76c6e839f3cdc91576161e99f133febedfe03b5faa5`.
- Its `INTERIOR_SOFTMAX.candidate.v2.architecture.review.v1.md`: `32106ffe6ad40862fbd7240b8ff5cac44511f1a31aaad0ac435c82442b79e7a3`.
- `../normalized_stationary_frontier_20261105/NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md`: `624219c736392dc9fc755f9d6e32e33b40cf13005436589b85df0a6e4ac90770`.
- `CAUSAL_PRELN_ANCHOR_WITNESS.candidate.v1.md`: `1ff194ebc9faad5dd8513efb84863df764277e42906c632b8def9edb35b9d43c`.
- Its `INDEPENDENT_CAUSAL_PRELN_ANCHOR_WITNESS_AUDIT.v1.md`: `c3b09793a61ef15336385fdd5a396e256f35c891f748134d4c198154e9e7d275`.
- `ANCHORED_MEMORY_EXTENSION.candidate.v1.md`: `b805fe74f02bbd61f2f27a59506aff98bf3ebf8942c90acb1d0521f898d71acb`.
- Its `INDEPENDENT_ANCHORED_MEMORY_AUDIT.v1.md`: `4b0bcaeed443e7fa2346935f254ef2410a258e46119915eee76bae66dd10bd29`.

The suffix statistical theorem and the full transitive packing/arithmetic/padding proof chain are imported, not independently rebuilt from first principles in this review. Their hypotheses and application to the enlarged program were checked. No new primary-literature search or novelty assessment was performed. The anchored communication theorem's general proof and its external statistical dependencies were not newly re-proved; only the physical dependence/stability membership needed here was checked.

The old suffix estimator supplies the entire O(b^(-1/2)) statistical rate. The added interaction is only O(log N/(bN^2)) at the logical terminal output, with smaller physical error. Because s=b+1 grows, this does not prove consistency at fixed anchor count, improve the one-use frontier, establish a bounded separable rank through LN, or yield an advantage from repeated attention. No general Transformer, PostLN, training, floating-point, or statistical-innovation claim is certified.

Acceptance is exact-file and conditional as stated. Later edits require a renewed review; scientific execution remains subject to its separate pre-run and complete-capture requirements.
