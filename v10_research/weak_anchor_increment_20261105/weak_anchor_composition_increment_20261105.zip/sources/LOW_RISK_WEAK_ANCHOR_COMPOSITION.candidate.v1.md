# Low-risk PreLN prediction with a weak causal anchor interaction

Private analytical candidate v1, 5 November 2026 UTC. Frozen for independent paper review. This is a deliberately weak composition of existing constructions, not a new prediction rate or a fixed-anchor consistency theorem. No scientific executable, numerical diagnostic, model run, parameter-generation script, upload, or public mutation was performed.

## 1. Precise claim and what changes

Fix known c in (0,1/2), and the stationary interior binary second-order source class P_c of NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md. For N>=6 choose a power-of-two suffix length b with 4<=b<=N-2. There is a fixed-width raw-token causal PreLN network with all-feature positive-epsilon LN, ordinary affine vocabulary logits and vocabulary softmax, exactly THREE useful zero-score scalar-value attention invocations, and

    D=O_c(log(N+1)+b),
    sup_(p in P_c) E TV(Q_N,p_actual) <= C_c/sqrt(b).

All complete states, matrices, full biases and primitive Lipschitz constants lie in one finite c-dependent envelope, chosen before N and b vary. Width is one absolute finite constant for binary input, enlarged by a fixed number of shadow/witness registers. Norm constants may depend on c. This is a PreLN-only result.

At every useful read, every nonterminal K/V bank depends only on its own raw token plus anchors

    S={1} union {N-b+1,...,N}.

Thus s=b+1, and s grows when consistency is requested. The last two useful invocations implement an actual causal anchor interaction; each changes some realized terminal outputs, and changing x2 with x1=1 changes the output. Here x2 is outside S because b<=N-2.

The added interaction is only an O(log N/(bN^2)) logical-output perturbation. The physical approximation is chosen smaller than its separation margin. The original suffix estimator supplies the entire statistical rate. For b of order log N this is still the already-known O((log N)^(-1/2)) upper at logarithmic depth. No advantage from repeated attention is proved. The result is NOT a combination in a class with a fixed, N-independent number of anchors.

## 2. Why direct concatenation is not used

Two already-normalized networks cannot simply be placed in parallel banks and assumed to retain their old outputs: full-feature LN mixes the norms and means of both banks. Moreover, the existing small-amplitude compiler performs approximate overwrites and clears, not exact logical overwrites. An approximation guarantee alone does not establish the exact support of attention values, hence does not establish anchored membership.

We instead build one bounded logical reference program, preserve explicit raw shadow registers, certify exact physical zero support at the first two reads, and rederive the small-amplitude error recurrence for all three reads. Final normalization and ordinary vocabulary output are recompiled for the combined full feature dimension.

## 3. Logical reference program

### 3.1 Existing suffix estimator

Use the reviewed binary source program CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md with G=b and a suffix of b symbols. Its general-b form is established in NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md. It has one useful uniform scalar head, bounded constant-width local operations, exact all-row simplex output q, and

    E TV(q,p_actual) <= 13 sqrt(32/(b-1))+1/b,
    D_src=O(log(N+1)+b).

The source's scalar attention value is

    v_i=sum_(a=1)^2 a ReLU(qweight_i+x_i(a)+I_i-2),

where I_i selects the suffix exactly on the public position grid, and 0<qweight_i<=1/B for the fixed integer base B>=4(2+1). Outside the suffix I_i=0, so EVERY ReLU argument is at most 1/B-1< -3/4. The synthetic row is excluded. Pre-head computation is entirely token-local.

For the compilation below, allocate a dedicated v register that starts at zero and is untouched until this displayed value is written by ONE residual ReLU injection. No previously nonzero destination is approximately cleared to serve as this value register. This is only a constant-width/local scheduling modification, not a new algorithm. The two ReLU terms can be evaluated in one fixed-width FFN injection with fixed coefficients. The attention destination is a separate initially-zero bank.

Keep separate paired shadows of the original onehot, public p_i=i/P, and the constant anchor 1 unchanged through the computational program. The source may clear its own working copies, not these shadows. They add only fixed width and a fixed complete-state norm. At T the shadow onehot is zero.

### 3.2 Two extra logical witness heads

After the source computes q, keep q in a reserved bank and use fresh g,r,bw,f registers, all initially zero. Let tau=3/(2P). Compute

    g_i=ReLU((tau-1)anchor-p_i+shadow_x_i(1)).

This equals 1/(2P) only for i=1 and x1=1, and equals zero everywhere else. The next useful uniform head writes

    r_t=(1/t) sum_(i<=t) g_i.

Thus r_t=1/(2Pt) if x1=1, and otherwise zero. Compute the local witness gate

    bw_i=ReLU(r_i+shadow_x_i(1)-anchor).

It equals r_i for observed token 1, and zero for token 0 and the synthetic row. The THIRD useful uniform head writes

    f_t=(1/t) sum_(i<=t) bw_i.

At T,

    f_T=(1/(2PT)) sum_(i<=N:x_i=1) 1/i     if x1=1,
    f_T=0                                 if x1=0.

Therefore 0<=f_T<=H_N/(2PT). Every other row also has bounded f_t. The q bank is untouched by these logical witness operations. All complete logical states remain bounded uniformly in N,b; primitive maps have fixed bounds and depth increases only by a constant number of blocks.

### 3.3 Bounded ordinary logits and weak perturbation

Let a be the largest negative power of two not exceeding c. Apply the existing fixed-floor clip/serial-log construction to q, obtaining ell with

    ||ell-log(max(q,a))||_infinity <= epsilon_log=1/(4b^2).

The serial circuit costs O_c(b) depth at fixed width and has uniformly bounded full states and matrices. Define delta=1/b and logical logits

    L0=ell0, L1=ell1+delta f.

Their ranges are bounded by a constant depending only on c. The addition is one paid bounded affine primitive, not an external readout. Let Qref=softmax(L). No actual network softmax is used in the reference arithmetic before final compilation; Qref denotes the mathematical output comparator.

By the existing clipping inequality and binary-softmax derivative bound,

    E TV(Qref,p_actual)
      <=13 sqrt(32/(b-1))+1/b+epsilon_log+delta H_N/(8PT).       (1)

The last term uses |sigmoid'(z)|<=1/4 and changes only one logit. A looser delta/4 bound is also sufficient. The entire rate comes from the suffix estimator.

## 4. Small-amplitude PreLN compilation with three useful heads

This section explicitly extends the local recurrence, rather than quoting an unproved multi-head version of the earlier compiler.

Represent every logical register in paired physical coordinates and include fixed paired anchors. Write h=eta z, eta=2^(-M). All computational-step anchors and shadows are unchanged physical coordinates. With interior gain one and epsilon one,

    LN(h)=eta s(z)z,
    s(z)=(1+eta^2||z||^2/d)^(-1/2).

For each homogeneous local reference overwrite F, a standard shallow FFN implementing F-I gives exactly

    z_new=z+s(z)(F(z)-z).

On a fixed one-unit tube around the bounded reference trajectories its error against F(z) is at most C eta^2. All old normalization statistics include the NEW shadow and witness registers; the full tube radius and constants are recomputed once for this enlarged program.

For EACH uniform-attention reference step

    z'_t=z_t+B(1/t)sum_(i<=t) A z_i,

the physical block performs

    z'_t=z_t+B(1/t)sum_(i<=t) A s(z_i)z_i.

The max-row local error is at most ||B||||A||Z^3 eta^2/(2d), uniformly in t. This applies to all THREE attention steps separately. Uniform averaging is length-independent in max-row norm, so one common L>=2 bounds all reference stages. With m total counted logical stages,

    e_l <= L e_(l-1)+C eta^2,
    e_l <= C eta^2 L^m.

Choose eta so that the last expression is at most xi, where xi<=1/16 is specified below. The usual tube induction closes. No dependence on the number of heads is hidden beyond their inclusion in m; the number is exactly three. Every useful head is a complete PreLN block with zero FFN, and every local primitive is a complete block with zero attention. Dummy normalizations remain present. Fresh destinations are used for all three average writes.

For final conventional output, use the same paid logit-bank scaling, full-vector norm-padding circuit, bounded-gain radial restoration, final LN and affine vocabulary head as INTERIOR_SOFTMAX.candidate.v2.md Section 5. It depends on a bounded paired logit bank, not on where its values originated. Choose the scaling constant large enough for the bounded L, and use padding accuracy kappa, computational accuracy xi, and restoration coefficient accuracy tau_restore all small enough that the final physical logits differ from L by at most zeta. Its proof gives the explicit sufficient inequality

    C_out[2xi+7(C_pad kappa+C_norm xi)+2tau_restore] <= zeta.

Choose each as a sufficiently small positive dyadic below zeta/[100 C_out(1+C_pad+C_norm)]. All constants concern the enlarged bounded program and are frozen with c. Full-vector clearing at this FINAL stage may be approximate; there are no more useful reads, so it does not affect the membership proof below. Final output is ordinary vocabulary softmax, not a projection interpreted as probabilities. Binary output TV from Qref is at most zeta (a conservative bound).

Finally use the already-exact equal-gain reparameterization: replace each interior gain-one LN by gain two and divide every consuming FFN first matrix and attention value matrix by two. Q/K are zero. Physical states remain exactly the same; final gain was already two. Thus every LN has the same epsilon-one/gain-two/zero-shift convention as the normalized frontier.

The resulting depth is

    D=O_c(log(N+1)+b+log(1/zeta)).                          (2)

This includes logarithm, padding, restoration, all three useful heads, embedding, final LN, affine head and vocabulary softmax. No high-depth local decoder is placed outside the stack.

## 5. Exact anchored membership of the PHYSICAL network

Approximation of logical states is not itself sufficient; the following zero-support invariants are needed.

### 5.1 First head: exact suffix support

At the dedicated value injection, physical qweight and interval-gate coordinates differ in analytical logical coordinates from their reference values by at most xi<=1/16. Shadow symbol coordinates and anchor remain exactly original. Outside the suffix each ReLU argument is therefore at most

    1/B-1+2xi <0.

Positive homogeneity and the common positive LN factor preserve this sign. Each contribution is EXACTLY zero, and the dedicated value register was zero beforehand, so it remains exactly zero outside the suffix. The subsequent attention LN also preserves that zero coordinate because the whole physical state is paired and mean zero. The first attention uses zero scores, so its denominator is exactly t and contains no token-dependent leakage.

Before this head, all states are token-local. Hence its outputs depend only on suffix token values plus the own row's prior state. All subsequent local computational states, until the next head, depend only on (x_i, X_suffix) and public information.

### 5.2 Second head: exact position-one support

The g bank is fresh and initially zero. Its injection reads only the unchanged raw shadows and anchor. Its physical value is a common positive scalar times

    ReLU((tau-1)-p_i+shadow_x_i(1)).

Thus it is EXACTLY zero except at i=1,x1=1, even though other scratch registers and full LN norm can depend on the suffix. The head again has public denominator t and zero scores. Therefore it introduces no dependence outside S=suffix union {1}. Its value at row 1 may depend on existing permitted anchors; that is allowed by the anchored condition. Causality actually prevents suffix dependence at row 1 when the suffix starts after row 1, but this stronger fact is unnecessary.

### 5.3 Third head and final continuation

Before the third head, all physical rows depend only on their own raw token and X_S. Its values may be nonzero at all positions and may involve full LN coupling, but remain functions of exactly those permitted inputs. That is the required anchored-bank condition. The third head can introduce wider dependence into post-head states; there is no later useful read, so this does not violate the condition on banks used AT reads. Subsequent arithmetic is positionwise.

All masks are the standard inclusive full prefixes; only value coordinates have proved zeros. There is no backward broadcast, extra positional mask, cropped raw input, exact-clear assumption, or supplied history-dependent feature.

## 6. Preserve genuine but very weak usefulness after compilation

The approximation target must be smaller than the witness separation; choosing only the statistical error scale would not certify this.

Let M_c=log(1/a)+3 and

    nu_c=min_(|z|<=M_c) sigmoid'(z)>0.

All reference logit differences, including the weak perturbation, lie in this interval. For two histories differing only at x2, with x1=1, their suffix is identical because b<=N-2. The logical q, clipped log values and unperturbed logits at T therefore agree. The witness changes f_T by exactly 1/(4PT), so the reference probability separation is at least

    nu_c delta/(4PT).

Choose a positive dyadic zeta<=nu_c delta/(32PT). Since the physical output is within zeta of its corresponding Qref on every history, the physical probability difference is at least nu_c delta/(4PT)-2zeta>0.

Each new head is also genuinely useful, not merely present in syntax. Consider the same physical network with only one of the two new attention outputs set to zero. The same small-amplitude proof applies to its corresponding ablated logical reference; all reference trajectories stay in the same enlarged bounded envelope. Choose constants for the union of original and two ablated programs. In either ablated logical program f_T=0. On a history with x1=1 the original reference has f_T>=1/(2PT), so probability separation is at least nu_c delta/(2PT). The physical approximation margins again leave a strictly positive difference. The original suffix head is useful because removing it changes the suffix estimator's reference output on suitable histories; the present note relies on the established source-head usefulness and does not require a quantitative margin uniform in b for that separate assertion. If only a claim of at-most-three useful reads is desired, nothing in the risk or anchored results needs this last inherited usefulness assertion.

This purpose of zeta explains the additional log(N) precision charge. Since delta=1/b, P<2(N+1), T=N+1 and b<=N, one may choose zeta within a factor two of the displayed positive bound and obtain

    log(1/zeta)=O_c(log(N+1)+log b).

Together with (2), D=O_c(log(N+1)+b). This is exact-real coefficient precision, not finite-arithmetic execution precision.

## 7. Complete resource and risk accounting

- Useful attention: one suffix read plus two witness reads, all zero-score scalar-value and full-prefix inclusive. Physical one-head slot reused three times. No multihead sum is introduced.
- Width and FFN hidden width: fixed binary-source allowance plus a constant number of shadows, paired witness registers, output-bank and padding scratch. No b-wide or N-wide simultaneous bank; serial spline/arithmetic remains paid depth. The same width can be chosen independently of c; numerical envelopes depend on c.
- Depth: O_c(log(N+1)+b), with every local primitive, useful and dummy block, padding/restoration stage, final LN, affine head and vocabulary softmax charged.
- Norms: reference full-state and full-matrix bounds are the finite union of the existing source/serial-log/padding bounds and the bounded witness operations. Small-amplitude physical states and restored states obey their previously derived tube/radial bounds. All new blocks have fixed bounded matrices and full biases. No componentwise norm substitute is used.
- Descriptions: maximum public coefficient bit description O_c(log(N+1)+b), using the same dyadic amplitude and restoration parameter construction; untied dense total description O_c((log(N+1)+b)^2). No actual parameter-generation run is claimed.
- Work: three useful dense heads cost O(N^2); positionwise work O_c(N[log(N+1)+b]); dense evaluation of every dummy head gives the conservative O_c(N^2[log(N+1)+b]). Rolling real storage O(N) at fixed width.
- Anchors: s=b+1. Under AA/BB ownership retain actual s_A,s_B. The earlier finite-branch simulation may therefore cost exponentially in b; this construction does not improve that bound or certify finite-separable rank through LN.

From (1) and physical approximation,

    sup_(P_c) risk <=13 sqrt(32/(b-1))+1/b+1/(4b^2)
                       +H_N/(8bPT)+zeta
                  <=C_c/sqrt(b).

A uniformly bounded ordinary logit head cannot give vanishing worst-source risk over deterministic sources; the restriction to known stationary interior P_c is intentional and exactly the normalized-frontier source class. No unrestricted-source extension is claimed.

## 8. Stop boundary and provenance

What has been established, subject to independent exact-version review: a growing-anchor, three-read PreLN program can preserve the known suffix statistical rate and a strictly detectable but asymptotically negligible additional interaction. It cannot be used as evidence that repeated attention improves statistical power or that fixed-s anchored models are consistent. Directly stacking the old physical networks would not prove this result; the protected-support and recomputed normalization arguments are essential.

We stop at this boundary. No stronger perturbation, fixed-s estimator, sharp anchored lower/upper matching, PostLN counterpart, training claim, or improved general self-attention frontier is asserted. This is composition, not innovation in estimation.

Read dependencies:
- ../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md and its accepted audit: logical suffix estimator, exact value support and all-row bounded program.
- ../standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md: local/attention error recurrence, full-feature paired compilation, approximate clearing and paid radial restoration.
- ../softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md, Section 5, and its architecture review: bounded logit bank, paid full-vector padding and ordinary affine vocabulary head.
- ../normalized_stationary_frontier_20261105/NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md: general-b source and stationary interior risk bound, exact shared normalization convention.
- CAUSAL_PRELN_ANCHOR_WITNESS.candidate.v1.md and INDEPENDENT_CAUSAL_PRELN_ANCHOR_WITNESS_AUDIT.v1.md: directly audited two-read structural witness. Here its LOGICAL small-signal mechanism is recompiled, not concatenated physically.
- ANCHORED_MEMORY_EXTENSION.candidate.v1.md and its independent audit: conditional dependency definition and finite-branch cost.

The established ingredients, including local ReLU selectors, uniform pooling, bounded-gain normalized simulation and empirical Markov estimation, are attributed in the existing primary-literature comparisons. No new live literature search or novelty certification was performed. The only additional proof obligations here are the three-step attention recurrence accounting, exact supported-value invariants and a sufficiently small uniform approximation target preserving an intentionally weak interaction.
