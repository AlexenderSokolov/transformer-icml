# Conditional weak-anchor composition increment

This separately frozen increment contains LOW_RISK_WEAK_ANCHOR_COMPOSITION candidate versions v1 through v4 and INDEPENDENT_LOW_RISK_WEAK_ANCHOR_COMPOSITION_AUDIT.v1. Original source bytes are unchanged and bound by SOURCE_MAP.json. The exact-version audit reports a conditional PASS for v4 under its stated contracts; earlier candidate versions remain historical versions, not silently upgraded by that review.

The anchor count grows as s = b + 1. The statistical rate in this composition is imported from the earlier suffix method. This does not establish a repeated-attention advantage or a general result for arbitrary Transformers. The construction and its source/statistical/architecture restrictions must be read together.

The referenced earlier proofs and public dependency closure remain separate. This archive does not establish self-contained execution or provide a new numerical experiment. Packaging did not execute research scripts or revise any proof.
