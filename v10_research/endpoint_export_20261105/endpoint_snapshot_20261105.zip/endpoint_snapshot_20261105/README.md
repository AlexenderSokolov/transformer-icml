# v10 retained endpoint research snapshot

This directory preserves the available retained endpoint proofs, analytical reviews, counterexamples, provenance limitations and report versions as of 5 November 2026. It is not a claim that every historical execution record was recovered.

`ENDPOINT_SOURCE_MAP.json` binds each original source version and its public derivative. Some public copies remove host paths, private delivery identifiers and non-scientific coordination or communication metadata. Original scientific sources were not overwritten. Historical hash lists and review hashes still identify original bytes; use the source map for public-file integrity.

The strict replay remains **NOT RUN / NO-GO**. Missing pre-run environment, per-case results and some standalone original checker/output files were not recovered. Analytical proofs, emitted parameter files, static inspection and numerical execution are distinct types of evidence. Internal analytical review is not formal verification or external peer review.

Historical file-path references are identifiers, not guaranteed clickable links. Top-level endpoint sources use the canonical endpoint directory as their source base. Frozen copies under bundle `inputs/` retain that canonical base rather than their physical copy's directory. In public path aliases, `./` denotes that endpoint source base; `../shared/` and `../workspace/` denote companion research roots outside this archive. Cross-project references require the companion retained-research archive; this endpoint directory alone is not claimed to be a self-contained execution environment. A path alias does not supply an unavailable dependency.

Latest finite-testing additions are in `endpoint/KNOWN_CHANNEL_minority_erasure_finite_testing.addendum.v1.md` and its independent review. They concern a predeclared public, realizable finite candidate family with positive transitions, a common bounded relative transition-log ratio, a common minority direction and the same public one-state strict one-edit channel. They require no additional rho endpoint-mass assumption. They do not establish a uniformly estimable unknown-source minimax predictor for the full continuous source class.

File inventory and publication checks concern retained bytes and privacy metadata. They do not rerun scientific experiments or reconstruct missing historical records.
