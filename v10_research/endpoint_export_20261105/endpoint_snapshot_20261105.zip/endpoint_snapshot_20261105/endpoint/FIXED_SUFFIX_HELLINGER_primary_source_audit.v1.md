# Primary-source delta audit: finite posterior comparison and suffix prediction

Date: 2026-11-05 UTC. Focused primary-source comparison, not novelty certification or a replacement for independent proof review. No scientific executable checks, numerical experiments, or public writes were performed. Existing research files remain unchanged.

## 1. Current result and its actual scope

The centered-flow note has a separate analytical PASS for its exact identities and suffix-only score lemma. The finite-posterior candidate has a separate analytical PASS for both its finite comparison and statistical suffix theorem. These are distinct advances beyond the earlier method barriers, but they do not settle the unrestricted-position no-floor S=1 problem.

With Hellinger convention

    H^2(P,Q)=sum_x (sqrt(P(x))-sqrt(Q(x)))^2,

the finite comparison is

    E_(P,C)|p_P(Z)-p_Q(Z)|
      <=E_P|g_P(X)-g_Q(X)|+2 sqrt(rho) H(P,Q)+H^2(P,Q).

P and Q are fixed raw-word laws, C is one common normalized source-independent kernel, and each g is its source-specific future success probability as a function of the terminal pair. This is an expected comparison of posterior probabilities, not classification risk, full-history posterior TV, or a posterior over source hypotheses. No common support or bounded likelihood-ratio assumption is imposed.

For a stationary binary at-most-order-two source in D2(beta), fixed 0<beta<1, and a channel that leaves an initial prefix exactly unchanged and confines changes to the final L raw coordinates, the statistical bound is

    Risk <= C_beta min{1,m^(-1/2)+min{rho,sqrt(rho L/m)}},
    m=M-L>=1, N=M+2, 0<=L<=M-1.

The channel can inspect the whole observed history, including the entire raw suffix. Future-blindness excludes looking at the next unobserved source innovation; it does not require current-symbol causality inside the history. The theorem is therefore broader than S=1 online suffix channels, but more restrictive about edit placement than arbitrary-position S=1 channels.

No strict edit count enters this proof. A channel can make at most k edits far apart and still have no long clean prefix. Thus L cannot be replaced by k, k^2, a random number of affected locations, or an unproved effective horizon. When L is fixed and m is comparable to M, the consequence is O_(beta,L)(M^(-1/2)); the constant is not asserted independent of L. L may also grow, with its displayed dependence retained.

## 2. Strongest finite-comparison antecedent

Ohnishi and Honorio, *Novel Change of Measure Inequalities with Applications to PAC-Bayesian Bounds and Monte Carlo Estimation*, lemma 6 and table 2, uses unhalved Hellinger square. After interchanging their measure labels, its variational bound gives

    E_P phi<=H^2(P,Q)+E_Q[phi/(1-phi)].

For E_Q u=0, |u|<=1, and phi=t u, this yields

    E_P u<=H^2/t+t E_Q u^2/(1-t).

Optimizing t=H/(sqrt(E_Q u^2)+H), with boundary cases by limits, gives exactly 2 sqrt(E_Q u^2) H+H^2. This is our derivation from their lemma, not their stated posterior theorem. Their density-ratio presentation does not explicitly settle singular mass; retain the candidate's direct decomposition for that case. [Primary AISTATS 2021 paper](https://proceedings.mlr.press/v130/ohnishi21a/ohnishi21a.pdf).

Thus the variance-sensitive Hellinger change-of-measure shape and its constants are not a new general inequality. The candidate specializes it to an appropriately centered conditional residual and the terminal-pair reliability event, and then applies it to a conditional fitted experiment.

### 2.1 The posterior residual is centered, not endpoint supported

Let the joint laws be mathsf P(x,z)=P(x)C(z|x) and mathsf Q(x,z)=Q(x)C(z|x). Because X is retained in this joint experiment,

    H^2(mathsf P,mathsf Q)=H^2(P,Q)

exactly. Projecting to Z alone gives only the usual contraction inequality. Confusing those two operations would obscure why the raw-law distance suffices here.

Set f(x,z)=g_Q(x)-p_Q(z), and multiply by the sign of its P-conditional mean. Under mathsf Q, this signed residual is still centered and bounded by one. Its second moment is

    E_Q Var(g_Q(X)|Z)
      <=E_Q[g_Q(X)-g_Q(S(Z))]^2
      <=Q_C{S(X)!=S(Z)}<=rho.

The residual f itself need not vanish on endpoint-preserved paths. It is the squared error from the displayed-row reference that vanishes there, yielding a conditional-variance bound. This is different from the explicitly endpoint-supported centered-score expression in the flow note.

### 2.2 Which endpoint probability is needed

For this finite comparison, only the integrated endpoint-change probability under **Q** is needed. A certificate averaged only under the true P would not guarantee the same fact under a fitted or alternative Q. The per-clean-word condition guarantees it uniformly for every Q, including words outside the true law's support.

No independence between endpoint changes and likelihood ratios is used. This is also not an iid Huber-mixture representation of the corrupted word. The endpoint probability measures a target-specific event, not the total corruption probability or fraction of independently contaminated coordinates.

### 2.3 Singular support and constants

On Q support write dP=R^2 dQ, and keep the P-singular part separately. Expanding R^2-1=2(R-1)+(R-1)^2 gives the linear Hellinger term and a quadratic remainder. The latter includes the singular mass exactly. Consequently p_Q may be defined arbitrarily in [0,1] on zero-Q outputs, with that contribution charged to H^2.

The remainder is not silently discarded. It pays for changing the observation measure, including support mismatch. A first-order variance bound alone is not the stated finite theorem.

If normalized Hellinger is h^2=(1/2)sum(sqrt P-sqrt Q)^2, the same bound is

    direct row error+2 sqrt(2) sqrt(rho) h+2 h^2.

Do not mix these constants with a different convention. Similarly, the expectation is one-sided under P,C; replacing it by an overlap-weighted or Q-weighted expression changes the statement.

## 3. Relation to established posterior stability and centered scores

McDonald and Yuksel's common-kernel Bayesian-update lemma bounds expected posterior TV in terms of fixed-prior TV. Arbitrary finite block channels are valid one-update kernels after enlarging the latent state. It is a strong general antecedent, but it does not automatically exploit the small conditional variance of this particular terminal functional or give the displayed rho-dependent Hellinger comparison. Neither its integrated conclusion nor the finite candidate may simply substitute a different Q_Z for every observed output. [Primary version 2, lemma 3.2](https://arxiv.org/pdf/1910.08463v2).

The earlier audit already covers Chan–Darwiche log-ratio oscillation, Hilbert-to-TV control, and evidence-sensitive Bayesian stability. Those results often emphasize pointwise ratios or evidence. The present finite comparison instead uses square-root densities and permits singular support. This difference is worth stating, without claiming that posterior stability or support-aware probability comparison begins here.

For a general S=1 channel, the flow note writes the exact posterior as b_theta(z)+A_theta(z)/D_theta(z). The actual edit mask and z determine the raw word, and its prefix sums determine the actual counter. The bound sum_z|A_theta(z)|<=rho is integrated; it neither bounds A/D pointwise nor controls its parameter derivative.

Differentiating the complete normalized likelihood yields

    dot p=E[dot g|Z]+Cov(g,S_all|Z).

The initial stationary-law score and all transition scores enter S_all. The denominator derivative centers that score; it cannot be omitted. These are established normalized-reweighting identities. Giordano, Broderick, and Jordan's theorem 1/corollary 1 provides a precise covariance-sensitivity formulation; the direct derivative is additional when g changes with the parameter. [Primary JMLR paper, section 2.2](https://jmlr.org/papers/volume19/17-670/17-670.pdf).

The suffix assumption makes every score term before the suffix observable, including the initial-pair score. Its conditional covariance is therefore zero. Only L transition martingale differences remain, with exact second moment L I_step by orthogonality, not independence. Conditional variance of the future row is at most the posterior endpoint-change probability. Two Cauchy-Schwarz steps give

    E|Cov(g,S_all|Z)|<=sqrt(rho L I_step)

with constant one. This lemma needs only integrated endpoint probability under the current source, unlike the finite comparison's Q requirement or the earlier positive-floor exponential-envelope argument's weighted per-word requirement. It never needs the generally invalid factorization E[1_A T^2]<=rho E[T^2]. No mixing certificate is needed for this local score calculation once the stated regularity, stationarity, and observed-prefix assumptions hold.

The lemma is an infinitesimal scalar control. The finite statistical theorem does not follow just by multiplying it by a fitted parameter error. The new candidate instead supplies a separate finite-law comparison, thereby avoiding parameter-path integration and its changing-measure complications.

## 4. Unchanged-prefix fitting is conditioning, not independence

Let H=X_1:n=Z_1:n, n=N-L. The add-one row table is fitted only from this clean prefix. Conditional on H=h, it is one fixed table while suffix output w varies. Both true P_h and fitted Q_h suffix laws start at the same exactly observed final prefix pair. No fitted stationary initial law is required, and the fitted transition table need not satisfy D2(beta).

The conditional channel C_h(w|v)=C((h,w)|(h,v)) remains normalized and common because the prefix is always unchanged. It may still depend on h and inspect v. Its per-word certificate is inherited. Positive add-one rows give positive fitted mass to every suffix word, so fitted evidence is positive on actual true-supported outputs.

This justifies applying the fixed-P,Q comparison separately for each h. It does not assume that training data and future contexts are independent. Nor would it justify refitting a distinct Q_(h,w) after observing each suffix output without a new argument.

## 5. Primary clean-Markov prediction precedents

Han, Jana, and Wu, *Optimal Prediction of Markov Chains with and without Spectral Gap Conditions*, supplies particularly close methods. Main equation (5), theorem 3 and corollary 4 use add-one estimation and predictive KL. The supplement's section 7.2.1, lemma 15 and remark 4 analyze terminal-conditioned moments and warn about losing rare-state weights or extra logarithms. Appendix B reverses terminal conditioning to initial conditioning using reversibility. Section 5.1, equation (30), gives sequential KL decomposition in the prediction/redundancy argument. These strongly precede the ingredients here. The relevant spectral-gap theorem is for reversible irreducible clean first-order chains, not the possibly nonreversible order-two reverse-Doeblin conditional experiment or corrupted suffix. [Main paper](https://proceedings.neurips.cc/paper/2021/file/5d69dc892ba6e79fda0c6a1e286f24c5-Paper.pdf); [supplement](https://proceedings.neurips.cc/paper/2021/file/5d69dc892ba6e79fda0c6a1e286f24c5-Supplemental.pdf).

### 5.1 What must still be proved for this application

The candidate imports the reviewed three-step minorization of the stationary triple chain and its reversal on positive stationary support. Conditioning on any positive-probability pair at or after the prefix changes the reversed initial distribution, not the backward transition kernel. Arbitrary-start count concentration therefore applies without dividing by the conditioning pair's stationary mass. Stationarity of the actual source is still required; this is not an arbitrary-initial-source theorem.

The substantive conditional row estimate is

    E[KL(theta_u||theta_hat_u(H)) | future pair]
      <= C_beta/[m Pi(u)+1].

It must hold under the dependent future-pair conditioning, not only unconditionally. The proof treats small context counts, ordinary numerator counts, rare numerator deficits, and context-count tails separately. Its binary bad-numerator step uses the sign of the other KL coordinate; a general-alphabet version would need its own argument. Add-one smoothing avoids infinite loss at unvisited or zero-probability rows, without imposing a positive true transition floor.

Stationary weighting then gives

    E KL(theta_U||theta_hat_U(H))
       <=C_beta sum_u Pi(u)/[m Pi(u)+1]<=4C_beta/m.

This controls prediction geometry, not maximum-row error. Rare rows need not be estimated accurately uniformly. Zero-stationary-mass rows receive zero weight.

### 5.2 Expected conditional path KL, not a uniform prefix guarantee

The suffix chain rule has exactly L transition terms and no initial-law term, because both suffix laws start from the observed pair. Averaging over the true prefix law yields

    E_H KL(P_H||Q_H)<=C_beta L/m,
    E_H H^2(P_H,Q_H)<=C_beta L/m.

This is an expectation over H, not a bound for every prefix. It follows from the future-conditioned row estimate at each context. It is not a universal sequential predictor that updates its fitted table after every suffix symbol.

Pinsker and the same weighted row estimate give direct terminal-row error O_beta(m^(-1/2)). Conditional application of the finite comparison, followed by Cauchy-Schwarz, therefore yields

    Risk(q_post)<=C_beta[m^(-1/2)+sqrt(rho L/m)+L/m].

There is no unproved independent train/test step in this argument.

## 6. Jensen, public estimator selection, and remaining boundaries

The separate displayed-terminal-row estimator has risk at most C_beta/sqrt(m)+rho. Its proof first compares fitted rows at displayed and true terminal pairs, charging one only on a changed pair, then controls fitting error at the true stationary context. It does not assume that a channel-selected displayed context has the same estimation guarantee.

Conditional Jensen transfers latent-row error to a posterior-target **upper** bound. It supplies no lower bound in the opposite direction. The complete future probability, not the realized Bernoulli outcome's aleatoric variance, is the functional in all these comparisons.

The public selector uses q_end when rho<=L/m and q_post otherwise. In the second branch L/m<=sqrt(rho L/m), so the quadratic remainder is absorbed; in the first branch the independent rho bound is used. This does not remove H^2 from the finite comparison itself. At rho=0 and at L=0 the endpoint contribution is zero. The unit cap handles the remaining large-error regimes.

The result does not provide a matching lower, state minimality, an arbitrary-position S=1 improvement, a proof of the conjectured general k sqrt(rho I_step) score bound, an efficient posterior algorithm, finite-precision correctness, or training achievability. Prior no-floor score counterexamples and broader-channel lower bounds remain compatible because they use different channel placement or target comparisons.

## 7. Evidence and bounded positioning

A defensible description is: a conditional-residual specialization of variance-sensitive Hellinger change of measure, with explicit support handling, combined with future-pair-conditioned clean Markov estimation to obtain a suffix-supported posterior-prediction upper. Add-one estimation, time reversal, KL chain rules, score covariance, and the scalar Hellinger shape have clear precedents.

Both requested files and their current independent reviews were read in full. The prior `RHO_INTERPOLATION_primary_source_audit.v1.md`, `RARE_RHO_SCORE_primary_source_audit.v1.md`, and `ONE_STATE_POSITIVE_FLOOR_primary_source_audit.v1.md` were consulted to preserve earlier source/target qualifications rather than duplicate them. Primary sources were checked at the cited locations. This was a focused comparison, not an exhaustive priority search.

Present-byte SHA-256 bindings:

- `KNOWN_CHANNEL_fixed_suffix_finite_predictive_upper.candidate.v1.md`: `62efe80b0b7daea4c451526db3dc3706eaf5382d4c23bc57fe8f098418e86e65`
- `KNOWN_CHANNEL_fixed_suffix_finite_predictive_upper.independent_review.v1.md`: `8b1586193de324ce3518f5cf6080fad3ed639bdef264a3a00eff03c0cb3c1909`
- `KNOWN_CHANNEL_one_state_centered_likelihood_flow.research.v1.md`: `44d7b71bdf913e510ddb7e5115f1226aaa33d8b37f5cf5f907bae34a32624e47`
- `KNOWN_CHANNEL_one_state_centered_likelihood_flow.independent_review.v1.md`: `9bfc3ceaf36649d5ca746a353cfb6e397fd656bc92327c0040d4d1fadb98293b`

The PASS dispositions report existing exact-file analytical reviews. This source audit supplies neither a new proof-acceptance verdict nor scientific executable evidence.
