# Exact iid one-edit addendum: latent posterior instability is not predictive instability

5 November 2026 UTC. Pure analytical addendum, pending independent exact-file review. No scientific executable checks, numerical experiments, or public writes. The preceding rare-source score-barrier candidate is preserved unchanged.

## 1. Quantitative statement

For every integer M>=4, let N=M+2. There is one deterministic, source-independent, online S=1 channel with an actual binary edit counter, at most one edit on every raw word, and no endpoint edits, such that the following hold.

For any fixed 0<d<=1/8, take stationary iid binary sources

    a_-=(1-d)/M,   a_+=(1+d)/M.

Their length-N raw laws have

    KL(P_+||P_-)<=10d^2.                              (I1)

Nevertheless their full clean-history posteriors mu_+,mu_- satisfy

    sum_z min{P_+^Z(z),P_-^Z(z)} TV(mu_+(.|z),mu_-(.|z))
       >= e^(-4)d/2.                                 (I2)

The same lower holds when the posterior TV is averaged under either output law separately. Thus the full latent posterior can remain a constant distance apart with only ONE actual edit, despite arbitrarily small fixed raw KL.

The source-specific next-bit posterior targets, in contrast, are simply a_- and a_+, differing by 2d/M. The two-source predictive minimax absolute-loss risk is between d/(2M) and 3/M. This example therefore supplies no constant predictive lower.

At the central source a_0=1/M, the missing complete-source Fisher information obeys

    E_(a_0) Var_(a_0)(S_(a_0)(X)|Z) >= e^(-4) M^2/5, (I3)

whereas the one-step source Fisher information is between M and 4M/3. Consequently a uniform bound by C_beta k^2 times one-step information fails already at k=1.

These iid sources satisfy D2(beta) for every beta<=1, including beta=1. The barrier does not rely on dependent source rows, an uncharged hidden state, or a latent counter independent of raw history.

## 2. Channel and its exact one-state legality

The actual edit counter e starts at zero. At each position i<=M, if e=0 and the current raw bit is one, output zero and increment e. Otherwise output the raw bit. Positions M+1 and M+2 are always unchanged.

This is exactly the kernel K_i(z|x,e) of one base state. All its rows are deterministic and normalized. When e=1 the channel is identity; the exhausted counter is never exceeded. Every raw word has at most one changed coordinate, and neither coordinate of its terminal pair is changed. The channel is known, online, source independent, and future blind. It does not use a or d.

Let U indicate whether an edit occurred. This is the parameter-independent raw-word function

    U=1{sum_(i=1)^M X_i>=1}.

Its dependence on the raw history is essential and is retained throughout the calculation.

## 3. An exactly solvable output branch

Consider z_0=0^N. Its raw preimages are exactly:

- the all-zero word;
- a word with exactly one one, located at one of the first M coordinates.

No other raw history produces z_0. Under iid Ber(a),

    P_a^Z(z_0)=(1-a)^N [1+Ma/(1-a)],
    v_a(z_0):=P_a(U=1|Z=z_0)
       =Ma/[1+(M-1)a].                               (I4)

Conditional on U=1 and z_0, the erased location is uniform on the first M coordinates, under every source a. Hence on this branch the full posterior TV is exactly

    TV(mu_+(.|z_0),mu_-(.|z_0))=v_+(z_0)-v_-(z_0).

Exact subtraction gives

    v_+(z_0)-v_-(z_0)
      =2d / {[1+(M-1)a_+][1+(M-1)a_-]}
      >=d/2,                                        (I5)

because the denominator is at most (2+d)(2-d)<=4.

For either alternative a<=9/(8M)<=1/2, N<=3M/2, and log(1-a)>=-2a. Thus

    P_a^Z(z_0)>=(1-a)^N
       >=exp(-2aN)>=exp(-27/8)>=exp(-4).             (I6)

Multiplying (I5) by the minimum of the two actual output masses proves (I2), without discarding a rare-output factor or conditioning on different observation events.

## 4. Raw KL and the actual predictive risk

For Bernoulli probabilities p,q,

    KL(Ber(p)||Ber(q))<=(p-q)^2/[q(1-q)].

Here q=a_->=7/(8M), 1-q>=3/4, p-q=2d/M, and N<=3M/2. Multiplying the one-bit inequality by N gives

    KL(P_+||P_-)<= (64/7)d^2 <10d^2,

proving (I1). Pinsker and channel data processing imply

    TV(P_+^Z,P_-^Z)<=sqrt(5)d.

The source future is iid and independent of the channel's observed raw word. Therefore for every supported output,

    P_a(X_(N+1)=1|Z=z)=a.                             (I7)

The two-source absolute-loss inequality gives a predictive minimax lower of

    [d/M][1-TV(P_+^Z,P_-^Z)]>=d/(2M),                (I8)

using d<=1/8. For the matching order upper, use the displayed empirical mean q(Z)=N^(-1)sum_i Z_i. Pathwise it differs from the clean empirical mean by at most 1/N. Hence, under either alternative,

    E_a |q(Z)-a|
      <=sqrt[a(1-a)/N]+1/N
      <=3/M.                                        (I9)

Thus the predictive risk in this exact pair of experiments is of order 1/M for fixed d, even though its full clean-history posterior discrepancy stays bounded below by a positive constant.

## 5. Exact missing Fisher information

Keep this entire deterministic channel fixed and differentiate the true iid parameter a. Let T=sum_(i=1)^N X_i. The complete-source score is

    S_a(X)=[T-Na]/[a(1-a)].

Its complete Fisher information and one-step Fisher information are

    I_complete(a)=N/[a(1-a)],
    I_step(a)=1/[a(1-a)].                             (I10)

On the output z_0, T=U takes only the values zero and one. Thus the exact conditional score variance is

    Var_a(S_a(X)|Z=z_0)
      =v_a(z_0)[1-v_a(z_0)]/[a^2(1-a)^2].            (I11)

At a_0=1/M,

    v_(a_0)(z_0)=1/(2-1/M) in [1/2,4/7],
    v_(a_0)(z_0)[1-v_(a_0)(z_0)]>=1/5.

Since a_0^2(1-a_0)^2<=1/M^2, (I11) is at least M^2/5. The same mass bound (I6) applies at a_0, proving (I3).

The observed score is E_a[S_a(X)|Z], because the channel is source independent. The law of total variance therefore identifies the left side of (I3) exactly as

    I_complete(a_0)-I_observed(a_0).

At this central source,

    M<=I_step(a_0)<=4M/3,
    M^2<=I_complete(a_0)<=2M^2.                       (I12)

The lower (I3) is consequently compatible with information data processing, while its ratio to k^2 I_step(a_0), with k=1, is at least (3e^(-4)/20)M and diverges.

The bounded-mode sensitivity version fails as well. Direct differentiation of (I4) gives

    (d/da)v_a(z_0)|_(a=a_0)
       =M/(2-1/M)^2>=M/4.

Averaging its absolute value over the actual full output law gives

    E_(a_0) |(d/da)v_a(Z)|_(a=a_0)|>=e^(-4)M/4,      (I13)

while k sqrt(I_step(a_0)) is only of order sqrt(M). Equivalently, the standard identity d v_a(z)/da=Cov_a(U,S_a(X)|Z=z) has large conditional covariance for a genuine one-edit raw-dependent counter mode.

## 6. Precise implication for the open S=1 problem

The example rules out proving a sharp general S=1 predictive upper by first asserting either a uniform O_beta(k/sqrt(M)) full clean-history posterior comparison or a uniform C_beta k^2 I_step missing-information bound.

It does not rule out direct endpoint-weighted score or covariance arguments. Here the future target is the constant a, so the large latent conditional score variance has no corresponding future-row posterior uncertainty. That distinction is exactly what a successful proof must preserve.

No matching general no-floor S=1 upper or base-state separation is established by this addendum.
