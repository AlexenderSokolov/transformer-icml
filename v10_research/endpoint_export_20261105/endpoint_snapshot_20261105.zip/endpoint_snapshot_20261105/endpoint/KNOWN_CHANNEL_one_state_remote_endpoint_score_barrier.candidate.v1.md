# One-state counters prevent terminal localization of the posterior target score

5 November 2026 UTC. Pure analytical candidate, pending independent review. No scientific executable checks, numerical experiments, or public writes. This concerns the actual future-prediction target, unlike the preceding full-latent-posterior barriers.

## 1. Result and exact limitation

For every fixed 0<beta<1 and rational 0<rho<=1, there is a stationary binary first-order source with a fixed positive transition floor and a known, source-independent, online S=1 channel with at most two actual edits such that a source-score contribution from the FIRST TWO raw coordinates has

    E |Cov(g_a(X_N), S_pre(X_1,X_2) | Z)| >= r rho/8, (T1)

uniformly for every N>=4. Here g_a(X_N) is the true next-bit transition probability, r>0 is a fixed beta-dependent constant, and S_pre is the actual stationary initial-pair score for a one-dimensional source parameter a.

Consequently raw-source D2 mixing does not imply exponential decay with distance to the endpoint for this posterior target covariance. Discarding remote scores gives a nonvanishing error even if every intervening raw bit is displayed exactly. The hidden actual counter preserves the relevant dependence.

This is a barrier to a specific terminal-localization step. It is not a predictive minimax lower, a proof against all endpoint-sensitive methods, or a matching S=1 upper. In fact local and remote score terms can cancel exactly; an upper argument must preserve that possibility.

## 2. Source and actual one-state channel

Choose 0<r<=min{(1-beta)/2,1/8}, and use the stationary first-order source

    P_a(1|x)=a+r x,

with a in a neighborhood of a_0=1/3. Its stationary probabilities are

    pi_a(1)=a/(1-r), pi_a(0)=(1-r-a)/(1-r).

The pair-chain all-state minorization has constant exactly 1-r>=beta, by the identity P_a^2((w,x),(y,z))=P_a(y|x)P_a(z|y). In a sufficiently small fixed neighborhood of a_0, every transition probability is at least 1/4.

The channel uses one base state and the actual edit counter e in {0,1,2}:

- At i=1, output zero if e<2; otherwise output the input. On the actual initialized path e=0, this spends one edit precisely when X_1=1.
- At i=2,...,N-1, output the raw input unchanged.
- At i=N, if e=1, flip the raw input with probability rho; otherwise output it unchanged. Increment e only when a flip occurs.

All unused rows are defined by these same guards, including exhausted-counter identity rows. The endpoint coin is independent auxiliary randomness. Every path has at most two edits. For every fixed raw word, the endpoint-change probability is rho if X_1=1 and zero otherwise. The channel is normalized, rational, source independent, online, and future blind. Its public expanded time-indexed table has O(N[b_rho+1]) description bits, with the three-valued actual counter separately charged.

Let U=X_1. On reachable paths U is exactly the counter e_(N-1), since the middle segment is identity. Set B=X_N and W=Z_N. Thus

    W=B xor (U F),   F~Ber(rho).

The middle observation H=(Z_2,...,Z_(N-1)) is the corresponding clean raw segment.

## 3. Endpoint conditioning creates long-range dependence

On the observable event that X_2=0, stationary detailed balance gives

    P_a(U=1|X_2=0)=a.

Conditional on the entire middle segment H, the Markov property makes U and B independent. If both retained boundary bits are zero,

    X_2=X_(N-1)=0,

then before observing W they are independent Ber(a) variables. There is no remaining raw-source long-range interaction in that conditional statement. The dependence below is created by the channel's hidden actual counter.

Write

    D_a=1+rho(1-2a).

Conditional on such H, the probability of W=1 is

    ell_a(1)=a D_a.

The three possible joint masses for (U,B) on W=1, before division by ell_a(1), are

    (0,1): a(1-a),
    (1,1): a^2(1-rho),
    (1,0): a(1-a)rho.

Direct subtraction gives

    Cov_a(U,B|H,W=1)
       =-rho(1-a)^2/D_a^2.                           (T2)

At rho=1, U and B are opposite fair bits on this branch, so the covariance is exactly -1/4.

The actual future transition probability is

    g_a(B)=a+rB,

and its source-specific posterior is E_a[g_a(B)|Z]. No surrogate latent target is substituted.

## 4. The remote source score and its contribution

Hold the entire channel fixed while differentiating the source parameter a. Define

    S_pre(X_1,X_2)
       =(d/da) log[pi_a(X_1)P_a(X_2|X_1)].

On X_2=0, the conditional law of U=X_1 is Ber(a). Therefore the difference between the two values of this score is exactly

    S_pre(1,0)-S_pre(0,0)=1/[a(1-a)].

The derivative of the X_2 marginal is a common term and cancels from a conditional covariance. Equations (T2) and g_a(B)=a+rB consequently imply, on H with both retained boundary bits zero and W=1,

    |Cov_a(g_a(B),S_pre|Z)|
       =r rho(1-a)/[a D_a^2].                        (T3)

Evaluate at a=a_0=1/3. More generally all the following inequalities hold for any a<1/2 with pi_a(0)>=1/2. For this binary chain,

    P_a^m(0,0)=pi_a(0)+pi_a(1)r^m>=pi_a(0).

Hence the joint probability of the two retained zero boundary bits is

    P_a(X_2=0,X_(N-1)=0)
       =pi_a(0)P_a^(N-3)(0,0)>=pi_a(0)^2>=1/4.

Multiply their joint mass, ell_a(1)=a D_a, and (T3). Since

    D_a=1+rho(1-2a)<=2(1-a),

the contribution from this one observable branch is at least

    (1/4) r rho(1-a)/D_a >= r rho/8.

This proves (T1). The constant has no dependence on the distance N-2 between the remote initial pair and the endpoint.

## 5. Exact failure of a terminal-score truncation

For i>=3 write the ordinary first-order transition score

    s_i=(d/da)log P_a(X_i|X_(i-1)).

The complete stationary source score is

    S_all=S_pre+sum_(i=3)^N s_i.

Every s_i for 3<=i<=N-1 is a function of the displayed middle segment and therefore has zero conditional covariance with g_a(B) given Z. The only potentially nonzero terms are S_pre and s_N.

Differentiation of the actual posterior target gives the exact identity

    (d/da)P_a(X_(N+1)=1|Z)
       =1+Cov_a(g_a(B),S_pre+s_N|Z).                 (T4)

The direct derivative of g_a is one. If a proposed localization keeps only the last ell transition scores, with 1<=ell<=N-2, all retained middle scores again have zero conditional covariance. Its approximation is exactly

    1+Cov_a(g_a(B),s_N|Z).

Its integrated absolute error from the true derivative (T4) is therefore at least r rho/8, by (T1), for every such ell. Even retaining every transition score except the initial-pair score fails to make this error vanish as N grows.

This rules out an appeal to clean-source D2 mixing to obtain a uniform exponential terminal-localization bound for the posterior target score in this channel class.

## 6. Count-conditioned forward-backward does not remove the mixing-weight term

Conditioning on the actual counter e_(N-1)=U is a legitimate internal decomposition:

    p_a(z)=sum_(u=0,1) nu_a(u|z) q_a(u,z),
    nu_a(u|z)=P_a(U=u|Z=z),
    q_a(u,z)=E_a[g_a(B)|Z=z,U=u].

Differentiating gives both terms

    p_a'(z)=sum_u nu_a(u|z) q_a'(u,z)
               +sum_u q_a(u,z) nu_a'(u|z).           (T5)

Conditioned on U, the remote score is constant in that stratum and cannot create within-stratum covariance. Recovering the unconditioned target, however, requires the source-dependent weights nu_a. Their differentiation includes the remote prior information carried by the counter, as well as local endpoint likelihood information. These contributions may cancel; conditioning on a hidden count does not authorize dropping either.

At rho=1 on the selected W=1 branch, nu_a(0|z)=nu_a(1|z)=1/2 for every a because both prior bits are Ber(a). Thus the TOTAL derivative of these weights happens to be zero. Nevertheless the separate remote and terminal covariance terms in (T4) are nonzero and opposite. Indeed the posterior target on that branch is a+r/2, whose derivative is exactly one. This is an explicit cancellation, not exponential forgetting of the remote term.

The augmented source-counter process has no uniform contraction between U=0 and U=1 during the identity middle segment: the counter retains its value exactly. Clean-source mixing alone therefore cannot provide the missing estimate after marginalizing that hidden counter.

## 7. Remaining task

A general S=1 upper could still control the combined endpoint-sensitive covariance, including cancellations and the source-dependent posterior distribution of the actual counter. This note only identifies a concrete obstruction to terminal score localization or to transferring a count-conditioned forgetting statement through an unexamined mixture.

The reviewed S=1 lower and general D2 upper remain unmatched in the principal sub-square-root-budget regime. No new minimax separation or matching-upper claim follows from this barrier.
