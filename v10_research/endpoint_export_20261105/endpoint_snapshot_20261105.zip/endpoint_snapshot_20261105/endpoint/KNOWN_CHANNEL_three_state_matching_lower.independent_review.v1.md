# Independent analytical review: three base-state implementation

Review time: 2026-11-05 08:38:51 UTC.

## Exact materials and outcome

**PASS within the stated paid, time-indexed channel interface.** I fully read the current implementation addendum and independently checked its state invariants and coupling. The addendum has SHA-256:

- `KNOWN_CHANNEL_three_state_matching_lower.addendum.v1.md`: `6d7869f24ad38c5861a732f5fdbe33c391d09759946ac926499dc67198cfd82c`.

The unchanged, previously independently reviewed statistical proofs to which the implementation transfers are:

- `KNOWN_CHANNEL_online_thinning_mode_matching_lower.candidate.v1.md`: `bd616d8ae614fbd99a312a18cd6927fbaee7d05945389342d9d953904bf8c874`.
- `KNOWN_CHANNEL_online_one_edit_lower.candidate.v1.md`: `411908bdfb5385066e19daaa84edcc302fc0a80bf76eb23d258a3f7187fa6e60`.

These hashes were independently computed in this review. They identify present bytes, not an inferred historical state. The statistical proof is not rewritten or strengthened here: the new result is an exact implementation of the already reviewed channels with fewer base states.

## 1. Schedule and mode preservation

Candidate times are multiples of three, so their triples `(j-2,j-1,j)` are disjoint. Since their last coordinate is at most `N-5`, all candidate triples precede the terminal triple `(N-3,N-2,N-1)`. The finite table therefore never assigns two incompatible roles to one time. The first candidate, when present, reads positions 1 and 2 before acting at 3. If the candidate set is empty, the endpoint reset still supplies its own two-bit gate.

The inactive state `I` is absorbing and emits every input unchanged. Both `A0` and `A1` remain in the active class under every listed transition. In particular, resetting `A1` to `A0` does not forget the hidden mode. No transition merges either active state into `I`.

At a candidate's first predecessor, the active accumulator is overwritten with the current raw bit, independent of its old value. At the second predecessor, it becomes the product of the two raw predecessor bits. Consequently, immediately before candidate `j`, it equals exactly the raw-pair-11 indicator. These two predecessor positions are never edited. The candidate can use this stored gate and the current raw bit in its output transition, then discard the gate.

The endpoint starts a new accumulator at `N-3`, overwriting it with `1-x_(N-3)`. Its update at `N-2` yields exactly the raw-pair-00 indicator before `N-1`. No access to `x_N` or any later input is used. The full previous raw pair need not be stored at times when no test will query it.

## 2. Exact counter and pathwise coupling

Fix any complete clean word, one hidden-mode draw, and a complete sequence of potential thinning and endpoint coin draws. Use these same random choices for the eight-state and three-state implementations. Before every candidate they have the same gate; if their previous counters agree, their eligibility, output, and increment agree. The initial counters are both zero, so induction gives equality of every output and the complete actual-edit counter path. The endpoint gate and guard also agree by the separate accumulator invariant. All other positions are identity in both channels.

Coin draws can be indexed at every public candidate even if a gate fails; ignoring such a draw in both channels does not change either law. Thus the coupling is valid for every input and coin realization, not only for either specially chosen source.

The counter remains the actual number of output/input disagreements. It is not assigned a mode, time, gate or arbitrary auxiliary code. Its guards prevent overflow on every row, including unreachable rows. In the large-budget construction the interior cap is `h`, the endpoint adds at most one, and `h+1<=k`. The nonintegral probabilities are exactly the original rational initialization, thinning and endpoint probabilities. Every row is normalized, including the cases of a failed gate or an exhausted cap.

It follows that the joint law of the source word, displayed word, hidden mode, actual counter and source future is unchanged. The displayed word does not include the internal state or counter. Consequently each source-specific posterior target, its observation law, and every estimator's risk are identical to those in the reviewed eight-state proof. This also transfers its per-word endpoint certificate without an additional inference about cap conditioning or hidden-mode posteriors.

## 3. Small-budget branch

The large-budget construction is used only in the large-h range of the original proof; its `1/(2h)` is not evaluated at `k=1`. In the bounded-k fallback, two accumulator states suffice for the deterministic one-edit channel. Its candidate gate, terminal gate, reset rules and current-bit input reproduce the original four-raw-pair-state channel pointwise. Its counter can reach only 0 and 1, and candidate/endpoint edits require counter zero. Thus the fallback still uses at most one actual edit and fits the available `k+1` counter values for every `k>=1`.

The independent clean and protected-budget witnesses use one base state each. Padding unused states therefore places all three lower witnesses in an allowance `S>=3`. As before, their lower bounds are combined by taking the maximum of separate witnesses; edit budgets of distinct channels are not added.

## 4. Consequence and resource boundary

The reviewed matching endpoint lower and full fixed-beta minimax profile now hold for an allowed base-state budget `S>=3`, under the same sufficiently-large-horizon, stationary source, disclosed rational channel, actual posterior target and time-indexed interface assumptions. No statistical constant or approximation error is lost in the state reduction.

The large branch has **three base states**, not three total configurations. Its augmented base/counter space has at most `3(k+1)` configurations. The public time schedule remains a separately paid expanded table. The stated conservative ledger

`ell = O(N * 3^2 * (k+1) * [b_rho + log(h+1) + log(N+1) + 1])`

appropriately retains the counter, time expansion, rational probabilities and destinations. A homogeneous implementation would have to represent the relevant time information differently and is not established here.

Three is a sufficient count, not a lower bound on the minimum number of base states. In particular this review neither rules out two states nor approves an unreviewed use of the edit counter to encode a mode. Such a different construction requires its own actual-edit and statistical argument.

## Review method

Pure mathematical inspection and exact-file hashing only. No scientific executable checks, simulations, model runs, numerical validation, public writes, training claim, novelty certification or floating-point claim. Original proof files were not edited.
