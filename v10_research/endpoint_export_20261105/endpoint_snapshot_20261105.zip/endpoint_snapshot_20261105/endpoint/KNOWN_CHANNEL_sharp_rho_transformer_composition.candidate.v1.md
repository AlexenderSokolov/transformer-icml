# Implementing the sharp-rho interpolation upper

5 November 2026 UTC. Analytical candidate for independent audit. No scientific executable checks, numerical experiments, public writes or optimality claims. Earlier artifacts remain unchanged.

## 1. Result, experiment and claim boundary

The two estimators underlying the known-channel sharp-rho interpolation upper can both be implemented, including their public selection, under the paid rational finite-state computational interface. This gives the interpolation upper for that subclass. It does not establish a matching minimax lower restricted to finite-state or online channels.

Let N=M+2, M>=64, 0<=k<=M. The source is a stationary binary homogeneous order-two source with stationary pair law Pi and all-state certificate

    P^2(s,t)>=beta Pi(t),
    beta=a_beta/2^p in (0,1).

The public endpoint budget is the exact dyadic

    rho=a_rho/2^q in [0,1].

The displayed finite-state channel has normalized rational one-pass kernels, independent auxiliary randomness relative to the entire source process, a strict all-realization k-edit counter, and a certified per-clean-word endpoint-change probability at most rho. Its complete expanded time-indexed rational description is charged. Its realized seed, edit mask and clean word are not observed. The source-specific target is

    p_(theta,C)(Z)=P_theta,C(X_(N+1)=1 | Z).

Put u=max{1,ceil(log2(1/beta))}, interpreted by exact integer comparisons, and let

    b=2^-u, A=2^(160+10u), C_0=8A, C_int=4C_0=32A.

For every r>=1 there is a raw-token bounded-score Transformer with output Q_r such that, for k>=1,

    E|Q_r(Z)-p_(theta,C)(Z)|
      <= min{1, C_int [M^-1/2+k/M
                   +min{rho,(k^2/M)^(1/3)}] +2^-r}.     (R1)

For k=0 the bound is

    E|Q_r(Z)-p_(theta,C)(Z)|
      <= min{1,2^17 M^-1/2+2^-r}.                       (R2)

Both are uniform over sources and channels satisfying the stated contract. Constants are explicit and extremely loose. For fixed beta this is the same rho-dependent upper order as the unrestricted statistical interpolation theorem. In its more detailed notation F_beta>=k/M, so (R1) also implies the upper with M^-1/2+F_beta+min{rho,(k^2/M)^(1/3)}. No uniform sharp dependence on moving beta is asserted.

The input remains exactly displayed binary one-hots, public p_t=t/P with P=2^ceil(log2(N+1)), and one synthetic zero-symbol query row. The mask is self-inclusive causal; all eligible attention scores are zero. There is no LayerNorm/RMSNorm or final vocabulary softmax. One implementation has d=64 and FFN128 with uniformly bounded matrices, biases and all-row states; its depth and precision are charged in Section 6.

## 2. Exact rational protected estimator and clipping

For k>=1 let the observed terminal pair be (a,c)=(Z_(N-1),Z_N). Its designated successor is d=1-a. Let C_des count observed training triples with context (a,c) and successor d. Use the reviewed binary protected estimator from EPR001/SC003:

    v_d = max{C_des-6k,0}/(J'_(a,c)+6k+2),
    q_raw(1)=v_d if d=1, and q_raw(1)=1-v_d if d=0.

This is the fixed-orientation lower-envelope estimator, not corrupted-row add-one.

Let zbar=M^-1 sum_(t=3)^N Z_t and delta=1-beta. Binary TV equals absolute difference of symbol-1 probabilities. Therefore EPR001's radial projection is exactly the scalar clip

    q_lat = min{zbar+delta, max{zbar-delta,q_raw(1)}}.    (R3)

It lies in [0,1] because q_raw and zbar do. Negative lower interval endpoints or upper endpoints above one cause no difficulty; the selected value still lies in [0,1].

All terms in (R3) are rational. To make this fully explicit, put D_row=J'_(a,c)+6k+2 and let n_raw be its numerator for q_raw(1). With n_1=M zbar and b_num=2^p-a_beta, a common denominator is

    D_all=M D_row 2^p>0.

The three numerators used in the nested clip are

    n_raw M2^p,
    D_row(2^p n_1-M b_num),
    D_row(2^p n_1+M b_num).

Signed integer comparisons implement min/max, and the chosen numerator is in [0,D_all]. The output

    q_lat,r = 2^-r floor(2^r numerator/D_all)

has absolute error below 2^-r. The possible integer output bit one is retained. No real division, discontinuous scalar rounding primitive, or free rational output decoder is added to the Transformer: ordinary Boolean integer division produces the finite output bit word before the existing ReLU compilation.

## 3. The clipped estimator's posterior risk and explicit constants

The independently reviewed EPR001 protected-to-endpoint wrapper gives, for the latent original-terminal row,

    E|q_lat(Z)-theta_(S(X))(1)|
      <= (2^18+sqrt(2)/2)s +(2^20+1)F_beta
             +2rho(1-beta),
    s=M^-1/2,
    F_beta=(k/M)[1+log(1+1/(e k))],
    e=max{sqrt beta,1/M}.                              (R4)

Its imported binary protected constants are A_2=2^17 and B_2=2^19. The wrapper repairs the attack when an endpoint changed instead of conditioning the protected theorem on an adaptively selected event.

That auxiliary repaired channel can be offline; it is only a comparison device inside an upper proof already valid for all source-independent strict-k channels. The actual channel being implemented remains in the paid online finite-state subclass. The predictor neither runs that repair nor receives the original word.

Future blindness supplies the exact identity

    p_(theta,C)(Z)=E[theta_(S(X))(1)|Z].

Since q_lat is Z-measurable, conditional Jensen transfers (R4) unchanged to posterior prediction. This is an upper-bound transfer only; no latent-target lower bound is transferred.

For k>=1, b=2^-u<=beta implies

    F_beta <= (k/M)[1+log(1+2^(u/2))]
            <=(u+2)k/M.

Indeed e>=sqrt beta>=sqrt b and k>=1. Hence (R4) is at most

    C_lat(s+k/M+rho), C_lat=2^22(u+2).

Because u+2<=2^(u+1), C_lat<=2^(u+23)<=C_0=2^(163+10u). We have the fully explicit posterior bound

    E|q_lat(Z)-p_(theta,C)(Z)|
       <=min{1,C_0(s+k/M+rho)}.                       (R5)

Neither sqrt beta nor the logarithm in F_beta must be evaluated by the predictor or compiler; they only justify the stated bound on its rational estimator.

## 4. The other estimator and entirely public selection

Let q_post be the exact full majority/fitted-posterior/saturated estimator from `KNOWN_CHANNEL_full_logfree_transformer_composition.candidate.v1.md`, using the same b=2^-u and A. That independently reviewed result gives

    E|q_post(Z)-p_(theta,C)(Z)|
       <=min{1,C_0 a_0},
    a_0=((k+1)^2/M)^(1/3).                            (R6)

Its implementation q_post,r differs from q_post by at most 2^-r on every word. In particular this is the full log-free estimator, not an unsupported claim about the fitted-posterior branch alone.

For public integer M, let h_M=floor(log2 M) and define

    s_up=2^-floor(h_M/2).

The bit length of M gives h_M exactly, and s<=s_up<2s.

Let h_a be the least integer satisfying

    M 2^(3h_a)>=(k+1)^2,

where a negative exponent is handled by multiplying the opposite side by its denominator. Put a_up=2^h_a. This uses only integer shifts and comparisons. Its search range has O(log N) possible integer exponents, and

    a_0<=a_up<2a_0.

Define L_up=s_up+k/M+rho. The compiler makes the public decision

    choose q_lat,r if L_up<=a_up;
    otherwise choose q_post,r.                        (R7)

The selection depends only on M,k,beta,rho and is independent of the displayed word, source, hidden seed and edit mask. It is evaluated exactly by integer arithmetic on finite rationals. It is not validation-set selection or a potentially overfitting choice based on the observed trajectory.

## 5. Proof of the interpolation bound and the zero budget

First select between the exact estimators in (R5)-(R6), before their finite output approximation. Equations (R5)-(R7) give

    risk <=C_0 min{L_up,a_up}
         <=2C_0 min{s+k/M+rho,a_0}.

Let B_0=s+k/M and a_k=(k^2/M)^(1/3). For k>=1, a_0<=2a_k. Therefore

    min{B_0+rho,a_0}
       <=B_0+min{rho,a_0}
       <=B_0+2min{rho,a_k}
       <=2[B_0+min{rho,a_k}].

This proves the C_int=4C_0 exact-estimator bound. Only one selected output is used, so replacing it with its dyadic approximation adds at most 2^-r, not two such errors. Every output belongs to [0,1], giving the unit cap in (R1).

When k=0, the channel is identity on every realization, regardless of the supplied rho. Use the clean add-one row at the actual displayed terminal pair,

    q_clean(1)=(C'_(S(Z),1)+1)/(J'_(S(Z))+2),

and its dyadic approximation. The inherited clean bound A_2 M^-1/2 with A_2=2^17 gives (R2). No endpoint term or positive-edit selector is used in this branch.

## 6. Paid bit, network and compiler resources

Let ell count the expanded per-time rational channel initialization and transition-table description, and S the channel state count excluding the separately charged edit counter. Retain

    B_base=ell+4(N-1)ceil(log2 N)+ceil(log2(N+2))+r+4,
    B_full=B_base+30u+512

from the complete log-free construction. A conservative interpolation budget is

    B_int=B_full+p+q+4ceil(log2(N+1))+64,
    R=O(NS^2(k+1)),
    G_int=O((R+N+1)B_int^2),

padded to include N ceil(log2(N+1))+r+u+p+q+1 wires/gates. Precision exponents p and q are charged as actual rational precision/storage costs, even if a compact header writes those exponents in binary. An arbitrarily long binary expansion is not free.

The clipped estimator alone needs O(p+r+log N)-bit arithmetic, since D_row<=7M+2 and D_all=M D_row 2^p. The public selector needs O(q+log N) rational comparison bits and O(log N) exponent comparisons. They can be computed by the compiler, or included as constant-input Boolean subcircuits. The displayed G_int safely covers either approach and both candidate estimators. No channel lookup oracle is added.

Applying the reviewed Boolean-to-Transformer constructions gives either:

- Growing bank: d=O(G_int), L=O(G_int), exact scalar bit length w=O(r+log(N+1)+log(G_int+1)).
- Constant-width two-stack simulation: d=64, FFN128, L=O(N log(N+1)+G_int^2), w=O(G_int+r+log(N+1)).

Both preserve the raw-input, causal-mask, zero-score and uniform per-matrix/bias/all-row-state bounds. Large thresholds and dyadic certificate bits are finite circuit data, not large network coefficients. The per-scalar exact bit costs are different because one construction stores Boolean work spatially and the other packs it into explicitly charged finite base-four stack digits.

Conservative exact-rational dense runtime is O(L(Td^2+T^2d)w^3), rolling states O(Tdw) bits, optional materialized scalar attention O(T^2w), and explicit untied dense parameters O(Ld^2[log(N+1)+log(G_int+1)]) bits. The constant-width stack parameter coefficients need only O(log N) bits apiece. Rational-channel preprocessing, public-certificate/selector arithmetic, circuit generation and parameter emission are separately charged and polynomial in the displayed finite inputs. No IEEE robustness, training result or optimal frontier follows.

If rho is supplied only approximately, a certified dyadic rational upper budget rho_bar may replace it, with its precision charged in q. The guarantee then contains rho_bar. Recovering the original moving-rho rate requires an appropriately accurate certificate or paying its excess, since min{rho_bar,a_k}<=min{rho,a_k}+(rho_bar-rho). Unnamed arbitrary real beta/rho values are not paid computational interfaces.

## 7. Lower bounds and limitations

The broad statistical theorem permits arbitrary future-blind offline channels. Its sharp lower witnesses cannot simply be imported into the online finite-state subclass. In particular, the earlier EPR latent original-terminal endpoint lower is not a posterior-target lower, and this composition makes no such transfer.

The identity channel belongs to the subclass and supports the ordinary clean statistical lower, but a full matching restricted-channel lower for the k/M and min{rho,a_k} terms is not established here. Consequently the correct claim is an explicit implementation of the sharp-rho statistical upper profile on the paid subclass, not a proved sharp minimax theorem for that subclass.

All statistical expectations refer to the stationary source experiment and the source-specific posterior target. No conditional-on-word guarantee, arbitrary unknown initial-law theorem, bounded-precision/IEEE execution, pre-LayerNorm architecture, tied network, fixed-network length generalization or resource-optimal depth statement is asserted.

## 8. Imported sources

1. `EPR001_endpoint_probability_interpolation.md`, Sections 2-5, and `EPR001_independent_analytical_review.md`: binary SC003 lower-envelope rule, clipping, repaired-channel upper, and explicit constants A_2=2^17, B_2=2^19. Its predecessor protected theorem is imported at the reviewed scope, not freshly reproved.
2. `KNOWN_CHANNEL_stationary_binary_rho_interpolation.v1.md`, Section 3: conditional-Jensen posterior transfer and deterministic estimator selection.
3. `KNOWN_CHANNEL_full_logfree_transformer_composition.candidate.v1.md` and its independent review: explicit A, full log-free estimator, stationary risk and complete branch compilation.
4. `KNOWN_CHANNEL_finite_state_transformer_bridge.candidate.v1.md`, `KNOWN_CHANNEL_finite_state_constant_width_bridge.addendum.v1.md`, and their independent review: paid finite-state DP and bounded-norm raw-token compilations.

This new composition and its resource accounting require their own independent analytical review before promotion.
