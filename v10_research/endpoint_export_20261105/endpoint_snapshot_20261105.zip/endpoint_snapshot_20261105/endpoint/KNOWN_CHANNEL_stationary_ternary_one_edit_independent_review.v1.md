# Independent review: stationary ternary one-edit lower

**Analytical PASS for the ternary lower and its stated full-support variant.** No unresolved mathematical blocker was found.

Present-time complete read and SHA-256 capture: **2026-11-05T03:34:23Z**.

Reviewed source: `KNOWN_CHANNEL_stationary_ternary_one_edit_lower.md`.

SHA-256: `2620f9d7e434ac86f4d8ca0a6194a0e9a766bb086debb9e13f03c98d37bdf271`.

This binds the current bytes actually reread, not a historical hash claim. The reviewer did not edit the source. Work consisted of analytical reasoning, file reading, hashing, and review-document writing. No scientific executable check, numerical experiment, simulation, test suite, or public write was performed.

## 1. Claim and exact scope

For integer M>=64, N=M+2, beta,rho in [0,1], and an edit upper budget k>=1, the note constructs one disclosed, source-independent, future-blind ternary channel using at most one edit on EVERY word. Two stationary sources in the all-state D2(beta) class give maximum posterior-predictive TV risk at least rho(1-beta)/128. A second pair, both with positive ternary transition tables, gives rho(1-beta)/512.

The predictor knows the channel algorithm, not its realized seed, edit mask, or hidden branch. The true source parameter remains unknown. The target is the conditional next-symbol law under each fixed true source and channel, not a prior-averaged target. Future generation uses the original terminal state. These are particular-channel lower bounds, not bounds for every known channel.

The sources depend on M. Full support in the second construction does not impose a positive transition floor independent of M, and the lower is not a pointwise inconsistency claim for one fixed positive source.

## 2. Stationary clone factorization and source order

The alphabet is {0,1,*}, with collapse c(0)=c(*)=0, c(1)=1. Starting with the stationary binary Q chain, independently labeling each zero as ordinary 0 or rare * with probabilities 1-p and p produces precisely the transition table T_p in the note. This is a genuine observed first-order Markov chain, not merely an unverified hidden-Markov representation: each ternary observation determines its collapsed binary state.

The stationary symbol law is ((1-p)/2,1/2,p/2) in the order 0,1,*. The initial PAIR law Pi_p(a,b)=pi_p(a)T_p(a,b) is correct and retains the correlation of the collapsed Q chain. It is not replaced by pi_p tensor pi_p.

Conditional on an entire collapsed V path, clone assignments at its zero locations are independent Bernoulli(p), including the initial observation. Thus the number of rare clones in a prefix with m collapsed zeros is Binomial(m,p). The argument does not treat the correlated collapsed chain itself as IID or assert an unconditional Binomial(M,p) clone count.

For every starting and target symbol, T_p(x,y)>=(1-2alpha)pi_p(y). This remains true at p=0 for a starting rare clone outside stationary support. Multiplying by the next transition gives

    P_p^2((a,b),(c,d))
      =T_p(b,c)T_p(c,d)>=(1-2alpha)Pi_p(c,d)>=beta Pi_p(c,d).

The all-state certificate is therefore valid on all nine pair states, including unsupported states. For p in (0,1), Q's entries are positive and every ternary transition and stationary pair mass is positive.

## 3. Full per-word channel legality

If either final-pair token is *, the channel returns identity. Otherwise it inspects the M positions 1,...,N-2. With no interior *, it may flip the final binary token using the independent Bernoulli(rho) coin. With exactly one interior *, it erases that token to 0 and makes no terminal modification. With two or more it returns identity.

These branches are mutually exclusive. The interior branch excludes BOTH terminal positions. Hence every input/output realization differs in at most one token and every input has terminal-pair change probability at most rho. The source-independent algorithm uses no p, Q, unknown source index, or future innovation. It is an offline observation channel, not a source-state intervention or an online-channel theorem.

The parameter rho bounds endpoint changes only. The deterministic interior erasure is allowed even when rho=0. For the optional larger-alphabet embedding, the final source now explicitly extends the channel by identity on every word containing any added symbol. That clarification makes the channel defined and legal on the full extended input alphabet.

## 4. Exact full-observation masses, including terminal clone loss

The proof restricts to complete observed words z=(h,1) with h binary. Let H(h) be the probability of the collapsed prefix V_(1:N-1)=h, let b=h_(N-1), r=Q(b,1), and let m count zeros among h_1,...,h_M.

The clone-free penultimate token contributes s_p=(1-p) raised to the indicator b=0. Exactly original interior clone counts zero and one can yield the displayed binary interior, giving

    w0_p=(1-p)^m,
    w1_p=mp(1-p)^(m-1),
    g_p=w0_p+w1_p,
    t_p=rho w0_p/g_p=rho(1-p)/[1+(m-1)p].

Here t_p is a branch probability before conditioning on the displayed terminal token. It is not incorrectly held fixed as a posterior branch probability after observing that token.

The terminal guard is important. An original final * remains * and cannot appear in the restricted event ending in 1. The original binary-last masses are therefore UNNORMALIZED r for state 1 and (1-r)(1-p) for ordinary state 0. Dropping this excluded mass or normalizing it without restoring the factor would give the wrong observation likelihood.

Direct enumeration of the count-zero and count-one preimages gives

    ell_p=r(1-t_p)+(1-r)(1-p)t_p,
    P_p^Z(h,1)=H(h)s_p g_p ell_p,
    A_p=P_p(c(X_N)=1|Z=(h,1))=r(1-t_p)/ell_p.

Equivalently, the unnormalized contributions to the displayed terminal 1 are r[(1-rho)w0_p+w1_p] and (1-r)(1-p)rho w0_p. This confirms the full-word mass, not just a terminal marginal or a count-only surrogate.

Because T_p(x,1)=Q(c(x),1), the actual next-symbol probability of event {1} is exactly 1/2-alpha+2alpha A_p. Other next-symbol probabilities may also differ, but they are not needed for the TV lower.

## 5. Terminal mixture and posterior separation

For p0<p1 and a fixed h, let D_i=1+(m-1)p_i. Exact subtraction gives

    d=t0-t1=rho m(p1-p0)/(D0 D1)>=0,

    A1-A0
      =r(1-r)[(1-p0)d+(p1-p0)(1-t0)t1]/(ell0 ell1).

The second numerator term is nonnegative. Thus selection against an original terminal clone and the lower flip probability under p1 reinforce the posterior difference on displayed terminal 1. There is no approximation or subtracted O(p) error that might fail when rho is small.

All denominators are positive for p_i<1, including rho=0 or 1. For m=0, g_p=1, D_p=1-p, and d=0. The proof legitimately discards that zero contribution to its chosen lower, without asserting that every other possible posterior difference vanishes there.

The full observation laws need not coincide. Both s_p and g_p=P(Binomial(m,p)<=1) are nonincreasing in p. For m=0,1, g_p is constant; for m>=2 the monotonicity follows by coupling or differentiating the binomial expression. Consequently the smaller prefix factor can be bounded using s_1g_1.

Using r(1-r)>=3/16 and max(ell0,ell1)<=3/4, the pointwise common observation mass times target-TV separation is at least

    H(h)s_1g_1 (alpha/2)(1-p0)d.

Triangle inequality against the same predictor under the two source laws, then division by two, proves

    max_i Risk_i >= alpha(1-p0) E_H[s_1g_1d]/4.

Independent predictor randomization is harmless: apply the pointwise inequality for each common independent seed and average.

## 6. Event weights and constants

For p0=0 and p1=p=1/M,

    g_1d=rho mp(1-p)^(m-1).

For m>=1, s_1>=1-p and m<=M imply s_1g_1d>=rho mp(1-p)^M. The m=0 term is zero. Since the collapsed process is stationary with zero marginal 1/2,

    E_H[m]=M/2,
    E_H[s_1g_1d]>=rho(1-1/M)^M/2>=rho/8.

The expectation here is explicitly under the common collapsed-prefix measure H, not under a falsely unchanged conditional observation law. The necessary observation weights s_1g_1 were already retained inside the overlap integral. The inequality (1-1/M)^M>=1/4 for M>=2 is valid. Thus the lower is rho alpha/32>=rho(1-beta)/128.

For the positive-table variant p0=1/(2M), p1=1/M, D0<=3/2 and

    g_1d=rho m(p1-p0)(1-p1)^(m-1)/D0.

The same argument gives E_H[s_1g_1d]>=rho(1-1/M)^M/6>=rho/24. Since 1-p0>=3/4, the maximum risk is at least rho alpha/128>=rho(1-beta)/512. These constants check exactly.

## 7. Binary comparison and review boundary

The ternary lower is self-contained apart from the declared actual-prediction convention and elementary overlap inequality. Its comparison with binary consistency imports `KNOWN_CHANNEL_stationary_binary_upper.v2.md`.

This reviewer read the finding/scope of the separate `KNOWN_CHANNEL_stationary_binary_upper_independent_review.v2.md`, which binds that upper candidate to SHA-256 `e4b5840206bff6735b5cce4a6dfeb70d9ea2568341dc0128773fa6c68327156b` and reports a valid stationary binary fixed-positive-beta bound with k=o(sqrt(M)) as a sufficient consistency regime. The binary upper was not independently re-audited in this review. Its rate and threshold are not asserted necessary or sharp.

Accordingly, the binary-versus-ternary contrast has the stated fixed-positive-beta, stationary, known-channel scope. It must not be generalized to unknown channels, arbitrary initialization, moving beta, or a fixed positive transition floor without separate proof.

## Disposition

Analytical PASS applies to the exact ternary source file identified above, including the two constants, stationary initialization, all-state certificate, strict all-word budget, endpoint-only rho condition, terminal-clone accounting, and larger-alphabet identity extension. No unresolved blocker remains in this scope.

This is not formal verification, external peer review, a novelty certificate, a numerical test, or a computational/neural realization. Full support in the positive variant is explicitly distinct from a uniform positive transition floor.
