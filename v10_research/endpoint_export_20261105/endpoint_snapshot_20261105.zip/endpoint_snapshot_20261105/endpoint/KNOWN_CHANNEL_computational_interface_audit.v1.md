# Disclosed-channel posterior prediction: the computational interface must be paid

Date: 2026-11-05 UTC. Pure analytical supplement. No scientific program, simulation, numerical check, formal verification, public write, or novelty claim. This note does not change the statistical interpolation theorem. It separates mathematical disclosure from a bounded-resource implementation and gives a sufficient structured-channel interface for evaluating the existing estimator.

## 1. Results first

1. The statistical theorem permits arbitrary disclosed kernels. Disclosure alone bounds neither channel-description length, evaluation time, numerical precision, nor the cost of integrating out hidden histories and channel randomness.
2. This is a real obstruction, not merely an incomplete implementation. With k=1 and any fixed beta in (0,1), one fixed, fully known, positive stationary binary source supports channels whose posterior predictions encode arbitrary Boolean functions of the retained prefix. For every fixed rho>0, a weighted counting argument forces exponentially many total description bits to attain o(rho) expected error uniformly over these channels, unless external channel access or storage is left uncharged.
3. A separate, explicitly computable but deliberately slow, single batch-channel program can be constructed by finite circuit counting. Its posterior requires exponentially large digital circuits. This conclusion requires a charged finite-precision digital computation model; it is not a lower bound for unrestricted real-arithmetic networks.
4. The representation witness is easy with a free likelihood oracle. At k=1 there are only N+1 possible clean preimages of an output. Thus one must not confuse representation/evaluation hardness with an exponential inverse sum at fixed k.
5. A known, rational, polynomial-size finite-state stochastic transducer, with an explicit edit counter and certified endpoint gate, permits the fitted posterior in the existing upper bound to be evaluated by a forward dynamic program in O(N S^2 (k+1)) arithmetic operations, with polynomial paid bit complexity. The statistical upper transfers to this subclass. The matching lower for that restricted subclass is not established here.

## 2. Inputs and the scope of the existing result

The relevant local inputs are:

- `KNOWN_CHANNEL_stationary_binary_rho_interpolation.v1.md`, particularly Sections 1, 3, and 6.
- `KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md`, particularly Sections 3, 5, and 7.
- `POSTERIOR_CHANNEL_primary_source_audit.v1.md`.
- `RHO_INTERPOLATION_primary_source_audit.v1.md`.
- Relevant target, disclosure, and computational-scope statements in `EPR001_primary_source_prior_art_audit.v1.md` and `QUANTITATIVE_BINARY_RATE_primary_source_audit.v1.md`.

The interpolation theorem fixes beta in (0,1), takes N=M+2, and permits the channel and estimator to depend on M and the public budgets. Each fixed-source target is

    p_(theta,C)(z) = P_(theta,C)(X_(N+1)=1 | Z=z).

The realized channel seed is not part of the observation. Future blindness means the joint law factors as

    P_theta(x) C(z|x) theta_(S(x))(y).

The theorem's infimum allows a different mathematical predictor q_C for each disclosed C. It does not bound how C is represented or how q_C is computed. In particular, cancellation of C(z|x) in a comparison of two posterior likelihood ratios does not eliminate that factor from the posterior that must actually be evaluated.

For k=1 and fixed positive rho, the unrestricted unknown-source statistical risk is order M^(-1/3). The example below shows that this rate need not be achievable by a uniformly small finite-precision model over the full arbitrary-channel class, even when the source itself is also revealed.

## 3. One fixed source and arbitrary one-edit channels

Fix beta in (0,1). Set

    delta = (1-beta)/4,
    l = 1/2-delta,
    u = 1/2+delta.

Use the stationary symmetric first-order binary chain

    T(b,1) = l+2 delta b,
    T(0,0)=T(1,1)=u,
    T(0,1)=T(1,0)=l.

View it as an order-two source with theta_(a,b)(c)=T(b,c). Its stationary pair law is Pi(a,b)=T(a,b)/2. Its pair-chain two-step kernel satisfies

    P^2((a,b),(c,d)) = T(b,c)T(c,d),
    P^2((a,b),(c,d))/Pi(c,d) = 2T(b,c) >= 2l >= beta.

Thus this one positive stationary source belongs to D2(beta). It is fixed across all horizons, and it may be fully revealed to the predictor. No unknown source sign is used anywhere in this construction.

Let n=N-1. For any Boolean function f:{0,1}^n->{0,1}, define C_f by drawing E~Ber(rho), independently of the source and its future innovation, and setting

    Z_1:n = X_1:n,
    Z_N = X_N xor [E f(X_1:n)].

This channel is source independent and future blind, is defined on every input word, and changes at most one symbol on every realization. Its endpoint-change probability on input x is exactly rho f(x_1:n), hence at most rho. At rho=1 it is deterministic and bijective; no seed is hidden at all.

Write y for the retained prefix, w for the displayed last bit, and

    r_y = T(y_n,1) in {l,u}.

If f(y)=0 then the clean last bit is w, so p_f(y,0)=l. If f(y)=1 then Bayes' rule gives

    ell_0(y) = P(Z_N=0 | y,f(y)=1)
             = (1-r_y)(1-rho)+r_y rho in [l,u],
    p_f(y,0) = l + 2 delta r_y rho / ell_0(y).

The two possible target values at (y,0) therefore have separation at least

    Delta = 2 delta l rho/u.                         (C1)

Under either choice of f(y), the conditional probability of displayed last bit zero is at least l. This bound is uniform over prefixes, so the argument below cannot lose its mass on a rare displayed word.

For rho=1 the entire target simplifies to

    p_f(y,w) = l + 2 delta [w xor f(y)].              (C2)

Consequently, evaluating the posterior to accuracy less than delta at every (y,0) recovers f exactly. Section 4 strengthens this worst-word statement to expected risk.

## 4. Exponential description lower for expected risk

### 4.1 The resource contract

Fix one interpreter/architecture family at horizon N. A descriptor of at most B bits specifies the entire predictor, including its architecture, finite-precision weights, constants, and any channel-dependent compiled advice. There are fewer than 2^(B+1) such descriptors. No channel-specific truth table, code, oracle, or preprocessing result is supplied for free outside those B bits.

Randomized predictors are allowed if their probability law is specified by the descriptor and their random coins are independent auxiliary coins. Conditional Jensen lets us replace each such predictor by its mean output for the purpose of a lower bound. There are still at most as many mean-output functions as descriptors. This argument is about total finite descriptions, not a count of unrestricted real-valued parameters.

The interpreter can be fixed in advance; it cannot be chosen anew for each f without charging that choice. Equivalently, all channel-specific hard-coded information must be counted.

### 4.2 Decoding from small prediction loss

For each descriptor d, let q_d(y,0) be its mean prediction and define g_d(y) by thresholding at the midpoint of the two possible target values from Section 3. These two values depend only on y_n, the fixed source, and rho, not on unknown f.

If g_d(y) differs from f(y), then q_d(y,0) has absolute target error at least Delta/2. Since the conditional mass of w=0 is at least l,

    R_f(q_d) >= A_beta rho d_mu(f,g_d),
    A_beta = delta l^2/u,
    d_mu(f,g) = sum_y mu(y) 1{f(y)!=g(y)},           (C3)

where mu is the clean, and also displayed, prefix law. This holds even though the full displayed-word law depends on f.

### 4.3 Weighted counting

The prefix law is

    mu(y) = (1/2) product_(i=2)^n T(y_(i-1),y_i).

Its collision mass is exactly

    sigma_n^2 := sum_y mu(y)^2
               = (1/2)(l^2+u^2)^(n-1).             (C4)

To see this, sum the squared transition weights successively: both rows have squared sum l^2+u^2, and the two possible starting symbols contribute 2*(1/2)^2.

Draw all truth-table bits f(y) independently and uniformly. For each fixed g_d, the mismatches are independent Ber(1/2) variables, weighted by mu(y). Hoeffding's inequality gives

    P_f{d_mu(f,g_d)<=1/4}
      <= exp[-1/(8 sigma_n^2)]
      = exp[-1/(4(l^2+u^2)^(N-2))].                (C5)

Union bound over all descriptors. If

    (B+1) log 2 < 1/[4(l^2+u^2)^(N-2)],            (C6)

there exists one f for which every such predictor has d_mu(f,g_d)>1/4, and hence

    R_f(q_d) > A_beta rho/4                         (C7)

for every predictor in the resource class. The same fixed known source is used throughout. The channel depends on f and the horizon, as the original theorem allows.

Since l^2+u^2=1/2+2delta^2<1, the right side of the bit requirement is exponential in N. Thus uniform expected error o(rho) over all disclosed one-edit C_f requires exponentially many total description bits in this model. This is stronger than merely observing that some exact targets have enormous truth tables.

For fixed beta<1 and fixed rho>0, (C7) stays bounded away from zero, whereas the unrestricted theorem gives O_beta(M^(-1/3)). There is no contradiction: its estimators have no B-bit resource restriction.

If rho shrinks, the obstruction scales with rho. When rho<=a(M,1)=M^(-1/3), this argument does not prevent an efficient predictor from achieving the statistical minimax order while ignoring the details of f. At rho=0 the construction is identity and proves no computational obstruction. At beta=1, delta=0 and the witness also disappears. No beta-uniform lower is claimed.

## 5. Fixed channel versus horizon-dependent channels

The simplest conclusion above uses a different arbitrary table f_n at each horizon. That is a legitimate C_M witness for the stated finite-horizon worst-channel theorem, but it is not by itself one short, fixed channel program that is hard at every length.

A stronger uniform-computability statement is possible under a digital circuit resource model. Choose a fixed positive rational delta<1/2 with 1-2delta>=beta; now the prefix weights in (C4) are rational and exactly computable. Set rho=1. Choose a fixed rational eta with

    0 < eta < -log_2(l^2+u^2),
    s_n = 2^floor(eta n).

There are at most exp[O(s_n log(s_n+n))] Boolean circuits of size at most s_n over a fixed finite fan-in-two basis. For all sufficiently large n this count is smaller than the reciprocal probability in (C5). Hence some Boolean table f_n has d_mu(f_n,g)>1/4 for every such circuit g.

Define f_n to be the lexicographically first table with that property; if exhaustive search finds no such table, use the all-zero table. The fallback occurs at most at finitely many small lengths. This family is computable by one finite program without knowing an explicit onset horizon: enumerate the finitely many tables and circuits, evaluate them on the finitely many inputs, and compare their rational weighted disagreement. This is an existence proof of a finite, terminating algorithm, not an instruction to run that enumeration. Its runtime is enormous.

The single program C takes a finite input word x, computes n from its length, computes f_n(x_1:n), and flips only its last bit by that value. It is a deterministic, future-blind, source-independent strict-one-edit batch channel. On every sufficiently large n, a predictor whose thresholded output q(y,0)>=1/2 is implementable by a Boolean circuit of size at most s_n has constant expected posterior error: (C2) and the same mass argument give at least delta l/4.

This is an unconditional circuit-counting obstruction, not a computational-complexity conjecture. Applying it to a Transformer requires a separate, explicit simulation contract: bounded-bit inputs/weights/activations, a finite digital output convention, and elementary operations whose cost is charged. A polynomial-size finite-precision digital implementation produces only a polynomial-size Boolean circuit, so it cannot evaluate this target uniformly in n with vanishing expected error. A randomized implementation is covered when fixing any of its independent random tapes yields a circuit within the charged bound: every fixed tape has the lower bound, so their average does too. Unrestricted real weights or unit-cost operations on arbitrarily many bits are outside this conclusion.

Compact program description alone does not imply fast execution. Conversely, the fixed-program result is not an exponential *program-description* lower: the deliberately slow program is short. Sections 4 and 5 address different resources.

Finally, one fixed algorithm accepting different finite batch lengths is not the same thing as a projectively consistent corruption of one infinite stream. Here the location called "last" changes with the horizon. No infinite-stream consistency or causal online-emission theorem follows.

## 6. What free oracle access changes

The counting obstruction disappears if the channel table or an evaluation oracle is supplied for free as additional information. For rho>0, the single exact likelihood query

    C_f((y,0) | (y,1)) = rho f(y)

reveals f(y). With known source, the target can then be computed from the formulas above. An approximate likelihood oracle accurate to less than rho/2 also identifies f(y). For rho=1 a forward evaluation of the deterministic channel on (y,0) reveals f(y) directly.

Thus this witness does not prove a lower bound on the number of unit-cost channel-oracle calls. If a truth table is supplied in random-access memory, lookup may be fast, but its exponentially large storage has not vanished. If it is supplied as an ordinary sequence of input tokens, that input length and its processing must be counted. If a small program is supplied, the runtime of executing it cannot be declared free.

Giving the realized random seed is another change of interface. The theorem does not do so. The rho=1 witness needs no hidden seed, and therefore its computational obstruction survives even complete disclosure of every random choice. For rho<1, observing E changes the natural target to P(X_(N+1)=1|Z,E); on the branch E=1, which has probability rho, the deterministic decoding issue remains. This is a separate statistical experiment, not an unqualified extension of the interpolation theorem's lower bounds.

Efficient forward sampling is also not the same promise as efficient evaluation of the exact kernel C(z|x). A sampler may hide a sum over many seeds. This note uses no hardness assumption for that latter distinction and proves no general approximate-inference lower in the sampler-oracle model.

## 7. The actual enumeration bound is the Hamming ball

For any strict-k channel, a clean preimage x of z belongs to the Hamming ball around z. Its size is

    B(N,k) = sum_(j=0)^k binom(N,j).

The posterior estimator in the log-free upper fits positive Pi_hat and theta_hat from z, then evaluates

    q_C(z) =
      [sum_(x:d_H(x,z)<=k) P_hat_z(x) C(z|x) theta_hat_(S(x))(1)]
      / [sum_(x:d_H(x,z)<=k) P_hat_z(x) C(z|x)].       (C8)

One direct implementation uses B(N,k) likelihood evaluations and O(N B(N,k)) additional arithmetic operations. Its numerical costs depend on the likelihood representation. At fixed k and efficient pointwise likelihood access, this is polynomial in N; at k=1 it examines only N+1 histories. At growing k it can be superpolynomial, and B(N,k) is exponential for appropriate linear k. That is an upper bound on an enumeration implementation, not a computational lower bound.

Moreover, the statistical theorem can choose a simpler estimator or a trivial capped bound in regimes where full posterior evaluation is unnecessary. One cannot infer a minimax runtime lower merely because (C8) has many terms, particularly when the statistical rate is already constant.

## 8. A structured interface that permits paid computation

### 8.1 Channel representation

A sufficient restriction is a known time-inhomogeneous stochastic finite-state transducer. Its hidden state has S possibilities, with a specified rational initial distribution independent of the source. Given current clean symbol x_i and its previous state s, it emits z_i and updates its state to s' with known rational probability

    K_i(s',z_i | s,x_i).

Each row sums to one. The state may include a public-position-dependent endpoint gate. The transducer may depend on N and public budgets, but not on an unknown source parameter or on future innovations.

To enforce the raw edit cap, augment with e in {0,...,k}, update it by 1{x_i!=z_i}, and forbid a change when e=k. The counter update is deterministic once x_i,z_i are specified. To enforce endpoint reliability, one simple construction draws G~Ber(rho_g) independently at initialization, stores G in the state, and forbids editing positions N-1,N whenever G=0. Choose rho_g=rho when rho is represented rationally, or any supplied rational rho_g<=rho otherwise. The probability of any endpoint change conditional on every fixed input word is then at most rho_g<=rho. Other separately certified implementations are possible.

Forbidden states must still have a specified row-stochastic transition. For example, start from a base row K_i^0 and, when an edit is forbidden, define K_i(s',x_i|s,x_i)=sum_z K_i^0(s',z|s,x_i) and K_i(s',1-x_i|s,x_i)=0. Thus would-be edits are explicitly redirected to a no-edit output while retaining the chosen next state. This defines a new normalized channel; it does not silently zero probability mass, truncate paths, or condition a different channel on satisfying the budget.

This subclass is meaningful and nonempty, but it is narrower than arbitrary offline channels. Ordinary independent symbol flips do not by themselves satisfy an all-realization hard edit cap; the explicit counter matters. The independent endpoint gate and hard counter also impose different constraints and should not be conflated.

### 8.2 Forward recurrence

Use the same positive Pi_hat and theta_hat from the reviewed statistical upper. For i>=2, define alpha_i(a,b,s,e) as the fitted joint mass of the displayed prefix z_1:i, last two clean symbols (a,b), channel state s, and used edit count e.

Initialize at i=2 by summing the known initial channel state, its first two transitions, the four possible clean initial pairs, and Pi_hat(a,b). This can be implemented by two vector-matrix products for each clean pair; no stationarity of Pi_hat for theta_hat is needed.

For i>=3, accumulate

    alpha_i(b,c,s',e') += alpha_(i-1)(a,b,s,e)
                          theta_hat_(a,b)(c)
                          K_i(s',z_i | s,c,e),
    e' = e+1{c!=z_i}, e'<=k.                       (C9)

The endpoint gate can be included in s. At the final time,

    D = sum_(a,b,s,e) alpha_N(a,b,s,e),
    A = sum_(a,b,s,e) alpha_N(a,b,s,e) theta_hat_(a,b)(1),
    q_C(z)=A/D.                                    (C10)

If D=0, define q_C(z)=1/2. Because the fitted clean-word law has full support, D is positive on every output with positive probability under any true source and this channel. Thus the fallback does not affect the actual risk.

For binary order-two sources, the source-state and symbol factors are absolute constants. Dense transitions between S channel states give O(N S^2(k+1)) arithmetic operations and O(S(k+1)) working numbers. The update's deterministic edit-counter increment avoids an unnecessary factor k from a dense counter-to-counter transition matrix. If the supplied state count already includes the counter, use that convention consistently instead of counting it twice.

### 8.3 Precision and statistical effect

Suppose the transition and initialization tables are supplied explicitly, and every supplied rational probability has at most b numerator/denominator bits. Charge their full storage. If tables are instead generated by a program, add its generation/evaluation time and storage; a short generator alone is not a polynomial-time promise. The fitted probabilities have O(log N)-bit denominators. At each step, take a common denominator of the finitely many rational coefficients used there. The logarithm of that common denominator is at most the sum of their input denominator bit lengths. Across N steps, the numerator and denominator bit lengths are therefore polynomial in N, S, k, and b. Exact rational dynamic programming, followed by rounded division, has polynomial bit complexity, in addition to any charged table generation. Tiny evidence is not a hidden infinite-precision oracle: its rational encoding can still have only polynomially many bits.

Rounding the final scalar to absolute error at most epsilon increases expected loss by at most epsilon. Choosing epsilon smaller than the statistical target rate preserves its order. More efficient floating-point/scaled implementations need their own error analysis; no unstated numerical-stability guarantee is used here.

For fixed beta with the upper bound's constants available, the majority branch and the public deterministic choice between the two existing estimators remain as in the theorem. The finite-state recurrence evaluates precisely the posterior branch, rather than a different heuristic target. All statistical assumptions and future coupling remain unchanged.

This proves a sufficient computational *upper* interface. It is not a complete Transformer construction: translating the dynamic program into specified depth, width, heads, bit precision, sequence length, positional representation, and error tolerance still requires an explicit compilation theorem. It also does not establish that the original rare-normalization lower channels belong to a bounded-state transducer subclass, so the restricted subclass's sharp minimax rate remains a separate question.

## 9. Required wording for a bounded-resource claim

A later neural or algorithmic result should specify all of the following:

1. Whether one fixed C is used, or a horizon-indexed family C_M, and whether "fixed" means a batch program or a coherent infinite-stream mechanism.
2. Whether C is compiled into weights, supplied as tokens, stored in external memory, or exposed through a likelihood/sampling oracle.
3. The charged description/storage length, channel-evaluation runtime, preprocessing time, input/output access costs, numerical precision, and auxiliary randomness.
4. Whether the channel seed is hidden or observed, and the corresponding target sigma-field.
5. The fixed-beta regime and behavior of constants; the construction here is nontrivial only for beta<1.
6. The rho regime. Constant-rho computational separation is strong; an o(rho) claim is the appropriate scale when rho moves.
7. The actual posterior evaluation algorithm, or a proved approximation with a risk budget, rather than cancellation of a likelihood factor only within a statistical comparison proof.

Defensible concise description:

> The disclosed-channel interpolation is an unrestricted statistical existence theorem. An efficient implementation requires a paid representation and inference interface for the channel. Arbitrary one-edit channels can encode exponentially complex posterior functions, even for one fixed known stationary binary source. Known finite-state rational channels admit a forward dynamic program, while a resource-bounded Transformer realization and a matching restricted-channel lower require separate proofs.

The finite-state calculation is the ordinary forward-sum principle specialized to the current fitted source and edit counter. It is not presented as new methodology. Prior source audits already distinguish ordinary structured HMM observation mechanisms from arbitrary offline block channels; this supplement supplies a concrete resource obstruction and an explicit sufficient computational contract.
