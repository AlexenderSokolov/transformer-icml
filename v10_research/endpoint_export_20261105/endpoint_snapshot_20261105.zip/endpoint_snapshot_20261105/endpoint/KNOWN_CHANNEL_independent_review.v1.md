# Independent review: known-channel posterior counterexample

Status: **analytical PASS**, within the exact scope below. No unresolved mathematical blocker was found.

Present-time full-text read and SHA-256 capture: **2026-11-05T02:46:49Z**.

Reviewed file: `KNOWN_CHANNEL_posterior_counterexample.md`.

SHA-256: `0d4ab89cc49a0ada2adeb18d73dfec9984775376411c3f05c6637075212d9fb9`.

This binding identifies the current bytes actually reread, not an earlier historical hash. The source was preserved unchanged by this reviewer. Only analytical reasoning, file reading, hashing, and review writing were performed. No mathematical executable check, numerical experiment, simulation, or test suite was run; no public write was made.

## 1. Reviewed claim and its limits

For K>=5, even M>=64, N=M+2, beta,rho in [0,1], and

    ceil(4sqrt(M))+2 <= k <= M,

one fixed, fully disclosed stochastic channel and two stationary sources give posterior-predictive minimax TV loss at least

    (35/864)rho(1-beta).

The unknown quantity is which source generates the data, not the channel algorithm. Both source algorithms can also be known. Channel disclosure does not reveal the realized seed, the hidden count S, the scrambling bit A, or the edit mask; the proof uses the same observation interface as EPR001. In particular, revealing A would reveal the original terminal V bit from W and change this experiment.

The counterexample is horizon-specific: both sources and the known channel may depend on public M. At the minimal allowed budget k=ceil(4sqrt(M))+2, k=o(M). For fixed positive rho(1-beta), the lower therefore does not vanish even though the source transition tables approach each other. This is not a claim about a single fixed source at every horizon, a one-edit lower, K<5, every known channel, or online-only corruption.

## 2. Legal finite-alphabet Markov sources and all-state minorization

Each source has four generated symbols (u,v) in {0,1}^2 and a reserved fifth marker. U is IID Bernoulli(p_i), p_i=1/2 +/- 1/sqrt(M), and independent of the stationary symmetric first-order V chain with persistence alpha=min((1-beta)/2,1/4). Their product is a homogeneous FIRST-order chain on four symbols, hence a valid homogeneous second-order source by ignoring the first symbol in each context.

The stationary symbol law is pi_i(u,v)=nu_i(u)/2. Initializing the pair at Pi_i(c,d)=pi_i(c)T_i(c,d) gives the required stationary experiment. This is not an incorrect product initialization of the correlated V coordinates. The construction indeed makes all U positions IID, including the initial and final positions, independently of the entire V process.

For every supported destination c and every starting symbol b,

    T_i(b,c) >= (1-2alpha) pi_i(c).

Unused starting symbols reset to pi_i, so this inequality also holds there. Consequently P_i^2((a,b),(c,d)) >= (1-2alpha)Pi_i(c,d) >= beta Pi_i(c,d) for every pair state, including those outside support. Destinations involving unused symbols have zero stationary mass and satisfy the certificate trivially.

The lower bound 3/32 on all transitions inside the four-symbol stationary support is correct: the least U probability is at least 3/8 and the least V transition at least 1/4. There is deliberately no full support or fixed transition floor on all K symbols, since the marker is never generated. Maximum-row TV between the two source tables is exactly 2/sqrt(M), including unused starting rows.

## 3. Strict channel budget and observation interface

The count block 2,...,N-1 contains exactly M symbols. Setting h=ceil(4sqrt(M)) and returning identity outside |S-M/2|<=h makes the budget a WORST-CASE bound, not a high-probability allowance. On the active branch, at most h block substitutions, one first-symbol marker substitution, and one terminal substitution occur at disjoint positions. Thus every output lies within h+2<=k Hamming edits.

Normalization can also change the penultimate U coordinate, so the terminal PAIR can change even when A=0. This does not invalidate the endpoint bound: every modification occurs only after the independent Bernoulli(rho) trigger, giving endpoint-change probability at most rho on every fixed input. On words containing symbols outside the four generated symbols, the channel is identity.

The channel reads only the word and public M,rho. It uses neither p_i nor alpha, not even through an oracle. It is future-blind, and the future is generated from the original terminal symbol rather than the displayed replacement. The reserved marker identifies the active branch exactly under both witness sources. The case rho=0 is explicitly handled as trivial before conditioning on this event.

## 4. Exact normalization, symmetry, and event probability

Conditional on S=s, the original IID U block is uniform over weight-s strings. Uniformly removing s-M/2 ones, or uniformly adding M/2-s ones, yields a uniform weight-M/2 output for EVERY s. Coordinate-permutation symmetry is sufficient: all balanced outputs are equally likely and exhaust total mass one. The normalization seed is independent of the tie-breaking seed and V process. Hence the normalized block is independent of S and A on the active branch and has the same law under both sources. U_N remains independent with its original Bernoulli(p_i) law.

Reflecting all clean U bits sends the plus source to the minus source, preserves the good event, and exchanges the sign bit A. The fair tie rule is essential for the exact relation t_-=1-t_+. The good probability g is exactly common.

Under the plus source, ES=M/2+sqrt(M) and Var(S)<=M/4. Chebyshev yields P(S<=M/2)<=1/4. Outside the good window, |S-ES|>h-sqrt(M)>=3sqrt(M), giving P(G^c)<=1/36. Therefore

    g>=35/36,
    t_+>=3/4-1/36=26/36,
    d=t_+-t_- >=4/9.

The lower bound on t_+ correctly uses division by g<=1, not a reversed inequality. The fair-tie contribution is nonnegative. These calculations are valid for every even M>=64, not only square horizons.

## 5. The actual posterior targets

On the marker branch, let b=V_(N-1), B=V_N, W=B xor A, and r=1/2+alpha(2b-1). Conditional on the retained prefix, B has probability r of being one, and A is independent Bernoulli(t_i). The Markov property makes the last retained V coordinate sufficient for this conditional B law; erasing V_1 does not change it.

Thus l_i(1)=r+(1-2r)t_i, l_i(0)=1-l_i(1), and

    P_i(B=1|Z,W=1)=r(1-t_i)/l_i(1),
    P_i(B=1|Z,W=0)=rt_i/l_i(0).

The marker event is already determined by Z; writing it additionally in the conditioning is harmless. Every denominator is at least 1/2-alpha>=1/4.

The NEXT V probability is 1/2-alpha+2alpha P_i(B=1|Z). Direct subtraction gives, for both displayed values w,

    |a_+(w)-a_-(w)|
      =2alpha r(1-r)d/[l_+(w)l_-(w)].

These are conditional laws for the respective fixed true sources under the same known channel, not targets averaged over a source prior. Their V-marginal separation lower-bounds the full K-alphabet TV distance. Future U differences need not be used.

## 6. Full observation laws are not identical: overlap is the correct proof

The common marker event has mass rho g under both sources. Conditional on it, the balanced U block and retained V prefix have exactly common laws. The final retained U_N and displayed terminal W do NOT have identical laws under the two sources. Thus this construction must not be justified by the earlier heat-bath same-observation-law argument.

The final draft instead correctly uses

    Risk_+(q)+Risk_-(q)
      >= integral min(dP_+^Z,dP_-^Z) TV(p_+(Z),p_-(Z)).

On the marker event, the common balanced-block/V-prefix factors can be factored exactly. The remaining product overlap can be bounded using min(ab,cd)>=min(a,c)min(b,d). The retained U_N contributes total common mass 1-2/sqrt(M)>=3/4. For each retained b, the W contribution is

    sum_w min(l_+(w),l_-(w)) |a_+(w)-a_-(w)|
      =2alpha r(1-r)d sum_w 1/max(l_+(w),l_-(w))
      >=4alpha r(1-r)d/(1/2+alpha)
      =2alpha(1-2alpha)d.

This bounds the complete observed experiment, including the marker and all retained symbols. Discarding the non-marker contribution only discards nonnegative risk. The proof is not an unsupported reduction to a count-only observation.

## 7. Constant and final assessment

After dividing the risk sum by two, the lower is

    rho g(1-2/sqrt(M))alpha(1-2alpha)d.

Using g>=35/36, 1-2/sqrt(M)>=3/4, alpha>=(1-beta)/4, 1-2alpha>=1/2, and d>=4/9 gives exactly

    (35/864)rho(1-beta).

The beta=1 boundary gives the claimed zero lower without a singular expression. Independent estimator randomization is handled by integrating the pointwise overlap inequality over its common independent seed.

The exact file bound above therefore receives analytical PASS. It establishes one known-channel counterexample for the stated alphabet, stationary source class, horizon, and budget. It supplies no external novelty certification, formal verification, finite-implementation resource theorem, smaller-budget lower, full-support-on-all-symbols extension, or guarantee about extra independent observations from the same unknown source.
