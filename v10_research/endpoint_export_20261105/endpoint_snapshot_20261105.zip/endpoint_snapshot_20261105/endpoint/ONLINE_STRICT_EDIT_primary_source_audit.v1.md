# Primary-source delta audit: online strict-edit posterior lower bounds

Date: 2026-11-05 UTC. Analytical source comparison, not novelty certification or independent proof acceptance. No scientific executable checks, experiments, or public writes were performed. Existing candidate and review files remain unchanged.

## 1. Findings and update to the preceding audit

The new online witnesses close part of the restricted-channel gap recorded in `FINITE_STATE_TRANSFORMER_BRIDGE_primary_source_audit.v1.md`:

- At one edit, a four-base-state online channel now supplies the endpoint lower matching the inherited statistical upper.
- A one-base-state protected channel supplies the k/M term for general budgets.
- A growing-budget construction supplies min{rho,(k/M)^(1/3)} using O(N²) base states, in addition to the separately charged edit counter. It does not reach the unrestricted offline min{rho,(k²/M)^(1/3)} endpoint scale.

Consequently, the older blanket statement that restricted online corruption lower bounds remain unproved is no longer current. The unresolved question is the growing-k endpoint rate and its dependence on the allowed memory/state budget. The gap between the present lower and inherited upper is not itself a proved separation between online and offline adversaries.

Primary causal-channel coding work already allows current/past-symbol access, strict corruption budgets, hidden randomized attack state, and staged attacks. HMM research already distinguishes identifiability from uniform minimax learnability near degeneracy. The comparison-sensitive claim here is more specific: one common disclosed normalized rational online channel, a strict raw-token edit cap and per-clean-word endpoint budget, and a lower bound for the source-specific clean-next-bit posterior.

## 2. Exact result and channel class

Let N=M+2. The clean source is a stationary binary homogeneous order-two chain with all-state pair-chain minorization P²(s,v)>=beta Pi(v), for fixed 0<beta<1. Its parameter theta is unknown. The predictor observes Z and the complete channel C, but not the raw history, realized hidden channel state, edit counter, mask, or coin.

The statistical target is

    p_(theta,C)(z)=P_(theta,C)(X_(N+1)=1 | Z=z),

and the loss is expected absolute error, equivalently Bernoulli TV. Conditioning averages latent histories under each fixed source. It does not average the source alternatives under a parameter prior. This is a probability-estimation loss, not message decoding, hidden-bit classification, or loss against the unobserved actual-terminal transition row.

For each lower witness, C is the same kernel under both alternatives, is disclosed before prediction, and does not use the unknown source sign. It may be designed from public M,k,rho and shared family-design constants. Source independence does not prohibit input-dependent edits. Auxiliary channel randomness is independent of the entire source process, and no action uses future clean innovations.

The candidate channels act immediately using the current raw bit, prior raw-memory state, public time, and counter. Thus they are current-symbol causal, or zero-lookahead, not one-step-delayed/strictly causal in the usual information-theoretic terminology. Replacing 1 by 0 is a binary substitution; it is not an erasure channel with a visible erasure symbol.

Every input word and every channel realization uses at most k substitutions. Conditional on each clean word, endpoint-change probability is at most rho. Neither constraint is merely a source-averaged or expected-budget condition. All transition rows are normalized; proof conditioning is not used to manufacture a channel by rejection or terminal acceptance.

The current lower statements hold for sufficiently large M depending on beta, every rational rho in [0,1], and integer 1<=k<=M (with k=1 for the first construction):

    one edit:       c_beta min{rho,M^(-1/3)},
    protected:      27 k/(1024 M),
    growing budget: c_beta min{rho,(k/M)^(1/3)}.

The protected witness works also at beta=1; the rare endpoint constructions require beta<1. Combining identity, protected, and growing-budget witnesses gives

    R_online,beta >= c_beta min{1, M^(-1/2)+k/M
                                      +min{rho,(k/M)^(1/3)}}.

This is a maximum over distinct admissible channels and source pairs, which dominates a constant times their sum. It does not compose their edits or add their budgets. The inherited upper has the larger endpoint term min{rho,(k²/M)^(1/3)}. At k=1 the k/M term is dominated by the clean baseline, yielding the matched statistical order M^(-1/2)+min{rho,M^(-1/3)} for the stated time-indexed online class. This is not resource-optimal Transformer complexity.

At k=0 only the identity/clean result is invoked. The computational upper's exact dyadic certificate interface should also remain explicit: a general positive rational rho can use a paid upward dyadic certificate between rho and min{2rho,1} to preserve the stated order, rather than silently treating an arbitrary real budget as a free input.

## 3. What the online normalization actually does

### 3.1 One edit

Candidate sites are separated by three positions; eligibility uses the preceding raw pair 11. The channel immediately replaces the first eligible current one by zero. At N-1, if the edit remains unused and the preceding raw pair is 00, it flips the current bit with probability rho. Position N is untouched. Four raw-pair base states plus a binary edit counter suffice.

The retained scaffold H is recoverable from Z because eligibility depends on untouched noncandidate coordinates. Conditional on H, missing candidate bits are independent, but generally not identically distributed: their probabilities depend on retained following pairs. Those following bits are used in mathematical conditioning, not in the earlier online edit decision. The 01-following type need not have a success probability of order t and cannot be discarded.

The all-zero eligible output occurs exactly when the total hidden eligible-one count S is at most one. S=0 and S=1 collide on that branch but leave different edit availability. The source-dependent posterior probability of unused budget controls the final hidden flip mode. This is a direct causal coarsening construction, not an imported offline count-layer transport.

### 3.2 Protected k/M witness

Under iid Bernoulli alternatives p_-=k/(8M) and p_+=k/(4M), replace the first k interior ones by zero and protect the last two coordinates. The common output 0^N has probability at least 27/64 under either source, while the source-specific next-bit posterior remains exactly p. The target gap is k/(8M).

This is an elementary contamination-style loss of information, explicitly realized inside the protected disclosed online subclass. It needs neither global observation-law closeness nor a rare-posterior argument. Its value is the exact admissible realization, not a new general phenomenon that suppressing informative rare observations impedes estimation.

### 3.3 Growing budget

For h=k-1, the channel replaces the first h eligible ones by zero. It also retains counts of completed raw patterns 11?00 and 11100. Each pattern is counted only after its two following bits arrive; all required counts are complete by N-3. At N-1 a common threshold comparison S_00>floor(n_00 t), together with the past-00 gate, controls a rho-coin endpoint flip. It never reads X_N before acting.

The all-zero eligible output is exactly C={S_all<=h}. The 00 subset satisfies an exact conditional binomial law given H, while S_all is generally Poisson-binomial. After additionally conditioning on C, the subset is not asserted to remain binomial. The cap-conditioned sign gap is obtained by a quantitative conditioning-error bound instead.

On suitable scaffolds the total conditional hidden mean is at most h/64, giving an exponentially small cap-failure probability. A common fixed threshold has a uniformly positive sign-probability difference under q_+-q_-=2d/sqrt(h). The design chooses t comparable to (h/M)^(1/3), so the hidden informative mean and the clean-path KL are controlled at the scales Mt³ and Mt³/h respectively.

This explains the scale in this construction. The preceding offline normalization uses a different count-transport mechanism and alternatives separated at order 1/h, leading to Mt³/h². The present proof does not establish that every online construction must lose that factor; the smaller exponent is an attained lower, not an online impossibility theorem for stronger attacks.

### 3.4 Retaining the probability of the revealing output

On the relevant terminal scaffold, the raw penultimate bit B is Ber(t), and the future success probability is t+(r-t)B. If the hidden flip mode has conditional probability v_q, then

    T_q=rho v_q,
    ell_q(1)=t+(1-2t)T_q,
    p_q(H,1)=t+(r-t)t(1-T_q)/ell_q(1).

The complete displayed-word mass includes the scaffold mass, cap-branch mass, and ell_q(1). The two-point lower uses

    sum_z min{P_+^Z(z),P_-^Z(z)} |p_+(z)-p_-(z)|.

Only one posterior normalizer cancels against this overlap weight. The resulting scale is rho*t/(rho+t), comparable to min{rho,t}. A large conditional posterior discrepancy by itself would be insufficient. Exact equality of the full output laws is not claimed or needed.

## 4. State, precision, and asymptotic quantifiers

The one-edit witness has four base states, excluding the binary edit counter and public time-indexed tables. The protected witness has one base state, excluding its k+1 counter values. These are not four-state or one-state stationary homogeneous-channel theorems. Public horizon-dependent tables distinguish interior candidate times from N-1 and N. Implementing that clock inside a homogeneous machine changes the state ledger.

The growing construction has at most 16(M+1)² base states for four raw bits and two counters, plus the separate edit counter. O(N²) is state cardinality, not the number of bits needed for the two mutable count registers: those registers use O(log N) bits. Conversely, logarithmic mutable memory does not make the complete transition tables free. The candidate conservatively charges

    ell=O(N S_ch²(k+1)[b_rho+u+log(N+1)+1]),

where b_rho is actual rational numerator/denominator precision and t=2^-u is chosen with O_beta(log N) precision. Dense zeros, time expansion, thresholds, state encoding, generation, and storage are charged. The ledger is an upper accounting bound, not a lower or an optimal encoding claim.

The source alternatives and the channel family may vary with M,k. Vanishing rare transition entries are compatible with the fixed minorization certificate; a fixed positive transition/stationary-mass floor is a stronger restriction. For h comparable to M, t need not tend to zero, so the good-terminal-scaffold argument uses a uniform small failure bound, not convergence to probability one. Source parameters involving sqrt(h) need not be rational because only the channel is required to have rational tables; those alternative-specific values do not appear in its table.

The class for the growing result must admit these paid polynomial-state families. It is not the same theorem as a fixed four-base-state allowance for every k. It also does not prove inconsistency at one fixed source and one fixed infinite-stream channel.

## 5. Primary causal-channel and robustness precedents

### A. Direct causal bit-flip channels

Dey, Jaggi, Langberg, and Sarwate's *Upper Bounds on the Capacity of Binary Channels with Causal Adversaries* defines actions using raw inputs through the current symbol and earlier actions, with a strict Hamming budget. Its babble-and-push converse includes hidden randomized phase state and stops spending at the budget. Theorem 1 concerns achievable communication rate; the attack is chosen after the code and decoder. It does not formulate estimation of a source-specific future posterior under a pre-disclosed common kernel. Thus causality, hard caps, and hidden adaptive state have direct precedent, while the present posterior target and explicit small-state realization are additional requirements. [Primary manuscript, sections II–III and theorem 1](https://arxiv.org/pdf/1204.2587).

Zhang, Jaggi, Langberg, and Sarwate's *The Capacity of Causal Adversarial Channels* generalizes this setting to finite input/output/state alphabets, state-deterministic channels, cost constraints, and current/past-input causal jamming. Its converse uses prefix corruption and suffix symmetrization. Here an AVC “state” is a per-symbol control input, not necessarily the jammer's bounded internal-memory state. A finite state alphabet therefore does not imply four memory states or the present O(N²) ledger. Its coding theorems do not automatically imply the candidate posterior lower. [Primary manuscript, definitions 1–4 and theorems 1–2](https://arxiv.org/html/2205.06708v1).

### B. Current-symbol access versus one-step delay

Dey et al., *The benefit of a 1-bit jump-start, and the necessity of stochastic encoding, in jamming channels*, separately studies an adversary that cannot see the current bit. Its theorems 1–2 show that delay and encoder randomization materially change communication guarantees. The present substitution rule inspects the current bit and thus does not satisfy that delayed model. Nor should its 1-to-0 replacements be called visible-symbol erasures in the paper's channel sense. [Primary manuscript](https://arxiv.org/pdf/1602.02384).

### C. “Online” can constrain the estimator rather than the adversary

Kane, Diakonikolas, Xiao, and Liu's *Online Robust Mean Estimation* makes the learner commit to mean-coordinate estimates as sensor-vector coordinates arrive. Definitions 1–2 still allow strong contamination to inspect the entire clean sample set and replace an epsilon fraction of full vectors. Thus it has a different adversarial information pattern and budget unit from editing positions of one dependent path. Its mean-estimation guarantees are not known-channel terminal-posterior rates. [Primary manuscript, definitions 1–2 and theorems 1–2](https://cseweb.ucsd.edu/~dakane/OnlineRobust.pdf).

Chen, Koehler, Moitra, and Yau's *Online and Distribution-Free Robustness: Regression and Contextual Bandits with Huber Contamination* permits adaptive interaction and corrupted responses, but an independent per-round corruption opportunity differs from a strict all-realization cap. Its guarantees concern clean regression prediction/regret, not a posterior formed under one disclosed adversarial channel. A per-round Huber parameter is not the current per-clean-word endpoint budget. [Primary FOCS paper, section I.B and theorems I.5–I.6](https://ieee-focs.org/FOCS-2021-Papers/pdfs/FOCS2021-5stbVHiOp5jRHWlSl41FkR/205500a684/205500a684.pdf).

Blanc and Valiant's adaptive/oblivious equivalence, already discussed in the prior audits, uses iid sampling and polynomial sample enlargement by subsampling. Its current version does not yield fixed-horizon exponent equality, preserve temporal endpoints, or identify an offline block adversary with a current-symbol causal transducer. It cannot import the offline endpoint exponent here. [Primary version 3, theorem 3](https://arxiv.org/html/2410.13548v3).

## 6. HMM identification, finite-state augmentation, and ambiguity

Abraham, Gassiat, and Naulet's *Fundamental Limits for Learning Hidden Markov Model Parameters* is the strongest quantitative HMM comparison. Remark 1 permits sample-size-dependent regularity parameters while holding a spectral-gap bound fixed; its minimax theorems and KL analysis quantify difficulty near degeneracy. This already establishes the general distinction between mixing/identifiability and uniform learnability. Its ordinary-emission parameter-estimation target differs from the present strict-edit clean-future posterior. [Primary paper, remark 1, theorem 1, and proposition 2](https://arxiv.org/pdf/2106.12936v3).

Finite-state source/channel augmentation is standard, not an obstacle to calling the result a hidden finite-state model. Pfister, Soriaga, and Siegel explicitly combine a finite-state source with a channel P(Y_i,Q_(i+1)|X_i,Q_i) and give forward posterior recursions. The present witnesses are time-inhomogeneous versions at each fixed horizon; appending a clock does not make the augmented process stationary or ergodic. Knowing both source and channel permits filtering, while the lower leaves the source unknown. [Primary paper, section II.B](https://pfister.ee.duke.edu/papers/globecom2001.pdf).

Alexandrovich, Holzmann, and Leister identify homogeneous stationary HMMs under full-rank ergodic transitions and pairwise distinct emissions; linear independence is not required. Therefore failure of emission linear independence alone is not a blanket exclusion of positive HMM results. The clean-source minorization does not establish those hypotheses for irreversible edit/count memory and public time-dependent tables. [Primary paper, assumptions A1–A3, theorem 1, and example 1](https://arxiv.org/pdf/1404.4210v2).

Csiszar and Narayan's AVC symmetrizability characterizes an exact output-ambiguity condition relevant to deterministic coding; state constraints introduce a symmetrizing cost. This is a useful precedent for ambiguity subject to a budget, not a reduction to the current result. The candidate needs only overlap, uses one common causal map under two source laws, and estimates a source-dependent conditional probability. It does not prove the AVC symmetrizing identity. [Primary paper, definition 2, theorem 1, and state-constraint discussion](https://user.eng.umd.edu/~prakash/papers/Csiszar_Narayan-IT_1988ii.pdf).

A focused companion, `ONLINE_HMM_identifiability_comparison.research.v1.md`, records these model assumptions and exact inspected locations in more detail. The earlier filtering, denoising, coarsening, and expected-posterior-stability comparisons remain applicable; the online property alone does not invalidate them or satisfy their other hypotheses.

## 7. The binomial sign lemma uses established probability tools

For fixed c, the identity

    d/dp P(Bin(n,p)>c)=n P(Bin(n-1,p)=c)

is elementary finite-sum differentiation. It is also the symmetric threshold-event instance of Russo's pivotal derivative formula. The local lemma correctly holds c=floor(nt) fixed while q varies; it does not differentiate a moving threshold or assert that the scaffold law is parameter-independent. [Russo, *An Approximate Zero-One Law*, lemma 2](https://math.bme.hu/~balint/oktatas/perkolacio/percolation_papers/russo_3.pdf).

The local-mass bound is obtained by elementary KL comparison and Stirling inequalities. Robbins gives the classical explicit factorial remainder bounds used for such estimates. These tools do not require a normal approximation and are not themselves a new anti-concentration principle. [Robbins, *A Remark on Stirling's Formula*, equations (1)–(2)](https://dornsife.usc.edu/sergey-lototsky/wp-content/uploads/sites/211/2024/02/Stirling-Robbins.pdf).

The heterogeneous cap tail comes from the Bernoulli product moment-generating function. It applies conditionally on a fixed scaffold after independence and the total-mean bound are proved. Only the 00 subset is binomial. Conditioning on the cap may destroy independence and the binomial law; the lemma does not reuse those claims after conditioning.

For 0<=U<=1, the mixture on C and C-complement gives exactly

    |E(U|C)-EU| <= P(C-complement).

There is no missing factor 1/P(C). Applying it under both alternatives subtracts at most twice the cap-failure probability from the sign gap. This elementary identity avoids an unjustified monotonicity claim for the cap-conditioned distribution. The supporting lemma's useful role is the uniform constants and explicit onset within this construction, not a claim of new derivative, Stirling, or concentration methodology.

## 8. Bounded positioning and remaining obligations

A defensible description is:

> The constructions realize source-specific clean-future posterior lower bounds using one common disclosed normalized rational current-symbol-causal channel under a strict edit budget. A constant-base-state one-edit witness attains the M^(-1/3) endpoint obstruction; a protected online witness attains k/M; and a paid horizon-dependent polynomial-state construction attains (k/M)^(1/3) endpoint dependence. The matching growing-budget online rate and a fixed-state version remain open.

This is a bounded comparison, not a priority claim. It does not establish a first causal adversarial channel, first hidden-state posterior ambiguity, first near-degenerate HMM minimax lower, or first binomial threshold-separation argument.

Any attempted transfer from communication, filtering, robust mean estimation, or offline normalization must preserve all of the following: the common disclosed kernel; current-symbol causality; per-word/per-realization budgets; channel-state resources; horizon quantifiers; the fixed-source conditional target; and probability-weighted loss. Conditional Jensen supplies an upper transfer from latent-row loss, not a lower transfer. A coding converse, latent-target lower, or large posterior gap on an unweighted rare event is not a substitute.

## 9. Evidence binding and limits

Read in full: the four requested candidate/lemma files and the two online independent-review files. The earlier source and computational audits were consulted for their scopes and historical open questions. Their independent analytical dispositions are recorded evidence, not replaced by this literature audit. No exhaustive priority search or theorem-level nonexistence claim is made.

Input SHA-256 snapshots:

- `KNOWN_CHANNEL_online_one_edit_lower.candidate.v1.md`: `411908bdfb5385066e19daaa84edcc302fc0a80bf76eb23d258a3f7187fa6e60`
- `KNOWN_CHANNEL_online_protected_budget_lower.candidate.v1.md`: `dae5c75cd818401f8cb323c10f4e34d0754d7d5a92114fa3f7f4723d5d186fbe`
- `KNOWN_CHANNEL_online_growing_budget_endpoint_lower.candidate.v1.md`: `9ebe6191bcca016d99e57fbfeda0ef0afed46333b02f796cbd7dbb4f3dcbc601`
- `KNOWN_CHANNEL_online_binomial_sign_lemma.candidate.v1.md`: `1b8c1194ff99d443ead50efebe4598ca5900a486f7f162afc0e673c9bd62dc2d`
- `KNOWN_CHANNEL_online_lower.independent_review.v1.md`: `915b06a98cc514398c3ae4364f6d75eb24e85b3bf7f1b55dc368d095bf44a407`
- `KNOWN_CHANNEL_online_growing_budget.independent_review.v1.md`: `e4f42628789d3365554b9cf4a035a698071410b1b62faf29629ae7a37e1f0c6b`

Companion source note SHA-256:

- `ONLINE_HMM_identifiability_comparison.research.v1.md`: `af583e82bba65729a5aa85d049982a43ae44a5b3c19591db095a45c8eb13ed45`

Exact primary URLs and relevant theorem/section locations accompany the comparisons. The Robbins scan and Russo paper were inspected through primary-paper text extraction; no unsupported screenshot interpretation was used. No scientific executable validation, channel simulation, public upload, or modification of the supplied proofs was performed.
