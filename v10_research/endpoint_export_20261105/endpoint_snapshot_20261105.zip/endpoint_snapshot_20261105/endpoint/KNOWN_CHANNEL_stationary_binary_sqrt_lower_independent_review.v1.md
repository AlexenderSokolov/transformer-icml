# Independent analytical review: stationary binary square-root-budget lower

Date: 2026-11-05 UTC. Present-time clock check: 04:14:05 UTC; final file identity and status were checked immediately afterward.

## Finding and exact file binding

The lower-bound construction is valid with its final asymptotic quantifiers. I found no substantive gap in the stationary law, all-state minorization, conditional factorization, strict channel budget, observation overlap, posterior target, or extension to every fixed beta in (0,1).

Reviewed final candidate:

    KNOWN_CHANNEL_stationary_binary_sqrt_lower.v1.md
    SHA-256: c75ef32562b08f1606189e060d3ab014c589804e210bed076aedb0f759eaa946

The complete mathematical draft was read. The author then renamed it to the final filename and changed only the opening review-status sentence; the final identity and that sentence were rechecked. The author confirmed that the file is frozen. This is a present-time binding, not a historical digest assertion.

For fixed beta in (0,1), fixed rho>0, and any fixed a>0, the construction gives a positive posterior-prediction minimax floor using floor(a sqrt(M))+1 edits once M is sufficiently large. The onset horizon may depend on a, beta and rho. The constants are defined analytically through strictly positive compact minima; no numerical onset horizon is claimed.

Combined with the already reviewed stationary binary upper, this proves the exact uniform-consistency budget condition k=o(sqrt(M)) for fixed beta in (0,1) and fixed rho>0 when the channel is known. It does not prove a sharp risk rate inside that regime, pointwise inconsistency of one fixed source, or a lower for every known channel.

This is mathematical review, not formal verification, external peer review, or novelty certification. Tools were used only for document inspection, file hashing, and writing this review. No scientific executable checks, numerical experiments, or public writes occurred.

## 1. Stationary source and all-state certificate

For theta_q(a,b)(1)=q+(1-2q)b+e(2a-1), complementing the pair and next bit preserves transition probabilities. Positivity makes the stationary pair law unique, so its symbol marginal is one half.

The supplied stationary pair formula checks directly. If r=Pi(0,0)=Pi(1,1) and s=Pi(0,1)=Pi(1,0), stationarity gives r(q-e)=s(1-q-e) and r+s=1/2. Solving gives exactly the displayed expressions.

The coefficient of the first context bit is 2e>0, so the sources are genuinely second order. For the base parameters and M>=64, every transition coordinate is in [1/3,2/3]. The stationary pair masses are at most (2/3)(1/2)=1/3. Every two-step pair transition is a product of two legal symbol transitions and is at least 1/9. Therefore the all-state D2(1/4) certificate holds with slack; the stated stronger D2(1/3) implication is also correct.

The certificate covers every starting pair, not only typical or stationary-supported contexts. All four pair states in fact have positive mass.

## 2. Conditional IID eligible bits

Candidates are spaced by three positions. An order-two historical likelihood factor contains only three consecutive symbols and therefore cannot contain two candidates. Initial pair factors exclude candidates, and the final source transition to X_N depends only on retained coordinates.

Eligibility uses the four neighbors at distances one and two. None of those neighbors is a candidate. Consequently the eligible mask is determined entirely by retained coordinates and places no condition on an eligible bit's value. The retained object H is a common deterministic function of the clean prefix under both source hypotheses.

At an eligible site, the three factors involving a one are

    (q-e)(q+e)(1-q-e),

and those involving a zero are

    (1-q+e)^3.

Their ratio is therefore precisely the candidate's A/B. Distinct eligible bits occur in disjoint sets of likelihood factors. Conditioning on H gives IID Bernoulli(p(q)) bits, not merely uncorrelated observations.

The terminal clean bit is conditionally independent of all these bits given H, with the stated r_q(H). In particular, keeping the final three positions outside the candidate set prevents an overlooked endpoint likelihood interaction.

The derivative of log(A/B) is correctly computed. Its last two terms have positive sum when e<(1-q)/2, since their numerator is 2(1-q)-4e. Together with q>e, this proves p'(q0)>0 in the required neighborhood.

## 3. Strict channel and visible event

For every binary input word, the count-normalization operation is well-defined. It changes exactly |S-m_n| eligible symbols on the active branch, hence at most h of them. All eligible sites are outside the terminal pair. The final XOR changes at most one additional symbol, so the strict pathwise budget is h+1.

The endpoint changes only when A_sign R=1. Conditional on every input, this has probability at most rho. This is a per-word statement, not a claim about endpoint error after conditioning on an output.

The channel leaves all coordinates that determine H and eligibility unchanged. Its visible event E is therefore recoverable from the output and occurs exactly when the normalization branch runs, with n=0 explicitly excluded. Identity outside the window cannot accidentally produce its center. No reserved marker, seed, hidden branch, or edit mask is supplied to the estimator.

The constants q0,e and p0 are fixed public design constants shared by both hypotheses. The channel does not use the unknown q_+ versus q_-, future symbols, or the estimator seed. Horizon dependence is explicit and permitted.

## 4. Complete observation law and actual prediction target

Conditional on S=s, the eligible configuration is uniform among words of that count. Uniformly choosing deleted ones or added ones makes the normalized output uniform among words with count m_n, for every s in the active window. A direct subset-counting calculation confirms the common probability 1/binomial(n,m_n).

Thus the normalized word reveals no additional information about S or its sign once H and the active branch are fixed. The independence of the normalization and sign/trigger coins gives the exact binary XOR experiment in section 4.

Both posterior formulas F_0 and F_1 are correct. The next source row is evaluated at the ORIGINAL terminal pair, giving

    q+e(2b-1)+(1-2q)F_w(r_q,t_q),

not the row at the edited display. Future blindness is required here and is explicitly retained.

Every output on E is determined by H, the normalized eligible word, and W. The factorization f_q(H) g_q(n) / binomial(n,m_n) times ell_q(w) therefore accounts for the complete observed word, rather than a projection that might omit distinguishing information. No prior mixture over source hypotheses enters the target.

## 5. Positive-density eligibility and uniform binomial limit

Each eligibility indicator depends on a bounded window of five symbols. Uniform geometric mixing of the finite pair chains bounds the covariance series, including the finitely many overlapping windows, and yields Var(n)=O(M) uniformly over the local alternatives.

The candidate-site density tends to 1/3. Continuity of the stationary finite-window law gives the claimed positive limit nu0. The eligibility event includes the all-five-zero event, whose probability is strictly positive. Consequently the set T={nu0/2<=n/M<=1/3} has probability tending to one under both sources.

The uniform binomial approximation is justified: n>=c0 M, p(q_+/-) remains bounded away from zero and one, and its Taylor remainder is uniform. The rounding errors from floor(n p0) and floor(a sqrt(M)) vanish after division by sqrt(M). A Berry-Esseen bound provides a uniform CDF error of order M^(-1/2); tie mass also vanishes uniformly. This is a standard analytical limit argument, not an executable check.

The limiting positive-mean normal density exceeds its reflection at every positive y. Hence both g(v) and D(v) are continuous and strictly positive on the compact interval [c0,1/3]. Their minima g_* and D_* are finite and positive. This proves the eventual bounds in (B8), including uniformity over all retained scaffolds in T.

The result is asymptotic. It does not assert the displayed lower for every M>=64 or provide a numerical value of the full onset horizon.

## 6. Scaffold overlap and finite lower constant

For the base family, each transition-coordinate difference is 2 gamma/sqrt(M). The Bernoulli KL bound with denominator at least 2/9 contributes at most 18 gamma^2/M per transition. The stationary initial-pair contribution is O(gamma^2/M), as also follows from the explicit positive pair law.

Thus prefix KL tends to at most 18 gamma^2. With gamma=1/100, Pinsker gives a limiting TV upper of 0.03, strictly below 1/8. Data processing applies to H even though its mask depends on the prefix, because that map is common to both sources. Combining this with P(T)->1 gives the scaffold overlap of at least 3/4 in (B9).

For a common r and either displayed terminal value, exact subtraction yields the stated posterior difference with denominator ell_+ ell_-. The reference coefficient 1-2q0=1/4 and r(1-r)>=2/9 give target separation at least |t_+-t_-|/18.

Parameter replacement is uniformly controlled, since all denominators stay at least 1/3. The conservative bound of 4 gamma/sqrt(M) per target is valid, so the total loss in separation is at most 8 gamma/sqrt(M). For fixed rho>0 this is eventually smaller than rho D_*/72, proving (B11). This explains why the final statement properly allows the onset horizon to depend on rho and makes no uniform rho->0 assertion.

The observation-overlap factors are exactly

    (2/3)(g_*/2)(3/4)=g_*/4.

Multiplying by the gap rho D_*/72 and dividing the risk-sum inequality by two gives rho g_*D_*/576. The arithmetic in (B12) is correct.

## 7. Every fixed beta in (0,1)

The extension alpha=e=(1-beta)/32 and q0=1/2-alpha is valid. Writing s=alpha+e and x=2s=(1-beta)/8, the center's all-state certificate ratio is bounded below by

    (1-x)^2/(1+x)=1-3x+4x^2/(1+x)>beta.

The inequality has strict slack for every fixed beta<1. Continuity preserves the certificate for the local alternatives at sufficiently large horizons. Positivity, q0>e, and e<(1-q0)/2 also hold. The endpoint signal 1-2q0=2alpha and genuine second-order coefficient e remain strictly positive.

The previous proof therefore extends with beta-dependent positive constants. The onset horizon and constants are not uniform as beta approaches one. Nothing here combines with a beta=0 upper to give a beta=0 threshold theorem.

## 8. Exact scope of the threshold conclusion

The reviewed upper supplies consistency when k=o(sqrt(M)) for fixed positive beta. If an integer budget sequence fails this condition, it has a subsequence with k_M/sqrt(M)>=epsilon>0. Choosing a smaller fixed a, for example epsilon/2, makes floor(a sqrt(M))+1<=k_M eventually on that subsequence. The present lower then keeps its minimax risk bounded away from zero when beta in (0,1) and rho>0 are fixed.

This proves the claimed iff condition for uniform consistency in that experiment. It does not identify the risk rate for smaller budgets. It also does not imply exact observational nonidentifiability: the proof uses positive overlap of full observation laws. Sources vary with M, so pointwise fixed-source inconsistency is not established.

The beta=1 boundary is correctly excluded. There P^2(s,.)=Pi; summing over the second target coordinate forces every source row to equal pi. Stationary initialization then gives an IID source, its future target is pi, and the corrupted empirical frequency has risk at most 1/(2sqrt(M))+k/M.

The theorem also fixes rho>0. It does not settle the same budget threshold for rho=0 or rho varying with the horizon. Identity and other benign known channels are not claimed to have the lower floor.

## Sources and restrictions

The complete lower candidate was inspected alongside the already reviewed stationary binary upper and the source/channel/target conventions used in the endpoint-risk notes. The final review is limited to the statistical theorem and its consistency consequence. No efficient channel implementation, efficient predictor, Transformer realization, external novelty, or formal verification is certified.
