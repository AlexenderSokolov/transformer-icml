# Independent analytical review: rare-event binary budget lower

Date: 2026-11-05 UTC. Present-time clock check: 05:01:34 UTC; candidate and dependency digests were checked immediately afterward.

## Finding and exact file bindings

The general-budget lower is valid. I found no substantive gap in (RB1)-(RB9), including the uniform small-count bin argument, source-dependent stationary initialization, source-independent channel, exact posterior comparison, uniformity in k and rho, and addition of the clean baseline by selecting a witness.

Reviewed candidate:

    KNOWN_CHANNEL_stationary_binary_rare_budget_lower.v1.md
    SHA-256: 9bfc30dcf44224b238ea315a7d306e4ff4e6ef7f6108e9fd97ed68dd3fb19689

Reviewed one-edit dependency:

    KNOWN_CHANNEL_stationary_binary_rare_one_edit_lower.v1.md
    SHA-256: 49915c863da95d1b139c467c686aee5cf65a5bd408ad9ec762ed8c7408ad88c9

Its separate independent review:

    KNOWN_CHANNEL_stationary_binary_rare_one_edit_lower_independent_review.v1.md
    SHA-256: bd1ef0bf31d69a6677d37eba8c616d846c27697abdd1b722ee629e38ea4ec69b

Both complete proofs were read, and the author confirmed that both candidate files are frozen. These are present-time bindings, not historical digest assertions.

For fixed 0<beta<1, the combined result is

    c_beta [M^(-1/2)+rho min{(k^2/M)^(1/3),1}],

for all sufficiently large M uniformly over 0<=k<=M and rho in [0,1]. The constants and onset horizon may depend on beta, but not on k or rho.

This strengthens the unrestricted binary lower and includes the separately proved one-edit M^(-1/3) term. It does not establish a matching upper or close the unrestricted sharp-rate question. The fixed-positive-floor linear-rate theorem is not contradicted.

This was mathematical review only. Tools were used for document inspection, file hashing, and writing this review. No scientific executable checks, numerical experiments, public writes, novelty certification, or formal verification occurred.

## 1. Stationary source family at the new scales

The exact stationary law and all-state certificate from the one-edit note remain valid for every q in [1-d,1+d] and t<=tau. The new alternatives lie in that interval and satisfy those bounds for every h>=1. The initialization is always the stationary law of the particular q,t source, not a common surrogate initial law.

The transition KL calculation is correct. Only row 11 changes, by 2d t/h. Its conditional KL is O(d^2 t/h^2), its stationary occupation mass is O(t^2), and the total transition contribution is O(d^2 M t^3/h^2)=O(d^2 tau^3).

The uniform initial-law estimate also checks. Differentiating the explicit stationary probabilities gives a log derivative bounded by C_beta t in every coordinate. More specifically, the 00,01,10 derivatives are O(t^3), while the 11 derivative is O(t); the weaker common bound suffices. Thus their log likelihood ratios are O_beta(d t/h), and

    t/h=tau M^(-1/3)h^(-1/3)<=tau M^(-1/3).

The initial KL therefore tends to zero uniformly even when h is of order sqrt(M), where t need not tend to zero. This avoids an otherwise important stationary-initialization gap.

## 2. Uniform rare-scaffold control

The exact eligibility probability is still u_q t^2[1+(q-1)t]. With t<=tau sufficiently small and q in the fixed compact interval, its coefficient relative to t^2 stays close to one uniformly. Together with the candidate density near 1/3, this places E n/(M t^2) strictly inside (1/4,1/2) for all large M uniformly in h.

The rare-event variance estimate Var(n)<=C_beta M t^2 is inherited with the same uniform mixing certificate. It uses the O(t^2) earlier-event probability in the covariance bound, not a crude O(M) estimate.

Since M t^2>=tau^2 M^(1/3), concentration is uniform over all h>=1. The terminal event A has probability at least 31/32 after choosing tau small enough, uniformly because t<=tau. Combining this with the 31/32 count event needs only a union bound, not independence. Full-clean-word TV at most 1/8 then leaves the stated scaffold overlap of at least 3/4.

All choices of tau and the later horizon bounds can be made in sequence using beta alone. No moving-rho requirement enters this step.

## 3. Strict bin channel and collisions

On A intersect T, the center c=max{h,floor(n t)} is determined by retained H and public parameters. In particular it does not depend on q or on the unknown source sign. The bin is fixed while q varies in the posterior and derivative calculations.

The proof below ensures 0<=c-h<=c+h<=n uniformly for all claimed horizons. Thus uniform normalization is defined on every active input. It changes at most h interior symbols, followed by at most one penultimate-bit flip, for total at most h+1<=k. The conditional probability of changing the final pair is at most rho for every input.

H and its eligible mask remain unchanged. Inputs outside A intersect T remain outside it. With H inside that event, an untouched count outside the bin cannot equal its center. Therefore the displayed center count identifies the normalization branch exactly, without collisions from nonbranch inputs.

Given a count, uniform subset selection produces a uniform normalized word of count c, independently of the original count. This justifies the complete branch-output mass formula used later. No edit mask, random seed, or hidden sign is revealed.

## 4. Large-h part of the bin lemma

On T, mu0=n t is between a h^2 and b h^2. Direct calculation of p_q gives the displayed mean shift bound |mu-mu0|<=2d mu0/h and the upper bound mu<=2b h^2.

The required H_beta exists: a,b are fixed positive constants, and 2db is much smaller than 1/4 under the stipulated tau bounds. For h>=H_beta, mu0>=4h makes c=floor(mu0), and the rounding plus source-mean shift is at most h/4.

The bin then contains the h/2 neighborhood of the true mean. Chebyshev bounds its complement by at most 8b, which is less than 1/8 after the stated small-tau choice. The bin is contained in the valid count range: its lower end is positive, and h<=mu0/4 implies c+h<=5n t/4<=n.

Within the bin, |s-mu|<=5h/4 and min(mu,s+1)>=a h^2/2. The first logarithm in the adjacent-mass formula is controlled because 1-s/n and 1-p_q are bounded away from zero. The second is controlled using the a h^2 denominator. Both contributions are O_beta(1/h). Summing at most 2h steps gives a finite ratio bound independent of h,n,M,q.

No normal approximation is used, and none is required when the count scale is large.

## 5. Small-h part of the bin lemma

This finite-range argument is correct and essential. For 1<=h<H_beta, every possible bin count is at most the fixed integer S_beta. Meanwhile n>=tau^2 M^(1/3)/4 tends to infinity uniformly over that finite range. A single beta-dependent horizon therefore ensures n>=2S_beta for every such input in T and verifies containment of the bin.

The odds parameter L=n p_q/(1-p_q)=q mu0/(1-t) stays in the displayed compact interval [ell,U] with ell>0. The exact ratio identity is

    w(s)/w(0)=[(n)_s/n^s]L^s/s!.

For n>=2S_beta and s<=S_beta, every falling-factorial ratio lies between 1/2 and one. The resulting lower bound (ell/2)^s/s! and upper bound U^s/s! are valid also at s=0. Taking minima and maxima over finitely many s gives a strictly positive common lower and finite upper.

The lower bound w(0)>=exp(-2mu)>=exp(-4b H_beta^2) follows because p_q<=1/2. Thus at least one point in every bin has a fixed positive mass, proving the bin-probability lower as well as its internal ratio bound.

The constants may be extremely conservative, but they are finite and depend only on beta. H_beta and S_beta are selected before the onset horizon; there is no circular dependence on M or h. This handles fixed h, where a Gaussian approximation would be inappropriate.

## 6. Exact sign separation and terminal target

The combined bin lemma yields conditional mass at least 1/[R(2h+1)] at each count. The lower and upper subsets in (RB6) each have mass at least 1/(6R), count separation at least h, and sign values zero and one. The independent-copy covariance identity therefore gives h/(36R^2), including h=1.

The restricted binomial family is an exponential family in log odds. Its bin and sign statistic are fixed with respect to q. Since the log-odds increment is at least 2d/h, integration of the exact covariance derivative gives the constant sign-probability gap d/(18R^2). The bounds on v_q away from zero and one follow from the same subsets.

On A, the hidden penultimate bit has the exact shared prior Ber(t). The two future row values are the shared t and r. Thus the posterior target is exactly t+(r-t)F_w(t,T_q), with no parameter-replacement error.

For w=0, the lower bound ell_q(0)>=(1-t)(1-v_q)>=1/(12R) holds for every rho, including one. Exact posterior subtraction and denominators at most one then give (RB8). The inequalities t<=r/2 and t<=1/2 follow from tau<=d/4 and r=4d.

## 7. Full observation overlap and budget conversion

The complete normalized-output mass is f_q(H)g_q(n)/binomial(n,c) times ell_q(w). Uniformity over normalized configurations makes the binomial factor cancel when summing outputs. Keeping only w=0 still gives overlap at least (3/4)g_*/(12R).

Multiplying this overlap by the target gap and dividing the risk-sum inequality by two yields a positive constant times rho t, hence rho(h^2/M)^(1/3). This is overlap of complete output laws, not an assertion that the output laws are identical.

For k>=2, h>=min{k,sqrt(M)}/2. Taking the two-thirds power gives precisely a constant multiple of min{(k^2/M)^(1/3),1}. The one-edit dependency supplies the k=1 endpoint, and k=0 has no rare-event term.

All bin, concentration, and overlap requirements are uniform in h and rho. In particular the cap correctly remains outside rho.

## 8. Clean baseline and final quantifiers

The existing identity-channel clean lower is valid for every budget and rho. The worst-channel risk is at least both that lower and the rare-event lower. Taking their maximum, then using max{x,y}>=(x+y)/2 after choosing the smaller constant, proves (RB1).

This is legitimate witness selection. It does not require two different channels to operate simultaneously or claim that one experiment adds two unrelated risks. For each public parameter tuple one selects the admissible construction supplying the larger lower. Each chosen channel remains common to its own two source hypotheses.

The maximum of the finitely many beta-dependent onset requirements covers the clean proof, the one-edit proof, and the uniform h>=1 bin proof. Therefore one M_beta works for all k and rho as asserted.

## Scope retained

- For sub-square-root budgets the source's transition floor vanishes, so the matching fixed-positive-floor rate remains intact.
- The result is a stronger lower, not a matching unrestricted upper or a sharp full-class rate.
- The alternatives and known channel can vary with the horizon and budget. No fixed-source inconsistency or exact nonidentifiability is shown.
- The source initialization is exactly stationary and source dependent. There is no arbitrary initial-law uncertainty.
- The channel is offline on the available clean history, future-blind, source independent, and strictly budgeted per word.
- Neither efficient computation, finite-rational realization of every public parameter, neural implementation, executable confirmation, nor external originality is certified.
