# Independent review: posterior prediction and channel identifiability

Status: analytical PASS for the scoped statement below. No unresolved mathematical blocker was found.

Present-time read/hash capture: **2026-11-05T02:33:05Z**.

Reviewed file: `POSTERIOR_PREDICTION_channel_identifiability.md`.

SHA-256: `ae34d4c79371995cce91e328989a078b874741dd8976b8602f19b0d500db3675`.

This digest binds the complete text reread at the stated time. It does not claim earlier historical hashing. The reviewed source file was not edited by this reviewer. Only analytical reasoning, file inspection, file hashing, and review-document writing were performed; no mathematical program, simulation, numerical check, or test suite was executed. The EPR001 predecessor interfaces retain their separately declared evidence status.

## 1. Target and channel semantics

The target is the conditional next-symbol distribution for each fixed true generating specification (theta,mu,C), not a posterior averaged over a prior on unknown models. The source's actual next symbol is generated from the ORIGINAL clean terminal state. The observation channel neither updates the physical source state nor sees the future, and its seed is independent of future innovations. Thus the stipulated joint experiment has the factorization

    P_(theta,mu)(x) C(z|x) theta_(S(x))(y),

and the predictive target is E[theta_(S(X))|Z]. A marginal kernel C(z|x) alone would not specify that factorization if future-correlated randomness were permitted.

The predictor is not told which channel is in force. Revealing the algorithms of both candidate channels is compatible with that restriction; revealing their actual index is not. The exact lower continues to hold when the complete fixed source law is disclosed. Priors over source or channel hypotheses are only lower-bound devices and do not redefine the target.

## 2. Source certificate and legality of the heat-bath channel

Let delta=1-beta and alpha=min(delta/2,1/4). The symmetric binary first-order kernel has diagonal probability 1/2+alpha, stationary symbol law uniform on {0,1}, and stationary pair law Pi(c,d)=T(c,d)/2. Since every binary transition is at least (1-2alpha)/2,

    P^2((a,b),(c,d)) >= (1-2alpha) Pi(c,d) >= beta Pi(c,d).

For K>2, unused current symbols have binary-uniform successors, giving exactly Pi after two steps. All target pair states outside binary support have zero stationary mass. The certificate therefore holds on all pair states, not merely on the support.

C0 is identity. C1 uses an independent Bernoulli(rho) trigger and, only on all-binary words, redraws the last symbol independently from the public kernel T determined by beta. It is identity on other words. This is a fixed channel with no unknown table, stationary law, initial law, or future symbol as an input. Matching its public hard-coded kernel to the single witness source does not introduce an oracle for arbitrary unknown theta.

The channel changes at most one coordinate on every realization, so it is legal for k>=1. On binary words its conditional endpoint-change probability is at most rho(1/2+alpha); on other words it is zero. The identity extension is important: without it, a redraw of an unused final symbol could have change probability rho rather than the sharper binary bound. In either case the principal at-most-rho constraint is satisfied, but the final text correctly establishes the sharper bound on every input.

## 3. Equality of observations and different predictive targets

Conditional on the entire prefix H=X_(1:N-1), the original last symbol has law T(X_(N-1),.). Independently redrawing it from this same law leaves the conditional and hence full word distribution unchanged. Thus the law of all of Z, not merely a histogram or endpoint marginal, is identical under C0 and C1.

Both trigger branches have that same observation law. Consequently the trigger remains Bernoulli(rho) after conditioning on Z. On the redraw branch, original X_N and displayed Z_N are independent conditional on H. The future still depends on original X_N. For s_v=2v-1, this gives

    p0(1|z)=1/2+alpha s_(z_N),
    p1(1|z)=(1-rho)p0(1|z)
              +rho[1/2+2alpha^2 s_(z_(N-1))].

Under their common observation law, consecutive observed symbols agree with probability 1/2+alpha. The exact mean TV separation is therefore

    rho alpha[(1/2+alpha)(1-2alpha)
                +(1/2-alpha)(1+2alpha)]
      =rho alpha(1-4alpha^2).

For any predictor, including independent randomization, the triangle inequality under this common law yields a maximum risk at least half this separation. The midpoint predictor achieves that same risk for each channel. Thus the exact minimax risk of the KNOWN-SOURCE, TWO-CHANNEL subexperiment is

    rho alpha(1-4alpha^2)/2 >= 3rho(1-beta)/32.

The inequality follows from alpha>=delta/4 and 1-4alpha^2>=3/4. The boundaries rho=0 and beta=1 are harmless; k=0 is excluded from the endpoint construction. The exact minimax equality is not asserted for the full unknown-source class.

## 4. Transfer to the unknown-source theorem

Conditional Jensen gives

    E TV(q(Z),E[theta_(S(X))|Z])
      <= E TV(q(Z),theta_(S(X))).

For a randomized predictor, additionally condition on its independent seed. Thus the actual EPR001 estimator transfers with its constants and resource qualifications.

For protected channels, theta_(S(X))=theta_(S(Z)) is measurable from Z with the true table held fixed. The predictive target is exactly that same row, so the protected s and F lower bounds transfer without changing the loss. The original hidden-terminal endpoint lower alone would not transfer; the new channel-identifiability construction supplies the missing endpoint term.

Combining these independent lower witnesses by their maximum gives the stated capped profile

    min{1,max{M^(-1/2),F,rho(1-beta)1{k>=1}}}.

The inherited constants 2^-15 for K>=3 and 2^-54 for K=2 are smaller than 3/32. The EPR001 upper constants remain sufficient. The binary cutoff still requires SC003 plus BT002, not SC003 alone. No endpoint operation is composed with an already full k-edit protected attack.

## 5. Disclosure and future-aware boundary checks

For a known transition table, write D(theta)=max_(u,v)TV(theta_u,theta_v). Conditional convexity gives

    TV(p(Z),theta_(S(Z))) <= D(theta) Pr(S(X)!=S(Z)|Z).

Averaging yields risk at most rho D(theta)<=rho(1-beta), with zero at k=0. This does not assert that the posterior event probability given every z is at most rho. The final text correctly restricts the matching worst-source order statement to k>=1.

When theta,mu,C are all known, the conditional law itself is an admissible predictor and distribution-estimation loss is zero. This neither guarantees exact guessing of the realized next symbol nor supplies an efficient computation theorem. If C is known but theta is not, the two-channel lower is unavailable; the final text correctly leaves the full sharp rate for that different experiment unclaimed.

The future-aware counterexample is also correct and explicitly outside the model. For k>=1 and IID fair symbols, replacing Z_N by the future symbol with probability rho preserves the IID-fair Z law and uses one edit, but produces target (1-rho)/2+rho z_N instead of 1/2. The common-law two-point lower is rho/4 even at beta=1. Its marginal history-to-observation kernel can coincide with a future-blind redraw kernel while its joint coupling with the future differs. This validates the need for the conditional-independence assumption.

## Disposition and limits

The final readback contains the required off-binary channel extension, positive-budget qualifiers, fixed-model target definition, observation-only corruption semantics, independent future randomness, and unknown-channel qualification. Analytical PASS applies to these exact bytes and the theorem scope above.

This is not formal verification, an external novelty result, a new audit of every inherited protected theorem, a finite sampling implementation, or a training/architecture theorem. It makes no claim that the endpoint lower survives disclosure of the actual channel index.
