# A one-edit rare endpoint defeats linear-rho Fisher control of the full predictive score

5 November 2026 UTC. Pure analytical candidate, pending independent exact-file review. No scientific executable checks, numerical experiments, or public writes. This simplifies v1 to an endpoint-only channel; the reviewer identified that a counter prefix is unnecessary for the stated obstruction. Version 1 is preserved unchanged.

## 1. Precise result and scope

Fix 0<beta<1 and a positive rational

    r<=min{(1-beta)/2,1/8}.

For each integer M>=4 put N=M+2, rho=1/M, and a_0=1/M. Consider the stationary binary first-order source

    P_a(1|x)=a+r x,

with a varying near a_0 while r, M, the channel, and rho stay fixed. There is a known online S=1 channel with at most ONE actual edit and per-word endpoint-change probability exactly rho for which

    E_(a_0) |Cov_(a_0)(g_(a_0)(X_N), S_all | Z)|
        >=5r/16,
    I_step(a_0)<=2M,                                  (B1)

where g_a(X_N)=a+rX_N is the true future success probability and S_all=partial_a log P_a(X_1,...,X_N) is the COMPLETE stationary-source score.

Thus no uniform inequality

    E |Cov(g_a(X_N),S_all|Z)|
        <=C_beta rho^alpha k sqrt(I_step(a))           (B2)

can hold in the no-floor S=1 class for any alpha>1/2, already with k=1. In particular the linear-rho version alpha=1 is false.

This is a rare-endpoint conditioning obstruction, not a hidden-counter-specific obstruction. It does not establish a new predictive minimax rate, a separation by base-state count, or a failure of a bound with an additional rho-independent baseline. It does not prove that the alpha=1/2 inequality is valid.

## 2. Source certificate and exact channel

The stationary probabilities are

    pi_a(1)=a/(1-r), pi_a(0)=(1-r-a)/(1-r).

Viewed as an order-two source, it has

    P_a^2((w,x),(y,z))=P_a(y|x)P_a(z|y),
    Pi_a(y,z)=pi_a(y)P_a(z|y).

The minimum of P_a(y|x)/pi_a(y) is 1-r, so the all-state D2(beta) certificate holds.

The channel displays X_1,...,X_(N-1) unchanged. At N, if the actual counter is zero, it flips X_N with an independent probability-rho coin and otherwise leaves it unchanged. Its exhausted-counter row is identity. Every actual path uses at most one edit; every raw word has endpoint-change probability exactly rho. The kernel depends only on time, current raw bit, and actual edit count. It is normalized, source independent, online, future blind, and has one base state. All channel probabilities are rational.

## 3. Exact complete-score covariance

Write H=X_1,...,X_(N-1), B=X_N, and W=Z_N. The entire H is observed without error. Given H, put

    p=a+r X_(N-1),
    q=rho+(1-2rho)p=P_a(W=1|H).

The posterior endpoint probabilities are

    F_1=P_a(B=1|H,W=1)=p(1-rho)/q,
    F_0=P_a(B=1|H,W=0)=p rho/(1-q).                  (B3)

All source-score terms before the terminal transition are measurable functions of H and therefore have zero conditional covariance. The last transition score is

    s_N=(B-p)/[p(1-p)].                               (B4)

Consequently the covariance with the complete score, after all possible cancellations, is exactly

    Cov_a(g_a(B),S_all|H,W=w)
        =r Var_a(B|H,W=w)/[p(1-p)]
        =r rho(1-rho)/ell_w^2,                       (B5)

where ell_1=q and ell_0=1-q. Both signs are positive. The actual predictive target satisfies

    P_a(X_(N+1)=1|H,W=w)=a+r F_w,
    partial_a P_a(X_(N+1)=1|Z)
        =1+Cov_a(g_a(B),S_all|Z).                    (B6)

Equation (B6) includes the direct derivative of g, the local Bayes reweighting, and the complete stationary initial-law score. No remote or local score is omitted.

For reference, summing over both endpoint outputs gives the exact integrated formula

    E_a |Cov_a(g_a(B),S_all|Z)|
        =r rho(1-rho) sum_(x=0,1)
             pi_a(x)/[q_x(1-q_x)],
    q_x=rho+(1-2rho)(a+rx).                          (B7)

## 4. Retain the actual rare-output mass

At a=a_0=rho=s=1/M, on the observable event

    A={Z_(N-1)=0, Z_N=1},

one has p=s, q=2s(1-s), and

    P_(a_0)(A)=pi_(a_0)(0) 2s(1-s),
    Cov_(a_0)(g,S_all|Z)=r/[4s(1-s)] on A.            (B8)

Their product is exactly pi_(a_0)(0) r/2. Since s<=1/4 and r<=1/8,

    pi_(a_0)(0)=(1-r-s)/(1-r)>=5/8.

Keeping A in the full expectation proves the first inequality in (B1):

    E |Cov(g,S_all|Z)|>=5r/16.                        (B9)

The output event has mass of order rho, while the complete conditional covariance is of order 1/rho. The rare-output mass has not been discarded.

## 5. Fisher information and the contradicted exponents

The stationary one-step Fisher information is

    I_step(a)=pi_a(0)/[a(1-a)]
                 +pi_a(1)/[(a+r)(1-a-r)].             (B10)

At a_0=s, the first term is at most 4/(3s). The second is at most

    1/[(1-r)(1-s-r)]<=64/35<2<=1/(2s).

Thus I_step(a_0)<2/s=2M. With k=1,

    rho^alpha k sqrt(I_step(a_0))
        <=sqrt(2) M^(1/2-alpha),                      (B11)

which vanishes for every alpha>1/2, contradicting (B9) under any fixed constant. Equivalently, the Fisher-normalized integrated covariance is at least a fixed beta-dependent multiple of sqrt(rho).

There is also an L2 obstruction. The same event A gives

    E [Cov(g,S_all|Z)^2]
        >=pi_(a_0)(0)r^2/[8s(1-s)]
        >=5r^2 M/64.                                 (B12)

Therefore E Cov^2<=C_beta rho k^2 I_step fails too. More generally no positive power of rho can multiply k^2 I_step in a uniform squared-covariance bound of this form.

## 6. Why this does not give a new minimax separation

The derivative in (B8) is large only on output mass of order 1/M. Parameter alternatives a=(1+/-d)/M have a difference of order 1/M, so this branch can produce a constant target separation but only an order-1/M integrated predictive contribution. That is below the independent clean M^(-1/2) lower. No matching-rate conclusion follows from the score obstruction.

For the open S=1 upper, this calculation rules out inserting a linear-rho factor into a Fisher-normalized complete-score estimate solely from the endpoint certificate, even after preserving every cancellation. A successful argument must retain rare endpoint likelihood denominators and baseline row-estimation terms, or use a different global comparison quantity.
