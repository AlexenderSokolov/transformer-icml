# A genuine one-base-state counter lower, without a free gate

5 November 2026 UTC. Version 2 corrects a mixed-neighbor odds identity and explicitly guards the unreachable exhausted-counter row at position 1. Pure analytical candidate, pending independent review. No scientific executable checks, numerical experiments, or public writes. The existing reviewed S>=2 matching theorem is unchanged.

## 1. Result and what remains open

For fixed 0<beta<1, sufficiently large M, N=M+2, integer 1<=k<=M and rational rho in [0,1], the actual-counter, time-indexed one-base-state class has the lower bound

    R_{S=1,beta}(M,k,rho)
      >= c_beta min{1, M^(-1/2)+k/M
                         +rho min{1,k/sqrt(M)}}.                 (A1)

This is a statistical lower for an actual S=1 channel, not an automaton nonimplementation argument. It matches the already reviewed general upper when k>=sqrt(M), up to fixed-beta constants. For k=o(sqrt(M)) it generally does not match the S>=2 endpoint term min{rho,(k^2/M)^(1/3)}. No uniform S=1 improvement of that upper, separation, minimality claim, or sharp S=1 profile is proved here.

The clean and protected-budget terms in (A1) are the existing one-state witnesses. The new endpoint witness has uniform transition floor 1/4; the imported protected k/M term in (A1) concerns the stated broader D2 class and is not, by that import alone, a fixed-floor theorem. Below we establish the additional rho min{1,k/sqrt(M)} term for unbounded k; the clean witness absorbs the finitely many excluded k.

## 2. Stationary binary sources with an explicit D2 certificate

Put gamma=(1-beta)/64. Use the stationary first-order binary chain

    P_a(1|x)=a+gamma x,      a in [1/4,3/8].

Regard it as an order-two source with theta_a(uv)(1)=a+gamma v. Its stationary one-bit probabilities are

    pi_a(1)=a/(1-gamma),
    pi_a(0)=(1-gamma-a)/(1-gamma).

For pair states (w,x),(y,z),

    P_a^2((w,x),(y,z))=P_a(y|x)P_a(z|y),
    Pi_a(y,z)=pi_a(y)P_a(z|y).

The minimum of P_a(y|x)/pi_a(y) over x,y is exactly 1-gamma. Thus the all-state D2(beta) certificate holds, since 1-gamma>=beta.

Choose constants alpha>0 and d_0>0 in that order, both sufficiently small; alpha is dyadic. They are absolute constants, with no dependence on M,k,rho. Put

    a_-=1/3-delta,   a_+=1/3+delta,   delta=d_0/sqrt(M).

For sufficiently large M both alternatives lie in the displayed interval. Transition probabilities and stationary probabilities are uniformly bounded away from zero and one. Consequently the raw fixed-start tail KL is at most C M delta^2 <= C d_0^2, and its TV is at most C d_0. These follow directly from the Bernoulli KL bound on a compact subinterval and the chain rule.

## 3. Exact one-state channel

For k>=3 set

    h=min{k-2,floor(sqrt(M))},    epsilon=alpha h/M,
    J={4,6,8,...} intersect {i:i<=N-2}.

There is only one base state. The following rows depend solely on time i, the current raw symbol x_i, and the actual edit counter e.

1. At i=1, output zero when e<k; otherwise output x_i. At the actual initialization e=0, e therefore becomes exactly X_1.
2. At i in J, if x_i=1 and 1<=e<h+1, erase it with probability epsilon. Otherwise output x_i.
3. At i=N, if 1<=e<k, flip x_i with probability rho. Otherwise output x_i.
4. At all remaining positions output x_i.

Every change increments e by exactly one. Coins are independent auxiliary randomness. The rules, including counter guards, define normalized rational rows at all counter values. No other stored state or shared hidden random bit is used.

If X_1=0, the counter remains zero and the channel is identity after position 1. If X_1=1, the initial erasure activates the counter-positive mode, permits at most h additional candidate erasures, and leaves one reserved endpoint edit. Hence every path has at most h+2<=k changes. On every fixed raw word the endpoint-change probability is exactly rho when X_1=1 and zero otherwise, because the reservation is never exhausted before N. The channel is online and future blind.

The table uses only M,k,rho and the fixed rational alpha. In particular it uses neither unknown a nor any raw context. Its expanded description and actual k+1-valued counter are paid separately, with a conservative ledger

    ell=O(N(k+1)[b_rho+log(M+1)+log(k+1)+1]).

## 4. A genuinely hidden counter mode

Condition on the observable event B_pre={Z_2=0}. Position 1 always displays zero. Since position 2 is untouched, the raw tail starts from X_2=0. Let U=X_1, which is exactly the edit count at tail entry. Stationary binary detailed balance gives

    P_a(U=1 | B_pre)=P_a(X_1=1 | X_2=0)=a.             (A2)

Moreover the Markov property makes the entire subsequent raw tail independent of U conditional on B_pre. Its law Q_a is the chain started from X_2=0. The branch probability is b_a=pi_a(0)>=1/2.

The mode prior omega_a=a is not common to the alternatives. Its monotonicity is useful, and its small difference is explicitly accounted for below. No common-prior assertion is made.

## 5. Recoverable scaffold and uniformly monotone conditional odds

Let H retain X_2 and all later raw coordinates except the candidate bits X_j, j in J, and B=X_N. All retained coordinates are untouched. Thus H is recoverable from the output. Candidates are nonadjacent and do not neighbor B, so the first-order Markov factorization makes all the missing bits conditionally independent given H. Candidate probabilities need not be identical.

The conditional candidate odds depend on the retained adjacent pair (u,v) and are

    o_a(0,0)=a(1-a-gamma)/(1-a)^2,
    o_a(0,1)=(a+gamma)/(1-a),
    o_a(1,0)=(a+gamma)/(1-a),
    o_a(1,1)=(a+gamma)^2/[a(1-a-gamma)].                (A3)

Throughout a in [1/4,3/8], 0<gamma<=1/64, direct differentiation gives the deliberately loose uniform bounds

    1/4 <= o_a(u,v) <= 1,
    2 <= d[log o_a(u,v)]/da <= 14.                    (A4)

For example the logarithmic derivatives in the order displayed in (A3) are

    1/a-1/(1-a-gamma)+2/(1-a),
    1/(a+gamma)+1/(1-a),
    1/(a+gamma)+1/(1-a),
    2/(a+gamma)-1/a+1/(1-a-gamma).

Thus all candidate probabilities p_aj=o_aj/(1+o_aj) lie in [1/5,1/2], and

    exp(4delta) <= o_+j/o_-j <= exp(28delta).          (A5)

There are n=|J| candidates, with M/3<=n<=M/2 for sufficiently large M. Conditional on H, B has probability p_a^B=a+gamma X_(N-1), independently of the candidates.

## 6. The exact capped likelihood is a positive polynomial

Fix any scaffold H. Let P_a0 be the product distribution of the displayed candidate vector Y under U=0. Let P_a1 be its distribution under U=1 with the actual h-erasure cap. Put

    Lambda_a(Y)=P_a1(Y)/P_a0(Y),
    m_a(Y)=(1-a)P_a0(Y)+a P_a1(Y),
    v_a(Y)=P_a(U=1|H,Y).

For each fixed Y, write E for the set of candidate sites that were actually erased. Necessarily E is a subset of the displayed-zero sites and |E|<=h. Conditional on E and Y the raw candidate vector is fixed. Its probability relative to P_a0(Y) is product_{j in E} o_aj. The probability of the corresponding channel coin path depends on Y,E,epsilon and the cap, but not on a. Therefore there are nonnegative coefficients c_E(Y), common to both sources, such that exactly

    Lambda_a(Y)=sum_{E subset {j:Y_j=0}, |E|<=h}
                   c_E(Y) product_{j in E} o_aj.       (A6)

The empty coefficient is positive. The terms in (A6), normalized by Lambda_a(Y), are precisely the posterior law of the actual erasure set under active mode. Let

    r_a(Y)=E_a[|E| | H,Y,U=1].

Using (A5) term by term and Jensen's inequality yields the exact capped inequalities

    log Lambda_+(Y)-log Lambda_-(Y) >= 4delta r_-(Y),
    0 <= log Lambda_+(Y)-log Lambda_-(Y) <= 28delta h. (A7)

This avoids subtracting a fixed cap-TV error from a separation that tends to zero with M.

## 7. Hidden mode overlap retains order h actual erasures

All constants in this section are uniform in H.

In the uncapped active experiment let D be the proposed erasure count. It is a sum of independent Bernoulli variables of mean

    mu=epsilon sum_j p_-j,
    alpha h/20 <= mu <= alpha h.

The capped actual count is D_h=min(D,h). Since (D-h)_+ <= D(D-1)/h,

    E D_h >= mu-mu^2/h >= alpha h/40                 (A8)

when alpha is sufficiently small. Also E D_h^2 <= mu+mu^2. For h>=H with a fixed H>=1/alpha, this is at most 2alpha^2 h^2.

The standard one-coordinate product chi-square calculation between Ber(p) and Ber((1-epsilon)p), with p in [1/5,1/2], gives

    TV(P_-0,P_-1^uncapped) <= C alpha h/sqrt(M)
                            <= C alpha.

Coupling until the cap gives an additional TV of at most

    P(D>=h) <= (e alpha)^h.

Increase the fixed H, if needed, so this is at most alpha whenever h>=H. Hence

    TV(P_-0,P_-1) <= C_0 alpha.                       (A9)

Let E_0={1/2<=Lambda_-<=2}. The likelihood-ratio test bound gives P_-1(E_0^c)<=C TV(P_-0,P_-1)<=C alpha. Cauchy-Schwarz on the joint active law of (Y,D_h), followed by the second-moment bound, gives

    E[D_h 1{Y in E_0^c}] <= C alpha^(3/2) h.

Choose alpha sufficiently small. Equations (A8) and (A9) then imply

    sum_{Y in E_0} P_-1(Y) r_-(Y) >= alpha h/80,
    sum_{Y in E_0} m_-(Y) r_-(Y) >= alpha h/320.      (A10)

Conditional raw candidate product laws under a_+ and a_- have TV at most C delta sqrt(n)<=C d_0, by their uniformly bounded odds and derivatives. Applying the same capped channel preserves that bound for the active distributions. The differing mixture weights add at most 2delta. Consequently

    ||m_+-m_-||_1 <= C_1 d_0.                         (A11)

Since r_-<=h, take d_0 small enough after alpha. Then

    sum_{Y in E_0} min{m_+(Y),m_-(Y)} r_-(Y)
        >= alpha h/640.                              (A12)

The posterior mode odds are a Lambda_a/(1-a). On E_0, equation (A7), delta h<=d_0 and a in [1/4,3/8] put both posterior odds in a fixed compact subinterval of (0,infinity); after decreasing d_0 they lie in [1/6,12/5]. The logistic derivative on this interval is at least 1/16. The prior log odds increase with a, and (A7) therefore gives

    v_+(Y)-v_-(Y) >= (delta/4) r_-(Y),   Y in E_0.

Thus, for every H,

    J(H):=sum_Y min{m_+(Y),m_-(Y)} |v_+(Y)-v_-(Y)|
          >= alpha d_0 h/[2560 sqrt(M)].              (A13)

There is no assumption of independence between a terminal event and an erasure count. This estimate holds for every scaffold, so no such event is needed.

## 8. Endpoint posterior and lower bound

Let W=Z_N. The active mode has a reserved endpoint edit, so put T_a=rho v_a(H,Y). For W=0,

    ell_a(0)=1-p_a^B+(2p_a^B-1)T_a,
    F(p,T)=pT/[1-p+(2p-1)T],
    g_a(H,Y,0)=P_a(X_(N+1)=1|Z)=a+gamma F(p_a^B,T_a).

These are source-specific posterior targets. Because p_a^B is uniformly interior, ell_a(0)>=1/4. Moreover

    dF/dT = p(1-p)/[1-p+(2p-1)T]^2 >= 1/4,
    dF/dp = T(1-T)/[1-p+(2p-1)T]^2 >= 0.

Both p_a^B and v_a increase from the minus to the plus alternative. Hence the direct change of a and the endpoint-mixture change have the same sign, and

    g_+(H,Y,0)-g_-(H,Y,0)
        >= (gamma rho/4)(v_+(H,Y)-v_-(H,Y)).          (A14)

Let f_a be the conditional scaffold law on B_pre. By the fixed-start raw KL bound and data processing, decreasing d_0 gives

    sum_H min{f_+(H),f_-(H)} >= 3/4.

The output mass on the retained branch is b_a f_a(H)m_a(Y)ell_a(0), with b_a>=1/2. Applying the two-source absolute-loss inequality, (A13), and (A14) yields

    max_a Risk_a(Q) >= c_beta rho h/sqrt(M).           (A15)

For h>=H, h is at least a fixed multiple of min{k,sqrt(M)}. Increase M_beta so floor(sqrt(M))>=H. If h<H, then k<=H+2 is bounded; the clean one-state lower c_beta/sqrt(M) absorbs rho min{1,k/sqrt(M)} after a fixed constant loss. Taking the maximum with the existing clean and protected-budget witnesses proves (A1).

## 9. Exact form of an arbitrary one-state, one-edit channel

This is a useful reduction, not an S=1 minimax upper.

For k=1 write a_i(x)=K_i(1-x|x,e=0). At e=1 the strict cap forces identity. For a displayed word z, its no-edit preimage has channel mass

    c_0(z)=product_{i=1}^N [1-a_i(z_i)].

Its preimage flipped only at j has channel mass

    c_j(z)=a_j(1-z_j) product_{i<j}[1-a_i(z_i)].        (A16)

There is no survival factor after j. Therefore, for every source law P_theta,

    P_theta^Z(z)=c_0(z)P_theta(z)
                 +sum_j c_j(z)P_theta(z^flip_j).      (A17)

The numerator of the posterior next-bit target is the same sum with each term multiplied by theta of that preimage's terminal pair. Thus all early j<=N-2 share the displayed terminal transition row; only j=N-1,N change that row. Formula (A17) is valid even with zero hazard/survival probabilities and needs no division by c_0 or P_theta(z).

A general upper would still need to control the source-dependent local likelihood ratios in this mixture uniformly over arbitrary time-dependent hazards and all stationary D2(beta) sources, including rare transition rows. Merely observing that these hazards cannot explicitly test a raw two-bit gate does not prove that upper or a separation.

## 10. Current boundary

The analytically established S>=2 profile remains the appropriate general upper for S=1. If this new candidate is accepted, the one-state brackets become

    c_beta min{1,M^(-1/2)+k/M+rho min{1,k/sqrt(M)}}
       <= R_{S=1,beta}(M,k,rho)
       <= C_beta min{1,M^(-1/2)+k/M
                            +min{rho,(k^2/M)^(1/3)}}.

They match for k>=sqrt(M), and also in regimes where the endpoint upper is absorbed by the clean/protected terms. They leave the principal sub-square-root-budget S=1 question open. In particular no claim that two base states are necessary follows from this note.
