# Present-time hash attestation: stationary binary known-channel upper

Date: 2026-11-05 UTC. Current-time check: 2026-11-05 03:20:02 UTC. File-content and SHA-256 verification followed immediately afterward in this review session.

## Exact present-time files

Candidate:

    KNOWN_CHANNEL_stationary_binary_upper.md
    SHA-256: 939edd8779288fd004a47978e4bc527c5c6f3f6538bf292a9e5392e7e6ee4200

Independent review:

    KNOWN_CHANNEL_stationary_binary_upper_independent_review.v1.md
    SHA-256: d66526ae8f2a3f28ca47b22a450c73980800a797a848b50d73dacd13a883ae97

Both files are in the same directory as this attestation. Neither original file was edited to create this attestation.

## Scoped present-time reaffirmation

I reaffirm the independent review for the current candidate at the digest above. The candidate now explicitly states 0<beta<=1 and explicitly derives the transition logarithm bound from epsilon<=beta^2 a^2/8<=eta/2. These resolve the two editorial clarification requests recorded in the unchanged review. They do not alter the theorem's mathematical scope or proof strategy.

The reviewed result is the information-theoretic stationary binary known-channel upper

    min{1,C_beta[M^(-1/10)+(k/sqrt(M))^(1/4)]},

and its explicit finite-parameter bound (B11). The analytical review found no substantive gap or counterexample. This supports uniform consistency for fixed positive beta and k=o(sqrt(M)); it does not establish a sharp rate, moving-beta result, arbitrary-start extension, ternary result, efficient implementation, external novelty, or formal verification.

## Current binding versus historical binding

These SHA-256 values identify the files as checked now. The earlier independent review named the candidate but did not record a candidate digest at the time it was first written. This attestation does not invent a historical digest or retroactively claim cryptographic binding of the earlier review to historical candidate bytes. It supplies a new, present-time reaffirmation tied to the exact current candidate and review files above.

The candidate and review are frozen for the requested private preservation. A stronger separate version may be written under another filename; it is not covered by this attestation.

Only document inspection, file hashing, and document writing were performed for this attestation. No scientific executable check, experiment, public repository write, or alteration of either preserved original occurred.
