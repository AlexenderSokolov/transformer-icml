# Same-preimage endpoint weighting of the actual edit window

5 November 2026 UTC. Pure analytical addendum to `KNOWN_CHANNEL_one_edit_hazard_reduction.research.v1.md`. No scientific execution, diagnostics, numerical experiment, or public write. This is not a general one-state predictive upper. Independent review is pending.

## Statement

Use the stationary binary D2(beta), one-base-state, strict-one-edit experiment and notation of the cited research note. Let c_* be a minority symbol, m=pi(c_*), and

    g_N(X)=theta_(X_(N-1),X_N)(c_*).

Fix nonnegative integers r,s, a local word w of length r+s+1, and the valid interior edit indices r+1<=i<=N-s. Let its central symbol be c. If pi(c)>0, then

    E[g_N(X) 1{r+1<=J<=N-s, W_J=w}]
       <= [C_(beta,r) m/pi(c)+2/beta] Pr(W=w)
       <= [C_(beta,r)+2/beta] Pr(W=w).                 (E1)

Here W_i=X_(i-r):X_(i+s), J is the actual edit time, and C_(beta,r) is the constant from H8 of the research note. The rightmost bound uses pi(c)>=m. If pi(c)=0 the event has zero probability.

Thus weighting by the future minority probability of the **same actual raw preimage** removes the marginal inverse cost from H8. The constant is independent of the horizon and the arbitrary time-dependent hazard schedule. It does not use the endpoint certificate rho.

## Proof

First set aside the single exceptional index i=N when r=s=0. At that index the continuation i-r through N contains only X_N, while g_N can also depend on X_(N-1); directly, its contribution is at most Pr(X_N=w), since both g_N and the edit indicator are at most one. We charge this bound to the d=0 geometric-remainder term below, rather than applying (E2) there.

For every remaining index, let b=beta/2 and B_i=sum_(h<=i-r-2)lambda_h. The reverse survival argument in H7 is uniform over every fixed continuation from i-r through N. This continuation now includes both terminal coordinates, so it can first be conditioned on that entire continuation and then averaged with the nonnegative, continuation-measurable factor g_N(X)1{W_i=w}. This yields

    E[g_N 1{J=i,W_i=w}]
       <= a_i(c) exp(-b B_i) E[g_N 1{W_i=w}].         (E2)

Put t=i+s. If s=0 and r=0, average over the raw pair ending at t conditional on X_t; otherwise that pair is fixed or partly fixed by W_i. In all cases the Markov property and two-step minorization give, uniformly in the resulting initial pair distribution,

    E[g_N | W_i=w]
       <= m+(1-beta)^floor((N-t)/2).                  (E3)

Indeed, start the pair chain at its raw pair ending at t. The target g_N is a bounded [0,1] function of the pair ending at N, with stationary mean m. The total-variation contraction after N-t pair transitions is at most (1-beta)^floor((N-t)/2). Averaging over any unspecified coordinate of the initial pair preserves this bound. At the very first raw coordinate, the stationary preceding pair can be supplied by a two-sided stationary extension, or the same conclusion follows by conditioning on that preceding bit and averaging; no extra observation is provided to the predictor or channel.

Sum (E2), substitute (E3), and use stationarity of W_i. The m contribution is bounded exactly as in H8 by

    C_(beta,r) [m/pi(c)] Pr(W=w).

For the geometric contribution, discard both a_i(c)<=1 and exp(-b B_i)<=1. The distance d=N-i-s ranges over a subset of the nonnegative integers, so

    sum_i (1-beta)^floor((N-i-s)/2)
       <= sum_(d=0)^infinity (1-beta)^floor(d/2)
       =2/beta.

If the exceptional index r=s=0, i=N exists, the sum over the other indices has d>=1 and is at most 2/beta-1; adding its direct bound Pr(X_N=w) restores at most the same 2/beta coefficient. Thus (E1) holds with the stated constants in all cases. No independence between the edit time, the local pattern, and the endpoint was asserted.

## Exact limitation

The target g_N, the window W_J, and J in (E1) all refer to one and the same raw word and its actual channel edit. The endpoint-prediction cross-product H4 also contains terms where an early edit time from one posterior preimage is paired with the future-row value or local raw pattern of another preimage. Those are not instances of (E1).

In particular, a raw 101 can be changed to displayed 111, whose competing endpoint-edit preimage has raw 111. The rarity of that competing raw pattern and its future-row value must be combined with its actual posterior likelihood weight. The new lemma does not remove that denominator or solve this crossed-preimage term.

The full strict-one-edit S=1 root-M question remains open in these notes.
