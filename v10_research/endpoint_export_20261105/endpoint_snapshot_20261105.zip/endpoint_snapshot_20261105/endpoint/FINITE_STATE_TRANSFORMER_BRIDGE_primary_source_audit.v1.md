# Primary-source audit: finite-state channel Transformer bridges

Date: 2026-11-05 UTC. Source comparison and analytical interface audit. No executable scientific checks, experiments, public uploads, or edits to the theorem candidates were performed. This is not novelty certification or a replacement for independent proof review.

## 1. Findings

The nearest precedents are stronger than a comparison only with general Turing-completeness results would suggest. Weighted-automaton inference, direct Transformer simulation of weighted automata, bounded rational stack encodings, Boolean arithmetic, and zero-score averaging all have substantial prior art. None should be presented as new individually.

The supplied candidates instead assemble a specific computational contract: a disclosed normalized online rational channel; the actual fitted-posterior estimator; explicit denominator and Boolean-circuit accounting; raw-token causal softmax/ReLU realization with uniformly bounded local norms; and composition with a source-specific expected posterior-prediction upper bound. Their useful distinction is that complete package and its charged resources, particularly the separate growing-width and growing-precision implementations.

The statistical upper profile is inherited on a narrower implementable channel class. The matching lower for arbitrary offline channels has not been established for this online class. Calling the new result a sharp minimax theorem for bounded-state online channels would overstate it.

This report supplements, rather than repeats, `RHO_INTERPOLATION_primary_source_audit.v1.md`, the preceding stationary/posterior audits, and `KNOWN_CHANNEL_computational_interface_audit.v1.md`. Their distinctions between latent-terminal loss, source-specific posterior loss, common versus hypothesis-dependent channels, and pointwise versus expected guarantees remain in force.

## 2. Exact object being implemented

### 2.1 Statistical experiment and target

The clean source is stationary, binary, homogeneous, and order two. Write N=M+2. Its pair chain satisfies the all-state minorization P²(u,v) >= beta Pi(v). The source parameter theta is unknown. The channel C and the public finite budgets/certificates are disclosed; its seed, edit mask, hidden states, and clean history are not.

The target is

    p_(theta,C)(z) = P_(theta,C)(X_(N+1)=1 | Z=z).

This conditional averages hidden clean histories under each fixed source. It is not a posterior mixture over unknown source parameters, a hidden-state classification label, a MAP/Viterbi path, or the unobserved terminal transition row itself. Bernoulli TV equals absolute error here. The target may be computable with zero distribution-estimation loss if both theta and C are known, despite irreducible randomness in the next bit.

Future blindness must be a property of the joint experiment: channel auxiliary randomness is independent of the entire source process, and the channel only reads the available prefix. A marginally specified stochastic kernel alone must not be coupled to a future innovation through an undisclosed seed.

### 2.2 Online channel restriction

The implemented C is a one-pass, possibly time-inhomogeneous, rational finite-state transducer with normalized kernels K_i(s',z | s,x,e). It sees the current clean symbol and its own state/counter, not future clean symbols within the observed block. This is narrower than the statistical theorem's arbitrary future-blind offline block channel.

Source independence means that the channel does not receive the unknown source parameter and the same kernel applies under alternative sources. It does not mean that its edits are independent of the observed clean symbols. Its design may use the public horizon and budgets.

The hard edit budget is an all-realization condition enforced by a deterministic counter e'=e+1{x!=z}, not an expected number of edits. When an edit is prohibited, the construction redirects its probability to the matching output while retaining the selected next base state. It does not discard probability mass or condition a different channel on eventual acceptance. There is no terminal acceptance/global-conditioning step.

The endpoint constraint is conditional on every clean input word, not merely source-averaged. An independent initial endpoint gate with probability rho_g <= rho is one sufficient implementation. That gate and the strict edit counter are different constraints. S excludes the separately charged counter; if the gate is stored in s, it is already included in S.

The expanded time-indexed rational table length ell is charged. Reusing a homogeneous table does not make its repeated denominator contribution free. A compact program requires its own generation/evaluation costs; a sampler is not an exact likelihood oracle. S may grow, with that growth explicitly paid. The candidates give horizon/channel/precision-indexed compiled families, not one fixed coherent infinite-stream channel or one fixed network valid at every length.

### 2.3 Fitted posterior versus true target

Counts from the displayed word define positive fitted transitions and an initial pair law:

    theta_hat_u(c) = (C'_(u,c)+1)/(J'_u+2),
    Pi_hat_u = (J'_u+1)/(M+4).

Pi_hat need not be stationary for theta_hat. It is a computational initial law, not an extension of the statistical theorem to arbitrary unknown initial distributions. For a fixed displayed z, the fitted parameters are fixed before the hidden-path summation:

    q_fit,C(z) =
      sum_x P_hat_z(x) C(z|x) theta_hat_(S(x))(1)
      / sum_x P_hat_z(x) C(z|x).

The bridge approximates this specified fitted quantity, not the unknown true posterior by algebra alone. Its statistical performance is a separate theorem. Positive fitted clean-word mass makes its evidence positive on every output supported by the actual source/channel. A 1/2 fallback handles zero evidence on off-support inputs and makes the compiled computation total.

## 3. Resource ledger that distinguishes the candidates

The forward state is the product of clean pair, channel state, edit count, and time. The deterministic counter increment gives R=O(NS²(k+1)) arithmetic updates, rather than a quadratic counter factor. Denominator clearing gives integer bit length O(ell+N log N+r). Nonnegative intermediate masses are controlled by their common denominators. Tiny evidence is handled by charged integer bits and final integer division, not an unbounded inverse-evidence activation or a unit-cost rational decoder.

With B the displayed bit budget and G=O((R+N+1)B²), padded to include input/count/output work, schoolbook arithmetic yields a finite Boolean circuit. The candidate then compiles that circuit rather than claiming multiplication/division as primitive Transformer operations. Its output retains the integer bit needed for q=1 and otherwise uses r dyadic fractional bits, with error at most 2^-r.

Both realizations use only the N displayed one-hot bits, public p_t=t/P for P=2^ceil(log2(N+1)), and one zero-symbol query row. The mask is self-inclusive causal. All eligible attention scores are exactly zero. There is one ordinary softmax head, residual two-layer ReLU feedforwards, no LayerNorm/RMSNorm, no final vocabulary softmax, and a coordinate output projection.

To recover an individual raw input bit, positional equality is built by bounded-slope clipped doubling; uniform causal averaging then produces either zero or z_i/t. O(log N) further clipped doublings recover the bit exactly. Repeating this operation costs O(N log N) layers. It does not obtain concentrated attention for free. Earlier rows contain valid padded-prefix bit words, supporting the claimed all-row state invariant.

- **Growing bank:** d=O(G), L=O(G) after padding, and exact scalar bit length w=O(r+log N+log G). Boolean wires occupy separate coordinates of size h=2^-ceil(log2 d). Serial gates/fanout keep each matrix norm bounded; the final bounded-depth-per-doubling output reconstruction restores scale. Large integers reside in many Boolean coordinates.
- **Constant-width stacks:** d=64, FFN width 128, L=O(N log N+G²), and w=O(G+r+log N). A stack with m<=G bits is S=sum_j b_j 4^-j, bounded by 1/3. Push/pop/top extraction are bounded piecewise-linear operations on separated digit ranges. Public gate-address access is implemented by paid sequential moves between two stacks and restoration, not a random-access oracle or a free controller. The denominator 4^G explicitly costs O(G) bits.

Constant width and bounded activation magnitude therefore do not mean constant information capacity. The second construction exchanges spatial Boolean storage for precision and depth. Bounded norm of each local matrix also does not bound the Lipschitz constant of the entire growing-depth network uniformly in N.

These are exact-rational constructions with charged finite descriptions and conservative polynomial bit-operation/evaluation bounds. They are not floating-point robustness guarantees: repeated stack pops can amplify a low-order digit error. There is no proved training procedure, practical parameter claim, fixed-depth universality, optimal width/depth frontier, or tied-weight length generalization result.

For T=N+1, the stated conservative dense exact-rational runtime is O(L(Td²+T²d)w³), with O(Tdw) rolling-state bits and optional O(T²w) materialized attention. Explicit dense untied parameters cost O(Ld²(log N+log G)) bits; the stack construction's coefficients need only O(log N) bits each. Rational-table preprocessing, circuit generation, and parameter emission remain charged separately. These bounds do not treat sparsity, circuit addresses, or compilation as free computation.

## 4. Closest primary precedents

The entries below distinguish what the source establishes from its applicability to this experiment. The comparison is bounded by the inspected sources and their stated models.

### 4.1 Weighted transducers and sum-product inference

Mohri's *Weighted Automata Algorithms* develops probability-semiring path sums and weighted-transducer composition by a product construction and summation over intermediate strings. Section 5.1, equation (23), is a direct precedent for composing a source with an observation transducer; the acyclic shortest-distance discussion explicitly charges semiring-operation costs. Here, time unrolling, the pair state, and the edit counter specialize that established machinery. Joint emission/next-state kernels fit an edge-emitting transducer, or an augmented HMM. The present channel uses substitutions, not insertion/deletion epsilon transitions. The rational bit ledger and the subsequent statistical bound are additional obligations, not new forward-inference principles. [Author manuscript](https://www.cs.nyu.edu/~mohri/postscript/hwa.pdf).

Aji and McEliece's *The Generalized Distributive Law* treats Bayesian normalization and probabilistic state machines, with the chain/junction-tree specialization recovering sum-product/BCJR computation; changing semirings gives different algorithms such as Viterbi. Their illustrative state-machine inputs are independent, whereas the candidate uses a Markov clean source. State augmentation places the candidate in the same general factorization framework. This is a sum-over-paths posterior, not maximum-path decoding. [Author manuscript, examples 2.4–2.5 and section 4.5](https://cba.mit.edu/events/03.11.ASE/docs/Aji.pdf).

### 4.2 Direct Transformer simulation of weighted automata

Rizvi, Lizaire, Lacroce, and Rabusseau, AISTATS 2024, *Simulating Weighted Automata over Sequences and Trees with Transformers*, is the strongest direct architecture precedent. Theorem 1 gives exact weighted-automaton simulation using hard attention and bilinear layers; Theorem 2 states arbitrary-accuracy simulation with softmax and two-layer MLPs at O(log T) depth, with embedding dimension O(n²) and MLP width O(n⁴). Appendix B.2 uses a tunable score-saturation constant and polynomial-approximation machinery, without the candidate's uniform coefficient/activation norms and exact finite-rational ledger. The candidate also must construct data-dependent fitted parameters and normalize a posterior, rather than only compose fixed token-transition matrices. Thus the bridge should not claim Transformer realization of finite-state weighted computation in general as new. [Primary proceedings paper, theorems 1–2 and appendix B](https://proceedings.mlr.press/v238/rizvi-martel24a/rizvi-martel24a.pdf).

### 4.3 HMM inference architectures and prediction from demonstrations

Chang and Mehta's *Dual Filter*, v2 dated 13 March 2026, studies known finite HMM parameters and a model-specific filter/next-observation prediction target. Proposition 16 identifies the true filter as a fixed point of its transformer-like construction. Although contraction analysis for iteration remains future work, v2 also gives a single-shot algorithm with T sequential backward passes; describing it as only an unproved iteration would be inaccurate. The authors explicitly develop an analogous architecture rather than an exact model of an ordinary Transformer. It does not provide the current bounded-norm Boolean/rational compilation or strict-k/endpoint-rho statistical theorem. [Version-specific primary source, sections 3–4 and 6](https://arxiv.org/html/2505.00818v2).

Hao, Ye, Han, and Zhang's *Transformers as Multi-task Learners*, v1, proves a conditional-prediction approximation using n independent demonstration sequences under low-rank, observability, feature-linearity, and positive design-eigenvalue assumptions. Mixtures of HMMs are an experimental setup, not an explicit Bayes-over-task-mixtures statement of its main theorem. Its construction permits softmax or ReLU attention; appendix D.1 uses an infinite positional-score limit for exact copying and includes future-token gathering. Those assumptions and the demonstration input differ from one corrupted dependent trajectory and the current causal zero-score interface. It provides neither the current channel model nor finite-bit compilation. [Primary source, assumptions 1–3, theorem 1 and appendix D.1](https://arxiv.org/html/2506.01919v1).

### 4.4 Bounded rational stacks and Transformer universality

Siegelmann and Sontag's *On the Computational Power of Neural Nets* (1995), sections 3.1–3.4, represents stacks in bounded rational coordinates with base-four separated digits, affine push/pop, and saturated-linear digit extraction. Their fixed-size recurrent simulation is a direct antecedent of packing many bits into a bounded scalar. The candidate uses digits 0/1 with a public stack length, ReLU formulas, and a finite unrolled schedule. Its explicit O(G)-bit charge is essential: a bounded scalar is not a constant-bit register. This supports a resource-accounted specialization, not priority for neural stack encoding. [Author-hosted primary paper](https://binds.cs.umass.edu/papers/1995_Siegelmann_JComSysSci.pdf); [second author copy](https://www.sontaglab.org/FTPDIR/siegelmann_sontag_jcss1995.pdf).

Pérez, Barceló, and Marinkovic's *Attention is Turing Complete* (2021) uses hard attention, arbitrary rational precision, generated computation positions, and positional values including an unbounded index. These are not the current bounded raw-token interface. Nevertheless, the proof of Lemma 9 explicitly sets both query and key maps to zero and obtains uniform averaging. Zero-score averaging itself is therefore not a new mechanism; the candidate's distinguishing step is the complete bounded-resource input recovery and subsequent compiled computation. [Primary JMLR paper, Lemma 9 and its proof](https://jmlr.org/papers/volume22/20-302/20-302.pdf).

Bhattamishra, Patel, and Goyal (2020) also simulate recurrent computation with Transformer feedforward updates, using positional information or directional masking. Their universality constructions use hardmax attention and autoregressive continuous states with arbitrary rational precision. They reinforce that circuit/recurrent simulation is established, while leaving the present raw-input, exact resource accounting and statistical composition to prove separately. [Primary CoNLL paper, theorems 4.1–4.2](https://aclanthology.org/2020.conll-1.37.pdf).

### 4.5 Recent softmax universality is not uniformly hard-attention prior art

Jiang, Hahn, Zetzsche, and Lin's *Softmax Transformers are Turing-Complete* appears at ICLR 2026. Its chain-of-thought construction proceeds through counting RASP, with distinctions between unary/letter-bounded and arbitrary languages; the latter require an extension with relative positions. Its formal Transformer realization permits Heaviside operations and logarithmic attention-score scaling. Generated computation tokens and those primitives differ from the candidate's fixed N+1 rows, zero scores, ReLU-only blocks, and paid growing depth/precision. It nevertheless rules out positioning softmax universality itself as new. [Version-specific paper, including appendix A.1](https://arxiv.org/html/2511.20038v1); [official proceedings](https://proceedings.iclr.cc/paper_files/paper/2026/hash/48c218b01802a712ee8d7243d27fd9cf-Abstract-Conference.html).

Brösamle and Eckstein, ICML 2026, *The Expressive Power of Low Precision Softmax Transformers with (Summarized) Chain-of-Thought*, analyze rounding of activations and attention weights. Their softmax conversion uses separated scores and a context-dependent scale, with logarithmically growing architectural resources and generated CoT/SCoT tokens. This is a stronger numerical-precision comparison than older arbitrary-precision universality alone. It differs from zero-score fixed-row compilation and supplies rounding guarantees that the candidate does not claim. The candidate must not advertise itself as the first finite-/low-precision softmax computation result. [Primary paper, section 4 and theorem 4.2](https://arxiv.org/html/2605.18079v1); [official proceedings](https://proceedings.mlr.press/v306/brosamle26a.html).

### 4.6 Arithmetic circuits and fixed-depth limitations

Hesse, Allender, and Barrington prove DLOGTIME-uniform constant-depth threshold-circuit results for integer division and iterated multiplication. Their unbounded-fan-in threshold gates are not bounded-norm serial ReLU blocks. This stronger parallel arithmetic result is not a constant-depth realization in the candidate's model, but elementary finite Boolean arithmetic and division are established ingredients. The 2014 corrigendum retracts parts 1 and 3 of Corollary 6.6 concerning bounded arithmetic, not the main division-in-uniform-TC0 theorem. [2002 primary paper](https://people.cs.rutgers.edu/~allender/papers/division.pdf); [corrigendum](https://people.cs.rutgers.edu/~allender/papers/hab.corrigendum.pdf).

Merrill and Sabharwal's *The Parallelism Tradeoff* (2023) places fixed-depth, log-precision Transformers in uniform threshold-circuit classes. The fixed-depth quantifier is crucial. Its section 7 also constructs Transformers evaluating serialized threshold-circuit inputs using saturated attention and thresholded pooling, an explicit circuit-to-Transformer precedent. The candidate instead compiles the circuit into weights and permits growing depth; its stack realization additionally pays linear-in-G scalar precision. These regimes cannot be interchanged to infer either an impossibility or a constant-depth advantage. [Primary TACL paper, definitions 11–12, theorem 2, and lemma 3](https://aclanthology.org/2023.tacl-1.31.pdf).

Hahn's fixed-soft-attention sensitivity result bounds the effect of changing one input symbol by O(1/n), with constants depending on the fixed network. A family whose depth grows with input length can amplify small differences through many bounded local maps. Thus this result does not contradict the candidate's repeated clipped-doubling construction, and bounded local matrix norms alone do not restore the fixed-network hypothesis. [Primary TACL paper, section 6 and lemma 5](https://aclanthology.org/2020.tacl-1.11.pdf).

## 5. Statistical composition: what is inherited and what is implemented

The log-free composition implements the complete majority/fitted-posterior/saturated estimator. The rate is not proved merely by implementing its fitted-posterior branch. Saturation and majority selection are exact finite integer tests, including the cube comparison, so there is no free cube-root oracle. A certified dyadic minorization lower bound determines explicit constants; their large numerical values are stored as circuit bits rather than large network coefficients.

The sharp-rho candidate adds the protected lower-envelope row estimator and scalar clipping around the empirical marginal. It represents the clip exactly using integer numerators over a common denominator. The beta precision p matters even when ceil(log2(1/beta)) is small; beta near one can still require many bits. The rho precision q is also charged. A compact encoding of a huge exponent does not erase the rational storage cost.

Future blindness gives

    p_(theta,C)(Z) = E[theta_(S(X))(1) | Z].

For any Z-measurable q, conditional Jensen gives

    E|q(Z)-p_(theta,C)(Z)|
      <= E|q(Z)-theta_(S(X))(1)|.

This transfers an upper bound only. It does not transfer a latent-terminal lower bound to the posterior target. The auxiliary repaired channel in the protected-to-endpoint proof can be offline because it is a comparison device inside an upper theorem valid over the broader class. The implemented predictor does not execute that repair or observe the clean word.

The final choice between the clipped protected estimator and the full log-free estimator uses only public M,k,beta,rho, not Z, theta, the seed, or observed loss. Exact dyadic upper approximations to the two rate scales suffice. This is deterministic public selection, not data-dependent model selection with an unproved risk guarantee. The selected exact estimator is then approximated once, adding one 2^-r error term.

For fixed beta and k>=1 the implemented upper profile is

    E|Q_r(Z)-p_(theta,C)(Z)|
      <= min{1, C_beta [M^-1/2 + k/M
                 + min{rho,(k²/M)^(1/3)}] + 2^-r}.

The claimed quantifier is: for each admissible disclosed channel and finite public inputs, compile a predictor independently of the unknown theta, with the risk bound uniform over the allowed sources. The deterministic approximation is to the selected fitted/count-based estimator. It is not an existential network selected after learning the unknown source.

At k=0 the channel is identity on every realization, and the clean estimator supplies the M^-1/2 upper without an endpoint term. Constants are explicit but extremely loose; no uniform sharp moving-beta dependence is claimed. Replacing an unavailable exact rho by a certified dyadic upper bound rho_bar changes the guarantee to rho_bar, or requires paying the excess rho_bar-rho.

For the sharp composition, B_int adds the beta/rho certificate precision to the base/full-estimator budgets. With G_int=O((R+N+1)B_int²), the growing-bank and constant-width resource forms in section 3 persist. This is an explicit implementation of an expected-risk upper. Uniform deterministic approximation of the chosen estimator does not turn the statistical guarantee into a conditional-on-every-word guarantee for the unknown true posterior.

## 6. Scope of the defensible contribution

A suitable statement is:

> For an explicitly disclosed normalized rational online finite-state channel with paid description and bit complexity, the specified robust stationary binary posterior predictor admits a raw-token, causal, zero-score softmax/ReLU realization with uniformly bounded local norms. Two constructions trade width against depth and exact scalar precision. Composing their deterministic approximation with the statistical theorem yields its sharp-rho upper profile on this implementable channel subclass.

This wording does not certify priority. The combination still needs proof review at its exact architecture and computational interface; locating no identical theorem among these sources is not evidence that none exists.

Claims to avoid:

1. A first Transformer simulation of finite-state/HMM/weighted computation, first zero-score averaging construction, first bounded neural stack, or first Boolean-circuit/arithmetic realization.
2. A practical fixed-precision numerical algorithm solely from the exact-rational bit bound, or constant memory solely from d=64.
3. An efficient inference theorem for every disclosed offline channel, a free likelihood oracle, or a free compact-program evaluation.
4. A fixed network generalizing to every length, a tied-depth architecture, or a training/learnability guarantee.
5. A matching online finite-state minimax lower obtained simply by importing the offline normalization witnesses. The ordinary clean lower is available through the identity channel; the additional corruption terms still require restricted-class lower witnesses.
6. A rate for a parameter-mixture posterior, actual-terminal latent loss, arbitrary initial law, or source-averaged endpoint constraint without a separate argument.

The best next theoretical question is the restricted lower-bound class: can a common normalized online finite-state mechanism, with its states and description paid, realize an appropriate posterior-separation witness? Until that is established, the statistical adjective “sharp” describes the inherited broad-class upper profile, not a proved sharp rate for the implemented subclass.

## 7. Reviewed artifacts and evidence boundary

The three requested candidates and the finite-state/sharp-rho independent reviews were read. The computational-interface audit and earlier source audits were consulted to preserve their model distinctions. The full-log-free composition was consulted for its stated result and concrete estimator/branch interface; this source audit does not freshly reprove that statistical argument or every gate invariant.

Snapshot SHA-256 values:

- `KNOWN_CHANNEL_finite_state_transformer_bridge.candidate.v1.md`: `ce04cc928c88ca3edb2849d69c5207126edda5841140517636f2a17338a7b15a`
- `KNOWN_CHANNEL_finite_state_constant_width_bridge.addendum.v1.md`: `8ba86c1d06255f7858640483b4078a9e0856f4adf317c1f6a24607d404eeb7d0`
- `KNOWN_CHANNEL_sharp_rho_transformer_composition.candidate.v1.md`: `572f4a4d36f3afe4f23d8b4f1830031e8aa1a58ef80e9b2661c6586f20492c0a`
- `KNOWN_CHANNEL_finite_state_bridge.independent_review.v1.md`: `2572bbdfcecaed72385087a1b4c0d58fc700762fe70e743fa5a8b18ac3821634`
- `KNOWN_CHANNEL_sharp_rho_transformer_composition.independent_review.v1.md`: `70503ef0754602860d3aad13c607133d54dfbfe4b8348cc7e51ddc369224680c`
- `KNOWN_CHANNEL_full_logfree_transformer_composition.candidate.v1.md`: `616be470e1fae470cef701614ec4a9837be67736cf2317fb052bcaa91123e621`

Primary paper URLs and relevant theorem/section locations are attached directly to each comparison. Recent sources were checked against versioned manuscripts and, where available, official 2026 proceedings. Source reading establishes the cited model comparisons, not universal absence of earlier work. The local output is a research artifact only; no executable scientific validation or public repository action was undertaken.
