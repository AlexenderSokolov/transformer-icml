# Independent audit of the positive-floor rho upper

Date: 2026-11-05 UTC.

## Verdict and binding

The theorem and proof in `KNOWN_CHANNEL_positive_floor_rho_upper.candidate.v1.md` are mathematically sound under their stated assumptions. No substantive correction or counterexample was found. This independent audit was conducted without developing the candidate proof.

The full frozen candidate was reread at approximately 09:20:47 UTC after the two precision edits below were incorporated. This verdict binds to that final mathematical read of the named candidate, particularly theorem (2), Sections 2–7, and equations (3)–(16). Apart from those clarifications, no theorem or proof change was observed in the reread. An earlier inspection hash is deliberately omitted because it would not identify the final prose revision.

The full candidate and the older `KNOWN_CHANNEL_uniform_positive_floor_upper.md` and its independent review were read. Tools were used only for document inspection, hashing, and writing this review. No scientific executable checks, numerical experiments, or public writes were performed. This is an analytical audit, not formal verification or external peer review.

## Main checks

1. **Global clean-word control.** Each token changes at most two context observations and three triple observations. Equation (6) follows from the count differences and smoothing bias at most one. The low-count branch in Section 3 genuinely controls every corrupted word, not just a high-probability event. Binary clipping contracts distance to the true row. Initial-law L1 projection gives the stated factor two, so both inequalities (5) hold pathwise for every allowed pair `(x,z)`.

2. **Concentration and filtrations.** The two-step minorization gives `Pi(u)>=eta^2` and the stated contraction. For the occupation Doob martingale, revealing `Y_0,...,Y_i` gives exactly the increment `g_i(Y_i)-P g_i(Y_(i-1))`; the first increment is centered separately. The oscillation sum is at most `2/gamma`. There are M increments, yielding (8). The transition residual is a different martingale: use the raw-symbol filtration through `X_(i+2)` before its ith increment and reveal `X_(i+3)` afterward. Conditional mean zero and absolute increment at most one give (9). No conditioning on an occupation event or channel choice is used. The union bound and split at t/2 give precisely the admissible constant `c_eta=gamma^2/32` in (7).

3. **Exponential moment.** The Gaussian tail of `V=sqrt(M)(W-1/M)` uniformly bounds every fixed exponential-linear moment used in Section 4. For `1<=k<=sqrt(M)`, `(k+1)/sqrt(M)<=2` and the deterministic exponent `(k+1)k/M` is bounded and is also at most `2k/sqrt(M)`. Thus (10) follows with a finite constant depending only on eta and the fixed exponent coefficient. No claim uniform in vanishing eta is possible or made.

4. **Data-dependent posterior fits.** Fixing z freezes both fitted parameters. The surrogate is a normalized positive clean-word law even though its initial law need not be stationary for its transition table. True and fitted transition-coordinate log errors are bounded by `2 epsilon/eta`, and initial-coordinate log errors by `2 Delta/omega`. Two preimages are at distance at most 2k, so at most 6k triples differ. This establishes (12), with the shared channel cancelling exactly.

5. **Normalized localization.** If `r=P_hat_z/P_theta` on the preimage, then the actual posterior density is `h=r/E_nu r`. Log oscillation at most L implies `exp(-L)<=h<=exp(L)`. Crucially `E_nu(h-1)=0`. Subtracting the true displayed-terminal-row value makes the integrand vanish outside `A_z`, and `|h-1|<=exp(L)-1`. Therefore (13) is valid even if the fitted posterior greatly increases the endpoint-change mass. Replacing this exponential by a uniformly capped linear factor would not be justified; the candidate correctly does not do so.

6. **Per-word rho versus a marginal rho.** Equation (14) applies to every valid output of each clean word, including outputs selected adaptively from that word's fluctuations. Consequently conditioning on the clean word bounds the weighted endpoint term by the envelope times `P_C(A|X)`. The per-word bound supplies the factor rho in (15). No independence of edits and clean statistics, posterior endpoint estimate, or hidden source-dependent channel comparison is used. Merely bounding the unconditional probability of A would not prove this step.

7. **Boundary regimes.** The small-budget argument yields the endpoint term `rho k/sqrt(M)`; the displayed-row estimator gives `rho` for `k>sqrt(M)`. Equality at the threshold is covered by the former branch. At k=0 the channel is identity on its support and the endpoint event is empty, exactly as claimed. At rho=0 the endpoint term vanishes in either branch. The maximal budget k=M and rho=1 are covered by the unit loss cap. The case eta=1/2 is valid, including its degenerate fully specified transition rows. The estimator uses M, k, eta and the disclosed kernel, not rho or the unknown source.

## Precision edits incorporated in the final candidate

- Equation (3) now explicitly assigns value one to an exponent-zero expression for both h=0 and h=1, including gamma=1. This resolves the `0^0` typography ambiguity.
- Section 5 now explicitly restricts posterior normalization to nonempty channel preimages and defines the predictor arbitrarily on impossible outputs. Every possible output has positive true and surrogate posterior normalizers.

Both edits are correct and fully incorporated. No outstanding correction is required.

The resulting upper is information-theoretic and restricted to stationary sources with a fixed public positive floor and the stated per-word channel certificate. This audit does not certify optimality, matching lower bounds, computational efficiency, architectural implementation, or an extension based only on marginal endpoint reliability.
