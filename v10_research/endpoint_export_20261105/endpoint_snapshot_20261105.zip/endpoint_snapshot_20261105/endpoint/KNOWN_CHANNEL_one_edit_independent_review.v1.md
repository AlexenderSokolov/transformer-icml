# Independent review: one-edit known-channel lower bounds

**Analytical PASS.** No unresolved mathematical blocker was found in the exact statement reviewed below.

Present-time full-text read and SHA-256 capture: **2026-11-05T03:16:35Z**.

Reviewed source: `KNOWN_CHANNEL_one_edit_lower.md`.

SHA-256: `aaf8583176b36fcbd4c0f379f75832f8b7fc98f9a83ca033b778c058703cffa0`.

This binds the current text actually reread, not an earlier historical hash. The source was preserved unchanged by this reviewer. Work consisted of analytical reasoning, file reading, hashing, and review writing. No scientific executable check, numerical experiment, simulation, test suite, or public write was performed.

## 1. Results covered by this review

For beta,rho in [0,1], M>=64, N=M+2, and any positive edit upper budget k>=1, the reviewed note establishes:

- Stationary K>=4 sources: one known channel gives predictive minimax TV loss at least rho(1-beta)/64.
- Strictly positive four-symbol stationary sources: the same channel gives a lower rho(1-beta)/128 with both source tables fully supported when K=4.
- Binary arbitrary initial-pair laws: a known channel and a fully known transition table give lower rho(1-beta)/8 when the initial law remains unknown.

All three are specific-channel existential lower bounds. The full observation laws are not asserted identical; the proof correctly uses their overlap. None is a lower for every known channel, a stationary binary theorem, a fixed-positive-transition-floor extension, a causal-only channel theorem, or a claim about revealing the realized mask or seed.

The target is the next-symbol conditional law for each FIXED true source, initial law, and channel. The future is generated from the original terminal state and the channel seed is independent of future innovations. The known object is the channel algorithm, not its realized hidden branch. A prior over source hypotheses is only a proof device.

## 2. Common posterior-overlap calculation

Given the retained V prefix with last bit b, let B be the original terminal V bit and r=1/2+alpha(2b-1), alpha in [0,1/4]. Before observing W, let A be an independent flip bit with source-dependent probability t_i, and W=B xor A.

Then

    l_i(1)=r+(1-2r)t_i,  l_i(0)=1-l_i(1),
    P_i(B=1|W=1)=r(1-t_i)/l_i(1),
    P_i(B=1|W=0)=rt_i/l_i(0).

The predictive NEXT V mean is 1/2-alpha+2alpha P_i(B=1|W). Direct subtraction, with d=|t_0-t_1|, gives

    |a_0(w)-a_1(w)|
      =2alpha r(1-r)d/[l_0(w)l_1(w)].

Every l_i(w) lies in [1/2-alpha,1/2+alpha], so the denominators are positive. Weighting by the smaller terminal observation probability and summing over w yields

    sum_w min(l_0(w),l_1(w)) |a_0(w)-a_1(w)|
      >=2alpha(1-2alpha)d.

For arbitrary, independently randomized predictors,

    Risk_0+Risk_1
      >= integral min(dP_0^Z,dP_1^Z) TV(p_0(Z),p_1(Z)).

Dividing by two gives the maximum-risk lower. This argument accounts for the complete observation measures. It does not require identical measures, nor a false claim that the flip probability remains t_i after conditioning on the displayed terminal bit W. That latter conditioning is explicitly handled by Bayes' formula above.

## 3. Stationary source construction and all-state certificate

The four symbols are pairs (U,V). U is IID Bernoulli(p_i), independently of the complete stationary symmetric V chain. Their product is a homogeneous first-order finite-state chain, hence belongs to the declared order-two family through theta_(a,b)=T_i(b,.). Initializing at Pi_i(c,d)=pi_i(c)T_i(c,d) gives the correct stationary PAIR law.

For the generated symbols, T_i((u,v),(u',v'))=nu_i(u')Q(v,v'), with pi_i(u',v')=nu_i(u')/2. Since the least V transition is (1-2alpha)/2,

    T_i(b,c)>=(1-2alpha)pi_i(c)

for every supported c. Unused starting symbols reset to pi_i, so this inequality holds on all starting symbols, including those outside stationary support. It follows that

    P_i^2((a,b),(c,d))
      =T_i(b,c)T_i(c,d)>=(1-2alpha)Pi_i(c,d)>=beta Pi_i(c,d).

Zero-mass destinations are harmless. The argument remains valid at p_0=0, even though that source uses only two of the four designated symbols. The source tables differ by exactly 1/M in maximum-row TV when p_0=0 and p_1=1/M.

## 4. The one-edit channel is legal on every word

The nuisance count uses positions 1,...,N-2, a block of exactly M symbols excluding BOTH members of the terminal pair. The branches are mutually exclusive:

- Count zero: optionally flip the final V bit, with probability rho.
- Count one: erase the unique interior U=1 while preserving its V coordinate.
- Larger count: identity.

Words containing undesignated symbols are also mapped to themselves. The first branch changes at most one terminal token. The second changes exactly one strictly interior token and never reaches the terminal pair. No realization combines these two operations. Thus the budget is deterministically at most one edit and endpoint-change probability is at most rho for every input word.

The channel uses only the observed input and public rho/horizon, not p_i, beta, alpha, a stationary law, an initial-law index, or the future. In particular, the deterministic interior erasure may occur when rho=0: rho bounds ENDPOINT corruption, not the chance of any corruption. The final note makes this distinction explicit.

## 5. Hidden count, all-zero observation event, and exact overlap

Let E be the observed event that the nuisance U block is all zero. It arises exactly from original count zero or one. With p_0=0, source 0 has E probability one and flip rate t_0=rho. With p_1=p=1/M,

    w0=(1-p)^M,
    w1=Mp(1-p)^(M-1)=(1-p)^(M-1),
    g=P_1(E)=w0+w1,
    t_1=rho w0/g,
    d=rho w1/g.

The S=1 branch never flips the terminal V bit. This is why conditioning on E produces the source-dependent rates above despite one identical, fully known channel algorithm.

No hidden information is discarded from the lower proof. On E, all displayed interior U coordinates are deterministic zeros. The complete retained V prefix is common under both sources and independent of the U count and channel randomness. Its last bit gives the stated conditional probability r for the original terminal V bit. The erased U position leaves no V trace because the channel preserves every V coordinate in that branch and U is independent of the entire V process.

There are TWO retained outside U coordinates, U_(N-1) and U_N. Restricting them both to zero costs the common mass (1-p)^2. They are independent of the interior block, V process, and branch, so they do not change t_i. On this common observation portion, the smaller density is bounded by g(1-p)^2 times the common prefix density and min(l_0,l_1), because g(1-p)^2<=1.

The overlap calculation therefore gives

    max_i Risk_i >= g(1-p)^2 alpha(1-2alpha)d
                  =rho(1-1/M)^(M+1)alpha(1-2alpha).

The count-event probability g cancels only after it has been included in the observation overlap. It would be wrong to use conditional target separation without this event weight or to forget either retained outside U bit.

For M>=2, (1-1/M)^M>=1/4 and 1-1/M>=1/2. One analytic verification of the first inequality is that x log(1-1/x) is increasing for x>1: its derivative is u-log(1+u)>=0 with u=1/(x-1). The value at x=2 is log(1/4). Together with alpha>=(1-beta)/4 and 1-2alpha>=1/2, this proves rho(1-beta)/64.

## 6. Strictly positive four-symbol variant

Taking p_0=1/(2M), p_1=1/M leaves the same channel unchanged and makes all four-symbol transitions positive. Conditional on E,

    g(p)=(1-p)^(M-1)[1+(M-1)p],
    t(p)=rho(1-p)/[1+(M-1)p].

Exact subtraction gives

    t(p_0)-t(p_1)
      =rho M(p_1-p_0)/([1+(M-1)p_0][1+(M-1)p_1])
      >=rho/6.

The event S<=1 decreases as p increases, so min_i g(p_i)=g(p_1)>=2(1-1/M)^M>=1/2. The common mass with both outside U bits zero is at least (1-1/M)^2>=3/4 for M>=64. Combining these factors with alpha(1-2alpha)>=(1-beta)/8 gives exactly rho(1-beta)/128.

This is a full-support K=4 statement, but not a uniform positive transition-floor statement: some probabilities vanish as M grows. For K>4 the indicated simple embedding retains zero-mass unused symbols. The two tables in this positive variant differ by 1/(2M), not by a fixed separation.

## 7. Binary arbitrary-start construction

The source table theta_(a,b)=T(b,.) is homogeneous order two and satisfies the all-state certificate via the same symmetric-kernel calculation. The two initial PAIR laws fix X_1 to 0 or 1 while making X_2 uniform. Such initialization is permitted in the arbitrary-start experiment. It must not be interpreted as applying T to generate X_2 from X_1; specified source transitions begin at X_3.

Thus X_2,...,X_N have a common stationary first-order law, while the initial bit differs. The known channel either flips the terminal bit with probability rho when X_1=0, or overwrites X_1 with 0 when X_1=1. These operations are alternatives, not a composition. Since N>=3, the first position is outside the terminal pair. Every word suffers at most one edit and endpoint probability at most rho.

The displayed first bit is always zero. The remaining retained prefix has a common law. Conditional on that prefix, flip rates are t_0=rho and t_1=0, with no rare-event or additional-coordinate overlap loss. The common posterior calculation gives

    max_i Risk_i >=rho alpha(1-2alpha)>=rho(1-beta)/8.

The transition table and channel may both be fully known; the initial law remains unknown. This does not contradict zero distribution-estimation loss when theta,mu,C are all known. It is not a stationary binary lower.

## Disposition

The exact source file bound above receives analytical PASS for all three stated constructions, with correct endpoint-only probability interpretation, all-word edit budget, source class, hidden-count posterior conditioning, and constants. The boundaries rho=0 and beta=1 cause no singularity: the claimed endpoint lower is simply zero. Positive edit permission k>=1 remains essential.

No external novelty, formal verification, neural realization, finite sampling-cost theorem, stationary K=2 or K=3 result, fixed-positive-transition-floor extension, or mask/seed-disclosure equivalence is certified here.
