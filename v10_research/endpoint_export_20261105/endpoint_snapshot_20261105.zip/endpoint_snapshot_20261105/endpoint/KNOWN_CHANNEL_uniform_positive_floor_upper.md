# Known-channel posterior prediction with a uniform positive transition floor

Date: 2026-11-05 UTC. Mathematical analysis only. No scientific executable checks, public write, external novelty claim, sharp minimax rate, or computational-efficiency claim.

## Result

Fix a finite alphabet K>=2 and a supplied public floor 0<eta<=1/K. Consider stationary homogeneous second-order sources whose EVERY successor probability satisfies

    theta_u(c)>=eta for all pair rows u and symbols c.

For every disclosed, source-independent, future-blind observation channel C with strict raw Hamming budget k, a statistical predictor satisfies

    E TV(q_C(Z),P_(theta,C)(X_(N+1) in . | Z))
       <=min{1,C_(K,eta)(k+1)/sqrt(M)}.                  (U1)

Here M>=64, N=M+2 and 0<=k<=M. The constant is finite for fixed K,eta; explicit non-asymptotic quantities are given below. No endpoint-reliability restriction is needed, so the result holds for all rho including rho=1.

Thus a fixed positive floor prevents a constant one-edit posterior-prediction obstruction in EVERY finite alphabet, and k=o(sqrt(M)) suffices for uniform consistency. This is a sufficient regime, not a necessary corruption threshold or a sharp rate.

The theorem requires stationarity. Unknown arbitrary initial pair laws permit the earlier binary one-edit lower even when the transition table is known and uniformly positive.

## 1. A more general quantitative interface

Let the pair state space have K^2 states, transition

    P((a,b),(b,c))=theta_(a,b)(c),

and stationary pair law Pi. Assume the following supplied lower bounds:

    theta_u(c)>=eta>0,
    Pi(u)>=omega>0,
    Dobrushin(P^2)<=1-gamma, 0<gamma<=1.                (U2)

The last line means that applying the TWO-STEP pair kernel contracts TV by at least the factor 1-gamma. One-step pair transitions have structural zeros and are not asserted strictly positive. The supplied public floors obey 0<eta<=1/K and 0<omega<=1/K^2. The coefficient gamma is needed for the risk analysis, not as an estimator input.

For every known strict-k-edit channel, define

    B_row=2K^2[ sqrt(K)/sqrt(M omega)
                    +(2K+6k+20/gamma)/(M omega) ],
    B_init=K sqrt(5/(gamma M))+4k/M.

There is a predictor with the explicit uniform bound

    Risk<=min{1,
       (1+24k/eta) B_row + 4 B_init/omega}.             (U3)

The estimator may use eta,omega and C; gamma is used to certify the risk. Its fitted initial law is estimated separately and need not be stationary for its fitted transition table. This is an allowed statistical estimator, not a claim that the surrogate lies in the true model class.

## 2. Transition positivity supplies the interface without an extra mixing assumption

For every starting pair (a,b) and target pair (c,d),

    P^2((a,b),(c,d))=theta_(a,b)(c)theta_(b,c)(d)>=eta^2.

Thus P^2 dominates gamma times the uniform law on the K^2 pair states with

    gamma=K^2 eta^2.

It follows that its Dobrushin coefficient is at most 1-gamma. Stationarity gives

    Pi(c,d)=sum_s Pi(s)P^2(s,(c,d))>=eta^2.

Therefore a uniform transition floor alone supplies

    omega=eta^2, gamma=K^2 eta^2.                      (U4)

Inserting (U4) into (U3) is one fully explicit choice of the constant dependence in (U1). In particular,

    B_row=2K^2[ sqrt(K)/(eta sqrt(M))
         +(2K+6k+20/(K^2 eta^2))/(eta^2 M) ],
    B_init=sqrt(5)/(eta sqrt(M))+4k/M.                  (U5)

Before taking the unit cap, these formulas give

    Risk<=C_(K,eta)[(k+1)/sqrt(M)+k(k+1)/M].            (U6)

Let g=(k+1)/sqrt(M). The quadratic term is at most g^2. If g<=1, g+g^2<=2g; if g>1, the risk is at most one. This proves (U1) after enlarging its constant. No assertion uniform in growing K or vanishing eta is made by the O_(K,eta) notation; use (U3)-(U5) for those questions.

## 3. Estimate every transition row from the corrupted word

Let J_u count occurrences of context u among the M historical pairs ending at times 2,...,N-1. For the clean stationary source,

    E J_u=M Pi(u).

For the indicator of a named pair u, lag-h covariance is

    Pi(u)[P^h(u,u)-Pi(u)].

Contraction in (U2) implies

    TV(P^h(s,.),Pi)<=(1-gamma)^floor(h/2).

Summing the resulting geometric series in the variance gives

    Var(J_u)<=5M Pi(u)/gamma,
    P{J_u<M Pi(u)/2}<=20/[gamma M Pi(u)].               (U7)

Let C_u be the K-dimensional clean successor-count vector and

    Z_u=C_u-J_u theta_u.

It is a sum of predictable-row vector martingale differences. Orthogonality and the one-step conditional second moment give

    E||Z_u||_2^2<=M Pi(u),
    E||Z_u||_1<=sqrt(K M Pi(u)).                       (U8)

The clean add-one row q_u=(C_u+1)/(J_u+K) satisfies

    TV(q_u,theta_u)
       <=(||Z_u||_1/2+K)/(J_u+K).

On J_u>=M Pi(u)/2, this contributes in expectation at most

    sqrt(K)/sqrt(M Pi(u))+2K/[M Pi(u)].

For the observed-word add-one row q'_u, the deterministic shared-count comparison gives

    TV(q'_u,q_u)<=3k/(J_u+K).

On the good-count event this adds at most 6k/[M Pi(u)]. On its complement the entire row loss is at most one; charge (U7) once. Therefore

    E TV(q'_u,theta_u)
       <=sqrt(K)/sqrt(M Pi(u))
                    +(2K+6k+20/gamma)/[M Pi(u)].       (U9)

Project q'_u in L1 distance onto the probability simplex having every coordinate at least eta/2. Use deterministic tie-breaking. This simplex is nonempty, and the true row is feasible. Projection optimality and the triangle inequality imply

    TV(theta_hat_u,theta_u)<=2TV(q'_u,theta_u).

Summing the K^2 row bounds and using Pi(u)>=omega yields

    E epsilon<=B_row,
    epsilon=max_u TV(theta_hat_u,theta_u).              (U10)

All martingale and occupation statements concern the unconditional clean source. Corruption is handled pathwise; no independence of row observations, channel choices or edit locations is assumed.

## 4. Estimate the initial pair law separately

Let J'_u be the observed context counts and define Pi_raw(u)=J'_u/M. This is a probability vector. Each changed token affects at most two of these context pairs, hence

    TV(Pi_raw,Pi_clean_empirical)<=2k/M.

From (U7), Cauchy-Schwarz and sum_u sqrt(Pi(u))<=K,

    E TV(Pi_raw,Pi)
       <=(K/2)sqrt(5/(gamma M))+2k/M.

Project Pi_raw in L1 distance onto the K^2-dimensional probability simplex with every coordinate at least omega/2, using deterministic tie-breaking. The true Pi is feasible. Its resulting estimate Pi_hat obeys

    Delta:=TV(Pi_hat,Pi)<=2TV(Pi_raw,Pi),
    E Delta<=B_init.                                  (U11)

Pi_hat is not required to be stationary for theta_hat. The surrogate law initialized by Pi_hat and transitioned by theta_hat is nevertheless a positive probability law on clean words.

## 5. Likelihood ratios on a Hamming preimage set

For each fixed displayed word z, form the surrogate clean-word probabilities

    P_hat(x)=Pi_hat(x_1,x_2)
                 product_(t=3)^N theta_hat_(x_(t-2),x_(t-1))(x_t),

using its data-dependent fitted parameters. Combine P_hat(x) with the known C(z|x), normalize over x, and average theta_hat_(S(x)) to obtain q_C(z).

The actual target under the FIXED source is

    p_theta(z)=sum_x P_theta(x | Z=z) theta_(S(x)),

because the channel's seed is independent of future innovations conditional on the clean word. The future is generated from the original state, not the edited display. No prior averaging of unknown source hypotheses is part of this target.

Both true and fitted row coordinates are at least eta/2, and both initial pair masses are at least omega/2. Since a coordinate difference between probability vectors is bounded by their TV distance, the mean-value inequality for log gives

    |log(Pi_hat(s)/Pi(s))|<=2Delta/omega,
    |log(theta_hat_u(c)/theta_u(c))|<=2epsilon/eta.

If C(z|x)>0 and C(z|x')>0, then d_H(x,x')<=2k. At most 6k historical triple positions differ. Consequently the oscillation of log(P_hat(x)/P_theta(x)) over that preimage set is at most

    L=4Delta/omega+24k epsilon/eta.                     (U12)

The same channel factor C(z|x) cancels in posterior likelihood ratios. Normalizing likelihood ratios whose logarithms have oscillation at most L makes each posterior density at least exp(-L) times the other. Their TV distance is therefore at most 1-exp(-L)<=L. The difference in their averaged source rows adds at most epsilon. Thus, pointwise,

    TV(q_C(z),p_theta(z))
       <=(1+24k/eta)epsilon+4Delta/omega.

This comparison permits theta_hat and Pi_hat to depend on z because z is fixed throughout the comparison. Taking expectations and using (U10)-(U11) proves (U3).

The calculation is purely information-theoretic. It may sum over K^N clean words and assumes access to the disclosed kernel values; no efficient algorithm or finite rational implementation of an arbitrary real channel is claimed.

## 6. Stationary-mass alternatives inside D2(beta)

Suppose instead that the source is in the all-state class

    P^2(s,t)>=beta Pi(t), 0<beta<=1.

This supplies gamma=beta. Its common-component consequence is

    theta_u(c)>=beta pi(c).

Two useful alternatives therefore fit (U2):

### Known stationary symbol-mass floor

If pi(c)>=nu>0 for every symbol, then

    eta=beta nu,
    omega=beta nu^2,
    gamma=beta.                                      (U13)

Indeed Pi(a,b)=sum_c Pi(c,a)theta_(c,a)(b)>=beta pi(a)pi(b).

### Known stationary pair-mass floor

If Pi(u)>=omega>0 for every pair, then pi(c)>=K omega, and one can take

    eta=beta K omega,
    gamma=beta,                                      (U14)

with the supplied omega unchanged. Inserting (U13) or (U14) into (U3) gives explicit dependence on the supplied mass and mixing floors.

These deductions require beta>0. A stationary mass floor alone, without the stated positive mixing/common-component condition or a separate row floor, does not supply the transition lower bound needed by this proof. No theorem is asserted for that larger class here.

## 7. Relation to the ternary rare-clone lower

In `KNOWN_CHANNEL_stationary_ternary_one_edit_lower.md`, the rare-clone transition probabilities have the form

    T_p(x,*)=p Q(c(x),0),

with p=1/M or p=1/(2M). Its stationary clone mass is pi_p(*)=p/2. Therefore both a fixed positive transition floor eta and a fixed positive stationary symbol-mass floor nu exclude that sequence; a fixed pair-mass floor excludes it as well.

The distinction is stronger than merely noting that a particular witness is excluded. The uniform upper (U1) proves that no disclosed future-blind one-edit channel has a constant stationary posterior-prediction floor anywhere in the fixed-K, fixed-eta class as M grows. It still permits ordinary statistical error. The rare-clone lower remains valid in the larger D2(beta) class and in the class with only strict positivity, because those allow probabilities to approach zero with M.

## Scope

- Endpoint edits may be unrestricted: no rho factor is needed for this upper.
- The kernel C is known, but its realized seed, branch and edit mask are hidden.
- Stationary initialization is essential to the estimates and initial-law fitting. The unknown arbitrary-start binary counterexample is not contradicted.
- Fixed K and fixed positive eta, or fixed positive parameters in (U13)-(U14), give the consistency conclusion. The explicit bound is available for examining varying parameters, but no sharp varying-parameter claim is made.
- k=o(sqrt(M)) is sufficient, not asserted necessary. A matching lower or optimal k-dependence is not established.

## Dependencies

- `KNOWN_CHANNEL_stationary_binary_upper.v2.md`: empirical initial-law fitting and preimage likelihood-ratio proof pattern.
- `EDIT_OVERLAP_and_TARGET_BOUNDARIES.md`: deterministic same-row add-one comparison.
- `EPR001_endpoint_probability_interpolation.md`: all-state D2(beta) and observation-channel conventions.
- `KNOWN_CHANNEL_stationary_ternary_one_edit_lower.md`: exact rare-clone sequence and its probability-floor limitation.
