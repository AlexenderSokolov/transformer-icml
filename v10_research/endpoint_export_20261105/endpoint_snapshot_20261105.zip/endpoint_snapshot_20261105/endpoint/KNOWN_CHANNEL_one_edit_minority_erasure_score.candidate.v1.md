# A complete-score bound when nonterminal edits only erase the minority

5 November 2026 UTC. Pure analytical candidate. No scientific execution, numerical diagnostic, public write, or minimax-rate claim. Independent review is pending. The earlier reviewed hazard notes remain unchanged.

## 1. Result and restriction

Let N=M+2 with M>=2. Fix the public symbol labels 0 and 1, and consider the source subclass in which m=pi(1)<=1/2. At an interior stationary binary order-two source theta in this subclass, assume the all-state pair minorization P^2>=beta Pi, for fixed 0<beta<1. Let C be one disclosed source-independent, future-blind, online one-base-state channel with actual counter e in {0,1} and at most one edit on every path.

The additional restriction is

    a_i(0)=0 for every i<=N-2.                           (S1)

Thus all nonterminal edits erase a minority 1. The last two positions may flip either symbol arbitrarily, subject to the strict one-edit budget and any supplied endpoint certificate rho. The channel cannot consult the unknown source marginal: (S1) describes a fixed channel paired with the source subclass in which the erased symbol is a minority.

For the true future minority-row value

    g_theta(X)=theta_(X_(N-1),X_N)(1),

and the complete stationary-source score S_all along any differentiable interior source path through theta, let I_step be the ordinary stationary one-step Fisher information in that direction. Then

    E_theta,C |Cov_theta,C(g_theta,S_all | Z)|
        <= C_beta sqrt(I_step).                         (S2)

Including the direct row derivative gives

    E_theta,C |d p_theta,C(Z)/dt|
        <= C_beta sqrt(I_step),                         (S3)

with the channel held fixed during differentiation. These are source-wise integrated derivative bounds, uniform in the horizon, the arbitrary time hazards, and rho. They are not finite-alternative comparisons under one fixed observation measure, and they do not yet supply a data-dependent fitted minimax estimator.

The genuinely new count bound used below is

    E|Cov(g_theta,T_111 | Z)|
        <= C_beta sqrt(Pr_theta(111)).                   (S4)

This settles the all-minority count coordinate under restriction (S1), while leaving general majority-to-minority insertions unresolved.

The score statements concern interior differentiable paths only. The count-covariance statements separately extend to m=0: the stationary source has g=0 almost surely, so every such covariance is zero. When m>0, D2(beta) gives p_111>=beta^2 m^3>0, and no division by a zero marginal is made. The stipulated M>=2 makes the two terminal training indicators in (S8) well defined; at M=2 the remote sum is empty.

## 2. Dependencies and notation

For each triple abc let

    T_abc(X)=sum_(t=3)^N 1{X_(t-2):X_t=abc},
    p_abc=Pi(ab)theta_ab(c).

The reviewed actual-edit-window bound H8 in `KNOWN_CHANNEL_one_edit_hazard_reduction.research.v1.md` says that for a fixed local window w centered at the actual edit time J,

    Pr{W_J=w, valid window indices}
       <= C_(beta,r) Pr(W=w)/pi(w_center),               (S5)

where r is the number of window positions preceding J. It applies to the actual raw window, not a competing preimage. The proof below uses it only in that valid sense.

For any strict-one-edit channel, two raw preimages of the same displayed word differ in at most two coordinates. Consequently their counts T_abc differ by at most six. Since Eg=m, the independent-posterior-draw identity gives

    E|Cov(g,T_abc|Z)|<=6m.                               (S6)

The minorization gives p_abc>=beta^2 pi(a)pi(b)pi(c). For abc!=111, at least one symbol is a majority, so

    p_abc>=beta^2 m^2/2,
    E|Cov(g,T_abc|Z)|<=(6 sqrt(2)/beta) sqrt(p_abc).       (S7)

These last bounds do not require (S1).

## 3. Monotone remote counts remove the crossed-preimage difficulty

Split

    T_111=T_far+T_end,
    T_far=sum_(t=3)^(N-2) 1{X_(t-2):X_t=111},
    T_end=1{X_(N-3):X_(N-1)=111}
             +1{X_(N-2):X_N=111}.                       (S8)

The empty sum T_far is zero. All coordinates entering T_far lie at or before N-2. By (S1), a change there can only replace a 1 by 0, and terminal edits cannot affect T_far. Therefore, for every actual raw/output pair,

    Delta(X,Z)=T_far(X)-T_far(Z)>=0.                     (S9)

Also Delta<=3. If Delta>0, the actual erased bit belongs to at least one raw 111 triple counted in T_far. Apply (S5) to the three orientations of this triple around J: (r,s)=(0,2),(1,1),(2,0). Each has central raw symbol 1, and each stationary window probability is p_111. A union bound yields

    Pr(Delta>0)<=A_beta p_111/m,
    E Delta<=3 A_beta p_111/m.                          (S10)

There is no posterior-preimage substitution here: the event concerns the actual edit and the actual raw triple. Since T_far(Z) is observed,

    Cov(g,T_far(X)|Z)=Cov(g,Delta|Z).

Both g and E[g|Z] lie in [0,1], so

    E|Cov(g,T_far|Z)|<=2 E Delta
                     <=6 A_beta p_111/m.               (S11)

Independently, the same posterior-draw argument as in (S6) gives

    E|Cov(g,T_far|Z)|<=6m.                              (S12)

Take the smaller of (S11) and (S12). The inequality min(x,y)<=sqrt(xy) gives

    E|Cov(g,T_far|Z)|<=6 sqrt(A_beta p_111).              (S13)

For the two terminal triples, 0<=T_end<=2 and E T_end=2p_111 by stationarity. Thus E T_end^2<=4p_111. Conditional Cauchy-Schwarz and then unconditional Cauchy-Schwarz give

    E|Cov(g,T_end|Z)|
       <=sqrt(E Var(g|Z) E Var(T_end|Z))
       <=2 sqrt(m p_111)<=2 sqrt(p_111).                (S14)

Equations (S13)-(S14) prove (S4). Combining with (S7), there is a common C_beta such that

    E|Cov(g,T_abc|Z)|<=C_beta sqrt(p_abc)

for all eight triple coordinates. The proof preserves endpoint ambiguity; it does not assert that the terminal pair or actual edit time is observed.

## 4. The transition score in an arbitrary source direction

Write theta_u(1)=q_u and let dot ell_u denote the derivative of its log odds along the source path. Put

    I_u=Pi(u)q_u(1-q_u),
    I_step=sum_u I_u (dot ell_u)^2.

The transition contribution to the complete length-N score is

    S_tr=sum_u dot ell_u [(1-q_u)T_(u,1)-q_u T_(u,0)].  (S15)

The count bounds imply

    E|Cov(g,S_tr|Z)|
       <=C_beta sum_u |dot ell_u|
             [(1-q_u)sqrt(Pi(u)q_u)
                          +q_u sqrt(Pi(u)(1-q_u))]
       <=2 C_beta sum_u |dot ell_u| sqrt(I_u)
       <=4 C_beta sqrt(I_step).                        (S16)

The penultimate inequality uses sqrt(q_u)<=1 and sqrt(1-q_u)<=1; the last is Cauchy-Schwarz over four rows. No transition floor is used.

## 5. The stationary initial-pair score is separately controlled

Let v(s)=d log Pi(s)/dt and let P^* be the stationary reversed pair transition operator on L2(Pi). Differentiating stationarity yields

    v=P^*v+r,
    r(s)=sum_t Pi(t) dot P(t,s)/Pi(s).                  (S17)

The function r is the conditional expectation, given the destination pair s, of the one-step transition score. Hence Pi(r)=0 and

    ||r||_(L2(Pi))<=sqrt(I_step).                       (S18)

The reversed pair chain has (P^*)^2>=beta Pi. Write (P^*)^2=beta Pi+(1-beta)Q, where Q preserves Pi. On mean-zero functions, its L2 operator norm is at most 1-beta; every Markov operator preserving Pi is an L2 contraction. Therefore

    ||(P^*)^n||_(mean-zero L2)<= (1-beta)^floor(n/2),
    ||v||_2 <= sum_(n>=0)||(P^*)^n r||_2
             <=(2/beta)sqrt(I_step).                  (S19)

This also justifies the mean-zero resolvent solution in (S17); v has mean zero by differentiation of normalization. In the interior all pair masses are positive. Legal pair transitions have fixed support, so the one-step score is defined on those legal transitions.

The initial source-score term is S_init=v(X_1,X_2). Conditional Cauchy-Schwarz gives

    E|Cov(g,S_init|Z)|
       <=sqrt(E Var(g|Z) E Var(S_init|Z))
       <=(2/beta)sqrt(m I_step)
       <=(2/beta)sqrt(I_step).                         (S20)

Together with (S16), this proves the complete-score bound (S2), including the stationary initial law rather than silently treating it as fixed.

## 6. Direct future-row change and remaining limits

Future blindness and the source-independent channel give

    d p_theta,C(z)/dt
       =E[dot g_theta(X)|Z=z]+Cov(g_theta,S_all|Z=z).

Here dot g_theta(X)=q_U(1-q_U) dot ell_U for U=(X_(N-1),X_N). Stationarity and Cauchy-Schwarz give

    E|dot g_theta(X)|
       =sum_u I_u |dot ell_u|
       <=sqrt(sum_u I_u) sqrt(I_step)
       <=(1/2)sqrt(I_step).                           (S21)

Equations (S2) and (S21) prove (S3).

This is not a claim that the full latent posterior is stable: its missing score variance can still be much larger than I_step. The proof only controls the future-row covariance and, for the rare triple, uses the monotonicity (S9).

If nonterminal majority-to-minority insertions are allowed, (S9) fails. In particular, a raw 101 can become displayed 111, and the all-minority count can decrease or increase across posterior alternatives. The cross-preimage term identified in the reviewed hazard notes therefore remains unresolved for the full S=1 class.

Finally, integrating (S3) uses source-dependent observation measures. No common-measure finite-alternative inequality, boundary continuation, fitted-model risk bound, general root-M minimax theorem, or state separation is established here.
