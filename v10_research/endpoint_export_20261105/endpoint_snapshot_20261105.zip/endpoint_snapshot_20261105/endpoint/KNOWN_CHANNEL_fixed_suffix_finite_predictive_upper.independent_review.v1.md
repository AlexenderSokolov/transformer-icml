# Independent review: finite posterior comparison and fixed-suffix prediction

Review time: 2026-11-05 11:27:11 UTC.

Disposition: **PASS for the stated finite comparison and fixed-suffix statistical upper.** This is an analytical review, not a scientific executable test or a computational certificate.

## Exact file and scope of approval

The complete final candidate was independently read and its hash checked:

- `KNOWN_CHANNEL_fixed_suffix_finite_predictive_upper.candidate.v1.md`
- SHA-256: `62efe80b0b7daea4c451526db3dc3706eaf5382d4c23bc57fe8f098418e86e65`

This approval binds these current bytes, including the corrected fixed-L constant notation, explicit public estimator selector, and non-strict inequality covering L=0. It does not attach approval to earlier hashes of this filename or infer historical file integrity. The candidate is preserved unchanged by this review.

The approved statements are:

1. With the **unnormalized** convention H^2(P,Q)=sum_x(sqrt(P(x))-sqrt(Q(x)))^2,

       E_(P,C)|p_P(Z)-p_Q(Z)|
          <= E_P|g_P(X)-g_Q(X)| + 2 sqrt(rho) H(P,Q) + H^2(P,Q).

2. For a stationary binary source in D2(beta), an unchanged prefix containing m=M-L training transitions, and any disclosed future-blind channel supported on the last L coordinates with the stated per-word endpoint certificate, a source-independent statistical predictor satisfies

       Risk <= C_beta min{1, m^(-1/2)
                                  + min{rho,sqrt(rho L/m)}}.

No positive transition floor is required. The channel need not be online or have one base state. Conversely, its edits must be confined to the specified suffix; this is not an unrestricted-position S=1 result.

## 1. Finite comparison: centering, convention, and support

The common raw-word kernel gives equality of the raw and joint Hellinger distances, not merely a data-processing inequality:

    sum_(x,z) (sqrt(P(x)C(z|x))-sqrt(Q(x)C(z|x)))^2
       = H^2(P,Q).

The posterior target is the conditional average of the appropriate terminal-row future probability. This interpretation uses the raw-word, future-blind channel experiment; a channel allowed to reveal the unseen future outcome would not be covered by this identity for the target.

For the drift remaining after the direct row difference, let f(x,z)=g_Q(x)-p_Q(z). Then |f|<=1, and E_Q[f|Z]=0. The relevant variance bound is

    E_Q f^2 = E_Q Var(g_Q(X)|Z)
       <= E_Q[(g_Q(X)-g_Q(S(Z)))^2]
       <= Q_C{S(X)!=S(Z)} <= rho.

This does not claim that f itself vanishes off the endpoint-change event. Nor does it assert a pointwise conditional probability bound by rho or any independence between that event and a likelihood ratio.

Multiplying f by the sign of the P-conditional posterior difference preserves |f|<=1 and Q conditional centering. On a common dominating measure, the identity

    p-q = 2 sqrt(q)(sqrt(p)-sqrt(q)) + (sqrt(p)-sqrt(q))^2

proves the stated drift bound directly by Cauchy-Schwarz and the variance inequality. Equivalently, the candidate's absolutely continuous/singular decomposition is correct: its quadratic remainder includes both E_Q(R-1)^2 and the P-singular mass, whose sum is exactly the unnormalized Hellinger square. It therefore handles P mass outside Q support and Q-output evidence equal to zero. A fallback p_Q in [0,1] is sufficient on such outputs.

Only the integrated endpoint probability under Q is needed for this finite comparison. The per-clean-word certificate ensures it for every candidate Q, including raw words outside the true source's support. A certificate valid only after averaging under the true P would not automatically provide this uniform fitted-model conclusion.

If normalized Hellinger is instead defined by H_norm^2=(1/2)sum(sqrt(p)-sqrt(q))^2, the same bound reads

    direct row error + 2 sqrt(2) sqrt(rho) H_norm + 2 H_norm^2.

Thus the originally proposed normalized-convention constants 3 and 12 are conservative. They should not be silently mixed with the final candidate's convention.

## 2. The fitted suffix law really is fixed in the required experiment

The prefix H=X_1:n is observed exactly, with n=N-L and m=n-2. Conditional on H=h, the add-one row table is one fixed table as the suffix output varies. Both the true and fitted suffix chains start from the same observed pair (h_(n-1),h_n). The fitted law does not require a stationary initial law or membership in D2(beta).

Because the original channel always leaves the entire prefix unchanged for every raw input and realization, C_h(w|v)=C((h,w)|(h,v)) is normalized. It is the same kernel for P_h and Q_h even if the channel uses h, hidden randomization, or the whole raw suffix. The per-word endpoint certificate is inherited for every fixed h,v.

Positive add-one rows give positive fitted mass to every suffix word. Consequently, every true-supported channel output has a positive fitted posterior denominator. The more general zero-evidence handling in the finite lemma remains correct but is not needed on the actual support of this fitted estimator.

This argument does not justify choosing a different raw law Q_(h,w) after seeing each suffix output. The candidate explicitly avoids that invalid interchange. Dependence of the fit on the unchanged prefix is fully accounted for by conditioning, not ignored as if the fit were independent of the future context.

## 3. Future-pair-conditioned count concentration

The imported concentration mechanism is the reviewed three-step minorization of the stationary triple chain and its reversal on positive stationary support. Conditioning on any positive-probability pair at or after the final prefix pair changes only the reversed chain's initial distribution. It does not change its backward kernel.

This also covers conditioning on the final prefix pair itself: its associated triple can be the last training triple, and the arbitrary-initial-law concentration allows that initial observation. For a later conditioning pair, reversing through the intervening gap likewise leaves an arbitrary initial distribution at the training block. Splitting training triples into three residue classes preserves uniform constants and introduces no division by the conditioning pair probability.

Accordingly, the conditional Bernstein tail and second moment in (F6) hold for the needed context and successor counts, centered at their stationary means. Zero stationary masses are either harmless zero coordinates or receive zero future-context weight. No arbitrary-initial-source claim is being substituted for stationarity of the actual source.

The concentration dependency inspected for this review is:

- `KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md`, Sections 2.1-2.2; current SHA-256 `a94a259168502b550b696d970b9a577689e82703365b02b0397d5c0a6f14232f`.
- Its existing independent review has current SHA-256 `4665036a148b430e3eb91f349a4db671de184d2c145ac56caec6e87defe8ce6f`.

The new future-pair extension and all subsequent estimation steps were checked independently here. The earlier centered-flow score note, SHA-256 `44d7b71bdf913e510ddb7e5115f1226aaa33d8b37f5cf5f907bae34a32624e47`, is contextual motivation; the finite comparison does not require integration of that derivative lemma.

## 4. Conditional add-one KL: all count regimes checked

The claimed bound E[KL(p||q)|future pair]<=C_beta/(w+1), w=m Pi(u), is valid using only (F6), the binary count identity, and smoothing. In particular, the proof does not need an unstated O(1) first-moment bias estimate.

- If w<8, KL(p||q)<=log(J+2), and the second-moment bound controls E J. The resulting constant is converted to C_beta/(w+1) by a uniform enlargement over w<8.
- On G={w/2<=J+2<=2w} with C_c+1>=(v_c+1)/4 for both symbols, KL<=chi-square gives the exact denominator (J+2)(C_c+1). Writing A_c=(C_c-v_c)-p_c(J-w)+1-2p_c yields E A_c^2<=C_beta(v_c+1), since p_c^2(w+1)<=v_c+1. No count independence or mean-zero assertion is used.
- On a small-numerator event B_c, v_c>3 and G implies q_c<p_c. In the binary case the other KL coordinate is nonpositive, so the total KL is at most (v_c/w)log(2v_c). The deficit is C_c-v_c<-(3v_c+3)/4, giving an exponential factor in v_c. The bounded supremum of v log(2v)exp(-c_beta v) supplies C_beta/w. Both B_c cannot occur on G when w>=8.
- On the lower part of G^c, the loss bound J+2 is O(w), and the probability is exponentially small in w. On its upper part, for t>=2w and w>=8, the count deviation t-2-w is at least t/4, while w+1 is O(t). Thus (F6) really does give an exponential tail in t. Integrating that tail, including its threshold contribution, bounds E[(J+2)1_(G^c)] by C_beta(w+1)exp(-c_beta w), hence C_beta/w.

The positive pseudocounts are essential to these denominators and bounds. True zero transition probabilities cause no division-by-zero issue because their KL coordinates have weight zero; unused stationary rows are omitted from the predictive weighting.

## 5. Conditional geometry and actual prediction risk

For any future context U, stationarity gives P(U=u)=Pi(u). Applying the uniform conditional row bound with the conditioning event U=u gives

    E KL(theta_U||theta_hat_U(H))
       <= C_beta sum_u Pi(u)/(m Pi(u)+1) <= 4 C_beta/m.

This correctly handles the dependence between the training fit and U. It does not require uniform accuracy on rare rows.

The suffix chain rule has exactly L transition terms and no initial-law term because the starting pair is fixed and common. Averaging with respect to the true prefix law therefore gives E KL(P_H||Q_H)<=C_beta L/m. For the declared unnormalized convention, H^2<=KL, so the same estimate controls average Hellinger square. Pinsker and the same future-context bound control the direct terminal-row discrepancy by C_beta/sqrt(m).

Applying the finite comparison separately for each fixed prefix and then averaging is legitimate. Cauchy-Schwarz gives the posterior estimator's bound

    C_beta[m^(-1/2)+sqrt(rho L/m)+L/m].

This is an actual finite-sample bound on the source-specific posterior next-bit target, rather than a derivative or latent-posterior statement.

The displayed-terminal-row estimator independently has risk at most C_beta/sqrt(m)+rho. Its error is compared to the fitted row at the true terminal context first, charging at most one on the terminal-pair-change event, and only then to the true source row. Thus it does not incorrectly evaluate estimation accuracy at a channel-selected displayed context.

With a=L/m, the public selector chooses this endpoint estimator when rho<=a and the posterior estimator otherwise. In the first case min{rho,sqrt(rho a)}=rho. In the second, a<=sqrt(rho a), so the quadratic term is absorbed by the square-root term. This proves (F2). The cases rho=0 and L=0 are valid; when L=0 the fitted suffix has no random coordinates and the two estimators coincide with the clean terminal-row fit. The unit cap and m>=1 handle the remaining small-sample range.

## 6. Limits and preservation

The result is uniform in the disclosed suffix-supported channel and uses no strict edit count or state-count restriction. It therefore cannot establish L<=k or L<=k^2 for an arbitrary-position channel, cannot close the unrestricted no-floor S=1 problem, and does not assert a matching lower bound or state separation.

For fixed L and m comparable to M, the stated root-M consequence allows a constant depending on L. The candidate now records that dependence explicitly. No source transition floor, fixed fitted stationarity, output/source independence, or uncharged clean initial pair is assumed: the clean initial pair is actually observed because of the suffix restriction.

This review does not certify computational efficiency, finite-precision evaluation, a transformer construction, training, or novelty. No scientific executable checks, simulations, numerical experiments, or public writes were performed. File reads and SHA-256 checks served only document inspection and integrity binding. The source candidate and earlier proof files were not edited by the reviewer.
