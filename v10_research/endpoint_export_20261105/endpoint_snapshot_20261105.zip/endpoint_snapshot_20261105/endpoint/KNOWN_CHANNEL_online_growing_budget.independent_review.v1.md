# Independent review of the online growing-budget endpoint lower

Review time: **2026-11-05 07:21:32 UTC**.

Reviewed current files in `./`:

1. `KNOWN_CHANNEL_online_growing_budget_endpoint_lower.candidate.v1.md`
   SHA-256: `9ebe6191bcca016d99e57fbfeda0ef0afed46333b02f796cbd7dbb4f3dcbc601`.
2. `KNOWN_CHANNEL_online_binomial_sign_lemma.candidate.v1.md`
   SHA-256: `1b8c1194ff99d443ead50efebe4598ca5900a486f7f162afc0e673c9bd62dc2d`.

I read both complete arguments and checked the final uniform-in-h scaffold amendment. These hashes were independently measured for this present review. No historical byte state is inferred. No scientific executable tests, numerical experiments, model execution or public writes were performed.

## Disposition

**Analytical PASS for the stated online lower and the supporting sign lemma.** The construction supports

    c_beta min{rho,(k/M)^(1/3)}

for fixed 0<beta<1, sufficiently large M, every 1<=k<=M, and rational rho in [0,1], in the stated paid online finite-state class. It does not establish min{rho,(k^2/M)^(1/3)}.

The large-budget channel has at most 16(M+1)^2 base states plus its separately charged k+1-state edit counter. This approval is not a constant-state growing-budget lower. The channel is a public-horizon-dependent time-indexed family, not a single homogeneous length-independent transducer.

## 1. Rational design and source-class uniformity

Choosing a fixed positive dyadic tau and a dyadic t within the stated factor-two cube-root bracket is valid. The latter can be found by integer comparisons, and its precision is O_beta(log M). The channel uses t only for its common integer threshold. It does not use the source alternative q, the irrational square root in q_+-q_-, or the source parameter r as a transition probability.

The fact that t is shared by the source alternatives does not make the channel source dependent: t is fixed publicly from M,k and the fixed design constant before the unknown alternative is selected. The channel is the same stochastic map under both sources.

The stationary rare-source formulas and all-state minorization continue to hold uniformly because q stays in [1-d,1+d] and t<=d/4. The transition KL is O_beta(d^2 Mt^3/h), hence bounded by a fixed multiple of d^2 tau^3. For the initial law, differentiating its displayed normalization gives derivatives O_beta(t^3) for log u_q and O_beta(t) for every pair log mass. Thus the initial log ratios are O_beta(t/sqrt h), and

    t/sqrt h <= tau M^(-1/3) h^(-1/6)

tends to zero uniformly in the allowed h. The clean-history TV bound can therefore be enforced uniformly by choosing tau and the onset horizon as stated.

This uniformity argument matters when h is comparable to M: t then need not tend to zero. The final draft correctly avoids relying on such a false uniform limit.

## 2. Raw counters, online causality and strict budget

A pattern centered at j becomes fully known at time j+2. The last four raw bits, together with the current raw bit, identify both 11?00 and 11100. Counting only public candidate centers ensures every counted window is valid, and all such counts are finalized by N-3.

The distinction between the two counters is correct:

- n_00 is determined by the retained preceding/following coordinates and is H-measurable.
- S_00 includes the hidden raw candidate bit. It is not H-measurable and is intentionally a hidden statistic used by the channel.

Using S_00 is permitted online: the channel observed each raw bit when it arrived and retains its count. It is not an oracle for a hidden statistic unavailable to the channel. Conversely, the predictor is not supplied that counter, state or edit mask.

Interior erasures use at most h=k-1 edits. The endpoint step can add at most one, increments the counter when it does, and has the explicit e<k guard. Even outside the good scaffold or the all-zero branch, every path obeys the k cap. If the raw sign count is large after the interior cap has been reached, the possible endpoint edit still produces no more than h+1=k edits.

The endpoint decision reads only previously completed counts, the preceding raw pair, current input, public time and an independent coin. It does not read X_N. For every clean word, the endpoint-change probability is zero or rho. All probability rows are normalized and rational, and no acceptance/rejection conditioning is used to define the channel.

## 3. Recoverable scaffold and the two different count laws

Candidate spacing by three ensures that their preceding and following positions are noncandidates. Those retained positions are unchanged, so the eligibility mask and H can be recovered from Z. Every order-two likelihood factor contains at most one missing candidate; candidate factors and the penultimate-bit factors are also separated. Conditional on H, the missing candidate bits are independent of one another and of B.

The four future-neighbor odds are the correctly derived expressions from the one-edit audit. Only the 00 subset has a common Bernoulli parameter. Therefore

    S_00 | H ~ Bin(n_00, qt/[1+(q-1)t])

is exact, while the total S_all is generally Poisson-binomial. The draft does not conflate these distributions.

Erasing the first h eligible ones makes all eligible displayed bits zero exactly when C={S_all<=h}. If S_all>h, a later eligible one remains visible. Eligibility cannot change after a previous erasure because it depends on untouched noncandidate positions. Thus C is an identifiable output branch without an exposed edit flag, and there are no additional outside-C preimages of its all-zero candidate configuration.

After conditioning on C, S_00 is not asserted to remain binomial. Its law is handled solely through the explicit cap-conditioning estimate, which is the correct approach.

## 4. Uniform good-scaffold probability

The final explicit mean calculation is sound. From r<=1/16, t<=1/256 and q<=65/64, the stationary normalization gives u_q>=1-3t. Combining this with the candidate density yields the stated uniform interval [9/32,11/32] for E n_00/(Mt^2), for M>=64. It lies strictly inside the target interval (1/4,1/2).

The geometric pair-chain mixing bound controls disjoint rare-window covariances by O_beta(t^2) times a decaying factor; overlapping windows contribute the same order a fixed number of times. Hence Var(n_00)<=C_beta Mt^2. Because Mt^2>=(tau^2/4)M^(1/3), the count-event failure probability tends uniformly to zero.

The stationary minority mass is at most 2t, so the terminal scaffold has failure probability at most 6tau<=1/32. This is a uniform small bound, not convergence to one as h varies with M.

The cross-source odds estimate from the one-edit proof remains applicable: o_+/o_q<=2 and o_q<=1/8 imply o_+<=4p_q. Therefore E_q L_+<=4Mt^3<=4tau^3 h, giving the stated Markov failure bound 256tau^3. All source/scaffold conditions can be imposed simultaneously with fixed tau and M_beta.

D is one common H-measurable set under both alternatives. Data processing of the clean-history TV bound and P_q(D)>=7/8 therefore give the required overlap at least 3/4.

## 5. Binomial sign lemma

I checked the lemma's constants and derivative argument independently.

The identity for p(q)-t gives |p(q)-t|<=dt/sqrt h. Consequently p remains between 3t/4 and 5t/4, and p'(q)>=3t/4. With m=n-1 and c=floor(nt), the assumptions imply that c is interior and

    mp(1-p)>=mu/2,
    |c-mp|/sqrt(mu)<=9/16.

The elementary KL upper bound D(x||p)<=(x-p)^2/[p(1-p)] then yields mD(c/m||p)<=81/128<1. Applying the stated elementary Stirling inequalities gives

    P(Bin(n-1,p)=c)>=1/(4e sqrt(mu)).

The explicit numerical weakening in that step is valid. The threshold c is fixed as q varies, even though the scaffold distribution itself depends on q: the calculation is performed pointwise at one fixed H and hence one fixed n_00.

Differentiating the finite binomial tail telescopes to nP(Bin(n-1,p)=c). Multiplication by p'(q), followed by integration across the q interval, gives the lemma's lower 3d sqrt(a)/(8e), and hence its conservative Delta_*.

For the heterogeneous full hidden family, the conditional mean is at most h/64 on D. Its product mgf gives P(C^c|H)<=(e/64)^h without requiring identical Bernoulli probabilities. For any bounded U in [0,1], the exact mixture on C and C^c gives

    |E(U|C)-EU|<=P(C^c).

There is no missing normalization factor. Applying this separately to the two sign expectations subtracts at most twice the cap tail. The displayed H_beta ensures both mu>=16 and a remaining gap at least Delta_*/2. No unproved monotonicity of a cap-conditioned family is invoked.

## 6. Exact terminal posterior and retained output mass

On the terminal scaffold, B|H is Ber(t), independent of the hidden interior bits, and its next-symbol row is t+(r-t)B. The hidden sign statistic is completed before B arrives. On C there are at most h interior edits, so one endpoint edit remains available. Therefore the endpoint flip probability conditional on H,C is exactly rho v_q.

The displayed W=1 law and source-specific posterior formulas follow directly. The full branch observation mass is f_q(H)g_q(H)ell_q(1), with no prior mixture over sources and no unobserved-output collision term.

The exact posterior-gap subtraction is correct. Multiplying by the minimum observation mass cancels only one ell denominator, leaving the lower factor rho t/(rho+t). With g_q>=1/2, r-t>=r/2 and 1-t>=1/2, the displayed factor r v_*/8 is valid. Summing scaffold overlap and dividing the two-risk inequality by two gives 3r v_*/64 times rho t/(rho+t).

The argument is uniform in rho, including zero. The positive t prevents a zero posterior denominator on these outputs. No rare displayed-output mass is dropped.

## 7. Small and large budgets and state resources

The case split has no gap: h=k-1>=H_beta covers k>=H_beta+1, and the reviewed one-edit witness covers 1<=k<=H_beta. For large h, h>=k/2 and the dyadic bracket give t>=c_beta(k/M)^(1/3). For bounded k, the factor H_beta^(1/3) converts the one-edit scale to the requested scale and is absorbed into a fixed beta-dependent constant.

The growing construction uses 16(M+1)^2 base states for raw memory and two counts, plus the separate counter. This is polynomial, not constant, state cardinality. The fully expanded time-indexed table ledger explicitly charges state pairs, counter dependence, rational rho, dyadic precision, zeros, comparison generation and public design data. Threshold comparison is finite integer arithmetic. The real-valued source parameters do not enter the rational channel table.

Combining with clean and protected-budget lower bounds uses a maximum of distinct admissible witnesses, not a composition of their edits. The resulting lower is valid for an online class allowing these paid polynomial-state families. It should not be advertised as a lower with a fixed four-state allowance for growing k.

The approved conclusion is the endpoint exponent k^(1/3)M^(-1/3). The offline k^(2/3)M^(-1/3) endpoint term, constant-state growing-budget sharpness, resource-optimal Transformer bounds, fixed-positive-floor lower, one fixed-source asymptotic impossibility, training, numerical correctness and external novelty remain unproved here.
