# Three base states suffice for the matching online lower

5 November 2026 UTC. Pure analytical implementation addendum. No scientific executable checks or public writes. The eight-state lower proof remains unchanged. This note describes an exactly equivalent three-base-state implementation and a two-state implementation of its small-budget fallback.

## 1. Consequence and scope

The matching endpoint lower from `KNOWN_CHANNEL_online_thinning_mode_matching_lower.candidate.v1.md` holds already for an allowed base-state budget **S>=3**, with its actual edit counter and public time-indexed table still charged separately. Consequently its combined T2 minimax profile holds at this state allowance as well.

This is an exact channel implementation improvement. The source alternatives, posterior target, risk proof, endpoint budget and constants are unchanged. It neither removes the growing counter nor proves optimality of three base states.

## 2. The three states and the public schedule

Use base states I, A0 and A1. State I means the inactive mode U=0. States A0,A1 mean U=1 and carry one binary gate accumulator. Initialize to I with probability 1/2 and A0 with probability 1/2, independently of the source.

Let J={j divisible by 3: 3<=j<=N-5}, exactly as in the reviewed thinning-mode channel. The three-time windows {j-2,j-1,j}, j in J, are pairwise disjoint. The endpoint gate uses N-3,N-2,N-1, which are outside every such window because j<=N-5. Thus the time-indexed rows below have no conflicting roles.

For every time and raw bit, I stays I and outputs the raw bit without an edit. For an active state Ab, b in {0,1}, use the following rows, always updating the actual counter by precisely 1{output differs from input}:

1. At i=j-2 for j in J: output x_i unchanged and move to A_(x_i). This overwrites the old accumulator even when it was zero.
2. At i=j-1 for j in J: output x_i unchanged and move to A_(b*x_i).
3. At i=j for j in J: if b=1, x_i=1 and e<h, output zero with probability epsilon=1/(2h); otherwise output x_i. After either output move to A0. Thus the candidate step resets the accumulator regardless of the coin, gate or counter.
4. At i=N-3: output x_i unchanged and move to A_(1-x_i).
5. At i=N-2: output x_i unchanged and move to A_(b*(1-x_i)).
6. At i=N-1: if b=1 and e<k, flip x_i with probability rho; otherwise output x_i unchanged. After either output move to A0.
7. At every remaining time, output x_i unchanged and move to A0. This includes i=N.

Here h=min{k-1,floor(sqrt M)} is the already reviewed large-budget choice. The rules apply to every row, including unused rows: the e<h and e<k guards prevent over-budget outputs. Initialization and all nonintegral row probabilities are rational.

## 3. Pathwise equivalence, not merely equality in source law

Fix any clean binary input word and every initialization, thinning and endpoint coin realization. Couple this implementation to the original eight-state implementation by using those same coins.

If U=0, both channels remain identity. If U=1, immediately before each candidate j, the accumulator is

    b=x_(j-2)*x_(j-1)=1{the preceding raw pair is 11}.

The candidate erasure test and its coin are therefore identical to the original channel's. Both counters increment on exactly the same steps. Immediately before N-1, the accumulator is

    b=(1-x_(N-3))*(1-x_(N-2))
      =1{the preceding raw pair is 00}.

The endpoint test, counter guard and coin likewise agree. Every other output is unchanged in both implementations. By induction, the two displayed words and entire actual-counter paths agree for every input and coin realization.

Thus the joint law of the clean word, displayed word, hidden mode, actual counter and clean future is exactly the same for every source. In particular the source-specific posterior target and every predictor's risk are unchanged. No statistical approximation, source-specific encoding or uncharged counter memory is introduced.

The inactive mode requires no gate memory, which is why the product count 2 modes times 2 gate values compresses further from four to three states.

## 4. Small-budget fallback uses only two base states

The original matching proof uses the reviewed one-edit online channel for its bounded small-h range. Its two raw-pair tests have the same public schedule. It can therefore be implemented using only F0,F1, with initialization F0 and the gate updates/reset rules 1,2,4,5,7 above (replace A by F).

At each candidate j, erase x_j=1 exactly when the gate is one and the actual counter is zero; then reset to F0. At N-1, flip with probability rho exactly when the gate is one and the counter is zero; then reset to F0. The actual counter is separately charged and can be embedded in the available k+1 values; only 0 and1 are reached.

The same pointwise gate invariant proves exact equivalence to the reviewed one-edit channel. Its lower bound and bounded-k fallback therefore do not require four base states. The clean identity witness and the protected k/M witness each need only one base state. All witnesses used in T2 consequently fit S>=3 after padding unused states.

## 5. Paid resources and what is not proved

The large-budget family has three base states, a separately charged actual counter with k+1 values, and an expanded rational time-indexed table of conservative length

    ell=O(N * 3^2 * (k+1)
              *[b_rho+log(h+1)+log(N+1)+1]).

The clock is supplied by the already permitted time-indexed interface, whose full table expansion is paid. This does not implement the schedule in a time-homogeneous three-state machine. It also does not overwrite the edit counter with another quantity or omit it from the total augmented-state accounting.

Three is a sufficient base-state count, not a proved minimum. A lower bound against all S=1 or S=2 channels would require a statistical argument beyond observing that this particular explicit representation has three distinguishable memory configurations.
