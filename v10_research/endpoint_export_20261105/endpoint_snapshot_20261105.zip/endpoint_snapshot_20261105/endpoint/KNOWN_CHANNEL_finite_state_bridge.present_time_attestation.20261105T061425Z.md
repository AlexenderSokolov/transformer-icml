# Present-time exact-file attestation for the finite-state bridges

Issued: **2026-11-05 06:14:25 UTC**, following a fresh complete reread of all three files below. This is a private analytical attestation, not a scientific execution, numerical test, formal verification, or public publication.

## Exact current files

Base directory: `./`.

1. `KNOWN_CHANNEL_finite_state_transformer_bridge.candidate.v1.md`

   SHA-256: `ce04cc928c88ca3edb2849d69c5207126edda5841140517636f2a17338a7b15a`

2. `KNOWN_CHANNEL_finite_state_constant_width_bridge.addendum.v1.md`

   SHA-256: `8ba86c1d06255f7858640483b4078a9e0856f4adf317c1f6a24607d404eeb7d0`

3. `KNOWN_CHANNEL_finite_state_bridge.independent_review.v1.md`

   SHA-256: `2572bbdfcecaed72385087a1b4c0d58fc700762fe70e743fa5a8b18ac3821634`

I independently computed these hashes with SHA-256 before the fresh reread and recomputed all three after the reread. The two observations agree exactly. The reread covered the complete contents of each current file, including the end of the main candidate and beginning of the addendum through supplementary reads where the combined display was truncated. None of these three original files was edited during this attestation task. This separate attestation preserves the original review unchanged.

## Present analytical reaffirmation

I reaffirm the original review's scoped favorable conclusion for the exact current bytes listed above. Both deterministic constructions are analytically coherent under their specified normalized rational online finite-state channel, source-independent auxiliary randomness, raw-token input, zero-score self-inclusive attention, counted bounded affine/ReLU primitives, and exact-rational evaluation contracts.

The complete reread includes the final clarifications:

- The supplied channel description is expanded over time, including repeated homogeneous tables and explicit counter dependence. The online subclass is distinguished from arbitrary offline future-blind channels.
- All channel randomness is independent of the source process. Forbidden edits are handled inside a normalized channel, rather than by an uncharged rejection/conditioning operation.
- The integer budget is explicit, the circuit is sufficiently padded, zero evidence uses a positive dummy division denominator and a selected 1/2 fallback, and the final probability is a dyadic approximation with its possible integer bit included.
- The growing-width compiler preserves all-row Boolean inputs and bounded whole-vector norms, pays output amplification, and does not use a free arbitrary-rational probability decoder.
- The constant-width addendum specifies **64 persistent coordinates and FFN hidden width 128**, with separate retained operands and restoration scratch. Stack reads restore both memories, and each scalar primitive is charged a fixed number of canonical blocks.
- Every occurrence of `Digit(4S)` is staged through the explicit intermediate `y=4S`. The continuous fixed-slope extractor is used only on its valid separated digit intervals.
- The posterior compiler is beta-free. Full statistical composition retains separate majority/other-branch obligations and charges varying-beta threshold representations and constant selection when needed.

The resource conclusions remain:

    Growing width: d,L=O(G), scalar rational size O(r+log N+log G).
    Constant width: d=64, L=O(N log N+G^2), scalar rational size O(G+r+log N).

Both output the specified fitted posterior to error at most 2^-r, with an exact simplex output. The fixed-width result explicitly buys storage through larger scalar precision and depth.

## Scope exclusions

This is not approval of a mandatory-PreLN or RMSNorm construction. These files explicitly use no normalization layer. It is not a claim of IEEE/GPU correctness, floating-point robustness, constant-bit precision, optimal depth, training achievability, tied weights, arbitrary-initial-law learning, arbitrary-channel efficient inference, or a matching restricted-channel minimax lower bound. The imported stationary statistical theorem and its rho interpolation are not independently certified by this attestation. Implementing the fitted posterior alone does not implement all branches of those statistical estimators.

## No historical hash inference

This attestation binds the analytical reaffirmation **at the issuance time above to the current bytes identified by these hashes**. It does not claim that these were the files' hashes at an earlier review, message, creation time, or approval time. It does not retroactively turn the original hash-free review into a historically hash-bound certificate. The matching hashes supplied in the preservation request were independently checked now; they are not being used as proof of an earlier byte state or earlier approval.

Only private file inspection, cryptographic identity checks, and creation of this separate attestation were performed. No scientific executable checks, dense model execution, numerical experiments, public repository writes, or edits to the three bound originals were performed.
