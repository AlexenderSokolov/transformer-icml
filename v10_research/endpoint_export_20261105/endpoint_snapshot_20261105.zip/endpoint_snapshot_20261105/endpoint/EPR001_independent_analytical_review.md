# EPR001 independent analytical review

Date: 2026-11-05 UTC. This is an independent mathematical review, not a numerical experiment, formal verification, external peer review, or novelty certification. No scientific code was executed and no public write was made. The predecessor theorems are imported at their stated scope rather than re-proved here.

## Review scope and conclusion

Reviewed:

- `EPR001_endpoint_probability_interpolation.md`.
- `EDIT_OVERLAP_and_TARGET_BOUNDARIES.md`.
- Locally available SC002, SC003, BT002, EP001, their relevant acceptance scopes, and the consolidated source-corruption manuscript.
- Relevant stage-eight text for an existing endpoint-probability interpolation, and RG001/JP001 to distinguish input corruption from representation noise.

The interpolation theorem, the distinct corrupted-target lower, the binary full-support limiting argument, and the shared-count refinement are analytically valid under the exact qualifications below. Final readback on 2026-11-05 at approximately 02:19 UTC confirmed the zero-budget correction, the corrected forged-output description, and the full fixed-eta boundary proof. This review does not independently attest the remote commit or historical hashes quoted by the author.

## 1. Exact experiment and probability budget

The main channel has at most k Hamming substitutions on every input/output realization. For every fixed complete input word x, its conditional probability of changing either member of the terminal pair is at most rho. These are upper budgets, not exactly k edits or exactly rho endpoint-change probability. The channel can inspect x but receives no unknown source parameter or predictor seed. The predictor sees the whole corrupted word without a mask or attack seed.

The main target is the next-symbol row at the ORIGINAL terminal pair. The source class uses the two-step certificate on all K-squared pair states, including states outside stationary support. Stationary initialization means the hidden qualifying pair law Pi, not the product of its symbol marginals.

The common per-word channel class makes R_stat <= R_all immediate by source inclusion. For the optional source-averaged condition, use the same supremum over all qualifying source tables and all initial laws to define the channel class for both risks. Defining two different channel classes by separate stationary/all-start suprema would not justify that exact ordering.

For k=0 no endpoint change is possible, irrespective of the supplied rho. Every interpretation requiring rho(1-beta)=O(M^-1/2) must therefore either include 1{k>=1} or explicitly restrict to positive budgets. A deterministic channel with rho<1 cannot change an endpoint in the per-word model; randomization is material to this interpolation.

## 2. Common-component and clipping proof

Marginalizing P^2(u,(c,d)) >= beta Pi(c,d) over d gives theta_u(c) >= beta pi(c). Thus all rows share the same beta pi component. Their TV diameter is at most delta=1-beta, and each row is within delta of every convex average of rows. This justifies clipping radius delta, rather than the looser 2delta triangle bound through pi.

The generated-symbol average has decomposition b = mbar + W, where W is the average of M vector martingale differences. Orthogonality yields E||W||_2^2 <= 1/M and E||W||_1/2 <= sqrt(K)/(2sqrt(M)). A k-edit attack changes the generated-symbol empirical law by at most k/M. Therefore, for every row u on every realized word,

    TV(b',theta_u) <= delta + ||W||_1/2 + k/M.

This is uniform over rows and hence valid even when u is selected adaptively from the corrupted word. No conditional concentration assertion is needed.

Let q be the existing protected estimator evaluated on the corrupted word, and radially clip q toward b' into the TV ball of radius delta. If G is the event that the terminal pair is unchanged, the pointwise loss is bounded by

    2 1_G TV(q,theta_original)
      + 2delta 1_(G^c) + ||W||_1/2 + k/M.

The repaired channel C^0 returns the corrupted word on G and the original input on G^c. It is a common source-independent, endpoint-preserving, at-most-k channel. Consequently the good-event loss contribution is bounded by the UNCONDITIONAL protected risk of q under C^0. This is the correct way to avoid an invalid risk bound after conditioning on a history-adaptive event.

The same clipping argument works for the corrupted-row target because the row bound is simultaneous and both targets agree on G. That agreement does not make the targets interchangeable elsewhere.

## 3. Constants and alphabet branches

The inherited protected upper can be written A_K s+B_K F, with

    K>=3: A_K=2^13 K^(5/2),
           B_K=12K^2(17+log 80)+60K^4;
    K=2:  A_2=2^17, B_2=2^19.

The cutoff is e=max(beta,1/M) for K>=3 and e=max(sqrt(beta),1/M) for K=2. The binary estimator is the k-aware fixed-orientation lower envelope, not ordinary corrupted-row add-one. Its matching logarithmic lower requires BT002 and its finite scalar completion; SC003 alone does not prove it.

For k>=1 the reviewed upper is

    (2A_K+sqrt(K)/2)s + (2B_K+1)F + 2rho delta.

Hence C_K=2A_K+2B_K+sqrt(K)/2+3 is sufficient against the capped maximum profile. The k=0 clean branch is separately valid. Lower constants 2^-15 for K>=3 and 2^-54 for K=2 survive the new endpoint term. All are fixed-alphabet constants, not sharp growing-K constants.

The wrapper is beta-aware and rho-blind. With arbitrary real beta it is a measurable statistical estimator, not automatically a finite rational or bounded-resource implementation.

## 4. Original-target lower and strict budget

The existing protected lower witnesses remain admissible for every rho. Separately, a Bernoulli(rho) trigger followed by setting only the last symbol to 0 uses at most one edit and is legal for k>=1. It must not be composed with a full k-edit protected attack; the lower witnesses are combined by a maximum.

For EP001's stationary symmetric binary source, alpha=min(delta/2,1/4). Even after revealing the trigger coin and source law, the original last symbol is hidden on the erasure branch. Posterior optimal loss is (1/2-alpha)2alpha >= delta/8. Thus the endpoint lower is rho delta/8. Revealing the trigger coin is not revealing the actual edit mask. The actual endpoint-change probability in this stationary witness is rho/2, which is fully legal for the at-most-rho class.

## 5. Corrupted-target lower and rare contexts

The separate stationary binary family with only theta_01(1)=p nonzero, p in {0,delta}, has Pi concentrated on 00 and P^2(u,00)>=1-p>=beta on every pair. All clean histories are zero. A common Bernoulli(rho) last-bit change to 1 produces the same forged query 01 under both sources. Equal prior weights on the two endpoints give lower rho delta/2. A continuous uniform prior would give delta/4 before multiplication by rho and cannot justify the stronger constant.

The first-order full-support approximation is valid for beta<1: take p_0=a, p_1=delta-sqrt(a), sqrt(a)+a<=delta, T_i(0,1)=a, and T_i(1,1)=p_i. Its stationary law is (1-p_i,a)/(1-p_i+a), and T_i >= (1-p_i+a) pi_i >= beta pi_i. The stationary all-zero word probability tends to one for fixed finite M, including beta=0. The two-point subevent bound converges to rho delta/2. This is a finite-horizon supremum argument, not one fixed positive-a chain that stays unlearnable forever.

This full-support argument establishes the new binary endpoint floor only. It does not by itself re-prove every inherited protected lower under a newly restricted full-support class, especially when K>3 and old witnesses use unused symbols. A fixed positive lower bound on all transition probabilities excludes this limiting construction.

The target separation is genuine. Under the rare-row family the original target is constant while the forged target contains the unknown parameter. Under a known symmetric source the corrupted target is known from the observed pair while the original target remains ambiguous after erasure. Equal broad-class minimax orders do not imply a pointwise dominance or equivalence of losses.

## 6. Fixed-positive-transition-floor boundary

The separate binary boundary argument in the final companion section 5 is valid. If every transition probability lies in [eta,1-eta] for fixed 0<eta<1/2, sample pair states ending at times 4,6,...<=M+1. Each named pair has conditional probability at least eta^2 given the history two steps earlier. With L=floor((M-1)/2), an adapted Bernoulli Chernoff bound gives

    Pr(min_u J_u < eta^2 M/8) <= 4 exp(-eta^2 L/8), M>=4.

For each row, Z_u=C_(u,1)-theta_u(1)J_u is a predictable-row martingale sum with E Z_u^2<=M. Applying the simultaneous row bound and the companion's same-row perturbation bound proves a corrupted-target risk upper of

    min{1, 32/(eta^2 sqrt(M)) + 32/(eta^2 M)
             +24k/(eta^2 M) +4 exp(-eta^2 L/8)}.

In particular it tends to zero when k=o(M), even when endpoints are unrestricted. This is an upper bound, not a sharp fixed-eta minimax theorem. For fixed beta<1 the original-target endpoint lower can persist in the same transition-floor class by choosing 0<alpha<=min{delta/2,1/2-eta,1/4}.

## 7. Shared-count refinement

The companion's overlap union h(E) correctly accounts for adjacent edits. Untruncated affected intervals give h(E)=3+sum min(3,e_j-e_(j-1)); a contiguous interior k-block has h(E)=k+2.

For the same queried row before and after corruption, write clean and corrupted counts as w+r and w+r', where w is the unchanged contribution and the changed-triple incidence masses are a_u,b_u. Add-one smoothing shares the submeasure (w+1)/(max(J,J')+K). Therefore

    TV(q_u,q'_u) <= max(a_u,b_u)/(max(J,J')+K)
                  <= h(E)/(J+K) <= 3k/(J+K).

This is a valid improvement over the coarse 6k bound. The latent clean damage counts are analysis quantities, not observed estimator inputs. The same-row calculation alone does not justify applying a clean actual-terminal theorem to an attacker-selected forged query.

## 8. No per-word statistical guarantee and archive overlap

Only the channel constraint and algebraic comparison bounds are per-word. The risk theorem averages over the source trajectory. For a direct counterexample to a per-word risk interpretation, take beta=1,k=0 and binary IID p in {1/4,3/4}. The word 0^N has positive probability under both sources. Any prediction from that same word has conditional expected TV at least 1/4 for one of the two sources, regardless of M.

The stage-eight archive already contains the protected frontier, the binary sqrt(beta) completion, and the fully editable-endpoint original-target theorem. Relevant source reads and targeted text searches did not locate an intermediate-rho interpolation. That is a scoped internal duplicate check, not proof of external novelty or an exhaustive semantic search. RG001 and JP001 concern different representation/noise interfaces and cannot be silently reused as an input-token endpoint theorem.

## Final disposition

Analytical PASS for the final-readback interpolation and the explicitly separated target/boundary propositions, with the zero-budget and source-class qualifications now present. No unresolved mathematical blocker was found in this scoped review. No executable verification, neural realization, causal-adversary logarithmic lower, or external novelty conclusion is supplied by this review.
