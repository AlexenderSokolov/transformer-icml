# A hidden thinning mode closes the growing-budget online endpoint gap

5 November 2026 UTC. Pure analytical candidate for independent review. No scientific executable checks, public writes, or novelty certification. This is a new candidate; the preceding reviewed erasure/sign construction remains unchanged.

## 1. Proposed result

Fix 0<beta<1. For sufficiently large M, N=M+2, every integer 1<=k<=M and rational rho in [0,1], the disclosed causal normalized rational strict-k channel class satisfies

    R_online,beta(M,k,rho)
        >= c_beta min{rho,(k^2/M)^(1/3)}.                    (T1)

The large-budget witness uses **eight base states**, excluding the separately charged edit counter and the public time-indexed transition table. Its base state is the last two raw bits and one persistent hidden fair bit. It needs no growing raw-count state. Thus the lower applies to an allowed base-state budget S>=8 (padding unused states if needed), not to every smaller fixed S.

Combining with the already reviewed clean and protected-budget lower witnesses, and the sharp-rho upper applicable to this class, would give, after independent acceptance of this proof,

    R_online,beta(M,k,rho)
        asymp_beta min{1, M^(-1/2)+k/M
                              +min{rho,(k^2/M)^(1/3)}}.     (T2)

The maximum of three separate witnesses yields the lower sum; their edit budgets are not added. This does not prove an online/offline separation. It instead removes the previously unmatched growing-k endpoint gap for this paid time-indexed class. The model still has a growing separately charged counter and a horizon-dependent table, so this is not a fixed-state homogeneous transducer theorem when those resources are included.

## 2. Sources and scales

Put d=(1-beta)/64 and r=4d. Choose a fixed positive dyadic tau sufficiently small depending only on beta, with

    tau <= min{d/4,1/256}.

For k>=2 set

    h=min{k-1,floor(sqrt(M))},
    (tau/2)(h^2/M)^(1/3) <= t <= tau(h^2/M)^(1/3),
    q_-=1-d/h, q_+=1+d/h.                                (T3)

A dyadic t in this interval may be selected. The channel below never uses t, d, r, or q, so their representation is not a hidden channel-table resource.

Use the same rare stationary binary order-two family as the reviewed one-edit and rare-budget proofs:

    theta_q(00)(1)=theta_q(01)(1)=t,
    theta_q(10)(1)=r, theta_q(11)(1)=q t.

Its stationary pair law is

    Pi_q(00)=u_q,
    Pi_q(01)=Pi_q(10)=u_q t/(1-r),
    Pi_q(11)=u_q t^2/[(1-r)(1-q t)],

with u_q the normalizer. The reviewed all-state D2(beta) certificate holds uniformly for q in [1-d,1+d] and t<=d/4.

Only the 11 row changes between sources. Its Bernoulli KL is at most C d^2 t/h^2, and its stationary context mass is at most C_beta t^2. Therefore

    KL(P_+^(1:N)||P_-^(1:N))
       <=KL(Pi_+||Pi_-)+C_beta d^2 M t^3/h^2.

The second term is at most C_beta d^2 tau^3. Differentiating the displayed stationary law gives |d log Pi_q(s)/dq|<=C_beta t, so its initial-law log ratios are O_beta(t/h), and

    t/h <= tau M^(-1/3) h^(-1/3) <= tau M^(-1/3).

Reduce tau and enlarge M_beta to obtain uniformly

    TV(P_+^(1:N),P_-^(1:N)) <= 1/8.                      (T4)

## 3. The actual causal channel

At initialization sample a hidden fair mode U in {0,1}, independently of the entire source process. Put

    epsilon=1/(2h),
    J={j: j is divisible by 3, 3<=j<=N-5}.

Maintain the actual edit counter e and the previous two **raw** bits.

1. At j in J, if U=1, the preceding raw pair is 11, the current raw bit is one, and e<h, erase that one with probability epsilon. Increment e only on an erasure. Use independent coins at different opportunities. Otherwise output the raw bit unchanged.
2. At i=N-1, if U=1, the preceding raw pair is 00, and e<k, flip the current raw bit with probability rho, independently of the source and thinning coins. Increment e only on a flip.
3. All other outputs, including X_N, are unchanged. Always update raw memory with the input bit, not the displayed bit.

At most h interior edits and one endpoint edit occur, so every realization has at most h+1<=k edits. For every fixed clean word, terminal-pair-change probability is at most rho (in fact at most rho/2). No future symbol is read, including X_N at the endpoint action. There is no terminal acceptance condition.

The initialization probabilities 1/2, thinning probabilities 1/(2h), and endpoint probabilities rho are rational. Eight base states suffice for (U,last raw pair); the separately paid actual counter has k+1 values. The per-word endpoint certificate is checked directly above; the bridge permits such separately verified normalized tables and does not require an additional stored endpoint coin. All unused table rows can be normalized by the same guarded rules. A conservative expanded description ledger is

    ell=O(N * 8^2 * (k+1)
              *[b_rho+log(h+1)+log(N+1)+1]).              (T5)

The table also pays for time expansion, zero entries, state/counter destinations and generation. The exact integer computation of floor(sqrt M) and its comparisons are polynomial in the paid description. No unknown source parameter is supplied to the predictor or appears in the channel.

## 4. Recoverable scaffold and its good set

Use the previously reviewed scaffold H: remove B=X_(N-1) and candidate bits whose preceding raw pair is 11, retaining their positions and all other raw coordinates. Candidate spacing three ensures the preceding two positions are noncandidates. They are untouched, so the missing-site mask and H are recoverable from the displayed word, even after the strict cap is reached.

Conditional on H, all missing candidate raw bits are independent and independent of B. If the retained following pair is (a,b), their odds are

    o_q(0,0)=q t/(1-t),
    o_q(0,1)=q r/(1-r),
    o_q(1,0)=q^2 t^2/[r(1-t)],
    o_q(1,1)=q^3 t^2/[r(1-q t)].                        (T6)

All odds increase with q. They are at most 1/8 throughout these parameters. Write p_qj=o_qj/(1+o_qj), n_00 for the number of missing candidate sites followed by 00, and L_+=sum_j o_+j.

Set eta=1/64 and define the common H-measurable set

    D={X_(N-3)=X_(N-2)=X_N=0}
        intersect {M t^2/4<=n_00<=M t^2/2}
        intersect {L_+<=eta h^2}.                       (T7)

The reviewed rare-window calculation gives, uniformly here,

    E n_00/(M t^2) in [9/32,11/32],
    Var(n_00)<=C_beta M t^2.

Indeed a candidate's exact 11?00 probability is u_q t^2[1+(q-1)t], u_q>=1-3t, and its density is between 1/3-2/M and 1/3. Because M t^2 >= (tau^2/4)M^(1/3), the count event has probability tending uniformly to one. The stationary minority mass is at most 2t, so the terminal event has failure probability at most 6tau.

The previously checked odds comparison o_+/o_q<=2 and o_q<=1/8 gives o_+<=4p_q at each missing site. Consequently

    E_q L_+ <=4 E_q sum_j X_j <=4 M t^3<=4tau^3 h^2,
    P_q(L_+>eta h^2)<=256tau^3.                         (T8)

Choose tau and M_beta so P_q(D)>=7/8 under both sources. If f_q is the scaffold law, (T4) and data processing then give

    sum_(H in D) min{f_+(H),f_-(H)} >=3/4.              (T9)

The channel does not test D or calculate any of its counts.

## 5. An uncapped comparison experiment

For analysis only, first omit the e<h guard on interior thinning. Conditional on H, let Y be the displayed candidate vector. Under U=0 its product law P_q0 has success probabilities p_qj; under U=1 its product law P_q1 has success probabilities (1-epsilon)p_qj. Put

    m_q=(P_q0+P_q1)/2,
    Lambda_q(Y)=P_q1(Y)/P_q0(Y),
    v_q(Y)=P_q(U=1|H,Y)=Lambda_q/(1+Lambda_q).

Every product probability is positive. The exact mode likelihood ratio is

    Lambda_q(Y)
       =(1-epsilon)^(sum_j Y_j)
          product_(j:Y_j=0)(1+epsilon o_qj).             (T10)

The terms for displayed ones do not depend on q. Thus Lambda_+>=Lambda_- pointwise.

### 5.1 Conditional output overlap and bounded mode odds

For product Bernoulli laws, direct multiplication of the one-coordinate chi-square identities gives

    1+chi2(P_q1||P_q0)
       = product_j(1+epsilon^2 o_qj)
       <=exp(epsilon^2 L_+)
       <=exp(1/256).                                    (T11)

Hence TV(P_q0,P_q1)<=1/16, using TV<=sqrt(chi2)/2 and exp(x)-1<=2x for 0<=x<=1.

Let E_0={1/2<=Lambda_-<=2}. On its complement |P_-1-P_-0|/(P_-1+P_-0)>=1/3, so

    m_-(E_0^c)<=3TV(P_-0,P_-1)<=3/16.                 (T12)

The four formulas (T6) give

    0<=log(o_+j/o_-j)<=10d/h,
    0<=o_+j/o_-j-1<=20d/h.                             (T13)

For example log(q_+/q_-)<=3d/h; the fourth odds has three such terms and an extra log[(1-q_-t)/(1-q_+t)]<=d/h. Also 10d/h<=10/64<1, so the second inequality follows from exp(x)-1<=2x.

For one Bernoulli coordinate,

    chi2(Ber(p_+)||Ber(p_-))
      =(o_+-o_-)^2/[o_-(1+o_+)^2]
      <=(20d/h)^2 o_+.

Thus

    chi2(P_+0||P_-0)<=exp(400d^2 eta)-1,
    TV(P_+0,P_-0)<=1/32.                               (T14)

The last numerical bound follows from d<=1/64, eta=1/64 and exp(x)-1<=2x: 2*400/(64^3)<1/256. The thinning map is common, so data processing, followed by mixing, gives TV(m_+,m_-)<=1/32.

Let E_z be the event that at least n_00/2 of the 00 candidate outputs are zero. Under m_-, each such success probability is at most p_-(00)<=t. Markov gives m_-(E_z^c)<=2t<=1/128; the weaker 4t<=1/64 also suffices. For E=E_0 intersect E_z,

    sum_(Y in E) min{m_+(Y),m_-(Y)}
       >=1-3/16-1/64-1/32 >=3/4.                      (T15)

### 5.2 A constant posterior-mode gap

On E_z, (T10), the mean-value bound for log, and the exact 00 odds give

    log Lambda_+ - log Lambda_-
      >=(n_00/2) * epsilon * [2d t/(h(1-t))]
                              /[1+epsilon o_+(00)]
      >=d n_00 t/(4h^2)
      >=d M t^3/(16h^2)
      >=Delta:=d tau^3/128>0.                          (T16)

The harmless weakening used 1+epsilon o_+(00)<=2. On all outputs, (T13) gives the matching finite upper control

    0<=log Lambda_+-log Lambda_-
      <=epsilon*(20d/h)*L_+<=10d eta<log 2.            (T17)

Consequently on E both Lambda_- and Lambda_+ lie in [1/2,4]. The logistic map x -> exp(x)/(1+exp(x)) has derivative at least 1/10 on log[1/2,4]. Equations (T16)-(T17) imply v_+-v_->=Delta/10 there. Define

    J(H)=sum_Y min{m_+(Y),m_-(Y)} |v_+(Y)-v_-(Y)|.

By (T15), uniformly for every H in D,

    J(H)>=J_*:=3Delta/40>0.                            (T18)

No sign-of-count threshold, normal approximation or binomial local-limit lemma is needed.

## 6. Enforcing the strict cap without losing the rare endpoint factor

Return to the actual capped channel. Conditional on H and U=1, the uncapped number D_edit of proposed erasures is a sum of independent Bernoulli variables of probabilities epsilon p_qj. On D its mean is at most

    epsilon sum_j p_qj <=epsilon L_+<=h/128.

The standard product-mgf Chernoff calculation gives

    P_q(D_edit>h|H,U=1)<=a_h:=(e/128)^h.              (T19)

Couple capped and uncapped channels with the same raw bits and coins. Their candidate outputs agree unless D_edit>h. Therefore, with P_q1^cap the conditional capped mode-one output law,

    TV(P_q1^cap,P_q1)<=a_h.

Mode zero is unchanged. Let m_q^cap=(P_q0+P_q1^cap)/2 and v_q^cap=P_q1^cap/(P_q0+P_q1^cap). These are the actual mode posterior probabilities before seeing the endpoint output.

For clarity, the needed perturbation lemma is proved directly. If P_1 changes to P_1' with TV at most a, while P_0 stays fixed, set m=(P_0+P_1)/2, m'=(P_0+P_1')/2, v=P_1/(2m), and v'=P_1'/(2m'). Then

    ||m'-m||_1<=a,
    sum_Y m'(Y)|v'(Y)-v(Y)|
      <= (1/2)||P_1'-P_1||_1+||m'-m||_1<=2a.        (T20)

For two source laws, |min(m_+',m_-')-min(m_+,m_-)| is bounded by |m_+'-m_+|+|m_-'-m_-|. Apply the triangle inequality to |v_+'-v_-'| and use min(m_+',m_-')<=m_q'. This proves

    J_cap(H)>=J(H)-3(a_++a_-)>=J_*-6a_h.              (T21)

Choose a finite beta-dependent H_beta so 6(e/128)^h<=J_*/2 for h>=H_beta. Then

    J_cap(H)>=J_*/2,  H in D, h>=H_beta.              (T22)

It is essential to transfer the mode-posterior gap first. A crude unweighted TV transfer of the final future-prediction experiment would subtract a_h from a quantity of order t and would not be uniform as t tends to zero at fixed h. Equations (T20)-(T22) avoid that error.

## 7. Exact endpoint posterior and final lower

On H in D, B=X_(N-1) is Ber(t), independently of (Y,U) conditional on H under either capped or uncapped experiment. This follows from the separated order-two factors; the cap concerns only missing interior candidate bits and independent coins. The endpoint preceding-pair gate is automatically 00 and an edit remains, since there are at most h interior edits and h+1<=k.

Write v_q=v_q^cap(H,Y), T_q=rho v_q, and W=Z_(N-1). Then

    ell_q(1)=P_q(W=1|H,Y)=t+(1-2t)T_q,
    p_q(H,Y,1)
       =P_q(X_(N+1)=1|Z)
       =t+(r-t)t(1-T_q)/ell_q(1).                     (T23)

These are fixed-source posterior targets, not posterior probabilities under a prior mixture over sources. Exact subtraction yields

    |p_+(H,Y,1)-p_-(H,Y,1)|
      =(r-t)t(1-t)rho |v_+-v_-|/[ell_+(1)ell_-(1)]. (T24)

The displayed output mass is f_q(H)m_q^cap(Y)ell_q(1). Since r-t>=r/2, 1-t>=1/2 and max ell_q(1)<=t+rho,

    min{P_+^Z(z),P_-^Z(z)} |p_+(z)-p_-(z)|
      >=(r/4) [rho t/(rho+t)] min{f_+(H),f_-(H)}
           * min{m_+^cap(Y),m_-^cap(Y)} |v_+-v_-|.   (T25)

This retains the mass of the rare W=1 output. It is valid also at rho=0, where its right side is zero. All denominators are positive because t>0.

Sum (T25), use (T9) and (T22), and apply the two-source absolute-loss inequality. For h>=H_beta,

    max_q Risk_q(Q)
       >= (3rJ_*/64) [rho t/(rho+t)]
       >= c_beta min{rho,t}.                           (T26)

Finally h>=min{k,sqrt(M)}/2 for k>=2 and M>=4. The dyadic bracket implies

    t >= c_beta min{(k^2/M)^(1/3),1}.

Since rho<=1, (T26) implies (T1) for h>=H_beta. Enlarge M_beta so floor(sqrt M)>=H_beta. If h<H_beta, then k<=H_beta. The existing independently reviewed one-edit online witness gives c_beta min{rho,M^(-1/3)}, which is at least a fixed beta-dependent multiple of min{rho,(k^2/M)^(1/3)} for this bounded k range. This covers k=1 too.

## 8. Interpretation, resources and limits

The earlier erasure/sign construction spends one edit per hidden rare success and therefore requires M t^3=O(k). Here only a fraction epsilon=Theta(1/h) of successes is erased. A persistent hidden mode changes their output likelihoods enough to retain an O(1) source-dependent mode posterior, while the expected edit count is O(M t^3/h)=O(h). This permits M t^3=Theta(h^2), the offline endpoint scale.

Causality is not a statistical contraction assumption on hidden mode memory. The raw source mixes, but the channel retains U for the whole horizon. That memory is permitted and is paid explicitly; it has only two values. Exact finite-state filtering still cannot treat its posterior as source independent.

The eight-state count excludes the actual k+1 edit counter and public horizon-dependent table. The same channel construction is common to the source alternatives and in fact does not use their design parameters. It is a rational online channel, not an offline normalization or rejection kernel. The witnesses vary with M,k, approach the rare-transition boundary and do not establish fixed-source inconsistency or a positive-transition-floor obstruction.

The source certificate, scaffold identities and mixing-count facts are imported at exactly their already reviewed scope from the rare-one-edit, online-one-edit, rare-budget and growing-budget notes. The novel pieces requiring independent audit are the thinning-mode likelihood ratio, the conditional-overlap argument, the cap perturbation lemma, their endpoint composition, and the improved state/rate claim. No external novelty claim is made.
