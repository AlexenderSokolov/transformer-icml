# Independent analytical review: one-base-state counter lower

Review date and clock check: 2026-11-05 09:14:20 UTC.

## Decision and exact binding

**PASS for the corrected version 2, within its stated statistical and channel scope.** The new endpoint witness proves a lower of order

`c_beta rho min{1,k/sqrt(M)}`

using one base state, the separately paid actual edit counter, a paid time-indexed rational table, and stationary binary sources with a uniform successor-probability floor of 1/4. Together with the existing separate clean and protected witnesses it gives the candidate's general-D2 lower bracket, not a full general S=1 minimax theorem for sub-square-root budgets.

The fully read, independently hashed candidate is:

- `KNOWN_CHANNEL_one_state_counter_lower.candidate.v2.md`
- SHA-256: `81ec5725846233595bfdb803ab92640dc20d419488b68ece2460e99d43a546ce`.

Version 1 was preserved with SHA-256 `cab7c6a22f00ecc89de9174da54bf93017a0f633b61f41ce93d496fe35429da8`. This approval does not bind that uncorrected version. During review, the mixed-neighbor odds identity and its derivative were corrected, and the author supplied the missing exhausted-counter guard at position 1. Version 2 contains both fixes and explicit scope clarifications.

These are present-byte bindings, not inferred historical hashes. No original proof was overwritten by this review.

## 1. Source class, stationary law and observable activation

The source is first-order, hence an admissible special case of an at-most-second-order source. Its pair-chain two-step kernel is `P_a(y|x)P_a(z|y)`, and its stationary pair law is `pi_a(y)P_a(z|y)`. Direct substitution gives a minimum ratio exactly `1-gamma`; with `gamma=(1-beta)/64`, this is at least beta for every fixed `0<beta<1`.

All successor probabilities are at least 1/4 throughout the stated parameter rectangle. The parameter alternatives differ by `2delta`, with `delta=d_0/sqrt(M)`. Their fixed-start tail KL is bounded by a constant times `M delta^2`, since all Bernoulli probabilities stay in a fixed compact interval. No rare transition row or vanishing source-mass floor is used.

The first output is forced to zero only while `e<k`, making the full transition table legal even on unreachable exhausted-counter rows. At the actual initialization `e=0`, this performs one actual edit if and only if `X_1=1`. The activation mode is therefore represented by a real changed coordinate, not a free hidden bit or a relabelled counter value.

The event `Z_2=0` is observable and equals `X_2=0`. Its probability is at least 1/2. The stationary calculation is exact:

`P_a(X_1=1 | X_2=0) = pi_a(1)(1-a-gamma)/pi_a(0) = a`.

Thus the mode prior is source-dependent, equal to a. It is not incorrectly held common between the two alternatives. Conditional on `X_2=0`, the first-order Markov property makes the complete later raw tail independent of the activation mode. This conditional independence, not an unconditional independence claim, is what the proof uses.

## 2. One-state implementation and strict counter accounting

The channel's rows use only public time, the current raw input and the actual edit counter. It never reads a previous raw symbol or stores a gate outside that counter. A counter-zero path remains inactive forever after position 1. A counter-positive path starts at one, permits at most h candidate erasures, and retains one endpoint edit because `h<=k-2`.

Every counter increment equals an actual raw/output disagreement. Consequently the total is at most `h+2<=k` on every input and coin realization. The endpoint guard is satisfied on every reachable active path, even after the interior cap is attained. Therefore the per-word endpoint-change probability is exactly rho when `X_1=1` and zero otherwise. Only the final historical bit is edited at that endpoint; no future innovation is consulted.

The table is rational and normalized, including unreachable counter rows. The alpha in `epsilon=alpha h/M` is a fixed paid rational constant. The source parameter a does not appear in the table. The resource ledger retains the actual `k+1` counter values and full time expansion. One base state does not mean one total state or a time-homogeneous machine.

## 3. Scaffold factorization and the corrected odds

Candidate sites are nonadjacent and are separated from the final raw bit B by a retained neighbor. No first-order likelihood factor contains two missing bits. Hence conditional on the recoverable scaffold the missing candidate bits and B are independent. The candidate probabilities are generally not identical.

I independently multiplied the two factors at each candidate. The correct mixed-neighbor identity is

`o_a(1,0) = o_a(0,1) = (a+gamma)/(1-a)`.

This equality was wrong in version 1 and is corrected in version 2, together with its logarithmic derivative. The remaining two odds formulas are correct. On the stated rectangle, their bounds `1/4<=o<=1` and `2<=d(log o)/da<=14` hold with slack. Thus the probabilities lie in `[1/5,1/2]` and all odds increase uniformly between the alternatives.

For the terminal bit, the exact conditional probability is `p_a^B=a+gamma X_(N-1)`. Its retained predecessor is observed, and it is independent of the candidate bits and mode after conditioning on the scaffold and activation branch.

## 4. The capped likelihood polynomial is exact

For a fixed candidate display Y, an actual erasure set E is a subset of its zero positions and has size at most h. The raw candidate word is uniquely determined by E and Y. Its product-law probability divided by that of Y is exactly the product of the odds at E.

All remaining factors are channel probabilities determined by E, Y, the fixed epsilon and the chronological cap. These factors may depend on the order in which the cap is reached; they do not depend on a. Consequently the nonnegative polynomial representation in (A6) is valid for the actual capped law, with an everywhere-positive empty-set coefficient.

Under the minus alternative, the normalized polynomial terms are the posterior distribution of the actual erasure set in active mode. Taking the ratio of the two polynomials gives the expectation of the product of their odds ratios. Jensen's inequality then gives the lower log gap `4delta r_-(Y)`, while the degree bound h gives the upper gap `28delta h`. These inequalities hold for every displayed candidate word, without pretending that the capped law is an uncapped law conditioned on an edit-count event.

This exact argument is important because the target gap can tend to zero with M. The proof does not subtract a fixed cap-total-variation error from that small gap.

## 5. Erasure-weighted overlap and constants

Under the preassigned-coin coupling, the actual capped erasure count equals `D_h=min(D,h)`, where D is the independent proposed-erasure count. The bounds on candidate probabilities and count give `alpha h/20<=mu<=alpha h`. The factorial-moment inequality used in (A8) gives an expected actual count at least `alpha h/40`. For `h>=1/alpha`, the second moment is at most `2alpha^2 h^2`.

The uncapped active product law has total-variation distance at most `C alpha h/sqrt(M)<=C alpha` from the inactive law. The cap coupling adds at most `(e alpha)^h`. This use of total variation controls overlap and weighted moments, not the final vanishing target gap.

The likelihood-ratio test controls active probability outside `1/2<=Lambda_-<=2` by `C alpha`. Cauchy-Schwarz with the actual-count second moment then loses only `C alpha^(3/2)h` from the expected count. Choosing alpha sufficiently small retains the claimed order `alpha h` weighted mass on this overlap set.

The conditional raw product laws under the two alternatives differ in total variation by at most `C delta sqrt(n)`. Applying the same capped channel preserves that bound. The difference of the mode priors contributes at most `2delta` in total variation and is explicitly charged. Since `r_-<=h`, choosing `d_0` sufficiently small after alpha gives (A12).

On the overlap set, the posterior mode odds remain in the stated fixed interval. The prior log odds increase with a, in the same direction as the polynomial likelihood ratio. The logistic derivative bound 1/16 therefore gives the displayed posterior gap and the exact constant `alpha d_0 h/(2560 sqrt(M))` in (A13).

The choices can be ordered consistently: choose a sufficiently small fixed dyadic alpha, choose a still smaller d_0, choose a finite H large enough for the moment/cap estimates, then take M large enough. Constants are uniform over scaffolds, h in the large-h range, rho and M. No assumed iid candidate law or terminal/count independence is used.

## 6. Actual endpoint target and full observation overlap

With `T_a=rho v_a`, the formulas for the W=0 observation mass and the posterior terminal bit are exact. The denominator is uniformly at least 1/4. The displayed derivatives of F are correct, and `dF/dT>=1/4` is conservative in the stated parameter range.

Both the conditional raw terminal probability and the posterior activation probability increase with a. The direct change in the future row's intercept a therefore cannot cancel the endpoint-mixture gap. This sign property is necessary and is supplied explicitly, rather than inferred from an absolute-value inequality.

The complete retained output mass is `b_a f_a(H)m_a(Y)ell_a(0)`. The branch factor is at least 1/2, the endpoint factor is at least 1/4, the scaffold overlap is at least 3/4 by the fixed-start KL comparison, and the conditional candidate overlap is the weighted functional already bounded for every H. Thus no rare or source-dependent observation factor is dropped. The two-source absolute-loss inequality proves (A15) for the actual source-specific posterior target.

The calculation remains valid at rho=0 and rho=1. At rho=0 the extra endpoint lower is zero, leaving the separate clean/protected witnesses. The proof requires fixed beta strictly below one: gamma is positive, and the endpoint lower constant is not asserted uniform as beta approaches one.

## 7. Budget ranges and the general S=1 bracket

For `h>=H`, h is a fixed multiple of `min(k,sqrt(M))`. When h is smaller and the horizon is sufficiently large, k is bounded by a fixed constant. The clean one-state lower absorbs the requested endpoint expression in that range, including k=1 and k=2. The thinning formula is not evaluated with h=0.

Taking the maximum with the already reviewed clean and protected-budget witnesses yields the candidate's general-D2 lower bracket. The witnesses are separate; their budgets are not added. For `k>=sqrt(M)` it matches the existing general upper up to fixed-beta constants, because both endpoint terms reduce to rho. In the principal sub-square-root range, the proposed general lower and upper need not match. Neither a full S=1 profile nor a separation from S>=2 is proved.

The new endpoint witness has a fixed transition floor of 1/4. The imported protected k/M witness, however, was proved in the broader D2 class and can have vanishing transition probabilities. Its import is not a proof of the whole displayed bracket in every fixed-floor subclass. Version 2 now states this distinction explicitly.

## 8. A limited matched fixed-floor corollary

Combining only this endpoint witness and the clean iid witness with the already independently reviewed positive-floor upper gives a further valid, limited consequence: for binary sources, any fixed public floor `0<eta<=1/4`, and `rho=1`, the one-base-state minimax rate is

`Theta(min{1,(k+1)/sqrt(M)})`

for the stationary fixed-floor class. The same conclusion holds after intersection with a fixed `D2(beta)` class for `0<beta<1`, with allowed constants depending on that class. The upper applies to all disclosed strict-k future-blind channels, so in particular to this one-state subclass. Both lower witnesses satisfy the floor and the stated D2 condition. No protected-budget term is needed for this corollary.

This is a consequence using an existing upper, not a new audit of that upper. The inspected upper and its prior review bind respectively to:

- `KNOWN_CHANNEL_uniform_positive_floor_upper.md`: `93379139b31483502d4b6d9efdda02b3f122f592c8cec7274e83d36696b09b5b`.
- `KNOWN_CHANNEL_uniform_positive_floor_upper_independent_review.v1.md`: `663a2e10536411b0c34cc4b03cd864de06161da1bb999c92cde1b3835f4acbf1`.

This corollary is not asserted for every floor below 1/2 without adapting the present source construction, and the floor 1/2 itself is degenerate. It also does not settle the sharp rho dependence for the fixed-floor class or the unrestricted D2 class.

## 9. One-edit hazard appendix

For a binary one-base-state channel with a genuine one-edit counter, the no-edit preimage probability is the product of survival probabilities. The preimage changed at j has survival factors only before j, its flip hazard at j, and identity afterward because the cap is exhausted. The formulas (A16)-(A17) follow directly and remain valid with zero hazards or zero survival factors.

This reduction assumes the stated finite-state kernel interface: no additional uncharged persistent random memory is allowed outside the actual counter. It does not by itself bound the source likelihood ratios or posterior prediction error, and therefore does not establish a general S=1 upper.

## Review method and limits

Pure mathematical reconstruction, document inspection, private review writing and cryptographic hashing. No scientific executable tests, simulations, numerical experiments, model execution, public writes or external novelty investigation. No training, finite-precision, neural realization or homogeneous finite-state claim follows from this review.
