# Independent analytical review: rare-event binary one-edit lower

Date: 2026-11-05 UTC. Present-time clock check: 04:59:38 UTC; the final candidate digest and clarified all-state argument were checked immediately afterward.

## Finding and exact file binding

The one-edit lower is valid. I found no substantive gap in (R1)-(R18), including the source-dependent stationary initialization, all-state minorization, rare-event variance estimate, exact endpoint conditioning, branch identification, and uniformity in rho.

Reviewed candidate:

    KNOWN_CHANNEL_stationary_binary_rare_one_edit_lower.v1.md
    SHA-256: 49915c863da95d1b139c467c686aee5cf65a5bd408ad9ec762ed8c7408ad88c9

The complete proof was read. The final clarification splitting the target-00 minorization check by the second starting coordinate was rechecked. The author confirmed that the file is frozen. This is a present-time binding, not a historical digest assertion.

For each fixed 0<beta<1, the proof establishes c_beta rho M^(-1/3) at a strict budget of one edit, for every sufficiently large M uniformly over rho in [0,1]. In particular, fixed rho>0 rules out an unrestricted stationary binary O((k+1)/sqrt(M)) upper already at k=1.

This is a decaying lower, not a constant one-edit floor. It remains consistent with the binary consistency threshold and with the existing power-1/3 upper in (k+1)/sqrt(M). The fixed-positive-transition-floor rate is not contradicted, because this construction's transition floor tends to zero.

This was mathematical analysis only. Tools were used for document inspection, file hashing, and writing this review. No scientific executable checks, numerical experiments, public writes, novelty certification, or formal verification occurred.

## 1. Exact stationary law

For theta_00=theta_01=t, theta_10=r and theta_11=q t, the two balance equations in the candidate are correct. Together with normalization they give exactly (R3). Equivalently, with

    D=(1-r)(1-q t)+2t(1-q t)+t^2,

the pair masses are

    Pi00=(1-r)(1-q t)/D,
    Pi01=Pi10=t(1-q t)/D,
    Pi11=t^2/D.

These are the individual sources' own stationary laws; no common or arbitrary initial distribution is substituted. Every transition is strictly positive at each finite horizon, so the stationary pair law is unique. The first context coordinate has a real effect because t<r, making the family genuinely order two.

The stationary minority-symbol mass is O_beta(t). The rare pair 11 has mass of order t^2, which is the relevant information scale later in the proof.

## 2. All-state minorization

I checked all four target-pair ratios, including the potentially restrictive 01 and 11 cases. For target 00, the second starting coordinate matters: when it is zero, the relevant successor-one bounds are r and t; when it is one, they are q_max t and r. This yields the stated product lower.

For target 01 and second starting coordinate zero, division by Pi01 gives (1-theta_s(1))(1-r)/u, at least (1-r)^2. For second coordinate one, the additional r/t factor is at least one, while 1-theta_s(1)>=1-r. The 10 and 11 bounds follow from the lower successor-one floor q_min t and the explicit target masses.

Their common lower product is valid. Since r=4d and q_max t<=d, the elementary product bound gives at least 1-11d, which is strictly greater than beta=1-64d. This verifies the all-state condition uniformly, rather than only on likely contexts or in a limiting approximation.

The assumptions tau<=d/4 also give t<=r/16, so all later uses of t<=r/2 and t<=1/2 are justified.

## 3. Clean-law overlap with source-dependent initialization

Only row 11 changes between the hypotheses. Its conditional Bernoulli KL is O(d^2 t), and its stationary occupation probability is O(t^2). The exact stationary chain-rule expression therefore gives O(d^2 M t^3)=O(d^2 tau^3), as in (R5).

The initial-pair term is retained, not omitted. All four coordinate likelihood ratios from (R3) tend to one, including the rare 11 coordinate, so its KL tends to zero. Choosing tau small enough and then a sufficiently large horizon yields the full-clean-word TV bound of 1/8. These choices are independent of rho.

The retained H is a common deterministic function of the full clean word. Its definition includes the unedited final symbol, so using full-word rather than prefix overlap here is correct.

## 4. Exact rare-bit and terminal factorization

The candidate spacing ensures that no historical likelihood factor contains two eligible bits. Their four eligibility neighbors are retained and the candidate range excludes all factors involving the penultimate latent bit B. Conditioning on H thus factors the eligible bits and B independently.

For the 11?00 scaffold, the candidate-one and candidate-zero weights are exactly

    (q t)(1-q t)(1-r),
    (1-q t)(1-r)(1-t).

Their cancellation gives p_q=q t/[1+(q-1)t] and odds q t/(1-t). No approximation is used.

On the terminal event A, the two weights for B are t(1-t) and (1-t)^2. Their normalized prior is exactly Ber(t), shared by both sources. The next-row values are exactly t and r because the retained final symbol is zero. This shared prior and shared pair of future rows remove the nuisance parameter-replacement term that was needed in the previous positive-floor construction.

## 5. One edit, not two

The branches are mutually exclusive. Count one causes a single interior erasure and no endpoint operation. Count zero causes no interior operation and at most one penultimate-bit flip. Every other input is left unchanged. Thus the maximum realized Hamming cost is truly one, not an expected cost or the composition of two separate edits.

The terminal pair changes only on the count-zero branch and with probability rho there. This is the required per-input bound. The channel's rule uses no unknown source sign or future innovation.

H, its eligible mask, n, and the terminal scaffold A remain recoverable and unchanged. An input failing A cannot enter A. An input with n=0 cannot become one with n>=1. On A and n>=1, an untouched count at least two cannot equal the branch's displayed zero count. Therefore the output identifies S<=1 exactly, with no hidden collision from an identity branch.

Conditional on that output branch, B remains independent of the original count and has prior Ber(t). The mixture flip probability is exactly T_q=rho/(1+q a). This gives the output masses and posterior formulas used in (R9)-(R12). The only source parameter averaged in the actual target is the latent clean endpoint, not a prior over q.

## 6. Rare-event concentration is strong enough

The eligibility probability is exactly Pi11(A_q+B_q), which simplifies to u_q t^2[1+(q-1)t]. Consequently E n/(M t^2) tends to 1/3.

The variance refinement in (R14) is essential and valid. For overlapping five-symbol windows, absolute covariance is bounded by the probability of one eligibility event, O(t^2). For separated windows, conditioning at the end of the earlier window gives a future-event discrepancy bounded by the pair-chain mixing coefficient. Multiplication by the earlier event's probability supplies the same O(t^2) factor before summing the geometric lags.

Thus Var(n)<=C_beta M t^2, rather than merely O(M). Since M t^2=tau^2 M^(1/3) diverges, the interval T has probability tending to one. A union bound using the stationary minority mass gives P(A^c)=O(t). Combining this high-probability scaffold event with full-word TV at most 1/8 yields the 3/4 scaffold overlap in (R15).

No independence between the terminal scaffold and the count concentration event is assumed.

## 7. Uniform-rho separation and final constant

On T, a lies in the fixed interval [tau^3/4,tau^3]. The difference v_- - v_+ and the quantity 1-v_q therefore have positive beta-dependent lower bounds. For example, valid choices are

    b_beta=d tau^3/[2(1+q_max tau^3)^2],
    b'_beta=q_min tau^3/[4(1+q_max tau^3)].

The bound p_q<=2t and n p_q<=tau^3 gives g_q>=exp(-2tau^3). Also T_q=rho v_q<=v_q, so

    ell_q(0)>=(1-t)(1-v_q)>=b'_beta/2

holds even at rho=1 and uniformly as rho tends to zero. This avoids a vanishing-denominator or moving-rho horizon issue.

The exact posterior subtraction gives a gap at least t(1-t)rho b_beta. Multiplication by r-t yields the stated target gap r b_beta rho t/4. Combining the overlap factors and dividing the risk-sum inequality by two proves the lower. With ell_*=b'_beta/2 and g_*=exp(-2tau^3), one may take the final coefficient no larger than

    3 r b_beta g_* ell_* tau/32,

after increasing the horizon as required earlier. It is strictly positive for fixed beta<1 and independent of rho.

## Scope retained

- The source is stationary, binary, and genuinely order two, with its correct source-dependent initial law.
- The known channel is offline within the available history but future-blind; its seed, branch and edit location are not revealed.
- The source sequence has vanishing transition and stationary minority probabilities. It is excluded by a fixed positive transition floor.
- The bound tends to zero and does not contradict uniform consistency at a fixed one-edit budget.
- It refutes the proposed unrestricted linear rate for fixed rho>0, but does not by itself establish a matching upper or the general-budget formula.
- No exact observational nonidentifiability, fixed-source inconsistency, efficient algorithm, neural realization, or prior-art originality is certified.

The separate general-budget candidate requires and receives its own review; its additional bin lemma is not assumed in this one-edit audit.
