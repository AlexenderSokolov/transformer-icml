# A paid finite-state posterior-to-Transformer bridge

5 November 2026 UTC. Analytical construction candidate. No scientific executable checks, numerical experiments, formal verification, or public writes. This note supplies a deliberately conservative polynomial upper construction, not an optimal resource claim. Independent review is requested separately.

## 1. Result and exact scope

For the disclosed rational finite-state channel interface in `KNOWN_CHANNEL_computational_interface_audit.v1.md`, the fitted posterior in its equation (C8) can be approximated uniformly on all channel-supported displayed words by a bounded-score causal ReLU Transformer with polynomial paid resources.

The input is exactly N displayed binary-symbol one-hots, the public scalar position p_t=t/P with P=2^ceil(log2(N+1)), and one synthetic zero-symbol row at T=N+1. There is no clean history, source parameter, realized channel seed, edit mask, lagged-token input, count oracle, or likelihood oracle. The channel is compiled into the network and its entire description and compilation are charged. The network is an untied, public-(N,C,r)-dependent family.

The mask is self-inclusive causal, s<=t. There is one ordinary softmax head per block, all eligible scores exactly zero, a residual two-layer ReLU FFN of width 2d, no LayerNorm/RMSNorm, and no final vocabulary softmax. A norm-one coordinate projection selects the final two probability coordinates (q,1-q).

Let S count channel states, including the endpoint gate if used but excluding the separate edit counter. Let ell be the total bit length of the expanded rational initial distribution and effective time-indexed channel tables, including an explicit counter dependence when present. A homogeneous table reused N times is counted N times in this definition; a compact encoding requires charging its expansion or replacing this denominator bound by one reflecting repeated use. Put

    R = O(N S^2(k+1)),
    r >= 1,  epsilon = 2^-r,
    B = ell + 4(N-1) ceil(log2 N) + ceil(log2(N+2)) + r + 4,
    G = O((R+N+1) B^2).

There is a construction with

    d = O(G),
    L = O(G + N log(N+1) + r + log(G+1)) = O(G).

All per-matrix operator norms, bias norms, and reached per-position hidden-state Euclidean norms have absolute bounds independent of N,S,k,ell,r. Attention-score gaps are zero. Each parameter has O(log(N+1)+log(G+1)) rational-description bits. The terminal output satisfies

    |q(z)-q_C^fit(z)| <= 2^-r

whenever the fitted evidence is positive, and both predictors use 1/2 on zero evidence. Exact rational evaluation of this specially constructed network uses O(r+log(N+1)+log(G+1)) bits per scalar. This is not a statement about unmodified IEEE/GPU execution.

Width grows polynomially. This construction therefore does not establish the earlier fixed-K constant-width promise, a tied-weight model, length generalization of one fixed network, training achievability, or an optimal/necessary depth. It preserves the common raw-information and bounded-local-norm interface while paying a much larger width and depth ledger.

## 2. Channel, source, and hard-budget contract

The source-side fitted law is exactly the positive law from `KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md`, with M=N-2 and displayed triple/context counts:

    theta_hat_u(c) = (C'_uc+1)/(J'_u+2),
    Pi_hat(u) = (J'_u+1)/(M+4).

Pi_hat is not asserted stationary for theta_hat, and is not claimed to estimate an arbitrary unknown initial-pair law from one trajectory. This note evaluates that specified fitted law. Its statistical use imports only the existing stationary D2(beta) theorem, not an all-initial-law extension.

All channel randomness is independent auxiliary randomness relative to the entire source process; conditional choices follow the supplied kernels. In particular X_(N+1) and Z are conditionally independent given X_1:N. The disclosed channel has rational initialization mu(s), and normalized rational transition rows

    K_i(s',z | s,x,e).

The edit count updates deterministically to e+1{x!=z}; no transition with count above k is permitted. A forbidden edit is redirected to the matching-symbol output while retaining the selected next base state, exactly as in the computational-interface audit. Simply zeroing forbidden mass or conditioning an unconstrained channel is not this channel.

One sufficient endpoint certificate samples G_end~Ber(rho_g), independently of the source, at initialization, stores this gate in s, and permits changes at N-1,N only when G_end=1, where the supplied rational rho_g<=rho. Thus, for every fixed clean word, the probability of any endpoint change is at most rho_g. The hard counter and endpoint gate are separate mechanisms. All tables are source-independent, use only the current clean input and current channel state, and cannot depend on the future innovation X_(N+1).

This row-stochastic one-pass class is online causal within the observed word. It is a strict subclass of the statistical theorem's future-blind class, which may inspect all N clean symbols before producing the displayed word. No terminal acceptance/rejection factor or global conditioning is included in the present subclass.

The construction also works for any supplied effective normalized tables with a separately verified strict-k and endpoint certificate. Certification is an assumption or separately charged work. Arbitrary offline channels, free likelihood oracles, uncharged table storage, and short programs without runtime bounds are outside this theorem.

If one starts from a smaller counter-independent base table, its redirected/counter-augmented table can be generated and charged separately. The bound above safely uses the full supplied effective description. Counter states are not counted twice.

## 3. Exact denominator-cleared dynamic program

For the channel initial distribution choose Q_0 equal to the product of its supplied denominators. At time i choose Q_i equal to the product of the supplied denominators of all effective K_i entries. Products rather than least common multiples suffice. Define integer coefficients

    m_s = Q_0 mu(s),
    k_i(s',z | s,x,e) = Q_i K_i(s',z | s,x,e).

If ell includes all denominator bits, then

    log2 Q_0 + sum_i log2 Q_i <= ell.

The integer tables may be larger than the original rational representation; their compilation and storage are charged below.

For the fitted source set d_u=J'_u+2 and

    Q_theta = product_(u in {00,01,10,11}) d_u,
    t_uc = (C'_uc+1) product_(v!=u) d_v,
    Q_Pi = M+4 = N+2.

Then theta_hat_u(c)=t_uc/Q_theta, Pi_hat(u)=(J'_u+1)/Q_Pi, and Q_theta<=N^4.

Initialize integer masses on a pending clean pair (a,b), channel state s and e=0 by

    beta_0(a,b,s,0) = (J'_(a,b)+1) m_s.

For positions 1 and 2 propagate respectively using clean symbols a and b and the integer channel transitions. For i>=3 use

    beta_i(b,c,s',e') += beta_(i-1)(a,b,s,e)
                           t_(a,b),c k_i(s',z_i|s,c,e),
    e' = e+1{c!=z_i} <= k.

The common denominator at time i>=2 is

    D_i = Q_Pi Q_0 product_(j=1)^i Q_j Q_theta^(i-2).

Consequently beta_i/D_i equals the ordinary fitted forward probability exactly. The sum of all alpha_i=beta_i/D_i is the probability of the displayed prefix and is at most one. Every beta_i, every nonnegative partial sum, and every update product is bounded by the corresponding full common denominator. The initial and first-step formulas use the same argument without Q_theta factors.

At the end set

    D = sum_(a,b,s,e) beta_N(a,b,s,e),
    A = sum_(a,b,s,e) beta_N(a,b,s,e) t_(a,b),1.

For D>0 the fitted posterior is exactly A/(Q_theta D). Its numerator and denominator are at most

    Q_Pi Q_0 product_i Q_i Q_theta^(N-1).

Thus O(ell+N log(N+2)) bits suffice for all exact integer DP arithmetic. There is no inverse-evidence factor hidden in this bit bound. Extremely small positive evidence is represented by an integer numerator and a polynomial-bit common denominator.

Return

    q_r = 2^-r floor(2^r A/(Q_theta D))

when D>0, and 1/2 when D=0. Include the possible integer bit q_r=1. The error is less than 2^-r on positive evidence. The fitted clean-word law has full support, so any output having positive probability under the true source and this channel has positive fitted evidence.

The counter increment is deterministic, so there are O(NS^2(k+1)) nonzero-form update slots, not a dense counter-to-counter factor (k+1)^2. Initialization and final summation fit this order. Working memory for an ordinary rolling arithmetic evaluator is O(S(k+1)B) bits plus its tables and displayed data.

## 4. A polynomial Boolean circuit, with no free rational decoder

The displayed counts use O(N log(N+2)) elementary Boolean gates. Source denominators, the fourfold Q_theta product and the t_uc values use polynomially many gates on O(log N)-bit integers. The DP has O(R) nonnegative additions/multiplications on O(B)-bit integers. Schoolbook multiplication and long division have O(B^2) Boolean-gate implementations over a fixed fan-in-two basis. A zero-denominator test and multiplexed 1/2 fallback are included.

Before division, replace Q_theta D by the positive dummy denominator 1 when D=0; the output is then selected to be 1/2 on that branch. Thus no circuit invokes division by zero. Unroll these finite loops, including the guarded final division of 2^r A by Q_theta D, into a Boolean circuit. Its number of gates and total input/constant/output wires can be bounded by

    G <= c (R+N+1) B^2

for an absolute c, after padding G>=N ceil(log2(N+1))+r+1. The channel integer tables occur as charged constant bits. The circuit outputs the r fractional bits and possible integer bit of q_r. It does not output an exact arbitrary rational by a free division/projection oracle.

## 5. Recover every raw token using bounded zero-score attention

Let H=ceil(log2 T), P=2^H. At source row t and for one fixed public i in {1,...,N}, compute

    delta_i(t) = |p_t-i/P|.

Apply x<-min{1,2x} exactly H times. The result is zero at t=i and one at every other row, since distinct positional scalars differ by at least 1/P. Its complement m_i(t) is therefore the exact positional equality indicator. No coefficient P is placed in a matrix: amplification is paid as H bounded-coefficient layers.

If z_t denotes the symbol-1 coordinate, use the ReLU AND

    v_i(t) = ReLU(z_t+m_i(t)-1).

At the synthetic row z_T=0. Thus v_i has one possible nonzero entry, exactly z_i at row i. A causal zero-score head gives at row t

    a_i(t) = 0                         for t<i,
    a_i(t) = z_i/t                     for t>=i.

Apply the same H clipped doublings. Since P>=T>=t, this is exactly zero for t<i and exactly z_i for t>=i. This recovery is exact at every row, not just the terminal row.

Store the recovered bit at a small fixed amplitude h in a fresh wire coordinate and clear the constant-sized scratch. Repeat for i=1,...,N. It takes O(N log(N+1)) blocks. At row t the stored input is the Boolean vector consisting of the observed prefix through min(t,N), padded with zeros. At T it is exactly the displayed word.

All scratch values have bounded magnitude. Each stage is an affine/ReLU primitive with bounded coefficients on only a constant number of coordinates, and can be implemented by a constant number of canonical residual blocks. An attention block injects the uniform mean into a previously zero scratch coordinate, then the FFN copies/resets it. No uncontrolled residual accumulation occurs.

## 6. Scaled serial Boolean gates and rowwise norm control

Choose d large enough for all G circuit wires, the input bank, the probability output and a constant number of scratch registers, and put

    J = ceil(log2 d), h=2^-J.

A Boolean wire is encoded as 0 or h. Initialize constant circuit bits with biases 0 or h. Their entire bias vector has norm at most sqrt(d)h<=1. The raw input bank from Section 5 is in this encoding at every row.

One fresh AND gate is

    wire_c = ReLU(wire_a+wire_b-h),

and one fresh NOT gate is

    wire_c = ReLU(h-wire_a).

The target coordinate begins at zero, so residual addition writes it exactly. AND and NOT form a complete Boolean basis. Process one gate per block. In that block W1 has only one active gate row with at most two unit input coefficients; W2 has only one active unit output coefficient. Matrix norms are therefore bounded by an absolute constant. Reusing a wire in later layers does not create a simultaneous fanout norm. The FFN can be padded to width 2d. Its attention has zero V/O.

All wires are 0/h at every row by induction, since the intake supplies exact bits at every row. Their collective Euclidean norm is at most sqrt(d)h<=1. Together with the unchanged raw one-hot, positional scalar, bounded scratch and two final probability coordinates, the whole per-position hidden-state norm is bounded by one absolute constant. The construction does not rely on a terminal-only bound.

Accumulate the output bits into a single h-scaled dyadic probability by a serial binary Horner recurrence with coefficient 1/2, incorporating the possible integer bit. This uses O(r) bounded pointwise stages. Apply J ordinary doublings to that accumulator. Its value never exceeds one because its final value is q_r in [0,1]. A final affine complement produces 1-q_r. This costs O(r+log d) layers and uses no large final projection coefficient.

These facts give d=O(G), L=O(G+N log N+r+log G), absolute per-matrix/bias/state bounds, zero attention scores, and the asserted simplex output.

## 7. Paid representation, compilation and exact bit evaluation

Channel access: no oracle is supplied at runtime. The rational tables are compiled into Boolean constants/topology. If instead a program generates those tables, its description, runtime and generated output must all be added. Efficient sampling alone is not sufficient.

Table preprocessing: products Q_i and exact divisions Q_i/denominator construct the integer coefficients. Using schoolbook arithmetic, O(ell^3) bit operations is a conservative bound, with O(ell^2) bits of generated integer-table storage. This is in addition to processing the public N,S,k,r parameters. The larger Boolean bound G already dominates the generated constant-wire count.

Network description: each rational coefficient has O(log(N+1)+log(G+1)) bits, consisting of small integer coefficients, position centers i/P, and h. A sparse serial instruction description uses O((G+N log N)(log(G+1)+log(N+1))) bits including addresses; the channel's original table bits must not be omitted when reporting total input/storage. Explicit canonical dense matrices require

    O(L d^2 (log(N+1)+log(G+1)))

bits, including their zeros. Emission of that representation costs at least its output length. A straightforward bit compiler can emit it in polynomial time in N,S,k,ell,r; no truth-table enumeration of 2^N words is used.

Exact scalar precision: during intake, position gates use dyadics with denominator P, a useful attention stage averages exactly one marked 0/1 value and thus has denominator t<=T, and clipped doublings restore exact bits. All later circuit wires are exactly 0/h, and the output accumulator has denominator dividing 2^(J+r). Scratch is cleared between intake rounds. Hence the actually reached scalar rational values have numerator/denominator lengths

    w = O(r+log(N+1)+log(G+1)).

The bit length B of DP integers is represented spatially as Boolean wires, not stored in an uncharged real activation. This distinction is essential.

An exact rational evaluator can compute exp(0)=1 symbolically, perform ordinary causal averaging exactly, and perform its rational affine/ReLU arithmetic exactly with widened temporaries. Reduced rational arithmetic on O(w)-bit operands has a conservative O(w^3) bit bound using schoolbook integer arithmetic and a naive Euclidean reduction bound. Thus a conservative dense all-block execution bound is

    O(L (T d^2+T^2 d) w^3)

bit operations, plus input/parameter reads and initialization. Rolling activation storage is O(T d w) bits; materialized scalar attention weights add O(T^2 w). Untied dense parameter storage is as displayed above. Sparse execution or a sharper arithmetic model can improve these deliberately loose bounds, but is a different stated evaluator.

This is an analytical exact-rational implementation specification. It is not execution evidence, a machine-conformance certificate, or a floating-point stability theorem.

## 8. Statistical composition and boundaries

The deterministic approximation inequality immediately gives

    E|q_r(Z)-p_(theta,C)(Z)|
       <= E|q_C^fit(Z)-p_(theta,C)(Z)|+2^-r.

The posterior alone is not the entire log-free estimator: the existing theorem uses a majority branch on low observed minority frequency and a trivial branch in the saturated regime. These rational/count decisions and the majority output can be included in the Boolean circuit with polynomial cost when their public threshold constants are supplied with a computable certificate. The posterior bridge itself is beta-free; any varying-beta constant representation and constant-selection costs must be added for the full statistical estimator. For example, a supplied rational A_beta allows the cubic majority-threshold comparison to be evaluated by integer arithmetic rather than an irrational cube-root oracle. If constants are only existentially specified, the resulting family is likewise only nonuniformly specified until a paid constant-selection procedure is supplied.

With that stated input, the existing stationary log-free statistical upper transfers to this finite-state subclass with additive 2^-r. The full rho interpolation also requires its other estimator and public branch selection to be implemented with their own rational/approximation accounting; this note does not silently replace those obligations by the posterior branch. The binary clipped empirical estimator is elementary rational arithmetic when beta is rational, but arbitrary-real beta needs an explicit representation or approximation contract.

No matching minimax lower for bounded-state channels is proved. The arbitrary one-edit channel obstruction remains valid outside this finite-state interface. This result does not show that all disclosed channels are efficiently representable, nor that the original rare-normalization lower channels lie in this subclass. It proves one paid, explicit polynomial resource bridge in an intentionally broad growing-width architecture.

## 9. Sources directly used

1. `KNOWN_CHANNEL_computational_interface_audit.v1.md`, Sections 7-9: fitted posterior, normalized hard counter, independent endpoint gate and finite-state forward recurrence.
2. `KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md`, Section 3: the precise fitted Pi_hat/theta_hat law and statistical majority/posterior branches.
3. `KNOWN_CHANNEL_stationary_binary_rho_interpolation.v1.md`, Sections 2-3: the scope of the imported stationary statistical theorem and distinct estimator-selection obligation.
4. `../shared/integrated_bounded_transformer_theorem_20261104.v2.md` and `../shared/original_input_scope_audit_20261104.md`: common raw-token/position/synthetic-query interface, causal mask, canonical residual architecture, norm restrictions and interpretation boundaries.

The serial marked-token intake and scaled Boolean-circuit construction are derived analytically in this note, rather than imported as a theorem about a different arithmetic or input interface.
