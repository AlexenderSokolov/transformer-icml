# Independent analytical review: minority-weighted relative upper

Date: 2026-11-05 UTC. Present-time clock check: 05:10:33 UTC; the final candidate digest was checked immediately afterward.

## Finding and exact file binding

The improved upper is valid. I found no substantive gap in (U1)-(U14), including the regenerative rare-occupation lemma, bounded random stopping, last-cycle overshoot, Freedman event argument, channel-adaptive count transfer, data-dependent posterior, or minority-weighted integration.

Reviewed candidate:

    KNOWN_CHANNEL_stationary_binary_relative_upper.v1.md
    SHA-256: eae022b6aaab82c16014afb1047a91d49e20d7ef1f4fda4425d3c3d000041b3a

The complete proof was read. The final scope clarification in section 7 was rechecked, and the author confirmed that the file is frozen. This is a present-time binding to the exact current candidate, not a historical digest claim.

The theorem gives

    min{1,C_beta[((k+1)^2 log(eM))/M]^(1/3)}

uniformly over stationary binary D2(beta), fixed beta>0, and all disclosed future-blind strict-k-edit channels. It supplies no rho dependence and imposes no fixed positive transition floor.

For fixed beta in (0,1), fixed rho>0, and k>=1, it is within a factor of order (log M)^(1/3) of the reviewed rare-budget lower in the nonsaturated regime. This is not an exact sharp-rate theorem or proof that the logarithm is necessary. The beta=1 and k=0 comparisons are correctly separated.

This was mathematical review only. Tools were used for document reads, file hashing, and writing this review. No scientific executable checks, numerical experiments, public writes, novelty certification, or formal verification occurred.

## 1. Regeneration really has stationary cycle paths

The lemma assumes the specific minorization K>=beta Pi, where Pi is the stationary law. For beta<1, the residual Q=(K-beta Pi)/(1-beta) is stochastic and preserves Pi. This latter fact is crucial: it would not follow from an arbitrary unrelated minorizing distribution.

Starting a fresh cycle from Pi and taking an independent geometric number L of states of the Q-chain produces the correct K-chain when cycles are concatenated. The first cycle may also start at a fresh regeneration because its initial state is Pi; the resulting forward path has exactly the required stationary initialization and transition kernel. No equilibrium residual-life construction is needed.

Cycle length is independent of its Q-path. Conditional on L, every state in that path has marginal Pi, so E[Z|L]=0 for the centered reward. The complete cycles, including lengths and paths, are IID.

If A is the count within a cycle, A^j<=L^(j-1)A and E[A|L]=pL. Together with p^j<=p and the elementary power inequality, this gives E|Z|^j<=2^j p E L^j. A geometric length has an exponential moment, so its factorial moment bound with a finite B_beta is valid. A fixed multiplicative moment prefactor can be absorbed into B_beta for all j>=2.

The centered moment expansion then proves (U4), including negative lambda. Absolute convergence is guaranteed by the same geometric exponential moment. This retains the rare probability p in the variance term rather than replacing it by one.

## 2. Bounded stopping and overshoot

T_n, the first full-cycle index whose cumulative length reaches n, is a stopping time for the filtration revealing complete cycles. Since every cycle has at least one state, T_n<=n deterministically.

Writing psi(lambda)=p B_beta^2 lambda^2/(1-B_beta|lambda|), the process

    exp(lambda sum_(j<=r) Z_j-r psi(lambda))

is a nonnegative supermartingale. Optional stopping at the bounded T_n gives expectation at most one. Since psi>=0 and T_n<=n, multiplication by exp(T_n psi)<=exp(n psi) yields the exact stopped-sum mgf bound asserted in the candidate.

This does not require T_n to be independent of rewards or lengths. No Wald-type shortcut is being used. The argument remains valid even though the final cycle is selected through its length.

The first-n-state centered count differs from the complete-cycle centered sum only by centered observations after position n within the final cycle. Its absolute difference is at most the final cycle length. Because T_n<=n, that length is bounded by the maximum of the first n geometric lengths. A union bound supplies the stated logarithmic overshoot term without any independence assumption about the selected final cycle.

Combining the two-sided Bernstein tail from the stopped-sum mgf with the geometric maximum tail proves (U2). The beta=1 case reduces to independent states and length-one cycles, as stated.

For the original pair chain, its two parity subsequences have kernel P^2 and stationary law Pi. Applying the lemma separately and taking a union bound correctly handles consecutive pair counts. Independence of the parity subsequences is neither assumed nor required.

## 3. Source geometry and observable estimates

The all-state certificate gives theta_u(c)>=beta pi(c) and Pi(a,b)>=beta pi(a)pi(b). If the stationary minority mass is m>0, every pair mass is at least beta m^2 and every pair-successor mass is at least beta^2 m^3.

These lower bounds concern the true source only. The predictor does not know m or the source probabilities. Both add-one estimators in (U6) are computed from observed counts and are normalized positive distributions. The empirical initial-pair estimate is permitted not to be stationary for the fitted table.

There are exactly M context pairs and M triples in the specified historical blocks. A raw edit affects at most two counted pairs and three triples, giving the coordinate bounds in (U7). These are pathwise for every corrupted word, including observations produced by an offline adaptive channel.

## 4. Relative estimation event and Freedman use

Applying the occupation lemma with a sufficiently small polynomial failure level gives the displayed simultaneous deviations of all four clean context counts. Under (U8), M Pi(u) is a sufficiently large multiple of k+ell. Indeed m<=1, Pi(u)>=beta m^2, and (k+1)^2 ell dominates k+ell. Increasing A_beta therefore guarantees the specified occupation bounds and J'_u>=M Pi(u)/2.

For each successor coordinate, Z_(u,c) is a bounded-increment martingale with predictable variance at most theta_u(c)J_u. On the good occupation event this variance is at most a deterministic source-specific bound 2M Pi(u)theta_u(c).

Freedman bounds the joint event of a large martingale deviation and variance below that deterministic bound. This is the correct event restriction, not conditioning the martingale law on the occupation event. A union bound over eight coordinates and four context counts gives the stated O(M^(-3)) failure probability.

The adaptive observations then satisfy

    |C'_(u,c)-theta_u(c)J'_u|<=|Z_(u,c)|+5k.

The add-one row bias is at most one. Dividing by the observed denominator and using Pi(u)theta_u(c)>=beta^2 m^3 proves the relative transition estimate. The initial-law estimate follows from the same occupation deviations and pair-count edit bound; its add-one bias is bounded by a constant and absorbed in ell. This establishes both parts of (U9).

The good event can be constructed from the clean source concentration statements. Those statements imply the error bounds for every allowable corruption of that clean word, so no independence from the channel's choices is needed. The resulting estimates themselves remain observable functions of Z only.

## 5. Posterior comparison and the minority weight

When m>0, the source geometry makes all true clean-word probabilities positive. The add-one surrogate law is positive for every word as well, so every possible true observation has a positive fitted posterior denominator.

On the relative event, logarithmic coordinate errors are at most twice their relative errors. Two clean preimages of the same output differ at at most 2k symbols and hence at most 6k triple positions. Unchanged factors cancel. This gives the stated log-ratio oscillation 24k epsilon_m+4d_m, including the initial-pair contribution.

The common known channel factor cancels. After posterior normalization the density ratio is between exp(-L_m) and exp(L_m). Coordinatewise multiplicative row bounds can then be integrated against these posteriors, giving the exact sandwich (U11).

For binary laws, the absolute error in the minority coordinate equals the prediction TV error. With L_m<=1 and epsilon_m<=1/2, the sandwich yields a constant times p(z)[(k+1)epsilon_m+d_m]. All quantities epsilon_m,d_m are deterministic bounds for a fixed source, while p(z) is its actual conditional minority probability.

The crucial integration is valid:

    E[1_E p(Z)]<=E p(Z)=m

for any selected subset E of the good event. It does not require E to leave the source law unchanged or be independent of p(Z). Stationarity and the future-blind posterior identity give the final equality.

The fitted parameters may depend on the same z throughout. The likelihood comparison is pointwise after fixing z, so no independent-estimate assumption is hidden here. The true minority label is used only in the analysis; the algorithm computes the full binary prediction without knowing that label.

## 6. Source-independent adaptation

The threshold a=A_beta[((k+1)^2 ell)/M]^(1/3) depends only on supplied public quantities. If a>1/16, an arbitrary probability-vector output and the unit-risk bound supply the claimed rate after increasing the constant.

Otherwise, the symbol-frequency concentration lemma and raw-edit bound imply |b'-pi(1)|<=a outside a polynomially small event. The three algebraic inequalities in (U13) follow from a0^3=(k+1)^2 ell/M and a0<=1.

If m<a, this event forces the correct majority branch. Its integrated loss is at most m. If a<=m<=4a, a majority output is still the correct majority because 5a<1/2; its contribution is at most 4a. If m>4a, the empirical minimum exceeds the branch threshold and the plug-in rule is selected. These are integrated loss statements and do not condition a stationary-law claim on a data-selected branch.

For m>=a, the relative-estimation condition holds. The displayed bounds on (k+1)epsilon_m and d_m follow directly after substituting m>=A_beta a0. Choosing A_beta once makes the relative errors at most one half and the likelihood oscillation at most one, uniformly in the source and channel.

## 7. Final rate calculation

Multiplying the relative-estimation bounds by the minority mass gives exactly the four terms in (U14):

    (k+1)sqrt(ell)/(sqrt(M)sqrt(m)),
    (k+1)(k+ell)/(M m^2),
    sqrt(ell/M),
    (k+ell)/(M m).

At m>=A_beta a0 these are respectively bounded by constants times

    a0/sqrt(A_beta), a0/A_beta^2,
    a0, a0^2/[A_beta(k+1)].

The use of k+ell<=(k+1)ell is valid because ell>=1. The majority cost is O_beta(a0), and the O(M^(-3)) exceptional-event probability is smaller than this rate. Replacing log(100M) by a constant multiple of log(eM) for M>=64 proves (U1), including the unit cap.

## Scope retained

- The upper uses stationary initialization, fixed beta>0, and the complete disclosed future-blind channel.
- No positive transition floor is imposed or supplied. True rare probabilities enter only the analysis.
- The predictor does not use rho; the upper is therefore uniform over all endpoint-reliability classes but does not determine sharp rho dependence.
- The near-matching comparison with the rare lower requires beta in (0,1), fixed rho>0, and k>=1. At beta=1 that lower is absent, and at k=0 the clean estimator is sharper.
- The remaining logarithmic factor is not proved necessary. The exact unrestricted risk rate is still open.
- The posterior computation may sum over exponentially many clean words. No efficient, finite-rational, or neural implementation is certified.
- No external novelty or formal-proof claim follows from this analytical review.

The complete candidate was checked alongside the previously reviewed relative-support posterior argument, the source/channel conventions, and the separate rare-budget lower. No frozen candidate or dependency was modified in this review.
