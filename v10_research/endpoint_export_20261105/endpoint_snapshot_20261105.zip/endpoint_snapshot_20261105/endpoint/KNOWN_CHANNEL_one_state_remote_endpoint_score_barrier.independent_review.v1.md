# Independent review: remote contribution to the actual endpoint-target score

Review time: 2026-11-05 10:29:55 UTC.

## Decision and exact binding

**PASS, with the candidate's explicit method-barrier limitation.** I fully read and independently checked:

- `KNOWN_CHANNEL_one_state_remote_endpoint_score_barrier.candidate.v1.md`
- SHA-256: `24239d8e0a4e87b86e4ae90b8c865ca5c944e93f09002a43f806a35adbf386a9`.

The bound `E|Cov(g_a(X_N),S_pre|Z)|>=r rho/8` is valid at the stated source, for every N>=4. It concerns a real contribution to the derivative of the source-specific future posterior, rather than a full-latent-history proxy. Nevertheless it is a nonvanishing **individual conditional-score contribution**, not a nonvanishing total derivative error of every method, a predictive risk floor or a minimax separation.

The exact initial-pair score, output event probability, signs and cancellation have all been checked. No correction is required. This is a present-byte binding without a historical-hash inference; the original candidate is unchanged.

## 1. Source, floor and mixing certificate

For `P_a(1|x)=a+r x`, the stationary marginal stated in the candidate is correct. Its two-step pair transition from `(w,x)` to `(y,z)` is `P_a(y|x)P_a(z|y)`, while the stationary pair probability is `pi_a(y)P_a(z|y)`. The minimum of their ratio is exactly `1-r`. Choosing `r<=min{(1-beta)/2,1/8}` therefore gives the all-state D2(beta) condition for every fixed `0<beta<1`.

The source has a genuine fixed positive floor. For example the entire parameter interval `[1/4,3/8]` around `a_0=1/3` has every successor probability at least 1/4 with this r bound. There is no rare-source limit or arbitrary initial law in the example.

The two-state first-order transition matrix has eigenvalues 1 and r. Its exact transition identity `P_a^m(0,0)=pi_a(0)+pi_a(1)r^m` is therefore valid, including the exponent used for the two observed boundary coordinates. At `a_0=1/3` and `r<=1/8`, `pi_a(0)>=1/2` as required by the lower bound. No assertion uniform as beta approaches one is made; the chosen positive r can tend to zero in that limit.

## 2. Physical channel and actual counter chronology

At initialization the channel displays zero. It spends one actual edit exactly if `X_1=1`. The middle segment is identity, so the counter immediately before N equals `U=X_1`. At N only the counter-one state can flip the current raw input, and an actual flip increments the counter to two. Thus every path makes at most two changes and the current counter always equals their number.

The guards also define legal normalized rows at unreachable counter values. No base-state gate, stored copy of the first raw bit, shared hidden random bit or separate mode register is introduced. The counter carries the initial information because it records a genuine edit.

For each fixed raw word, the terminal pair changes with probability rho if its first bit is one and zero otherwise. The last operation uses the current raw input and the actual counter only; it does not inspect the next source innovation. The normalized time-indexed table is rational for the stated rational rho and has the stated conservative expanded description cost. One base state still accompanies the three-valued actual counter and the paid public time schedule.

For N>=4 the budget two is within the common `k<=M=N-2` convention. All intermediate coordinates, including both retained neighbors used in the argument, are displayed exactly.

## 3. Full middle observation and endpoint covariance

Stationary binary detailed balance gives `P_a(X_1=1|X_2=0)=a`. Conditional on the entire displayed middle segment H, the first-order factorization makes `U=X_1` and `B=X_N` independent. When both retained boundary bits are zero, they are independent Bernoulli a variables before the endpoint output is observed.

For `W=B xor(UF)`, the three joint masses listed in Section 3 are exhaustive on W=1 and sum to `a[1+rho(1-2a)]`. Direct subtraction of the conditional product of means gives exactly

`Cov(U,B|H,W=1)=-rho(1-a)^2/[1+rho(1-2a)]^2`.

This calculation conditions on the full actual observation. It does not suppress any displayed middle coordinate. The dependence is introduced by the observed channel output and the persistent actual counter, despite the clean boundary variables being independent after conditioning on H.

At rho=1 the only two possibilities on this branch are `(U,B)=(0,1)` and `(1,0)`, with equal masses. The covariance is consequently exactly -1/4, as stated.

## 4. The score is the stationary initial-pair score

The candidate uses

`S_pre = d log[pi_a(X_1)P_a(X_2|X_1)]/da`,

not merely the score of the stationary first-bit marginal. This distinction changes the score contrast and is handled correctly.

On `X_2=0`, the pair law factors as the marginal of X_2 times the conditional Bernoulli-a law of U. The marginal's derivative is a common term. The difference of the two conditional scores is therefore exactly `1/a+1/(1-a)=1/[a(1-a)]`. The common term has zero conditional covariance with the future row.

Multiplying this contrast by r times the preceding covariance gives the signed remote contribution; its absolute value is exactly (T3). The actual next-bit row is `g_a(B)=a+rB`, so this is a covariance for the requested predictive functional, not for a substituted latent variable alone.

## 5. Event mass and the uniform lower constant

The probability of the two retained zero boundary coordinates is

`pi_a(0)P_a^(N-3)(0,0)>=pi_a(0)^2>=1/4`.

For every intervening middle word consistent with these boundaries, the conditional W=1 mass is the same `aD_a`, where `D_a=1+rho(1-2a)`. Multiplying this actual branch mass by the exact absolute covariance cancels a and one denominator factor. Since `D_a<=2(1-a)`, the contribution to the expected absolute covariance is at least `r rho/8`.

No full-word event of exponentially small probability is being treated as typical. Only the two retained boundary bits and W are restricted, and the proof sums over all middle words. The bound is for an expected absolute contribution, not for a signed average that could cancel elsewhere. It is uniform in N for each fixed positive rho. At rho=0 the displayed formula reduces to zero, as it should.

## 6. Exact score decomposition and truncation error

The full stationary history score is the initial-pair score plus the ordinary transition scores from i=3 through N. Each middle score with `3<=i<=N-1` is a function of coordinates already fixed by Z. Its conditional covariance with the future row is therefore exactly zero, irrespective of clean-source mixing.

Holding the complete channel fixed while differentiating a, the posterior differentiation identity is

`p_a'(Z)=E[g_a'(B)|Z]+Cov(g_a(B),S_all|Z)`.

Here the direct row derivative is identically one. This gives (T4) with just the remote initial-pair term and the terminal transition term. No source-score term for the unobserved future innovation should be added; its parameter dependence is already represented by the direct derivative of g.

A truncation retaining only the last ell transition scores, for `1<=ell<=N-2`, leaves only the terminal score covariance. Its error from the full derivative equals the omitted remote covariance pointwise. Consequently the integrated absolute truncation error is at least `r rho/8` for every such ell, including when every transition score except the initial-pair score has been retained.

This disproves the specified terminal-only localization or exponential-forgetting step based solely on clean D2 mixing. It does not refute a method that retains the initial-pair term separately, allows counter-mediated remote exceptions, or bounds the complete combined covariance directly.

## 7. Mixture derivatives and the exact cancellation

Conditioning internally on the actual counter U is legitimate, but reconstructing the unconditioned target requires its source-dependent posterior weights. Differentiation of the mixture has both the within-stratum derivative and the weight derivative. The remote score is constant within a stratum because both U and X_2 are then fixed; this does not authorize discarding its role in the weight derivative.

The candidate also handles the important cancellation case correctly. At rho=1, on the selected W=1 branch, both posterior mode weights are 1/2 for every nearby a. Their total derivative is zero. The posterior target is exactly `a+r/2`, so its derivative is exactly one.

In the unconditioned score decomposition, the remote covariance equals `-r/[4a(1-a)]` and the terminal covariance equals `+r/[4a(1-a)]` on this branch. Thus both are nonzero and cancel exactly. Calling this exponential decay of the remote term, or inferring a nonzero total predictive derivative error from the magnitude of one term, would be incorrect. The candidate makes neither inference.

The augmented raw-source/counter process does not contract between counter zero and counter one during the identity middle segment. This is a real memory feature of the counted channel, even though the underlying clean source itself is mixing. The proof therefore identifies why a count-conditioned forgetting argument cannot be passed through an unexamined mixture.

## 8. What is and is not established

The source has a fixed positive floor and the edit budget is two. The already reviewed positive-floor prediction bounds still allow vanishing risk of order `1/sqrt(M)` for this fixed-budget class. There is no contradiction: the present result concerns an individual score contribution and the error of a specified truncation, not a predictive-risk lower.

No constant risk floor, new predictive minimax separation, matching general S=1 upper, necessity of another base state, impossibility of all endpoint-sensitive methods or accumulation of many remote terms is established. The beta=1 boundary is not covered by a positive r. The general no-floor S=1 predictive question remains separate and unresolved by this barrier.

## Review method

Pure analytical reconstruction, private file inspection, exact hashing and this separate review artifact. No scientific executable checks, numerical experiments, simulations, model execution, public writes, external novelty investigation, training claims or finite-precision certification. The original candidate remains unchanged.
