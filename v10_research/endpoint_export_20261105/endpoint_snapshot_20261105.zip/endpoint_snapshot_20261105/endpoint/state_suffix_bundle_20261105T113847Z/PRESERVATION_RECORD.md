# Previous deliverables preserved

Mechanical SHA-256 inspection on 2026-11-05 confirmed the following existing files retain the previously recorded hashes. They were not modified by the state/suffix supplement task.

- Earlier endpoint report: report_bundle_20261105T034607Z/endpoint_posterior_report.zh.v2.html
  SHA-256: 5f66d2d8525d86738afec0fbe19610462f0f7caca2f3ae4d6c52a807f6834f5a
- Earlier online supplement: supplement_bundle_20261105T073513Z/endpoint_online_supplement.zh.v3.html
  SHA-256: 754f48305ae955a47f8c2866f927c1434d1a4c568976d696932b7a5b9dddd641

All new report sources were read from their frozen copies. The 91-source mathematical manifest and the separate two-source historical provenance manifest are retained without conflating their capture times. New revisions use new filenames; earlier drafts and review findings remain available.

This record is an integrity statement, not executable QA, model evaluation, historical run reconstruction, or a claim of rendering verification.
