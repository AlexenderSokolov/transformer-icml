# Executable-check provenance and conclusion dependencies

4 November 2026 UTC. Revision 2 inventories mandatory-post-LN implementation and readiness checks using preserved artifacts and historical execution records. Revision 1 remains historical. This public derivative removes non-scientific coordination details and private storage information; source and export hashes are separately recorded. No check was rerun to prepare this inventory. Plain file inspection is distinguished from executable validation.

## Common limitation and correction

The earlier parameter-compilation and static checks generally lack a separately frozen, independently reviewed pre-execution environment/code/input manifest and complete per-unit outcome capture. This is an evidence limitation. These activities did not evaluate model/source states, use estimator oracles or convert parameters to floating point.

Accordingly, their PASS statements are historical static-review/test verdicts under the retained evidence below. They must not be described as compliance with the new strict pre-run/per-block protocol, certified physical execution, or exact finite-arithmetic evidence. The analytical v4 proof and mathematical arguments remain distinct from those executable records. No model/source-state evaluation, floating coefficient conversion or estimator oracle was performed by these checks.

## 1. Initial readiness verification

One inline Python script read the readiness manifest, source bindings and case file. It asserted all 17 manifest entries' bytes/hashes, all nine original/snapshot bindings, all 16 histories and 80 physical rows, and exact integer/Fraction resource/tolerance/warmup calculations. It printed aggregate success messages and arithmetic totals.

Retained: input/source snapshots, manifest, cases, environment snapshot and later review. The script and raw output survive in historical execution records, not as standalone original files. The environment snapshot describes package preparation, not the checking process. Hashes were checked during the script, not in an independent preceding gate. Per-file/per-case assertions were not individually logged.

Dependent conclusions: the reported 17/9/16/80 checks, illustrative resource totals, two dyadic identities and five rational warmup inequalities. The initial NO-GO was also supported directly by the absent compiler/executor/parameter artifacts, not by a forward experiment.

## 2. Source authoring tests and public-parameter counts

`tests/source_static_contract.py` ran once before the source existed and once after implementation. The initial log records both named failures and tracebacks; the successful log contains two dots, aggregate count and OK, not named per-test PASS records or emitted IR. The enclosing initial shell command ended with `cat`, so its enclosing process exit code 0 was not the failing test's exit code.

Retained: test script, `review/source_missing_feature.log`, `review/source_static_result.log` and source code. No pre-run hashed environment/code/input manifest or independent gate was made.

A separate inline Python invocation compiled parameter IR for (N,K)=(4,2),(8,2),(32,2),(4,3) and printed register/depth/kind/public-parameter totals. It did not retain each emitted IR or per-primitive records. Script/output are historical-record-only. Source/test hashes were taken afterwards.

Dependent conclusions: static syntax/types/labels/order/clear coverage assertions and reported counts 45/513,45/525,45/913,71/789 for those public cases. No output semantics, estimator predictions, trained performance or finite-arithmetic conclusions follow from these tests.

## 3. Independent original-source executable check

One inline Python process imported the source builder, built N=4,K=2 parameter IR and reconstructed every affine matrix with identity-preserved rows. It checked distinct destinations/terms and computed aggregate maxima: Frobenius squared 300, bias squared 639/32, row absolute sum 16 and coefficient magnitude 16. It printed width/depth/kind/phase counts. The source digest was printed immediately before the Python invocation in the same shell call.

Retained: later `review/SOURCE_COMPILER_INDEPENDENT.v1.md`; original checker/output are historical-record-only. No standalone checker, independently reviewed pre-run environment/input manifest, per-primitive matrix/results ledger or structured failure record exists.

Dependent conclusions: exact 45/513 counts and the stated matrix/bias/row maxima. L=256 used the computed affine norm bound together with analytical ReLU/attention bounds. Phase correspondence, classifier margins, all-row virtual-word semantics, lag simultaneity, ties, clearing and source-state boundedness were mathematical/source-inspection arguments, not executed-history tests.

## 4. Conservative post-LN authoring and emission

The implementation record reports `tests/postln_static_contract.py` before and after implementation, recording missing-feature FAIL and later aggregate PASS JSON. It checks AST names, prohibited numerical imports and floating literals. `python3 -m py_compile` also ran. Neither had an independent pre-run gate/environment manifest or per-assertion outcome stream.

`python3 src/postln_compiler.py --output build/network.candidate.v1.jsonl.gz --report build/COMPILATION_REPORT.candidate.v1.json` generated exact parameters. Its stdout, stderr and explicit exit-code sidecar are retained. Every emitted physical block is preserved in the bundle, but there is no pre-launch independently reviewed compiler/environment/input manifest or per-block started/failed emission ledger. Parameters were not converted to floats or applied to states.

Dependent conclusions: syntax/AST acceptance, existence of the emitted bundle and its self-reported counts/schedules/size/precision ledger. The bundle is an inspectable artifact, not itself a forward trace or independent correctness certificate.

## 5. Independent conservative full-stream structural audit

One inline Python script streamed all 150,652 blocks, checking contiguous indices, sparse shapes/ranges/duplicates, absence of anchor outputs, canonical dyadics, parameter/LN references, one useful head, final beta location, phases and footer agreement. It recomputed W2 counts/exponents and the bundle digest.

Retained: later `review/POSTLN_COMPILER_INDEPENDENT.v1.md`; inline checker/raw output remain only in historical execution records. Hashes were computed during the audit. There was no separately frozen environment/checker/input manifest, independent execution gate or full per-block input/result/failure capture.

Dependent conclusions: observed 150,652 blocks, 147,645 tent blocks, 2,679,830 W2 entries, 631,766 tiny W2 entries, exponent -8207, phases and useful/final indices. The total 2,680,871 including shared entries was taken from the compilation report, not independently recounted by this script. Paired residual algebra, tent/polarization/Newton reasoning, complete-state bounds and probability repair were prose mathematical review.

## 6. Physical-runner authoring tests

The retained account reports one initial v1 missing-feature invocation, three later v1 static-test invocations, one v2 missing-feature invocation, and four later v2 static-test invocations. The successful scripts parsed AST/source strings and invoked only the missing-gate refusal path. The final two v2 invocations additionally created a temporary empty-JSON gate and asserted refusal. These are tests of code shape and refusal behavior, not executions of the physical model, conversion path or trace decoder.

The two RED logs were written in temporary storage and their text embedded in the corresponding notes. Their enclosing shells ended by printing logs, so enclosing process exit code 0 does not establish a successful Python test. Successful tests printed aggregate PASS; exact child exit codes and stderr were asserted but not separately retained. The temporary invalid-gate JSON and child output were not preserved after cleanup. No independent hashed environment/code/input gate, per-check intent or complete per-case result capture preceded them.

A separate record describes a one-header gzip/JSON inspection to read exact d,w,T,K, LN definitions and output indices, and used a temporary generation script plus inline source-writing operations to derive v2. Header-inspection output is historical-record-only. Source hashes were recorded afterwards; they identify files at those times, not continuous immutability. No NumPy environment command or capture-decoder invocation occurred.

Dependent conclusions: only the specific tested AST/refusal behavior. Literal forward semantics and capture-design descriptions came from source reading. The physical runner, coefficient conversion and decoder have not acquired numerical GO from these checks.

## 7. Conservative final resource/runner audit

One inline standard-library Python script parsed runner/verifier ASTs, read only the bundle's first header, printed shared shapes, computed integer dense-array and raw-trace totals, and hashed/size-counted files. It did not invoke the runner, decoder, compiler or supplied static tests, and did not stream the full block census.

Retained: later `review/FINAL_EXECUTION_RESOURCE_GATE.v1.md`; inline code/output are historical-record-only. No independent pre-run environment/code/input gate or per-case records exist. At-generation hashes were embedded in the review later.

Dependent conclusions: AST parse completion, header shapes, 395,520 shared matrix elements, 1,281 vector elements, the 7,954,664-byte array estimate, and the v2 raw-trace arithmetic. Block/underflow counts were inherited from the bound compiler reports. Decoder limitations, literal operator order and missing execution prerequisites came from code reading. NO-GO did not rely on a forward test.

## 8. Implementation rechecks and conservative archive validation

The implementation record includes later invocations of the source, post-LN AST, runner-v1 and runner-v2 static scripts before sealing. Their combined execution output is retained; there was no new independent pre-run gate or complete test-case ledger. A five-file hash check wrote `capture/FINAL_STATIC_READBACK.v1.json`, which DOES retain one PASS/hash entry for each named file, but its inline checker/environment were not independently frozen before launch.

`seal_artifacts.v1.py` generated the 53-file manifest, wrote the archive, ran ZIP CRC validation and compared every extracted file's bytes/hash to the manifest. The code, manifest, archive and `SEAL_RECEIPT.v1.json` persist. The manifest preserves each expected file input; the receipt reports only aggregate readback success/count, not individual extracted-result records. No independent gate bound this exact sealing script/environment before execution. The earlier review allowed compact preservation in principle, not this specific pre-run executable manifest.

Dependent conclusions: reported source/bundle identity and local archive/CRC/readback integrity. These are operational artifact checks, not evidence of network correctness or strict experimental capture.

## 9. Optimized source/post-LN authoring and emission

`tests/optimized_source_static.py` and copied `tests/postln_static_contract.py` ran expected missing-file and later AST/API checks. `py_compile` ran on the new post-LN compiler. Their retained JSON is aggregate; no independent pre-run gate/environment manifest or per-assertion ledger exists.

An inline invocation built the optimized source IR and printed its optimization certificate. The new exact compiler generated `build/network.optimized.candidate.v1.jsonl.gz`; stdout/stderr/exit sidecar and the complete emitted parameter records are retained. As with the conservative emission, no model state was evaluated, but there was no independent pre-launch compiler/environment/input gate or per-block emission/failure stream.

Dependent conclusions: syntax/API acceptance, parameter artifact existence and reported D=514/new schedule/count/precision/resource values. These are not strictly captured physical or numerical results.

## 10. Independent optimized-source checks

Two inline Python checks were run. The first built both source IRs, compared the lists after removing the paid clear, propagated backward liveness, reconstructed affine norms, checked three exact scalar inequalities and hashed source/plan/review files. The second scanned every later operation for reads of cleared registers before redefinition.

Retained: later `review/OPTIMIZED_SOURCE_INDEPENDENT.v1.md`; code/raw output remain in historical execution records. Hashes were computed during the first check, after its inspections. There is no separate pre-run environment/code/input gate or per-primitive dependency/norm ledger.

Dependent conclusions: D=514, live sets, operation-list equality, absence of read-before-redefinition and Frobenius squared 300 combine executable checks with source inspection. H0=28 is based on the independently written phase-by-phase bound |coordinate|<=4; the executable inequality only checked 45*16<28^2. L=32 combines the computed affine bound with analytical ReLU/projection/attention bounds. All-history/all-row equivalence is a structural mathematical argument, not enumeration of predicted outputs.

## 11. Independent optimized full-stream checker and separate header check

The original full-stream checker is preserved unchanged as `review/OPTIMIZED_POSTLN_STATIC_RECONSTRUCTION.v1.py`. Its original stdout is preserved from the original historical execution response, with that retrospective transcript provenance explicitly stated. It reconstructed and asserted all 33,300 blocks and reported aggregate PASS. It did not have a dedicated pre-run environment/code/input gate or retained per-block actual/expected/result stream.

Dependent conclusions: the all-block comparison assertion, 33,300 total, phase counts, 579,809 counted entries, exponent -4111, 90,736 tiny entries and useful/final indices. The actual input bundle is preserved, but that does not replace the missing original per-block result ledger.

A separate inline shared-header check read only the first bundle record and asserted the complete signed-identity matrix, square-hinge matrix, raw embedding, embedding bias, both zero biases/shapes and embedding references. It also hashed the unchanged old runner and evidence files, then printed HEADER_EXACT_CHECK_PASS. That script and output survive only in historical execution records, without a prior independent gate or per-object result stream. They are not part of the preserved checker. These checks support the additional full shared-header comparisons and identities, not new runner certification.

The full-stream checker explicitly asserted the one-history resource formula; it did not separately execute a sixteen-history resource test. Its H0=28 premise came from analytical source review, not model execution. Later preservation operations copied the existing checker unchanged, asserted original/preserved hash equality and unchanged review hash, and saved the exact original stdout string from the historical execution response. Those preservation checks also had no prior independent gate; the new receipt accurately labels the stdout's retrospective provenance. No checker was rerun during preservation.

Mathematical padding, gauge, source-equivalence and exact-simplex reasoning remain prose analytical review.

## 12. Optimized identity/resource rechecks

The implementation record includes later invocations of both optimized static scripts and checked the unchanged old source/compiler/bundle plus the new bundle digest. That combined result is historical-record-only, without a pre-run independent gate or per-file result artifact.

A later six-file hash check wrote `capture/FINAL_STATIC_READBACK.v1.json`; each named file's verified hash is retained, but its inline checking code/environment were not preregistered. `RESOURCE_PREFLIGHT.v1.json` records fresh disk/host-memory metadata and exact integer shape-based operation/resource arithmetic, not a workload benchmark. Its source operation is present in historical execution records, not an independently pre-gated validation run.

Dependent conclusions: recorded file identities, resource snapshots and shape-based arithmetic. No process-RAM maximum, runtime, actual compression ratio or durable large-trace capacity was measured or proved by those operations.

## 13. Storage verification boundary

Successful archive save/readback or small-file identity checks do not establish capacity for full model traces. They are not model-execution evidence.

## Current disposition

No incomplete historical capture is repaired retrospectively. The existing analytical reviews and original execution artifacts remain unchanged. The numerical/resource gate is NO-GO. The proposed strict replay v1 was independently rejected by prose review before any executable check launched; its blockers require a new frozen revision and another gate. Every future executable check, including archive validation and codec byte fixtures, must satisfy the new independent pre-run/case-record requirements.
