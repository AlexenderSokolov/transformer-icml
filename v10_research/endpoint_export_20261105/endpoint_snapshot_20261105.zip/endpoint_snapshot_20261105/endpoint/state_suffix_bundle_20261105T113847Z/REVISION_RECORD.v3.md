# Final precision revision

v1 and v2 remain unchanged. v3 is a new file at SHA-256 484284918f901aac5a10c55bd34c1245d842ed54dcf646c8b603d34c93c0315c, 44,018 bytes.

The independent factual reviewer found no remaining material discrepancy in v2, and suggested two precision improvements. Both are incorporated in v3:

- The infinitesimal suffix-score lemma explicitly requires a fixed channel, differentiable interior source family and finite one-step Fisher information. These derivative regularity conditions are not imposed on the separate finite comparison/statistical theorem.
- The runtime paragraph explicitly defines T=N+1 including the synthetic query row, w as the per-scalar rational numerator/denominator bit-length bound, and L_net as network depth.

No mathematical rate, proof dependency, source file or prior report changed. Final factual and static artifact reviews independently bind v3. No executable QA, scientific or model execution, rendering, or public upload was performed.
