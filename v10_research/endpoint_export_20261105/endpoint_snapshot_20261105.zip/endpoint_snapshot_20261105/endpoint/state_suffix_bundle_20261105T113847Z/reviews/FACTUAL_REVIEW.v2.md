# Static factual review of the Chinese supplement, version 2

Date: 2026-11-05 UTC. Exact version comparison and hash capture completed at approximately 11:52:43 UTC.

## Exact artifact and verdict

Reviewed artifact: `endpoint_state_suffix_supplement.zh.v2.html`.

SHA-256: `6ce266c90f18305bdb953ae9242a1abf44ef72a40d81080ecc7d5e64d53110de`.

**PASS for static factual consistency and source correspondence within the qualifications below.** No outstanding material discrepancy was found. This approval binds only these bytes. It is not a mathematical proof-acceptance verdict, a runtime or rendering result, external peer review, or novelty certification.

I read the entire preserved version 1, inspected its source dependencies, and independently checked the complete version-1-to-version-2 textual difference and the hashes of both versions. The four correction groups recorded in `FACTUAL_REVIEW.v1.md` are all incorporated: unsupported literature item removed; beta=1 statement restricted to the proved floor range; small-budget construction domains clarified; and compiler input identified as the displayed word Z rather than hidden X. Version 1 is preserved unchanged.

## Input integrity and evidence separation

- All 91 entries of `INPUT_SHA256SUMS.txt` matched their frozen input bytes during this review.
- Both entries of `HISTORICAL_PROVENANCE_SHA256SUMS.txt` matched: the strict replay status and executable-check provenance records.
- The 91-file mathematical cutoff remains 2026-11-05 11:38:47 UTC. The two historical files were added separately after that cutoff, without changing the original manifest. `SNAPSHOT_NOTES.md` documents the distinction.
- Current hashes certify inspected bytes only; they do not restore missing historical execution capture or establish that a digest was recorded at an earlier review time.
- The source-level flaw, retraction and replacement proof are independently documented in the frozen sources. This public derivative omits non-scientific communication metadata.

## Main factual checks

### 1. Experiment, target, state count, and quantifiers

The report consistently uses stationary binary at-most-second-order sources, an all-state pair-chain two-step D2(beta) certificate with fixed 0<beta<1 where required, one common disclosed source-independent channel under each lower-bound source pair, and expected absolute loss against the source-specific clean-next-bit posterior. It does not substitute classification error, a posterior over source hypotheses, or the unobserved actual terminal-row target.

Future blindness is distinguished from current-symbol online causality. Strict Hamming budget is pathwise, and endpoint reliability is per clean word. S counts base states; the actual k+1-valued edit counter and expanded public time schedule are paid separately. Separate witnesses are combined by a maximum, not by adding edit budgets. No fixed homogeneous total-state claim, free mode bit, or state-minimality conclusion is asserted.

### 2. Latest online and fixed-floor rates

The two-state counter-mode candidate and its 08:47:55 review support the full no-fixed-floor profile

`Theta_beta(min{1, M^(-1/2)+k/M+min{rho,(k^2/M)^(1/3)}})`

already for S>=2. Its paid prefix mode is not a pathwise compression of the preceding fair-mode machine. The common prefix ratio, mode prior in [1/3,2/3], branch mass at least 1/32, fixed-start domination, cap perturbation before endpoint weighting, and bounded-small-budget fallback match the approved sources. Earlier S>=8 and S>=3 descriptions are correctly treated as historical sufficient bounds.

The new protected iid witness supplies `5k/(3072M)` with floor 1/4 and endpoint budget zero. Together with the accepted endpoint lower and the uniform-rho upper it supports

`Theta(min{1,M^(-1/2)+k/M+rho min{1,k/sqrt(M)}})`

for fixed 0<eta<=1/4, and fixed 0<beta<1 when that intersection is imposed. The report does not extend the lower to all eta<1/2, to a vanishing floor, or to the degenerate eta=1/2 class. Its corrected beta=1 statement preserves the proved floor range and removes the endpoint term. The upper alone legitimately covers every fixed 0<eta<=1/2 and need not assume D2 separately.

### 3. General no-floor S=1 remains open

The rare-rho lower uses `b=min{1,k/sqrt(M)}` and endpoint term `min{rho sqrt(b),b sqrt(rho)}`. The report correctly retains the inherited upper, the sub-square-root gap, moving-rho uniformity, horizon-varying rare sources, signed rather than uniformly monotone odds, and observation-mass weighting. Its example k of order M^(1/4), rho of order M^(-1/8), and endpoint scale M^(-5/16) agrees with the source. It is not misrepresented as a fixed-floor theorem.

### 4. Method barriers are not predictive impossibility results

The iid one-edit barrier has the stated overlap-weighted hidden-history posterior gap, missing information of order M squared, and only order-1/M prediction risk for its specified pair. The remote positive-floor example concerns an individual omitted score contribution and permits exact cancellation. The preferred complete-score version 2 is an endpoint-only one-edit example, not uniquely a hidden-counter obstruction. Its L1 contradiction covers rho exponents greater than one half; it neither proves nor refutes the boundary one-half candidate. Its displayed L2 family fails for every positive rho exponent. None is promoted to a new minimax prediction lower.

The centered likelihood representation includes the actual counter, the complete stationary-source score, the direct row derivative, and the normalizing denominator. The integrated signed correction is not advertised as a pointwise quotient or derivative bound.

### 5. Fixed-suffix finite comparison and statistical upper

The report uses the unhalved convention `H^2=sum(sqrt(P)-sqrt(Q))^2` and the correct bound

`E_(P,C)|p_P-p_Q| <= E_P|g_P-g_Q|+2 sqrt(rho)H(P,Q)+H^2(P,Q)`.

The reference Q is fixed throughout the output expectation. Endpoint control is needed under Q; the per-word certificate supplies it for every fitted law. Singular support and zero-Q output evidence are paid by the Hellinger-square remainder. The report does not claim that the centered residual itself is endpoint supported.

The fitted law is fixed after conditioning on the unchanged prefix, starts from the same observed terminal pair, and need not be stationary or satisfy D2. Future-pair-conditioned count control handles fit/context dependence without dividing by a rare pair probability. The suffix KL estimate is averaged over the prefix, not uniform in every prefix. Public estimator selection, rather than deletion of a quadratic term, produces

`C_beta min{1,(M-L)^(-1/2)+min{rho,sqrt(rho L/(M-L))}}`.

The source needs no fixed positive floor. All edits must lie in the prescribed suffix; L can grow. This is not an arbitrary-position S=1 theorem, no L-to-k or L-to-k-squared conversion is supplied, and no matching lower or dedicated efficient compiler is asserted.

### 6. Computation, source precedents, and execution history

The quoted dyadic interface, B_base/B_int, circuit-size scale, explicit loose C_int, growing-bank and constant-width costs, zero attention scores, no normalization layers, and exact-rational limitations agree with the accepted sharp-rho composition. The report does not give the compiler hidden clean inputs, a free posterior oracle, training performance, floating-point robustness, or a mandatory-normalization architecture extension.

The retained literature comparisons are supported by the frozen primary-source audits. The Hellinger shape and constants, posterior covariance identities, add-one Markov estimation, time reversal, KL decomposition, log-ratio oscillation, network polynomials, causal hard caps, and concentration methods are not claimed as first discoveries. The report preserves the limited Louis retrieval statement and does not claim an exhaustive priority search.

The historical replay remains NOT RUN after isolation startup failed; planned counts are not completed cases. The report distinguishes historical static execution from numerical/model execution and makes no retrospective repair of missing pre-run or per-case capture.

## Exact current proof bindings used for the central conclusions

- Two-state candidate: `104b2193954650b160dd41dacd08107276098d5f109bd6b35bcc9157a4525094`; review: `89cc240de6340f81427df61f771aa79a3e5be2bb35f14e827f7b0f3874ae7ca1`.
- One-state fixed-floor endpoint candidate v2: `81ec5725846233595bfdb803ab92640dc20d419488b68ece2460e99d43a546ce`; review v1: `aea209b923c3c8cb0f0f60c783eaf1c20a5851597a52dfa1bc25fac22276cd2e`.
- Positive-floor uniform-rho upper: `4f472df0857c73d4a09dfb380136a3f4f3558c994ba75ea5c3cb6579bcf5f13f`; audit: `fdce59e69f7d84d755fc3224c60243d522cf2110c508258e06bba945b83b2e82`.
- New protected fixed-floor candidate: `7107da3ab4b928047801bd3cf2798c9156f0e74331995945948a204c69f32333`; review: `111247b9e44d3aac0c9c6771b8715a48b19f9baf5e0a28c1c42a463dbea708e6`.
- Rare-rho candidate: `d784c6abdc1eaaae97dc5dcdd8fab478f05ea387b40c8e634b452345749503cb`; review: `bff649fd9911b2b179b2eb445a7f4a3ecea78016897aad07aff3d1356c6e3216`.
- Centered flow: `44d7b71bdf913e510ddb7e5115f1226aaa33d8b37f5cf5f907bae34a32624e47`; review: `9bfc3ceaf36649d5ca746a353cfb6e397fd656bc92327c0040d4d1fadb98293b`.
- Fixed-suffix candidate: `62efe80b0b7daea4c451526db3dc3706eaf5382d4c23bc57fe8f098418e86e65`; review: `8b1586193de324ce3518f5cf6080fad3ed639bdef264a3a00eff03c0cb3c1909`.

The remaining indexed candidate and audit digests were compared against the frozen manifest. Their mathematical PASS descriptions report existing independent reviews rather than reissuing those proof verdicts.

## Nonblocking precision suggestions

The scalar suffix derivative statement may more explicitly say that it is at a differentiable interior source parameter with finite I_step, with the channel fixed. That regularity is not an extra assumption on the separate finite statistical theorem. The runtime paragraph may define T=N+1 and w as the per-scalar rational bit length. These are clarity improvements, not outstanding material corrections to the current factual verdict.

## Method and exclusions

This review used static document reading, textual searches/difference inspection, mechanical hashing, and private review writing only. It did not execute an HTML checker, source tests, a model, numerical computation, simulation, rendering, or external upload. No original source proof or report version was edited. No fresh web verification or new scientific theorem was attempted. The factual PASS cannot be used as a certificate for execution, rendering, training, finite-precision behavior, historical capture, or novelty.
