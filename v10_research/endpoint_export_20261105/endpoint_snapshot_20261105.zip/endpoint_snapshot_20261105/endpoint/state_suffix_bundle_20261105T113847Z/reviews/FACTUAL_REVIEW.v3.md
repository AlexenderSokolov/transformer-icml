# Final static factual review: Chinese state and suffix supplement, version 3

Date: 2026-11-05 UTC. Version-difference inspection and independent hash capture: approximately 11:54:50 UTC.

## Exact final artifact

Artifact: `endpoint_state_suffix_supplement.zh.v3.html`.

SHA-256: `484284918f901aac5a10c55bd34c1245d842ed54dcf646c8b603d34c93c0315c`.

**PASS for static factual consistency and source correspondence. No outstanding correction remains.** This verdict binds the current version-3 bytes. It is not a new mathematical proof review, formal verification, rendering result, executable artifact check, scientific test, model run, or novelty certification.

## Review chain and preserved changes

The full first report, its frozen mathematical and primary-source dependencies, and the historical provenance records were inspected. The findings and exact initial hash are preserved in `FACTUAL_REVIEW.v1.md`. The complete version-1-to-version-2 change was independently inspected and the corrected result approved in `FACTUAL_REVIEW.v2.md`.

I have now independently inspected the complete version-2-to-version-3 difference. It contains only the two expected precision improvements:

1. The suffix score-derivative statement now explicitly requires a fixed channel, a differentiable interior source family, and finite one-step information. It expressly distinguishes those derivative conditions from the separate finite comparison and statistical theorem.
2. The resource paragraph now defines T=N+1 including the query position, w as an exact rational scalar numerator/denominator bit-length bound, and L_net as network depth.

Both changes correctly clarify the approved sources. No mathematical rate, target, source class, state allowance, certificate, literature claim, or execution-status claim was otherwise changed. The earlier report versions and both earlier factual reviews remain preserved unchanged.

Independently captured prior report hashes:

- Version 1: `c420af36db1996d0a88b829f79e62fef82bc9889bb1696918d3aa20472184600`.
- Version 2: `6ce266c90f18305bdb953ae9242a1abf44ef72a40d81080ecc7d5e64d53110de`.

Preserved detailed review hashes:

- `FACTUAL_REVIEW.v1.md`: `aee5a56d4872228f4575c788fe2be3983eb2302163e4d7391d17f087a50a3d54`.
- `FACTUAL_REVIEW.v2.md`: `0ac5aef1a498bf95c56ea6a8c48ba40c3d5f3435e52a7a53618cdae0052e2b52`.

## Carried-forward verified scope

The detailed factual checks, current proof/review hashes, evidence separation, and review limitations in `FACTUAL_REVIEW.v2.md` apply unchanged to version 3. In particular:

- S>=2 achieves the complete no-fixed-floor online statistical profile with a separately paid actual counter and time-indexed table; two base states are not asserted minimal.
- S=1 has the matched fixed-positive-floor uniform-rho rate in the proved eta and beta ranges, using the new protected witness rather than the withdrawn unsupported import.
- The later rare-rho S=1 lower strengthens the old lower but leaves the general no-floor sub-square-root-budget question open.
- The latent-posterior, remote-score, and complete-score obstructions remain precisely scoped method barriers rather than unproved predictive minimax lower bounds.
- The finite Hellinger comparison uses one fixed Q, the unhalved convention, Q-side reliability, and an explicit quadratic/support term. The statistical suffix theorem fixes the fit after clean-prefix conditioning and makes no L-to-k or L-to-k-squared substitution.
- The retained primary-source comparisons are bounded antecedent comparisons, not exhaustive novelty claims. The unsupported version-1 literature item was removed.
- The final compiler input is displayed Z, not hidden X. The inherited implementation is exact-rational with fully paid resources, not an empirical or floating-point certificate.
- The strict historical replay remains NOT RUN after isolation startup failed; planned case counts are not executed results. Current hashes do not repair old capture gaps.

All 91 mathematical-manifest hashes and both separately listed historical-provenance hashes matched during the historical review. Those hashes bind original source bytes; ENDPOINT_SOURCE_MAP.json separately binds public derivatives. Non-scientific communication metadata is omitted.

## Method and limits

Only static reading, textual searches and difference inspection, mechanical hashes, and review writing were used. No source proofs or report versions were edited by this reviewer. No executable QA, scientific/model work, simulation, rendering, upload, or new external literature retrieval was performed. This factual PASS provides no additional authority to run, publish, or alter the frozen materials.
