# Static factual review of the preserved Chinese supplement, version 1

Date: 2026-11-05 UTC.

## Exact artifact and disposition

Reviewed artifact: `endpoint_state_suffix_supplement.zh.v1.html`.

SHA-256: `c420af36db1996d0a88b829f79e62fef82bc9889bb1696918d3aa20472184600`.

Disposition: **CORRECTIONS REQUIRED; superseded for delivery by the separately reviewed version 2.** This record preserves the findings against version 1. It does not modify that version or any source proof.

I read the complete report and compared its substantive claims with the frozen candidates, independent reviews, primary-source audits, and the two separately preserved historical provenance records. All 91 entries in `INPUT_SHA256SUMS.txt` passed mechanical SHA-256 comparison. Both entries in `HISTORICAL_PROVENANCE_SHA256SUMS.txt` also matched. These are integrity operations, not executable scientific or artifact-validation tests.

## Material corrections communicated before approval

1. **Unsupported source-provenance assertion in section 9.** The Foster–Kakade–Qian–Rakhlin Lemma A.9 and Weber section 3.2.2/equation 18 item was not present in any frozen input. The report nevertheless introduced those references as sources used in the frozen literature audits. No new external retrieval was authorized or performed for this review. The requested repair was removal unless separately recorded verified evidence was supplied. This finding concerns provenance, not a claim that either reference is mathematically false.

2. **Overbroad beta=1 fixed-floor boundary in section 4.** The positive rate `min{1,M^(-1/2)+k/M}` was stated for the fixed-positive-floor class without repeating the proved `0<eta<=1/4` restriction. That could include eta=1/2, where the report itself correctly says the risk is zero. The requested repair was to retain the established floor range explicitly.

3. **Small-budget construction domains in sections 4 and 5.** Formulas using `h=min{k-2,floor(sqrt(M))}` and the subsequent thinning scales need `k>=3`. Without that qualification the report-wide allowance k=0,1,2 supplies negative or zero h and can make the displayed formulas invalid. The small-budget cases are handled by separate clean witnesses, not by evaluating these thinning formulas. Version 1 needed to state that separation.

4. **Displayed inputs versus hidden clean inputs in section 8.** “原始二元 one-hot” was ambiguous about access to the hidden clean word. The compiler source explicitly receives the displayed word Z. The requested repair was to say “显示词 Z 的二元 one-hot” and to exclude hidden X.

## Findings otherwise supported

The principal S>=2 rate, the fixed-floor S=1 uniform-rho rate, the later rare-rho S=1 lower, the distinction between score barriers and predictive risk, the unnormalized-Hellinger constants, the fixed-Q requirement, Q-side endpoint reliability, clean-prefix conditioning, and the absence of an L-to-k or L-to-k-squared conversion were correctly represented. The report correctly treats state counts as base states with separately paid actual counters and time-indexed tables. It does not claim state minimality.

The mathematical reason for retracting the old import and the replacement fixed-floor proof are supported by the frozen primary-source audit and the 09:31:44 independent review. This public derivative omits non-scientific communication metadata.

## Method and limits

Only static document reading, textual comparison, mechanical SHA-256 comparison, and this review writing were performed. No source proofs were altered. No scientific executable checks, model execution, simulation, rendering, upload, fresh external literature search, or formal verification occurred. This is a factual/source-correspondence review, not a new mathematical acceptance review or novelty certification.
