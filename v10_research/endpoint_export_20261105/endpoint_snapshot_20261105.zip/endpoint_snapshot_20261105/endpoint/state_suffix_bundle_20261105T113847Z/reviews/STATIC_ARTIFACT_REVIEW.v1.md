# Static artifact review of the v1 Chinese report

Reviewed artifact: `endpoint_state_suffix_supplement.zh.v1.html`

SHA-256 of the complete reviewed file:
`c420af36db1996d0a88b829f79e62fef82bc9889bb1696918d3aa20472184600`

Size observed in the file listing: 43,877 bytes. Review date: 2026-11-05 UTC. The same SHA-256 was obtained before and after the source inspection. This review does not bind a subsequent version.

## Outcome and limits

No blocking artifact-level defect was found by static reading. This is not a mathematical acceptance, an HTML-validator result, a rendered-layout acceptance, or evidence of a successful executable check. The separate factual review has requested v2 revisions; v1 must remain preserved and should not be treated as final solely because of this artifact review.

Only read-only text inspection, a directory listing, and mechanical SHA-256 hashing were used to inspect the artifact and its snapshot note. No browser, rendering, HTML parser/validator, executable artifact checker, scientific execution, model test, training, network request, or link fetch was performed. The report was not modified. The review file itself was authored after inspection.

## Source structure, references, and self-containment

- The source has an HTML doctype, `lang="zh-CN"`, UTF-8, a viewport declaration, a descriptive title, one inline stylesheet, and a clear header/main/navigation/section/footer structure. The heading hierarchy is one h1 followed by eleven h2 sections with h3 subsections. Reading the complete source exposed no visibly unmatched structural tag, malformed attribute, or truncated ending; no machine validation is claimed.
- The eleven navigation fragment destinations are present and distinct: `scope`, `map`, `two`, `floor`, `rare`, `barriers`, `suffix`, `computation`, `precedents`, `replay`, and `proofs`. The source contains the distinct proof item identifiers `l1` through `l13`. No broken fragment link or duplicate identifier was found by reading.
- The textual citations [L1]–[L13], [A1]–[A3], and [E1]–[E2] have corresponding index entries. The proof citations are plain text rather than hyperlinks. This is a navigation convenience limitation, not a false link. The text expressly explains that technical filenames are identifiers, not public downloads.
- Fifteen external literature hyperlinks are written as ordinary HTTPS URLs with descriptive text. Their syntax and destinations as written were inspected; availability, redirects, access permissions, and bibliographic accuracy were not checked. There are no external script, stylesheet, font, image, iframe, or other rendering-resource loads. The named fonts are local font-stack preferences, not remote font requests. The report remains readable without fetching the literature links.

## Chinese text, formulas, and likely presentation

- The Chinese prose is coherent and the principal distinctions are explicit: posterior target versus latent/displayed endpoint rows; base states versus the paid counter; theoretical/statistical conclusions versus implementation and execution evidence. Technical English terms and PASS/NOT RUN are explained by context rather than presented as unexplained validation claims.
- Formulas are visible text using Unicode and HTML subscript/superscript, not a missing renderer or external math dependency. No source-level dropped formula, raw TeX delimiter, or obvious unmatched displayed grouping was found. Risk formulas, probability parameters, and reused precision symbols are introduced or disambiguated in nearby prose. Mathematical validity remains assigned to the factual reviewer.
- Screen layout has a bounded reading width, generous line height, reduced padding/type sizes below 650 px, wrap rules for identifiers/hashes/displayed formulas, and horizontally scrollable table wrappers. These choices plausibly support narrow screens, but actual line breaks, font coverage, table width, and readability have not been rendered or measured.
- Print CSS removes navigation, removes the screen width restriction, reduces type size, discourages separated headings/rows, and makes table overflow visible. Actual pagination, clipping, and printer/font behavior remain unverified.

## Accessibility and optional refinements

The language tag, semantic headings, named navigation, meaningful link text, ordinary selectable formula text, and column-header cells provide a useful baseline. None of the following is a blocking static finding, and no accessibility conformance is claimed:

1. Consider disabling `scroll-behavior:smooth` under `prefers-reduced-motion: reduce`.
2. Consider table captions, explicit `scope="col"`, and accessible labels/focus handling for scrollable table regions. The current simple header rows have implicit column relationships, but keyboard access to overflowing regions varies by browser.
3. Consider linking inline [Lx]/[Ax]/[Ex] references to the corresponding index entries, adding A/E identifiers if doing so. Current plain references are consistent but require scrolling.
4. Consider textual alternatives or MathML for complex formulas if screen-reader-quality mathematical reading becomes a requirement. Unicode with nested sub/sup is visible, but spoken interpretation is unverified.
5. Printed literature citations do not explicitly expand their URLs. If a paper-only reader must recover the sources, add printable URLs or another compact bibliographic locator. Existing hyperlinks may remain actionable in a PDF, depending on the print path; that has not been tested.

## Privacy, provenance, and preservation

- No local machine path, private note path, credential, token, personal sensitive information, or hidden operational prompt was found in the HTML source. Technical proof filenames, mathematical hashes, scholarly URLs, and the quoted sandbox error are relevant non-secret provenance identifiers rather than local filesystem disclosures.
- The 11:38:47 UTC mathematical snapshot of 91 files is distinguished from the two separately copied pre-existing execution-provenance records. The accompanying snapshot note preserves that distinction.
- The report says old reports/proofs remain unchanged and later results require a new version. This review itself did not alter or independently inventory all historical originals, so their global preservation is not independently certified here.
- The execution section consistently distinguishes the earlier failed isolation launch from a scientific run; planned counts from completed cases; static checking from numerical model execution; present-time hashes from historical capture; and current static review from rendering. It does not imply authorization to bypass isolation or retry. The concluding zero-current-execution statements are appropriately scoped.

## Separate factual revisions pending

The author relayed that the independent factual reviewer requested three v2 changes: remove an antecedent not supported by the frozen audit; restrict the β=1 positive matching-rate statement to the proved 0<η≤1/4 range; and explicitly mark k≥3 for the two endpoint constructions. Those are not cured or independently adjudicated by this static review. An immutable v2 needs its own complete-file hash binding and source review.
