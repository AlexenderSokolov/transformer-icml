# Frozen state and suffix report inputs

Mathematical cutoff: 2026-11-05 11:38:47 UTC. The 91 top-level endpoint Markdown sources were frozen at this cutoff. Historical source hashes remain in INPUT_SHA256SUMS.txt; ENDPOINT_SOURCE_MAP.json identifies any public metadata-redacted derivatives. The earlier report bundles and original source files were not overwritten.

Two historical provenance documents were added separately after the mathematical cutoff. They contain no new mathematical results. Their source identities are recorded separately in HISTORICAL_PROVENANCE_SHA256SUMS.txt.

The fixed-positive-floor composition was retracted and subsequently restored using a replacement proof. The mathematical reason and replacement are documented in ONE_STATE_POSITIVE_FLOOR_primary_source_audit.v1.md and KNOWN_CHANNEL_one_state_positive_floor_protected_lower.independent_review.v1.md. This snapshot does not certify communication history.

The strict replay failed isolation before scientific startup and remains NOT RUN. Missing historical pre-run and per-case capture was not recovered. No scientific execution, model run, rendering or executable artifact validation was performed while preparing this report. File inspection, copying and cryptographic identity checks are packaging operations, not scientific tests.
