# State and suffix supplement revision record

v1 is preserved unchanged at SHA-256 c420af36db1996d0a88b829f79e62fef82bc9889bb1696918d3aa20472184600.

v2 is a separate file. Its SHA-256 is 6ce266c90f18305bdb953ae9242a1abf44ef72a40d81080ecc7d5e64d53110de.

Independent factual review requested four improvements, all incorporated in v2:

1. Remove the Foster/Kakade/Qian/Rakhlin and Weber antecedent item, whose specific citations were not present in the frozen source audits. No source was added after the mathematical cutoff to justify that item.
2. Restrict the beta=1 positive matching-rate statement explicitly to the already proved fixed 0<eta<=1/4 range, leaving eta=1/2 zero risk intact.
3. Explicitly restrict endpoint constructions using h=min{k-2,floor(sqrt(M))} to k>=3 and retain the clean-witness small-budget fallback.
4. Clarify that the compiled Transformer receives displayed Z one-hots, not the hidden clean word X.

No original source, previous report, or v1 draft was overwritten. No executable checker, scientific/model test, browser rendering, or public upload was performed. Independent final reviews bind the complete v2 file separately.
