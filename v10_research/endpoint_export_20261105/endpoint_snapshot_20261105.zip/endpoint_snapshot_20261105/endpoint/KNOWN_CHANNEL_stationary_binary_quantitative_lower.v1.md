# Stationary binary known-channel prediction: a quantitative budget lower bound

Date: 2026-11-05 UTC. Pure mathematical analysis. No scientific executable checks, public write, novelty certification, or computational-efficiency claim. Independent review is recorded separately.

## 1. Result and experiment

Let N=M+2. Fix 0<beta<1. There are constants c_beta>0 and M_beta<infinity such that, for every M>=M_beta, integer 0<=k<=M, and 0<=rho<=1, one can choose a disclosed, source-independent, future-blind binary channel C and two stationary, genuinely second-order binary sources theta_-,theta_+ in D2(beta) with the following properties:

- Every output differs from its input in at most k raw tokens.
- For each input word, the probability that its terminal pair changes is at most rho.
- Every transition probability of either source lies in [1/3,2/3].
- Every predictor, even knowing C, has maximum source-specific posterior prediction TV risk at least

      c_beta [1/sqrt(M) + rho min{k/sqrt(M),1}].       (Q1)

The quantifier is existence of a bad known channel within each budget, not a lower for every channel. The channel and local source alternatives may depend on the horizon, beta, k, and rho. The alternatives are separated by order M^(-1/2); no fixed-source inconsistency claim is made.

For fixed rho>0 and 1<=k=o(sqrt(M)), (Q1) gives Omega_(beta,rho)((k+1)/sqrt(M)). This does not match the available O_beta(((k+1)/sqrt(M))^(1/3)) upper over the entire stationary binary D2(beta) class. The sharp rate in that larger class remains open.

The proof replaces the single normalization window in `KNOWN_CHANNEL_stationary_binary_sqrt_lower.v1.md` by disjoint count bins. Each bin is normalized to its own center. The bin is observed, but the within-bin sign is hidden. Many bins carry the needed overlap, so no small single-window probability is lost.

## 2. Source family and local overlap

Set

    alpha=e=(1-beta)/32, q0=1/2-alpha, gamma=1/100,
    delta=gamma/sqrt(M), q_-=q0-delta, q_+=q0+delta,
    theta_q(a,b)(1)=q+(1-2q)b+e(2a-1).

The coefficient 2e is nonzero. Initialize in the unique stationary pair law

    Pi_q(0,0)=Pi_q(1,1)=(1-q-e)/[2(1-2e)],
    Pi_q(0,1)=Pi_q(1,0)=(q-e)/[2(1-2e)].             (Q2)

All transition entries are in [1/3,2/3] for all sufficiently large M, uniformly for every q in [q_-,q_+]. Complement symmetry gives stationary symbol marginal 1/2.

At q0, put s=alpha+e=(1-beta)/16. Since Pi_q0(c,d)<= (1/2+s)/2, the all-state certificate follows from

    P_q0^2(u,v)/Pi_q0(v)
       >=(1-2s)^2/(1+2s)>beta.

Indeed, with x=2s=(1-beta)/8, the last expression equals 1-3x+4x^2/(1+x)>beta. By continuity the same strict D2(beta) certificate holds on [q_-,q_+] for all M>=M_beta after enlarging M_beta.

Rows under the two alternatives differ by 2delta. The Bernoulli KL inequality and the transition floor give

    KL(P_+^(1:N) || P_-^(1:N))
       <=KL(Pi_+||Pi_-)+18 gamma^2.

The initial-law term tends to zero by (Q2). Thus Pinsker gives, for all sufficiently large M,

    TV(P_+^(1:N),P_-^(1:N))<=1/8.                    (Q3)

The same bound holds for every common deterministic function of the clean prefix. We use conventional probability TV throughout.

## 3. The scaffold and conditionally independent eligible bits

Take candidate positions to be the multiples of 3 in [3,N-3]. A candidate j is eligible when

    X_(j-2)=X_(j-1)=X_(j+1)=X_(j+2)=0.

Let H retain every coordinate of X_1,...,X_(N-1) except eligible candidate bits. Eligibility is a function of noncandidate coordinates, so H determines the eligible set I, its size n, and the retained coordinates X_(N-2),X_(N-1). Every historical order-two factor contains at most one candidate, and factors involving an eligible site end by N-1.

Conditional on H, eligible bits are iid Bernoulli(p(q)), with

    p(q)=A(q)/(A(q)+B(q)),
    A(q)=(q-e)(q+e)(1-q-e),
    B(q)=(1-q+e)^3.                                  (Q4)

Their count S is Binomial(n,p(q)). The clean terminal bit B=X_N is conditionally independent of these bits and has probability

    r_q(H)=theta_q(X_(N-2),X_(N-1))(1).               (Q5)

Write p0=p(q0) and lambda(q)=log(p(q)/(1-p(q))). Then

    lambda'(q)=1/(q-e)+1/(q+e)
                 -1/(1-q-e)+3/(1-q+e)>0.            (Q6)

The final two terms have positive sum when 1-q>2e, which holds in a fixed neighborhood of q0. Consequently, after fixing that neighborhood, there are finite positive constants d_beta and L_beta such that

    lambda'(q)>=d_beta,
    |p(q)-p0|<=L_beta |q-q0|,

and p(q) stays in a compact subset of (0,1). All constants below can depend on this fixed neighborhood and beta, but not on M,k,rho.

There is a constant c0>0 for which

    T={c0 M<=n<=M/3},
    min(P_+(T),P_-(T))>=15/16                         (Q7)

for all sufficiently large M. To see this, the stationary expectation of n/M converges to

    nu0=(1/3)P_q0{X_1=X_2=X_4=X_5=0}>0.

The positivity follows already from the all-five-zero event. The common two-step geometric mixing bound and fixed-window nature of eligibility give Var_q(n)=O(M), uniformly in the local interval. Chebyshev applies with, for example, c0=nu0/2. The upper bound n<=M/3 is deterministic.

## 4. A source-independent disjoint-bin channel

For k>=2 put

    h=min{k-1,floor(sqrt(M))}, L=2h+1,
    J_n=floor((n+1)/L).

For j=0,...,J_n-1, define the full bin and its center

    B_j={jL,jL+1,...,jL+2h}, c_j=jL+h.               (Q8)

These bins partition {0,...,J_n L-1}. Counts in the remaining upper interval {J_n L,...,n}, if any, are not normalized. If J_n=0 or S is in that remainder, return the entire input unchanged.

If S is in the full bin B_j:

1. Uniformly normalize eligible bits to count c_j, changing S-c_j uniformly chosen ones to zero if S>c_j, or c_j-S uniformly chosen zeros to one if S<c_j.
2. Set A_sign=1 for S>c_j and A_sign=0 for S<c_j. At equality use an independent fair bit.
3. Draw independent R~Bernoulli(rho), and display W=X_N xor (A_sign R).

The output uses at most h+1<=k edits. Interior edits are outside the final pair, and the conditional final-pair-change probability is at most rho for every input word. The channel uses the input, fixed public parameters and independent random coins, never the unknown source sign or future innovations.

The displayed eligible count equals c_j exactly when normalization ran in bin j. No other full bin has the same center, and every unnormalized remainder count is larger than every center. Thus the observed count identifies the bin and normalization branch without an extra symbol or exposed edit mask. H remains unchanged and recoverable from the output.

## 5. Exact output masses and posterior target

For a fixed H and full bin j, write

    b_q(j|n)=P_q(S in B_j | H),
    v_q(j,n)=E_q[a_j(S) | S in B_j],
    a_j(s)=0,1/2,1 according as s<c_j,s=c_j,s>c_j,
    t_q(j,n)=rho v_q(j,n).

Conditional on its count, the clean eligible configuration is uniform. Uniform normalization maps every count in B_j to a uniform configuration of count c_j. This output law does not depend on the original count, so the normalized word is conditionally independent of A_sign and B given H and bin j.

With r=r_q(H) and t=t_q(j,n), define

    ell_q(1)=r(1-t)+(1-r)t,
    ell_q(0)=rt+(1-r)(1-t).

Both are at least 1/3. If f_q(H) is the clean scaffold law, every normalized output with bin j, normalized word y, and terminal bit w has mass

    f_q(H)b_q(j|n) binomial(n,c_j)^(-1) ell_q(w).      (Q9)

The source-specific posterior probability that B=1 is

    F_1(r,t)=r(1-t)/[r(1-t)+(1-r)t],
    F_0(r,t)=rt/[rt+(1-r)(1-t)].                      (Q10)

Writing b=X_(N-1), the actual next-symbol target under the fixed source is

    p_q(1|z)=q+e(2b-1)+(1-2q)F_w(r_q(H),t_q(j,n)).   (Q11)

Only latent clean histories, not the two source hypotheses, are averaged in this target.

## 6. A constant-probability collection of central bins

Choose a fixed constant

    A0=4+L_beta gamma/3.

Call a full bin central when |c_j-np0|<=A0 sqrt(M). Let D be the event that H is in T and S lies in a central full bin.

For H in T, Var_q(S|H)<=n/4<=M/12 and

    |n p(q)-n p0|<=L_beta gamma sqrt(M)/3.

Chebyshev gives P_q{|S-np(q)|<=2sqrt(M)|H}>=47/48. On this event, S is a distance of order M from both count endpoints, uniformly for H in T, because p0 is bounded away from zero and one. For all sufficiently large M it therefore lies in a full bin rather than the upper remainder, whose length is less than 2sqrt(M)+1. Its center differs from S by at most h<=sqrt(M), hence its bin is central. In particular the conditional central-bin probability is at least 15/16. Together with (Q7),

    min(P_+(D),P_-(D))>=(15/16)^2>=7/8.              (Q12)

Map each clean prefix deterministically to (H,j), where j is its full-bin index or a special remainder symbol. By (Q3), the resulting two laws have TV at most 1/8. Restricting their overlap to D gives

    sum_(H,j in D) min{f_+(H)b_+(j|n),
                         f_-(H)b_-(j|n)}>=3/4.      (Q13)

This is joint scaffold-and-bin overlap. No conditional overlap assertion based solely on scaffold overlap is used.

## 7. Quantitative hidden-sign separation within each central bin

Fix H in T and a central full bin. For q in [q_-,q_+], let

    w_q(s)=binomial(n,s)p(q)^s(1-p(q))^(n-s).

Every s in this bin satisfies |s-np0|<=(A0+1)sqrt(M). Its adjacent log-mass ratio is

    log[w_q(s+1)/w_q(s)]
       =log[(n-s)/(s+1)]+lambda(q).                 (Q14)

Since n>=c0 M, both s/n and (s+1)/n differ from p(q) by O_beta(M^(-1/2)). They and p(q) lie in a fixed compact subinterval of (0,1) for large M. Applying the mean-value bound to log on this interval proves

    |log[w_q(s+1)/w_q(s)]|<=C_beta/sqrt(M).

There are at most 2h<=2sqrt(M) steps within the bin. Hence a finite R_beta>=1 satisfies

    max_(s in B_j) w_q(s)/min_(s in B_j) w_q(s)
       <=R_beta                                                   (Q15)

uniformly in all the quantities under consideration. For example R_beta=exp(2C_beta) works.

Each point under the conditional bin law therefore has probability at least 1/[R_beta(2h+1)]. Consider the lower and upper subsets

    L_j={c_j-h,...,c_j-ceil(h/2)},
    U_j={c_j+ceil(h/2),...,c_j+h}.

Each has at least h/2 points and conditional mass at least 1/(6R_beta). Their points are separated by at least h, and a_j equals zero and one on the respective subsets. For independent S,S' from the conditional bin law, monotonicity gives

    Cov_q(a_j(S),S | B_j)
       =(1/2)E[(a_j(S)-a_j(S'))(S-S') | B_j]
       >=h/(36R_beta^2).                             (Q16)

The binomial family restricted to a fixed bin is an exponential family in lambda. Differentiating its finite sum gives the exact identity

    d E_lambda[a_j(S)|B_j]/d lambda
       =Cov_lambda(a_j(S),S | B_j).

Since lambda(q_+)-lambda(q_-)>=2d_beta gamma/sqrt(M), integration of (Q16) gives

    t_+(j,n)-t_-(j,n)
       >=a_beta rho h/sqrt(M),
    a_beta=d_beta gamma/(18R_beta^2)>0.               (Q17)

This works also for h=1. It uses no normal approximation and loses no central-window mass factor.

## 8. Posterior target separation and the nuisance source difference

For fixed r in [1/3,2/3] and either w, exact subtraction in (Q10) gives

    |F_w(r,t_+)-F_w(r,t_-)|
       =r(1-r)|t_+-t_-|/[ell_+(w)ell_-(w)]
       >=(2/9)|t_+-t_-|.                            (Q18)

Evaluate (Q11) first at q0 and r_q0(H) with the two actual values t_+,t_-. Since 1-2q0=2alpha, their separation is at least

    (4alpha/9)|t_+-t_-|.

For fixed t, the derivative of F_w with respect to r equals t(1-t)/ell(w)^2, at most 9/4. Also dr_q(H)/dq is either 1 or -1. Therefore the derivative of the entire expression in (Q11), with t held fixed, has absolute value at most 1+9/4=13/4. Replacing q0,r_q0 by q_+,r_+ and q_-,r_- costs at most

    (13/2)gamma/sqrt(M).

Put

    A_beta=(4alpha/9)a_beta,
    B0=(13/2)gamma,
    H_beta=max{1,2B0/A_beta}.

On every output represented in D, for either terminal bit,

    |p_+(1|z)-p_-(1|z)|
       >=[A_beta rho h-B0]/sqrt(M).                 (Q19)

In particular, if rho h>=H_beta, this is at least A_beta rho h/[2sqrt(M)]. This explicit nuisance term must not be dropped when k is bounded or rho is small.

## 9. Risk lower for the binned channel

For any predictor, the sum of its two expected Bernoulli-TV losses is at least

    sum_z min{P_+^Z(z),P_-^Z(z)}
                       |p_+(1|z)-p_-(1|z)|.         (Q20)

By (Q9), summing normalized words cancels their binomial factor. Since each terminal mass ell_q(w)>=1/3, (Q13) supplies output overlap on D at least

    (2/3)(3/4)=1/2.

When rho h>=H_beta, (Q19)-(Q20) yield

    max(Risk_+,Risk_-)>=A_beta rho h/[8sqrt(M)].       (Q21)

## 10. Clean baseline covers small k and small rho

Use the identity channel, which meets every nonnegative budget and endpoint-probability bound. Then the target equals the source row at the observed final pair. Its difference between q_+ and q_- is exactly 2gamma/sqrt(M), for every word. From (Q3) and (Q20),

    max(Risk_+,Risk_-)>=7gamma/[8sqrt(M)].             (Q22)

Write b_M=min{k,sqrt(M)}. For k>=2 and M>=4, the binned channel's h satisfies

    b_M/2<=h<=b_M.

If rho h>=H_beta, (Q21) gives A_beta rho b_M/[16sqrt(M)]. Here rho b_M>=1, so this is at least

    (A_beta/32)[1+rho b_M]/sqrt(M).

If rho h<H_beta, then rho b_M<2H_beta, and (Q22) is at least

    [7gamma/(8(1+2H_beta))][1+rho b_M]/sqrt(M).

For k=0,1, use (Q22) directly, with 1+rho b_M<=2. Taking the minimum of these positive constants proves (Q1). All required lower bounds on M were independent of k and rho, so M_beta can be chosen uniformly over their stated ranges.

## 11. A matching rate only in a fixed-positive-floor subclass

There is a precise restricted-class consequence. Fix 0<beta<1, 0<eta<1/2, and 0<rho<=1. Restrict to stationary binary sources in D2(beta) with every transition entry at least the supplied floor eta. Replace the choice of alpha=e above by

    alpha=e=min{(1-beta)/32,(1/2-eta)/8}.

The same D2(beta) argument has slack, and all transition entries exceed eta for sufficiently large M. The proof then gives constants depending on beta and eta in (Q1).

The independently established upper in `KNOWN_CHANNEL_uniform_positive_floor_upper.md` is

    min{1,C_eta(k+1)/sqrt(M)}

uniformly over this subclass and all the allowed known channels. Consequently, for fixed beta<1, eta<1/2, and rho>0, the worst-known-channel minimax rate on this restricted class is

    Theta_(beta,eta,rho)(min{1,(k+1)/sqrt(M)}).       (Q23)

This is a genuinely matching upper/lower statement for that restricted class. It does not give a sharp rate over all of D2(beta), where no fixed eta is imposed. It does not claim constants uniform as beta approaches one, eta approaches one-half, or rho approaches zero. The quantitative lower (Q1) itself is uniform in rho with its explicit rho factor.

## Scope and limitations

- The clean initialization is stationary, not arbitrary or unknown separately from the transition table.
- The channel is disclosed and common to both alternatives, with its realized normalization choices, hidden sign, endpoint coin and edit mask undisclosed.
- The channel may inspect the entire available clean history; it is future-blind, not required to be online or causal within that history.
- Each target is conditioned under its own fixed source. A two-point testing argument does not turn that target into a Bayesian mixture over sources.
- The full stationary binary D2(beta) minimax rate remains between the quantitative lower and the existing power-1/3 upper. The consistency budget threshold remains k=o(sqrt(M)) for fixed beta<1 and rho>0.
- The beta=1 boundary is excluded from the amplification lower. There the all-state certificate forces an iid source, as established in the square-root lower note.
- No executable confirmation, public publication, or claim of prior-art originality is part of this artifact.
