# Independent review of the complete explicit log-free composition

Review time: **2026-11-05 06:23:21 UTC**.

Reviewed file: `./KNOWN_CHANNEL_full_logfree_transformer_composition.candidate.v1.md`.

Independently measured SHA-256: `616be470e1fae470cef701614ec4a9837be67736cf2317fb052bcaa91123e621`.

This review binds the present analytical conclusion to those exact current bytes. It does not infer an earlier file hash or retroactively extend the earlier fitted-posterior-only review. The earlier bridge, addendum, review and attestation are unchanged. No scientific executable tests, numerical experiments, public writes or model execution were performed.

## Conclusion and scope

**The complete candidate passes this independent analytical review.** The explicit concentration constants, fitted log-ratio estimates, observable branches, risk assembly and paid arithmetic implementation support the displayed sufficient upper bound

    E|q_r(Z)-P_(theta,C)(X_(N+1)=1 | Z)|
      <= min{1, 8A ((k+1)^2/M)^(1/3) + 2^-r}.

This conclusion requires exactly the candidate's assumptions: stationary binary order-two sources, M>=64, 1<=k<=M, a finite public positive rational minorization lower bound, and the normalized rational online finite-state channel subclass with a strict all-realization edit cap and source-independent auxiliary randomness. It is a full log-free-estimator result, rather than only evaluation of a fitted posterior.

It is not a proof of the sharp rho interpolation, a matching restricted-channel lower bound, an arbitrary-initial-law theorem, a PreLN implementation, training achievability, numerical practicality, novelty, or floating-point correctness.

## 1. Finite beta certificate and numerical constants

The chosen u is the least integer u>=1 satisfying 2^-u<=beta_0. It can be computed by finite integer comparisons on the supplied rational number. This yields b<=min{beta_0,1/2}, so replacing the promised minorization by b is legitimate. The source remains unknown: the network does not verify the unknown source kernel's certificate from one sample. The certificate is a public model-class assumption, not an estimated source parameter.

The exponent identities are correct:

    D_c=32/b,
    H=2^20 D_c^2=2^(30+2u),
    B_*=2^40 H^4,
    A=B_*/b^2=2^(160+10u).

In particular H is far larger than every concentration constant it replaces. A is deliberately much larger than necessary. No practical finite-sample or sharp beta dependence follows from these constants.

## 2. Regeneration and future-conditioned count estimates

For a refresh cycle of stationary mean p, conditional Jensen applied to its average centered indicator gives

    E(|W|^s | L) <= 2p L^s.

The geometric tail bound P(L>x)<=2 exp(-bx), valid for b<=1/2, gives E L^s<=2s!b^-s. Thus the displayed centered-cycle mgf envelope with H_0=4/b is valid for both signs of lambda.

The first complete cycle covering the deterministic horizon is a stopping time for the complete-cycle filtration and has index at most n. Optional stopping of the nonnegative exponential supermartingale, followed by the deterministic bound on that index, gives the stated stopped-sum mgf and Bernstein tail. This step does not condition the final partial-cycle reward to have mean zero.

The forward remainder beyond a deterministic time is controlled by future independent refresh coins. The arbitrary-start initial block is controlled by its first refresh. Adding their two 2t/b bounds yields the displayed coefficient 8/b and failure probability 4e^-t. No maximum over n cycle lengths is taken, so no horizon logarithm is hidden.

For the triple chain, T^3(h,g)>=b Lambda(g) follows directly by factoring two pair transitions and the final successor transition. Stationary time reversal preserves this minorization on positive support. Conditioning on the future symbol changes the starting law of the reversed chain, not its kernel. Three reversed residue classes therefore permit the arbitrary-start count estimate. Their square-root terms sum to at most sqrt(3v), and their linear terms sum to 3t. Consequently D_c=32/b and 12e^-t are sufficient for all the stated triple, context and generated-symbol counts, under both required laws.

The T=Exp(1)+4 domination is valid because e^4>12 and the comparison is trivial below t=4. It yields

    E(V-v)^2 <= 2D_c^2(5v+26) <=64D_c^2(v+1).

For v>=1 and alpha=2D_c lambda sqrt(v)<=1/2, the exponential-moment comparison reduces to e^(4alpha)/(1-alpha). Its derivative on this interval is at most 12e^2<128, proving the displayed linear envelope. The deficit bound follows by choosing t=v/(64D_c^2); for smaller v its H-envelope exceeds one. All three parts of F2 therefore hold with the explicit H.

## 3. Log-ratio constants and the displayed-data event

The lower bounds theta_u(c)>=b pi(c), Pi(u)>=b m^2 and Pi(u)theta_u(c)>=b^2m^3 follow from all-state minorization and stationarity. When m>=a=Aa_0, they give v>=B_*j^2, with j=k+1. This also implies every denominator and edit-shift side condition used on G.

On the ordinary-numerator event, put

    U=2|C-v|/v+2|J-w|/w+10j/v.

Cauchy-Schwarz and F2 give the concrete bound

    E exp(ell U)
      <= exp(d)(1+4H ell/sqrt(v)),
    d=10ell j/v<=1.

The conditions on lambda hold because ell<=256j and sqrt(v)>=1024Hj. Using exp(d)-1<=2d and exp(d)<=3 yields the candidate's ordinary contribution 12H ell/sqrt(v)+20ell j/v.

On the small-numerator event, the clean deficit is at least v/4, while add-one gives exp(S)<=3v/2. The elementary inequality log(3v/2)<=2sqrt(v), together with sqrt(v)>=1024Hj, implies ell log(3v/2)<=v/(2H). Thus the contribution is at most H exp(-v/(2H))<=H^2 ell/sqrt(v). The total fits comfortably inside the stated coefficient 64H^2 in F3.

For the initial-law ratios, the direct bound D_u<=2|J-w|/w+8j/w leads to the same safe envelope F4. The moments are never taken conditional on G. The future-conditioned clean count laws and pathwise edit inequalities are sufficient.

## 4. Posterior comparison and risk assembly

The likelihood-ratio oscillation is controlled over clean preimages of one displayed word. Their Hamming distance is at most 2k, so the historical triple discrepancy count is at most 6k. The channel factor cancels in the fitted-to-true ratio, while future blindness supplies the conditional-next-symbol identity. This is the appropriate source-specific same-history target.

There are eight transition coordinates and four initial-law coordinates. Twelve-factor Hölder requires exponents no greater than 156j. Since 64*156=9984<2^14, and v>=b^2Mm^3, the claimed K_*=2^14H^2/b^2 dominates the resulting exponential-moment coefficient. Truncating errors by the displayed-data event makes the posterior weighting identity valid. No pointwise substitution p(z)<=m is used.

The exceptional-event calculation also checks. Four context failures cost at most 128H/(bMm^2) in total. The frequency failure costs at most 32H/(Mm), which is at most 32H/(bMm^2). Their sum is below the displayed 256H/(bMm^2).

For m>=a, a sharper intermediate risk expression is

    [4A + K_*/sqrt(A) + K_*/A^2
           +256H/(bA^2j^2)] a_0.

Dropping the denominators gives the candidate's looser expression [4A+2K_*+256H/b]a_0. The explicit A dominates 2K_*+256H/b, so the bound 5Aa_0 is valid.

For m<a, the shift k/M<=a/2 holds, the good-frequency event chooses the true majority, and its integrated loss is at most m. The remaining probability is bounded by 4H[1/(Ma)+1/(M^2a^2)]<=8Ha_0 in the active regime. This is below the claimed 2Aa_0 total. The degenerate m=0 case follows directly from the edit cap. In the saturated regime, the constant 1/2 output has loss at most 1/2<8Aa_0. These arguments establish F8, and the final deterministic approximation adds at most 2^-r.

## 5. Observable branch tests and complete arithmetic

Both branch tests are algebraically exact:

    a>1/16 iff 4096A^3j^2>M,
    h/M<=2a iff h^3<=8A^3j^2M^2.

Only public integers and displayed-symbol counts enter. The true minority m, source law, proof event G and future-symbol condition are not supplied to the model. The nontrivial majority branch cannot have an ambiguous empirical tie, although any fixed tie convention makes the total algorithm well defined.

The posterior branch retains the guarded zero-evidence convention. Branches returning 1/2 or a majority bit are exact, and a Boolean selector chooses the output word, including the possible integer bit. Thus the uniform implementation error relative to the exact full algorithm is at most 2^-r on every displayed word.

A^3 is a power of two of exponent 480+30u. Threshold products require only O(u+log N) bits, rather than time proportional to A itself. The proposed B_full=B_base+30u+512 covers these comparisons, their intermediate products, the exact posterior integer arithmetic and shifted division numerator. The padded G_full bounds constant wires, source fitting, added counters, comparisons and output selection. A finite beta-certificate processing cost is separately charged; u<=t_beta+1 is a safe representation bound.

## 6. Transformer resources and limits

Applying the previously reviewed compilers to this enlarged circuit is valid because every row still supplies a valid prefix-padded Boolean word. The additional integer comparisons are ordinary Boolean gates, so they preserve the all-row norm invariant.

- Growing wire bank: d,L=O(G_full), scalar rational size O(r+log N+log G_full).
- Two stacks: d=64, FFN128, L=O(N log N+G_full^2), scalar rational size O(G_full+r+log N).

The large threshold constants occur as finite bits and counted instructions, not large affine coefficients, activations or attention-score gaps. The existing dense parameter, computation and activation ledgers continue to apply after replacing G by G_full. Certificate processing, channel denominator preprocessing, Boolean compilation and parameter emission remain paid work.

This is an exact-rational mathematical implementation. It has no mandatory normalization layers and establishes neither ordinary float stability nor a trained implementation. The endpoint-aware estimator and public selection required for the sharp rho interpolation remain separate work, as the candidate states. The present approval is confined to the complete explicit log-free upper and its two stated computational realizations.
