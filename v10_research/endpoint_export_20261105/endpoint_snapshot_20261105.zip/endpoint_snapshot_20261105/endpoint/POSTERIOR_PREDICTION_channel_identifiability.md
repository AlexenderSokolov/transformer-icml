# Actual prediction after a corrupted history: channel identifiability

Date: 2026-11-05 UTC. Pure mathematical analysis. No scientific code, numerical experiment, public write, external novelty claim, or formal verification.

## Result first

The genuine next-symbol law after seeing a corrupted history is a third target, distinct from both targets in EPR001:

    p_(theta,mu,C)(z) = Law(X_(N+1) | Z=z).

For the future-blind observation channel defined below, this is the posterior average of the original clean terminal row. EPR001's upper transfers by conditional Jensen. Its original endpoint lower does NOT transfer: if the complete source law and channel are known, this posterior target is exactly computable and its estimation loss is zero.

Nevertheless, when the channel is unknown to the predictor, a different endpoint lower gives the same EPR001 minimax profile. The obstruction is channel nonidentifiability. Identity and a last-symbol heat-bath channel have exactly the same law of the entire observed word, but their actual next-symbol conditional laws differ by order rho(1-beta). This persists even if the complete source law is revealed to the predictor.

## 1. Experiment and the essential conditional-independence assumption

Use EPR001's alphabet K>=2, M>=64, N=M+2, all-state source class D2(beta), stationary or arbitrary-start experiment, Hamming budget 0<=k<=M, and per-word endpoint reliability condition

    C{d_H(X,Z)<=k | X=x}=1,
    C{S(Z)!=S(x) | X=x}<=rho, every x,
    S(x)=(x_(N-1),x_N).

Let mu denote the initial pair law when needed. The channel is a fixed stochastic kernel C(z|x), allowed to inspect the full observed clean history but not future symbols or the predictor's seed. Its random seed is independent of future source innovations. In particular, impose

    X_(N+1) is conditionally independent of Z given X.

Corruption changes observations only. It does not replace the physical state from which the source generates its next symbol. Given X, the next law remains theta_(S(X)), not theta_(S(Z)).

For each FIXED generating pair (theta,mu,C), define

    p_(theta,mu,C)(Z) = E_(theta,mu,C)[theta_(S(X)) | Z].       (P1)

The equality is exactly the conditional-independence consequence. Null-probability outputs can be assigned arbitrary versions. The predictor sees Z and public K,M,k,beta,rho, but receives neither theta, mu nor C. Its random seed is independent. Its risk is

    E_(theta,mu,C) TV(q(Z),p_(theta,mu,C)(Z)).                (P2)

The target in (P2) is not averaged over a prior on unknown source/channel hypotheses. A prior used in a minimax lower is only a proof device.

## 2. Upper and protected lower transfer

For any predictor q and fixed source/channel, conditional convexity of TV gives

    E TV(q(Z),p_(theta,mu,C)(Z))
       <= E TV(q(Z),theta_(S(X))).                          (P3)

This remains true for an independently randomized q by conditioning additionally on its seed. Hence EPR001's actual estimator, not merely an existential bound, gives the same predictive upper. For k>=1 it is

    (2A_K+sqrt(K)/2)M^(-1/2) + (2B_K+1)F + 2rho(1-beta).

For k=0 use the existing clean branch. All constants, alphabet branches and the finite-resource caveats remain those in EPR001.

If a channel preserves the terminal pair, theta_(S(X))=theta_(S(Z)) is Z-measurable for fixed theta. Therefore

    p_(theta,mu,C)(Z)=theta_(S(Z))=theta_(S(X)) a.s.          (P4)

The protected lower proofs apply without any change of loss. This imports the clean statistical and protected-corruption terms s and F. It does not import either EPR endpoint witness: the known-source erasure witness concerns hidden-row reconstruction loss; the rare forged-row witness has an actual next law that is constant on its deterministic clean histories.

## 3. A law-preserving channel pair gives the missing endpoint lower

Assume k>=1. Put

    delta=1-beta, alpha=min(delta/2,1/4).

Fix the stationary symmetric binary first-order source

    T(y,y)=1/2+alpha,
    T(y,1-y)=1/2-alpha, y in {0,1}.

Its second-order table depends only on the second symbol. For K>2, when that second symbol is unused, take the next symbol binary-uniform. The stationary symbol law is binary-uniform and

    Pi(c,d)=(1/2)T(c,d), c,d in {0,1}.

For a starting state whose second symbol is binary,

    P^2((a,b),(c,d))=T(b,c)T(c,d)
       >=(1-2alpha)Pi(c,d)>=beta Pi(c,d).

For an unused second symbol the first step is uniform, giving exactly Pi after two steps. Targets outside binary pair support have Pi mass zero. Thus the required all-state certificate holds.

Consider these TWO channels, whose full algorithms may both be disclosed to the predictor, but whose identity in force is not:

- C0 is identity.
- C1 draws B~Bernoulli(rho), independently. If B=0 it is identity. If B=1 and the input word is all-binary, independently redraw only its last symbol from T(x_(N-1),.). On non-binary words it is identity.

The latter extension makes both channels defined on every K-letter word. Both are source-independent fixed kernels: their only constants are alpha, which is determined by public beta, and rho. They do not receive theta, mu, a hidden stationary law or the future. Every realization changes at most one symbol. On all-binary words the endpoint-change probability is at most rho(1/2+alpha), and on other words it is zero; in particular the required bound rho holds for every word.

The source may now be revealed completely to the predictor. This only makes a lower harder to prove.

### 3.1 Identical full observed-word laws

Given the prefix H=X_(1:N-1), the original last symbol has law T(X_(N-1),.). Redrawing it independently from that same law preserves the conditional distribution of the whole word. Consequently

    Law_(T,C0)(Z) = Law_(T,C1)(Z) = Law_T(X).              (P5)

In particular B is still Bernoulli(rho) conditional on Z in the C1 experiment. On B=1, original X_N and displayed Z_N are independent conditional on H.

### 3.2 Distinct actual predictive laws

Write s_v=2v-1 for binary v. Under identity,

    p0(1|z)=1/2+alpha s_(z_N).

Under the heat-bath branch, the next symbol still comes from ORIGINAL X_N, so

    E[T(X_N,1)|H]=1/2+2alpha^2 s_(z_(N-1)).

Thus

    p1(1|z)=(1-rho)p0(1|z)
               +rho[1/2+2alpha^2 s_(z_(N-1))].           (P6)

Under the common observed-word law, P(Z_N=Z_(N-1))=1/2+alpha. Therefore

    E TV(p0(Z),p1(Z))
       =rho alpha[(1/2+alpha)(1-2alpha)
                     +(1/2-alpha)(1+2alpha)]
       =rho alpha(1-4alpha^2).                           (P7)

For any predictor, the triangle inequality under the COMMON law (P5) gives

    (Risk_C0(q)+Risk_C1(q))/2
       >=rho alpha(1-4alpha^2)/2
       >=3rho delta/32.                                 (P8)

The last step uses alpha>=delta/4 and alpha<=1/4. This includes delta=0 trivially. For this two-channel known-source subexperiment, the midpoint q=(p0+p1)/2 attains equality in the first lower expression, so the first value in (P8) is its exact minimax risk.

This is not an assertion that no single channel can be learned from labeled data. It states that corrupted histories alone have the exact same distribution for these two channels. Even extra independent unlabeled corrupted histories cannot identify which of these two channels is in force. Observed next-symbol labels would be different information and are not part of the stated experiment.

## 4. Unknown-source/unknown-channel theorem

Retain EPR001's definitions

    s=M^(-1/2),
    e=max(beta,1/M) for K>=3,
    e=max(sqrt(beta),1/M) for K=2,
    F=0 if k=0,
    F=(k/M)[1+log(1+1/(ek))] if k>=1,
    H=min{1,max{s,F,rho(1-beta)1{k>=1}}}.

Let R_stat^pred and R_all^pred be minimax risks for (P2), with one common per-word channel class and the channel unknown to the predictor. Then the inherited protected lower, (P3), and (P8) yield

    c_K H <= R_stat^pred <= R_all^pred <= C_K H.           (P9)

The EPR001 constants c_K and C_K remain sufficient because its inherited lower constants are smaller than 3/32. Combine separate source/channel witnesses by their maximum, not their sum. No endpoint operation is composed with a full k-edit protected witness.

The new proof ingredient is (P5)-(P8), rather than an unsupported transfer of hidden-terminal-row Bayes loss. This note does not claim external novelty or an independent re-proof of the protected predecessor theorems.

## 5. What source or channel disclosure changes

### 5.1 Known transition table, unknown channel

Let D(theta)=max_(u,v)TV(theta_u,theta_v), so D(theta)<=1-beta. Define G={S(X)=S(Z)}. For any fixed source and channel, (P1) gives the useful pointwise comparison

    TV(p_(theta,mu,C)(Z),theta_(S(Z)))
       <=D(theta)Pr(G^c|Z).

Therefore the table-aware predictor q(Z)=theta_(S(Z)) satisfies

    E TV(q(Z),p_(theta,mu,C)(Z))
       <=rho D(theta)<=rho(1-beta),                    (P10)

with zero when k=0. For k>=1, together with the fully revealed-source construction, this proves a worst-source order rho(1-beta) for channel uncertainty alone. The per-word condition does not assert Pr(G^c|Z=z)<=rho. The conclusion (P10) is integrated over Z.

### 5.2 Known complete source law and known channel

When theta, mu and C are all known, (P1) itself is an admissible predictor and risk (P2) is zero. Zero loss here means the conditional distribution is known, not that the next symbol can be guessed without error. This is information-theoretic and makes no computation or efficiency claim. Original hidden-row risk can nevertheless remain positive, precisely as in EPR001's known-source erasure example.

### 5.3 Known channel, unknown source

This is a different minimax experiment: the predictor can take C as an input. The general upper (P3) remains valid, but the two-channel endpoint lower no longer applies. The two candidate channels must not be compared while hiding their identity in an experiment that reveals it.

Protected-target identity (P4) still holds. Any protected lower proved with one fixed common channel for all source hypotheses also survives disclosure of that channel. This note does not independently audit all predecessor lower proof interfaces for channel disclosure, nor assert a full sharp known-channel minimax rate. In particular, neither a universal endpoint floor nor its universal absence is established here for the full arbitrary known-channel, unknown-source class.

## 6. Why future blindness is essential, including at beta=1

A stochastic kernel on histories must be coupled to the future in the stipulated independent way. Merely writing a marginal C(z|x) is insufficient if its random seed can share future source randomness.

For a sharp counterexample outside the admissible model, assume k>=1 and take IID fair binary symbols, so beta=1 and every original source row is Bernoulli(1/2). Compare identity against a future-aware channel that, with independent probability rho, replaces only Z_N by X_(N+1). Both have exactly the same IID-fair observed-word law, have at most one edit, and have per-word endpoint-change probability rho/2<=rho. Yet their predictive targets are

    p0(1|z)=1/2,
    p1(1|z)=(1-rho)/2+rho z_N.

The same triangle argument gives unknown-channel predictive risk at least rho/4. This survives beta=1, where EPR001's endpoint term is zero. Such a channel is forbidden by future blindness; it demonstrates why the conditional independence in section 1 is necessary for (P1), (P3), and the theorem.

## Sources and review scope

- `EPR001_endpoint_probability_interpolation.md`: exact source/channel definitions, common-component lemma, protected interfaces, upper estimator and constants.
- `EDIT_OVERLAP_and_TARGET_BOUNDARIES.md`: original-versus-corrupted-row distinction and existing result boundaries.
- `EPR001_independent_analytical_review.md`: earlier scoped audit and predecessor caveats.

The endpoint construction and target-transfer argument received a separate analytical check during this task. This document is a new analytical supplement, not an alteration of EPR001's target definition.
