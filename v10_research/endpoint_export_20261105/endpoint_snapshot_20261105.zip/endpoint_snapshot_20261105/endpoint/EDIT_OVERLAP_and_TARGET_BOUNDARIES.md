# Raw token edits: exact overlap and target boundaries

Date: 2026-11-05. Analytical supplement; no executable checks or publication.

## 1. Triple overlap, not three independent corruptions

For words x,z of length N=M+2 let E={i:x_i!=z_i}. A changed symbol i can affect only historical triples ending at i,i+1,i+2, after intersection with {3,...,N}. Define

    A(E)= union_(i in E) ({i,i+1,i+2} intersect {3,...,N}),
    h(E)=|A(E)|.

Then the set Q of actually changed triples equals A(E): a triple changes exactly when at least one of its three symbols differs. Thus |Q|=h(E)<=min(M,3|E|). The complete triple-count histogram obeys

    ||C(z)-C(x)||_1 <= 2|Q| <= 2h(E).

This holds for simultaneous, adjacent, adversarial edits. It is not an IID contamination model for triples, and arbitrary altered triple histograms need not correspond to any nearby word.

For an interior edit set e_1<...<e_k with all length-three affected intervals untruncated by the boundaries,

    h(E)=3+sum_(j=2)^k min(3,e_j-e_(j-1)), k>=1.

A single contiguous interior block of k edits therefore has h(E)=k+2, rather than 3k. Boundary truncation only reduces this number. This geometric refinement does not by itself establish a sharp minimax theorem for block-constrained adversaries.

## 2. A sharper normalized-row bound

Fix any query row u, the SAME row for both words. Let J,J' be its two total counts. Among the actually changed triples Q let a_u count the old triples whose old context is u, and b_u count the new triples whose new context is u. The unchanged triples in row u have a common successor-count vector w with mass U. Thus

    C_u=w+r, |r|_1=a_u,
    C'_u=w+r', |r'|_1=b_u,
    J=U+a_u, J'=U+b_u.

After add-one smoothing, both distributions contain the common submeasure

    (w+1)/(max(J,J')+K).

The total mass of this common submeasure is (U+K)/(max(J,J')+K). Hence

    TV((C_u+1)/(J+K), (C'_u+1)/(J'+K))
       <= max(a_u,b_u)/(max(J,J')+K)
       <= |Q|/(max(J,J')+K)
       <= h(E)/(J+K)
       <= 3k/(J+K).                                  (A)

Include a unit cap if using only the final coarser expressions. The first expression is already at most one. This improves the coarse 6k/(J+K) predecessor estimate by using shared mass rather than only an L1 normalization inequality. The factors and dependence are pathwise; no random-row independence is needed. Row-local incidence max(a_u,b_u) can be much smaller than global h(E).

These are analysis variables, not observable certificates when the clean word and edit mask are hidden. Formula (A) does not authorize an estimator to insert an unknown actual damage budget. A public block budget or other known restriction can be used only after the estimator and its accessible information are specified.

## 3. Why same-row sensitivity does not solve edited queries

If S(x)=S(z), apply (A) to the actual terminal row and combine it with a correct unconditional terminal-occupation theorem. The possible scarcity of that row produces the existing logarithmic corruption cost in weak-certificate regimes. A bare k/M assertion misses the small denominator.

If S(x)!=S(z), formula (A) still compares counts at a fixed chosen u, but choosing u=S(z) makes it an attacker-selected row rather than the clean actual terminal row. The clean terminal-risk theorem cannot simply be applied to that new query. A forged pair can be unsupported or arbitrarily rare in the clean source. The EPR001 clipping wrapper handles this event through a separate row-diameter budget and its probability.

The original target theta_(S(x)) and corrupted target theta_(S(z)) have distinct mechanisms. With the source known, the corrupted target is always computable from z, while the original target can remain uncertain after an endpoint erasure. With the source unknown, a forged terminal pair can query a row absent from all useful clean observations. EPR001 gives explicit witnesses for both statements.

## 4. Existing results that must not be repackaged as new

- SC001/SC002 already establish that the weak-certificate logarithmic k-edit penalty is intrinsic even when the entire corrupted word is visible.
- SC003 plus BT002 already close the binary protected-terminal frontier with cutoff max(sqrt(beta),1/M). SC003 alone predates the lower completion.
- EP001 already identifies a constant original-target floor from one editable endpoint for fixed beta<1.
- RG001 concerns perturbing a fixed-dimensional encoded coordinate bank, not changing input tokens. A robust inverse of that bank cannot reconstruct information the raw edit channel has erased.
- JP001/RE001 already compose source edits with post-encoding noise and precision. Any new claim must preserve their exact information cuts and resource accounting.

The new contribution proposed here is narrower: probabilistic endpoint reliability, a beta-aware clipping wrapper with a repaired-channel proof, explicit distinction of the two target risks, and a deterministic shared-count refinement. External novelty is unassessed.

## 5. Fixed-positive-probability baseline: a separate boundary illustration

The shared-model document discusses the narrower binary class

    eta <= theta_u(1) <= 1-eta for every pair u,
    fixed 0<eta<1/2.

In this class, selected-row add-one queried at S(Z) has corrupted-target risk

    O_eta(M^(-1/2)+k/M),

even if endpoint substitutions are permitted without a reliability restriction. Thus it is consistent for k=o(M). This is a separate elementary upper, not an extension of EPR001's full minimax theorem or a novelty claim.

Here is a full argument with loose explicit constants. Let S_t=(X_(t-1),X_t), J_u=sum_(t=2)^(M+1) 1{S_t=u}, and C_(u,1)=sum_(t=2)^(M+1) 1{S_t=u} X_(t+1). Sample pair end times t=4,6,...<=M+1, with L=floor((M-1)/2). Conditional on the history through t-2, every named pair u=(c,d) has probability at least eta^2, because the two required symbol transitions each have probability at least eta. This holds with arbitrary initial pair law.

The conditional moment-generating-function argument for Bernoulli lower tails gives

    Pr{J_u < eta^2 L/2} <= exp(-eta^2 L/8).

Independence of sampled pair indicators is not asserted: iterate

    E[exp(-lambda I_j) | previous sampled history]
       <= 1-eta^2+eta^2 exp(-lambda)

and apply the usual exponential Markov argument. Since L>=M/4 for M>=4, with probability at least 1-4exp(-eta^2 L/8), all four J_u are at least eta^2 M/8.

For each u the sum

    Z_u=C_(u,1)-theta_u(1)J_u

is a predictable-row martingale sum before any conditioning. Orthogonality gives E Z_u^2<=M and hence sum_u E|Z_u|<=4sqrt(M). The clean add-one coordinate satisfies

    |(C_(u,1)+1)/(J_u+2)-theta_u(1)|
       <= (|Z_u|+1)/(J_u+2).

On the simultaneous occupancy event, maximize over all four rows and use the sum of these numerators. The clean expected maximum-row error is at most

    32/(eta^2 sqrt(M))+32/(eta^2 M)
       +4exp(-eta^2 L/8).

For every corrupted word with at most k substitutions, (A) adds at most 24k/(eta^2 M) on that same event, uniformly over all possible selected rows, including S(Z). Therefore

    E TV(q_addone(Z),theta_(S(Z)))
       <= min{1, 32/(eta^2 sqrt(M))+32/(eta^2 M)
                    +24k/(eta^2 M)+4exp(-eta^2 L/8)}.    (B)

This proof handles endpoint selection by simultaneous row estimation, not by incorrectly treating the corrupted query as an ordinary clean terminal state. Neither the edit mask nor the clean counts are algorithm inputs.

The original-target obstruction is different. Even inside the fixed-eta class, choose the symmetric known-source example with

    0<alpha<=min{(1-beta)/2,1/2-eta,1/4}.

When beta<1 and eta<1/2 are fixed, alpha can be a positive constant. A last-symbol erasure still leaves original-target posterior loss alpha-2alpha^2>0 on the erasure branch. Thus (B) cannot be transferred to the original target merely by relabeling the endpoint.
