# Stationary binary known-channel prediction: a minority-weighted upper

Date: 2026-11-05 UTC. Pure mathematical analysis. No executable scientific checks, public writes, novelty certification, or efficient-computation claim. Immutable proof candidate for independent review.

## 1. Claim

Fix 0<beta<=1. For M>=64, N=M+2, and 0<=k<=M, every disclosed source-independent future-blind binary strict-k-edit channel C admits a source-independent statistical predictor with

    sup_{stationary theta in D2(beta)}
      E_theta |q_C(Z)-P_theta,C(X_(N+1)=1|Z)|
       <= min{1,C_beta [((k+1)^2 log(eM))/M]^(1/3)}.  (U1)

No transition floor is supplied or assumed. The result is uniform over all the allowed channels and hence over every endpoint-probability constraint rho. It is not a sharp-rate claim: the rare-budget lower has the same power without the logarithmic factor. The estimator is statistical and may sum over exponentially many latent histories.

The proof combines rare-event Bernstein concentration, relative rather than absolute transition errors, and a posterior comparison whose integrated loss is weighted by the true minority mass.

## 2. A stationary rare-occupation concentration lemma

Let K be a finite-state Markov kernel with stationary law Pi and K(x,.)>=beta Pi(.) for all x. Start the chain in Pi. If f is an indicator with p=Pi(f), then for any n>=1 and 0<delta<1,

    P{|sum_{i=1}^n f(Y_i)-np|
       >C_beta [sqrt(np log(4/delta))+log(4n/delta)]}
       <=delta.                                    (U2)

Here is a regenerative proof, including the random terminal cycle.

For beta<1 write K=beta Pi+(1-beta)Q. The stochastic kernel Q preserves Pi. Generate a cycle by drawing its initial state from Pi, following Q for a geometric number L of states, then restarting independently from Pi. The cycle length L has support {1,2,...}, success probability beta, and is independent of its Q-path. The resulting concatenation has exactly kernel K and stationary initialization. Successive full cycles, including their lengths and paths, are iid.

For one full cycle define

    Z=sum_{i=1}^L f(Y_i)-pL.

Conditional on L, every Q-state has law Pi, so E[Z|L]=0. For integers j>=2, using count^j<=L^(j-1) count,

    E|Z|^j <= 2^j p E L^j <= p j! B_beta^j         (U3)

for a finite B_beta. The last inequality follows from the geometric exponential moment, absorbing its fixed prefactor into B_beta. Hence for |lambda|<1/B_beta,

    E exp(lambda Z)
      <= exp{p B_beta^2 lambda^2/(1-B_beta|lambda|)}. (U4)

Let T_n be the first cycle index whose cumulative length is at least n. It is a stopping time for the complete-cycle filtration and T_n<=n deterministically. For either sign of lambda, the exponential process obtained from (U4) is a nonnegative supermartingale. Optional stopping at this bounded stopping time, and the bound T_n<=n, give

    E exp(lambda sum_{j=1}^{T_n} Z_j)
      <= exp{n p B_beta^2 lambda^2/(1-B_beta|lambda|)}.

Chernoff optimization gives the usual Bernstein bound for this stopped sum, with scale C_beta[sqrt(np log(4/delta))+log(4/delta)]. This step uses a bounded stopping time, not an unproved Wald identity or independence of T_n and the cycle rewards.

The difference between the centered first-n-state count and the stopped complete-cycle sum has absolute value at most L_{T_n}. Since T_n<=n,

    P{L_{T_n}>ell}<=P{max_{j<=n}L_j>ell}
      <=n(1-beta)^floor(ell).

Taking ell=C_beta log(4n/delta) bounds the overshoot with failure probability at most delta/2. Combining the two bounds proves (U2). For beta=1, K=Pi, cycles have length one and the same proof reduces to the iid bound.

For the original pair chain P, the class certificate is P^2>=beta Pi. Split any stationary consecutive pair-state count into its two parity subsequences. Each has kernel P^2 and stationary law Pi. Apply (U2) to both and take a union bound; no independence between the parity subsequences is needed. Thus (U2), with another C_beta, holds for M consecutive states of the pair chain as well.

## 3. Source geometry and estimators

Let pi be the stationary symbol marginal and m=min{pi(0),pi(1)}. The all-state minorization gives

    theta_u(c)>=beta pi(c),
    Pi(a,b)>=beta pi(a)pi(b).                    (U5)

Consequently, if m>0, every pair mass is at least beta m^2 and every pair-successor mass Pi(u)theta_u(c) is at least beta^2 m^3.

Let J_u be the M clean context counts, C_{u,c} their successor counts, and J'_u,C'_{u,c} the same counts in the displayed word. Use ordinary add-one estimates

    theta_hat_u(c)=(C'_{u,c}+1)/(J'_u+2),
    Pi_hat(u)=(J'_u+1)/(M+4).                    (U6)

They are positive probability vectors. Pi_hat need not be stationary for theta_hat. Both are computed only from the displayed word, not the unknown true source.

A raw-token edit affects at most two counted context pairs and at most three counted triples. Therefore, pathwise for every allowed corruption,

    |J'_u-J_u|<=2k,
    |C'_{u,c}-C_{u,c}|<=3k.                     (U7)

The channel may inspect the whole available history and randomize; these comparisons do not assume a nonadaptive attack or independence from the clean counts.

## 4. Simultaneous relative estimation event

Write ell=log(100M). There are constants K_beta and C such that, whenever

    M m^3 >= A_beta^3 (k+1)^2 ell               (U8)

with A_beta sufficiently large, an event G has probability at least 1-C M^(-3), uniformly over every allowed channel, on which

    max_{u,c} |theta_hat_u(c)/theta_u(c)-1|
      <=epsilon_m,
    epsilon_m=K_beta[sqrt(ell/(M m^3))
                         +(k+ell)/(M m^3)],

    max_u |Pi_hat(u)/Pi(u)-1|<=d_m,
    d_m=K_beta[sqrt(ell/(M m^2))
                         +(k+ell)/(M m^2)].       (U9)

To prove this, apply (U2) to all four context indicators with polynomially small failure probability. It yields

    |J_u-M Pi(u)|<=C_beta[sqrt(M Pi(u) ell)+ell].

Under (U8), all M Pi(u) are sufficiently large multiples of k+ell. Thus J_u lies between, for example, (3/4)M Pi(u) and (5/4)M Pi(u), and J'_u>=M Pi(u)/2.

For each u,c, the sum

    Z_{u,c}=C_{u,c}-theta_u(c)J_u

is a bounded-increment martingale sum with predictable quadratic variation at most theta_u(c)J_u. On the above occupation event this is at most 2M Pi(u)theta_u(c). The standard two-sided Freedman inequality, together with a union bound, gives

    |Z_{u,c}|<=C[sqrt(M Pi(u)theta_u(c) ell)+ell]

simultaneously for all eight coordinates outside another O(M^-3) event. This use of Freedman restricts to the event where the predictable variance is below the stated deterministic bound; it does not condition the martingale law on the occupation event.

Now

    |C'_{u,c}-theta_u(c)J'_u|<=|Z_{u,c}|+5k,

and the add-one bias contributes at most one more to the numerator. Divide by (J'_u+2)theta_u(c) and use Pi(u)theta_u(c)>=beta^2 m^3. The initial-law bound follows directly from the occupation estimate, (U7), add-one smoothing, and Pi(u)>=beta m^2. This proves (U9).

## 5. Minority-weighted posterior comparison

For each fixed output z, let P_hat_z be the positive clean-word law initialized at Pi_hat and run with theta_hat, both fitted at that z. Form its posterior using the same disclosed channel C(z|x). Average theta_hat at the latent clean terminal pair to obtain q_C(z). If no clean word can produce z, define q_C(z) arbitrarily; such observations have zero true probability.

On G suppose epsilon_m,d_m<=1/2. The relative bounds imply

    |log(theta_hat_u(c)/theta_u(c))|<=2epsilon_m,
    |log(Pi_hat(u)/Pi(u))|<=2d_m.

Any two clean preimages of z are at Hamming distance at most 2k. At most 6k historical triple positions differ. Hence the oscillation of log(P_hat_z(x)/P_theta(x)) on the posterior support is at most

    L_m=24k epsilon_m+4d_m.                      (U10)

The channel factor cancels. After normalization, the fitted-to-true posterior density lies between exp(-L_m) and exp(L_m). Let c_* be a true minority symbol and

    p(z)=P_theta,C(X_(N+1)=c_* | Z=z).

The future-blind channel identity represents p(z) as the true posterior average of theta_{S(X)}(c_*). Because every corresponding fitted coordinate is within multiplicative factors 1+-epsilon_m,

    (1-epsilon_m)e^(-L_m) p(z)
       <= q_C(z)(c_*)
       <= (1+epsilon_m)e^(L_m) p(z).             (U11)

If L_m<=1, this gives the POINTWISE bound

    |q_C(z)(c_*)-p(z)|
      <=C p(z)[(k+1)epsilon_m+d_m].             (U12)

Crucially, integration over any subset of the good event costs at most E p(Z)=m. The fitted parameters may depend on z throughout; every comparison above is pointwise at that z, with deterministic error bounds depending only on the fixed true source's m.

## 6. Source-independent minority adaptation

Define

    a0=[(k+1)^2 ell/M]^(1/3), a=A_beta a0.

Choose A_beta sufficiently large for all preceding constants. If a>1/16, the unit risk bound gives the stated result after increasing C_beta. Otherwise use the corrupted generated-symbol frequency

    b'=M^(-1)sum_{t=3}^N Z_t,
    m'=min{b',1-b'}.

If m'<=2a, predict the empirical majority symbol with probability one. Otherwise use the posterior plug-in predictor from Section 5. This algorithm depends only on beta,M,k,z and the disclosed channel.

Apply (U2) to the stationary symbol indicator and use the pathwise frequency perturbation k/M. Except on an O(M^-3) event,

    |b'-pi(1)|
      <=C_beta[sqrt(ell/M)+ell/M]+k/M <=a.      (U13)

The last inequality follows by increasing A_beta, using a0<=1 and

    sqrt(ell/M)=a0^(3/2)/(k+1)<=a0,
    ell/M=a0^3/(k+1)^2<=a0,
    k/M<=a0^3/ell<=a0.

If m<a, this event forces the correct majority branch, with integrated loss at most m. If a<=m<=4a, any majority branch on this event is also correct (4a+a<1/2), with integrated loss at most m<=4a; the plug-in branch can be bounded separately. If m>4a, this event forces the plug-in branch.

When m>=a, condition (U8) holds. Moreover (U9) and a0<=1 give

    (k+1)epsilon_m<=K_beta[A_beta^(-3/2)+A_beta^(-3)],
    d_m<=K_beta[A_beta^(-1)+A_beta^(-2)].

Choose A_beta so these imply epsilon_m,d_m<=1/2 and L_m<=1. By (U12), the integrated plug-in loss on the good event is at most

    C_beta[(k+1)sqrt(ell)/(sqrt(M)sqrt(m))
       +(k+1)(k+ell)/(M m^2)
       +sqrt(ell/M)+(k+ell)/(M m)].              (U14)

For m>=a=A_beta a0, each term is O_beta(a0). For example the first is at most a0/sqrt(A_beta), the second at most a0/A_beta^2 because k+ell<=(k+1)ell, the third is at most a0, and the fourth is at most a0^2/[A_beta(k+1)]<=a0/A_beta.

Combining the majority and plug-in branches and charging unit loss on the O(M^-3) exceptional event gives risk <=C_beta a0. Since log(100M)<=C log(eM) for M>=64, this proves (U1).

## 7. Limits of the conclusion

- Stationary initialization, fixed beta>0, and a disclosed future-blind channel are essential assumptions of this proof.
- No uniform positive transition floor is imposed. Rare triple masses enter only through the true source geometry in the proof; the estimator does not know them.
- The upper does not track rho and does not assert the logarithm is necessary. For fixed beta in (0,1), fixed rho>0, and k>=1, the rare-budget lower and this upper differ by at most a logarithmic factor in the nonsaturated regime. The beta=1 boundary does not have that rare-budget lower, and k=0 uses the sharper clean rule.
- At k=0 the established clean estimator is sharper; this theorem does not replace that clean result.
- All concentration and posterior arguments are analytical. No executable validation or public-repository change is part of this artifact.
