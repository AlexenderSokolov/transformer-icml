# Rare first-order sources strengthen the one-state rho lower

5 November 2026 UTC. Pure analytical candidate, pending independent review. No scientific executable checks, numerical experiments, or public writes. Earlier reviewed proofs remain unchanged.

## 1. Proposed result and remaining boundary

Fix 0<beta<1. Write b=min{1,k/sqrt(M)}. For the disclosed rational, time-indexed, one-base-state online class with the actual edit counter charged separately, the proposed lower is

    R_{S=1,beta}(M,k,rho)
      >= c_beta min{1, M^(-1/2)+k/M
                        +min{rho sqrt(b), b sqrt(rho)}}.       (R1)

Here M is sufficiently large, N=M+2, 1<=k<=M, and rho is rational in [0,1]. The clean and protected terms use the existing reviewed S=1 witnesses. The new endpoint witness uses rare first-order stationary sources, viewed as order-two sources in D2(beta).

This improves the previously reviewed endpoint lower rho b when rho and b both tend to zero. For example k of order M^(1/4) and rho of order M^(-1/8) give an endpoint lower of order M^(-5/16), whereas the positive-floor profile has order M^(-3/8). It does not close the general S=1 gap to the upper min{rho,(k^2/M)^(1/3)}. In particular no necessity of two base states or sharp no-floor S=1 profile is asserted.

## 2. Constants, scales, and stationary source

The following choices are sequential, so none is circular. Fix a sufficiently large absolute K for the Markov bounds in Section 5. Choose a fixed persistence 0<r<1-beta sufficiently small that the adverse-count coefficient C K r^2 below is smaller than the positive isolated-one coefficient. Choose a positive dyadic tau sufficiently small that tau<=r^4/100. After these choices take a positive dyadic alpha sufficiently small to satisfy the cap and likelihood-overlap bounds below. Finally choose d>0 sufficiently small after alpha,tau,r. All are fixed beta-dependent constants.

For k>=3 put

    h=min{k-2,floor(sqrt(M))},  B_M=ceil(sqrt(M)),
    b_0=h/B_M.

Let t be the largest dyadic power of two not exceeding tau max{rho,b_0}. Then

    (tau/2)max{rho,b_0}<t<=tau max{rho,b_0},
    L=1/t is an integer,   epsilon=alpha h/(Mt).       (R2)

For sufficiently large M, uniformly in h>=1 and rho, L/M tends to zero, epsilon<=1, and Mt tends to infinity. Indeed t>=tau h/(2B_M), so L/M<=2B_M/(tau h M).

Use the stationary first-order source

    P_a(1|x)=a+r x,
    a_-=t-delta, a_+=t+delta, delta=d sqrt(t/M).        (R3)

Increase the horizon so delta<=t/4. The stationary marginal is

    pi_a(1)=a/(1-r),  pi_a(0)=(1-r-a)/(1-r).

As in the reviewed positive-floor construction, the pair-chain identity

    P_a^2((w,x),(y,z))=P_a(y|x)P_a(z|y)

shows that the minimum of P_a(y|x)/pi_a(y) over x,y is exactly 1-r. Therefore P_a^2>=beta Pi_a at all pair states. There is no supplied positive transition floor independent of M.

Two fixed-start tail laws beginning at a common raw zero satisfy

    KL(Q_+||Q_-)<=C M delta^2/t=C d^2,                (R4)

by the transition Bernoulli KL bound. The row with previous bit zero has probability of a one comparable to t, and the other row has probability at least r. Taking d small makes the raw-tail TV, and hence the scaffold TV, arbitrarily small.

## 3. Exact one-base-state channel and activation branch

At positions 1,...,L, erase a raw one precisely when e=0; otherwise output the raw bit. Position L+1 is untouched. Let

    J={L+3,L+5,L+7,...} intersect {j:j<=N-2}.

At j in J, erase a current raw one with probability epsilon precisely when 1<=e<h+1. At N flip the current bit with probability rho precisely when 1<=e<k. All other outputs equal their raw inputs. Every edit increments the counter exactly once. All coins are independent. Explicitly redirect every forbidden edit at e=k to its matching-symbol output, including unused rows.

There is a single base state. The time schedule, current input, and actual counter are the only channel inputs. If the prefix contains no one then e=0 forever and the remainder is identity. Otherwise the prefix spends exactly one edit, the candidate phase spends at most h, and one endpoint edit remains reserved. Thus every path uses at most h+2<=k edits. For every fixed raw word, the probability of an endpoint change is rho if its first L raw bits contain a one, and zero otherwise. The final source innovation X_(N+1) is never read.

The effective normalized rational table is public and uses the common design t, not either unknown a. The full expanded table, rational rho and epsilon, L, and actual k+1-valued counter are paid. A conservative description ledger is

    O(N(k+1)[b_rho+log(M+1)+log(h+1)+1]).

Consider the observable branch

    B_pre={Z_1=...=Z_(L+1)=0}.

Its raw preimages have no one or exactly one one in the first L positions, followed by X_(L+1)=0. Let U indicate the latter event; U is exactly the actual counter at tail entry. The zero-one preimage mass is

    w_0(a)=pi_a(0)(1-a)^L.

The single-one/no-one mass ratio is exactly

    R_a=a/(1-a)+(L-1)a(1-a-r)/(1-a)^2.                (R5)

The first term accounts for a one at the initial position using stationary detailed balance; the remaining L-1 locations have the second weight. For sufficiently large M, a/t is uniformly close to one, and

    1/2<=R_a<=2,  omega_a=R_a/(1+R_a) in [1/3,2/3],
    b_a=P_a(B_pre)=w_0(a)(1+R_a)>=c>0.               (R6)

The derivative of a(1-a-r)/(1-a)^2 is

    [(1-r)-a(1+r)]/(1-a)^3>0.

Thus omega_a increases with a. Also |d log R_a/da|<=C/t. The raw tail after the anchor X_(L+1)=0 is independent of U conditional on B_pre, by the first-order Markov property. Its law is exactly Q_a from (R4).

## 4. Recoverable scaffold and signed conditional odds

Let H retain the anchor and every subsequent raw bit except the candidates X_j, j in J, and B=X_N. These retained coordinates are unchanged. The candidate mask is deterministic, so H is recoverable. Conditional on H the missing bits are independent, generally nonidentically distributed. Candidate spacing two and the retained site N-1 separate all missing first-order likelihood factors.

For retained neighbors (u,v), the candidate odds are exactly

    o_a(0,0)=a(1-a-r)/(1-a)^2,
    o_a(0,1)=o_a(1,0)=(a+r)/(1-a),
    o_a(1,1)=(a+r)^2/[a(1-a-r)].                     (R7)

The mixed-neighbor odds increase with a. For all a between a_- and a_+, the smallness of tau and delta/t gives

    log[o_+(0,0)/o_-(0,0)] >= delta/t,
    log[o_+(1,1)/o_-(1,1)] >= -4delta/t,
    |log[o_+(u,v)/o_-(u,v)]| <= C delta/t.             (R8)

These follow from the logarithmic derivatives

    1/a-1/(1-a-r)+2/(1-a),
    1/(a+r)+1/(1-a),
    2/(a+r)-1/a+1/(1-a-r).

The 11-neighbor term is allowed to decrease. It is not silently treated as monotone.

Write p_aj=o_aj/(1+o_aj). For an individual conditional candidate law the parameter Fisher information is

    p_aj(1-p_aj)[d log o_aj/da]^2 <= C_r/t.           (R9)

For 00 neighbors this is O(1/t); for mixed neighbors it is O(1/r); for 11 neighbors, 1-p=O(t/r^2), giving O(1/(tr^2)). Thus the conditional raw candidate product laws under a_+ and a_- have TV at most C_r d, uniformly in H. The same holds after the common capped thinning channel.

## 5. Good scaffolds, without an independence assumption

Let n_00 and n_11 count the candidate sites with those retained neighbor pairs. Put

    L_p(H)=sum_j p_-j,
    L_o(H)=sum_j o_-j.

There are between M/3 and M/2 candidates for sufficiently large M. A good scaffold D has

    X_(N-1)=0,
    n_00>=M/4,
    L_p<=K Mt,
    n_11<=K Mt(r^2+t),
    L_o<=K M(t+r^4).                                 (R10)

Here K is enlarged once to absorb the absolute constants in the following expectation estimates.

Under a stationary comparison source, the probability of neighbors 11 around a candidate is exactly

    pi_a(1)[(1-a-r)a+(a+r)^2] <= C a(a+r^2).

The corresponding 00-neighbor failure probability is O(a). The expected conditional success sum is just the expected number of raw candidate ones, hence O(Ma). Finally, direct multiplication of the probabilities of the three neighbor types by their odds in (R7) gives

    E L_o <= C M(a+r^4).

For example the 11 contribution is bounded by C(a+r^2)r^2, the mixed contributions by C ar, and the 00 contribution by C a. These bounds are uniform for a<=2tau<=r^4/50.

The fixed-start tail law Q_a is the stationary tail law conditioned on its initial anchor being zero. Since pi_a(0)>=1/2, nonnegative expectations and event probabilities are dominated by twice their stationary values. Therefore the same bounds hold under Q_a, with a comparable to t. Markov's inequality, the terminal minority bound, and the 00-neighbor failure bound give

    Q_-(D)>=1-C/K-C tau.

Choose K large, tau small, and d small in (R4). For the conditional scaffold laws f_a this yields

    sum_{H in D} min{f_+(H),f_-(H)} >=3/4.            (R11)

Only the minus-source good-set bound is needed here; the other source enters through total variation. The channel never tests D or stores any of these statistics.

## 6. Exact capped likelihood and its signed score

Fix H in D. Under U=0 let P_a0 be the raw candidate product law. Under U=1 let P_a1 be the actual capped candidate output law. Define

    Lambda_a=P_a1/P_a0,
    m_a=(1-omega_a)P_a0+omega_a P_a1,
    v_a=P_a(U=1|H,Y).

As in the reviewed one-state proof, for each displayed vector Y there are nonnegative source-independent coefficients c_E(Y) such that exactly

    Lambda_a(Y)=sum_{E subset {j:Y_j=0}, |E|<=h}
                    c_E(Y) product_{j in E} o_aj.     (R12)

The normalized terms are the posterior distribution of the actual erased set under active mode. Let D_00 and D_11 count its erasures at the corresponding neighbor types. Set

    G(Y)=E_-[D_00-4D_11 | H,Y,U=1].

Using (R8) term by term in the positive polynomial and then Jensen gives

    log Lambda_+(Y)-log Lambda_-(Y) >= (delta/t)G(Y),
    |log Lambda_+(Y)-log Lambda_-(Y)| <= C delta h/t.  (R13)

The upper bound is at most C d/sqrt(tau), since t>=c tau h/sqrt(M) and h<=sqrt(M). Taking d small makes this less than log 2. The lower bound is used only where G>=0.

## 7. Most useful erasures survive overlap and the cap

In the uncapped active experiment let D_total be the proposed erasure count, and let mu be its mean. On a good scaffold,

    mu<=K alpha h,
    E D_00^uncapped>=c_0 alpha h,
    E D_11^uncapped<=K alpha h(r^2+t).                (R14)

The second bound uses n_00>=M/4 and p_-(00)>=c t. The capped total count is min(D_total,h). Lost 00 erasures are at most (D_total-h)_+, whose expectation is at most mu^2/h. Therefore, by first taking r small and then alpha small,

    E_-[D_00-4D_11 | H,U=1] >= c_1 alpha h.          (R15)

Indeed the subtractions are bounded by K^2 alpha^2 h and 4K alpha h(r^2+t), while t<=tau<<r^2. For h above a fixed threshold H_beta, the second moment of the capped total is at most C K^2 alpha^2 h^2.

The uncapped thinning product calculation gives

    chi^2(P_-1^uncapped || P_-0)
        <=exp(epsilon^2 L_o)-1.

On D,

    epsilon sqrt(L_o)
      <= C sqrt(K) alpha [h/(sqrt(M)t)] sqrt(t+r^4)
      <= C sqrt(K) alpha sqrt(tau+r^4)/tau.           (R16)

Choose alpha so this makes the TV as small as a chosen absolute zeta>0. Capping adds at most (e K alpha)^h in TV. Increase H_beta so this is also at most zeta. With E_0={1/2<=Lambda_-<=2}, the likelihood-ratio test inequality gives

    P_-1(E_0^c)<=C zeta.

Cauchy-Schwarz and |D_00-4D_11|<=4 min(D_total,h) show that the signed expectation lost on E_0^c is at most C K alpha h sqrt(zeta). Take zeta sufficiently small in terms of c_1,K, and the preceding alpha choice accordingly. Equations (R15)-(R16) then give

    sum_{Y in E_0, G(Y)>=0} P_-1(Y)G(Y)>=c_2 alpha h.

Since omega_->=1/3, the same lower holds with m_- up to a fixed factor. By (R9), data processing for capped thinning, and |omega_+-omega_-|<=C delta/t, the two mixture laws satisfy

    ||m_+-m_-||_1<=C_r d.

Here Mt>=1, so delta/t=d/sqrt(Mt)<=d. On the selected set 0<=G<=h. Choose d sufficiently small after alpha. Subtracting h times the last L1 bound yields

    sum_{Y in E_0, G(Y)>=0} min{m_+(Y),m_-(Y)}G(Y)
          >=c_3 alpha h.                             (R17)

On this selected set the priors have odds in [1/2,2], Lambda_- is in [1/2,2], and Lambda_+ is in [1/2,4] by (R13). Both posterior mode odds therefore lie in [1/4,8]. The prior log odds increase with a. The logistic derivative is at least 1/16 on that interval, so

    v_+(Y)-v_-(Y)>=(delta/(16t))G(Y)>=0.

Consequently the selected, overlap-weighted mode gap is at least

    c_4 alpha delta h/t.                             (R18)

This is a signed-score argument for the actual cap. No absolute cap-TV error is subtracted from a vanishing posterior separation.

## 8. Rare endpoint, including the changing source row

On D, the retained bit X_(N-1)=0. Conditional on H, B=X_N is Ber(a), independently of candidates and U. The future success probability is a+rB. At the endpoint the active mode has its reserved edit. Put T_a=rho v_a, and retain W=Z_N=1. Then exactly

    ell_a(1)=a+(1-2a)T_a,
    F(a,T)=a(1-T)/[a+(1-2a)T],
    g_a(H,Y,1)=a+rF(a,T_a).                           (R19)

On the selected set from Section 7, v_a is uniformly bounded away from zero and one. Therefore

    c(t+rho)<=ell_a(1)<=C(t+rho).

The derivatives are

    dF/dT=-a(1-a)/[a+(1-2a)T]^2,
    dF/da=T(1-T)/[a+(1-2a)T]^2.

Since v_+>=v_- there, decomposition first in T and then in a gives

    g_- - g_+
      >= c r t rho/(t+rho)^2 (v_+-v_-)
           -C r rho delta/(t+rho)^2 -2delta.         (R20)

The direct change of a and the change of the endpoint prior have NOT been omitted. They have the potentially adverse sign.

The output mass is b_a f_a(H)m_a(Y)ell_a(1). For the positive term in (R20), its minimum under the two alternatives is at least

    c(t+rho) min{f_+(H),f_-(H)} min{m_+(Y),m_-(Y)},

using b_a>=c. For the negative terms, the total minimum output mass over the retained branch is at most C(t+rho), because ell_a(1)<=C(t+rho) and f_a,m_a are normalized. Thus their aggregate cost is at most

    C [r rho delta/(t+rho)+delta(t+rho)] <= C delta.

Applying the two-source absolute-loss inequality, retaining only H in D and the selected Y, and using |g_+-g_-|>=g_- - g_+, (R11) and (R18), proves

    max_a Risk_a(Q) >= c_beta h delta rho/(t+rho)-C_beta delta
                    >= c_beta [h/sqrt(M)]sqrt(t) rho/(t+rho)
                         -C_beta M^(-1/2).           (R21)

This keeps both the rare output mass and the source-row cancellation cost. The independent clean lower absorbs the final root-M term: if the proposed endpoint expression is at most a sufficiently large constant times M^(-1/2), use the clean witness; otherwise (R21) supplies a fixed fraction of it.

## 9. Scaling and small budgets

Let b_h=h/sqrt(M). By (R2), t is comparable, with fixed beta-dependent constants, to max{rho,b_h}. Directly splitting rho>=b_h and rho<b_h gives

    b_h sqrt(t) rho/(t+rho)
       >=c_beta min{rho sqrt(b_h), b_h sqrt(rho)}.     (R22)

For k>=3, b_h is within a fixed factor of min{1,k/sqrt(M)}. Once M is enlarged so floor(sqrt(M))>=H_beta, the excluded h<H_beta imply bounded k. In that range the endpoint expression is at most k/sqrt(M), so the clean lower absorbs it after a fixed constant loss. This also covers k=1,2.

Finally take the maximum with the reviewed S=1 clean and protected-budget witnesses; their budgets and laws are not combined. Their maximum bounds a fixed fraction of the sum, proving the proposed (R1).

## 10. Required audit points

The independent review should check the nondegenerate but source-dependent prefix prior; signed rather than monotone conditional odds; all three rare scaffold expectations; the conditional Fisher/TV bound; actual capped positive-polynomial coefficients; weighted signed-count retention; and especially the endpoint source-row cancellation with its complete observation mass.

The result is a lower only. In the full no-floor D2(beta) class the sub-square-root-budget S=1 minimax profile remains unresolved.
