# EPR001: Interpolating protected and unreliable terminal observations

Date: 2026-11-05. Analytical candidate and explicit dependency assembly. No executable checks, public writes, neural implementation, training result, external novelty claim, or formal verification are asserted. Existing research artifacts are unchanged.

## Result first

The existing protected-terminal corruption frontier and the existing unrestricted-endpoint theorem can be joined by a probability parameter. If an adaptive attack changes at most k observed symbols and changes the terminal pair with probability at most rho, the original-terminal minimax risk has order

    min{1, max{M^(-1/2), F_K(beta,M,k), rho(1-beta) 1{k>=1}}}.

The new upper construction is a simple wrapper around the existing protected-terminal estimator: project its output radially into a TV ball around the pooled empirical distribution. It is beta-aware and rho-blind. A repaired attack, rather than a false conditional-risk claim, justifies importing the protected theorem.

The same order holds if the target is changed to the source row at the CORRUPTED terminal pair, but its endpoint lower bound has a different explanation: the attacker can ask for an unobserved source row. The two targets are not pointwise interchangeable. The corrupted-target extension requires a source class permitting arbitrarily rare contexts; it does not transfer to a class with a fixed positive transition-probability floor.

## 1. Precise experiment and quantifiers

Fix K>=2, M>=64, N=M+2, 0<=k<=M integers, beta in [0,1], and rho in [0,1]. The unknown homogeneous second-order K-letter source has pair transition

    P((a,b),(b,c)) = theta_ab(c)

and a hidden stationary pair law Pi satisfying

    P^2(s,t) >= beta Pi(t) for EVERY pair state s,t.

This includes states outside stationary support. Here beta is the supplied all-state minorization certificate, NOT an attention temperature. The source starts either at Pi (the stationary experiment) or at an arbitrary unknown pair distribution (the all-start experiment). Denote this source class by D2(beta).

A corruption channel C is a fixed stochastic map on complete words x in [K]^N. It may depend on public K,M,k,beta,rho and inspect the entire word. It has no unknown source parameters, hidden stationary law, future symbols, or estimator seed as inputs. For every input x and every output z in its support,

    d_H(x,z) <= k.

Write S(x)=(x_(N-1),x_N). The endpoint reliability condition is

    Pr_C{S(Z) != S(x) | x} <= rho for every word x.       (1)

The predictor sees the entire Z, but not X, an edit mask, or the attack seed. Its seed is independent. The primary target is theta_(S(X)), the source's next law at the ORIGINAL actual terminal pair. Risk is unconditional expected TV. The supremum over channels does not silently supply the unknown source parameter to the channel. All lower constructions below use a common source-independent channel within their respective witness families.

Let R_stat^orig and R_all^orig be the corresponding minimax risks. Estimators may use the supplied public parameters, including beta and k.

Set

    s = M^(-1/2), delta = 1-beta,
    e = max(beta,1/M)             if K>=3,
    e = max(sqrt(beta),1/M)       if K=2,
    F = 0                        if k=0,
    F = (k/M)[1+log(1+1/(e k))]  if k>=1,
    H = min{1, max{s,F,rho delta 1{k>=1}}}.

There are constants c_K>0 and C_K<infinity depending only on K such that

    c_K H <= R_stat^orig <= R_all^orig <= C_K H.         (2)

One may take c_K=2^-15 for K>=3 and c_2=2^-54, inheriting the conservative protected-terminal lower constants. A sufficient upper constant is specified below.

Condition (1) is stronger than the upper proof needs. The same theorem remains valid if it is replaced by a source-uniform unconditional probability condition, namely sup_(theta,mu) Pr_(theta,mu,C){S(Z)!=S(X)}<=rho over ALL qualifying sources and ALL initial pair laws. Use this ONE common reference class to define the admissible channels for BOTH stationary and all-start risks; otherwise the channel classes can differ and the displayed ordering need not follow from source inclusion. The lower channels obey the stronger per-word condition already. These are different channel classes, and should be named separately if both are used. In the per-word class, a deterministic attack with rho<1 cannot ever change an endpoint; the interpolation uses randomized channels.

## 2. Existing protected-terminal interface

The previously established full-history protected-terminal estimator q_k uses the entire corrupted word and queries its observed final pair.

For K>=3, q_k is selected-row add-one smoothing. For K=2 and k>=1, it is the public fixed-orientation SC003 lower envelope, with B=6k:

    q_designated = (C'_designated-B)_+/(J'+B+2).

The designated successor is the complement of the first bit of the observed terminal pair. The other coordinate is its complement. For k=0, use the clean add-one rule.

For every source and every channel preserving both final symbols, the inherited theorem gives

    E TV(q_k(Z),theta_(S(X))) <= A_K s+B_K F,           (3)

where one may use

    A_K = 2^13 K^(5/2),
    B_K = 12K^2(17+log 80)+60K^4                  (K>=3),
    A_2 = 2^17, B_2 = 2^19.

This is an unconditional actual-terminal theorem, not an assertion that successors in a selected row are IID. The lower matching (3), up to constants and a unit cap, is SC002 for K>=3 and SC003 plus BT002 for K=2. BT002 is needed: the earlier SC003 file alone explicitly left the moving-beta binary logarithmic lower open.

## 3. A common-component lemma strengthens the pooled bound

Let pi(c)=sum_d Pi(c,d). Summing the all-state two-step certificate over the second coordinate yields

    theta_u(c) >= beta pi(c) for every u,c.             (4)

Indeed the first coordinate of the pair after two transitions is the next symbol generated from u. When delta>0, write theta_u=beta pi+delta r_u for a probability vector r_u. When delta=0, all rows equal pi.

Consequently, every pair of source rows is within delta in TV. More generally, every row and EVERY convex average of source rows are within delta. The latter is sharper than bounding each separately against pi and paying 2delta.

For t=3,...,N, put

    m_t = theta_(X_(t-2),X_(t-1)),
    mbar = M^(-1) sum_t m_t,
    W = M^(-1) sum_t (e_(X_t)-m_t).

The summands in W are vector martingale differences. Distinct-time inner products have zero expectation, and

    E ||W||_2^2 <= 1/M,
    E (||W||_1/2) <= sqrt(K)/(2sqrt(M)).                (5)

Let b'=M^(-1) sum_(t=3)^N e_(Z_t), the corrupted pooled empirical distribution, and set E_X=||W||_1/2+k/M. At most k generated positions change, so pathwise

    TV(b',mbar) <= E_X,
    TV(b',theta_u) <= delta+E_X for EVERY row u.        (6)

The choice of u may depend on the entire clean and corrupted word. No independence between the attack, endpoint, W, or counts is required.

## 4. The clipped estimator and its pathwise inequalities

For k=0 simply use clean add-one, making rho irrelevant. For k>=1 compute q=q_k(Z), b', and a=TV(q,b'). Define

    q* = q                                  if a<=delta,
    q* = b'+(delta/a)(q-b')                  if a>delta.

This is always a probability vector. At beta=1 it is b'. It depends on beta and k but does not use rho. The result is a measurable statistical estimator with arbitrary computation. If beta is an arbitrary real, this statement alone is NOT a finite rational implementation theorem. A rational beta/radius or a separately paid approximation certificate is needed before making such a claim.

Let G={S(Z)=S(X)} and let theta*=theta_(S(X)). On G, or indeed for any target row, radial projection and (6) give

    TV(q*,q) = (a-delta)_+
             <= TV(q,theta*)+E_X,
    TV(q*,theta*) <= 2TV(q,theta*)+E_X.                (7)

On G^c, membership in the clipping ball and (6) give the more useful bound

    TV(q*,theta*) <= 2delta+E_X.                      (8)

Thus, on every realization,

    TV(q*,theta*)
      <= 2 1_G TV(q_k(Z),theta*)+2delta 1_(G^c)+E_X.  (9)

## 5. Repairing the channel, not conditioning the clean theorem

To bound the first term in (9), define C^0 on every word x: draw z from C(x); output z if S(z)=S(x), and output x otherwise. C^0 is a source-independent channel preserving both endpoints and changing at most k symbols. It uses the original x only as part of its allowed corruption-channel input, not as predictor side information.

Under the natural coupling, q_k(C^0(X))=q_k(Z) on G. Nonnegativity of TV and the inherited protected guarantee imply

    E[1_G TV(q_k(Z),theta_(S(X)))]
      <= E TV(q_k(C^0(X)),theta_(S(X)))
      <= A_K s+B_K F.                                (10)

This avoids asserting that the original source law, terminal law, or statistical-risk theorem remains unchanged after conditioning on G. An adaptive attack may choose G using exactly the trajectories with large statistical errors.

Combining (1), (5), (9), and (10), for k>=1,

    risk(q*) <= (2A_K+sqrt(K)/2)s+(2B_K+1)F
                +2rho delta,                         (11)

because k/M<=F. Cap the loss at one. A sufficient C_K in (2) is

    C_K = 2A_K+2B_K+sqrt(K)/2+3.

For k=0 the clean branch has risk at most A_K s, already covered.

## 6. Matching lower bounds for the ORIGINAL terminal target

Protected attacks satisfy (1) with probability zero, so the complete SC002 or SC003+BT002 lower remains available at every rho. This supplies the s and F terms with stationary initialization.

For the endpoint term assume k>=1. Use EP001's stationary symmetric first-order binary source embedded in the K-symbol alphabet:

    T(0,0)=T(1,1)=1/2+alpha,
    T(0,1)=T(1,0)=1/2-alpha,
    alpha=min(delta/2,1/4).

Unused-symbol rows may be binary uniform. The stationary symbol law is uniform on {0,1}; the stationary pair law is pi(u)T(u,v). Since T(y,c)>=(1-2alpha)pi(c) for every starting symbol, the pair source obeys P^2>=beta Pi on all states.

The attack draws an independent Bernoulli(rho) coin B. If B=1 it sets only the final observed symbol to 0; if B=0 it is identity. This common channel uses at most one edit and has conditional endpoint-change probability at most rho on every word.

Grant the decoder B and the entire source law. Conditional on B=1, the prefix determines last-bit probabilities 1/2+alpha and 1/2-alpha, in an order determined by the preceding bit. The two true next-law values differ by 2alpha. Their minimum posterior absolute loss is

    (1/2-alpha)2alpha = alpha-2alpha^2 >= delta/8.

Giving extra information can only reduce risk; therefore the original experiment has risk at least rho delta/8. On B=0, knowledge of the law gives zero loss, which does not weaken this lower. Combining the separate witnesses by their MAXIMUM proves (2), without adding risks from unrelated sources.

## 7. What changes if the target is the corrupted terminal row?

Define R_stat^corr and R_all^corr by replacing theta_(S(X)) with theta_(S(Z)). This is a different loss: the source table is evaluated at the observed, possibly forged pair. The same upper (11) holds because (6) holds for every row and, on G, the two targets agree. The same protected lower also holds. The original-target known-source endpoint argument does NOT prove the remaining lower: if the source is known, theta_(S(Z)) is known exactly.

A separate binary two-point family gives the missing floor. Let

    theta00(1)=theta10(1)=theta11(1)=0,
    theta01(1)=p,  p in {0,delta}.

The stationary pair law is delta_00, every clean observed word is 0^N, and P^2(u,00)>=1-p>=beta for every pair u. Each source has a unique stationary distribution, even at p=1. Set the last bit to 1 on an independent Bernoulli(rho) attack coin and otherwise do nothing.

On the attack branch, every observation is 0^(N-1)1 and the two corrupted-target laws are Bernoulli(0) and Bernoulli(delta). Under equal prior weights, the triangle inequality gives conditional Bayes risk at least delta/2. Hence

    R_stat^corr >= rho delta/2, k>=1.                  (12)

It is the two-point prior, NOT a continuous uniform prior, that gives delta/2. A uniform prior on [0,delta] instead has optimal absolute loss delta/4.

Embedding this binary family in K>=3 by making all unused rows return to 0 preserves the all-state certificate. Thus both risks in the corrupted-target experiment have the same order H as (2), though the obstruction is different.

### 7.1 Full-support binary approximation

The corrupted-target floor is not merely an undefined-row artifact. Fix beta<1 and choose arbitrarily small a>0 with sqrt(a)+a<=delta. Use two first-order binary kernels with

    T_i(0,1)=a,
    T_i(1,1)=p_i,
    p_0=a, p_1=delta-sqrt(a).

All four legal symbol transitions are strictly positive for sufficiently small a. Set D_i=1-p_i+a and

    pi_i=(1-p_i,a)/D_i.

For p_i>=a, every transition satisfies T_i(y,c)>=D_i pi_i(c). For i=0, D_0=1; for i=1, D_1=beta+sqrt(a)+a>=beta. Therefore the stationary order-two embedding satisfies P_i^2>=beta Pi_i on every pair, with positive stationary mass at every binary pair.

The stationary probability of the complete all-zero word is

    w_i=pi_i(0)(1-a)^(N-1) -> 1 as a -> 0,

also when beta=0, because then 1-p_1=sqrt(a). On the common image 0^(N-1)1 of the all-zero word under the last-bit attack, the target gap is p_1-p_0 -> delta. Consequently

    (R_0+R_1)/2 >= rho min(w_0,w_1)|p_1-p_0|/2.

Take a to zero inside the source supremum to recover (12), for each fixed finite M. This is a supremum argument, not the claim that a single fixed positive-a source remains unlearnable at all growing horizons.

If the source class imposes a FIXED uniform transition floor eta>0, this sequence is excluded. In that narrower class one must analyze simultaneous row estimation, rather than import (12). Conversely, an original-target endpoint ambiguity can persist even for a known, well-conditioned source, because the original last symbol has actually been hidden.

### 7.2 No pointwise dominance between target definitions

In the deterministic-clean family above, the original target is always delta_0 and is trivial throughout the family, while the corrupted target carries the unknown p. In EP001's known-source symmetric example, the corrupted target is directly known from the observed pair, while the original target has positive posterior loss. Thus neither target can replace the other inside a proof, even though their broad-class minimax orders coincide.

## 8. Interpretation and limitations

- Retaining the clean statistical order requires BOTH F=O_K(M^-1/2) and rho(1-beta)1{k>=1}=O_K(M^-1/2).
- With fixed beta<1 and positive edit budgets k>=1, endpoint reliability must therefore improve at rate rho=O_K(M^-1/2) to preserve that order. Merely having k/N small does not suffice if endpoint hits remain possible with fixed probability.
- At beta=1 all source rows coincide and the endpoint term disappears, as it should.
- At rho=0 this reduces to the existing protected-terminal result. At rho=1 it is equivalent in order to EP001; the more detailed F term is already controlled by max{s,k/M,1-beta}.
- The attack may be offline and fully history-adaptive. The upper proof begins with pathwise inequalities. This does not establish the same logarithmic lower for a strictly online/causal corruption channel.
- The count, common-component, and radial inequalities are pathwise. The final statistical risk bound is UNCONDITIONAL over the source trajectory; a per-word endpoint-reliability constraint does not turn it into a conditional or worst-word prediction-risk guarantee.
- The binary sqrt(beta) cutoff concerns the specified all-state source class, not a general mixing-time law.
- The construction is a statistical full-history estimator. RG001's geometric coordinate-noise theorem and JP001/RE001's representation interfaces are separate. No Transformer implementation, resource optimality, or training achievability follows here.
- Internal analytical review is not external peer review or a priority certificate. The contribution claimed here is only the stated interpolation and target separation relative to the inspected predecessor files.

## 9. Source bindings and reading scope

All repository files below were obtained through the GitHub connector at commit 33a7bceca948881352ae48b78ea418d20fec0452. The protected/endpoint theorem statements and relevant proof sections were inspected directly. RG001, JP001, RE001, and the consolidated manuscript were inspected for their relevant definitions, statements, and composition boundaries rather than claimed as a fresh full-proof audit. No source code was executed.

- `v10_research/source_symbol_corruption/SC001_theorem.md`: raw edit/count sensitivity, rare-suffix obstruction, and common-kernel distinction.
- `v10_research/source_symbol_corruption_mixing/SC002_theorem.md`: complete K>=3 protected frontier and explicit upper constants.
- `v10_research/binary_source_corruption/SC003_theorem.md`: binary lower-envelope estimator and upper; its original lower-gap warning is preserved.
- `v10_research/binary_erasure_transport/BT002_entropy_bridge_lower.md` and `BT002_scalar_completion.md`: subsequent binary lower completion, with unrestricted finite transport computation.
- `v10_research/terminal_symbol_corruption/EP001_endpoint_corruption.md`: existing endpoint extreme and known-source erasure lower.
- `v10_research/source_corruption_manuscript/nonbinary_endpoint.tex`: consolidated predecessor assumptions and endpoint scope.
- `v10_research/robust_grid_packing/RG001_theorem.md`, `joint_corruption_precision/JP001_theorem.md`, and `robust_encoded_source_corruption/RE001_theorem.md`: distinction between input-symbol corruption and post-encoding coordinate perturbation.
- `v10_research/t1t2_shared_model_20261103/shared_model_interface_v0_1.html`: common actual-terminal risk and architecture/statistical interface boundaries.
- `v10_research/central_prior_art_20261103/ROBUST_PREDICTION_AUDIT.md`: prior-art and strict-word-transport cautions.

Canonical repository prefix: https://github.com/AlexenderSokolov/transformer-icml/blob/33a7bceca948881352ae48b78ea418d20fec0452/

Targeted repository searches for endpoint probability / terminal pair probability did not identify this interpolation. This was not an exhaustive literature or duplicate search. Independent analytical review found the wrapper, repaired-channel step, endpoint mixture, and separate corrupted-target constructions valid, with the caveats above; a separate review report should accompany any later acceptance.
