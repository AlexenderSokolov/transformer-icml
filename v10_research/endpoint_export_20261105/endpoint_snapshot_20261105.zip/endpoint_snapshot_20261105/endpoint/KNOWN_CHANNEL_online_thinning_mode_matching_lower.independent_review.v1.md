# Independent review of the hidden-thinning-mode matching lower

Review time: **2026-11-05 08:13:23 UTC**.

Reviewed current file: `./KNOWN_CHANNEL_online_thinning_mode_matching_lower.candidate.v1.md`.

Independently measured SHA-256: `bd616d8ae614fbd99a312a18cd6927fbaee7d05945389342d9d953904bf8c874`.

I read the complete draft and checked the final base-state and endpoint-certificate clarifications. This is a present-time exact-file analytical review, not an inference about historical hashes. No scientific executable tests, numerical experiments, model execution, public writes or external novelty certification were performed. The earlier weaker constructions and their reviews remain unchanged.

## Disposition

**Analytical PASS for the stated matching endpoint lower.** The construction supports

    c_beta min{rho,(k^2/M)^(1/3)}

for fixed 0<beta<1, sufficiently large M, every 1<=k<=M and rational rho in [0,1], in the stated paid online channel class with an allowed base-state budget S>=8.

The eight base states exclude the separately charged k+1-state edit counter and the horizon-dependent time-indexed transition table. Thus this is not a theorem about eight total states, every smaller state budget, or one homogeneous length-independent transducer.

Together with the reviewed clean and protected-budget lower witnesses and the applicable statistical upper, this closes the previously unmatched growing-k endpoint term for this interface. It does not establish optimal Transformer resources, training achievability, floating-point correctness or external novelty.

## 1. Rational channel, online decisions and strict cap

The base state (hidden mode U, previous raw pair) has eight values. Its initialization is source independent: U is fair, the raw pair register starts at 00, and the first two inputs populate that register before the first candidate can be edited.

For k>=2 the interior cap h=min{k-1,floor(sqrt M)} is positive, and epsilon=1/(2h) is a valid rational probability. At an eligible current one, the mode-one channel either erases immediately or passes it. Eligibility uses only the preceding raw pair and public time. Each erasure increments the actual counter. The channel never tests a candidate's future neighbors or retracts an earlier output.

The endpoint step uses U, the preceding raw pair, the current bit, the counter and an independent rho coin. Since at most h interior edits occurred and h+1<=k, an endpoint edit remains available on every actual path. The guard still defines all rows safely. Position N is unchanged.

Every realization uses at most k edits. For a fixed clean word, the endpoint-change probability is at most rho/2, since only the independent mode-one half can flip it. This satisfies the required at-most-rho certificate. The bridge's separately verified endpoint-certificate option applies; no additional stored endpoint coin or state is required.

All row probabilities are 0, 1, epsilon, 1-epsilon, rho or 1-rho, with rational fair initialization. The source parameters t,d,r,q do not appear in the channel. The expanded time/counter/state table and the bit lengths of rho and h are paid in T5. The small-budget fallback is a different already reviewed channel and avoids applying the epsilon formula at k=1.

## 2. Scaffold, mode prior and conditional factorization

Candidate spacing by three is essential. The two preceding and two following positions of a candidate are noncandidates. Candidates end by N-5, so those retained coordinates also avoid the potentially edited penultimate bit. Therefore eligibility and H are recoverable from Z, even when the cap stops further thinning.

H is exactly a function of the clean source word and is unchanged by the channel. In particular H does not depend on U, so the hidden mode remains fair after conditioning on H. This justifies the factors 1/2 in every conditional mode mixture below.

Separated order-two likelihood factors give conditional independence of all missing candidate raw bits and their independence from B. The four odds in T6 are correct. They include the non-negligible future-01 conditional probability rather than pretending all missing bits have the 00 probability. The initial pair factor contains only retained coordinates.

Independent thinning can be represented by preassigned independent coins at all candidate positions. Conditioning on H therefore leaves the ideal uncapped output as a product of Bernoulli variables with probabilities (1-epsilon)p_qj in mode one. No future-neighbor test is performed by the actual channel; future neighbors enter only the conditional likelihood calculation.

## 3. Sources and uniformly good scaffolds

The inherited stationary rare-source law and all-state D2(beta) certificate hold for the full parameter range in T3. The transition KL is O_beta(d^2 Mt^3/h^2)<=O_beta(d^2 tau^3). The initial-law log ratio is O_beta(t/h), with t/h<=tau M^(-1/3), so the initial term tends uniformly to zero. The common clean-history TV bound follows by a small fixed tau and sufficiently large onset horizon.

The good-scaffold facts are also uniform when h is comparable to sqrt M and t need not vanish. The mean n_00/(Mt^2) remains in [9/32,11/32], the rare-window covariance sum gives Var(n_00)<=C_beta Mt^2, and Mt^2>=(tau^2/4)M^(1/3). The terminal scaffold failure is bounded by 6tau, rather than being incorrectly asserted to vanish uniformly.

The cross-source odds bounds imply o_+<=4p_q under either source. Consequently E_q L_+<=4Mt^3<=4tau^3h^2. The stated Markov bound and the other events yield P_q(D)>=7/8. D is one common H-measurable set. Data processing then gives the restricted scaffold overlap at least 3/4.

## 4. Uncapped mode likelihood ratio and overlap

The exact one-coordinate output probabilities give

    Lambda_q(Y)=(1-epsilon)^(sum Y)
                  product_(Y_j=0)(1+epsilon o_qj).

Displayed-one factors cancel when comparing the source alternatives. Every zero-factor increases with q, so Lambda_+>=Lambda_- pointwise. This sign is proved for the uncapped comparison experiment only; the later argument does not need to assert it for the capped law.

For thinning, the one-coordinate chi-square divergence is epsilon^2 o_qj. Product multiplication yields T11. With L_+<=h^2/64 and epsilon=1/(2h), its exponent is at most 1/256, and the displayed TV bound 1/16 is conservative. The resulting likelihood-ratio event E_0 has m_- failure probability at most 3/16.

The four odds have log ratio at most 10d/h. The extra denominator in the future-11 odds contributes at most d/h; all terms are explicitly bounded in the stated parameter range. Therefore the relative odds difference is at most 20d/h. The Bernoulli chi-square identity in T14 is correct and bounds conditional raw-source TV by 1/32. Common thinning and mixture preserve that bound.

For 00 sites, p_-(00)<=t, and thinning cannot increase their displayed-one probability. Markov's bound on having fewer than n_00/2 zero outputs is valid. Combining these events gives overlap at least

    1-3/16-1/64-1/32=49/64>=3/4.

This establishes that the hidden mode is not effectively revealed on the observation region used by the proof, despite being retained internally for the whole horizon.

## 5. Quantitative posterior-mode separation

On that region, the zero 00 sites alone give

    log Lambda_+-log Lambda_->=d tau^3/128=Delta.

Other zero-site contributions are nonnegative. The upper bound 10d/64 on the log-ratio difference keeps both mode likelihood ratios within [1/2,4]. The logistic derivative is at least 1/10 throughout that interval. Thus the posterior-mode gap is at least Delta/10 on a conditional output overlap of at least 3/4, proving

    J(H)>=3Delta/40=J_*.

The conditional product laws are not assumed identical across candidate types. Their heterogeneity is handled by the exact odds formulas and the sum L_+.

## 6. Chronological cap and the perturbation functional

This is the critical step, and it is valid as written.

Given H and U=1, the ideal number of proposed erasures is a sum of independent Bernoulli variables with probabilities epsilon p_qj. Its mean is at most h/128. The product-mgf Chernoff bound therefore gives failure probability at most a_h=(e/128)^h.

Coupling the actual chronological cap and the ideal thinning with the same raw bits and preassigned coins makes their candidate outputs identical unless more than h proposed erasures occur. Hence the conditional mode-one output laws differ in TV by at most a_h.

The capped likelihood is **not** being equated with the uncapped likelihood conditioned on a count event. Such an equality would generally fail because after the cap, later ones are passed without the usual thinning probability. The proof avoids that issue entirely by perturbing the integrated posterior-mode gap J.

For a change in the mode-one law of TV at most a, the fair prior gives

    ||m'-m||_1<=a,
    sum m'|v'-v|<=2a.

Both constants depend on the explicit half-prior factor. The minimum-weight change contributes at most a_++a_-, and the two posterior changes contribute at most 2(a_++a_-). Thus J_cap>=J-3(a_++a_-), yielding the stated loss at most 6a_h. No hidden normalization factor or missing factor of two is present.

Choosing H_beta so this loss is at most J_*/2 supplies a positive mode-posterior gap **before** the endpoint rare-output factor is applied. This is uniform in rho and in arbitrarily small t. A generic additive TV error on the final prediction risk would not have supplied that uniformity.

## 7. Actual endpoint posterior and risk lower

On D, B is Ber(t), independent of U and the candidate outputs given H. The cap depends only on interior bits and coins, and the reserved endpoint edit means the e<k gate introduces no additional hidden variable on actual paths. Thus the endpoint flip probability conditional on H,Y is exactly rho v_q^cap(H,Y).

The two terminal source rows are the common values t and r. T23 and the exact subtraction T24 therefore give the actual fixed-source posterior target gap. They are not posterior probabilities under a mixture over source alternatives.

The observation mass is f_q(H)m_q^cap(Y)ell_q(1). Multiplication by the minimum mass retains the rare W=1 probability and cancels only one ell denominator. Using max ell<=t+rho yields the displayed factor rho t/(rho+t). This remains valid at rho=0 and all denominators are positive because t>0.

The coefficient in T26 checks: r/4 from the row/future factors, scaffold overlap 3/4, J_cap>=J_*/2, and division by two in the two-source risk inequality give 3rJ_*/64. Pointwise ordering of capped mode posteriors is unnecessary because both J_cap and the endpoint gap use absolute differences.

## 8. Scaling, matching claim and limits

For k>=2 and M>=4,

    min{k-1,floor(sqrt M)}>=min{k,sqrt M}/2.

The dyadic t bracket therefore gives a fixed beta-dependent multiple of min{(k^2/M)^(1/3),1}. Since rho<=1, the endpoint lower has the claimed scale. After enlarging M_beta so floor(sqrt M)>=H_beta, every case h<H_beta has k<=H_beta. The one-edit fallback then loses only a fixed factor H_beta^(2/3), completing all positive budgets without a missing intermediate regime.

The clean, protected-budget and thinning-mode witnesses may be combined by a maximum in the same class with base-state allowance at least eight. No edit budgets or probability laws of distinct witnesses are added. This yields the matching fixed-beta statistical profile with the paid counter and time-indexed tables. General rational rho is valid for the lower; the dyadic computational upper can use the already described paid upper dyadic certificate within a factor two when needed for an order comparison.

The source alternatives vary with M,k and approach rare-transition boundaries. The channel has persistent hidden memory and is not required to mix with the source. These are permitted, explicit features of the contract, not consequences of a stronger stationary-channel or fixed-positive-transition-floor assumption.

The approval does not cover every smaller base-state budget, eight total states including the counter, a fixed homogeneous channel, an all-initial-law extension, beta-uniform sharpness, fixed-source inconsistency, optimal depth/width/precision, training, floating-point execution or external novelty. Within the declared interface, however, the full growing-budget endpoint lower is now analytically established by this new argument.
