# Uniform binomial sign separation under a hidden success cap

5 November 2026. Analytical candidate for independent review.

This note proves an elementary uniform separation lemma for the hidden `00` count in an online-channel lower-bound construction. It also proves that conditioning on the total hidden count being at most the edit budget preserves a fixed positive separation. The threshold is common to both source alternatives. No normal approximation or numerical estimate is needed.

## 1 Assumptions and conclusion

Fix constants

    0 < d <= 1/4,        0 < a <= b <= 1.

Let h and n be positive integers and let t be a real number satisfying

    0 < t <= 1/8,
    a h <= mu := n t <= b h,
    mu >= 16.                                             (B1)

For every q in the interval [q_-,q_+], define

    q_- = 1 - d/sqrt(h),
    q_+ = 1 + d/sqrt(h),
    p(q) = q t / [1 + (q-1)t].                            (B2)

Under the law indexed by q, let S have distribution Bin(n,p(q)). Use the same integer threshold under both alternatives:

    c = floor(mu),
    A = 1{S > c},
    F(q) = E_q A.

Then

    F(q_+) - F(q_-) >= 3 d sqrt(a)/(8e)
                       >= Delta_*,

    Delta_* := d sqrt(a)/(8e) > 0.                        (B3)

The conservative constant Delta_* will be used in the truncation statement. Its value is independent of h, n and t within (B1).

## 2 Elementary bounds throughout the parameter interval

Put delta=d/sqrt(h), so 0<delta<=1/4. The denominator in (B2) is positive, and

    p(q)-t = (q-1)t(1-t) / [1+(q-1)t].

Since 1-t <= 1-delta t, this identity gives

    |p(q)-t| <= delta t,
    3t/4 <= p(q) <= 5t/4 <= 5/32 < 1/4.                 (B4)

Differentiating (B2) gives

    p'(q) = t(1-t)/[1+(q-1)t]^2
          >= t(7/8)/(33/32)^2
          = (896/1089)t
          >= 3t/4.                                      (B5)

Write m=n-1 and p=p(q). Since mu>=16 and t<=1/8, n>=128. In particular,

    c >= 16,
    m-c >= n-1-mu >= 7n/8-1 >= 111.                     (B6)

Thus 1<=c<=m-1, so none of the binomial masses below is at a boundary.

Using (B4) and mu>=16,

    mp = np-p >= 3mu/4-1/4 >= 2mu/3,
    mp(1-p) >= (2mu/3)(3/4) = mu/2.                     (B7)

Also,

    |c-mp|
      <= |c-mu| + n|t-p| + p
      <= 5/4 + d mu/sqrt(h).

The last inequality and (B1) imply

    |c-mp|/sqrt(mu)
      <= 5/[4sqrt(mu)] + d sqrt(mu/h)
      <= 5/16 + 1/4
      = 9/16.                                           (B8)

These estimates hold for every q in the entire interval, not just at its endpoints.

## 3 A uniform lower bound for the required local mass

For 0<x,p<1, write

    D(x || p) = x log(x/p)
                + (1-x) log[(1-x)/(1-p)].

The elementary inequality log u<=u-1 gives

    D(x || p)
      <= x(x/p-1) + (1-x)[(1-x)/(1-p)-1]
      = (x-p)^2/[p(1-p)].                               (B9)

Take x=c/m. By (B7)-(B9),

    m D(c/m || p)
      <= (c-mp)^2/[mp(1-p)]
      <= 2(9/16)^2
      = 81/128 < 1.                                     (B10)

For every integer r>=1, the usual elementary Stirling inequalities are

    sqrt(2 pi r)(r/e)^r <= r!
        <= sqrt(2 pi r)(r/e)^r exp[1/(12r)].

Apply the lower bound to m! and the upper bound to c! and (m-c)!. By (B6), all three applications are valid. Direct cancellation of the powers yields

    P(Bin(m,p)=c)
      >= exp[-m D(c/m || p)]
         exp[-1/(12c)-1/(12(m-c))]
         / sqrt[2 pi c(1-c/m)].                          (B11)

Since c>=1 and m-c>=1, the second exponential is at least exp(-1/6). Also c(1-c/m)<=c<=mu. Consequently (B10)-(B11) give

    P(Bin(m,p)=c)
      >= exp(-1) exp(-1/6)/sqrt(2 pi mu)
      >= 1/[4e sqrt(mu)].                               (B12)

The last numerical constant follows without approximation: exp(-1/6)>=1-1/6=5/6, pi<4, and (5/6)/sqrt(8)>1/4. This deliberately weak constant is sufficient.

## 4 The exact derivative identity and separation

For fixed c with 0<=c<=n-1, differentiation of the finite binomial tail and cancellation of adjacent terms gives

    d/dp P(Bin(n,p)>c)
      = n P(Bin(n-1,p)=c).                              (B13)

Explicitly, use

    k binom(n,k) = n binom(n-1,k-1),
    (n-k) binom(n,k) = n binom(n-1,k)

in the derivative of the sum over k=c+1,...,n. The positive sum begins at k-1=c and the negative sum begins at k=c+1, so only the mass at c remains.

Equivalently, the binomial score identity gives

    Cov_p(1{S>c},S)
      = n p(1-p) P(Bin(n-1,p)=c),

    dF(q)/dq
      = p'(q) Cov_p(1{S>c},S)/[p(1-p)]
      = n p'(q) P(Bin(n-1,p(q))=c).                     (B14)

The threshold c=floor(nt) is fixed as q varies. This is essential for applying (B13) directly.

Combining (B5), (B12) and (B14),

    F'(q)
      >= n (3t/4) / [4e sqrt(mu)]
      = 3 sqrt(mu)/(16e).

The interval length is q_+-q_-=2d/sqrt(h). Integration therefore gives

    F(q_+)-F(q_-)
      >= [2d/sqrt(h)] [3sqrt(mu)/(16e)]
      = 3d sqrt(mu/h)/(8e)
      >= 3d sqrt(a)/(8e).

This proves (B3).

## 5 Conditioning on the total hidden success cap

Suppose that, under each of the two endpoint laws q=q_- and q=q_+, the count S above is a subset sum of a finite independent Bernoulli family. The remaining Bernoulli variables need not have identical probabilities. Let K denote the sum over the entire family, and assume, for some fixed 0<eta<1/e,

    E_q K <= eta h,             q in {q_-,q_+}.          (B15)

Put

    C = {K <= h},
    epsilon_h = (e eta)^h.

The statement also applies pointwise after conditioning on a fixed scaffold: every probability and expectation in this section can be interpreted under that conditional law, provided its Bernoulli independence, (B1) and (B15) hold.

For lambda>0, Bernoulli independence and 1+u<=exp(u) give

    E_q exp(lambda K)
      = product_j [1+p_j(q)(exp(lambda)-1)]
      <= exp[(E_q K)(exp(lambda)-1)].

Choose lambda=log(1/eta)>0. Markov's inequality, and the inclusion {K>h} subset {K>=h}, imply

    P_q(C^c)
      <= exp[-h log(1/eta)]
         exp[eta h (1/eta-1)]
      = [eta exp(1-eta)]^h
      <= (e eta)^h
      = epsilon_h < 1.                                  (B16)

In particular, both conditional laws given C are well defined.

For any random variable U taking values in [0,1], write epsilon=P(C^c). The exact mixture identity is

    E U = (1-epsilon) E[U|C] + epsilon E[U|C^c].

If epsilon=0 the following bound is immediate; otherwise both conditional expectations exist. Rearranging yields

    |E[U|C]-E U|
      = epsilon |E[U|C]-E[U|C^c]|
      <= epsilon.                                       (B17)

Thus there is no factor 1/(1-epsilon) in the conditioning error. Applying (B17) separately under the two laws with U=A, and then using (B3) and (B16), gives the signed bound

    E_+[A|C] - E_-[A|C]
      >= E_+ A - E_- A - 2 epsilon_h
      >= Delta_* - 2(e eta)^h.                          (B18)

Define the explicit onset

    h_0 = ceil max{
              16/a,
              log(4/Delta_*) / log[1/(e eta)]
          }.                                             (B19)

If h>=h_0 and ah<=nt<=bh, the first term ensures nt>=16, and the second ensures (e eta)^h<=Delta_*/4. Therefore

    E_+[A|C] - E_-[A|C] >= Delta_*/2 > 0.              (B20)

No monotonicity assertion about the cap-conditioned Bernoulli law is used. The conditioning estimate controls its possible effect directly.

## 6 Parameters for the online hidden count construction

Let M>0 and suppose t is chosen, for a fixed tau>0, in the bracket

    (tau/2)(h/M)^(1/3) <= t <= tau(h/M)^(1/3),

and the retained scaffold has n eligible sites with retained future pair `00`, where

    M t^2/4 <= n <= M t^2/2.

Then

    (tau^3/32)h <= nt <= (tau^3/2)h.

Hence the lemma applies with

    a = tau^3/32,
    b = tau^3/2,
    eta = 1/64,
    Delta_* = d sqrt(tau^3/32)/(8e),                     (B21)

provided tau^3/2<=1, t<=1/8, and h>=h_0 from (B19). Rational or dyadic t is permitted; the proof needs no irrational parameter.

For the total hidden bits, let o_j(q) be their conditional odds. If the odds are increasing in q and the scaffold satisfies

    L_+ := sum_j o_j(q_+) <= h/64,

then both alternatives satisfy (B15), because

    E_q K
      = sum_j o_j(q)/[1+o_j(q)]
      <= sum_j o_j(q)
      <= L_+
      <= h/64.

Thus the cap tail is at most (e/64)^h under either law. A supplied unconditional estimate E_q L_+<=4Mt^3<=4tau^3h also implies, by Markov's inequality,

    P_q(L_+>h/64) <= 256 tau^3.                         (B22)

Equation (B22) controls the probability of failing this particular scaffold condition. Establishing all other scaffold conditions, recovering the scaffold from outputs, implementing the threshold online, and proving the final posterior-risk lower bound are separate obligations of the channel construction.

This lemma is intended only for h>=h_0. A one-edit witness can handle the finitely many smaller edit budgets with a constant loss depending on h_0; no finite-h extension is asserted here.
