# Stationary binary prediction through a known channel: a small-budget upper

Date: 2026-11-05 UTC. Analytical candidate for independent review. No scientific executable checks, public write, external novelty claim, efficient algorithm, or sharp-rate claim.

## Result

Fix 0<beta<=1. In the STATIONARY binary second-order class D2(beta), for every known, source-independent, future-blind observation channel with strict Hamming budget k, there exists a statistical predictor satisfying

    E TV(q(Z),P_(theta,C)(X_(N+1) in . | Z))
       <= min{1,C_beta[M^(-1/10)+(k/sqrt(M))^(1/4)]}.    (B1)

Here N=M+2, M>=64, and C_beta is finite for each fixed beta. The predictor may use beta, k and the complete channel kernel C. No endpoint-reliability restriction is needed for this upper; it therefore applies to every supplied rho. The rate is deliberately coarse.

In particular, k=o(sqrt(M)) gives uniform consistency for stationary binary sources when beta is fixed positive. This contrasts with the one-edit stationary K>=4 and binary arbitrary-start lower constructions. It does not settle a sharp stationary binary rate, beta=0, or a moving-beta regime.

All targets below condition under the FIXED true source and channel, not a prior mixture of source hypotheses. The channel does not change the physical source state or share randomness with future innovations.

## 1. Exact source model

The source has binary transition rows theta_(a,b)(c), pair transition

    P((a,b),(b,c))=theta_(a,b)(c),

and stationary pair law Pi satisfying

    P^2(s,t)>=beta Pi(t) for every pair s,t.

Write pi for its stationary symbol marginal and m=min(pi(0),pi(1)). Summing the minorization over the second coordinate of the target pair gives

    theta_u(c)>=beta pi(c) for all u,c.                  (B2)

Stationarity then gives

    Pi(a,b)=sum_c Pi(c,a)theta_(c,a)(b)
       >=beta pi(a)pi(b).                              (B3)

The two-step kernel contracts TV by at least the factor 1-beta. When m>=a>0, every row coordinate is at least eta=beta a, and every pair mass is at least beta a^2.

## 2. A known-channel posterior stability lemma

Suppose m>=a, let eta=beta a, and let another table theta_hat have all row coordinates positive. Let Pi_hat be its stationary pair law and

    epsilon=max_u TV(theta_hat_u,theta_u).

Pair-row TV equals source-row TV. Stationarity, contraction of the TRUE P^2, and the two-step perturbation bound give

    TV(Pi_hat,Pi)
       <=2epsilon+(1-beta)TV(Pi_hat,Pi),
    TV(Pi_hat,Pi)<=2epsilon/beta.                       (B4)

For a fixed observation z, let P_theta(x) and P_hat(x) be the stationary clean-word probabilities. Define posteriors on clean words using the SAME known channel C(z|x), and predict the next symbol by averaging the corresponding source row under each posterior.

The plug-in table theta_hat is allowed to depend on z. Everything in the following comparison is pointwise at this fixed z. Because both source tables and their stationary pair laws are positive, any observation possible under the true source has a positive plug-in denominator.

Assume first epsilon<=beta^2 a^2/8. From (B3)-(B4),

    |log(Pi_hat(s)/Pi(s))|<=4epsilon/(beta^2 a^2).

Also, (B2) and epsilon<=beta^2 a^2/8<=eta/2 give

    |log(theta_hat_u(c)/theta_u(c))|<=2epsilon/eta.

Every two clean words x,x' with C(z|x)>0 and C(z|x')>0 have Hamming distance at most 2k. Their stationary log-likelihood-ratio difference has an initial-pair contribution at most 8epsilon/(beta^2 a^2). At most 6k triple positions differ, and each contributes at most 4epsilon/eta. Hence the oscillation of log(P_hat(x)/P_theta(x)) over this posterior support is at most

    L=8epsilon/(beta^2 a^2)+24k epsilon/(beta a).        (B5)

After normalization, the two posterior densities have ratio between exp(-L) and exp(L). They therefore share a submeasure of mass at least exp(-L), so their TV distance is at most 1-exp(-L)<=L. Averaging source rows adds at most epsilon. Thus the plug-in predictive error is at most epsilon+L.

If epsilon>beta^2 a^2/8, the trivial unit bound is at most 8epsilon/(beta^2 a^2). Combining the two cases yields the global pointwise bound

    TV(p_hat(z),p_theta(z))<=D epsilon,
    D=9/(beta^2 a^2)+24k/(beta a).                      (B6)

This is an information-theoretic lemma. It does not claim that summing over all clean words is efficient or that an arbitrary real channel kernel has a finite rational representation.

## 3. Simultaneous row estimation from the corrupted word

For each of the four pair rows, form its add-one successor estimate from all M observed triples in Z. Clip each binary coordinate to [eta/2,1-eta/2], preserving the two coordinates' sum. Call the resulting table theta_hat. It is strictly positive and has a unique stationary pair law Pi_hat.

When the true m>=a, its rows lie in [eta,1-eta]. This coordinate clipping cannot increase their absolute errors. The simultaneous row estimate and raw-edit comparison proved in `EDIT_OVERLAP_and_TARGET_BOUNDARIES.md`, section 5, give

    E epsilon <= B,
    B=32/(eta^2 sqrt(M))+(32+24k)/(eta^2 M)
                      +4 exp(-eta^2 M/32).             (B7)

For completeness, the occupation proof samples pair states ending at 4,6,..., each with conditional probability at least eta^2 for each named pair. An adapted Chernoff bound gives all four clean row counts at least eta^2 M/8 except on an event of probability at most 4exp(-eta^2 M/32). Each clean row numerator is a predictable-row martingale sum with second moment at most M. Summing their expected absolute values and applying the shared-count perturbation bound adds at most 24k/(eta^2 M). Neither independent row samples nor conditioning the original statistical theorem on a selected row is assumed.

The predictor can compute the stationary posterior p_hat(z) using this theta_hat and the disclosed channel C. Applying (B6) pointwise, despite the data dependence of theta_hat, gives

    E TV(p_hat(Z),p_theta(Z))<=D B whenever m>=a.        (B8)

## 4. Adaptive treatment of a nearly deterministic binary source

The estimator does not know whether m>=a. Let

    b'=M^(-1)sum_(t=3)^N Z_t,
    m'=min(b',1-b').

Choose 0<a<=1/16 with k/M<=a/2. If m'<=2a, predict the empirical majority symbol with probability one. Otherwise use the posterior plug-in rule from sections 2-3.

For the clean empirical frequency b, stationarity and two-step mixing imply

    Var(b)<=5/(beta M).                                (B9)

Indeed the lag-h covariance of the binary coordinate is bounded in absolute value by (1-beta)^floor(h/2). Summing its geometric series in the variance expansion gives the displayed loose constant. Pathwise |b'-b|<=k/M. Thus, for

    D_freq={|b'-pi(1)|>=a},

Chebyshev gives

    P(D_freq)<=20/(beta M a^2).                        (B10)

This probability calculation only uses the unconditional clean stationary law and a pathwise corruption bound; C may be fully history-adaptive.

If m<a, selecting the plug-in branch requires D_freq. Otherwise the empirical majority is the true majority except on D_freq. The expected loss of predicting the true majority is m, because the future symbol has marginal pi. This remains valid when its loss is restricted to an observation-selected event: the nonnegative restricted loss is bounded by its unconditional value.

If a<=m<=4a, the plug-in bound (B8) is available. The majority branch costs at most m<=4a plus the probability of selecting the wrong majority, which requires D_freq.

If m>4a, selecting the majority branch requires D_freq, and the plug-in bound is again available. Here use that x->min(x,1-x) is 1-Lipschitz.

Combining the three cases yields the explicit uniform finite-parameter bound

    Risk <= min{1, 4a+40/(beta M a^2)+D B},             (B11)

with eta=beta a and D,B from (B6)-(B7).

Binary structure is essential to this fallback: if the minority mass is tiny, the entire next-symbol marginal is close to one point mass. With four symbols, an arbitrarily rare nuisance coordinate can coexist with a nontrivial second coordinate, as in the one-edit lower construction.

## 5. A coarse optimized consequence

Set

    a_*=max{M^(-1/10),(k/sqrt(M))^(1/4)}.

If a_*>1/16, any probability-vector predictor has risk at most 1<=16a_*, giving (B1) after increasing C_beta. Otherwise set a=a_*. Then k<=sqrt(M), and k/M<=a/2 automatically. The main contributions in D B are bounded using

    M^(-1/2)a^(-4)<=a,
    (k/sqrt(M))a^(-3)<=a,
    k+1<=2sqrt(M).

The empirical-frequency term also satisfies 1/(M a^2)<=a. The exponential remainder in D B is at most C_beta a: use a>=M^(-1/10), k<=sqrt(M), and the finite supremum of a polynomial times exp(-c beta^2 M^(4/5)). Thus (B11) implies (B1).

The displayed power 1/10 is an upper-bound artifact of loose simultaneous row and stationary-law estimates. No optimality is asserted. At k=0 one may instead use the existing clean terminal estimator to retain its sharper clean rate.

## Boundaries

- Stationary initialization is used both in the likelihood formula and the small-minority fallback. The binary arbitrary-start one-edit lower shows that it cannot simply be removed.
- beta is fixed positive for the consistency conclusion. The explicit bound (B11) is valid for beta>0 but its constants worsen as beta decreases; no uniform beta=0 result follows.
- The upper is uniform over all disclosed future-blind channels obeying the strict edit support condition, including channels that alter an endpoint with probability one. It is not available when the channel is unknown.
- The construction uses no edit mask or realized channel seed.
- Remaining gaps include a sharp stationary binary rate, the moving-beta transition, and the stationary ternary case.
