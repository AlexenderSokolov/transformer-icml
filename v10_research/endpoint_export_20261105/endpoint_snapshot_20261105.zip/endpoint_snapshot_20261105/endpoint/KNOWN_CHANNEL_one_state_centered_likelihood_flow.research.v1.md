# Centered likelihood flow for the open one-state upper

5 November 2026 UTC. Analytical research note only. No scientific executable checks, numerical experiments, external writes, or new general minimax theorem. The positive lemma below is elementary but has not received an independent exact-file review.

## 1. Result of the search

No general no-floor S=1 upper stronger than the reviewed unrestricted-online upper is established here. The direct likelihood-flow route has an exact endpoint-centered form, but its missing estimate is a quotient-stability estimate involving the full prefix/counter likelihood. Neither the endpoint certificate nor clean-source mixing supplies that estimate.

One useful positive control is proved in Section 4: if all changes are confined to the last L raw coordinates, the integrated complete-score covariance for the future prediction functional is at most sqrt(rho L I_step). This retains all clean-score cancellations, has no transition floor, and applies to any disclosed channel on that suffix. It does not extend to a channel with remote counter updates by merely replacing L with k or k^2.

## 2. Exact S=1 path flow

Let N=M+2 and let d=(d_1,...,d_N) be the actual edit indicators. For a fixed displayed binary word z, the raw word is x_i=z_i xor d_i, and e_(i-1)=sum_(j<i) d_j. Thus every legal S=1 kernel has exactly

    W_theta(z,d)=P_theta(z xor d)
       product_(i=1)^N K_i(z_i | z_i xor d_i,e_(i-1)),
    D_theta(z)=sum_(d: |d|<=k) W_theta(z,d).

There is no additional free latent mode in this representation. Every increment is an actual symbol disagreement. Exhausted-counter guards and any zero channel rows are included without dividing by channel probabilities.

Write h_theta(x)=theta_(S(x))(1), and b_theta(z)=theta_(S(z))(1). Define the signed endpoint correction

    A_theta(z)=sum_d W_theta(z,d)
                    [h_theta(z xor d)-b_theta(z)].

Only paths with a changed terminal pair contribute. Exactly,

    p_theta(z)=b_theta(z)+A_theta(z)/D_theta(z).       (F1)

The per-word endpoint certificate implies

    sum_z |A_theta(z)| <= rho.                       (F2)

Indeed |h-b|<=1 and it vanishes on the endpoint-preserved paths. Sum the resulting joint probability over x,z, and apply the certificate for each x. This is an unconditional statement; A_theta need not have either sign, and (F2) does not bound its derivative.

## 3. The exact derivative retains the whole denominator

Consider a differentiable one-dimensional source family theta(t), with a fixed channel. Work at an interior parameter where the finite supported word probabilities are positive. Let S_t(x)=partial_t log P_t(x), including the stationary initial-law score, and let dot h_t and dot b_t be direct row derivatives.

Differentiating (F1) gives

    dot p_t(z)=dot b_t(z)
        +[dot A_t(z)D_t(z)-A_t(z)dot D_t(z)]/D_t(z)^2,
    dot D_t(z)/D_t(z)=E_t[S_t(X)|Z=z],
    dot A_t(z)/D_t(z)
      =E_t[(h_t(X)-b_t(z))S_t(X)
                         +dot h_t(X)-dot b_t(z)|Z=z].

Consequently the exact cancellation-preserving identity is

    dot p_t(z)=E_t[dot h_t(X)|Z=z]
                     +Cov_t(h_t(X),S_t(X)|Z=z).     (F3)

Equivalently the covariance is

    E_t[1_{S(X)!=S(z)}(h_t(X)-b_t(z))
                      (S_t(X)-E_t[S_t(X)|Z=z]) | Z=z].  (F4)

The centering in (F4) is essential. A bound on A, or a forward bound on the flow into an endpoint-edit state, does not alone control dot A D-A dot D. The derivative of the posterior distribution of the actual counter is part of this expression.

For a noninfinitesimal comparison, the corresponding exact identity is

    p_t(z)-p_s(z)=b_t(z)-b_s(z)
        +[A_t(z)D_s(z)-A_s(z)D_t(z)]/[D_t(z)D_s(z)]. (F5)

Thus a general S=1 proof still needs to control the cross-product in (F5), with its actual observation mass, or to integrate (F3) while controlling data-dependent fitted parameters. It cannot substitute a separate total-variation bound for the entire latent posterior.

The existing iid first-one-erasure barrier demonstrates why bounding intermediate forward/counter score norms loses the necessary cancellation: those norms can diverge while the covariance in (F3) is identically zero because the future row is constant. The remote-endpoint barrier demonstrates why dropping prefix terms in dot D is invalid. The complete-score rare-endpoint barrier demonstrates why multiplying a Fisher bound by rho rather than sqrt(rho) is invalid even without remote edits. These are separate obstructions, all respected by (F3)-(F5).

## 4. Positive control: all channel changes confined to a suffix

Suppose, more restrictively, that X_1,...,X_(N-L) are displayed without change, that N-L>=2, and that every channel action is confined to the last L raw coordinates. The channel may otherwise be arbitrary, known, source independent, and future blind. In particular it need not be S=1 for this lemma. Assume its per-word terminal-pair change probability is at most rho.

Let theta(t) be a differentiable stationary binary order-two source family at an interior parameter. Define the ordinary transition martingale scores

    s_i=partial_t log theta_t(X_i | X_(i-2),X_(i-1)),
    I_step(t)=E_t s_i^2.

Stationarity makes I_step independent of i. Let S_all be the complete source score, including the stationary initial pair, and g_t=theta_t(S(X))(1). Then

    E_t |Cov_t(g_t,S_all|Z)|
                       <= sqrt(rho L I_step(t)).     (F6)

Proof. The complete source score before the suffix is a measurable function of the unchanged observed prefix. Its conditional covariance is zero. Therefore only

    T=sum_(i=N-L+1)^N s_i

remains in the covariance. Orthogonality of transition martingale differences gives E T^2=L I_step. Conditional variance is bounded by the squared error from any measurable reference; choosing b_t(Z)=theta_t(S(Z))(1) gives

    Var(g_t|Z) <= E[(g_t-b_t(Z))^2|Z]
                      <= P(S(X)!=S(Z)|Z).

Conditional Cauchy-Schwarz followed by unconditional Cauchy-Schwarz yields

    E|Cov(g_t,T|Z)|
       <= sqrt(E Var(g_t|Z) E Var(T|Z))
       <= sqrt(rho E T^2),

which is (F6). No independence of the endpoint event and source scores was assumed, and no source score was discarded unless it was actually Z-measurable. The direct row term E[dot g_t|Z] in (F3) remains separate.

This also explains the scale in the endpoint-only full-score barrier: L=1 and rho=1/M allow a constant integrated covariance when I_step is of order M. A linear-rho Fisher bound would instead predict a vanishing quantity.

## 5. Exact unresolved strengthening and scope

For an arbitrary S=1 channel with remote edits, the prefix source score is not generally observed. The tempting strengthening

    E|Cov(g_t,S_all|Z)|
                  <= C_beta k sqrt(rho I_step(t))    (F7)

would be consistent with the reviewed full-score endpoint-only obstruction and with the rare-rho lower's Fisher-normalized scaling. This note neither proves (F7) nor rules out counterexamples. In particular, replacing the suffix length L in (F6) by k^2 is not justified by the actual edit count alone: the iid one-edit barrier already rules out that substitution for the missing score variance used in the second Cauchy-Schwarz factor.

Even a proof of (F7) would not, by itself, finish a minimax upper. It would still require a finite-parameter or integrated-likelihood argument that handles the data-dependent estimator, changes of observation measure, the direct row term, boundary parameters, and the four-dimensional source parameterization. No root-M, k/sqrt(M), or k sqrt(rho)/sqrt(M) general S=1 risk rate is claimed.

The established no-floor brackets therefore remain unchanged. The exact identities above specify where a new argument has to enter while preserving the clean-row cancellation.

## Sources read

- KNOWN_CHANNEL_one_state_rare_rho_lower.candidate.v1.md and its reviewed result.
- KNOWN_CHANNEL_one_state_iid_score_barrier.addendum.v1.md.
- KNOWN_CHANNEL_one_state_remote_endpoint_score_barrier.candidate.v1.md.
- KNOWN_CHANNEL_one_state_full_score_rho_barrier.candidate.v2.md.
- KNOWN_CHANNEL_positive_floor_rho_upper.candidate.v1.md.
- KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md.
- KNOWN_CHANNEL_stationary_binary_rho_interpolation.v1.md.
