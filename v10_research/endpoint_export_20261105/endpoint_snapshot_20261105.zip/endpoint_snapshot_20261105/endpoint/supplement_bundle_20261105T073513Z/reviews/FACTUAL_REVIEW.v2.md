# Independent static factual review, version 2

Review date: 2026-11-05 UTC.

Artifact: `endpoint_online_supplement.zh.v2.html`.

Final preserved v2 SHA-256: `0a63960bb7d9632b7ce273e7fd8b697039fa43acc3f865fd83d41349d8c5494c`.

## Disposition

**The two v1 corrections are resolved. One minor probability-domain clarification remained before final factual approval.** The complete v2 was reread statically, including the last Euler-constant clarification, and compared with v1 and the frozen sources. No rate, resource, channel-class or execution-status error was found.

The protected rule now explicitly uses q_raw(1)=v for designated successor d=1 and q_raw(1)=1-v for d=0 before clipping. The Hao–Orlitsky–Pichapati description is limited to supported target/rare-state/positive-floor distinctions. Han–Jana–Wu now carries the terminal-conditioned/time-reversed count attribution. Added Chan–Darwiche, corrected-version Paulin and Abraham–Gassiat–Naulet rows match the preserved primary-source audits, including their model and theorem limitations.

Definitions of pi, displayed counts, p_c, B/W, output precision r and rational description cost b_rho are correct. The e in the cap-tail bound is now explicitly Euler's constant, distinct from the edit counter and the earlier auxiliary e.

The remaining clarification was in section 3.2. The identity E[p_c(Z)F(Z)]=m E[F(Z)|X_(N+1)=c] must be used only for m>0. At m=0 its right conditional expectation is not defined by conditioning on that null event; the source proof handles the deterministic case separately. A requested sentence stating this domain is sufficient. This affects exposition, not the theorem or its rates.

## Scope retained

All factual findings and limitations in `FACTUAL_REVIEW.v1.md` remain applicable. The proof-profile, fixed-floor versus unrestricted distinction, online sandwich/matched regimes, finite-state normalization, dyadic input contract, complete estimator, exact-rational architecture and full paid ledgers were rechecked without broadening them. The historical failed replay and zero new execution remain separated correctly.

The earlier intermediate v2 digest `888b7b22b98e892404c4312b0b9abf89dafa46786f85b357c8654d529f0be4ee` was observed before the final Euler-constant wording. This review binds only the final preserved v2 digest at the top.

Only static reads, text comparison, mechanical hashing and review writing were performed. No HTML/source edits, executable checker, scientific execution, rendering, model test, external retrieval or public upload occurred. This is not formal verification, visual QA, link reachability verification or external novelty certification.
