# Independent static factual review of the Chinese supplement, version 1

Review date: 2026-11-05 UTC.

Reviewed artifact: `endpoint_online_supplement.zh.v1.html`.

Present-time SHA-256: `2304c3e7f8d5509d0d6c03d5f9b35f368c08cf93981950add90418e6733f2a01`.

## Disposition

**HOLD for two localized corrections.** The current mathematical rates, channel classes, paid computational resources, online gaps, and execution-status separation are consistent with the frozen inputs. No additional substantive contradiction was found. The two corrections below should be checked in the next version before factual approval.

1. **Section 5.4, protected-estimator orientation.** After defining the designated successor d as the complement of the first observed terminal bit, the draft gives its probability v=(C'_des-6k)_+/(J'+6k+2) and immediately describes clipping around the empirical one frequency. It must explicitly convert to q_raw(1)=v if d=1, and q_raw(1)=1-v if d=0, before clipping. The current abbreviated wording can be read as clipping the probability of symbol zero around the frequency of symbol one. The precise rule is in the sharp-rho composition candidate, section 2, and its independent review, section 1.
2. **Section 8, Hao–Orlitsky–Pichapati attribution.** The frozen EPR001 source audit supports actual-terminal versus matrix estimation, rare-state distinctions and positive floors for this paper. It does not establish the draft's attribution of terminal-conditioned count methodology to it. Keep the supported claims and cite Han–Jana–Wu, *Optimal prediction of Markov chains with and without spectral gap conditions* (2021), supplement section 7.2, Lemma 15, Remark 4 and Appendix B, for the terminal-conditioned/time-reversed count comparison. The exact source and limitations are preserved in the rho-interpolation primary-source audit, section 5.C.

No HTML or source proof was edited by this reviewer.

## Inputs and method

The complete HTML was read statically. Relevant proof candidates, independent reviews and primary-source audits were read, including the quantitative and rare lower statements, log-free and rho-interpolation statements and proof interfaces, finite-state bridge and stack addendum, full and sharp-rho compositions, and online one-edit/protected/growing-budget constructions and reviews. The two subsequently captured historical provenance records were read in full.

All 57 mathematical inputs passed mechanical `sha256sum -c INPUT_SHA256SUMS.txt`; both additional provenance inputs passed `sha256sum -c PROVENANCE_INPUT_SHA256SUMS.txt`. These are present-byte identity checks, not retrospective execution gates or historical-hash attestations. The mathematical cutoff remains 07:35:13 UTC. The two later-captured historical records do not extend that cutoff.

Only static file reading, mechanical hashing and writing this review were performed. No executable checker, scientific program, model evaluation, simulation, browser rendering, external retrieval or public upload was run. This review is factual and analytical, not formal verification, external peer review, a new exhaustive literature search, visual QA or external-link reachability testing. Imported predecessor theorems such as SC003 were not re-proved.

## Verified result profile

- The experiment is the source-specific clean-future posterior under each fixed true source and a common disclosed future-blind channel. It is not a source-hypothesis mixture, classification loss, latent-terminal-row loss or displayed-terminal-row loss. The strict realized edit cap and per-clean-word endpoint constraint are retained.
- For fixed 0<beta<1, sufficiently large M, and all k,rho in the stated ranges, the unrestricted offline stationary binary risk is Theta_beta(min{1,M^(-1/2)+k/M+min{rho,(k^2/M)^(1/3)}}), with zero endpoint term at k=0. The equivalent F_beta form is correct at fixed beta. The minimum, rather than rho times the budget rate, is essential.
- At fixed positive rho the offline consistency threshold is exactly k=o(sqrt(M)); the moving-rho condition stated in section 3 is correct. The beta=1 IID boundary is properly separated.
- The fixed-positive-transition-floor matched rate requires fixed beta<1, eta<1/2 and rho>0. The quantitative lower has rho outside the saturation cap. No uniform sharp moving-rho fixed-floor rate is inferred.
- The representation-counting inequality and its expected-risk constant agree with the computational-interface audit. The free-likelihood-oracle exception, fixed-k Hamming-ball enumeration and full-description accounting are preserved.
- The finite-state interface uses normalized online rational tables, independent auxiliary randomness, paid public timing and a separate strict counter. Prohibited edits are redirected without deleting probability mass or terminal rejection conditioning.
- The bridge implements the actual fitted posterior and then the entire statistical estimator, including majority/saturation branches and the public sharp-rho selector. One final output contributes one 2^(-r) error. The large explicit constant and dyadic certificate precision are charged.
- The displayed R_ops, B_base, B_full, B_int and G bounds match the candidates. Growing storage has d,L=O(G) and w=O(r+log N+log G). The two-stack construction has d=64, FFN128, L=O(N log N+G^2) and w=O(G+r+log N). Dense parameter, runtime, activation, optional attention and preprocessing ledgers are retained.
- The common architecture is zero-score self-inclusive causal softmax/ReLU, with raw tokens plus public positions and a synthetic query; no LayerNorm/RMSNorm or final vocabulary softmax is assumed. Bounded local norms are not advertised as fixed information capacity or ordinary floating-point robustness.
- The online one-edit lower is c_beta min{rho,M^(-1/3)} with four base states plus a binary counter. The protected lower is 27k/(1024M) with one base state plus a k+1 counter. The latest growing-budget lower is c_beta min{rho,(k/M)^(1/3)}, with at most 16(M+1)^2 base states plus the counter. Public time dependence is charged.
- The current online sandwich and the matching regimes k=1, rho<= (k/M)^(1/3), and k of order M are correct for a class allowing the stated paid polynomial-state witnesses. The general growing-k endpoint gap is not an established online/offline separation, and fixed-state growing-budget sharpness remains open.

## Version and evidence separation

The draft correctly treats earlier claims that the full stationary binary rate, constant-width realization, complete estimator implementation or any growing-budget online lower remain open as historical statements superseded only in the specific directions established by later files. The still-open general growing-k online endpoint rate is not erased.

The historical strict replay record reports exactly one approved v4 launch that failed before replay during the required network-isolation setup. Both reported exits are 1, no replay directory or case events exist, and planned 33,300 blocks, 413 liveness operations, 514 Frobenius operations and 68,486 ordered events are not passed-case counts. The draft preserves this distinction, the nonretroactive capture gap, numerical NO-GO, and the separation from the new no-normalization analytical bridge.

## Prior-art positioning

Apart from the localized Hao attribution above, the draft is appropriately bounded. General Bayesian stability, weighted-automaton inference, Transformer simulation, bounded stack coding, causal adversarial channels and near-degenerate HMM difficulty have antecedents. The report does not claim priority or deny all HMM representations. Adding the precise frozen-audit citations for Chan–Darwiche, Han–Jana–Wu, corrected-version Paulin and Abraham–Gassiat–Naulet would improve attribution without changing the mathematical conclusions.

The report's current independent-review status is accurately pending. Any changed HTML requires a new hash-bound review or a precisely documented delta review; this disposition binds only the v1 bytes above.
