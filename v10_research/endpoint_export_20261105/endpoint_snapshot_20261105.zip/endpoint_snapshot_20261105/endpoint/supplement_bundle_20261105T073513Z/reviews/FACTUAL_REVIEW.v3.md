# Independent static factual review, final version 3

Review date: 2026-11-05 UTC, final candidate checked after 07:49:34 UTC.

Artifact: `endpoint_online_supplement.zh.v3.html`.

Present-time SHA-256: `754f48305ae955a47f8c2866f927c1434d1a4c568976d696932b7a5b9dddd641`.

## Disposition

**PASS for factual consistency with the frozen inputs at the stated scopes. No outstanding factual correction remains.** This is a hash-bound static factual approval, not executable, formal, numerical, visual or external peer-review certification.

The complete v2 was reread and its final digest bound in `FACTUAL_REVIEW.v2.md`. I then inspected the complete v2-to-v3 textual difference. It consists only of the version number, the correct positive-probability domain sentence in section 3.2, and the associated final-review wording. The new sentence explicitly confines the posterior weighting identity to m>0 and handles m=0 separately without conditioning on a null future event. This resolves the remaining v2 clarification.

The protected-estimator orientation and literature-attribution corrections from v1 remain present. Earlier versions and their review history remain preserved.

## Confirmed substantive conclusions

- For fixed 0<beta<1, the unrestricted stationary binary disclosed offline channel risk has the stated log-free sharp rho profile, uniformly in the specified k,rho ranges for sufficiently large M. Fixed positive rho gives exactly the square-root consistency threshold. The moving-rho condition, clean k=0 case and beta=1 exception are not conflated.
- The fixed positive transition-floor matched rate has its narrower source class and fixed-rho quantifier. The broad-class one-edit cube-root rate does not contradict that subclass's square-root rate.
- The full computational bridge uses a normalized rational online finite-state channel with paid time-expanded description, separate strict edit counter, independent randomness, and appropriate endpoint certification. Its full estimator, protected orientation, exact rational clipping, public selection and one final approximation error agree with the candidates.
- The two network resource alternatives, integer/circuit budgets, scalar precision, dense parameters, runtime, activation/attention memory and preprocessing are reported with their actual costs. Constant width does not imply fixed information or precision. The architecture omits normalization layers and uses an exact-rational contract, not ordinary floating-point or training guarantees.
- Online one-edit, protected and growing-budget lower bounds retain their correct state and counter costs. The growing-budget endpoint lower is (k/M)^(1/3), not the offline (k^2/M)^(1/3). Matching low-rho/one-edit/saturated-budget regimes and remaining general growing-k/fixed-state questions are stated accurately. The unresolved gap is not called a proven separation.
- Prior-art wording stays within the inspected frozen audits and distinguishes general antecedents from the particular theorem package. No priority claim, blanket exclusion of HMM representation or unsupported transfer of a coding/latent-target lower is made.
- Historical static executions, incomplete original capture, the single failed strict v4 containment launch, planned rather than executed case counts, numerical NO-GO and this supplement's zero new scientific execution are kept distinct. The old mandatory post-LN evidence line is not used to certify the new no-normalization construction or vice versa.

## Input integrity and review limits

At the final check, all 57 entries in `INPUT_SHA256SUMS.txt` and both entries in `PROVENANCE_INPUT_SHA256SUMS.txt` passed mechanical hash verification. The 07:35:13 mathematical cutoff and later capture of two historical provenance records remain distinct. Hashes identify current bytes and do not retrospectively fill historical pre-run or per-case capture gaps.

The earlier reports provide the detailed inspected-source inventory and issue history. This review does not freshly re-prove every imported predecessor such as SC003, establish exhaustive literature priority, or independently certify remote historical commit contents. It relies on the frozen candidates/reviews at their declared interfaces and independently checks their synthesis.

Only static text reading/comparison, mechanical hashing and review writing were used. No executable checker, scientific program, model evaluation, simulation, browser rendering, external retrieval, source/HTML editing or public upload was performed. Any subsequent change to the report bytes requires a new binding or explicit delta review.
