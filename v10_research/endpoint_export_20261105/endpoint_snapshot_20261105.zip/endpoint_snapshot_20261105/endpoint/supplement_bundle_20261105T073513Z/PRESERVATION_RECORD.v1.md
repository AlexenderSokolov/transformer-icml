# Supplement preservation record

Research snapshot cutoff: 2026-11-05T07:35:13Z (session clock immediately before copying). All 57 top-level endpoint-research Markdown files present at this cutoff were copied without modifying their originals. INPUT_SHA256SUMS.txt binds those copied bytes; it is a present-time snapshot, not a historical attestation.

Two existing execution-provenance documents, authored on 2026-11-04 and read/captured during 07:35:48–07:36:29 UTC on 2026-11-05, are included separately. PROVENANCE_INPUT_SHA256SUMS.txt binds these additional files. This later provenance retrieval does not move the mathematical result cutoff. Total copied Markdown inputs: 59.

The earlier 03:46 endpoint report bundle is preserved unchanged; this supplement is standalone and does not require it at runtime. Its version-2 report digest is 5f66d2d8525d86738afec0fbe19610462f0f7caca2f3ae4d6c52a807f6834f5a.

Methods permitted and used for this supplement: source reading, snapshot copying, mechanical hashing, document writing, and independent static factual/artifact review. No executable QA/checker, scientific program, browser rendering, model evaluation, training, simulation, or public upload was requested or performed. There was therefore no executable-QA launch to approve.

The standalone report omits machine paths and private coordination details. The full input preservation directory contains original technical notes, which may include machine-local provenance paths, and is not an approved public upload package.
