# Supplement version 2 revisions

Version 1 and its independent reviews are preserved unchanged.

1. The source-specific designated-successor rule now explicitly converts its probability to symbol-1 probability: v if d=1, 1-v if d=0, before clipping around the empirical symbol-1 frequency. This resolves the factual review's orientation ambiguity.
2. The Hao–Orlitsky–Pichapati comparison is limited to the inspected terminal/matrix/rare-state/positive-floor content. The terminal-conditioned/time-reversed count method is now attributed explicitly to Han–Jana–Wu with exact primary links and section references.
3. Added primary-source comparisons for Paulin corrected v5 concentration, Chan–Darwiche conditional-belief oscillation, and Abraham–Gassiat–Naulet near-degenerate HMM minimax theory. All were in the frozen source audits; no new external retrieval was performed.
4. Clarified standalone definitions for the stationary symbol marginal, displayed context/successor counts, the minority posterior, clean/displayed penultimate bit, output precision, actual rational-rho bit cost, and Euler's constant in the cap tail.
5. Updated version and completion-status wording. Delivery remains contingent on both independent version-2 factual and static artifact review bindings.

The mathematical source snapshot remains 2026-11-05T07:35:13Z. Historical provenance retrieval has its separately documented later interval. No old source, old report or version-1 review is overwritten; no executable checker, rendering, scientific/model test or public upload is performed.
