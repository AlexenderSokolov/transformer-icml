# Supplement version 3 revisions

Versions 1 and 2 and all corresponding review records are retained. Version 3 changes only:

- The visible version number.
- A sentence in section 3.2 restricting the future-minority conditional expectation identity to positive minority mass m>0, with m=0 handled separately by the deterministic-majority case. This avoids conditioning on a null event and matches the source proof.
- The final status paragraph's list of corrected issues.

No theorem rate, parameter constant, resource ledger, source citation, snapshot cutoff, HTML structure or CSS changed. Final delivery requires both independent v3 factual and static artifact hash bindings. No executable QA, rendering, scientific/model execution or public upload was performed.
