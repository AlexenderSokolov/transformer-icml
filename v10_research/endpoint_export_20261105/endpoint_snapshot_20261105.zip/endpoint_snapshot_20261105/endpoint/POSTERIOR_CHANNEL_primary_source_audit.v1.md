# Primary-source audit: posterior prediction, channel uncertainty, and disclosed offline corruption

Date: 2026-11-05 UTC. This is a focused literature and interpretation supplement, not a novelty certification or a replacement for the independent mathematical reviews. No scientific program, simulation, numerical experiment, formal verification, or public write was performed. Work consisted of reading the local documents, reading primary literature through web retrieval, analytical comparison, and mechanically hashing the local inputs and this new artifact.

## Results first

1. The general mechanism “different hidden explanations, the same observed-data law, incompatible inference targets” is established prior art. The closest inspected example is Gemelos, Sigurjonsson, and Weissman, *Universal Minimax Discrete Denoising under Channel Uncertainty* (2006). Their introductory example explicitly demonstrates this obstruction under unknown memoryless noise. The posterior-prediction note should cite that connection rather than present nonidentifiability itself as new.
2. The heat-bath witness has a narrower, concrete combination of properties: one fully known clean Markov source; two unknown-index channels; identical laws of the entire observed word; at most one terminal edit; per-input endpoint reliability; and an exact minimax loss for the source-specific clean-future conditional distribution. The inspected denoising example does not establish that exact statement. This comparison is not a claim that no other source does.
3. The known-channel counterexample is a different statistical mechanism. It uses one disclosed, sample-adaptive offline channel and two nearby, horizon-dependent sources. Their observation laws overlap but are not equal. Its lower bound is a uniform finite-horizon minimax statement, not exact nonidentifiability, a fixed-model inconsistency theorem, or a contradiction to structured HMM filter robustness.
4. Known-channel universal denoising and standard HMM identifiability do not imply a positive result for every known history-to-history channel. Their observation assumptions are substantive. Conversely, neither local construction proves failure for ordinary known memoryless HMM emissions.
5. The target, disclosure interface, and horizon quantifiers are as important as the edit budget. Keep the future-blind joint factorization, the fixed-true-model posterior target, the distinction between revealed algorithm and revealed randomness, and the distinction between per-input and source-averaged guarantees explicit.

## 1. Local scope and relation to the earlier audit

The complete versions of the following were read:

- `POSTERIOR_PREDICTION_channel_identifiability.md`.
- `KNOWN_CHANNEL_posterior_counterexample.md`.
- Their respective independent analytical review files.
- The earlier `EPR001_primary_source_prior_art_audit.v1.md`, with particular attention to its target/Jensen/quantifier discussion and previously inspected robust filtering and batch-attack sources.

The prior audit already covers clean Markov prediction, Huber contamination, transition-matrix robust inference, stochastic perturbations of variable-memory chains, distributionally robust Kalman filtering, adversarial Kalman observations, and batch attacks on HMM decoders. Those summaries are not reproduced here. In particular, the existing Caballero et al. batch-attack comparison remains relevant, but an attack against a specified decoder is not automatically an all-estimator minimax lower bound.

This audit does not independently re-prove the inherited SC002/SC003/BT002 statistical and protected-corruption interfaces. The earlier dependency caveats remain in force. The two new independent review files report scoped analytical PASS; that is distinct from this literature assessment.

## 2. Exact comparison of the two new experiments

### 2.1 Unknown channel, fully known source: exact observational equivalence

In the heat-bath subexperiment, fix the complete stationary source law T. Disclose both candidate channel algorithms C0 and C1, but do not disclose their realized index. For each fixed model, the target is its actual conditional law

    p_i(z) = Law_(T,C_i)(X_(N+1) | Z=z).

It is not a posterior averaged over an artificial prior on the channel index. The prior used to average two risks is a lower-bound device only.

The construction establishes exactly

    P_(T,C0)^Z = P_(T,C1)^Z,
    E TV(p_0(Z),p_1(Z)) = rho alpha(1-4alpha^2),

and therefore exact two-channel minimax risk rho alpha(1-4alpha^2)/2, attained by the midpoint. This is stronger than merely making testing difficult at one sample size: repeated independent, unlabeled, same-horizon corrupted histories retain identical laws under the two fixed channel hypotheses. That statement does not concern a projectively consistent infinite corrupted stream or histories with observed clean-future labels.

The law-preserving step is ordinary conditional resampling: redraw a coordinate from its conditional law given the retained coordinates. The specialized content is how that operation is paired with the unmodified physical next-state generation and strict terminal-edit constraints. The clean future depends on the original terminal symbol, not its displayed replacement.

Revealing the actual channel index destroys this particular lower-bound comparison. Revealing both algorithms does not. The same known source in both hypotheses also distinguishes this witness from a source/channel ambiguity example that changes both components.

### 2.2 Known channel, unknown source: overlapping experiments

The second note instead gives, for every admissible horizon M, a disclosed channel C_M and two sources theta_(M,+), theta_(M,-), with

    max-row-TV(theta_(M,+),theta_(M,-)) = 2/sqrt(M).

The channel reads the entire clean count block, normalizes it, and uses the hidden count sign to scramble the terminal V symbol. Its algorithm does not depend on the unknown source index. Nevertheless, the realized changes depend on the sample. “Fixed algorithm” or “source-independent kernel” must not be equated with a sample-oblivious corruption rule.

Here the correct lower-bound inequality is

    R_+(q)+R_-(q)
      >= integral min(dP_+^Z,dP_-^Z) TV(p_+(Z),p_-(Z)).

Unlike the heat-bath proof, the observed measures are not identical. The retained final U symbol already has different distributions. On the marker branch, the normalized U block and retained V prefix have common distributions, while terminal factors require the explicit overlap estimate. There is no valid reduction that simply discards those terminal factors and calls the whole output law identical.

Channel disclosure reveals the stochastic kernel, not its realized trigger, edit mask, hidden count, or scrambling bit A. Revealing A would allow W to be unscrambled and would change the experiment. This is an observation interface issue, not a computational restriction.

The current lower applies to K>=5, even M>=64, ceil(4sqrt(M))+2<=k<=M, a reserved marker outside stationary support, and offline corruption. Its sources have a positive floor on the four generated symbols, not full support over all K symbols. It does not establish the same lower for k=1, k=o(sqrt(M)), K<5, causal attacks, identity channels, or every known channel.

### 2.3 Why nearby transition tables do not contradict continuity

The known-channel pair varies with M. A local parameter difference of order M^(-1/2), repeated across M independent U bits, need not give a vanishing distance between full path experiments. Their count means differ at order sqrt(M), the same order as count fluctuations. The construction hides a statistic that remains informative at that scale.

For comparison, an elementary finite-alphabet conditional-TV inequality is

    E_(P^Z) TV(P(Y|Z),Q(Y|Z))
       <= TV(P^(Z,Y),Q^(Z,Y)) + TV(P^Z,Q^Z)
       <= 2 TV(P^(Z,Y),Q^(Z,Y)).

This follows by inserting Q's conditional law with P's observation marginal and using the triangle inequality; assign any version on Q-null outputs. For one common channel, data processing also bounds the joint output-and-future TV by the clean path-and-future TV. Neither statement converts maximum-row parameter distance alone into a uniform-in-horizon conclusion for arbitrary channels.

Thus the counterexample rules out a blanket uniform posterior guarantee derived solely from accurate transition-table estimation. It does not say that exact knowledge of the complete source law and channel is insufficient, or that one fixed regular HMM is inconsistent as its observation horizon grows.

## 3. Nearest primary literature

### A. Unknown-channel universal denoising: the closest explicit indistinguishability precedent

George Gemelos, Styrmir Sigurjonsson, and Tsachy Weissman, *Universal Minimax Discrete Denoising under Channel Uncertainty*, IEEE Transactions on Information Theory 52(8), 3476-3497, 2006.

Primary URLs:

- https://arxiv.org/pdf/cs/0504060
- https://web.stanford.edu/~tsachy/pdf_files/Universal%20Minimax%20Discrete%20Denoising%20under%20Channel%20Uncertainty.pdf

Inspected: abstract and introductory model/example, including the definition of an invertible DMC as full row rank. The example compares an all-zero source through a binary symmetric channel with a Bernoulli source through identity. The full noisy process law agrees, but appropriate reconstructions disagree; knowing output statistics completely does not resolve the ambiguity. Their criterion is denoising under single-letter loss and channel uncertainty. Both source and channel vary in that example. It does not itself give the local note's same-known-source, strict one-edit, clean-future posterior-prediction statement. It is nevertheless direct prior art for the general identifiability obstruction and minimax response to it.

### B. Known-channel universal denoising: useful positive boundary

Tsachy Weissman, Erik Ordentlich, Gadiel Seroussi, Sergio Verdu, and Marcelo J. Weinberger, *Universal Discrete Denoising: Known Channel*, IEEE Transactions on Information Theory 51(1), 5-28, 2005.

Primary URL:

- https://web.stanford.edu/~tsachy/pdf_files/Universal%20Discrete%20Denoising%20Known%20Channel.pdf

Inspected: introductory assumptions, framework, and relevant guarantee statements. The known observation mechanism is a discrete memoryless channel with the required invertibility/rank condition. The guarantees concern average single-letter denoising performance, including stochastic stationary-source and individual-sequence formulations. They do not assert terminal-only posterior prediction guarantees under every disclosed, nonlocal history channel. In particular, the count-normalization kernel is not the known DMC appearing in the theorem. Also distinguish optimal denoising risk from zero estimation loss for an exactly known conditional probability distribution: the former can remain positive even when that distribution is known.

### C. Finite-state HMM identifiability: assumptions exclude the proposed channel interfaces

Elisabeth Gassiat, Alice Cleynen, and Stephane Robin, *Finite state space non parametric Hidden Markov Models are in general identifiable*, arXiv:1306.4657, original posting 2013.

Primary URL:

- https://arxiv.org/pdf/1306.4657

Inspected: model definition and Theorem 2.1. Given a stationary hidden Markov chain of known finite size, observations are conditionally independent given the hidden sequence and their emission distributions depend only on the current hidden state. Full-rank transition matrix and linearly independent emission laws give identification from three consecutive observations, up to hidden-state relabeling. The two local channels are not that fixed stationary, current-state-only emission model. A broader augmented or time-inhomogeneous hidden representation may be possible; it would still need all theorem hypotheses checked. Ordinary label swapping is also not the heat-bath obstruction, which keeps the source and clean-symbol labels fixed.

### D. Unknown noise can still be identifiable under structural restrictions

Elisabeth Gassiat, Sylvain Le Corff, and Luc Lehericy, *Identifiability and Consistent Estimation of Nonparametric Translation Hidden Markov Models with General State Space*, Journal of Machine Learning Research 21(115), 1-40, 2020.

Primary URL:

- https://www.jmlr.org/papers/volume21/19-802/19-802.pdf

Inspected: model, Theorem 1, and surrounding assumption discussion. Observations are latent states plus IID additive noise independent of the latent sequence. Under the stated latent tail and dependence conditions, both signal and noise can be identified up to translation, without specifying the noise distribution. This is a useful caution against saying “an unknown observation channel always causes nonidentifiability.” The local lower uses a broader history-dependent channel class and a particular admissible ambiguous pair. Conversely, the positive theorem does not allow arbitrary count-dependent, horizon-specific offline edits.

### E. Filter robustness: continuity requires observation structure

Pavel Chigansky and Ramon van Handel, *Model robustness of finite state nonlinear filtering over the infinite time horizon*, Annals of Applied Probability 17(2), 688-715, 2007.

Primary URL:

- https://arxiv.org/pdf/math/0604295

Inspected: introduction, model, and Theorem 1.1. A continuous-time finite-state Markov signal is observed in independent white noise; mixing/positivity assumptions yield robustness to parameter misspecification uniformly in time. The proof framework uses local filtering dynamics and forgetting. These assumptions do not cover a disclosed arbitrary block channel that carries a long-history statistic into the last observation. The paper also explicitly separates fixed-time continuity from uniform-time robustness. It therefore supplies an appropriate comparison, not a contradiction to the horizon-indexed local counterexample.

### F. Adaptive versus oblivious robust statistics: do not identify different quantifiers

Clément L. Canonne, Samuel B. Hopkins, Jerry Li, Allen Liu, and Shyam Narayanan, *The Full Landscape of Robust Mean Testing: Sharp Separations between Oblivious and Adaptive Contamination*, FOCS 2023; arXiv:2307.10273.

Primary URL:

- https://arxiv.org/pdf/2307.10273

Inspected: abstract, introductory models, and main separation statements. In their IID mean-testing problem, adaptive replacement can inspect the sample, whereas an oblivious replacement chooses its positions and replacement values without seeing it. Their results separate sample complexities. This supports keeping the sample-adaptation distinction explicit; it does not transfer their numerical rates to dependent-path terminal prediction.

Guy Blanc and Gregory Valiant, *Adaptive and oblivious statistical adversaries are equivalent*, STOC 2025; arXiv:2410.13548, version 2.

Primary URL:

- https://arxiv.org/html/2410.13548v2

Inspected: introductory setup, formal definitions, and the main reduction. The equivalence allows polynomially increased IID sample size and uses subsampling. It is not equality of risks at the same horizon. It does not make a fixed algorithm that reads the entire path sample-oblivious, nor remove dependence and terminal-target issues in the local construction. The two cited robust-statistics results have compatible scopes: polynomial equivalence does not exclude sharp same-scale sample-complexity separations.

## 4. Quantifier, target, and channel checklist

### Target and future coupling

For a fixed true specification, the intended joint law is

    P_(theta,mu)(x) C(z|x) theta_(S(x))(y).

This is stronger than providing only a marginal history kernel C(z|x): its seed must not share future innovations. It implies the clean-future posterior target

    p_(theta,mu,C)(Z) = E[theta_(S(X)) | Z].

Do not replace that with theta_(S(Z)), the random hidden row theta_(S(X)), or a prior mixture over unknown source/channel hypotheses. Neither file is predicting a future corrupted observation under a stationary observation mechanism.

Conditional Jensen transfers the EPR001 hidden-row upper, not its endpoint lower. Protected terminal pairs restore equality of the relevant row and predictive targets and can transfer corresponding lower bounds. With complete source law and channel known, p itself has zero distribution-estimation loss, without asserting zero next-symbol classification error or efficient evaluation.

### Per-input bounds and averaging

The reliability condition is Pr_C(endpoint changes | X=x)<=rho for every input x, and the Hamming budget holds for every channel realization. Neither is merely an expected fraction of substitutions under the witness source. Independent Bernoulli symbol-noise models generally do not automatically obey a deterministic strict total edit cap.

Nor does the per-input condition imply Pr(endpoint changes | Z=z)<=rho for every displayed z. The known-table upper in the posterior note correctly averages that posterior event probability over Z. The distinction survives channel disclosure and is not altered by a source's mixing assumption.

### Disclosure and source independence

The unknown-channel lower hides the channel index while revealing one source and both algorithms. The known-channel lower reveals one algorithm while hiding the source index. These are not interchangeable minimax experiments.

A kernel can inspect the full sample without receiving the unknown source index. Conversely, writing a source argument out of a kernel signature alone would not establish a common algorithm across hypotheses. The constructions here explicitly exhibit the common algorithm required by their respective comparisons. The heat-bath constants depend on public beta; the count-normalization channel depends on public M and rho, not on the source parameters.

### Exact identification versus estimation difficulty

The heat-bath pair has exact observational equivalence for each fixed-horizon experiment. The known-channel pair only needs positive overlap. Extra independent histories from the known-channel pair can contain distinguishing information, so the same “unlimited unlabeled observations cannot help” conclusion is not available there.

Identifiability is a property of a model class and its observation map, not automatically a guarantee of favorable finite-sample rates. Conversely, a finite-horizon minimax lower under local alternatives does not by itself prove failure of pointwise asymptotic consistency.

## 5. Recommended positioning

Suggested concise research wording:

> Unknown-channel denoising already exhibits observational ambiguity between hidden explanations. Here we give a same-source terminal-resampling construction that preserves the entire observed history law while separating the actual clean-future conditional distributions under a strict one-edit budget. Separately, a disclosed offline channel can preserve a posterior-prediction lower bound by concealing a sample-dependent statistic; that construction is a horizon-indexed two-source overlap argument, not exact observational nonidentifiability.

Avoid claims that the general nonidentifiability mechanism, conditional resampling, two-point minimax comparison, or the need to distinguish denoising from prediction is new. Avoid saying all known channels remove the endpoint term, all unknown channels cause it, or parameter consistency automatically entails uniform posterior consistency through arbitrary offline channels. The inspected sources neither certify novelty nor invalidate the two narrowly stated local constructions.

## 6. Provenance and limits

Current input bytes were read and mechanically hashed during this audit. These are present-time bindings, not claims about earlier historical state:

- `POSTERIOR_PREDICTION_channel_identifiability.md`: `ae34d4c79371995cce91e328989a078b874741dd8976b8602f19b0d500db3675`.
- `KNOWN_CHANNEL_posterior_counterexample.md`: `0d4ab89cc49a0ada2adeb18d73dfec9984775376411c3f05c6637075212d9fb9`.
- `POSTERIOR_PREDICTION_independent_review.v1.md`: `e3757ac5be5f354e8dfa4f3f02ea0d7013141bd3a0173a9340fc48ad2f55bfd3`.
- `KNOWN_CHANNEL_independent_review.v1.md`: `24b6d68fb87cf628efd7b495eb6937733e19841839acb1b9c91bedac9a1f4de7`.
- `EPR001_primary_source_prior_art_audit.v1.md`: `1a2c6c45fc212795064585bd4484226185d79e5ea20fe271e27d9169398d70d4`.

The evidence is the portions of the primary sources described above, not an exhaustive review of every cited proof or all related literature. Search discovery alone was not treated as theorem verification. Scanned Geman-Geman and Donoho-Liu documents encountered during discovery were not relied on for detailed claims because usable text was not inspected. Secondary summaries were not used as authority. Some retrieved arXiv PDF title pages display a later automatic typesetting date; original arXiv posting/journal metadata, rather than that display alone, supplies the bibliographic date.

This is analytical literature work. No executable scientific checks were run, no local theorem file was changed, and no repository or other public service was written to.
