# A fixed-positive-floor protected lower with one base state

5 November 2026 UTC. Pure analytical candidate, pending separate independent proof review. No scientific executable checks, numerical experiments, public writes, efficiency claims, or novelty claims. This is an independent protected-budget witness, not an import of a rare-transition witness. Existing source files are unchanged.

## 1. Claim and quantifiers

Let M>=1 be an integer, N=M+2, and 1<=k<=M an integer. In the time-indexed channel class with one base state and a separately paid actual edit counter, the expected absolute-error risk for the source-specific clean next-bit posterior obeys

    R >= (5/3072) k/M.

The witness protects both final raw coordinates exactly, and therefore satisfies endpoint budget rho=0 and every allowed rho>=0. Both binary transition probabilities in every source row are at least 1/4. Consequently the result applies to a source class requiring transition floor eta whenever 0<=eta<=1/4. The sources satisfy D2(beta) for every 0<beta<=1. Constants here are absolute.

The displayed constant and construction do not assert a result for every eta in (1/4,1/2). At eta=1/2, a binary transition row with both probabilities at least eta must be exactly (1/2,1/2). Every source in that class is iid fair, its clean next bit is independent of any causal channel output, and the constant predictor 1/2 has zero risk. Thus a positive k/M lower cannot extend to that degenerate floor.

The meaning of one state is one base state, not one total finite-state-channel state or constant total memory. The actual counter has k+1 possible values, and public time indexes the rows. The theorem is statistical; it makes no description-optimality, computational-efficiency, sharp S=1 profile, state-minimality, or novelty claim.

## 2. Iid source pair for k>=2

Put

    h=k-1,   epsilon=h/(16M),
    p_plus=1/3,   p_minus=(1-epsilon)/3,
    Delta=p_plus-p_minus=h/(48M).

Use stationary iid Bernoulli sources with these success probabilities. Here 0<epsilon<=1/16, so p_minus>=5/16 and p_plus=1/3. Both success and failure probabilities are at least 1/4. All displayed probabilities are rational.

Viewed as order-two sources, set theta_p(uv)(1)=p for every pair uv. The pair-chain two-step transition probability from any pair to (y,z) equals Ber_p(y)Ber_p(z), its stationary probability. Thus the all-state D2(beta) minorization holds even for beta=1.

## 3. Exact common channel

There is one base state. Let e in {0,...,k} denote the number of actual changes already made, with initialization e=0. The following table specifies the output distribution and counter update at every time, input symbol and counter value.

1. At i=1 and e<k, output z_i=0. Increment e if and only if x_i=1. At i=1 and e=k, output z_i=x_i and leave e unchanged.
2. At candidate times i in {2,...,N-2}, if x_i=1 and 1<=e<k, output zero with probability epsilon and increment e by one, or output one with probability 1-epsilon and leave e unchanged. In every other candidate row output x_i and leave e unchanged.
3. At i=N-1,N, output x_i and leave e unchanged, for every e.

There are n=N-3=M-1 candidates. Every row is normalized and rational. Exhausted-counter rows always pass their input. Coins in different candidate rows are independent auxiliary randomness. This kernel uses only M,k, public time, the current raw symbol, and the actual counter. In particular it is identical for both sources and does not use the unknown success probability.

At the actual initialization, Z_1=0 and the counter after position 1 is exactly X_1. If X_1=0, the counter stays zero and every later input is passed. If X_1=1, the initial change costs one edit and at most h further changes can occur. Every raw word and every coin realization therefore incur at most k changes. The last two coordinates always satisfy (Z_(N-1),Z_N)=(X_(N-1),X_N), giving endpoint-change probability zero on every fixed raw word. The channel is current-symbol causal and future blind.

## 4. Selected branches and uncapped comparison

Let A_plus be the output law under source p_plus conditional on X_1=1. Let A_minus be the output law under source p_minus conditional on X_1=0. Both display Z_1=0. Iid independence makes all later raw bits independent of X_1 under each fixed source.

Define A_plus_uncapped only as a comparison experiment: conditional on X_1=1, independently erase each candidate one with probability epsilon without stopping at h erasures; still pass the last two bits. Its displayed candidate vector consists of independent Bernoulli variables with success probability

    (1-epsilon)p_plus=p_minus.

This is exactly the candidate-vector law under A_minus. In both comparison branches the final two raw bits are independent of the candidate vector. They have product success probabilities p_plus under A_plus_uncapped and p_minus under A_minus.

The physical channel does not use the uncapped experiment. No conditioning of that experiment on its erasure count is used.

## 5. Exact-cap coupling and overlap

Use the same raw candidates and independent proposal coins to couple A_plus and A_plus_uncapped. Let D count proposed erasures in the uncapped experiment. It is a sum of n independent Bernoulli variables with mean

    mu=n p_plus epsilon=(M-1)h/(48M)<=h/48.

The capped channel takes the first h proposals and then passes remaining candidates. If D<=h, the two complete output words agree. Therefore, using half-L1 total variation and Markov's inequality,

    TV(A_plus,A_plus_uncapped)
      <=P(D>h)<=E D/h<=1/48.

This applies even for h=1. It is unnecessary to claim the capped output is a product law.

Coupling each of the two protected Bernoulli bits between success probabilities p_plus and p_minus gives

    TV(A_plus_uncapped,A_minus)<=2 Delta<=1/24.

Consequently

    TV(A_plus,A_minus)<=1/16,
    sum_z min{A_plus(z),A_minus(z)}>=15/16.

Let P_plus^Z,P_minus^Z be the full output laws. The selected plus branch has mass p_plus=1/3; the selected minus branch has mass 1-p_minus>=2/3. Pointwise,

    P_plus^Z(z)>=p_plus A_plus(z),
    P_minus^Z(z)>=(1-p_minus) A_minus(z).

Since min{a f,b g}>=min{a,b} min{f,g} for nonnegative numbers,

    sum_z min{P_plus^Z(z),P_minus^Z(z)}>=5/16.

This argument does not assume equal mixture weights or a source-independent mode prior. The physical mode X_1 has source-dependent law, and only constant lower bounds on the two selected branch weights are used.

## 6. Source-specific posterior targets and risk

For each iid source p, X_(N+1) is independent of the raw history X_1,...,X_N and of the channel coins. Therefore

    P_p(X_(N+1)=1 | Z=z)=p

on the support of the observation law. The target is constant under each source despite the dependence introduced among displayed coordinates by the cap.

For any predictor Q using the displayed word and the disclosed common channel, the pointwise triangle inequality gives

    R_plus(Q)+R_minus(Q)
      >= Delta sum_z min{P_plus^Z(z),P_minus^Z(z)}.

If Q is randomized, average that pointwise inequality over its conditional randomization. Hence

    max{R_plus(Q),R_minus(Q)}
      >=(Delta/2)(5/16)
      =5h/(1536M)
      >=5k/(3072M),

where the last inequality uses k>=2. Taking the infimum over predictors preserves the bound. One common disclosed channel is used for both source alternatives.

## 7. The k=1 case is absorbed by a clean witness

Use the identity channel, which is admissible with one base state, any positive budget, and endpoint budget zero. Take iid sources

    p_0=1/3,   p_1=1/3+1/(16 sqrt(N)),
    d=p_1-p_0.

These sources also have transition floor at least 1/4 and D2(beta) even for beta=1. Rationality of source probabilities is not required; only the disclosed channel rows require rationality. The identity channel has rational rows.

The Bernoulli KL bound KL(Ber(q)||Ber(p))<= (q-p)^2/[p(1-p)] and independence yield

    KL(P_1^N||P_0^N)<=N d^2/[p_0(1-p_0)]=9/512.

Pinsker's inequality gives TV(P_1^N,P_0^N)<=3/32. Applying the preceding two-source absolute-loss inequality to the constant next-bit targets gives

    max{R_0(Q),R_1(Q)}>=29/(1024 sqrt(N)).

For M>=1, N=M+2<=3M^2. Thus this clean lower is at least 29/(1024 sqrt(3) M), which is greater than 5/(3072M). This proves the claimed k/M bound also for k=1.

## 8. Scope of the repair

This construction independently supplies the protected-budget term with a uniform positive transition floor. It removes any need to infer that floor property from a broader-class protected witness. It does not alter the separate endpoint candidate or close its sub-square-root-budget S=1 upper/lower gap. The lower is available at rho=0; the iid prediction target remains independent of the channel output within each source. No external theorem about posterior instability or nonidentifiability is needed for the branch-overlap argument.
