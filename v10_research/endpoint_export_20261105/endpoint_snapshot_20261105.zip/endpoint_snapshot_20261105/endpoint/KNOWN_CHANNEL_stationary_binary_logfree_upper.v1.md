# Stationary binary known channel prediction without a logarithmic loss

Date: 2026-11-05 UTC. Pure analytical proof candidate. No executable scientific check, public upload, novelty certification, or efficient-computation claim. The new ingredient is an exponential-moment argument conditional on the future minority symbol, with a data-dependent floor in the fitted transitions. This note is intended for independent mathematical review.

## 1 Claim and scope

Fix beta in (0,1), M>=64, N=M+2, and integer 1<=k<=M. For every disclosed source-independent future-blind channel C satisfying d_H(x,z)<=k on every realization, there is a source-independent statistical predictor q_C such that

    sup_{stationary theta in D2(beta)}
      E_theta,C |q_C(Z)-P_theta,C(X_(N+1)=1 | Z)|
        <= C_beta min{1, ((k+1)^2/M)^(1/3)}.              (L1)

The channel may inspect all N observed symbols and randomize. The estimator is allowed to sum over all clean preimages. No transition floor is assumed for the source; a floor is introduced only inside the estimator. The result is uniform over endpoint-reliability constraints rho and does not establish a rho-dependent interpolation. At k=0 use the separately established clean M^(-1/2) estimator rather than (L1).

Here D2(beta) is the binary homogeneous second-order source class with stationary pair law Pi and all-state pair-kernel certificate P^2(u,v)>=beta Pi(v). Write pi for the stationary one-symbol law and m=min{pi(0),pi(1)}. The certificate implies

    theta_u(c)>=beta pi(c),
    Pi(a,b)>=beta pi(a)pi(b),
    Pi(u)>=beta m^2,
    Pi(u)theta_u(c)>=beta^2 m^3.                       (L2)

The first inequality follows by summing the certificate over the second coordinate of the destination pair. The second follows from stationarity and the first. If m>0, all pair and triple probabilities are positive.

## 2 A log-free count bound including endpoint conditioning

### 2.1 Uniform-start regenerative concentration

Let K have stationary law Lambda and satisfy K(y,.)>=beta Lambda(.) on its support. For any initial law, any indicator f with p=Lambda(f), any n>=1, and t>=1,

    P{|sum_(i=1)^n f(Y_i)-np|
        >B_beta [sqrt(np t)+t]} <= B_beta exp(-t).     (L3)

First start from Lambda. Write K=beta Lambda+(1-beta)Q, where Q preserves Lambda. Regenerate from Lambda after independent geometric cycle lengths L. A complete cycle has centered reward

    W=sum_(i=1)^L f(Y_i)-pL.

The length is independent of the Q trajectory, all its one-time marginals are Lambda, and, for j>=2,

    E W=0,
    E|W|^j <= 2^j p E L^j <= p j! B_beta^j.

Consequently the complete-cycle reward has a Bernstein moment generating function with variance scale proportional to p. Stop the complete-cycle exponential supermartingale at the first cycle whose cumulative length reaches n. This is a stopping time bounded by n, so the completed-cycle sum has tails B_beta[sqrt(np t)+t].

The terminal cycle must not be bounded by a maximum over n cycles. At the fixed time n, its backward age A and remaining forward length R satisfy

    P(A>=ell)<= (1-beta)^(ell-1),
    P(R>=ell)<= (1-beta)^(ell-1)

up to an irrelevant shift by one. Indeed A>=ell requires no refresh among the previous ell-1 boundaries, and R>=ell requires no refresh among the next ell-1 boundaries. The terminal cycle length is at most A+R. Thus it has an exponential tail independent of n. The difference between the stopped complete-cycle centered sum and the first-n centered count is bounded by this length. This proves (L3) for stationary start, without log n.

For arbitrary start, the block before the first refresh has geometric length and absolute centered reward at most its length. Conditional on that length, the remaining horizon starts independently from Lambda and is no longer than n. Apply the stationary bound uniformly over the remaining deterministic horizon, and add the initial geometric tail. This proves (L3) as stated. The beta=1 case, though not needed for the fixed-beta lower comparison, reduces to a possible initial state followed by independent Lambda draws.

The following two consequences will be used. Write V=sum f and v=np. Constants below depend only on beta:

    E(V-v)^2 <= C_beta(v+1).                         (L4)

For v>=1 and 0<=lambda<=c_beta/sqrt(v),

    E exp(lambda |V-v|) <= 1+C_beta lambda sqrt(v).  (L5)

For (L5), choose c_beta sufficiently small. The tail in (L3) is bounded by C_beta exp[-c_beta min{x^2/v,x}] for all x>=0 after increasing the leading constant. Integrating

    E exp(lambda |V-v|)-1
      =lambda integral_0^infinity exp(lambda x)P(|V-v|>x) dx

and completing the square on the sub-Gaussian portion proves (L5). The sub-exponential portion is integrable because lambda<=c_beta/sqrt(v)<=c_beta. This derivation also proves (L4).

### 2.2 Conditioning on the future minority costs no factor 1/m

Set H_i=(X_i,X_(i+1),X_(i+2)). Its stationary law is

    Lambda(a,b,c)=Pi(a,b)theta_(a,b)(c).

Its transition kernel T satisfies

    T^3(h,(a,b,c))
      =P^2(last_pair(h),(a,b))theta_(a,b)(c)
      >=beta Lambda(a,b,c).                         (L6)

On positive stationary support, the reversed triple kernel satisfies

    (T_rev)^3(h,g)
      =Lambda(g)T^3(g,h)/Lambda(h)
      >=beta Lambda(g).                             (L7)

Condition on X_(N+1)=c, where pi(c)>0. Starting from H_(M+1)=(X_(N-1),X_N,X_(N+1)), this changes only the initial distribution of the reversed stationary triple chain. Its backward transition kernel remains T_rev. The training triples H_M,...,H_1 are therefore a length-M portion of an arbitrarily initialized reversed chain. Split them into three residue classes. Each subsequence has kernel (T_rev)^3 and arbitrary initial law. Apply (L3) to each and sum, with a fixed three-event union bound. The same (L3)-(L5), with enlarged beta-dependent constants, hold under the conditional law given X_(N+1)=c for every training triple count, context count, or generated-symbol count. They also hold unconditionally. No division by pi(c), burn-in logarithm, or assumed independence of the endpoint and counts is used.

## 3 The estimator and elementary exceptional events

Let J_u and C_(u,c) be the M clean pair-context and pair-successor counts. Their means are

    w_u=M Pi(u),
    v_(u,c)=M Pi(u)theta_u(c).

The displayed counts J'_u and C'_(u,c) satisfy pathwise

    |J'_u-J_u|<=2k,
    |C'_(u,c)-C_(u,c)|<=3k.                        (L8)

Define b'=M^(-1)sum_(t=3)^N Z_t and m'=min{b',1-b'}. Then the displayed frequency differs from the clean frequency by at most k/M, even for a history-adaptive channel.

Set

    a0=((k+1)^2/M)^(1/3),
    a=A_beta a0,

where A_beta is a sufficiently large fixed constant. If a>1/16, any predictor has loss at most 1<=16 A_beta a0, so only a<=1/16 needs consideration.

If m'<=2a, predict the displayed empirical majority deterministically. Otherwise form

    f=beta m'/4,
    theta_tilde_u(1)=(C'_(u,1)+1)/(J'_u+2),
    theta_bar_u(1)=projection of theta_tilde_u(1) onto [f,1-f],
    theta_bar_u(0)=1-theta_bar_u(1),
    Pi_bar(u)=(J'_u+1)/(M+4).                      (L9)

Projection can equivalently be described coordinatewise for both binary coordinates. These are positive probability vectors whenever the posterior branch is used. The fitted initial law Pi_bar need not be stationary for theta_bar. Given z, use this positive fitted clean-word law and the disclosed channel C(z|x) to form the fitted posterior over x. Predict by averaging theta_bar at the latent clean terminal pair.

For analysis when m>=a, let E be the event

    |b'-pi(1)|<=m/2,
    |J_u-w_u|<=w_u/4 for every u.                  (L10)

All statements about this event hold uniformly over channels. By (L2), M m^3>=A_beta^3(k+1)^2. Increasing A_beta ensures

    k/M<=m/4,
    (2k+2)/w_u<=1/4,
    v_(u,c)>=B_beta(k+1)^2,                        (L11)

where B_beta may be any fixed sufficiently large constant needed below. Apply (L4), the deterministic edit bounds, and Chebyshev's inequality. Since w_u>=beta M m^2 and M m^2 is bounded below by a sufficiently large constant,

    P(E^c)<=C_beta/(M m^2).                       (L12)

The symbol term is at most C_beta/(M m), which is smaller. This bound is unconditional and incurs unit loss only on context/marginal failures, not on rare triple failures.

On E, m/2<=m'<=3m/2. Hence

    beta m/8<=f<=3 beta m/8,
    theta_u(c)>=beta m>2f.                       (L13)

The true Bernoulli parameter lies inside [f,1-f], so projection can only decrease the absolute log ratio relative to the true coordinate.

## 4 Exponential moments of fitted log ratios

Fix a coordinate (u,c), and abbreviate

    theta=theta_u(c), w=M Pi(u), v=w theta,
    r=theta/m>=beta,
    S=|log(theta_bar_u(c)/theta)|.

All expectations in this section can be either unconditional or conditional on X_(N+1)=c_* for a true minority c_*. The bounds from Section 2 hold under both laws. All displayed-count inequalities are pathwise and therefore survive arbitrary channel randomization.

We prove, for every 1<=ell<=256(k+1), after choosing A_beta sufficiently large,

    E[(exp(ell S)-1)1_E]
      <=C_beta [ell/sqrt(v)+ell(k+1)/v].           (L14)

### 4.1 Ordinary numerator event

On E, D=(J'_u+2)/w lies between 1/2 and 3/2. If C'_(u,c)+1>=v/2, both the denominator and numerator are bounded away from zero on their natural scales. Since projection decreases absolute log ratios,

    S<=2(|C_(u,c)-v|+3k+1)/v
        +2(|J_u-w|+2k+2)/w =: U.                 (L15)

Use (L5) for the two counts, Holder's inequality, and w>=v. Because v>=B_beta(k+1)^2, ell/sqrt(v) and ell(k+1)/v can be made sufficiently small for the fixed coefficient range ell<=256(k+1). This gives

    E exp(ell U)-1
      <=C_beta [ell/sqrt(v)+ell(k+1)/v].          (L16)

There is no conditioning of a martingale law on E here. The count moment bounds are unconditional under whichever one of the two laws was selected, and the deterministic inequality is simply restricted to E.

### 4.2 Small numerator event

If C'_(u,c)+1<v/2 while E holds, the raw fitted coordinate is less than theta, because D>=1/2. Projection still leaves the coordinate at most theta and at least f. Thus

    S<=log(theta/f)<=log(8r/beta).                (L17)

By (L8) and v>=B_beta(k+1)^2, this event implies C_(u,c)-v<=-v/4. Equation (L3) gives its probability at most C_beta exp(-c_beta v). Crucially, use its own coordinate mean, not the worst-coordinate minimum:

    v=M Pi(u)theta >= beta(M m^3)r.              (L18)

For r>=beta, log(8r/beta)<=H_beta r with finite H_beta. Since M m^3>=A_beta^3(k+1)^2 and ell<=256(k+1), sufficiently large A_beta gives

    (8r/beta)^ell exp(-c_beta v)
      <=exp(-c_beta v/2).                       (L19)

The last quantity is at most C_beta ell/sqrt(v). Equations (L15)-(L19) prove (L14). The full exponential moment on this small-numerator event is what replaces a polynomially small global failure probability. A bound using only v>=beta^2 M m^3 and theta/f<=C/m would not prove this step.

### 4.3 Initial-law ratios

Let D_u=|log(Pi_bar(u)/Pi(u))|. On E,

    D_u<=2(|J_u-w_u|+2k+1)/w_u+4/M.

The same moment argument gives, for 1<=ell<=256(k+1),

    E[(exp(ell D_u)-1)1_E]
      <=C_beta [ell/sqrt(w_u)+ell(k+1)/w_u].     (L20)

## 5 The endpoint-conditioned posterior comparison

Fix a displayed z and fit Pi_bar and theta_bar from that z. For any two clean preimages x,y with C(z|x)C(z|y)>0, d_H(x,y)<=2k. At most 6k historical triple positions differ. With

    S_max=max_(u,c)|log(theta_bar_u(c)/theta_u(c))|,
    D_max=max_u |log(Pi_bar(u)/Pi(u))|,

the oscillation of log(P_bar_z(x)/P_theta(x)) over the posterior support is at most

    L=12k S_max+2D_max.                         (L21)

The channel factors cancel in posterior ratios. Therefore the normalized fitted-to-true posterior density is between exp(-L) and exp(L). Let

    p(z)=P_theta,C(X_(N+1)=c_* | Z=z),

where c_* is a true minority. Future blindness gives p(z) as the true posterior average of theta_(S(x))(c_*). The fitted coordinate is within exp(+-S_max) of that coordinate. Consequently the fitted prediction q(z) obeys the pointwise inequality

    |q(z)(c_*)-p(z)|
      <=p(z)[exp((12k+1)S_max+2D_max)-1].       (L22)

No small-log event or pointwise upper bound on p(z) is assumed. In particular, conditioning the posterior can make the minority next-symbol probability large on selected outputs; (L22) still applies.

Let S_i^E=S_i 1_E for the eight transition coordinates and D_j^E=D_j 1_E for the four pair coordinates. Set

    delta_m=(k+1)/sqrt(M m^3)+(k+1)^2/(M m^3).

By (L2), (L14), and (L20), each of the twelve moment factors needed for Holder satisfies

    E[exp(12(12k+1)S_i^E) | X_(N+1)=c_*]
      <=1+C_beta delta_m,
    E[exp(24D_j^E) | X_(N+1)=c_*]
      <=1+C_beta delta_m.                       (L23)

Indeed 12(12k+1)<=156(k+1)<256(k+1). Use max<=sum and Holder with twelve factors to obtain

    E{[exp((12k+1)S_max+2D_max)-1]1_E
           | X_(N+1)=c_*} <=C_beta delta_m.      (L24)

At this step the expectation is over the actual joint source/channel law. E may depend on clean counts and the displayed word. A subtlety is essential: the equality E[p(Z)F(Z)]=m E[F(Z)|X_(N+1)=c_*] applies directly only when F is Z-measurable. We therefore use the Z-measurable projection

    E_Z={z: every clean x with C(z|x)>0 satisfies
                |J_u(x)-w_u|<=w_u/4 for every u,
                and |b'(z)-pi(1)|<=m/2}.

This event is for analysis only, not an input to the estimator. The preceding moment arguments remain valid on E_Z, since E_Z implies E for every realized clean input. The probability of E_Z^c is not controlled by (L12) alone, so the clean count margins must be enlarged first as described in Section 6. The final proof uses that enlarged, Z-measurable event rather than E itself.

## 6 Closing the measurability gap and integrating the risk

Define the Z-measurable event directly from the displayed context counts:

    G={|b'-pi(1)|<=m/2,
          |J'_u-w_u|<=w_u/3 for every u}.        (L25)

Replace E by G everywhere in Sections 4 and 5. This replacement preserves all their bounds after changing numerical constants: on G, (J'_u+2)/w_u lies in [1/2,3/2] by (L11); the bound (L15) still holds using clean deviations and deterministic edits; (L13), (L17), and the coordinate-specific low-count tail are unchanged. The initial-law ratio bound also holds with adjusted constants. No property of E other than the displayed denominator and marginal bounds was needed in the exponential-moment proof.

Moreover, if |J_u-w_u|<=w_u/4 and 2k<=w_u/12, then |J'_u-w_u|<=w_u/3. Increase A_beta once more to ensure this deterministic edit inequality. The same second-moment proof as (L12) gives

    P(G^c)<=C_beta/(M m^2).                      (L26)

All of (L14), (L20), (L23), and (L24) therefore hold with G in place of E. Unlike E, G and the whole exponential factor in (L22) are functions of Z only, with the true source fixed throughout the analysis. This now justifies the exact weighting identity

    E[p(Z)F(Z)]=E[1{X_(N+1)=c_*}F(Z)]
      =m E[F(Z)|X_(N+1)=c_*].                  (L27)

Combining (L22), the G version of (L24), and (L27), the integrated posterior-branch risk on G is at most

    C_beta m delta_m
      =C_beta[(k+1)/(sqrt(M)sqrt(m))
                 +(k+1)^2/(M m^2)].            (L28)

If m>=a and the majority branch is selected on G, then m'<=2a and m'>=m/2 imply m<=4a. The empirical majority is the true majority because |b'-pi(1)|<=m/2 and 3m/2<=6a<1/2. Its integrated risk on any such subset is at most E p(Z)=m<=4a. On the posterior branch, (L28) and m>=a give

    (k+1)/(sqrt(M)sqrt(m))<=a0/sqrt(A_beta),
    (k+1)^2/(M m^2)<=a0/A_beta^2.

The exceptional-event loss is, by (L26), at most

    C_beta/(M m^2)
      <=C_beta/(M a^2)
      =C_beta a0/[A_beta^2(k+1)^2].             (L29)

For m<a, use the event |b'-pi(1)|<=a. It forces the correct-majority branch since m'<=m+a<=2a and m+a<1/2. By the clean symbol second-moment bound, the edit perturbation k/M<=a/2, and Chebyshev,

    P{|b'-pi(1)|>a}
      <=C_beta(Mm+1)/(M^2a^2)
      <=C_beta[1/(Ma)+1/(M^2a^2)]
      <=C_beta a0.                             (L30)

The loss on the good event is at most m<a. This also handles m=0 directly; the clean frequency is then deterministic and k/M<a. Combining (L28)-(L30) and the trivial a>1/16 branch proves (L1).

## 7 What changed and what has not been proved

The log-free result needs all three ingredients: a fixed-time geometric overshoot bound, concentration valid after conditioning on the future minority through reversal, and coordinate-specific inverse-likelihood control supplied by the fitted minority floor. Removing the log from the original high-probability event alone would not suffice.

The proof explicitly uses a Z-measurable good event G. Substituting a clean-history event into the posterior weighting identity would be invalid for a history-adaptive channel. The denominator-error moment bounds themselves are based on clean counts only through pathwise inequalities.

This candidate removes the logarithm from the previous upper, without imposing a transition floor or restricting the disclosed channel. It does not supply a uniform-in-rho sharp theorem, a computationally efficient estimator, or an all-initial-law extension. The supplied rare-budget lower can be compared after independent review; no sharpness or novelty certification is made here.
