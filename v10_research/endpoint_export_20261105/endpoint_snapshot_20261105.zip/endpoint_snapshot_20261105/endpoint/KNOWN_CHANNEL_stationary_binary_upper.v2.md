# Stationary binary prediction through a known channel: improved small-budget upper

Date: 2026-11-05 UTC. Pure mathematical analysis. No scientific executable checks, public write, external novelty claim, efficient implementation, or sharp-rate claim.

## Theorem

Fix 0<beta<=1. In the stationary binary second-order class D2(beta), for every disclosed, source-independent, future-blind observation channel C with strict Hamming budget k, a statistical predictor satisfies

    E TV(q_C(Z),P_(theta,C)(X_(N+1) in . | Z))
       <=min{1,C_beta[(k+1)/sqrt(M)]^(1/3)}.             (V1)

Here M>=64, N=M+2, 0<=k<=M, and C_beta is finite for every fixed beta. This is uniform over the true source and all such known channels. It requires no endpoint-reliability restriction, so covers every rho including rho=1.

In particular, stationary binary posterior prediction is uniformly consistent for fixed positive beta and k=o(sqrt(M)), whereas the one-edit constructions show a nonzero endpoint floor for stationary K>=4 and binary arbitrary-start sources. For fixed k this upper is O_beta(M^(-1/6)); it is not claimed optimal. At k=0 the established clean estimator gives a sharper rate.

This is a separate improvement of `KNOWN_CHANNEL_stationary_binary_upper.md`; that reviewed earlier proof remains valid. The improvements are a stationary occupation-variance bound and an independently fitted initial pair law, rather than requiring the fitted initial law to be stationary for the fitted transition table.

## 1. Model and consequences of all-state minorization

The true source has rows theta_(a,b)(c), pair transition

    P((a,b),(b,c))=theta_(a,b)(c),

and stationary pair law Pi such that P^2(s,t)>=beta Pi(t) for every pair s,t. Let pi denote its stationary symbol marginal and m=min(pi(0),pi(1)). Summing the certificate over the second coordinate of a target pair gives

    theta_u(c)>=beta pi(c).

Stationarity also gives

    Pi(a,b)=sum_c Pi(c,a)theta_(c,a)(b)
       >=beta pi(a)pi(b).                              (V2)

The true two-step pair kernel contracts TV by factor at most 1-beta. Therefore

    TV(P^h(s,.),Pi)<=(1-beta)^floor(h/2).

Fix a threshold 0<a<=1/16 for now. If m>=a, every row coordinate is at least eta=beta a and every pair mass is at least beta a^2.

The channel is a fixed kernel C(z|x), disclosed to the estimator, with C(z|x)>0 implying d_H(x,z)<=k. Its seed is independent of future innovations conditional on X. Thus for each FIXED true source,

    p_theta(z)=P_(theta,C)(X_(N+1) in . | Z=z)
              =E_(theta,C)[theta_(S(X)) | Z=z].

The corruption changes the displayed history, not the physical state. The target is not averaged over unknown source hypotheses.

## 2. Row estimation with a stationary occupation-variance bound

Let J_u count the M historical contexts u ending at times 2,...,N-1. Under the clean stationary source,

    E J_u=M Pi(u).

For the indicator of pair state u, lag-h covariance is exactly

    Pi(u)[P^h(u,u)-Pi(u)].

The mixing bound and a geometric-series sum therefore give

    Var(J_u)<=5M Pi(u)/beta,
    P{J_u<M Pi(u)/2}<=20/[beta M Pi(u)].                (V3)

For the clean successor-one count C_(u,1), the sum

    Z_u=C_(u,1)-theta_u(1)J_u

is a predictable-row martingale sum. Orthogonality gives E Z_u^2<=M Pi(u). The clean add-one row satisfies

    |(C_(u,1)+1)/(J_u+2)-theta_u(1)|
       <=(|Z_u|+1)/(J_u+2).

On J_u>=M Pi(u)/2, taking expectations bounds this by

    2/sqrt(M Pi(u))+2/[M Pi(u)].

For every corrupted word, the shared-count comparison from the endpoint-risk companion gives

    TV(q'_u,q_u)<=3k/(J_u+2),

where q'_u and q_u are add-one estimates at the SAME row. On the good-count event this adds at most 6k/[M Pi(u)]. On its complement the full row error is at most one, so (V3) need be charged only once. Thus

    E |q'_u(1)-theta_u(1)|
       <=2/sqrt(M Pi(u))+(2+6k+20/beta)/[M Pi(u)].

Clip each corrupted add-one row to [eta/2,1-eta/2]. When m>=a, this cannot increase error because the true rows lie in [eta,1-eta]. With

    epsilon=max_u TV(theta_hat_u,theta_u),

summing the four row bounds and using Pi(u)>=beta a^2 yields

    E epsilon<=B_row,
    B_row=8/[sqrt(beta)a sqrt(M)]
                +(8+24k+80/beta)/[beta a^2 M].         (V4)

The argument averages over the true clean source and uses pathwise comparisons for the attack. It does not assume independent row observations or a nonadaptive channel.

## 3. Fit the initial pair law separately

Let J'_u be the M observed context-pair counts used in the row estimates. Their normalized vector

    Pi_raw(u)=J'_u/M

is a probability vector. Each changed token affects at most two counted pairs, so its TV distance from the clean empirical context law is at most 2k/M. Applying (V3), Cauchy-Schwarz, and sum_u sqrt(Pi(u))<=2 gives

    E TV(Pi_raw,Pi)<=sqrt(5/[beta M])+2k/M.              (V5)

Project Pi_raw in L1 distance onto the simplex having every coordinate at least beta a^2/4. This simplex is nonempty. When m>=a, the true Pi belongs to it by (V2), so the triangle inequality and projection optimality imply

    Delta:=TV(Pi_hat,Pi)<=2TV(Pi_raw,Pi),
    E Delta<=B_init=2sqrt(5/[beta M])+4k/M.              (V6)

A deterministic tie rule makes the projection measurable. The fitted Pi_hat need not be stationary for theta_hat. An estimator may use this unrestricted positive initial law as a surrogate; it is not required to be a proper member of the true stationary model class.

## 4. Global known-channel posterior stability

For each fixed displayed word z, use its fitted Pi_hat and theta_hat to define a positive surrogate clean-word law

    P_hat(x)=Pi_hat(x_1,x_2)
                    product_(t=3)^N theta_hat_(x_(t-2),x_(t-1))(x_t).

Form its posterior on X with the SAME known C(z|x), then average theta_hat_(S(X)) to obtain q_C(z). Any observation possible under the true source has a positive surrogate denominator. The following is a pointwise comparison at z, so the fitted quantities may depend on z.

Both true and fitted initial masses are at least beta a^2/4, and both true and fitted row coordinates are at least beta a/2. The mean-value bound for log gives, without a small-error assumption,

    |log(Pi_hat(s)/Pi(s))|<=4Delta/(beta a^2),
    |log(theta_hat_u(c)/theta_u(c))|<=2epsilon/(beta a).

Two clean preimages of the same z are at Hamming distance at most 2k. At most 6k historical triple positions differ between them. Therefore the oscillation of log(P_hat(x)/P_theta(x)) over the posterior support is at most

    L=8Delta/(beta a^2)+24k epsilon/(beta a).            (V7)

The factor C(z|x) cancels in this likelihood-ratio comparison. After normalization, each posterior density is at least exp(-L) times the other; their TV distance is at most 1-exp(-L)<=L. Averaging their respective transition rows adds at most epsilon. Consequently

    TV(q_C(z),p_theta(z))
       <=(1+24k/(beta a))epsilon+8Delta/(beta a^2).

Taking expectations gives the plug-in bound, valid when m>=a,

    Risk_plugin <=(1+24k/(beta a))B_row
                               +8B_init/(beta a^2).   (V8)

The likelihood calculation is purely statistical and may sum over exponentially many words. No efficient computation or finite rational representation of an arbitrary real kernel is asserted.

## 5. Adapt to a nearly deterministic binary source

Use the corrupted generated-symbol frequency

    b'=M^(-1)sum_(t=3)^N Z_t,
    m'=min(b',1-b').

Assume k/M<=a/2. If m'<=2a, predict the empirical majority symbol with probability one. Otherwise use the plug-in predictor above.

The clean frequency b has variance at most 5/(beta M), by the same stationary mixing covariance sum. Since |b'-b|<=k/M pathwise,

    P{|b'-pi(1)|>=a}<=20/(beta M a^2).                 (V9)

If m<a, choosing the plug-in branch or choosing the wrong majority requires this deviation event. Otherwise the expected loss of predicting the true majority is at most m, because the next symbol has marginal pi. This remains an upper on loss restricted to an observed-data event by nonnegativity.

If a<=m<=4a, the plug-in bound is available and the majority branch has loss at most 4a plus the same wrong-majority probability. If m>4a, selecting the majority branch itself requires the deviation event, while the plug-in bound remains available.

Thus the following explicit finite-parameter bound is uniform over every stationary binary source and known channel under consideration:

    Risk<=min{1,
       4a+40/(beta M a^2)
       +(1+24k/(beta a))B_row+8B_init/(beta a^2)}.       (V10)

The distinction from larger alphabets is structural. A vanishing binary minority mass forces the future marginal close to a point mass. A rare nuisance coordinate in a larger alphabet can coexist with a nontrivial second coordinate.

## 6. Optimize the coarse bound

Let

    g=(k+1)/sqrt(M),
    a_*=g^(1/3).

If a_*>1/16, the unit risk bound is at most 16a_*. Otherwise set a=a_*. The condition k/M<=a/2 follows. For fixed beta, the non-frequency terms in (V10) are bounded by

    C_beta[(k+1)/(a^2 sqrt(M))+k(k+1)/(a^3 M)].

The first term equals C_beta a. The second is at most C_beta g^2/a^3=C_beta a^3<=C_beta a. Also 1/(M a^2)<=a since 1/M<=g^2=a^6. This proves (V1), after enlarging C_beta to handle the fallback case.

No lower matching the power 1/3 is established. The proven conclusion is a sufficient regime for uniform consistency, not a necessary edit-budget threshold or a sharp minimax rate.

## Scope and open gaps

- Stationary initialization and beta>0 are used essentially. The binary arbitrary-start one-edit lower prevents silently extending this theorem to unknown initial pair laws.
- The constant C_beta is not uniform as beta decreases. The explicit formula (V10) may be used for further moving-beta analysis, but no such optimized claim is made here.
- The channel must be known. The earlier heat-bath pair gives a binary stationary floor when its identity is unknown.
- No actual edit mask, hidden branch or realized channel seed is supplied.
- Stationary ternary sources and the sharp stationary binary rate remain open in this analysis.

## Source dependencies

- `EPR001_endpoint_probability_interpolation.md`: all-state D2(beta), common-component consequence, strict observation-channel model.
- `EDIT_OVERLAP_and_TARGET_BOUNDARIES.md`: same-row add-one perturbation bound 3k/(J+2).
- `KNOWN_CHANNEL_stationary_binary_upper.md`: prior valid coarse proof and the same minority-threshold principle.
- `KNOWN_CHANNEL_one_edit_lower.md`: alphabet and initialization contrasts.
