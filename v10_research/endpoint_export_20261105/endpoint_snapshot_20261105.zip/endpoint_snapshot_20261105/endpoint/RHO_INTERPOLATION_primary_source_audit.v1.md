# Primary-source delta audit: sharp endpoint-probability interpolation

Date: 2026-11-05 UTC. Analytical source comparison for the stationary binary disclosed-channel result. No executable scientific checks, experiments, public writes, theorem-file changes, or novelty certification. This report supplements the four earlier primary-source audits in this directory.

## 1. Findings and change from the preceding audit

The new interpolation and log-free upper close two questions left open in `QUANTITATIVE_BINARY_RATE_primary_source_audit.v1.md`: the sharp rate over the full stationary binary D2(beta) class, and the joint dependence on the endpoint-change allowance rho. Those earlier open-question statements describe an older proof state; they should not be repeated as current conclusions. The earlier positive-transition-floor result remains valid on its smaller source class.

The strongest additional precedents are general expected posterior stability under a common observation kernel, clean Markov prediction proofs that condition count estimates on the terminal state, and variance-sensitive Markov concentration. They substantially narrow the defensible positioning. Neither known-channel posterior sensitivity, observation-normalizer cancellation, time reversal for terminal conditioning, nor logarithm-free concentration should be presented as new in isolation.

The inspected sources do not give the entire matched rate with the present fixed-source prediction target, one common disclosed offline channel, strict realized raw-Hamming budget, and per-input endpoint constraint. This is a bounded comparison, not a priority claim. The precise result and the realizability of its lower-bound channels are the appropriate focus.

## 2. Exact experiment and rate

Fix beta in (0,1), let N=M+2, and let 0<=k<=M be an integer and rho in [0,1]. The source is a stationary homogeneous binary order-two chain. Its pair-chain kernel satisfies the all-state certificate

    P^2(u,v) >= beta Pi(v).

The predictor sees the complete channel description C and the displayed word Z. The channel may inspect the entire available clean history X_1:N, but not the future X_(N+1). It does not receive the unknown source sign. Its random seed and realized edit mask are not disclosed. For every input word, every realization uses at most k raw-token substitutions, and

    P_C{(Z_(N-1),Z_N) != (X_(N-1),X_N) | X_1:N=x} <= rho.

This is not an expected edit constraint or a source-averaged endpoint-failure bound. The kernel need not factor into independent emissions or be online-causal within the observed history. Source independence means the same kernel is used under the alternative sources, not that its output or edit decisions are independent of the input data. Its design may use the horizon and public budgets.

For each fixed source theta, the target is

    p_(theta,C)(z) = P_(theta,C)(X_(N+1)=1 | Z=z).

The risk is expected absolute error, equivalently Bernoulli total variation. The posterior averages latent clean histories under this fixed source; it does not average the competing source hypotheses under a parameter prior. This is neither classification error nor loss against the unobserved actual-terminal transition row. If theta and C were both known, the distribution-estimation loss could be zero even though the next bit remains random.

Let R_beta be the worst-disclosed-channel minimax risk. Estimators are channel-aware families q(C,z); the upper holds for every allowed C. Each lower uses a single common C under its two alternatives, rather than assigning a different channel to each hypothesis. The theorem does not claim difficulty for every channel.

For M>=M_beta, uniformly in k and rho, the supplied result is

    R_beta(M,k,rho)
      = Theta_beta(min{1, M^(-1/2) + F_beta(M,k)
                               + min{rho,a(M,k)}}),

where a=F_beta=0 at k=0, and otherwise

    a(M,k) = min{(k^2/M)^(1/3),1},
    e = max{sqrt(beta),1/M},
    F_beta(M,k) = (k/M)[1+log(1+1/(e k))].

For fixed beta, F_beta is comparable to k/M. Thus the simpler equivalent rate is

    Theta_beta(min{1, M^(-1/2) + k/M
                         + min{rho,(k^2/M)^(1/3),1}}),

with the last term zero at k=0. Constants and the onset horizon depend only on fixed beta, not on k or rho. No beta-uniform claim, beta=1 amplification claim, arbitrary-initial-law extension, or computational-efficiency conclusion follows.

At one edit and fixed positive rho the full-class rate is M^(-1/3), not the M^(-1/2) rate from a fixed positive transition floor. The rare alternatives have transition probabilities tending to zero with M while retaining the stipulated mixing certificate. Uniform mixing relative to a stationary distribution does not supply a fixed lower bound on its rare-state mass.

## 3. Why the new lower is a minimum, not a product

The rare family uses common terminal rows t and r, with r a positive beta-dependent constant, while only the row at context 11 varies. At k=1, t=tau M^(-1/3). For k>=2, h=min{k-1,floor(sqrt(M))} and t=tau(h^2/M)^(1/3). The two varying-row multipliers are separated by order 1/h. The rare informative transition has stationary frequency of order t^3, which keeps the clean-path KL controlled at the scale M t^3/h^2. Initial stationary-law differences are included, not discarded.

The separated-site construction supplies exact conditional Bernoulli bits, not an independent-sample approximation to the original chain. Conditional on its retained scaffold, the clean penultimate bit B is Ber(t). The future success probability is t+(r-t)B under both alternatives. The identifiable erasure or count-normalization branch hides a mode with probabilities v_+ and v_- separated by a beta-dependent constant. Its endpoint flip probability is T_q=rho v_q.

For displayed penultimate bit W=1, the exact output probability and clean-endpoint posterior are

    ell_q = t+(1-2t)rho v_q,
    P_q(B=1 | scaffold, normalized word, W=1)
       = t(1-rho v_q)/ell_q.

The full displayed-word masses factor as

    f_q(H) g_q(H) u_H(y) ell_q,

where u_H is the same normalized-word law under both hypotheses, g_q has a uniform positive lower bound, and the restricted scaffold laws have constant overlap. Count-layer uniformity is after averaging over a uniform input count layer. It is not uniformity conditional on each individual input word. The common displayed law of the normalized configuration alone does not assert equality of the complete observation laws.

Exact subtraction of the two source-specific targets gives

    |p_+(z)-p_-(z)|
       = (r-t)t(1-t)rho |v_+-v_-|/(ell_+ ell_-).

The two-point absolute-loss argument weights this by min{P_+^Z(z),P_-^Z(z)}. Hence one normalizer cancels:

    min{ell_+,ell_-}/(ell_+ ell_-)
       = 1/max{ell_+,ell_-} >= 1/(t+rho).

After summing the complete output masses, the lower is a constant times

    rho t/(rho+t), comparable to min{rho,t}.

This keeps the rare-output probability. There is no constant-probability claim for W=1, no insertion of an additional independent rho factor, and no inference from a large conditional gap alone. At rho=0 the endpoint lower vanishes, with positive denominators throughout. The same construction and constants work as rho tends to zero. The two terminal rows are common, so there is no direct source-row discrepancy to subtract at this stage.

The protected k/M contribution is supplied separately by one disclosed count-normalizing channel on an IID Bernoulli subclass. It edits only the first M coordinates and preserves both terminal coordinates, so it is admissible even at rho=0. Its constant-overlap branch hides the interior count while the future target remains the source's Bernoulli parameter. This is a genuine common-channel lower, not a transfer of an unknown-channel corruption lower.

Finally, the clean, protected, and rare-endpoint witnesses give three separate lower bounds. The worst-channel risk dominates their maximum, which dominates one third of their sum. They are not combined into a single experiment or a larger edit budget. The alternatives and channels may vary with M. Positive observation-law overlap, rather than exact equality, establishes uniform minimax difficulty; it does not establish inconsistency at one fixed source and one fixed channel.

## 4. What is required for the log-free upper

The known-channel upper v2 proves C_beta min{1,((k+1)^2/M)^(1/3)} for k>=1. Its principal comparison-sensitive steps are these:

1. For minority stationary symbol mass m, D2(beta) yields context masses at least beta m^2 and triple masses at least beta^2 m^3. No uniform transition floor is added.
2. The stationary triple chain has a three-step minorization by its stationary law. The reversed stationary chain inherits this minorization. Conditioning on the future minority symbol changes its reverse starting law; it does not require dividing an unconditional tail bound by m.
3. A direct Doeblin regeneration argument provides variance-sensitive count bounds uniformly over the initial law. The final incomplete block is controlled at the fixed observation horizon, rather than by taking a maximum of all block lengths. This avoids an artificial horizon logarithm.
4. Corrupted count differences are bounded pathwise by the edit budget. There is no assumption that adaptive edits are independent of the counts.
5. Add-one smoothing controls small empirical numerators. The proof uses each coordinate's own mean v and its exponentially small deficit probability; a generic inverse-minimum-probability bound would be too coarse.
6. Write p_c(Z)=P_(theta,C)(X_(N+1)=c | Z), where c is the minority symbol and m=P(X_(N+1)=c)>0. For a Z-measurable factor F, the exact identity

       E[p_c(Z) F(Z)] = m E[F(Z) | X_(N+1)=c]

   retains the minority weight. It does not assert p_c(Z)<=m pointwise. The proof-only good event can depend on fixed theta while remaining Z measurable. A zero-mass minority is handled without conditioning on that null event.

The resulting integrated error is balanced at m of order ((k+1)^2/M)^(1/3). Uniform, high-probability relative precision for every rare transition is not the objective. Replacing this expected-risk reasoning by a union bound and charging every rare-coordinate failure unit loss can add a spurious logarithm or a worse power.

For the uniform-rho upper, future blindness gives p(Z)=E[theta_(S(X))(1)|Z]. Conditional Jensen therefore transfers the EPR001 latent-row UPPER to a posterior-target upper of order M^(-1/2)+F_beta+rho(1-beta). It transfers no lower bound. Choosing between that estimator and the log-free estimator by their public deterministic risk bounds gives the stated minimum. This does not condition a clean-source theorem on a channel-selected edit mode, nor does it use a hidden channel seed to select the estimator.

## 5. Strongest additional primary sources

### A. Expected posterior stability under one common kernel

Curtis McDonald and Serdar Yuksel, *Exponential Filter Stability via Dobrushin's Coefficient* (2019 preprint; version 2, 21 May 2020), Lemma 3.2 and Example 3.3, PDF pp. 7-8.

Source: https://arxiv.org/pdf/1910.08463v2

For a dominated observation kernel Q and mu absolutely continuous with respect to nu, Lemma 3.2 gives

    E_(mu Q) TV(Bayes_Q(mu,Y),Bayes_Q(nu,Y))
       <= (2-delta(Q)) TV(mu,nu).

Its TV convention differs by a common factor from half-L1; the displayed multiplicative inequality is unchanged. Example 3.3 shows that a Bayesian update can expand TV even in expectation. Thus generic expected stability and failure of universal non-expansivity are prior art. The sequential contraction theorem imposes additional transition conditions, but this one-step lemma is more general. It does not supply the edit-budget minimax rate.

Application to the present experiment, rather than a claim made by that paper: take the entire clean history as the latent state. A disclosed offline channel is still a single dominated finite-state observation kernel. For the future-prediction target itself, include X_(N+1) in that latent state and let the channel ignore it, then project the latent posterior onto the future coordinate. Alternatively, a history-only application must also handle the change in the transition row. The rare positive-source alternatives meet the absolute-continuity condition. Their resulting whole-path prior-TV bound is generic and need not yield a vanishing statistical rate. Offline dependence alone is therefore not a valid way to dismiss this antecedent.

### B. A recent expected-TV balance formulation

Gonzalez, Akyildiz, Crisan and Miguez, *An Operator-Theoretic Analysis of Nonlinear Filtering under Model Misspecification*, arXiv:2607.11378v2, 13 October 2026. See Remark 2.1, Lemma 3.3, Theorem 3.4, and Section 4.

Source: https://arxiv.org/html/2607.11378v2

This preprint compares true and misspecified filters under the same true observation law. It gives an averaged update bound and an exact TV balance identity characterizing non-expansivity. Integrating the observation normalizer is explicit. Its stated model uses conditionally independent observations and strictly positive, observationwise bounded, Lebesgue-normalized likelihoods. The present finite, potentially zero-valued, globally budgeted channel is not literally that sequential model. The single-update normalization argument is nevertheless close. This is an adjacent preprint, not evidence for the present minimax theorem or a certified extension of its hypotheses.

### C. Clean Markov prediction and terminal-conditioned counts

Yanjun Han, Soham Jana and Yihong Wu, *Optimal prediction of Markov chains with and without spectral gap conditions*, NeurIPS 2021. See main Section 1.1 and Theorem 3; supplement Section 7.2, Lemma 15, Remark 4, and Appendix B.

Main: https://proceedings.neurips.cc/paper/2021/file/5d69dc892ba6e79fda0c6a1e286f24c5-Paper.pdf

Supplement: https://proceedings.neurips.cc/paper/2021/file/5d69dc892ba6e79fda0c6a1e286f24c5-Supplemental.pdf

The relevant result concerns clean next-state prediction in expected KL. The supplement reverses time to analyze empirical moments conditioned on the terminal state. Remark 4 explains why a stationary-mass prefactor in a Chernoff bound and a cruder second-moment argument can lose the desired rate, including an extra log n. This is a particularly strong methodological precedent. The cited spectral-gap argument assumes finite reversible irreducible first-order chains. An order-two pair chain need not be reversible, and the present proof instead uses inherited reverse Doeblin minorization. Neither a corruption channel nor the k,rho rate is supplied by that clean theorem.

### D. Variance-sensitive Markov concentration

Daniel Paulin, *Concentration inequalities for Markov chains by Marton couplings and spectral methods*, Electronic Journal of Probability 2015; corrected arXiv v5, 13 November 2018. See Theorem 3.11 and Proposition 3.15 in the corrected version.

Source: https://arxiv.org/pdf/1212.2015v5

The stationary nonreversible Bernstein inequality uses the observable's variance and the pseudo-spectral gap. For an indicator this retains rare-event variance without a horizon logarithm. The general nonstationary reduction introduces a density-ratio factor; for a point start it can depend on inverse stationary mass. It therefore cannot simply be cited to justify the upper's future-conditioned uniform constants. The corrected version explicitly repairs an earlier general-state-space proof gap. Cite that version and check its hypotheses rather than relying on an older theorem number or an unqualified concentration slogan.

### E. Regeneration as an established concentration method

Patrice Bertail and Gabriela Ciolek, *New Bernstein and Hoeffding type inequalities for regenerative Markov chains*, ALEA 16 (2019), 259-277.

Source: https://alea.math.cnrs.fr/articles/v16/16-09.pdf

DOI: https://doi.org/10.30757/ALEA.v16-09

The introduction and regeneration setup separate an initial block, independent regenerative blocks, and a terminal remainder, then control their concentration under moment assumptions. This is background for the upper's method, not an exact citation for its arbitrary-start rare-indicator lemma. Only those portions were compared here; the report does not claim a complete theorem-by-theorem reduction or that logarithm-free regenerative concentration begins with the supplied v2 proof.

### F. Fixed-observation posterior sensitivity and evidence

Nada Cvetkovic and Han Cheng Lie, *Upper and lower bounds for local Lipschitz stability of Bayesian posteriors*, arXiv:2505.23541v1 (2025), especially Proposition 3.7; also Proposition 3.2.

Source: https://arxiv.org/html/2505.23541v1

The prior-perturbation bounds through a common likelihood explicitly depend on the evidence. On equal-evidence level sets, upper and lower bounds connect posterior TV to prior TV divided by evidence; the lower result needs bounded misfit. This is a precise antecedent for small-normalizer sensitivity. Its fixed-data bounds do not integrate the gap against the probability of that observation. They alone prove neither a product rho*t nor the overlap-weighted minimum min{rho,t}. Likelihood zeros also require care when using bounded-misfit assumptions.

## 6. How this relates to the earlier comparisons

The earlier audits already cover Chan-Darwiche and Hilbert-metric posterior perturbation bounds, Chigansky-van Handel robust filtering, Weissman-Merhav noisy prediction, DUDE, corruption-kernel Bayesian inversion, coarsening-at-random, score/covariance identities, quantization, and robust transition estimation. Their source URLs and detailed comparisons remain in those artifacts and are not duplicated here.

The present delta strengthens rather than replaces that comparison:

- A common disclosed kernel does not make its Bayesian inverse known when the clean law is unknown, but this observation is already covered by general posterior and corruption-kernel theory.
- Standard sequential filtering often imposes structured emissions. Nevertheless, an arbitrary one-shot finite kernel fits a general Bayesian-update lemma after enlarging the latent state. Distinguish the sequential theorem from its one-step ingredients.
- A parameter-prior robustness problem and the present fixed-source future-law target are different. Applying a Bayesian-update inequality to two path laws does not turn the target into a mixture over source hypotheses.
- Large pointwise posterior discrepancies, averaged posterior stability, clean-path distinguishability, and minimax estimation from the corrupted word are four different statements. The supplied lower checks the full observation-law overlap and target separation together.
- Fixed mixing does not exclude rare states. Clean prediction already exploits stationary weighting, and terminal-conditioned analyses predate the current proof. What remains model-specific is how that weighting interacts with a strict adaptive edit budget and the disclosed channel's latent-history fibers.
- The old positive-floor linear-in-k bound and the new full-class cube-root rate are compatible. Substituting a shrinking transition floor into constants stated for a fixed floor would not prove the new theorem.

## 7. Recommended bounded positioning

The precise claim to compare with the literature is a matching local minimax analysis for stationary binary order-two source-specific posterior prediction through a common disclosed, future-blind offline channel, with a strict raw-Hamming budget and per-input endpoint protection. Its full-class rate contains an endpoint term min{rho,(k^2/M)^(1/3),1}; the rare-output calculation retains observation mass and the upper uses expected minority-weighted control.

Avoid claiming the first known-channel posterior counterexample, first posterior amplification phenomenon, first expected filtering stability result, first terminal-conditioning argument, first logarithm-free Markov concentration inequality, or a sharp rate for arbitrary initialization or moving beta. The search did not establish any such priority statement.

The example k=1 and rho=M^(-1/3) is a useful exact distinction: the theorem gives order M^(-1/3), whereas the product interpolation M^(-1/2)+F_beta+rho*a would give order M^(-1/2). This is a theorem-specific consequence, not an inference from generic posterior brittleness.

## 8. Evidence binding and review limits

The interpolation, log-free upper, their independent reviews, and both rare-source lower files were read. The supplied independent reviews report analytical acceptance; this source audit does not replace them or add computational validation. Relevant statements in previous audits were revisited to identify the change in proof status. New primary papers were read at the sections identified above; none was silently treated as fully audited.

All filenames below are relative to `./`.

- `KNOWN_CHANNEL_stationary_binary_rho_interpolation.v1.md`
  SHA256: `70b210c5ee6c9f410fe31a4d06aff2c82eef328d80165a5f257c2f8dee40e744`
- `KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md`
  SHA256: `a94a259168502b550b696d970b9a577689e82703365b02b0397d5c0a6f14232f`
- `KNOWN_CHANNEL_stationary_binary_rho_interpolation_independent_review.v1.md`
  SHA256: `f375dd09428fd3ee1270a8366afa05c00f5145facf8cd1e2691fbb2a34aefd60`
- `KNOWN_CHANNEL_stationary_binary_logfree_upper_independent_review.v1.md`
  SHA256: `4665036a148b430e3eb91f349a4db671de184d2c145ac56caec6e87defe8ce6f`
- `KNOWN_CHANNEL_stationary_binary_rare_one_edit_lower.v1.md`
  SHA256: `49915c863da95d1b139c467c686aee5cf65a5bd408ad9ec762ed8c7408ad88c9`
- `KNOWN_CHANNEL_stationary_binary_rare_budget_lower.v1.md`
  SHA256: `9bfc30dcf44224b238ea315a7d306e4ff4e6ef7f6108e9fd97ed68dd3fb19689`

Earlier comparison artifacts: `EPR001_primary_source_prior_art_audit.v1.md`, `POSTERIOR_CHANNEL_primary_source_audit.v1.md`, `STATIONARY_BINARY_THRESHOLD_primary_source_audit.v1.md`, and `QUANTITATIVE_BINARY_RATE_primary_source_audit.v1.md`. These frozen files were not modified. Reading, artifact creation, and SHA256 binding were the only local operations; no scientific code was run.
