# Stationary binary known channel prediction without logarithmic loss

Date: 2026-11-05 UTC. Pure analytical proof candidate for independent review. No executable scientific checks, public uploads, novelty certification, or efficient-computation claim. This version simplifies v1: ordinary add-one transitions suffice. The argument controls the full exponential posterior comparison in expectation and uses a displayed-data measurable good event.

## 1 Claim and scope

Fix beta in (0,1), M>=64, N=M+2, and integer 1<=k<=M. For every disclosed source-independent future-blind channel C satisfying d_H(x,z)<=k on every realization, there is a source-independent statistical predictor q_C such that

    sup_{stationary theta in D2(beta)}
      E_theta,C |q_C(Z)-P_theta,C(X_(N+1)=1 | Z)|
        <= C_beta min{1, ((k+1)^2/M)^(1/3)}.           (V1)

The channel may inspect all N observed symbols and randomize. The estimator may sum over all clean preimages. No source transition floor is assumed. The result is uniform over endpoint-reliability constraints rho but does not establish a uniform-in-rho sharp interpolation. At k=0 use the separately established clean M^(-1/2) estimator rather than (V1).

The class D2(beta) consists of binary homogeneous second-order sources with stationary pair law Pi and all-state certificate P^2(u,v)>=beta Pi(v). Write pi for the stationary one-symbol law and m=min{pi(0),pi(1)}. The certificate implies

    theta_u(c)>=beta pi(c),
    Pi(a,b)>=beta pi(a)pi(b),
    Pi(u)>=beta m^2,
    Pi(u)theta_u(c)>=beta^2 m^3.                    (V2)

The first inequality follows by summing the certificate over the second coordinate of the destination pair. The second follows from stationarity and the first. If m>0, every pair and triple probability is positive.

## 2 Count concentration without a horizon logarithm

### 2.1 Uniform-start regenerative concentration

Let K have stationary law Lambda and K(y,.)>=beta Lambda(.) on its support. For any initial law, indicator f, p=Lambda(f), n>=1, and t>=1,

    P{|sum_(i=1)^n f(Y_i)-np|
        >B_beta [sqrt(np t)+t]} <=B_beta exp(-t).    (V3)

For stationary start, write K=beta Lambda+(1-beta)Q. The residual kernel Q preserves Lambda. Regenerate from Lambda after independent geometric cycle lengths L. A complete cycle has centered reward

    W=sum_(i=1)^L f(Y_i)-pL.

Its length is independent of the Q trajectory, whose one-time marginals are Lambda. For j>=2,

    E W=0,
    E|W|^j<=2^j p E L^j<=p j! B_beta^j.

Thus the complete-cycle reward has a Bernstein moment generating function with variance scale proportional to p. Stop its exponential supermartingale at the first cycle whose cumulative length reaches n. This is a complete-cycle-filtration stopping time bounded by n, so the stopped centered sum has Bernstein tails B_beta[sqrt(np t)+t].

The difference from the first-n centered count is bounded by the unobserved remainder of the cycle covering n. This remainder is geometric: after the deterministic time n, the next refresh coin has success probability beta independently of the earlier coins. Equivalently, even the whole covering cycle has a horizon-independent exponential tail, since its backward age and forward remainder each require a run of failed refresh coins. There is no maximum over the first n cycles and no log n loss. Combining these tails proves (V3) for stationary start.

For arbitrary start, the initial block before the first refresh has geometric length and centered reward bounded in absolute value by its length. Conditional on that length, the remaining horizon starts independently from Lambda and is no longer than n. Apply the stationary bound uniformly over that deterministic remaining horizon, then add the initial geometric tail. This proves (V3) as stated.

Two useful consequences, with v=np and V=sum f, are

    E(V-v)^2<=C_beta(v+1),                         (V4)

and, for v>=1 and 0<=lambda<=c_beta/sqrt(v),

    E exp(lambda |V-v|)<=1+C_beta lambda sqrt(v).  (V5)

Choose c_beta small enough. To verify (V5), (V3) gives

    P(|V-v|>x)<=C_beta exp[-c_beta min{x^2/v,x}]

for all x>=0, after increasing the leading constant. Integrate

    E exp(lambda |V-v|)-1
      =lambda integral_0^infinity exp(lambda x)P(|V-v|>x) dx.

The Gaussian portion is O_beta(lambda sqrt(v)) by completing the square and using lambda sqrt(v)<=c_beta. The exponential portion has the same bound because lambda<=c_beta and v>=1. Integrating the tail without the exponential factor similarly proves (V4).

### 2.2 Future-conditioned counts have the same bounds

Set H_i=(X_i,X_(i+1),X_(i+2)). Its stationary law is

    Lambda(a,b,c)=Pi(a,b)theta_(a,b)(c).

Its transition kernel T satisfies

    T^3(h,(a,b,c))
      =P^2(last_pair(h),(a,b))theta_(a,b)(c)
      >=beta Lambda(a,b,c).                        (V6)

On positive stationary support, time reversal gives

    (T_rev)^3(h,g)
      =Lambda(g)T^3(g,h)/Lambda(h)
      >=beta Lambda(g).                            (V7)

Condition on X_(N+1)=c, where pi(c)>0. Starting from

    H_(M+1)=(X_(N-1),X_N,X_(N+1)),

this condition changes only the initial distribution of the reversed stationary triple chain, not its backward transition kernel. The training triples H_M,...,H_1 form a length-M portion of an arbitrarily initialized reversed chain. Split these indices into three residue classes. Each subsequence has transition (T_rev)^3 and an arbitrary initial law. Apply (V3) to each and sum, using only a fixed three-event union bound.

Consequently (V3)-(V5), with new beta-dependent constants, hold both unconditionally and conditionally on X_(N+1)=c for any training triple count, context count, or generated-symbol count, centered at M times its stationary mean. No factor 1/pi(c), burn-in logarithm, endpoint/count independence, or conditional martingale assertion is used.

## 3 Estimator and the observable good event

Let J_u and C_(u,c) be the M clean context and successor counts. Set

    w_u=M Pi(u),
    v_(u,c)=M Pi(u)theta_u(c).

The corresponding displayed counts satisfy, pathwise for every allowed channel,

    |J'_u-J_u|<=2k,
    |C'_(u,c)-C_(u,c)|<=3k.                       (V8)

Define b'=M^(-1)sum_(t=3)^N Z_t and m'=min{b',1-b'}. The displayed frequency differs from the clean frequency by at most k/M.

Set a0=((k+1)^2/M)^(1/3) and a=A_beta a0, with A_beta a sufficiently large fixed constant. If a>1/16, the unit loss bound proves (V1) after changing its constant. Otherwise use this estimator:

1. If m'<=2a, predict the displayed empirical majority deterministically.
2. Otherwise use the ordinary add-one estimates

       theta_hat_u(c)=(C'_(u,c)+1)/(J'_u+2),
       Pi_hat(u)=(J'_u+1)/(M+4).                  (V9)

   Use their positive clean-word law, together with the disclosed C(z|x), to form a posterior over clean preimages. Average theta_hat at the latent clean terminal pair to predict. Pi_hat need not be stationary for theta_hat.

For purposes of the analysis, define the same fitted vectors and fitted posterior prediction for every z, including outputs on which the algorithm ultimately uses the majority branch. Add-one makes every fitted vector positive. If no clean word can produce z, define its posterior prediction arbitrarily; such z have zero probability under the true experiment.

For m>=a, use the following event only in the proof:

    G={|b'-pi(1)|<=m/2,
           |J'_u-w_u|<=w_u/3 for every u}.       (V10)

For a fixed true source this event is measurable with respect to Z. This matters for the later posterior weighting identity.

Because m>=a,

    M m^3>=A_beta^3(k+1)^2.                     (V11)

Increase A_beta so that the following deterministic conditions hold:

    k/M<=m/4,
    2k<=w_u/12,
    2/w_u<=1/6,
    v_(u,c)>=B_beta(k+1)^2,                      (V12)

where B_beta may be any fixed sufficiently large constant used in Section 4. These follow from (V2), (V11), and m<=1/2. If the clean context count differs from w_u by at most w_u/4, then its displayed count differs by at most w_u/3. Apply (V4), (V8), and Chebyshev's inequality to the four contexts and the minority symbol frequency. Since all w_u are bounded below by a large constant,

    P(G^c)<=C_beta/(M m^2).                      (V13)

The symbol contribution is at most C_beta/(M m), which is smaller. This is an unconditional statement. We charge unit loss only on context/marginal failures, never on a global rare-triple failure event.

## 4 Exponential moments of the fitted log ratios

All expectations in this section may be either unconditional or conditional on X_(N+1)=c_* for a true minority c_*. Section 2 supplies the same count bounds under both laws. Displayed counts always obey (V8), so channel adaptivity and randomization do not affect the bounds.

Fix a transition coordinate and abbreviate

    theta=theta_u(c), w=M Pi(u), v=w theta,
    S=|log(theta_hat_u(c)/theta)|,
    D=(J'_u+2)/w.

On G, D lies between 1/2 and 3/2. We prove that, for every 1<=ell<=256(k+1),

    E[(exp(ell S)-1)1_G]
      <=C_beta[ell/sqrt(v)+ell(k+1)/v].           (V14)

Choose B_beta and hence A_beta sufficiently large for this fixed exponent range.

### 4.1 Numerator at least half its mean

If C'_(u,c)+1>=v/2, then

    S<=2(|C_(u,c)-v|+3k+1)/v
        +2(|J_u-w|+2k+2)/w =: U.                (V15)

Indeed theta_hat/theta=[(C'+1)/v]/D, and |log t|<=2|t-1| for t>=1/2. Apply (V5) to both counts and use Holder's inequality. Since w>=v and v>=B_beta(k+1)^2,

    E exp(ell U)-1
      <=C_beta[ell/sqrt(v)+ell(k+1)/v].           (V16)

The count moments themselves are not conditioned on G.

### 4.2 Small numerator

If C'_(u,c)+1<v/2 and G holds, then theta_hat/theta<1. Also C'+1>=1, so

    exp(S)=theta/theta_hat=vD/(C'+1)<=(3/2)v.    (V17)

This bound depends on the coordinate mean v, not on 1/m. By (V8) and sufficiently large B_beta, the small-numerator event implies C_(u,c)-v<=-v/4, which has probability at most C_beta exp(-c_beta v) by (V3). Therefore

    E[(exp(ell S)-1)1_G 1{C'+1<v/2}]
      <=C_beta ((3/2)v)^ell exp(-c_beta v).       (V18)

Uniformly over v>=B_beta(k+1)^2 and ell<=256(k+1), choose B_beta sufficiently large that

    ell log((3/2)v)<=c_beta v/2.                 (V19)

For completeness, log((3/2)v)/v is decreasing for v>=e/(3/2). At v=B_beta j^2 with j=k+1>=1, the left-hand ratio is at most

    256 log((3/2)B_beta j^2)/(B_beta j).

For B_beta>=e^2 this is maximized at j=1 and tends to zero as B_beta increases. This proves (V19). The right-hand side of (V18) is thus at most C_beta exp(-c_beta v/2), which is at most C_beta ell/sqrt(v). Together with (V16), this proves (V14).

The add-one pseudocount is important here: it gives the deterministic inverse bound (3/2)v even when the displayed successor count is zero. A coarse inverse bound based on theta or m alone would obscure this cancellation.

### 4.3 Initial-law ratios

Let D_u=|log(Pi_hat(u)/Pi(u))|. On G,

    D_u<=2(|J_u-w_u|+2k+1)/w_u+4/M.

Apply (V5) once more. For the same exponent range,

    E[(exp(ell D_u)-1)1_G]
      <=C_beta[ell/sqrt(w_u)+ell(k+1)/w_u].      (V20)

## 5 Posterior likelihood comparison and minority weighting

Fix an output z and fit Pi_hat and theta_hat at that z. Any two clean preimages x,y of z satisfy d_H(x,y)<=2k. Therefore at most 6k historical triple positions differ. Define

    S_max=max_(u,c)|log(theta_hat_u(c)/theta_u(c))|,
    D_max=max_u|log(Pi_hat(u)/Pi(u))|.

The oscillation over the posterior support of the fitted-to-true clean-word log likelihood ratio is at most

    L=12k S_max+2D_max.                          (V21)

The disclosed channel factor cancels. Thus the normalized fitted-to-true posterior density lies between exp(-L) and exp(L). Let

    p(z)=P_theta,C(X_(N+1)=c_* | Z=z),

where c_* is a true minority. By future blindness, p(z) is the true posterior average of theta_(S(x))(c_*). Fitted successor probabilities differ from true ones by factors between exp(-S_max) and exp(S_max). Hence the fitted posterior prediction satisfies, pointwise,

    |q(z)(c_*)-p(z)|
       <=p(z)[exp((12k+1)S_max+2D_max)-1].       (V22)

This does not require the exponent to be uniformly small. It also does not bound p(z) by m; selected outputs may have large conditional minority probability.

Put

    delta_m=(k+1)/sqrt(M m^3)+(k+1)^2/(M m^3).

Set S_i^G=S_i 1_G for the eight transition coordinates and D_j^G=D_j 1_G for the four initial-law coordinates. By (V2), (V14), and (V20), under the conditional law given X_(N+1)=c_*,

    E exp(12(12k+1)S_i^G)<=1+C_beta delta_m,
    E exp(24D_j^G)<=1+C_beta delta_m.             (V23)

Indeed 12(12k+1)<=156(k+1)<256(k+1). Use max<=sum and Holder with twelve factors to obtain

    E{[exp((12k+1)S_max+2D_max)-1]1_G
          |X_(N+1)=c_*}<=C_beta delta_m.         (V24)

The fitted errors and G are all Z-measurable for a fixed source. Therefore the exact identity

    E[p(Z)F(Z)]
      =E[1{X_(N+1)=c_*}F(Z)]
      =m E[F(Z)|X_(N+1)=c_*]                    (V25)

applies to their nonnegative truncated exponential factor. No clean-history event is inserted into this identity. Combining (V22)-(V25), the posterior-branch integrated loss on G is at most

    C_beta m delta_m
      =C_beta[(k+1)/(sqrt(M)sqrt(m))
                    +(k+1)^2/(M m^2)].          (V26)

Although the fitted estimates depend on z, every comparison above is pointwise at that z. Although the channel can select histories adaptively, its edits enter only the deterministic count inequalities, and the conditional count bounds concern the original source trajectory.

## 6 Majority adaptation and the final risk bound

Suppose m>=a. On G, |m'-m|<=m/2. If the majority branch is selected, m'<=2a implies m<=4a. The displayed majority is then the true majority, since |b'-pi(1)|<=m/2 and 3m/2<=6a<1/2. Its integrated loss on any such subset is at most E p(Z)=m<=4a.

The posterior-branch risk on G is bounded by (V26), and m>=a=A_beta a0 gives

    (k+1)/(sqrt(M)sqrt(m))<=a0/sqrt(A_beta),
    (k+1)^2/(M m^2)<=a0/A_beta^2.                (V27)

The exceptional-event unit loss is at most

    C_beta/(M m^2)
      <=C_beta/(M a^2)
      =C_beta a0/[A_beta^2(k+1)^2].              (V28)

Now suppose m<a. On |b'-pi(1)|<=a, the rule selects the true majority because m'<=m+a<=2a and m+a<1/2. The clean symbol second moment (V4), the edit perturbation k/M<=a/2, and Chebyshev give

    P{|b'-pi(1)|>a}
      <=C_beta(Mm+1)/(M^2a^2)
      <=C_beta[1/(Ma)+1/(M^2a^2)]
      <=C_beta a0.                             (V29)

The loss on the good subset is at most m<a. If m=0, the clean frequency is deterministic and k/M<a, so the majority branch is correct directly. Together with the trivial a>1/16 branch, (V26)-(V29) prove (V1).

## 7 Interpretation and limits

The logarithm in the previous upper is avoidable. The proof does not require every rare transition estimate to be accurate with polynomially small failure probability. Instead it integrates the full posterior comparison under the future-minority-conditioned law. Add-one smoothing bounds the inverse ratio by its own count mean on the small-numerator event, and its exponential tail pays for the k-dependent power.

The required good event is based on the displayed counts and frequency. A clean-history good event cannot be inserted directly into the posterior weighting identity under a history-adaptive channel.

This proof candidate gives the log-free upper uniformly over disclosed future-blind strict-k channels, with stationary initialization and fixed beta>0. It does not establish a rho-dependent sharp interpolation, an all-initial-law extension, or a polynomial-time predictor. The existing rare-budget lower may be compared after independent review. External novelty is unassessed.
