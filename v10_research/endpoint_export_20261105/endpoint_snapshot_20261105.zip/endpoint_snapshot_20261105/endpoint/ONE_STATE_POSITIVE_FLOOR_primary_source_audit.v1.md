# Primary-source delta audit: one-state counter lower and positive-floor rho upper

Date: 2026-11-05 UTC. Focused analytical comparison, not novelty certification, formal verification, or a replacement for the supplied independent reviews. No scientific executable checks, numerical experiments, or public writes were performed.

## 1. Current findings

The corrected `KNOWN_CHANNEL_one_state_counter_lower.candidate.v2.md` has an exact-file independent analytical PASS. Its new endpoint witness supplies

    c_beta rho min{1,k/sqrt(M)}

with one base state, a separately paid actual edit counter, time-indexed rational tables, and stationary binary sources whose successor probabilities are at least 1/4. With the separate clean and protected witnesses, its stated general-D2 bracket is

    c_beta min{1,M^(-1/2)+k/M+rho min{1,k/sqrt(M)}}
      <= R_(S=1,beta)
      <= C_beta min{1,M^(-1/2)+k/M
                              +min{rho,(k^2/M)^(1/3)}}.

These brackets match when k>=sqrt(M), but leave the principal sub-square-root general-D2 S=1 problem open. The already reviewed full rare-source rate is attainable with S>=2 in the later two-state construction. The preceding audit's S>=8 condition is sufficient but no longer the strongest available state bound. No necessity of two base states follows.

The new positive-floor upper is independently accepted at its final reviewed prose revision. For each fixed public 0<eta<=1/2, stationary binary order-two sources satisfying theta_u(c)>=eta obey

    Risk <= min{1,C_eta[M^(-1/2)+k/M
                             +rho min{1,k/sqrt(M)}]}.

This upper permits any disclosed source-independent future-blind channel with strict raw Hamming budget k and the per-clean-word endpoint certificate. It does not require online actions, finite state, rational probabilities, or efficient posterior evaluation. Future-blindness here only excludes dependence on the next innovation after the observed history; it is not current-symbol causality inside that history.

The original general-D2 protected witness cannot simply be imported as a fixed-floor k/M lower. During this audit, an urgent separate analytical task supplied a new protected one-state iid thinning witness that directly establishes that term with floor 1/4 and rho=0. Its exact proof is saved separately, rather than attributed to the earlier witness. Section 5 records the construction and the resulting composition boundary. Independent review status of that new proof should be taken from its own review, not inferred from this source audit.

## 2. Statistical target and genuine resource accounting

For each fixed unknown source theta and the common disclosed channel C, the target is

    p_(theta,C)(z)=P_(theta,C)(X_(N+1)=1 | Z=z), N=M+2.

Risk is expected absolute error in this conditional probability, equivalently Bernoulli TV. It is neither next-bit classification loss nor loss against the transition row at the unobserved actual endpoint. No prior over competing source parameters defines the target. Knowing C supplies its forward kernel, not the posterior over hidden histories without the unknown clean law.

The S=1 endpoint channel's mode is U=X_1. Forcing the first output to zero spends an actual edit precisely when X_1=1, so e becomes X_1. Later zero-counter paths remain inactive; positive-counter paths thin current ones and reserve an endpoint edit. Every increment equals a raw/output disagreement. There is no free persistent random bit, raw-pair gate, overwritten counter value, or uncharged register.

On the observable prefix event Z_2=X_2=0, stationary reversal gives P_a(U=1|Z_2=0)=a. Given that event, the first-order Markov tail is independent of U. This is a source-dependent conditional mode prior, not the preceding fair exogenous mode or the two-state proof's exactly common prefix prior. Its monotonicity helps the endpoint lower, and its change is explicitly included in the mixture-law comparison.

One base state does not mean a standard one-total-state memoryless channel. The actual counter has k+1 values, and the public clock selects horizon-specific rules. The table pays for its expansion and rational precision. If public time is internalized, it adds clock state. Counter exhaustion is monotone/absorbing, so clean-source mixing does not make the augmented channel state mixing.

Shemuel, Sabag, and Permuter's *Finite-State Channels with Feedback and State Known at the Encoder* defines the standard time-invariant kernel P(y_i,s_i|x_i,s_(i-1)) and unifilar state update in section II.B, equation (3), definition 1. In that convention, the actual counter is part of S. The present machine is naturally a time-indexed unifilar counter channel, since e_i=e_(i-1)+1{x_i!=z_i}. Their strongly connected communication setting is not an inference theorem for this monotone-counter experiment. [Primary source](https://arxiv.org/pdf/2212.12886).

Dey, Jaggi, Langberg, and Sarwate's causal-channel converse already allows current/past inputs, randomized attacks, and chronological stopping at a hard Hamming budget. Its target is communication rate and its attack can depend on the code. It does not charge this small-state representation or use the fixed-source posterior under one kernel disclosed before inference. Current-symbol causality and hard clipping therefore have direct precedents; their conjunction with this disclosure, target, and ledger must be checked separately. [Primary source, sections II–III](https://arxiv.org/pdf/1204.2587).

## 3. Exact capped likelihoods: established identities, specific implementation

For fixed scaffold H and displayed candidate vector Y, the endpoint lower writes the actual capped active/inactive likelihood ratio as

    Lambda_a(Y)=sum_E c_E(Y) product_(j in E) o_aj,

where E ranges over erased displayed-zero positions, |E|<=h, and c_E>=0 depends on the common channel and chronological cap but not on a. This is an exact latent-erasure-set expansion, not an assertion that capped thinning equals uncapped thinning conditioned on its edit count.

The normalized terms are the posterior distribution of E. With odds ratios between exp(4delta) and exp(28delta), Jensen gives a lower log-likelihood gap of 4delta times the posterior expected actual erasure count, and the degree bound gives the upper gap 28delta h. The point is to keep this vanishing gap exactly; a fixed additive cap-TV error would be too crude. TV coupling is still used to obtain overlap and weighted moments, where it is appropriate.

Darwiche's *A Differential Approach to Inference in Bayesian Networks* represents evidence by multilinear network polynomials and extracts posterior quantities through derivatives. Section 2.2, definition 1 and theorem 1 give the polynomial representation; theorem 2/corollary 1 and theorem 3 give probabilistic derivative interpretations. These are close precedents for nonnegative latent-path monomials. They do not establish the cap-specific coefficients, degree bound, or statistical rate. [Inspected JACM manuscript](https://people.cs.pitt.edu/~milos/courses/cs3710/readings/differential-darwiche.pdf); [DOI](https://doi.org/10.1145/765568.765570).

Wainwright and Jordan, *Graphical Models, Exponential Families, and Variational Inference*, proposition 3.1, equations (3.40)–(3.41), gives the classical log-partition gradient/expected-statistic and Hessian/covariance identities. Here with natural coordinates log o_j, the gradient is posterior edit-inclusion probability and its sum is expected edit count. Along the scalar source parameter a, however, the derivative is the expectation of sum_(j in E) d(log o_aj)/da, not simply the unweighted count. Uniform derivative bounds yield the count comparison. This is an authoritative synthesis of an established identity, not a priority claim. [Author-hosted source, section 3.5.1](https://people.eecs.berkeley.edu/~jordan/papers/wainwright-jordan-fnt.pdf).

At the endpoint, both the direct row parameter and the mode-posterior contribution increase with a. This sign calculation prevents cancellation. The lower retains the prefix probability, scaffold overlap, mixture overlap, and endpoint-output probability. No unweighted conditional gap or reversed application of conditional Jensen supplies the result.

## 4. Positive-floor upper: the decisive distinctions

### 4.1 A Hamming-fiber comparison, not global word-likelihood accuracy

The displayed-word fitted transition table and initial pair law are frozen after fixing z. The initial law need not be stationary for the fitted transitions. Both clean-word laws are positive, and both posterior normalizers are positive on every nonempty channel preimage. Impossible outputs are handled separately.

Two preimages of z differ in at most 2k raw positions and therefore at most 6k triple factors. The source/fitted log-ratio oscillation on that fiber is bounded by

    L(z)=24k epsilon(z)/eta+4 Delta(z)/eta^2.

The common channel factor cancels in posterior density ratios on their positive support. It does not disappear from either posterior individually. Bounding oscillation uses only differing factors rather than charging all M likelihood factors.

Chan and Darwiche's *A Distance Measure for Bounding Probabilistic Belief Change* defines exactly the max-minus-min log density ratio and bounds conditional-event odds changes by its exponential. Definition 1, theorem 2, theorem 3 and corollary 1 are direct precedents for this deterministic ingredient. Restricting that comparison to a Hamming fiber gives the present locality. The paper does not supply this fitted Markov risk, endpoint certificate, or rho integration. [Primary AAAI paper](https://cdn.aaai.org/AAAI/2002/AAAI02-081.pdf).

Cohen and Fausti's Hilbert-metric theorem gives TV<=tanh(H/4), after converting their L1 convention, for probability measures. This global posterior bound cannot simply be multiplied by the true endpoint-change mass. An exponentially upweighted event with true mass near exp(-L) can acquire order-one fitted mass. Thus a bound C min{1,L} nu(A) is not a valid replacement for the candidate's localized exponential factor. [Primary source, theorem 5.1 and corollary 5.2.1](https://arxiv.org/html/2309.02413v2).

### 4.2 Normalization and data-dependent fitting

With h_z=d nu_hat_z/d nu_z, normalized reweighting gives E_(nu_z)(h_z-1)=0 and exp(-L)<=h_z<=exp(L). Subtracting the displayed terminal-row value makes the target integrand vanish off A_z={x:S(x)!=S(z)}. Consequently

    TV(q_post(z),p_(theta,C)(z))
       <=epsilon(z)+(exp(L(z))-1)nu_z(A_z).

This pointwise argument permits fitted parameters to depend on the same z. It is not an independently estimated prior or a Bayesian posterior over theta.

Sprungk's *On the Local Lipschitz Stability of Bayesian Inverse Problems*, theorem 8 and remark 9, gives posterior-TV perturbation bounds with explicit evidence normalization. This is a strong general antecedent. The present method instead controls relative-likelihood oscillation on a positive finite fiber, avoiding a direct inverse-output-probability estimate. Channel zeros require that support restriction rather than an unqualified finite-potential assumption. [Primary version 3](https://arxiv.org/pdf/1906.07120v3).

McDonald and Yuksel's lemma 3.2 bounds expected Bayesian-update TV for two fixed priors and one dominated kernel. Any finite offline observation kernel can enter that one-update result by treating the entire clean word as latent. Offline dependence alone does not invalidate it. However, its integrated conclusion cannot simply replace a fixed second prior by the data-dependent fitted law P_hat_Z. The present fixed-output comparison and pathwise envelope address that distinction; generic whole-word TV control would not yield the desired k,rho rate. Their Dobrushin coefficient uses the overlap convention, unlike the contraction coefficient in the candidate. [Primary version 2](https://arxiv.org/pdf/1910.08463v2).

### 4.3 Concentration, the exponential moment, and exact extraction of rho

The fixed successor floor implies a positive two-step pair kernel and stationary masses at least eta^2. The one-step pair matrix still has structural zeros. The global clean-word envelope W controls the fitted errors for every allowed x,z, including adversarially small displayed counts. Its occupation-count Doob martingale and transition-residual martingale give a sub-Gaussian tail. For k<=sqrt(M), the scaled exponent (k+1)/sqrt(M) remains bounded, yielding

    E[exp(a_eta(k+1)(W+k/M))-1] <= C_eta k/sqrt(M).

Kontorovich and Ramanan's concentration theorems 1.1–1.2 use dependence coefficients, Hamming-Lipschitz functions, and martingale differences. They are methodological precedent for this part, not a new concentration principle. A one-step strict-contraction corollary cannot be cited unchanged for the pair chain; the two-step contraction or general dependence control matters. No uniformity as eta vanishes follows. [Primary version 2](https://arxiv.org/pdf/math/0609835v2).

The key averaging step is

    E[1_A G(X)] = E[G(X) P_C(A|X)] <= rho E[G(X)],

for the nonnegative clean envelope G supplied pathwise. This is conditional domination, not independence of edits and sufficient statistics. Merely P(A)<=rho permits concentrating failures on high-envelope histories and does not prove this factorization. The displayed-row estimator supplies the rho branch for k>sqrt(M), while k=0 is exact identity and has no endpoint contribution.

Chigansky and van Handel's robust-filter theorem 1.1 concerns continuous-time finite-state signals in Brownian noise, positive off-diagonal generators and positive initial distributions, with uniform-in-time squared filter discrepancy. This is relevant positive-parameter robustness precedent but not the present discrete two-step-positive source, globally budgeted observation kernel, fitted posterior target, or endpoint protection. [Primary version 3](https://arxiv.org/pdf/math/0604295v3).

## 5. Contamination comparison and the new protected witness

Chen, Gao, and Ren's *A General Decision Theory for Huber's epsilon-Contamination Model*, section 2 and theorem 3.2, studies iid draws from (1-epsilon)P_theta+epsilon Q, with unknown Q, robust testing, and a total-variation modulus of continuity. It is a direct precedent for contamination-induced observation overlap and a contamination-scale lower. But Q may vary across hypotheses; their experiment does not give one disclosed input-dependent channel, an exact realized edit cap, or a source-specific conditional future target. A linear k/M term is not novel as a contamination phenomenon, while its realization under this channel interface is an additional obligation. [Primary version 2](https://arxiv.org/pdf/1511.04144).

Blanc, Lange, Malik, and Tan formalize sample-adaptive versus sample-oblivious statistical adversaries. Source-independent C in the current problem can still adapt fully to its input word. Thus source independence is not their sample-obliviousness. Their iid statistical framework is not a sharp fixed-horizon posterior theorem for one dependent path. [Primary paper](https://proceedings.mlr.press/v178/blanc22a/blanc22a.pdf).

The new separate protected witness meets the missing interface directly. For k>=2, h=k-1, set epsilon=h/(16M), p_+=1/3 and p_-=(1-epsilon)/3. Force Z_1=0; actual counter positivity then records X_1=1. Active paths thin ones at positions 2,...,M with epsilon up to h further edits; inactive paths pass them. Both final coordinates are untouched.

Under active-plus uncapped thinning, the interior law is exactly iid Ber(p_-), matching inactive-minus. The cap changes that branch by TV at most 1/48 through a proposed-edit count with mean at most h/48. The two protected bits add at most 1/24 TV. Selected branch overlap is therefore at least 15/16; their mixture weights are at least 1/3, giving complete output overlap at least 5/16. The iid future targets remain exactly p_+ and p_-, with gap h/(48M), yielding risk at least 5k/(3072M). The k=1 case is covered by the clean witness. All rows are rational and guarded; all counter increments are actual edits. Sources have floor at least 1/4 and satisfy D2(beta) even at beta=1.

This proof uses cross-component overlap, not equality of full output laws or a common mode prior. Its mode probabilities differ between sources, but only a lower bound on selected mixture weights is needed. A common disclosed kernel can therefore retain a contamination-scale obstruction even in an iid positive-floor subclass.

Together with the independently accepted S=1 endpoint witness and clean lower, this new protected proof supplies all three lower terms for fixed 0<eta<=1/4 and, when imposed, fixed 0<beta<1. Combining separate witnesses by a maximum does not add their edit budgets. The positive-floor upper then gives the matching profile

    Theta(min{1,M^(-1/2)+k/M+rho min{1,k/sqrt(M)}})

in that fixed-floor S=1 interface, subject to the new protected proof's separate review binding. The same lower is admissible in the larger future-blind class covered by the upper. This is not a resolution of the general-D2 S=1 rare-source gap. Nor should it be asserted for every eta<1/2 without adapting the current lower sources. At eta=1/2 the clean law is fixed iid fair and the posterior probability target is known exactly, so a positive clean-rate lower would be false.

## 6. Positioning and evidence

The bounded contribution descriptions are: an exact cap-aware latent-set expansion implemented with a genuine paid counter; an endpoint-localized refinement of a Hamming-fiber posterior upper using fixed-floor exponential moments and a per-word certificate; and a protected iid thinning witness realizing k/M under the same one-base-state ledger.

Do not claim first polynomial inference, first score-as-expectation identity, first causal clipping, first posterior sensitivity bound, first Markov concentration, first contamination lower, or certified novelty. The source comparison does not establish minimal state resources, training, floating-point correctness, efficient evaluation, or vanishing-floor uniformity.

Prior artifacts consulted: `THINNING_MODE_primary_source_audit.v1.md`, `ONLINE_STRICT_EDIT_primary_source_audit.v1.md`, `QUANTITATIVE_BINARY_RATE_primary_source_audit.v1.md`, `RHO_INTERPOLATION_primary_source_audit.v1.md`, and relevant earlier source references. Both requested candidates and their current independent reviews were fully read. The later two-state statement and independent disposition were inspected to keep the state-bound comparison current.

Present-byte SHA-256 bindings:

- `KNOWN_CHANNEL_one_state_counter_lower.candidate.v2.md`: `81ec5725846233595bfdb803ab92640dc20d419488b68ece2460e99d43a546ce`
- `KNOWN_CHANNEL_one_state_counter_lower.independent_review.v1.md`: `aea209b923c3c8cb0f0f60c783eaf1c20a5851597a52dfa1bc25fac22276cd2e`
- `KNOWN_CHANNEL_positive_floor_rho_upper.candidate.v1.md`: `4f472df0857c73d4a09dfb380136a3f4f3558c994ba75ea5c3cb6579bcf5f13f`
- `KNOWN_CHANNEL_positive_floor_rho_upper.independent_audit.v1.md`: `fdce59e69f7d84d755fc3224c60243d522cf2110c508258e06bba945b83b2e82`
- New separate proof, `KNOWN_CHANNEL_one_state_positive_floor_protected_lower.candidate.v1.md`: `7107da3ab4b928047801bd3cf2798c9156f0e74331995945948a204c69f32333`

The upper review binds its final full mathematical read at approximately 09:20:47 UTC rather than an earlier inspection hash. These hashes independently record the bytes inspected for this comparison. Existing candidates, reviews, and prior audits were not changed. Exact primary URLs and inspected locations are supplied above; this was a focused source search, not exhaustive priority certification.
