# Full log-free estimator with explicit computable constants

5 November 2026 UTC. Analytical candidate for independent review. No scientific executable checks, numerical experiments, public writes, or optimal-resource claims. Earlier bridge files remain unchanged.

## 1. Result

The majority/fitted-posterior estimator in `KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md` admits a completely specified finite-state Transformer implementation. Its threshold constant need not remain an unspecified sufficiently large number.

Assume N=M+2, M>=64, 1<=k<=M, a stationary binary homogeneous order-two source with pair law Pi, and a public rational certificate beta_0 in (0,1] such that

    P^2(s,t) >= beta_0 Pi(t) for every pair state s,t.

Choose the computable integer

    u = max{1, ceil(log2(1/beta_0))}, b=2^-u,
    D_c=32/b,
    H=2^20 D_c^2=2^(30+2u),
    B_*=2^40 H^4,
    A=B_*/b^2=2^(160+10u), C_*=8A.

The definition of u means the least integer u>=1 with 2^-u<=beta_0 and is implemented by integer comparisons on the supplied rational certificate, not by a real logarithm oracle. Replacing beta_0 by b weakens the certificate and is valid.

The channel is the paid normalized rational online-causal finite-state strict-k subclass in the companion bridge, with all channel randomness independent of the source process. Its initial state, gates and transition tables are disclosed; the realized seed and edit mask are hidden. The source starts at Pi. There is no claim for an arbitrary unknown initial-pair law.

For every integer r>=1, the network constructed below has output q_r with

    sup_theta E |q_r(Z)-P_theta,C(X_(N+1)=1 | Z)|
       <= min{1, C_* ((k+1)^2/M)^(1/3) + 2^-r}.

In particular this is the existing log-free statistical rate with an explicit computable beta-dependent constant and additive output error. The constants are intentionally very loose and the resulting nontrivial sample regime may be enormous. No numerical practicality or sharp beta dependence is claimed.

The network has exactly the existing raw displayed-symbol + public normalized-position + synthetic-query input contract, self-inclusive causal mask, all eligible scores zero, no LayerNorm/RMSNorm and a simplex coordinate output. A constant-width option has d=64 and FFN128. Every layer norm, bias norm and reached per-position state norm is absolutely bounded. Detailed paid resources appear in Section 7.

## 2. The actual observable algorithm

Put j=k+1 and a_0=(j^2/M)^(1/3), a=A a_0. These roots describe the analysis; the algorithm does not compute them.

1. If 4096 A^3 j^2 > M, return 1/2.
2. Otherwise count n_1=sum_(t=3)^N Z_t and set h=min{n_1,M-n_1}. If

       h^3 <= 8 A^3 j^2 M^2,

   return the displayed empirical majority, with any fixed public tie rule.
3. Otherwise use the companion note's dyadic approximate fitted posterior q_r^fit, formed from

       theta_hat_u(c)=(C'_uc+1)/(J'_u+2),
       Pi_hat(u)=(J'_u+1)/(M+4).

The first integer comparison is exactly a>1/16. The second is exactly m'=h/M<=2a. All branch decisions are public/data-observable; the source-dependent good event used below is not tested by the network. The large A appears only as charged binary constants in Boolean arithmetic, never as a large affine coefficient or activation.

Let q denote the same algorithm with exact fitted-posterior output on branch 3. Branches 1 and 2 are represented exactly. The implemented network therefore satisfies |q_r(z)-q(z)|<=2^-r on every word, with the companion note's common 1/2 zero-evidence convention.

## 3. Explicit count concentration

The following elementary construction supplies all constants used below. It applies both to unconditional training counts and to their law conditional on a future symbol having positive stationary probability.

### 3.1 One minorized chain

For K>=b Lambda, write K=b Lambda+(1-b)Q. The residual Q preserves Lambda. A complete refresh cycle has length L>=1 with geometric parameter b, independent of its Q trajectory, and centered indicator reward W with stationary mean p=Lambda(f). Conditional Jensen gives, for integer s>=2,

    E|W|^s <= 2p E L^s <= 4p s! b^-s
            <= p s! (4/b)^s,
    E W=0.

Here P(L>x)<=2 exp(-bx) follows from b<=1/2, and integration gives E L^s<=2s!b^-s. Set H_0=4/b. Then

    log E exp(lambda W)
       <= p H_0^2 lambda^2/(1-H_0|lambda|),
       |lambda|<1/H_0.

Let tau be the first complete cycle whose accumulated length reaches the deterministic horizon n. The complete-cycle filtration makes tau a stopping time and tau<=n. Optional stopping of the nonnegative exponential supermartingale gives the same mgf bound for the stopped complete-cycle reward with p replaced by np. Its two-sided tail is

    P(|S_tau|>2H_0 sqrt(npt)+H_0 t)<=2e^-t.

The unobserved remainder after time n is at most 2t/b except with probability e^-t. An arbitrary initial pre-refresh block has the same additional bound. Conditional on that block's length, the remaining deterministic horizon starts from Lambda. These two boundary terms give, for t>=1,

    P(|V-np|>(8/b)[sqrt(npt)+t]) <=4e^-t.

No maximum of all cycle lengths is taken, and no horizon logarithm is introduced.

### 3.2 Training counts and future conditioning

For the stationary order-two source, the triple chain has invariant law

    Lambda(a,b,c)=Pi(a,b)theta_ab(c)

and T^3>=b Lambda. Its stationary time reversal has the same minorization on positive support. Conditioning on X_(N+1)=c changes only the initial law of the reversed chain, not its reverse kernel. Splitting the M training triple positions into three reverse residue classes therefore permits Section 3.1 for each class, including arbitrary initial laws. Triple, context and generated-symbol counts are indicator counts of these states. Summing the three bounds and using sum sqrt(n_i)<=sqrt(3M)<=2sqrt M gives

    P(|V-v|>D_c[sqrt(vt)+t])<=12e^-t,
    v=Mp, t>=1.                                      (F1)

This arbitrary-start step is internal to the concentration proof. The actual source experiment still has stationary initialization.

### 3.3 A single explicit envelope H

Let E be unit exponential and T=E+4. Equation (F1) implies stochastic domination

    |V-v| <=_st D_c[sqrt(vT)+T].

Since ET=5 and ET^2=26,

    E(V-v)^2<=64D_c^2(v+1).

For v>=1, the dominating variable divided by sqrt v is at most 2D_c T. With alpha=2D_c lambda sqrt v<=1/2,

    E exp(lambda|V-v|)<=e^(4alpha)/(1-alpha)
                     <=1+128alpha
                     =1+256D_c lambda sqrt v.

Thus the mgf estimate holds for lambda<=1/(4D_c sqrt v).

For v>=64D_c^2, put t=v/(64D_c^2) in (F1). Its threshold is strictly below v/4, so

    P(V<=3v/4)<=12 exp[-v/(64D_c^2)].

The chosen H=2^20D_c^2 consequently gives the following single envelope, under both required count laws:

    E(V-v)^2 <= H(v+1),
    E exp(lambda|V-v|) <=1+H lambda sqrt v
       for v>=1 and 0<=lambda<=1/(H sqrt v),
    P(V<=3v/4) <= H exp(-v/H) for every v>=0.       (F2)

For v<64D_c^2 the last inequality is trivial because its right side exceeds one. No unspecified beta-dependent constant remains in (F2).

## 4. Explicit fitted log-ratio bounds

Write m=min{pi(0),pi(1)}. The all-state certificate and stationarity give

    theta_u(c)>=b pi(c),
    Pi(u)>=b m^2,
    Pi(u)theta_u(c)>=b^2 m^3.

Let w=M Pi(u), v=M Pi(u)theta_u(c), and use the displayed-data event

    G={|b'-pi(1)|<=m/2 and |J'_u-MPi(u)|<=MPi(u)/3
         for all four contexts},
    b'=n_1/M.

Suppose the nontrivial branch a<=1/16 is active and m>=a. Then

    M m^3>=A^3 j^2,
    v>=b^2 A^3 j^2>=B_* j^2,
    w>=v.

These imply w>=24k, w>=12 and M m>=4k. Therefore the displayed denominator ratio (J'_u+2)/w lies in [1/2,3/2] on G, and all original geometric side conditions hold.

For 1<=ell<=256j, put S=|log(theta_hat_u(c)/theta_u(c))|. On G and the ordinary-numerator event C'_uc+1>=v/2,

    S<=2|C_uc-v|/v+2|J_u-w|/w+10j/v.

Hölder and (F2) at lambda=4ell/v and 4ell/w apply because sqrt v>=sqrt(B_*)j>=1024Hj. Also d=10ell j/v<=1. Hence

    E exp(ell S) on this event, minus its event mass,
       <=12H ell/sqrt v+20ell j/v,

where a precise safe route is to dominate the event contribution by E[exp(ell U)-1] for the displayed upper U. The latter is at most the displayed expression.

On G and C'_uc+1<v/2, add-one gives exp(S)<=3v/2. This event implies C_uc<=3v/4 because v>=12j. Since log(3v/2)<=2sqrt v for v>=1,

    ell log(3v/2)<=512j sqrt v<=v/(2H).

Its contribution is therefore at most H exp[-v/(2H)]<=H^2 ell/sqrt v. Combining both branches gives

    E[(exp(ell S)-1)1_G]
       <=64H^2[ell/sqrt v+ell j/v].               (F3)

For D_u=|log(Pi_hat(u)/Pi(u))|, the existing direct algebra on G gives

    D_u<=2|J_u-w|/w+8j/w.

The same mgf calculation yields the identical safe envelope

    E[(exp(ell D_u)-1)1_G]
       <=64H^2[ell/sqrt w+ell j/w].               (F4)

All expectations in (F3)-(F4) may be unconditional or future-symbol-conditioned. No count law is conditioned on G in applying (F2).

## 5. Explicit risk of the exact full estimator

The reviewed posterior likelihood argument is unchanged: two clean preimages of one displayed word differ in at most 2k coordinates, so the fitted/true likelihood-ratio oscillation is at most 12k S_max+2D_max. Future blindness and the fitted successor factors give, for a true minority c_*,

    |q_fit(z)(c_*)-p(z)|
       <=p(z)[exp((12k+1)S_max+2D_max)-1],
    p(z)=P(X_(N+1)=c_*|Z=z).

Apply twelve-factor Hölder using the eight transition and four initial-law coordinates, truncated by G. The largest exponent is 12(12k+1)<=156j. Equations (F3)-(F4) and v>=b^2 M m^3 imply, with

    K_*=2^14 H^2/b^2,
    delta_m=j/sqrt(Mm^3)+j^2/(Mm^3),

that the truncated exponential factor has future-minority-conditioned expectation at most K_* delta_m. Since G and the errors are Z-measurable, the exact identity

    E[p(Z)F(Z)]=m E[F(Z)|X_(N+1)=c_*]

then bounds posterior-branch loss on G by

    K_*[j/(sqrt M sqrt m)+j^2/(M m^2)].          (F5)

This is the existing reviewed minority-weighting argument, now with displayed constants. It does not replace p(z) by m pointwise.

For m>=a, the unconditional second moment in (F2) and the pathwise edit inequalities imply

    P(G^c)<=256H/(b M m^2).                      (F6)

Indeed four context failures each cost at most 32H/w after the 2k shift; the frequency failure costs at most 32H/(Mm) after the k/M shift. The stated envelope covers their sum.

On G, choosing the majority branch implies m<=4a, and that majority is correct because a<=1/16. Its integrated loss is at most 4a. Equation (F5), m>=A a_0, and (F6) therefore give

    risk <= [4A+2K_*+256H/b]a_0 <=5A a_0.       (F7)

The last inequality follows immediately from A=2^40H^4/b^2 and H>=2.

For m<a, k/M<=a/2 follows directly from k<=M and A>=2. On |b'-pi(1)|<=a, the correct-majority branch is selected and its integrated loss is at most m<a. The bad event has probability at most

    4H(Mm+1)/(M^2 a^2)
       <=4H[1/(Ma)+1/(M^2a^2)]<=8H a_0.

The final inequality uses M a_0^3=j^2, A>=1 and active-branch a_0<1. Thus this case costs at most (A+8H)a_0<=2A a_0. If m=0, the clean history and future are constant and the same majority conclusion follows directly from the edit bound.

Finally, if a>1/16, the 1/2 output has loss at most 1/2<8A a_0. Every output belongs to [0,1]. Combining all cases establishes

    E|q(Z)-P(X_(N+1)=1|Z)|<=min{1,8A a_0}.       (F8)

Adding the deterministic output approximation error proves Section 1's claim. No unverified all-initial-law statistical extension or free evidence lower bound is used.

## 6. Exact Boolean implementation of both branches

The fitted-posterior DP and its guarded integer division are unchanged. Add the generated-symbol counter n_1, its complement M-n_1, integer minimum, cubing and two comparisons from Section 2. Use their Boolean output flags to select an r-bit output word for 1/2, empirical-majority 0/1, or the fitted posterior. Include the possible integer output bit 1. The flags and selection are ordinary fixed fan-in Boolean circuits; no real-valued branch oracle appears.

The large numerical thresholds have binary length O(u+log(N+1)). For example A^3 has 480+30u leading exponent, and multiplication by j^2 M^2 adds only O(log N) bits. Thus A does not force unary-time computation. Its magnitude is paid by its finite binary representation and ordinary bit arithmetic.

The compiled model depends on the supplied beta certificate only through its finite circuit constants/program. Raw inference inputs are unchanged. The network does not receive Pi, theta, the hidden source majority, m, G, or a future-symbol condition.

## 7. Full resource and precision ledger

Let ell be the expanded rational channel-description bit length and retain S,k,N from the companion bridge. Define

    B_base=ell+4(N-1)ceil(log2 N)+ceil(log2(N+2))+r+4,
    B_full=B_base+30u+512,
    R=O(NS^2(k+1)),
    G_full=O((R+N+1)B_full^2),

padding G_full>=N ceil(log2(N+1))+r+u+1. This covers the source fitting, exact rational-channel DP, safe division, every majority/saturation comparison and final output selection. If beta_0 is given as positive numerator/denominator with at most t_beta bits, then u<=t_beta+1, and its computation and the certificate's input length are charged. The construction is polynomial in this finite certificate length, not an oracle model for an arbitrary unnamed real beta.

Two previously reviewed compilations apply without changing the input or causal contract:

1. Growing wire bank: d=O(G_full), L=O(G_full), scalar rational bit length w=O(r+log(N+1)+log(G_full+1)).
2. Two bounded base-four stacks: d=64, FFN128, L=O(N log(N+1)+G_full^2), w=O(G_full+r+log(N+1)).

Both have absolute per-matrix, bias and all-row hidden-state bounds and exactly zero eligible attention scores. All channel and threshold information is charged in constants and the layer program. No extra score gap, unbounded affine coefficient, precomputed count input, arbitrary-real advice, external table oracle or future token is supplied.

The companion ledgers continue to apply with G_full and w: conservative exact-rational dense inference costs O(L(Td^2+T^2d)w^3) bit operations, rolling states O(Tdw) bits, optional materialized scalar attention O(T^2w), and explicit dense parameters O(Ld^2[log(N+1)+log(G_full+1)]) bits (the constant-width stack program can use O(L log(N+1)) coefficient bits). Channel denominator preprocessing, beta-certificate processing, Boolean-circuit generation and full parameter emission are charged separately and remain polynomial in the displayed finite inputs. This is an analytical exact-rational implementation, not a floating-point or executed verification result.

## 8. Scope and remaining questions

This closes the computable-threshold/full-log-free-estimator gap for the paid rational finite-state subclass and stationary source experiment. The proof gives an explicit sufficient constant; it does not optimize that constant or the enormous resulting resource/sample upper bounds.

It does not by itself implement the other endpoint-aware estimator or the public selection needed for the sharp rho interpolation. It does not prove a matching minimax lower restricted to the finite-state channel class. No all-start theorem, pre-LayerNorm implementation, tied-weight theorem, training result, optimal depth/width/precision frontier or generic IEEE robustness is asserted.

For a fixed abstract real beta>0, the statistical theorem remains meaningful. A uniform effective compiler additionally needs a finite certified positive lower bound such as the rational beta_0 used here. Disclosure of an unnamed real constant is not a paid representation.

## 9. Dependencies and evidence

- `KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md` and its independent review: statistical geometry, reverse-count law, posterior oscillation, displayed-data good event and minority-weighted comparison.
- `KNOWN_CHANNEL_finite_state_transformer_bridge.candidate.v1.md` and `KNOWN_CHANNEL_finite_state_constant_width_bridge.addendum.v1.md`: exact fitted-posterior circuit and both bounded-norm Transformer compilations.
- `KNOWN_CHANNEL_finite_state_bridge.independent_review.v1.md`: independent analytical review of those two computational constructions.
- Explicit concentration constants in Section 3 were derived independently by a helper and checked algebraically in this composition. This candidate still requires its own independent review before promotion.
