# Present-time exact-byte analytical attestation

Capture time: 2026-11-05T09:22:29Z (UTC), obtained from the system clock immediately before SHA-256 capture and full document reads in the same inspection command.

Both following files were independently hashed and fully reread at this present inspection. They were not modified.

- Candidate: `./KNOWN_CHANNEL_positive_floor_rho_upper.candidate.v1.md`
  - SHA-256: `4f472df0857c73d4a09dfb380136a3f4f3558c994ba75ea5c3cb6579bcf5f13f`
- Independent review: `./KNOWN_CHANNEL_positive_floor_rho_upper.independent_audit.v1.md`
  - SHA-256: `fdce59e69f7d84d755fc3224c60243d522cf2110c508258e06bba945b83b2e82`

My independent analytical approval applies to these exact current bytes. The candidate's theorem (2) and proof in Sections 2–7, equations (3)–(16), are sound under the explicitly stated stationary binary second-order, fixed positive public transition-floor, disclosed source-independent future-blind strict-Hamming-budget channel, and per-clean-word endpoint-probability assumptions. The independent review accurately records the substantive checks and their scope. No outstanding mathematical correction was identified.

The current candidate includes both final clarifications: equation (3) explicitly treats exponent zero as one for h=0 and h=1 when gamma=1; Section 5 restricts posterior normalization to nonempty channel preimages and defines the predictor arbitrarily on impossible outputs. Its introductory review-status wording and final provenance paragraph are also included in the exact bytes attested here.

This is a new present-time hash capture and approval. It does not assert that these digests were captured at any earlier review timestamp, and does not retroactively supply a historical byte-level binding. The earlier review's read timestamps remain statements about those reads, not historical captures of the hashes above.

Scope limits: this is mathematical analytical review, not formal verification or external peer review. It does not establish matching lower bounds, optimality, uniformity as eta vanishes, computational efficiency, neural or architectural implementation, or an extension from a per-word endpoint certificate to a merely marginal endpoint bound. No scientific executable checks, numerical experiments, external publication, or public writes were performed. Hashing and document inspection are integrity operations only.

The two originals are preserved. A subsequent integrity read will rehash them alongside this new attestation; the resulting digests are reported separately rather than modifying either original.
