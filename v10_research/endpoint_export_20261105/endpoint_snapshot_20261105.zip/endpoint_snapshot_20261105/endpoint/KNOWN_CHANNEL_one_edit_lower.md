# One raw edit can preserve a known-channel posterior prediction floor

Date: 2026-11-05 UTC. Mathematical analysis only. No scientific executable checks, public write, external novelty claim, or formal verification.

## Results

For a known, source-independent, future-blind observation channel, unknown-source posterior prediction can have a nonvanishing endpoint term with just ONE permitted raw-token edit:

1. For K>=4 and stationary sources, one explicitly disclosed channel and two D2(beta) sources give minimax risk at least rho(1-beta)/64.
2. For K=2 and arbitrary initial pair law, one explicitly disclosed channel gives risk at least rho(1-beta)/8 even if the transition table is fully known; only the initial pair law is unknown.

The first statement embeds into every K>=5. The second is not a stationary-source theorem. Both respect the strict per-input-word endpoint-change bound rho. These are existential lower bounds for specific known channels, not lower bounds for every channel. They apply for every k>=1 because one-edit channels are admissible under larger upper budgets.

The parameter rho bounds the probability of changing the terminal pair, not the probability of making any edit. Deterministic interior erasure is permitted even when rho=0. A bound on the probability of any corruption would define a different channel class.

Throughout, beta,rho are in [0,1], M>=64 and N=M+2. The target for each FIXED source, initial law and channel is

    p_(theta,mu,C)(Z)=Law(X_(N+1) | Z)
                    =E[theta_(S(X)) | Z],
    S(X)=(X_(N-1),X_N).

The next symbol is generated from the original clean terminal state. The channel and its random seed are future-blind. Revealing the channel means revealing its stochastic algorithm, not its realized seed, edit mask or hidden branch. A prior over source hypotheses is used only to prove a minimax lower, not to redefine the target as a prior-averaged predictive law.

## 1. Posterior-overlap calculation used in both constructions

Suppose, after conditioning on common observed prefix information, the original terminal bit B has probability

    r=P(B=1)=1/2+alpha(2b-1),
    0<=alpha<=1/4,

where b is an observed preceding bit. The displayed terminal bit is W=B xor A. Under source hypothesis i, A is independent of B with probability t_i of being one. Put d=|t_0-t_1|. Then

    l_i(1)=P_i(W=1)=r+(1-2r)t_i,
    l_i(0)=1-l_i(1).

The posterior probabilities of B=1 are r(1-t_i)/l_i(1) for W=1 and rt_i/l_i(0) for W=0. If the next-bit law given B is Bernoulli(1/2+alpha(2B-1)), its source-specific predictive means a_i(w) satisfy

    |a_0(w)-a_1(w)|
       =2alpha r(1-r)d/[l_0(w)l_1(w)].                 (O1)

All l_i(w) lie between 1/2-alpha and 1/2+alpha. Thus

    sum_w min(l_0(w),l_1(w)) |a_0(w)-a_1(w)|
       >=4alpha r(1-r)d/(1/2+alpha)
       =2alpha(1-2alpha)d.                            (O2)

For any estimator q, independently randomized or not, its two risks obey

    Risk_0(q)+Risk_1(q)
       >= integral min(dP_0^Z,dP_1^Z) TV(p_0(Z),p_1(Z)). (O3)

Consequently each shared observation factor of mass h, followed by the two W laws, contributes at least h alpha(1-2alpha)d to the maximum risk. When additional factors differ, use min(ab,cd)>=min(a,c)min(b,d). The complete observation laws need not coincide.

## 2. Stationary K>=4: the nuisance count selects which symbol is edited

### Source family

Use four designated symbols (u,v) in {0,1}^2. Set

    delta=1-beta,
    alpha=min(delta/2,1/4),
    p_0=0, p_1=1/M.

Under source i, U_t is IID Bernoulli(p_i). Independently, V_t is a stationary symmetric binary Markov chain with

    Q(v,v)=1/2+alpha,
    Q(v,1-v)=1/2-alpha.

For a designated symbol (u,v), define

    T_i((u,v),(u',v'))=nu_i(u')Q(v,v'),
    pi_i(u',v')=nu_i(u')/2.

From any unused alphabet symbol, define the next distribution to be pi_i. No source transition generates unused symbols. Use the second-order table theta_(a,b)=T_i(b,.) with stationary pair initialization Pi_i(c,d)=pi_i(c)T_i(c,d).

For every starting symbol b and supported c,

    T_i(b,c)>=(1-2alpha)pi_i(c).

Therefore the all-state certificate holds, including starting and target pairs outside stationary support:

    P_i^2((a,b),(c,d))
       =T_i(b,c)T_i(c,d)
       >=(1-2alpha)Pi_i(c,d)>=beta Pi_i(c,d).           (O4)

The two transition tables are separated by only 1/M in maximum-row TV.

### Known channel

On any input containing an undesignated symbol, return the word unchanged. Otherwise count the U bits in positions 1,...,N-2:

    S=sum_(t=1)^(N-2) U_t.

This block has M symbols and excludes BOTH terminal symbols. Apply exactly one of these mutually exclusive branches:

- If S=0, flip only the final V coordinate with probability rho, independently; otherwise return the input unchanged.
- If S=1, deterministically change its sole U=1 to U=0, keeping that token's V coordinate unchanged.
- If S>=2, return the input unchanged.

Every input/output realization differs in at most one token. On S=0 the endpoint-change probability is rho. On S=1 the edit is strictly outside the terminal pair, so that probability is zero. All other cases are identity. The kernel is source-independent, knows neither p_i nor the future, and is fully disclosed to the estimator.

The hidden branch is material: the predictor does not receive an edit mask telling it whether an internal erasure or a terminal flip occurred.

### Observable overlap and predictive targets

Let E be the observed event that all U bits in positions 1,...,N-2 are zero. Under source 0, E has probability one and the hidden terminal-flip bit A is Bernoulli(rho). Under source 1, write p=1/M and

    w0=(1-p)^M,
    w1=Mp(1-p)^(M-1)=(1-p)^(M-1),
    g=P_1(E)=w0+w1.

Exactly the original count-zero and count-one branches produce E. The former flips the terminal V bit with probability rho; the latter never flips it. Hence on E

    t_0=rho,
    t_1=rho w0/g,
    d=t_0-t_1=rho w1/g.                               (O5)

The block's displayed U coordinates are deterministically zero. The whole observed V prefix V_1,...,V_(N-1) has a common law under both sources and is independent of S and A. Given its last bit b, B=V_N has the probability r used in section 1.

The only other observed U coordinates are U_(N-1),U_N. They are independent of the block, V process and channel branch. Restricting them both to zero supplies common mass (1-p)^2, since they are identically zero under source 0. Thus (O2)-(O3) and (O5) imply

    max_i Risk_i(q)
       >=g(1-p)^2 alpha(1-2alpha)d
       =rho(1-1/M)^(M+1)alpha(1-2alpha).               (O6)

For M>=2, (1-1/M)^M>=1/4 and 1-1/M>=1/2. Also alpha>=delta/4 and 1-2alpha>=1/2. Consequently

    max_i Risk_i(q)>=rho delta/64.                    (O7)

The source-0 and source-1 full observation laws are not identical. The lower uses their overlapping zero-block event and the exact terminal-bit posterior difference.

### Optional strictly positive four-symbol variant

For K=4, the floor does not require a zero transition probability. Keep the same channel and take

    p_0=1/(2M), p_1=1/M.

Both source tables now have full support. For a generic p let

    g(p)=P_p(S<=1)=(1-p)^(M-1)[1+(M-1)p],
    t(p)=rho(1-p)/[1+(M-1)p].

Exact subtraction gives

    t(p_0)-t(p_1)
       =rho M(p_1-p_0)
          /([1+(M-1)p_0][1+(M-1)p_1])>=rho/6.

The count event decreases with p, so min_i g(p_i)=g(p_1)>=2(1-1/M)^M>=1/2. The common mass of the two outside U bits being zero is at least (1-1/M)^2>=3/4 for M>=64. Inserting these three bounds into (O2)-(O3), together with alpha(1-2alpha)>=delta/8, yields

    max_i Risk_i(q)>=rho delta/128.                   (O8)

This is full support for K=4, not a fixed transition-probability floor: some probabilities are of order 1/M. For K>4 the simple embedding still leaves unused symbols.

## 3. Binary arbitrary-start experiment: uncertainty about the initial pair

Use the binary symmetric transition table

    T(v,v)=1/2+alpha,
    T(v,1-v)=1/2-alpha,
    alpha=min((1-beta)/2,1/4),

and homogeneous SECOND-ORDER table theta_(a,b)=T(b,.). Its qualifying stationary pair law is the same as in EPR001, and P^2>=beta Pi on every pair.

Compare two arbitrary initial pair laws:

    mu_0: X_1=0 and X_2 is uniform,
    mu_1: X_1=1 and X_2 is uniform.

The source's specified transitions begin at X_3. Do not replace these initial pair laws by the first transition of a stationary first-order chain. Both are permitted in the arbitrary-start order-two experiment, and X_2,...,X_N have the same stationary first-order law under both hypotheses.

The transition table theta may be revealed completely to the estimator. Only mu_0 versus mu_1 is unknown. Reveal this fixed channel as well:

- If the clean X_1=0, flip X_N with probability rho and otherwise do nothing.
- If the clean X_1=1, set X_1=0 deterministically and do not touch the endpoint.

The branches are mutually exclusive and use at most one edit. Since N>=3, the first position lies outside the terminal pair, so the per-word endpoint-change probability is at most rho. The algorithm is source-independent and future-blind.

The observed first bit is always zero. The remaining prefix X_2,...,X_(N-1) has a common law. Conditional on that prefix, the original B=X_N has probability r as in section 1. Its displayed version is B xor A with

    t_0=rho, t_1=0.

Therefore (O2)-(O3), now with no additional observation-factor loss, give

    max_i Risk_i(q)>=rho alpha(1-2alpha)>=rho(1-beta)/8. (O9)

This does not contradict exact prediction when theta, mu and C are all known: here mu is expressly hidden. Nor does it establish a stationary binary lower, because the two initial pair laws are not the qualifying stationary initialization.

## Scope of the remaining question

- These two constructions close the question of whether a known-channel floor can persist at k=o(sqrt(M)): yes, at k=1 for stationary K>=4 and for binary arbitrary-start sources.
- Stationary K=2 is not covered by either construction. Stationary K=3 is also not covered here.
- The first construction exploits arbitrarily rare nuisance symbols. Its full-support variant excludes any fixed positive lower bound on all transition probabilities as M grows.
- The binary arbitrary-start construction exploits uncertainty in the initial pair and an offline channel that uses that pair to decide whether to modify the remote endpoint.
- No conclusion is asserted here for k=0, when the endpoint cannot change, or for source/channel experiments revealing the actual edit mask or random seed.
- These are mathematical statistical statements; no efficient posterior computation or neural implementation is established.

## Context

This note sharpens `KNOWN_CHANNEL_posterior_counterexample.md`, whose earlier construction needed O(sqrt(M)) edits. The earlier construction remains valid, but its edit threshold is not a lower limit for the broad D2(beta) source class. The actual-prediction convention and channel/source quantifiers are those in `POSTERIOR_PREDICTION_channel_identifiability.md`.
