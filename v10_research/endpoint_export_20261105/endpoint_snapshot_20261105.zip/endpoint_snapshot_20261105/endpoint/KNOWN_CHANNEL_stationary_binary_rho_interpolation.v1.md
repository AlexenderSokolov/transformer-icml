# Stationary binary known-channel prediction: sharp endpoint-probability interpolation

Date: 2026-11-05 UTC. Pure analytical proof candidate for independent review. No executable scientific checks, public writes, computational-efficiency claim, all-initial-law extension, moving-beta theorem, or external novelty certification.

## 1. Result and quantifiers

Fix 0<beta<1. Let N=M+2, integer 0<=k<=M, and 0<=rho<=1. The source is a stationary binary homogeneous second-order chain satisfying the all-state certificate P^2(u,v)>=beta Pi(v). A channel C is disclosed, source independent and future blind; every realization has Hamming distance at most k from its input; and for every input word x,

    P_C{S(Z)!=S(x) | x} <= rho,
    S(x)=(x_(N-1),x_N).

Let R_beta(M,k,rho) denote the worst-disclosed-channel minimax expected absolute prediction loss for the source-specific target

    p_(theta,C)(Z)=P_(theta,C)(X_(N+1)=1 | Z).

Thus an estimator can depend on the disclosed C, and each lower bound below uses one common channel for its two source alternatives. The channel, source alternatives and estimator may depend on the horizon and public budgets. There is no mixture over source hypotheses in the target.

Put

    s=M^(-1/2),
    a=0                                      if k=0,
    a=min{(k^2/M)^(1/3),1}                    if k>=1,
    e=max{sqrt(beta),1/M},
    F_beta=0                                 if k=0,
    F_beta=(k/M)[1+log(1+1/(e k))]            if k>=1.

For all M>=M_beta, uniformly over k and rho,

    R_beta(M,k,rho)
      =Theta_beta(min{1, s+F_beta+min{rho,a}}).       (I1)

Since beta is fixed, F_beta is comparable to k/M with beta-dependent constants. Equivalently,

    R_beta(M,k,rho)
      =Theta_beta(min{1, M^(-1/2)+k/M
                           +min{rho,(k^2/M)^(1/3),1}}),  (I2)

with the endpoint term defined as zero at k=0. The inner 1 in (I2) is redundant for rho<=1 but records the saturation of a.

The new point is the uniform rho dependence. The existing rare-budget lower rho*a is not the sharp interpolation. The same rare construction, examined on displayed terminal bit w=1 rather than w=0, supplies rho*a/(rho+a), which is comparable to min{rho,a}. The upper follows from two existing reviewed upper bounds, with no conditioning on an adaptive edit mode.

## 2. Dependencies and their exact scope

The following existing analytical results are used:

1. `KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md`, with review `KNOWN_CHANNEL_stationary_binary_logfree_upper_independent_review.v1.md`: for k>=1, every disclosed allowed channel admits a posterior predictor with risk at most

       C_beta min{1, ((k+1)^2/M)^(1/3)}.

2. `EPR001_endpoint_probability_interpolation.md`, with review `EPR001_independent_analytical_review.md`: a channel-blind predictor q_lat satisfies the unconditional latent actual-terminal-row bound

       E |q_lat(Z)-theta_(S(X))(1)|
         <= C [s+F_beta+rho(1-beta)]

   up to a unit cap. Its proof repairs the endpoint-changing channel rather than conditioning a protected-risk theorem on the endpoint-preservation event.

3. `KNOWN_CHANNEL_stationary_binary_rare_one_edit_lower.v1.md` and `KNOWN_CHANNEL_stationary_binary_rare_budget_lower.v1.md`, with their corresponding independent reviews: the exact rare-family sources, channels, output masses, conditional targets and scaffold overlaps used in Section 4 below.

4. The identity-channel clean lower, for example Section 10 of `KNOWN_CHANNEL_stationary_binary_quantitative_lower.v1.md`: R_beta>=c_beta s uniformly over the budgets.

Only the first two dependencies are used for the upper. The protected corruption lower in EPR001 is NOT imported into this disclosed-channel experiment. Section 5 constructs an explicit common known protected channel instead.

## 3. Upper: conditional Jensen, then deterministic estimator selection

Future blindness gives the exact identity

    p_(theta,C)(Z)=E[theta_(S(X))(1) | Z].

Because q_lat is Z measurable, conditional Jensen implies

    E |q_lat(Z)-p_(theta,C)(Z)|
      <= E |q_lat(Z)-theta_(S(X))(1)|
      <= C [s+F_beta+rho(1-beta)].                    (I3)

This transfer is from a latent-target UPPER to a posterior-target upper. It does not transfer latent-target lower bounds. It conditions only the final scalar inequality on the observation sigma field; it does not assert that a clean-source statistical law remains valid after conditioning on a channel-selected edit mode.

For k>=1, (k+1)<=2k, so the log-free upper gives a second estimator with risk at most C_beta a. Take the better of these two estimators using their known bounds and public beta,M,k,rho. Neither the channel seed nor its realized edit mode is observed or used in selecting the estimator. Their constants are fixed mathematical constants depending at most on beta.

Writing b=s+F_beta and increasing C_beta, the risk is at most

    C_beta min{1,a,b+rho}
      <= C_beta min{1,b+min{rho,a}}.                  (I4)

The last inequality is elementary: if rho<=a, use b+rho; if rho>a, use a. At k=0, use the established clean estimator directly. This proves the upper in (I1).

## 4. Sharpening the rare-family lower uniformly in rho

### 4.1 Existing exact experiment

Keep the reviewed rare source family

    d=(1-beta)/64, r=4d,
    theta_q(00)(1)=theta_q(01)(1)=t,
    theta_q(10)(1)=r,
    theta_q(11)(1)=q t,

with its exact stationary pair law. Fix tau>0 sufficiently small depending only on beta to satisfy BOTH reviewed one-edit and general-budget constructions, and enlarge their common onset horizon M_beta accordingly. For k=1 use

    t=tau M^(-1/3), q_-=1-d, q_+=1+d.

For k>=2 use

    h=min{k-1,floor(sqrt(M))},
    t=tau(h^2/M)^(1/3), q_-=1-d/h, q_+=1+d/h.

In either case t<=r/2 and t<=1/2. All-state D2(beta), stationary initialization, source independence, future blindness, the all-word strict edit budget and the per-word endpoint bound are already verified for these exact constructions. Nothing in the channel is changed here.

On the reviewed typical scaffold event D=A intersect T, there is a retained scaffold H and a hidden clean penultimate bit B which, conditional on H, is Ber(t). The future row is t+(r-t)B. After the channel's identifiable normalization/erasure branch, the displayed bit is W=B xor E and

    P(E=1 | H, branch)=T_q=rho v_q.

Conditional independence of B and the hidden edit-mode variable is an exact likelihood-factorization statement in the existing construction, not an assumption about generic adaptive channels.

The branch output masses have the form

    P_q^Z(H,y,w)=f_q(H) g_q(H) u_H(y) ell_q(w),    (I5)

where u_H is a common probability mass on normalized displayed configurations. For k=1 it is a point mass on the all-zero eligible configuration. For k>=2 it is uniform on configurations of the known normalized count c. Existing uniform constants satisfy

    sum_(H in D) min{f_+(H),f_-(H)} >=3/4,
    g_q(H)>=g_*>0,
    |v_+(H)-v_-(H)|>=v_*>0.                        (I6)

Constants may differ between k=1 and k>=2; take their minima. They depend only on beta and are uniform over k,rho and M>=M_beta. The sign of v_+-v_- differs between the one-edit and bin constructions, but only its absolute value is used.

For w=1 the exact displayed mass and clean-endpoint posterior are

    ell_q(1)=t(1-T_q)+(1-t)T_q
            =t+(1-2t)rho v_q,
    F_1(t,T_q)=t(1-T_q)/ell_q(1),
    p_q(1|H,y,1)=t+(r-t)F_1(t,T_q).                (I7)

In particular ell_q(1)>0 because t>0. The formula is valid also at rho=0. Since 0<=v_q<=1 and t<=1/2,

    ell_q(1)<=t+rho.                                (I8)

### 4.2 Keep the observation mass with the posterior gap

Exact subtraction gives

    |p_+(1|H,y,1)-p_-(1|H,y,1)|
      =(r-t)t(1-t)rho|v_+-v_-|
            /[ell_+(1)ell_-(1)].                    (I9)

Multiplying by the minimum of the two output masses is crucial. From (I5),

    min{P_+^Z(H,y,1),P_-^Z(H,y,1)}
      >=min{f_+(H),f_-(H)} g_* u_H(y)
                                           min{ell_+(1),ell_-(1)}.

Consequently, their product with (I9) is at least

    min{f_+(H),f_-(H)} g_* u_H(y)
      (r-t)t(1-t)rho|v_+-v_-|
                       /max{ell_+(1),ell_-(1)}

    >=min{f_+(H),f_-(H)} g_* u_H(y)
                         (r v_*/4) rho t/(t+rho).   (I10)

The small displayed mass is retained exactly. There is no claim of constant-probability w=1 outputs, no deletion of a rare-output factor, and no multiplication of a conditional gap by an unrelated overlap.

For arbitrary predictor Q, the two-source absolute-loss inequality is

    Risk_+(Q)+Risk_-(Q)
      >=sum_z min{P_+^Z(z),P_-^Z(z)}|p_+(z)-p_-(z)|.

Sum (I10) over y (whose common mass sums to one) and H in D, use (I6), and divide by two. This proves

    max{Risk_+(Q),Risk_-(Q)}
      >=(3g_*r v_*/32) rho t/(t+rho).                (I11)

No nuisance source-row difference occurs here: the two possible terminal rows t and r are the same under both alternatives. Only the posterior weight on B changes.

### 4.3 Convert t into the budget rate

For k>=2 and M>=4,

    h>=min{k,sqrt(M)}/2.

Thus, with constants depending only on beta, t is comparable to a. For k=1 the same comparison follows directly from t=tau M^(-1/3). Since

    rho t/(rho+t) >= (1/2)min{rho,t}
                     >=c_beta min{rho,a},

(I11) gives

    R_beta(M,k,rho)>=c_beta min{rho,a}, k>=1.        (I12)

At rho=0 this lower is zero, as it should be. All preceding denominators remain positive, and the same source/channel construction and constants work for arbitrarily small positive rho. At k=0 the endpoint term is defined to be zero and this channel is not invoked.

## 5. A disclosed protected channel supplies the k/M term

This independent construction avoids transferring an undisclosed-channel lower. An iid Bernoulli(p) source is a stationary member of D2(beta) for every beta<=1: its pair kernel obeys P^2(u,v)=Pi_p(v) for all states. Its source-specific posterior future target remains the constant p under every future-blind channel.

The clean lower already supplies c_beta s. If k<8sqrt(M), then k/M<8s, so this also lower-bounds a constant multiple of k/M. It remains to consider k>=8sqrt(M), with M sufficiently large, say M>=4096.

Set

    h=min{k,floor(M/4)}, c=floor(M/2),
    p_-=c/M-h/(4M), p_+=c/M+h/(4M).

Both probabilities lie in [3/8,5/8]. Also h>=4sqrt(M) and h>=k/8. Take the M interior coordinates 1,...,N-2, leaving BOTH terminal coordinates unchanged. Let S be their count of ones. The disclosed channel is:

1. If |S-c|>h, return the input unchanged.
2. Otherwise uniformly normalize the interior count to c by changing exactly |S-c| coordinates, selected uniformly among the required zeros or ones.

This channel is defined on every binary word, uses at most h<=k edits, has endpoint-change probability zero, is source independent and future blind, and is therefore admissible for every rho. The normalized branch is identified by displayed interior count c; unnormalized counts are outside the band and cannot collide with c.

Under source p_i, the interior mean is c plus or minus h/4. Hence

    g_i=P_(p_i){|S-c|<=h}
       >=1-Var(S)/(3h/4)^2
       >=1-4M/(9h^2)
       >=35/36.                                    (I13)

For iid Bernoulli input, conditional on S the interior configuration is uniform. Uniform normalization to count c is permutation invariant, so its displayed law on this branch is the same uniform law U_c under both alternatives. The two unedited terminal bits are independent of the interior and retain their respective Bernoulli(p_i) product laws V_i. Thus branch outputs have masses

    g_i U_c(y) V_i(b_1,b_2).

Each of the four V_i values is at least (3/8)^2=9/64. Therefore the branch observation-law overlap is at least

    min_i g_i sum_(b_1,b_2) min{V_+,V_-}
       >=(35/36)(9/16)>1/2.                        (I14)

The future target gap is exactly p_+-p_-=h/(2M), independent of the displayed word. The two-source loss inequality yields

    max_i Risk_i(Q)>=h/(8M)>=k/(64M).               (I15)

Together with the small-budget clean baseline, this proves R_beta>=c_beta k/M uniformly over k,rho. Finally,

    k/M<=F_beta
       <=[1+log(1+beta^(-1/2))]k/M, k>=1,           (I16)

so the disclosed protected lower also supplies c_beta F_beta for the fixed-beta theorem.

## 6. Assemble the lower and interpret the interpolation

The identity-channel, protected-normalization and rare-endpoint constructions separately give lower bounds proportional to s, F_beta and min{rho,a}. The worst-channel minimax risk is at least their maximum. A maximum of three nonnegative terms is at least one third of their sum. Taking the smaller constants, and then imposing the harmless unit cap, proves the lower half of (I1). This selects one of the separate admissible witnesses; it does not add edit budgets or pretend all three witnesses occur in one experiment.

For 1<=k<=sqrt(M), the protected term k/M is at most s, and the rate simplifies to

    Theta_beta(M^(-1/2)+min{rho,(k^2/M)^(1/3)}).

For k>=sqrt(M), it is

    Theta_beta(min{1,M^(-1/2)+k/M+rho}).

In particular, with k=1 and rho=M^(-1/3), the lower is order M^(-1/3). A hypothetical uniform rate s+F_beta+rho*a would instead be order M^(-1/2), so the linear-product interpolation is false. Rare displayed terminal ones amplify the change in hidden edit-mode probabilities, while their actual observation masses are accounted for exactly by (I10).

The result is for stationary sources and fixed beta in (0,1). Constants and the horizon threshold may deteriorate as beta approaches 0 or 1. It does not prove the displayed F_beta expression with beta-uniform constants, nor extend the rare lower to beta=1. It remains a statistical existence result for an estimator, potentially summing over exponentially many latent histories.
