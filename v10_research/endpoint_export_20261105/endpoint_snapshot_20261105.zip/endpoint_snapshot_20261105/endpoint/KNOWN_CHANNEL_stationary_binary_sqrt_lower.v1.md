# Stationary binary sources: a known-channel floor at square-root edit budgets

Date: 2026-11-05 UTC. Pure mathematical analysis. No executable checks, public write, novelty claim, or computational-efficiency claim. Independent review is reported separately.

## Result and quantifiers

Fix any a>0 and rho in (0,1]. For all sufficiently large M, N=M+2, there is one disclosed, source-independent, future-blind binary observation channel with strict Hamming budget

    k_M = floor(a sqrt(M))+1

and per-input-word terminal-pair-change probability at most rho, and two stationary, genuinely second-order binary sources in D2(1/4), such that every predictor has maximum source-specific posterior prediction risk at least a positive constant c_a rho, independent of M.

The sources have uniformly positive transition entries and differ by O(M^(-1/2)). Their parameters depend on the horizon. The result is a uniform minimax lower, not a pointwise inconsistency claim for one fixed source or a lower for every known channel. The channel is fixed and common to both hypotheses within each experiment. Its public algorithm is the same across horizons, with the explicit horizon-dependent window above.

Together with the stationary binary upper, this proves that the sufficient edit-budget regime k=o(sqrt(M)) cannot be enlarged uniformly at fixed beta=1/4. More generally, the construction can be centered closer to independence to accommodate any fixed beta<1; section 9 gives the parameter choice. It does not identify the sharp risk rate below that threshold.

## 1. A stationary, genuinely order-two source

Set

    e=1/32, q0=3/8, gamma=1/100,
    q_-=q0-gamma/sqrt(M), q_+=q0+gamma/sqrt(M),
    theta_q(a,b)(1)=q+(1-2q)b+e(2a-1).

The coefficient 2e of a is nonzero, so these are genuinely second-order sources. All four pair states have positive stationary mass. Initialize each source in its own unique stationary pair law Pi_q.

For completeness its stationary pair probabilities are explicitly

    Pi_q(0,0)=Pi_q(1,1)=(1-q-e)/[2(1-2e)],
    Pi_q(0,1)=Pi_q(1,0)=(q-e)/[2(1-2e)].

Every transition probability lies in [1/3,2/3]. Complement symmetry gives stationary symbol marginal 1/2. Consequently

    Pi_q(c,d)<=1/3,
    P_q^2((a,b),(c,d))=theta_q(a,b)(c)theta_q(b,c)(d)>=1/9.

Thus the all-state certificate P_q^2(s,t)>=(1/4)Pi_q(t) holds, including every starting pair. This has slack. In fact these bounds imply D2(1/3).

## 2. Editable sites and exact conditional independence

Let J consist of the multiples of 3 in [3,N-3]. A candidate j in J is eligible if

    X_(j-2)=X_(j-1)=X_(j+1)=X_(j+2)=0.

All four neighbors are noncandidates. No order-two likelihood factor contains two candidates. The first two positions and last three positions are not candidates.

Let H retain all coordinates of X_1,...,X_(N-1) except the eligible candidate bits. Eligibility is recoverable from retained coordinates, so H determines the eligible set I and n=|I|. It also retains X_(N-2) and X_(N-1).

Conditional on H, the eligible bits are independent with common probability

    p(q)=A(q)/(A(q)+B(q)),
    A(q)=(q-e)(q+e)(1-q-e),
    B(q)=(1-q+e)^3.                                  (B1)

These products are exactly the three source factors involving an eligible site, for bit one and bit zero respectively. The conditional clean terminal bit B=X_N is independent of these eligible bits and has probability

    r_q(H)=theta_q(X_(N-2),X_(N-1))(1).                (B2)

Put p0=p(q0). The derivative p'(q0) is strictly positive: the derivative of log(A/B) is

    1/(q-e)+1/(q+e)-1/(1-q-e)+3/(1-q+e)>0

near q0. For the last two terms, positivity follows from e<(1-q)/2.

## 3. One source-independent channel

For n>=1 put m_n=floor(n p0), h=floor(a sqrt(M)), and let S be the number of ones among eligible sites. Put G={|S-m_n|<=h}. If n=0 or G fails, return the input word unchanged.

On G:

1. Normalize the eligible bits to exactly m_n ones: if S>m_n choose uniformly S-m_n of their ones and change them to zero; if S<m_n choose uniformly m_n-S of their zeros and change them to one.
2. Let A_sign be one for S>m_n, zero for S<m_n, and an independent fair bit at equality. Draw an independent Bernoulli(rho) bit R, and display W=X_N xor (A_sign R).

Every realization uses at most h+1 raw-token edits. Interior edits are outside the final pair. Conditional on any input, the probability of a final-pair change is at most rho. The channel uses only the observed clean history, the public constants, and independent coins; it is future-blind and does not use the unknown hypothesis.

Let E be the observed event that n>=1 and the displayed eligible count is m_n. Then

    E holds if and only if G ran.                     (B3)

Indeed the normalization guarantees E on G, while identity outside G leaves the count outside its window, hence unequal to its center. No unused alphabet marker or realized edit mask is needed. The channel leaves H unchanged.

## 4. Exact source-specific posterior

Given H, S is Binomial(n,p(q)). Define

    g_q(n)=P_q(G | H),
    v_q(n)=P_q(A_sign=1 | H,G), t_q(n)=rho v_q(n).

Conditional on each count S=s, its bit configuration is uniform. Uniform normalization makes the resulting eligible word uniform on the binomial(n,m_n) words of count m_n, independently of s. Hence, conditional on H,E, the normalized word is independent of A_sign and the terminal clean bit.

For w in {0,1}, let

    ell_q(1)=r_q(1-t_q)+(1-r_q)t_q,
    ell_q(0)=r_q t_q+(1-r_q)(1-t_q).

Both values are at least 1/3. The posterior clean-terminal-one probability is exactly

    F_1(r,t)=r(1-t)/(r(1-t)+(1-r)t),
    F_0(r,t)=rt/(rt+(1-r)(1-t)).                       (B4)

With b=X_(N-1), the actual target for the fixed source q is

    p_q(X_(N+1)=1 | Z)
      =q+e(2b-1)+(1-2q) F_w(r_q(H),t_q(n)).           (B5)

This averages only the latent clean history under that source and the disclosed channel. It does not average over the two source hypotheses.

Writing f_q(H) for the clean retained-scaffold law, each observation on E has exact mass

    f_q(H) g_q(n) [binomial(n,m_n)]^(-1) ell_q(w).     (B6)

## 5. A positive-density supply of eligible sites

The source pair chains have uniform geometric mixing from the common minorization. Each eligibility indicator depends on a fixed window of five symbols. Covariance summation therefore gives Var_q(n)=O(M), uniformly for q=q_-,q_+.

Stationarity and continuity of the finite-state stationary law give

    E_q[n]/M -> nu0
      =(1/3) P_(q0){X_1=X_2=X_4=X_5=0}>0.

For example, the probability of all five symbols being zero is positive because all transitions and stationary pairs are positive. Thus, for c0=nu0/2 and

    T={c0<=n/M<=1/3},

both source probabilities of T tend to one. Rounding the number of candidate sites does not affect this conclusion.

## 6. The hidden sign retains a constant source difference

Uniformly for n/M=v in [c0,1/3], the binomial central limit theorem, or its Berry-Esseen bound, gives

    (S-m_n)/sqrt(M) -> Normal( +/- mu(v), sigma(v)^2),
    mu(v)=v p'(q0) gamma>0,
    sigma(v)^2=v p0(1-p0)>0.                          (B7)

Uniformity follows from n>=c0 M, probabilities staying in a compact subset of (0,1), and the uniform Taylor expansion p(q_+/-)=p0 +/- p'(q0)gamma/sqrt(M)+O(1/M). Tie probabilities vanish uniformly.

Let Y_v have Normal(mu(v),sigma(v)^2) law, and define

    g(v)=P(|Y_v|<=a),
    D(v)=2 P(Y_v>0 | |Y_v|<=a)-1.

Both g(v) and D(v) are continuous and strictly positive on [c0,1/3]. For D, the density at y>0 exceeds that at -y because mu(v)>0. Reflection gives the corresponding negative-mean sign probability.

Therefore there are constants g_*>0 and D_*>0, depending on a but not M, such that for all sufficiently large M and every H in T,

    min(g_+(n),g_-(n))>=g_*/2,
    t_+(n)-t_-(n)>=rho D_*/2.                        (B8)

Here g_* and D_* can be the minima of g and D on the indicated compact interval. This step is analytical and uses no numerical evaluation.

## 7. Scaffolds overlap and posterior targets separate

For Bernoulli transition probabilities in [1/3,2/3],

    KL(Ber(u)||Ber(v)) <= (u-v)^2/[v(1-v)].

The two row probabilities differ by 2gamma/sqrt(M). Chain-rule KL for the clean prefix therefore gives

    KL(P_+^(1:N-1)||P_-^(1:N-1))
       <=18 gamma^2(1+o(1))+o(1).

The stationary initial-pair contribution tends to zero by continuity and positivity. With gamma=1/100, Pinsker and data processing give TV(f_+,f_-)<1/8 for all sufficiently large M. Consequently

    sum_(H in T) min(f_+(H),f_-(H))>=3/4.             (B9)

For a fixed r and either w, exact subtraction in (B4) gives

    |F_w(r,t_+)-F_w(r,t_-)|
       =r(1-r)|t_+-t_-|/[ell_+(w)ell_-(w)]
       >=r(1-r)|t_+-t_-|.                           (B10)

First evaluate (B5) with q0 and r_0(H), retaining its actual t_+ or t_-. Since 1-2q0=1/4 and r_0 is in [1/3,2/3], their separation is at least |t_+-t_-|/18. Replacing q0,r0 by q_+,r_+ or q_-,r_- changes the two targets by O(M^(-1/2)), uniformly in H,w,t. All denominators stay at least 1/3. Thus for all sufficiently large M, uniformly on E and T,

    |p_+(1|Z)-p_-(1|Z)|>=rho D_*/72.                (B11)

## 8. Risk lower bound

For any estimator, its two expected TV risks satisfy the standard overlap inequality

    Risk_+ + Risk_- >= sum_z min(P_+^Z(z),P_-^Z(z))
                                  |p_+(1|z)-p_-(1|z)|.

Use (B6), sum over normalized words, and sum over w. Since each ell_q(w)>=1/3, (B8)-(B9) give observation overlap on E and T at least

    (2/3)(g_*/2)(3/4)=g_*/4.

Then (B11) yields

    max(Risk_+,Risk_-)>=rho g_* D_*/576>0.            (B12)

The sufficiently large horizon may depend on a and rho. The constant g_*D_*/576 is independent of M.

## 9. Any fixed beta<1

The explicit fractions above prove the requested fixed-positive-beta counterexample. For a general fixed beta in (0,1), choose fixed alpha>0 and e>0 with s=alpha+e sufficiently small that

    (1-2s)^2/(1+2s)>beta,

and put q0=1/2-alpha. Keep e<(1-q0)/2 and q0>e. The source remains theta_q(a,b)(1)=q+(1-2q)b+e(2a-1). Complement symmetry still gives symbol marginal 1/2. At the center, all entries lie in [1/2-s,1/2+s], hence

    P_q0^2(s,t)/Pi_q0(t)
      >=2(1/2-s)^2/(1/2+s)
       =(1-2s)^2/(1+2s)>beta.

An explicit valid choice is alpha=e=(1-beta)/32. Then s=(1-beta)/16 and, writing x=2s=(1-beta)/8,

    (1-x)^2/(1+x)=1-3x+4x^2/(1+x)>beta.

Continuity preserves the certificate at q0 +/- gamma/sqrt(M) for all large M. The genuine order-two coefficient e and endpoint signal 1-2q0=2alpha are strictly positive. Formula (B1) and its positive derivative remain valid. Choose gamma>0 small enough to keep clean-prefix TV below 1/8. Every subsequent argument holds with beta-dependent positive constants. Thus every fixed beta<1 and fixed rho>0 admits a nonzero floor at k=floor(a sqrt(M))+1.

## Scope

- This gives the sharp order of the uniform-consistency budget threshold: k=o(sqrt(M)) is sufficient, and any sequence failing this has a subsequence with a positive minimax lower (choose a smaller fixed a along that subsequence). The beta=1 case is not covered by the lower.
- The threshold statement fixes beta in (0,1) and rho>0. At beta=1, equality P^2(s,.)=Pi and summing over the second target coordinate force theta_s=pi for every pair s. The source is then iid, its actual next-symbol target is pi, and the corrupted empirical frequency has risk at most 1/(2 sqrt(M))+k/M. Thus the beta=1 boundary is different.
- It does not prove a sharp minimax rate for k=o(sqrt(M)), nor a nonzero floor at fixed k.
- The lower uses horizon-varying local source alternatives and a horizon-indexed known channel. It does not assert pointwise inconsistency for one fixed source.
- The source is stationary, binary, and genuinely second order, with a fixed positive transition floor. No rare symbol or arbitrary initial-law uncertainty is used.
- No channel seed, edit mask, or hidden branch is revealed. Revealing those would define a different experiment.
- There is no computational-efficiency claim and no executable confirmation.
