# Independent analytical review: binary disjoint-bin quantitative lower

Date: 2026-11-05 UTC. Present-time clock check: 04:36:00 UTC; the final candidate digest and clarified parameter ranges were checked immediately afterward.

## Finding and exact file binding

The quantitative lower is valid. I found no substantive gap in (Q1)-(Q23), including the strict channel construction, central-bin overlap, finite covariance argument, small-signal case split, uniformity in rho, and matching fixed-floor subclass consequence.

Reviewed candidate:

    KNOWN_CHANNEL_stationary_binary_quantitative_lower.v1.md
    SHA-256: 2c7995314aaf395ae6bbf0dbd9bff671c83554b9d93a85241875a5d85b6ed54a

The complete draft was read. The final clarification making the section 11 parameter ranges explicit was rechecked, and the author confirmed that the file is frozen. This is a present-time binding to the exact current candidate, not a historical digest claim.

For fixed 0<beta<1, the proved lower is

    c_beta [M^(-1/2)+rho min{k/sqrt(M),1}],

for every sufficiently large M, uniformly over all allowed integer budgets k and rho in [0,1]. The horizon threshold and constant can be chosen independently of k and rho. The cap is correctly outside rho.

For fixed beta, fixed eta in (0,1/2), and fixed rho>0, combining this proof with the previously reviewed positive-floor upper gives the matching restricted-class rate

    Theta_(beta,eta,rho)(min{1,(k+1)/sqrt(M)}).

This matching rate is for D2(beta) intersected with the fixed transition-floor class. The sharp risk rate for the entire stationary binary D2(beta) class remains open.

This is mathematical review, not formal verification, external peer review, or novelty certification. Tools were used only for document reads, file hashing, and writing this review. No scientific executable checks, numerical experiments, or public writes occurred.

## 1. Source, scaffold, and common local alternatives

The source and conditional-factorization calculations inherited from the square-root lower remain valid. The explicit stationary pair law in (Q2) solves the stationarity equations, and complement symmetry gives a stationary symbol marginal of one half. Since e>0, these are genuinely order-two sources.

With alpha=e=(1-beta)/32, the center has an all-state D2(beta) certificate with strict slack. Continuity preserves it for the local interval at all sufficiently large M. All transition entries remain in [1/3,2/3]. The two-step certificate concerns every pair state, not only typical contexts.

The KL calculation is correct: a transition-coordinate difference of 2gamma/sqrt(M), with Bernoulli denominator at least 2/9, costs at most 18gamma^2/M per transition. The stationary initial-pair contribution tends to zero. Gamma=1/100 therefore gives TV at most 1/8 after enlarging a beta-dependent horizon threshold.

Candidates are spaced by three, no historical likelihood factor contains two candidates, and their four eligibility neighbors are retained noncandidate positions. Conditional on H, eligible bits are exactly IID Bernoulli(p(q)), with the displayed three-factor ratio A/B. The terminal clean bit depends only on retained coordinates and is conditionally independent of those bits.

The log-odds derivative (Q6) is positive in a fixed neighborhood. All neighborhood constants, the positive eligible-site density, and the O(M) occupation variance can be selected independently of k and rho. This is important for the uniform quantifiers later in the theorem.

## 2. Strict per-word channel budget and collision handling

For k>=2, h=min{k-1,floor(sqrt(M))} is at least one, and every full bin has 2h+1 count values with center c_j. Uniform count normalization changes exactly |S-c_j|<=h eligible bits. The terminal XOR changes at most one more token. Thus every realization respects h+1<=k, without relying on an average budget.

All interior edits lie outside the final pair. Conditional on any complete input, a terminal change occurs with probability at most rho because it requires the independent Bernoulli(rho) trigger. The per-word endpoint requirement is therefore satisfied.

The full bins are disjoint. Their centers lie inside their own bins and are distinct. Every count in the unnormalized upper remainder exceeds every full-bin center. Hence an output with a center count identifies exactly its original full bin and normalization branch. A remainder input or an input with no full bin cannot collide with such an output at the same retained H.

Different retained scaffolds cannot create hidden collisions either: H is recoverable from unchanged noncandidate positions and unchanged noneligible candidate values. Eligibility is unchanged by both the interior edits and the final XOR. These facts justify using the observed center as a bin label without an extra marker.

The channel's design depends only on public parameters and the current input, not the unknown source sign. All random coins are future-blind. Identity on the remainder and on n too small is defined on every input, including atypical ones.

## 3. Full observation masses and posterior prediction

Given a count S=s, the eligible configuration is uniform. Uniformly selecting the ones to remove or zeros to add maps every possible s in a bin to the same uniform law on configurations of count c_j. The subset-counting identity gives probability 1/binomial(n,c_j) for each normalized word.

Consequently the normalized word reveals no additional information about the original within-bin count or its sign after conditioning on H and the bin. The exact mass factorization (Q9) accounts for the entire displayed word, including the terminal bit, rather than a selected statistic of it.

The XOR posterior formulas (Q10) and the actual next-symbol target (Q11) are correct. The next law is generated from the original clean terminal pair. The conditional expectation averages latent histories under each fixed source separately, not a prior mixture over hypotheses.

Each terminal displayed probability is at least 1/3 because it is a convex combination of r_q and 1-r_q. This remains uniform for all rho, all bins, and all retained scaffolds.

## 4. Central bins retain constant joint overlap

For H in T, the conditional mean shift of S relative to n p0 is at most L_beta gamma sqrt(M)/3, and the conditional variance is at most M/12. Chebyshev at radius 2sqrt(M) yields probability at least 47/48, as stated.

On this event, the count is a linear-in-M distance from both endpoints for all sufficiently large M: n>=c0 M and p(q) is uniformly bounded away from zero and one. The upper incomplete remainder has only O(sqrt(M)) values, uniformly over h. Thus the count lies in a full bin. Its center is at distance at most h<=sqrt(M), and the chosen A0 has sufficient slack to make the bin central.

The conditional central-bin probability is therefore at least 15/16 uniformly over H in T. Multiplication by P(T)>=15/16 gives (15/16)^2>=7/8. All required onset bounds are independent of k and rho because h is capped at sqrt(M).

The crucial overlap step correctly uses the JOINT common map from the clean prefix to (H,j), with a remainder symbol. Data processing gives TV at most 1/8 for these joint laws. Restricting their overlap to an event of probability at least 7/8 leaves at least 3/4. This does not assume that scaffold overlap by itself implies conditional bin overlap.

## 5. Finite within-bin likelihood and covariance bounds

For a central full bin, every count is within (A0+1)sqrt(M) of n p0. Since n>=c0 M and the intermediate p(q) differs from p0 by O(M^(-1/2)), both s/n and (s+1)/n remain in a fixed compact interior interval and differ from p(q) by O(M^(-1/2)). The mean-value bound for log proves the stated adjacent log-mass estimate.

There are at most 2h<=2sqrt(M) adjacent steps in a bin. Thus the ratio of its largest and smallest binomial masses is bounded by a finite R_beta independent of M,k,rho, uniformly over the entire local source interval. No normal approximation or asymptotic replacement of the conditional bin law is used.

The conditional mass of each count is at least 1/[R_beta(2h+1)]. Each of the lower and upper subsets in the draft has at least h/2 points, hence mass at least 1/(6R_beta). Their count values are separated by at least h, while the sign statistic takes values zero and one respectively.

In the symmetric covariance identity, the two ordered cross-events cancel the leading factor one half. Restricting to them therefore yields exactly

    Cov(a_j(S),S | B_j)>=h/(36R_beta^2).

This also works for h=1: each subset then contains one count and the bin has three values.

For a FIXED bin, its conditional binomial law is an exponential family in the log odds lambda. The bin endpoints, its center, and the sign statistic do not move with q. Differentiating the finite normalized sum therefore gives exactly the covariance identity, with no missing derivative of a moving event. Integrating over the local parameter interval proves (Q17) with the displayed a_beta.

## 6. Target perturbation and one-channel risk bound

The fixed-r posterior subtraction (Q18) is exact for either terminal value. Since the reference endpoint coefficient is 2alpha and r(1-r)>=2/9, the reference target separation is at least (4alpha/9)|t_+-t_-|.

For fixed t, both posterior maps have derivative t(1-t)/ell^2 with respect to r, bounded by 9/4. The target's direct q derivative is bounded by one in absolute value, and |dr_q/dq|=1. Thus the conservative derivative bound 13/4 is valid. Replacing both reference parameters costs at most (13/2)gamma/sqrt(M). The nuisance term in (Q19) is necessary and is retained.

When rho h>=H_beta, (Q19) gives the stated positive gap. Summing normalized output configurations cancels the binomial factor in their masses. Joint scaffold-bin overlap at least 3/4 and the two terminal contributions at least 1/3 each give full-output overlap at least 1/2. Dividing the overlap risk-sum inequality by two yields the factor 1/8 in (Q21).

The source/channel selection is common to both hypotheses, and the argument applies to any predictor that knows the complete channel, including independent randomization.

## 7. Small budgets and small rho: the case split is valid

The identity-channel target is the row at the observed final pair. Its two-source TV gap is exactly 2gamma/sqrt(M) on every word. Observation overlap is at least 7/8, so the clean lower 7gamma/(8sqrt(M)) in (Q22) is correct.

For k>=2, the elementary cap relation b_M/2<=h<=b_M, where b_M=min{k,sqrt(M)}, holds including noninteger sqrt(M). In the high-signal case, rho h>=H_beta>=1, the binned channel gives a constant multiple of [1+rho b_M]/sqrt(M). In the low-signal case, rho b_M<2H_beta, so the clean lower gives the same form with a smaller beta-dependent constant. The cases k=0,1 are covered directly by the clean lower.

This selects ONE channel according to the public parameters in each regime. It does not incorrectly add lower bounds belonging to unrelated experiments. The same local source pair can be used throughout the cases.

All horizon requirements precede this split and are independent of k and rho. The nuisance threshold is handled by the clean baseline rather than by requiring M to grow as rho decreases. Consequently the uniform-in-rho statement (Q1) is justified, including rho=0.

The cap must remain outside rho, as it does in the candidate. This proof gives rho min{k/sqrt(M),1}; it does not supply min{rho k/sqrt(M),1} uniformly in rho for large k.

## 8. Matching fixed-floor subclass rate

With 0<beta<1, 0<eta<1/2, and rho>0 fixed, let alpha=e=min{(1-beta)/32,(1/2-eta)/8}. This value is strictly positive. The same D2 certificate has slack because alpha+e is no larger than in the base choice. The center's smallest transition entry is 1/2-2alpha, which exceeds eta with strict slack; the local alternatives therefore also exceed eta at all sufficiently large M.

All preceding arguments go through with beta- and eta-dependent constants and onset horizon. This gives the lower for a source pair actually inside the restricted class, not merely inside the larger D2 class.

For fixed rho>0,

    M^(-1/2)+rho min{k/sqrt(M),1}
       >=rho min{1,(k+1)/sqrt(M)}.

Combining this with the independently reviewed positive-floor upper proves (Q23). Its constants may depend on beta, eta, and rho. The eta=1/2 singleton boundary and beta=1 IID boundary are correctly excluded from this amplification claim.

The lower's uniformity in rho is stronger than the fixed-rho matching-rate statement, but it does not make that matching rate uniform as rho tends to zero. No sharp rho=0 or moving-rho result is claimed here.

## Scope retained

- The source is stationary and binary; its initial pair law is not an independently unknown nuisance parameter.
- The known channel is allowed to inspect the entire available history but is future-blind. No hidden sign, seed, normalization choices, or edit mask are disclosed.
- The lower uses horizon-varying local alternatives and overlap of full output laws. It does not prove fixed-source pointwise inconsistency or exact observational nonidentifiability.
- The unrestricted D2(beta) binary rate remains open despite the matching fixed-floor subclass rate.
- The proof is statistical and information-theoretic. It does not establish efficient computation, neural realization, executable confirmation, or prior-art originality.

## Sources inspected

The complete quantitative candidate was checked against `KNOWN_CHANNEL_stationary_binary_sqrt_lower.v1.md`, its independent review, the known-channel target conventions, and the previously reviewed `KNOWN_CHANNEL_uniform_positive_floor_upper.md`. No frozen source file was modified in this review.
