# Stationary binary known-channel prediction: a rare-event budget lower

Date: 2026-11-05 UTC. Pure mathematical analysis. No scientific executable checks, public writes, novelty certification, or computational-efficiency claim. New proof draft for independent review.

## 1. Result

Fix 0<beta<1. For all sufficiently large M, every integer 0<=k<=M and every 0<=rho<=1, the worst disclosed, source-independent, future-blind strict-k-edit channel with per-input endpoint-change probability at most rho has stationary binary D2(beta) posterior-prediction minimax risk at least

    c_beta [M^(-1/2)
        + rho min{(k^2/M)^(1/3),1}].             (RB1)

The source-specific target is P_theta(X_(N+1)=1|Z), N=M+2. The lower is an existence statement about a bad common known channel and two stationary sources; the choices may depend on the horizon and budgets. The constant and sufficiently large horizon depend only on beta, not on k or rho.

This is not a matching upper or a sharp-rate claim. It strengthens the earlier fixed-positive-floor lower when k=o(sqrt(M)), and rules out a linear (k+1)/sqrt(M) upper on the unrestricted class. The one-edit case is proved separately and completely in `KNOWN_CHANNEL_stationary_binary_rare_one_edit_lower.v1.md`; this note supplies the uniform k>=2 extension.

## 2. Same source family, new scales

Use the notation and exact identities from the one-edit note. In particular d=(1-beta)/64, r=4d, and

    theta_q(00)(1)=theta_q(01)(1)=t,
    theta_q(10)(1)=r, theta_q(11)(1)=q t.

For k>=2 put

    h=min{k-1,floor(sqrt(M))},
    t=tau (h^2/M)^(1/3),
    q_-=1-d/h, q_+=1+d/h.                        (RB2)

Choose tau>0 sufficiently small depending only on beta, with tau<=min{d/4,1/512}. Then 1-d<=q<=1+d and t<=tau. The stationary law and all-state D2(beta) certificate in the one-edit note remain valid verbatim.

The clean-chain KL satisfies

    KL(P_+^(1:N)||P_-^(1:N))
      <= KL(Pi_+||Pi_-)+C d^2 M t^3/h^2
      = KL(Pi_+||Pi_-)+C d^2 tau^3.              (RB3)

The initial term tends to zero uniformly in h: differentiating the explicit stationary probabilities gives |d log Pi_q(s)/dq|<=C_beta t for every state, hence each log ratio is O_beta(d t/h). Since t/h=tau M^(-1/3) h^(-1/3)<=tau M^(-1/3), this is uniformly o(1). Choose tau smaller and M larger if needed, to obtain clean-word TV<=1/8 uniformly over all h.

Keep the same candidates, eligible scaffold 11?00, missing penultimate bit B, retained scaffold H, and terminal event A={X_(N-3)=X_(N-2)=X_N=0}. Conditional on H the candidate bits are iid Ber(p_q), independent of B, where

    p_q=q t/[1+(q-1)t].

On A, B is exactly Ber(t), and the future row is t+(r-t)B.

The same rare-indicator variance proof gives Var(n)<=C_beta M t^2. For sufficiently small fixed tau, the mean of n/(M t^2) lies in a fixed interval strictly inside (1/4,1/2), uniformly over h and all large M. Moreover M t^2>=tau^2 M^(1/3). Consequently

    T={M t^2/4<=n<=M t^2/2}

has probability at least 31/32 for all sufficiently large M, uniformly in h. The stationary minority mass is at most C_beta t; by reducing tau, P(A)>=31/32. Thus the H-laws obey

    sum_{H in A intersect T} min(f_+(H),f_-(H))>=3/4. (RB4)

## 3. The common bin channel

For H in A intersect T, set

    c=max{h,floor(n t)}, B_n={c-h,...,c+h}.

For all sufficiently large M the bin is contained in {0,...,n}; a proof is included below. If H is outside A intersect T or S is outside B_n, return identity. Otherwise:

1. Uniformly normalize the eligible bits to exactly c ones, changing |S-c| bits.
2. Set A_sign=0 for S<c, 1 for S>c, and an independent fair bit at equality.
3. Flip the clean penultimate bit B when A_sign=1 and an independent Bernoulli(rho) coin is one.

The total number of edits is at most h+1<=k. The per-input endpoint-change probability is at most rho. The channel is known, source independent and future blind. All quantities in its definition are fixed public constants or clean-history functions; q is not used.

H remains unchanged and recoverable. On H in A intersect T, displayed eligible count c identifies the normalization branch exactly: untouched outside-bin inputs have counts different from c. Uniform normalization maps a uniform input of any count in B_n to a uniform output of count c, so the displayed eligible configuration carries no information about the hidden original count beyond its bin membership.

## 4. Uniform elementary bin lemma

Let

    a=tau^3/4, b=tau^3/2, mu0=n t.

On T, a h^2<=mu0<=b h^2. Along the entire parameter interval q in [1-d/h,1+d/h], put mu=n p_q. Direct algebra gives

    |mu-mu0|<=2d mu0/h<=2db h,
    mu<=2b h^2, p_q<=2tau.

There are constants g_*>0 and R<infinity depending only on beta (through tau and d) such that, uniformly over h, n in T, q in this interval, and all sufficiently large M,

    P_q(S in B_n|H)>=g_*,
    max_{s in B_n} P_q(S=s|H)
      /min_{s in B_n} P_q(S=s|H) <= R.           (RB5)

Here is an elementary proof avoiding normal approximations.

Large h: choose a fixed integer H_beta large enough that h>=H_beta implies mu0>=4h, h>=8, and 1+2db h<=h/4. Then c=floor(mu0), c-h>=0, and c+h<=n because mu0=n t with t<=tau small. Also |c-mu|<=h/4. The bin contains every integer S with |S-mu|<=h/2. Since Var(S)<=mu<=2b h^2 and tau is small, Chebyshev gives bin probability at least 7/8. For adjacent masses w(s),

    log[w(s+1)/w(s)]
      =log[(1-s/n)/(1-p_q)] + log[mu/(s+1)].

Throughout the bin, |s-mu|<=5h/4, min(mu,s+1)>=a h^2/2, and both 1-s/n and 1-p_q are bounded below by 1/2. The mean-value bound for log therefore gives an absolute adjacent log ratio at most C_beta/h. Summing at most 2h steps gives the finite ratio bound exp(2C_beta).

Small h: there are only finitely many integers 1<=h<H_beta. Every bin index is at most the finite integer S_beta=ceil(b H_beta^2+2H_beta). Uniformly over this finite range, n tends to infinity with M; choose M so n>=2S_beta. Set L=n p_q/(1-p_q)=q mu0/(1-t). It lies in a fixed compact subset [ell,U] of (0,infinity), where one may use ell=(1-d)a and U=(1+d)b H_beta^2/(1-tau). For every 0<=s<=S_beta,

    w(s)/w(0)= [(n)_s/n^s] L^s/s!,
    (ell/2)^s/s! <= w(s)/w(0) <= U^s/s!.

These finitely many positive bounds give a common ratio bound. Also w(0)=(1-p_q)^n>=exp(-2mu)>=exp(-4b H_beta^2), so any one bin mass gives a fixed positive lower on bin probability. This also verifies c+h<=n in the small-h range. Taking minima/maxima over the two regimes proves (RB5).

## 5. Hidden-sign and endpoint separation

Let v_q=E_q[A_sign|H,S in B_n]. By (RB5), every conditional bin point has mass at least 1/[R(2h+1)]. The lower and upper quarter subsets

    L={c-h,...,c-ceil(h/2)},
    U={c+ceil(h/2),...,c+h}

each have conditional probability at least 1/(6R), are separated by at least h, and carry A_sign values zero and one. Therefore

    Cov_q(A_sign,S|S in B_n)>=h/(36R^2),
    1/(6R)<=v_q<=1-1/(6R).                     (RB6)

The restricted binomial law is an exponential family in lambda=log[p_q/(1-p_q)]=log q+log[t/(1-t)]. Differentiation yields dv_q/dlambda=Cov_q(A_sign,S|S in B_n). Since

    lambda(q_+)-lambda(q_-)=log[(1+d/h)/(1-d/h)]>=2d/h,

integration gives

    v_+-v_->=d/(18R^2)=v_*>0.                  (RB7)

On the normalization branch, the endpoint flip probability is T_q=rho v_q. The exact posterior target remains

    p_q(1|Z)=t+(r-t)F_w(t,T_q).

For w=0, its output mass ell_q(0)=t T_q+(1-t)(1-T_q) is at least (1-t)(1-v_q)>=1/(12R). Exact subtraction gives target separation at least

    (r-t)t(1-t)|T_+-T_-| >= (r v_*/4) rho t.   (RB8)

The output mass at H, normalized configuration y, and w equals

    f_q(H) g_q(n) binomial(n,c)^(-1) ell_q(w).

Sum over y, apply (RB4)-(RB5), and keep w=0. The output overlap on this event is at least (3/4)g_*/(12R). The two-source absolute-loss overlap inequality and (RB8) consequently yield

    max(Risk_+,Risk_-)>=c_beta rho (h^2/M)^(1/3). (RB9)

All constants and sufficiently large horizons above are uniform in h and rho. Since h>=min{k,sqrt(M)}/2 for k>=2 and M>=4, this proves the rare-event term in (RB1) for k>=2. The separate one-edit note covers k=1 with the same order, and k=0 contributes no rare-event term.

## 6. Add the clean baseline

The identity-channel clean baseline in `KNOWN_CHANNEL_stationary_binary_quantitative_lower.v1.md` supplies c_beta M^(-1/2) for every nonnegative budget and every rho. The worst-channel risk is at least the maximum of this clean lower and the rare-event lower. Their maximum is at least half their sum after taking the smaller constant, proving (RB1).

This last step does not assert that the two different channel constructions occur simultaneously. For each budget one selects the construction giving the larger lower; the result is the required existence of one admissible bad known channel.
