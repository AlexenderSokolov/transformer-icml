# A finite-alternative posterior bound and a no-floor fixed-suffix upper

5 November 2026 UTC. Pure analytical candidate, pending independent exact-file review. No scientific executable checks, numerical experiments, public writes, or computational-efficiency claim.

## 1. Results and precise scope

This note lifts the fixed-suffix score control to a finite-alternative posterior comparison without integrating a parameter path. It then supplies an actual statistical upper, using a fitted model that is fixed after conditioning on an unchanged observed prefix.

Throughout, the Hellinger convention is

    H^2(P,Q)=sum_x (sqrt(P(x))-sqrt(Q(x)))^2,

with range [0,2]. This is twice the convention that includes a factor 1/2.

### Finite-alternative comparison

Let P,Q be two raw-word laws, and C one common, known, source-independent channel. Let g_P(x),g_Q(x) be their future success probabilities, each depending only on the terminal pair S(x). Let p_P,p_Q be their posterior future success probabilities given Z. Suppose the channel's per-word terminal-pair change probability is at most rho. Then

    E_(P,C)|p_P(Z)-p_Q(Z)|
      <= E_P|g_P(X)-g_Q(X)|
                      +2 sqrt(rho) H(P,Q)+H^2(P,Q).       (F1)

The laws need not have common support. On a zero-Q output, define p_Q arbitrarily in [0,1]. In fact the proof needs only the integrated bound Q_C{S(X)!=S(Z)}<=rho, not the corresponding P bound. The per-word certificate ensures it uniformly for every candidate Q.

This comparison is valid for arbitrary common channels, not just online or S=1 channels. It requires Q to be one fixed law throughout the output expectation. It does not automatically apply to a distinct fitted law Q_Z chosen separately at every output.

### Statistical fixed-suffix theorem

Fix 0<beta<1. Let X_1,...,X_(N+1) be a stationary binary homogeneous order-two source in D2(beta), with N=M+2. Let 0<=L<=M-1 and

    n=N-L,    m=n-2=M-L>=1.

Let C be any disclosed, source-independent, future-blind channel that always displays X_1,...,X_n unchanged, changes only coordinates n+1,...,N, and satisfies the per-word terminal-pair certificate rho. There is a statistical predictor q_C with

    E|q_C(Z)-P(X_(N+1)=1|Z)|
       <= C_beta min{1, m^(-1/2)
                         +min{rho,sqrt(rho L/m)}}.         (F2)

For L=0 the second term is zero. No positive transition floor is assumed. The constant depends only on beta. The suffix length L can grow; it need not be fixed. When m is comparable to M, the bound is at most O_beta((1+sqrt(L))M^(-1/2)); in particular, a fixed L gives O_(beta,L)(M^(-1/2)).

The theorem covers all such suffix-supported channels, including S=1 online channels. It is not a general S=1 theorem: no substitution L->k, L->k^2, or any other conversion of suffix length into the actual number of edits is asserted. A separate strict-k constraint may be imposed, but is not used by this proof.

## 2. Proof of the finite-alternative comparison

Let mathsf P and mathsf Q be the joint laws of (X,Z) induced by P,Q and the same C. Their Hellinger distance is exactly that of the raw laws:

    H^2(mathsf P,mathsf Q)
      =sum_(x,z) C(z|x)(sqrt(P(x))-sqrt(Q(x)))^2
      =H^2(P,Q).                                        (F3)

First separate the direct row difference:

    E_mathsf P|p_P-p_Q|
       <=E_P|g_P-g_Q|
             +E_(mathsf P_Z)|E_mathsf P[g_Q(X)|Z]-p_Q(Z)|.

Define

    f(x,z)=g_Q(x)-p_Q(z).

Then |f|<=1 and E_mathsf Q[f|Z]=0, mathsf Q_Z almost surely. Moreover, with b_Q(z)=g_Q evaluated at S(z),

    E_mathsf Q f^2
       =E_mathsf Q Var(g_Q(X)|Z)
       <=E_mathsf Q [g_Q(X)-b_Q(Z)]^2
       <=mathsf Q{S(X)!=S(Z)}<=rho.                    (F4)

Take a(z) to be the sign of E_mathsf P[g_Q(X)|Z=z]-p_Q(z), with arbitrary values at zero-mass outputs. The second term in the preceding display equals E_mathsf P[a(Z)f(X,Z)].

On the support of mathsf Q, write the absolutely continuous part of mathsf P as R^2 mathsf Q. Let mathsf P_s be the part supported outside mathsf Q. Conditional centering gives E_mathsf Q[af]=0, so

    E_mathsf P[af]
       =2 E_mathsf Q[af(R-1)]
          +E_mathsf Q[af(R-1)^2]+E_(mathsf P_s)[af].

Cauchy-Schwarz and (F4) bound the first term in absolute value by

    2 sqrt(rho) sqrt(E_mathsf Q(R-1)^2).

The other two terms have absolute value at most

    E_mathsf Q(R-1)^2+mathsf P_s(total)
          =H^2(mathsf P,mathsf Q).

This proves (F1) using (F3). In particular, the singular part and the outputs with mathsf Q_Z=0 are paid for by the quadratic remainder. There is no hidden bounded-likelihood-ratio or common-support assumption.

## 3. Fitting only the unchanged prefix

Write H=X_1:n=Z_1:n. For the m training transitions i=3,...,n, let

    J_u=sum_i 1{(X_(i-2),X_(i-1))=u},
    C_(u,c)=sum_i 1{(X_(i-2),X_(i-1))=u,X_i=c}.

Set the add-one estimate

    theta_hat_u(c)=(C_(u,c)+1)/(J_u+2).              (F5)

It is positive at every row, including rows not visited in the prefix. It need not satisfy D2(beta), and it need not be paired with its stationary initial law.

After fixing H=h, start the fitted suffix chain at the exact observed pair (h_(n-1),h_n). Let Q_h be its law on X_(n+1):N, using the fixed rows theta_hat(h). Let P_h be the corresponding true conditional suffix law.

The suffix channel

    C_h(w|v)=C((h,w)|(h,v))

is a normalized common kernel after h is fixed. This remains true if the disclosed channel uses h, hidden randomness, or the whole raw suffix. Its prefix output is always h. Its per-word endpoint certificate remains valid for each fixed h,v.

Combine Q_h with C_h and average the fitted terminal row to obtain q_post(h,w). This is the fitted source-specific posterior under Q_h, not a posterior over unknown source hypotheses. The raw fitted suffix has positive mass on every suffix word; therefore every output supported by P_h,C_h also has a positive fitted denominator.

The decisive measurability point is that theta_hat(h) is fixed as w varies. Thus (F1) can legitimately be applied conditional on H=h. It would not be valid to make this step with a separately refitted theta_hat(h,w) without a new argument.

No stationary initial-law estimate is used. The true source's stationary law enters the estimation analysis below, while both conditional suffix laws use the same exact observed starting pair.

## 4. Future-conditioned clean count bounds

We use the reviewed stationary count concentration from Sections 2.1-2.2 of KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md, extending its conditioning from a future symbol to a future pair. The extension changes only the initial distribution of the reversed chain, exactly as in the reviewed proof.

For completeness, the triple chain T on (X_i,X_(i+1),X_(i+2)), with stationary law Lambda, satisfies

    T^3(h,v)>=beta Lambda(v).

Its stationary reversal satisfies the same three-step minorization on its positive stationary support. Condition on any pair U=(X_r,X_(r+1)) with r>=n-1 and P(U=u)>0. Start the reversed triple chain at a triple whose last pair is U, with the conditional distribution of its first coordinate. This is an arbitrary initial distribution. Reverse to the training block, and split its triples into the three residue classes. The reviewed arbitrary-initial-law regenerative count inequality applies to every class. No division by P(U=u) is made.

Consequently, conditionally on any such future pair, a training count V with stationary mean v obeys

    P{|V-v|>x | U=u}
       <=A_beta exp[-a_beta min{x^2/(v+1),x}],
    E[(V-v)^2 | U=u]<=A_beta(v+1).                  (F6)

After increasing A_beta, these statements hold for every x>=0. They apply to J_u with v=m Pi(u), and to C_(u,c) with v=m Pi(u)theta_u(c). Constants are uniform in the source, conditioning pair, its time, and all count means, including zero. The source itself remains stationary; no arbitrary-initial-source theorem is claimed.

## 5. Conditional add-one row KL bound, without a floor

Fix one row u with Pi(u)>0 and one allowed future-pair conditioning event. Write

    p_c=theta_u(c), w=m Pi(u), v_c=w p_c,
    q_c=(C_(u,c)+1)/(J_u+2).

We prove

    E[KL(p||q) | future pair]<=C_beta/(w+1).          (F7)

All expectations and probabilities in this section are under that conditional law. The proof uses only (F6), C_(u,0)+C_(u,1)=J_u, and the add-one definition.

For w<8, KL(p||q)<=log(J_u+2). Jensen and (F6) give

    E log(J_u+2)
       <=log(w+sqrt(A_beta(w+1))+2)<=C_beta,

which proves (F7) after a constant enlargement.

For w>=8 let G={w/2<=J_u+2<=2w}. On the part of G where, for both c,

    C_(u,c)+1 >=(v_c+1)/4,

use KL(p||q)<=sum_c (p_c-q_c)^2/q_c. Define

    A_c=C_(u,c)-p_c J_u+1-2p_c.

Then each term is

    A_c^2/[(J_u+2)(C_(u,c)+1)]
                    <=8 A_c^2/[w(v_c+1)].

The second moments in (F6) yield E A_c^2<=C_beta(v_c+1), because p_c^2(w+1)<=v_c+1. Thus this part contributes at most C_beta/w.

On G, suppose B_c={C_(u,c)+1<(v_c+1)/4}. Then v_c>3, q_c<p_c, and the other coordinate has the opposite sign of q-p. Hence

    KL(p||q)<=p_c log(p_c/q_c)
                          <=(v_c/w) log(2v_c).

The event B_c implies C_(u,c)-v_c<-(3v_c+3)/4. Its probability is at most A_beta exp(-a_beta' v_c) by (F6). Therefore its expected contribution is at most

    (A_beta/w) v_c log(2v_c) exp(-a_beta' v_c)
                                                    <=C_beta/w.

This handles both coordinates; the two events cannot both occur on G.

Finally, on G^c use KL(p||q)<=log(J_u+2)<=J_u+2. The lower-tail contribution is at most C_beta w exp(-c_beta w). For the upper tail, integrate (F6) from J_u+2>2w. For t>=2w and w>=8, its tail is at most A_beta exp(-c_beta t), so

    E[(J_u+2)1_{G^c}]<=C_beta(w+1)exp(-c_beta w)
                                                    <=C_beta/w.

This proves (F7). If p_c is zero, that KL coordinate is interpreted as zero; the preceding proof remains valid. Rows with Pi(u)=0 will have zero weight in the next step.

## 6. Prediction geometry and the estimation error

Let U be any pair at or after the final prefix pair. Stationarity and (F7), conditioning on U=u, give

    E KL(theta_U||theta_hat_U(H))
       <=sum_(u:Pi(u)>0) Pi(u) C_beta/[m Pi(u)+1]
       <=4C_beta/m.                                (F8)

This is the relevant no-floor parameter geometry. Individual rare rows need not be uniformly accurate, but their stationary-weighted predictive KL is O_beta(1/m), even though the fitted rows and U are dependent.

The suffix chain rule, starting at the same observed pair, gives exactly

    KL(P_H||Q_H)
       =sum_(i=n+1)^N E_P[KL(theta_(X_(i-2),X_(i-1))
                      ||theta_hat_(X_(i-2),X_(i-1))(H)) | H].

Integrating H and using (F8) for each of the L terms yields

    E_H KL(P_H||Q_H)<=C_beta L/m,
    E_H H^2(P_H,Q_H)<=C_beta L/m.                   (F9)

The direct terminal-row discrepancy is also controlled by (F8) and Pinsker:

    E|theta_(S(X))(1)-theta_hat_(S(X))(1)|
                                                   <=C_beta/sqrt(m). (F10)

Apply (F1) conditional on H and then average. Equations (F9)-(F10) and Cauchy-Schwarz give

    Risk(q_post)<=C_beta[m^(-1/2)
                              +sqrt(rho L/m)+L/m].  (F11)

This argument uses no parameter path, no interchange of an output-dependent parameter with an output integral, no stationary initial-law fit, and no uniform transition floor.

## 7. Removing the quadratic remainder by a public estimator choice

The simple displayed-terminal-row estimator

    q_end(z)=theta_hat_(S(z))(1)

has, by future blindness and conditional Jensen,

    Risk(q_end)
       <=E|theta_hat_(S(Z))(1)-theta_(S(X))(1)|
       <=C_beta/sqrt(m)+rho.                        (F12)

The last step compares the two fitted rows at S(Z),S(X), costing at most one only when the terminal pair changed, and then uses (F10).

Put a=L/m. Choose q_end if rho<=a, and q_post otherwise. This choice depends only on public m,L,rho, not on any hidden channel mode or unknown source parameter. In the first case (F12) supplies the rho term. In the second case a<=sqrt(rho a), and (F11) supplies at most twice the sqrt(rho a) term. Equivalently, the elementary inequality

    min{rho,sqrt(rho a)+a}<=2 min{rho,sqrt(rho a)}

follows by splitting rho<=a and rho>a. This proves (F2), after changing C_beta and imposing the unit cap. When L=0 there is no corrupted suffix and q_end gives the clean term directly.

## 8. What this resolves and what it does not

- The score lemma now has a finite-alternative counterpart with a one-sided true-output expectation and explicit support handling.
- The fixed-suffix statistical upper is uniform over every known future-blind suffix-supported channel. It is stronger in scope than an S=1-only suffix result, but weaker in channel placement than the requested unrestricted-position S=1 problem.
- The source class is stationary binary D2(beta), with beta fixed. There is no floor eta. The fitted row table need not belong to that source class.
- Stationary initialization is used for reverse count concentration and stationary future-pair weights. The fitted suffix starts from the exactly observed context rather than a fitted stationary law.
- The raw-law Hellinger distance in (F1) must be small for the relevant conditional experiment. For arbitrary-position edits there need not be a long unchanged prefix on which to fit a single Q before summing over outputs.
- The quadratic Hellinger remainder explicitly pays for output-measure mismatch. Dropping it without another argument is not justified. In the statistical theorem it is removed only by selecting the separate endpoint-reliable estimator when appropriate.
- No L->k^2 conversion, general no-floor S=1 improvement, matching lower, minimal-state separation, efficient inference, or novelty claim is made.

## Dependencies

- KNOWN_CHANNEL_one_state_centered_likelihood_flow.research.v1.md and its independent review: the earlier scalar suffix score lemma and the general-S=1 boundary.
- KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md, Sections 2.1-2.2, and KNOWN_CHANNEL_stationary_binary_logfree_upper_independent_review.v1.md: reviewed arbitrary-start regenerative concentration and stationary reverse-triple-chain method.
