# A constant-state online one-edit posterior lower

5 November 2026 UTC. Pure analytical candidate, pending independent review. No executable scientific checks, public writes, or full-budget sharpness claim.

## 1. Result and scope

Fix 0<beta<1. There are c_beta>0 and M_beta such that, for M>=M_beta, N=M+2, and every exact rational endpoint budget rho in [0,1], a disclosed normalized rational online-causal channel using at most ONE edit satisfies

    inf_Q max_{q in {q_-,q_+}} E_q |Q(Z)-P_q(X_(N+1)=1 | Z)|
        >= c_beta min{rho,M^(-1/3)}.                  (O1)

The channel has FOUR base states, excluding its separately charged binary edit counter. Its only nonintegral transition probability is rho. The two stationary binary order-two sources satisfy the all-state D2(beta) certificate. The channel is the SAME for both sources and uses no source parameter. The alternatives depend on M, as allowed in horizon-wise minimax risk.

Together with the identity-channel clean lower and the existing interpolation upper, this proves the sharp fixed-beta k=1 restricted-online rate

    Theta_beta(M^(-1/2)+min{rho,M^(-1/3)}).            (O2)

For any k>=1 the same one-edit witness is admissible, so (O1) still supplies a lower, but no matching growing-k lower is asserted. This does not import an offline witness or a latent-target lower.

## 2. The source family and imported elementary facts

Use the already reviewed rare-family source identities from `KNOWN_CHANNEL_stationary_binary_rare_one_edit_lower.v1.md`, Sections 1-3 and its rare-indicator variance argument. Put

    d=(1-beta)/64, r=4d, q_-=1-d, q_+=1+d,
    t=tau M^(-1/3),
    theta_q(00)(1)=theta_q(01)(1)=t,
    theta_q(10)(1)=r, theta_q(11)(1)=q t.

Choose a fixed positive tau sufficiently small depending only on beta, with tau<=d/4. The stationary pair masses are

    Pi_q(00)=u_q,
    Pi_q(01)=Pi_q(10)=u_q t/(1-r),
    Pi_q(11)=u_q t^2/[(1-r)(1-q t)],

where u_q normalizes. The cited elementary calculation gives P_q^2(s,v)>=beta Pi_q(v) at every pair s,v, and, after reducing tau and increasing M_beta,

    TV(P_+^(1:N),P_-^(1:N))<=1/8.                    (O3)

Indeed the transition KL is O(d^2 M t^3)=O(d^2 tau^3), and the stationary initial-law KL tends to zero. The stationary minority mass is O_beta(t). These are properties of the sources only; none of their probabilities are inputs to the channel.

## 3. A genuinely online channel

Let J be the deterministic candidate positions j divisible by 3 with 3<=j<=N-5. Maintain the last two RAW input bits and the edit counter e, initially 0. At each time:

1. If i belongs to J, the previous raw pair is 11, x_i=1, and e=0, output z_i=0 and set e=1.
2. At i=N-1, if the previous raw pair is 00 and e=0, flip the current input with probability rho, using an independent Bernoulli(rho) coin; on a flip set e=1, and otherwise leave e=0. If the gate fails, output the input unchanged.
3. At all other times output the current input unchanged.

After every step, update the pair state using the current RAW bit, not the output. In particular position N is never edited. The first rule erases the first eligible candidate one immediately; there is no test of its future neighbors and no attempt to undo an earlier output.

Every path uses at most one edit. For every fixed clean word, an endpoint edit occurs with probability either zero or rho. The auxiliary coin is independent of the entire source process. Each output and state update uses only time, the prior state, the counter, and the current raw bit. Every transition row is normalized and rational. No terminal acceptance factor, conditioning of the channel law, hidden buffering of outputs, or future innovation is used.

Four raw-pair states suffice, initialized to 00 before reading x_1. The public time-indexed tables encode J and the last two positions. This is a public-horizon-dependent family, not one fixed length-independent homogeneous transducer. For rational rho=a/b, let b_rho charge the actual numerator and denominator bit lengths. The expanded description is O(N(b_rho+1)) bits under a conservative dense-row encoding; all its storage and expansion are paid. In particular rho=a/2^q costs O(N(q+1)) bits with the actual dyadic precision charged. A compact homogeneous implementation would additionally store the clock and thereby use O(N) states, but the reviewed interface already permits and charges time-indexed tables.

## 4. A recoverable scaffold and the hidden independent bits

Call a candidate j eligible when its two preceding raw bits are 11. Let I be this set. The two preceding positions are noncandidates and never changed, so I is recoverable from the output. Define H by retaining every clean coordinate except the penultimate bit B=X_(N-1) and the bits X_j for j in I, with the missing positions marked.

H is a common deterministic function of the clean word, does not depend on q, and is unchanged and recoverable under the channel. Ineligible candidate bits remain in H. Eligible sites are spaced at least three apart, and their involved order-two likelihood factors end by N-3. Hence no likelihood factor contains two missing candidate bits or both a missing candidate bit and B. Conditional on H, the missing candidate bits are independent, and they are independent of B.

The conditional candidate probabilities need NOT be identical. If (a,b)=(X_(j+1),X_(j+2)) is the retained future pair, write o_q(a,b) for its conditional odds. Direct multiplication of its three likelihood factors gives

    o_q(0,0)=q t/(1-t),
    o_q(0,1)=q r/(1-r),
    o_q(1,0)=q^2 t^2/[r(1-t)],
    o_q(1,1)=q^3 t^2/[r(1-q t)].                   (O4)

Every odds is strictly increasing in q. Put

    L_q(H)=sum_{j in I} o_q(X_(j+1),X_(j+2)),
    S=sum_{j in I} X_j.

Since these are independent Bernoulli bits conditional on H,

    g_q(H)=P_q(S<=1 | H)
          = [product_{j in I}(1+o_q(j))^(-1)](1+L_q),
    v_q(H)=P_q(S=0 | H,S<=1)=1/(1+L_q).           (O5)

The observable event that ALL eligible candidate outputs are zero is equivalent to S<=1: the first clean one is erased, while every later clean one is left visible. Thus no S>=2 history collides with this output branch. On the branch, the candidate output configuration is the unique all-zero configuration; the observer is not given S, the edit counter, or the coin.

## 5. Typical scaffolds and separation

Let n_00 count eligible candidates whose retained future pair is 00, and define

    A={X_(N-3)=X_(N-2)=X_N=0},
    T={M t^2/4<=n_00<=M t^2/2},
    D=A intersect T intersect {L_+<=1}.            (O6)

These are events of H. They are used only for the proof, not as channel gates.

The exact stationary probability of a candidate's 11?00 pattern is

    u_q t^2[1+(q-1)t].

There are M/3+O(1) candidates. Therefore E_q n_00/(M t^2) tends to 1/3 and the rare-window mixing covariance sum gives Var_q(n_00)<=C_beta M t^2. Since M t^2=tau^2 M^(1/3) tends to infinity, P_q(T) tends to one. Also P_q(A) tends to one by the stationary minority bound.

For completeness L_+ is controlled without discarding any future-neighbor types. Our parameter bounds imply o_+/o_q<=2 and o_q<=1/8 for either source and all four types in (O4). If p_q(j)=o_q(j)/(1+o_q(j)), then o_+(j)<=4p_q(j). Consequently, by conditional expectation,

    E_q L_+<=4 E_q S
             =4 |J| Pi_q(11) q t
             <=4 M t^3=4 tau^3.                 (O7)

The last loose inequality follows from |J|<=M/3, Pi_q(11)<=2t^2, q<=65/64. Reducing tau makes P_q(L_+>1) arbitrarily small by Markov's inequality. We may consequently arrange P_q(D)>=7/8. With f_q the law of H, (O3) and data processing imply

    sum_{H in D} min{f_+(H),f_-(H)}>=3/4.         (O8)

On D, L_-<=L_+<=1, and the n_00 terms alone give

    L_+-L_->=(q_+-q_-) n_00 t/(1-t)
              >=d tau^3/2.

Thus

    v_--v_+=(L_+-L_-)/[(1+L_-)(1+L_+)]
             >=d tau^3/8=:v_*>0.                 (O9)

Also log(1+x)<=x yields

    g_q >= product_j (1+o_q(j))^(-1)
         >=exp(-L_q)>=exp(-1)=:g_*.             (O10)

The constant separation is not based on pretending the future-01 sites have small conditional success probability. They are retained in L_q and controlled by (O7).

## 6. Exact posterior targets and their overlap-weighted gap

On A, the two conditional weights of B are t(1-t) and (1-t)^2, so B|H is exactly Ber(t), independently of q and the candidate bits. The next-symbol success probability is t+(r-t)B, because X_N=0 on A.

On the all-zero candidate output branch, S=1 consumes the edit and leaves B unchanged, while S=0 flips B with probability rho. Therefore, with W=Z_(N-1),

    T_q=rho v_q,
    ell_q(1)=P_q(W=1 | H,S<=1)=t+(1-2t)T_q,
    F_1(t,T_q)=P_q(B=1 | H,S<=1,W=1)
              =t(1-T_q)/ell_q(1),
    p_q(H,1)=P_q(X_(N+1)=1 | Z)
             =t+(r-t)F_1(t,T_q).                (O11)

These are source-specific posterior targets, not a Bayesian mixture over q. The corresponding output mass is exactly f_q(H)g_q(H)ell_q(1). The final raw bit X_N was not available when B was acted upon; its value 0 enters only this subsequent conditioning.

Exact subtraction gives

    |p_+(H,1)-p_-(H,1)|
      =(r-t)t(1-t)rho |v_+-v_-|/[ell_+(1)ell_-(1)].

Since ell_q(1)<=t+rho, t<=r/2, and t<=1/2, multiplying by the minimum of the two output masses gives, on D,

    min{P_+^Z(z),P_-^Z(z)} |p_+(z)-p_-(z)|
      >= min{f_+(H),f_-(H)} g_* (r v_*/4)
                                    rho t/(rho+t). (O12)

The formula is also valid at rho=0, when the lower is zero. No rare-output probability has been dropped.

For every predictor Q, the two-source absolute-loss inequality is

    Risk_+(Q)+Risk_-(Q)
       >=sum_z min{P_+^Z(z),P_-^Z(z)}|p_+(z)-p_-(z)|.

Summing (O12) over H in D and dividing by two proves

    max_q Risk_q(Q)>=(3 g_* r v_*/32) rho t/(rho+t).

Finally rho t/(rho+t)>=(1/2)min{rho,t}, and t=tau M^(-1/3) with fixed 0<tau<=1. This proves (O1).

## 7. What this establishes and what it does not

- The one-edit power-1/3 endpoint obstruction survives strict online causality with constant base-state size. Exponential state or an offline terminal filter is unnecessary.
- The known channel is source independent, while the posterior target remains source dependent. Its unobserved one-edit allocation creates the obstruction.
- The source alternatives vary with the horizon and have transition entries tending to zero. This is not a fixed positive-floor lower or a single fixed-source asymptotic impossibility statement.
- At rho=0 this witness contributes zero; the clean baseline remains. At k=0 the channel is inadmissible and identity is used instead.
- For k=1, the existing statistical interpolation upper and this lower match in statistical order at fixed beta. For the dyadic computational interface the matching claim applies directly to dyadic rho; a general positive rational rho may instead use an upward dyadic certificate rho_bar in [rho,min{2rho,1}], whose actual precision is paid, preserving the order. This does not prove resource-optimal Transformer complexity.
- For growing k, the unrestricted offline bin-normalization lower still cannot be imported. The matching growing-k endpoint term min{rho,(k^2/M)^(1/3)} remains open in this candidate. A separate elementary protected online witness supplies the k/M term in `KNOWN_CHANNEL_online_protected_budget_lower.candidate.v1.md`.
