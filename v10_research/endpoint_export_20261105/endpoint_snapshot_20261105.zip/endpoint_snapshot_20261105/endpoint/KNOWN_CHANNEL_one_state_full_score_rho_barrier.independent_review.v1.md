# Independent review: combined predictive-score rho barrier

Review time: 2026-11-05 10:43:19 UTC.

## Decision and exact binding

**PASS for the stated total-covariance inequalities and their precise scope.** I fully read and independently checked:

- `KNOWN_CHANNEL_one_state_full_score_rho_barrier.candidate.v1.md`
- SHA-256: `8d69accfcb86385a96c5fd667e96e034859b4af2133ffe72aeab48fd9f7d28e1`.

The candidate proves an M-independent positive lower for the expected absolute **complete-source covariance** in the derivative of the actual future posterior, with `rho=1/M` and k=2. It correctly includes the opposing local and remote score effects before taking its lower bound. The rare complete-output mass is retained. This is not merely a lower on one isolated score contribution.

The conclusion is a counterexample to the specified Fisher-normalized score bounds, not a predictive minimax lower, finite-alternative weighted-TV theorem or refutation of a bound that includes a separate rho-independent row-error term. The original file remains unchanged; the hash binds the present read without historical inference.

## 1. Fixed experiment and online legality

The channel is fixed by M and `rho=1/M` throughout differentiation of a. Its prefix erases precisely the first raw one among the first M coordinates, if any. The following anchor is unchanged, and only the actual counter-one state can trigger the terminal flip. Thus every path makes at most two actual changes. At the endpoint, the per-word change probability is rho exactly when the raw prefix contains a one, and zero otherwise.

All rows, including unreachable exhausted-counter rows, are normalized and remain within the actual counter domain. No source parameter or past raw-symbol register is supplied to the kernel. One base state is accompanied by the real three-valued edit counter and paid time-indexed table. The endpoint operation reads the current raw bit but no future innovation.

The stationary first-order source has the correct marginal law and all-state pair minorization `1-r>=beta`. A fixed rational positive r exists for each fixed beta strictly below one. A small open neighborhood of `a_0=1/M` keeps every probability positive. There is no fixed transition floor along this sequence, and no positive-r conclusion at beta=1 is asserted.

## 2. Exact prefix and endpoint conditioning

The all-zero displayed prefix through its protected anchor has exactly the zero-one and one-one raw preimages stated in the candidate. The first-position-one weight has ratio `a/(1-a)` to the zero word by stationary detailed balance. Every other permitted one contributes `a(1-a-r)/(1-a)^2`. This gives exactly both expressions for R in (F4).

The prefix mass is `b=pi_a(0)(1-a)^M(1+R)`, and the actual activation prior is `v=R/(1+R)`. The stationary marginal factor cancels from that prior but remains in the observation mass. It is not treated as a fixed initial distribution when the complete source is differentiated.

Conditional on the prefix, the raw terminal bit is Bernoulli a and independent of activation because the protected anchor is zero. Consequently the effective flip probability is `T=rho v`, and the endpoint observation mass, terminal posterior and next-bit posterior in (F6) are exact. They account for all no-flip, prefix-edit-only and two-edit preimages of the complete output `0^(M+1)1`.

## 3. Both derivative effects and exact cancellation algebra

Holding the channel, M and rho fixed, direct differentiation gives the two partial derivatives in (F7). The full derivative is

`rho[v-rho v^2-a(1-a)v']/ell^2`.

The endpoint-prior change and activation-prior change have opposite signs, and both are retained. This prevents incorrectly carrying over the earlier nonvanishing individual-score contribution as if it were already a bound on the combined covariance.

I independently differentiated R and checked all central identities:

`R=(1-r)/(1-a_0)`,
`v=(1-r)/(2-r-a_0)`,
`a_0 v'=(1-r-a_0 r)/(2-r-a_0)^2`.

Substituting them yields exactly the positive bracket in (F9). Its lower bound 1/8 is conservative: `(1-a_0)>=3/4`, `(1-r)>=7/8`, and the squared denominator is at most four. Since `ell<=2a_0` and the fixed rho equals a_0 only at the evaluation point, (F10) follows. The proof never differentiates the identity rho=a_0 as if rho varied with a.

The posterior derivative identity for a fixed source-independent channel is `p'_a=E[partial_a g_a|Z]+Cov(g_a,S_all|Z)`. Here the direct row derivative is one. Thus the lower `r/(32a_0)` applies to the **sum of all posterior score terms**, namely `p'_{a_0}-1`. No initial-score, terminal-score or stationary-law contribution is omitted.

## 4. Actual output weighting and constants

At the central source, `pi_a(0)>=5/8` and `(1-a_0)^M>=exp(-2)`. Therefore `b(a_0)>=exp(-3)`. Also `ell(a_0)>=a_0`. Multiplying this complete-output mass by the full covariance lower proves exactly `r exp(-3)/32` in (F1).

The selected complete output is rare, with probability of order a_0. The candidate does not treat the prefix event alone as the complete observation. Squaring the covariance before multiplying by this same output mass gives (F14), including its factor `M/1024`.

These are integrals under the actual central output distribution. They are not yet minimum-two-source-output-weighted TV comparisons. No such finite-difference claim is needed or supplied by this candidate.

## 5. Fisher normalization and the invalid bounds

The one-transition Fisher formula (F12) is correct for the stationary first-order source. Its first term is at most `4/(3a_0)`. For the second term, canceling `a_0/(a_0+r)<=1` gives the bound `64/35<2<=1/(2a_0)`. Their sum is less than `2/a_0=2M`.

For fixed k=2, the proposed right-hand side with `rho^alpha sqrt(I_step)` is at most a fixed multiple of `M^(1/2-alpha)`. It tends to zero for every alpha>1/2, whereas (F1) stays positive for the fixed chosen r. This validly contradicts any uniform constant depending only on beta in those stated inequalities. The linear-rho case is included.

The proposed squared-covariance bound `C_beta rho k^2 I_step` has a bounded right-hand side here, while (F14) diverges linearly in M. That separate L2 contradiction is also valid. The example does not establish a universal alternative bound or rule out the square-root-rho L1 scaling at its boundary exponent.

## 6. Scope of the obstruction

The quantity bounded below is the full covariance response of the actual predictive target, after subtracting its direct parameter derivative one. It is not a statement that the expected total prediction error remains nonzero. The source parameter is rare, the selected output has probability of order `1/M`, and the corresponding natural local parameter scale is also small. A finite-alternative predictive lower would require its own experiment and loss comparison.

In particular this calculation does not disprove an `O(k/sqrt(M))` predictive upper, a score bound with an additional term independent of rho, or a direct-row estimation bound capable of absorbing the contribution. It also does not establish a general S=1 rate, a state separation or a necessity of counter memory for this particular inequality's failure.

The counter construction is legal and its algebra is useful for checking combined cancellation. However, an endpoint-only noise channel can already obstruct this exact Fisher-rho inequality. The result should therefore be described as a rare endpoint-conditioning obstruction, not as uniquely caused by a hidden counter. Any simpler separate construction requires its own exact binding and does not change the present approval.

## Method and preservation

Pure analytical reconstruction, private file reading, exact hashing and this separate review file. No scientific executable checks, simulations, numerical experiments, model execution, public writes, external novelty investigation, training claims or finite-precision certification. The frozen candidate is preserved unchanged.
