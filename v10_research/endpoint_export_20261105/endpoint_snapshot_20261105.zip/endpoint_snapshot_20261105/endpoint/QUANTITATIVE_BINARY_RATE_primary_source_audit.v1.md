# Primary source comparison for the quantitative binary posterior prediction rate

Date: 2026-11-05 UTC. Analytical literature comparison. No scientific executable checks, experiments, public writes, novelty certification, or edits to the theorem files. This report supplements the earlier primary-source audits rather than replacing them.

## 1 Findings

The new disjoint-bin lower proves a budget-dependent risk bound, not just the previously established square-root consistency threshold. Combined with the positive-floor upper, it gives a matching rate for stationary binary sources with a fixed positive transition floor, a fixed all-state mixing parameter below one, and fixed positive endpoint-corruption allowance. The sharp rate over the entire stationary binary D2(beta) class remains unresolved by these files.

The strongest additional primary-source comparisons are:

- Bernoulli score differentiation and fingerprinting lemmas already give the covariance identity used to differentiate the within-bin sign probability.
- Statistical quantization literature already studies disjoint bins, conditional scores, and information discarded inside bins. Its usual constraint is communication, not strict raw-token edits, and its main target is parameter estimation.
- Coarsening-at-random theory distinguishes a disclosed mechanism from an ignorable one. Exact count-layer symmetry does not make the full-word channel constant on every latent-history fiber.
- General corruption-kernel theory explicitly distinguishes knowing a forward kernel from knowing its Bayesian inverse, which also depends on the clean law. This is directly relevant to why disclosed C does not remove source uncertainty.
- Recent robust Markov estimation concerns transition matrices from multiple trajectories, including arbitrary corrupt trajectories. It does not give the same terminal conditional-law loss or the same corruption scale.

The inspected sources do not provide the full combination of the present channel realization, fixed-source prediction target, and quantitative matched rate. This is a bounded search finding, not evidence of priority. Generic score identities, quantization, conditioning, type symmetry, mixing estimates, and two-point lower-bound methods should not be presented as new.

## 2 Exact result and experiment

Write N=M+2. The clean process is a stationary homogeneous binary order-two Markov source. Its pair-chain kernel P satisfies

    P^2(u,v) >= beta Pi(v) for every pair u,v,

with beta fixed in (0,1). The predictor receives a complete description of C and the displayed word Z. The joint experiment is

    P_theta(x) C(z|x) theta_(S(x))(y).

The channel observes the entire available clean word and has independent random coins. It is future-blind but need not be online within the observed history. It changes at most k raw tokens in every realization and changes the final pair with probability at most rho for every input word. These are stronger requirements than an expected edit budget or a source-averaged endpoint bound. The exhibited C is the same algorithm under both source alternatives; it does not receive their unknown sign.

The risk is

    E_(theta,C) TV(q(C,Z), Law_(theta,C)(X_(N+1) | Z)).

For binary outcomes this is expected absolute error in the true conditional probability. It is not next-bit classification error, cumulative decision loss, clean transition-table error, hidden-terminal-row loss, or a posterior averaged over a prior on the two source hypotheses. If the complete clean law and C were known, this distribution-estimation loss could be zero, despite irreducible uncertainty about the realized next bit.

The new lower is, for all sufficiently large M, every integer 0<=k<=M and every rho in [0,1],

    c_beta [M^(-1/2) + rho min{k/sqrt(M),1}].

For each public parameter combination it selects one bad disclosed channel and two local stationary source alternatives. The onset horizon and c_beta do not depend on k or rho. This is a worst-known-channel statement, not a lower bound for every C. Benign channels such as identity are included in the class but are not said to incur the amplified error.

For fixed beta in (0,1), supplied eta in (0,1/2), and fixed rho>0, restrict the source class further to theta_u(c)>=eta in every row. The local lower family can be chosen inside this intersection. Combining with the positive-floor upper gives

    minimax risk = Theta_(beta,eta,rho)(min{1,(k+1)/sqrt(M)}).

Here the infimum is over channel-aware predictor families q(C,z), and the supremum includes both the admissible disclosed channels and the source class. The upper is uniform over channels, including those with no endpoint-reliability restriction. Its proof does not assume computationally efficient evaluation of C or its latent-history posterior.

The matching formula is not uniform as rho tends to zero, eta tends to one-half, or beta tends to one. In particular, the quantitative lower has rho OUTSIDE the cap: rho min{k/sqrt(M),1}. It does not prove min{rho k/sqrt(M),1} uniformly in rho. The rho=0 lower is the clean statistical baseline; the rho-independent upper does not establish a sharp joint (k,rho) rate. The beta=1 IID boundary and eta=1/2 singleton boundary are excluded from the amplification claim.

## 3 What the disjoint bins change

The source family and the separated-site scaffold come from the preceding square-root lower. Conditional on the retained scaffold H, the eligible bits are exactly IID Bernoulli(p(q)), their count S is binomial, and the clean terminal bit is conditionally independent of them. The eligibility mask is determined by retained neighbors, not by the bit selected for hiding. All source transitions stay uniformly positive, and local alternatives are q_0 plus or minus gamma/sqrt(M).

The new mechanism uses h=min{k-1,floor(sqrt(M))} for k>=2. Each full count bin has 2h+1 integer values and is mapped to its own center c_j. Uniform additions or deletions change at most h interior bits; a hidden within-bin sign, multiplied by an independent Bernoulli(rho) coin, controls at most one terminal XOR. The incomplete upper remainder is left unchanged. Distinct centers and the location of that remainder make the original bin and normalization branch recoverable from the displayed count, without an additional alphabet symbol.

### Exact transport between count layers

Given S=s, the eligible word is uniform over weight-s configurations. For a fixed weight-c output y, uniform normalization gives

    s>=c: binom(n-c,s-c) / [binom(n,s) binom(s,c)] = 1/binom(n,c),
    s<c:  binom(c,s) / [binom(n,s) binom(n-s,c-s)] = 1/binom(n,c).

The equalities are elementary double counting. Uniformity holds after averaging over the uniform INPUT COUNT LAYER. It does not say that the normalized output is uniform conditional on each individual input word. Therefore, given H and a bin, the normalized word reveals no further information about the old count or its sign. The bin label itself remains visible and informative.

For scaffold mass f_q(H), bin probability b_q(j|n), and terminal display probability ell_q(w), the complete normalized output mass is

    f_q(H) b_q(j|n) binom(n,c_j)^(-1) ell_q(w).

This factorization accounts for the whole displayed word, not merely the count. The proof uses joint scaffold-and-bin overlap. Closeness of scaffold laws alone would not justify closeness of their conditional bin probabilities.

### The quantitative step

For a central bin, the binomial masses have uniformly bounded maximum-to-minimum ratio. Adjacent log-mass ratios are O_beta(M^(-1/2)); at most 2h<=2sqrt(M) steps remain inside the bin. Thus the lower and upper portions each have constant conditional mass and are separated by order h. With a_j(s) equal to zero, one-half, or one below, at, or above the center,

    Cov(a_j(S),S | S in B_j) >= h/(36 R_beta^2).

For fixed bin endpoints and lambda=logit(p), the exact finite-sum identity is

    d E_lambda[a_j(S) | S in B_j] / d lambda
        = Cov_lambda(a_j(S),S | S in B_j).

The bin is held fixed during differentiation. Moving the event with the parameter would introduce a different problem. Integrating over the local alternatives yields a hidden endpoint-flip probability difference of order rho h/sqrt(M). No central limit theorem, normal approximation, or Berry-Esseen estimate is used in this quantitative replacement.

Many central bins jointly retain constant probability even when h is small. This is the difference from confining normalization to a single narrow window, whose probability could shrink with h/sqrt(M). It is not an assertion that every bin has constant probability.

### From a hidden sign to the actual target

The future target changes through both the hidden endpoint posterior and the source transition table. The proof explicitly subtracts the direct source perturbation, obtaining a pointwise gap of the form

    [A_beta rho h - B_0]/sqrt(M).

It uses the binned channel when rho h exceeds a fixed threshold. For smaller rho h and for k=0,1, identity supplies the clean M^(-1/2) lower. Choosing one of these channels according to the public parameters establishes the displayed sum-rate lower; it does not add lower bounds from two unrelated experiments without a case split.

The final step integrates the target gap against overlap of the FULL observation laws. Those laws need not be equal, and the bin label and retained scaffold may still help distinguish the sources. The alternatives and channel vary with the horizon. This establishes uniform minimax difficulty, not inconsistency for one fixed source and fixed channel, or exact observational nonidentifiability.

## 4 Primary comparisons added in this audit

### Score differentiation and fingerprinting

Thomas Steinke and Jonathan Ullman, *Tight Lower Bounds for Differentially Private Selection*, FOCS 2017.

Primary source: https://arxiv.org/pdf/1704.03024

Inspected: Section 3.2.1, Lemma 9 and its finite-product differentiation. For IID Bernoulli(p) bits, it gives p(1-p)g'(p)=E[f(X) sum_i(X_i-p)]. The paper labels this a rescaling of earlier results, not an original score identity. Applying it to a(S)1_B and 1_B, then taking the quotient derivative, produces the conditional covariance identity above. This last application is our comparison. Their privacy-selection setting does not supply the hard-Hamming normalization, central-bin covariance lower bound, or endpoint target. Cite it as an explicit technical antecedent, not a theorem proving the present rate.

### Information in quantized samples

Leighton Pate Barnes, Yanjun Han, and Ayfer Ozgur, *A Geometric Characterization of Fisher Information from Quantized Samples with Applications to Distributed Statistical Estimation*, Allerton 2018.

Primary source: https://web.stanford.edu/~aozgur/FisherAllerton.pdf

Expanded-paper record: https://jmlr2020.csail.mit.edu/papers/v21/19-737.html

Inspected: model, Lemmas 1-2, and the ensuing bin-centroid interpretation. Under their regularity assumptions, the quantized score is the conditional mean of the original score. Its squared norm determines Fisher information after quantization. They credit Amari (2011) for closely related preceding formulas. This is a clear antecedent for studying information retained in disjoint bins. Their resource is transmitted bits and their target is parameter estimation. It neither implements a quantizer by a strict number of Hamming changes nor proves the sensitivity of a hidden endpoint conditional law. No inference about preservation of that target follows merely from preserved Fisher information.

Earlier source identified by that paper: Shun-ichi Amari, *On Optimal Data Compression in Multiterminal Statistical Inference*, IEEE Transactions on Information Theory 57(9), 5577-5587, 2011. DOI: https://doi.org/10.1109/TIT.2011.2162270. Author PDF identified in the focused source search: https://bsi-ni.brain.riken.jp/database/file/311/316.pdf. Its rate-constrained inference setting is not adversarial editing; no separate theorem audit of this earlier paper is claimed here.

### Coarsening and ignorability

Richard D. Gill and Peter D. Grunwald, *An Algorithmic and a Geometric Characterization of Coarsening at Random*, Annals of Statistics 36(5), 2409-2422, 2008.

Primary source: https://arxiv.org/pdf/0811.0683

DOI: https://doi.org/10.1214/07-AOS532

Inspected: introduction, Section 2, equation (2.1), and the fixed-partition observation. CAR requires the chance of reporting a compatible set to be constant over its underlying points. Reporting a fixed partition cell is an example. The paper traces ignorability to Heitjan-Rubin (1991) and its stated CAR definition to Gill-van der Laan-Robins (1997). In our comparison, count-to-bin reporting is partition coarsening, but the entire normalization-plus-endpoint channel is a different object. Its exact layer-averaged erasure does not justify treating the full-word mechanism as CAR. Disclosure is not ignorability.

For a shared C, its factor cancels when comparing two posterior likelihood ratios on the common positive support. It does not disappear from either individual posterior. This distinction is mathematical, not terminological.

### A forward kernel does not determine its inverse without the source law

Laura Iacovissi, Nan Lu, and Robert C. Williamson, *Corruptions of Supervised Learning Problems: Typology and Mitigations*, arXiv:2307.08643v4, 18 May 2026. The initial 2023 title was *A General Framework for Learning under Corruption: Label Noise, Attribute Noise, and Beyond*.

Primary sources: https://arxiv.org/abs/2307.08643 and https://arxiv.org/html/2307.08643v4

Inspected: model overview, Section 5.2.1, Definition 29, Remarks 31-32, and Section 6.1. Their Bayesian inverse depends on the input law as well as the forward kernel. The discrete formula is ordinary Bayes conditioning. Their stated limitations separate distribution-level Bayes-risk comparisons from finite-sample analysis. This directly supports the known-C/unknown-source distinction. Treating a whole history as an attribute can represent a block kernel, but that formal representation does not supply the present M-dependent statistical rate or hard edit geometry. The arXiv record states a JMLR 2026 publication plan; the final journal record was not verified here.

### Parameter information versus hidden conditional information

David Pollard, *A Note on Insufficiency and the Preservation of Fisher Information*, arXiv:1107.3797v2, 2012.

Primary source: https://arxiv.org/pdf/1107.3797

Inspected: simplified Kagan-Shepp example in Section 2 and Theorem 7. The example can discard an ancillary sign while preserving Fisher information, although its conditional sign law depends on the parameter. This is a useful warning against identifying parameter information with sufficiency for latent conditional quantities. It is not the present lower: the example is continuous and has parameter-dependent support, while the local binary construction has uniformly positive finite-state transitions. Pollard attributes the underlying phenomenon to Kagan and Shepp (2005) and gives historical antecedents for the conditional-score theorem. No priority for those generic facts is assigned here.

### Clean Markov estimation and mixing

Geoffrey Wolfer and Aryeh Kontorovich, *Minimax Learning of Ergodic Markov Chains*, ALT 2019, PMLR 98, 904-930.

Primary source: https://proceedings.mlr.press/v98/wolfer19a/wolfer19a.pdf

Inspected: Theorems 1-2, Definitions 3 and (3.5), and the occupation/mixing discussion. The target is the full transition matrix from one clean trajectory, in maximum-row L1 norm, which is twice maximum-row probability-TV. Their sample complexity explicitly depends on minimum stationary mass and pseudo-spectral gap. This is relevant background for the estimation part, not a noisy-terminal posterior theorem. Their assumptions are not identical to the local supplied floor or all-state two-step certificate, and their general lower does not by itself prove the specific binary lower here.

### Robust Markov estimation from several paths

Lasse Leskela and Maximilien Dreveton, *Robust Estimation of a Markov Chain Transition Matrix from Multiple Sample Paths*, Statistica Neerlandica 80(1), e70023, first published 22 January 2026.

Primary sources: https://onlinelibrary.wiley.com/doi/10.1111/stan.70023 and https://arxiv.org/pdf/2506.20325

Inspected: model, Section 3.2 and Theorem 3.5 in the current journal version. Independent paths may have heterogeneous transitions and nonstationary starts; some entire data-matrix rows are arbitrary. The transition-matrix bound includes sampling, heterogeneity, and a corrupt-trajectory fraction divided by minimum stationary mass. Here a data-matrix row means a whole path, not a transition-table row. This is closer to adversarial Markov estimation than ordinary Huber mixtures, but differs in corruption unit, target, information supplied about the mechanism, and number of trajectories. It does not establish a terminal posterior rate proportional to k/sqrt(M). Earlier indexed versions use different theorem numbering; the present comparison binds to Theorem 3.5 of the January 2026 version.

### Retrospective contamination is established but does not fix the target

Sujay Bhatt, Guanhua Fang, Ping Li, and Gennady Samorodnitsky, *Minimax M-estimation under Adversarial Contamination*, ICML 2022, PMLR 162. The PDF title uses *Corruption*.

Primary source: https://proceedings.mlr.press/v162/bhatt22a/bhatt22a.pdf

Inspected: Section 2 and the finite-variance theorem. Their strong contamination model allows changing a bounded number of IID observations after seeing the whole data set. Thus retrospective sample-adaptive corruption is established terminology and machinery. Their estimand is the clean mean under moment assumptions, not a fixed-source latent conditional law under a disclosed kernel. Its tail-dependent contamination rate cannot be transplanted to this bounded binary prediction target. Their informal comparison to Huber contamination also does not make an IID mixture satisfy a deterministic edit cap in every realization.

## 5 Relation to the earlier source audits

The following earlier comparisons remain applicable, but their full discussions are not duplicated:

- `EPR001_primary_source_prior_art_audit.v1.md`: source/channel quantifiers, per-input versus source-averaged endpoint constraints, and Jensen's one-way transfer between hidden-row and posterior targets.
- `POSTERIOR_CHANNEL_primary_source_audit.v1.md`: unknown-channel exact indistinguishability, known-channel overlap, HMM emission restrictions, DUDE, filter robustness, and adaptive-versus-oblivious comparisons.
- `STATIONARY_BINARY_THRESHOLD_primary_source_audit.v1.md`: separated-site conditional independence, uniform count normalization, Chan-Darwiche log-ratio oscillation, Hilbert metric stability, noisy universal prediction, and consistency versus clean-rate crossover.

Relevant primary URLs retained for those inherited ingredients are:

- Chan-Darwiche conditional-belief bounds: https://cdn.aaai.org/AAAI/2002/AAAI02-081.pdf
- Cohen-Fausti Hilbert metric: https://arxiv.org/html/2309.02413v2
- Conclique conditioning: https://arxiv.org/pdf/1205.6086 and https://arxiv.org/pdf/1808.04739
- Weissman-Merhav noisy prediction: https://webee.technion.ac.il/people/merhav/papers/AAP158.pdf
- Known-channel DUDE: https://web.stanford.edu/~tsachy/pdf_files/Universal%20Discrete%20Denoising%20Known%20Channel.pdf

In the positive-floor upper, theta_u(c)>=eta implies Pi(u)>=eta^2 and contraction of the TWO-STEP pair kernel with a common mass K^2 eta^2. The one-step pair matrix retains its structural zeros. No separate IID or independent-edit assumption appears. The clean occupation and martingale arguments supply estimation; pathwise count perturbation handles adaptivity. Hamming preimages then localize log-likelihood oscillation to O(k) local factors. This explains the factor k multiplying statistical parameter error without replacing the actual posterior by the transition row at the displayed endpoint.

The floor is uniform in M, not merely strict positivity at each horizon. Mixing alone does not supply that floor in the larger D2 class. The positive-floor theorem excludes rare-symbol constructions with probabilities approaching zero, but the new lower needs no such rarity. The upper applies to every fixed finite alphabet; the matched consequence audited here is binary only.

## 6 Recommended formulation and scope corrections

Suggested positioning:

> We use a disclosed offline observation kernel with a strict raw-token edit budget. Exact normalization within disjoint count bins, combined with conditional score differentiation and local stationary binary alternatives, yields a quantitative lower for estimating the clean next-symbol conditional law. Together with a Hamming-supported posterior stability upper, this gives the matching rate min{1,(k+1)/sqrt(M)} on fixed-positive-floor binary classes for fixed positive endpoint allowance.

Keep the following qualifications beside the rate: stationary initialization, fixed beta<1 and eta<1/2, fixed rho>0 for matching, hidden realized channel randomness, source-independent common C, future blindness, horizon-dependent alternatives, and uniform rather than fixed-source minimax risk.

The positive-floor upper and its earlier review say that no matching lower is established. The new quantitative lower supersedes those historical scope statements for the specified binary intersection, without changing their upper theorem. It does not establish a matching rate for all finite alphabets, the full binary D2 class, moving floors, or causal-only channels. The earlier square-root audit's statement that no sharp risk formula had yet been supplied should likewise be read in its historical context.

The new covariance proof removes the old lower's normal-approximation dependency. It does not remove the need to prove full-output masses, joint scaffold-bin overlap, retained-neighbor eligibility, endpoint independence given the scaffold, or the nuisance-parameter subtraction. No theorem here implies an efficient algorithm, a neural realization, or robustness against future-aware attacks.

## 7 Provenance and reading limits

Both current theorem files and both independent reviews were read completely. Relevant sections of the previous primary-source audits were reread; their inherited sources were not all reaudited. New source reading scopes are listed individually above. The independent reviews report scoped mathematical validity; this report does not upgrade that to formal verification or external peer review.

Present-time SHA-256 bindings for the current inputs:

- `KNOWN_CHANNEL_stationary_binary_quantitative_lower.v1.md`: `2c7995314aaf395ae6bbf0dbd9bff671c83554b9d93a85241875a5d85b6ed54a`.
- `KNOWN_CHANNEL_stationary_binary_quantitative_lower_independent_review.v1.md`: `fd7ebf3c198ee0c95aeaaa84b49d1631fe2da7ff3802779ebe95f28846ddc1f4`.
- `KNOWN_CHANNEL_uniform_positive_floor_upper.md`: `93379139b31483502d4b6d9efdda02b3f122f592c8cec7274e83d36696b09b5b`.
- `KNOWN_CHANNEL_uniform_positive_floor_upper_independent_review.v1.md`: `663a2e10536411b0c34cc4b03cd864de06161da1bb999c92cde1b3835f4acbf1`.

These identify the bytes read now, not an earlier historical state. Search was targeted to quantization and score methods, coarsening, known-kernel inversion, robust Markov estimation, and the exact statistical target. It was not exhaustive. Secondary summaries served discovery only. An OpenReview copy returned a browser-verification page; no challenge was solved. The authors' accessible arXiv version was inspected separately. One requested arXiv HTML version was absent, and a final JMLR record could not be verified; these limitations do not affect the cited accessible primary text. No scientific executable check, source mutation, or public upload occurred.
