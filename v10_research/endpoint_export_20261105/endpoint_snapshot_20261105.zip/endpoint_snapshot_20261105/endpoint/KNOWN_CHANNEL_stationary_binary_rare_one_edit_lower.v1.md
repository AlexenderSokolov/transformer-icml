# Stationary binary prediction: a rare-event one-edit obstruction

Date: 2026-11-05 UTC. Pure mathematical analysis. No executable scientific checks, public writes, novelty certification, or efficient-computation claim. This is a new proof draft requiring independent review.

## Result

Fix 0<beta<1. There are c_beta>0 and M_beta<infinity such that, for every M>=M_beta and every 0<=rho<=1, a single disclosed, source-independent, future-blind binary channel with strict Hamming budget ONE and per-input terminal-pair-change probability at most rho, together with two stationary genuinely second-order sources in D2(beta), satisfies

    inf_predictor max_{q in {q_-,q_+}}
      E_q |predictor(Z)-P_q(X_(N+1)=1 | Z)|
        >= c_beta rho M^(-1/3),                 (R1)

where N=M+2. The channel is common to the alternatives and disclosed to the predictor. Every conditional target is formed under its own fixed source.

For fixed rho>0 this rules out an O_beta,rho((k+1)/sqrt(M)) upper over the full stationary binary D2(beta) class, already at k=1. It does not contradict the fixed-positive-transition-floor result: the transition floor here vanishes like M^(-1/3). The existing power-1/3 upper in ((k+1)/sqrt(M)) remains valid and is not matched by this lower.

## 1. Source family and stationary law

Let d=(1-beta)/64, r=4d, q_-=1-d, q_+=1+d. Choose a fixed tau>0 sufficiently small depending on beta, with tau<=d/4. Set

    t=t_M=tau M^(-1/3),
    theta_q(00)(1)=theta_q(01)(1)=t,
    theta_q(10)(1)=r,
    theta_q(11)(1)=q t.                           (R2)

All probabilities are strictly between zero and one. The source is genuinely second order because theta_q(00)(1)=t differs from theta_q(10)(1)=r. Its unique stationary pair law is

    Pi_q(00)=u_q,
    Pi_q(01)=Pi_q(10)=u_q t/(1-r),
    Pi_q(11)=u_q t^2/[(1-r)(1-q t)],              (R3)

where u_q normalizes the four masses. The two balance identities are Pi(01)(1-r)=Pi(00)t and Pi(11)(1-q t)=Pi(01)t. These identities and normalization verify stationarity. In particular the stationary minority-symbol mass is O_beta(t).

## 2. All-state D2(beta) certificate

For pair states s=(a,b), v=(c,e),

    P_q^2(s,v)=theta_q(s)(c) theta_q(b,c)(e).

Write q_min=1-d, q_max=1+d. Since t<=tau<=d/4 and r=4d, we have q_max t<=r and t<=r. Using u_q<=1 in (R3), the four target-pair ratios obey, uniformly over the starting pair,

    P_q^2(s,00)/Pi_q(00) >= (1-r)(1-q_max t),
    P_q^2(s,01)/Pi_q(01) >= (1-r)^2,
    P_q^2(s,10)/Pi_q(10) >= q_min(1-r)(1-q_max t),
    P_q^2(s,11)/Pi_q(11) >= q_min^2(1-r)(1-q_max t).

For the 00 bound, when b=0 the two relevant rows have successor-one probabilities at most r and t, respectively; when b=1 they have successor-one probabilities at most q_max t and r. This gives its displayed product bound. For the 01 bound, when b=0 the ratio is (1-theta_q(s)(1))(1-r)/u_q >=(1-r)^2; when b=1 it is (1-theta_q(s)(1))r(1-r)/(u_q t), at least (1-r)^2 because q_max t<=r and r>=t. The 10 and 11 bounds follow directly from theta_q(s)(1)>=q_min t and the corresponding lower bounds on the second factor.

All four ratios are consequently at least

    (1-d)^2 (1-r)^2 (1-q_max t)
      >= 1-2d-2r-q_max t
      >= 1-11d > beta.                          (R4)

Thus both sources lie in the all-state class D2(beta). Their pair chains have a common geometric mixing bound with fixed beta.

## 3. Close clean experiments

The transition tables differ only at row 11. The Bernoulli KL inequality gives

    KL(P_+^(1:N) || P_-^(1:N))
      = KL(Pi_+||Pi_-)
          + M Pi_+(11) KL(Ber(q_+t)||Ber(q_-t))
      <= KL(Pi_+||Pi_-) + C d^2 M t^3
      = KL(Pi_+||Pi_-) + C d^2 tau^3.            (R5)

Here C can be an absolute finite constant after the above bounds on r,t,q. The initial-law term tends to zero: each of the four coordinate ratios Pi_+(s)/Pi_-(s), as given explicitly by (R3), tends to one. Choose tau still smaller if needed, then M_beta larger, so Pinsker yields

    TV(P_+^(1:N),P_-^(1:N)) <= 1/8.             (R6)

The same bound holds for every common deterministic function of the observed clean word. This choice is independent of rho.

## 4. Conditionally independent rare editable bits

Take candidates j to be multiples of 3 in [3,N-5]. A candidate is eligible when its four surrounding symbols have the pattern

    (X_(j-2),X_(j-1),X_(j+1),X_(j+2))=(1,1,0,0).

Let B=X_(N-1). Define H by retaining every clean coordinate except B and the eligible candidate bits, whose positions are marked missing. Eligibility is a function of noncandidate coordinates, does not use B, and is recoverable from H. Let I be the eligible set, n=|I|, and S=sum_{j in I} X_j.

No order-two likelihood factor contains two candidates. All factors involving an eligible candidate end by N-3, whereas the factors involving B end at N-1 or N. Conditional on H, the eligible bits are independent and identically distributed and are independent of B. Their Bernoulli probability is

    p_q = A_q/(A_q+B_q) = q t/[1+(q-1)t],
    A_q = (q t)(1-q t)(1-r),
    B_q = (1-q t)(1-r)(1-t).                    (R7)

In particular S|H is Binomial(n,p_q), with odds p_q/(1-p_q)=q t/(1-t).

Consider the retained terminal-scaffold event

    A={X_(N-3)=X_(N-2)=X_N=0}.                  (R8)

On A, the two unnormalized conditional weights of B are

    B=1: theta_q(00)(1) theta_q(01)(0)=t(1-t),
    B=0: theta_q(00)(0) theta_q(00)(0)=(1-t)^2.

Thus B|H is exactly Ber(t), independent of q, whenever A holds. The future row equals t for B=0 and r for B=1.

## 5. A one-edit channel

The channel uses the following public rule, independent of q.

- If A fails, n=0, or S>=2, return the entire word unchanged.
- If A holds, n>=1 and S=1, erase the sole eligible one and leave B unchanged.
- If A holds, n>=1 and S=0, leave all eligible bits unchanged and flip B with probability rho, using an independent coin.

Each realization makes at most ONE raw-token edit. The terminal pair changes only in the S=0 branch, with probability rho for each such input; all other inputs have endpoint-change probability zero. The channel is future-blind and does not change the physical endpoint.

H is left unchanged and remains recoverable. On A with n>=1, the output has eligible count zero if and only if the S<=1 branch ran. Inputs with S>=2 remain at counts at least two. Thus branch identification has no collisions and uses no exposed edit mask or extra symbol.

## 6. Exact source-specific posterior target

Fix H satisfying A and n>=1. Write

    a=n t/(1-t),
    g_q=P_q(S<=1|H)=(1-p_q)^n(1+q a),
    v_q=P_q(S=0|H,S<=1)=1/(1+q a),
    T_q=rho v_q.                               (R9)

On this branch the displayed eligible bits are all zero. The clean B is independent of S and is Ber(t). Its displayed value W is B xor D where D has conditional probability T_q. Let

    ell_q(0)=t T_q+(1-t)(1-T_q),
    ell_q(1)=t(1-T_q)+(1-t)T_q.

For w=0 the clean-endpoint posterior is

    F_0(t,T_q)=t T_q/[t T_q+(1-t)(1-T_q)].        (R10)

The actual next-symbol target is exactly

    p_q(1|Z)=t+(r-t) F_w(t,T_q).                (R11)

If f_q(H) is the clean scaffold law, each branch output has mass

    f_q(H) g_q ell_q(w).                        (R12)

There is no mixture over q in these conditional targets.

## 7. Typical scaffold and a positive overlap

The stationary probability of eligibility at one candidate is exactly

    Pi_q(11)(A_q+B_q)
      =u_q t^2[1+(q-1)t].                      (R13)

There are M/3+O(1) candidates. Hence E_q n/(M t^2) tends to 1/3 uniformly for the two alternatives.

The common geometric mixing bound gives

    Var_q(n) <= C_beta M t^2.                   (R14)

One direct justification is to sum covariances of the fixed five-symbol eligibility indicators. For overlapping windows, each absolute covariance is at most the eligibility probability O(t^2). For disjoint windows, condition on the pair at the end of the earlier window: the conditional probability of the later event differs from its stationary value by at most the pair-chain TV mixing bound. Multiplication by the earlier event probability supplies the O(t^2) factor before the geometric lag sum. This is a rare-event variance bound, not the cruder O(M) bound.

Because M t^2=tau^2 M^(1/3) tends to infinity,

    T={M t^2/4 <= n <= M t^2/2}

has probability tending to one under both sources. Also P_q(A^c)=O_beta(t) by the stationary minority mass and a union bound. Therefore, for all sufficiently large M, P_q(A intersect T)>=7/8. Combining with (R6) by data processing,

    sum_{H in A intersect T} min(f_+(H),f_-(H)) >=3/4.  (R15)

## 8. Separation and lower bound

On T, because M t^3=tau^3 and t<=1/2,

    tau^3/4 <= a=n t/(1-t) <= tau^3.

Consequently

    v_- - v_+
      =2d a/[(1+q_-a)(1+q_+a)] >= b_beta>0,     (R16)

and 1-v_q>=b'_beta>0, with fixed positive constants. Also p_q<=2t for the chosen tau, so n p_q<=tau^3 on T; using log(1-p)>=-2p for p<=1/2,

    g_q >= (1-p_q)^n >= exp(-2tau^3)=g_*>0.

For every rho in [0,1],

    ell_q(0)>=(1-t)(1-v_q)>=b'_beta/2=:ell_*>0. (R17)

Exact subtraction in (R10), and ell_q(0)<=1, give

    |F_0(t,T_-)-F_0(t,T_+)|
      =t(1-t)|T_--T_+|/[ell_-(0)ell_+(0)]
      >= t(1-t)rho b_beta.

Since t<=r/2 and t<=1/2, the target gap on these w=0 outputs is at least

    |p_-(1|Z)-p_+(1|Z)| >= (r b_beta/4) rho t.  (R18)

By (R12), (R15) and (R17), the overlap of these branch outputs with H in A intersect T and w=0 is at least (3/4)g_*ell_*. For every predictor, the sum of its two expected absolute losses is at least the overlap-weighted target gap. Dividing by two proves (R1), since t=tau M^(-1/3).

## Scope and next question

- This already refutes a linear (k+1)/sqrt(M) upper without a fixed transition floor, even for one edit.
- The constants depend on fixed beta<1. The beta=1 iid boundary is excluded.
- The alternatives and the known channel depend on the horizon, as allowed in the minimax experiment.
- The initial pair law is the exact stationary law of each source, not an independently chosen or arbitrary initial law.
- The channel may inspect all available history and is not online-causal. It is future-blind.
- This artifact does not establish a sharp rate, a matching upper, or the general-budget heuristic lower (k^2/M)^(1/3). The latter requires a separate bin construction and proof.
