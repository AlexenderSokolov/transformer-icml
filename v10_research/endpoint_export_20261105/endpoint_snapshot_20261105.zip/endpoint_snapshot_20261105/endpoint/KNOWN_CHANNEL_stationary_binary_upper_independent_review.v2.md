# Independent analytical review: improved stationary binary known-channel upper

Date: 2026-11-05 UTC. Present-time clock check: 03:22:04 UTC; final candidate digest and clarified scope were checked immediately afterward.

## Finding and exact file binding

I find the improved argument valid, including the explicit constants in (V3)-(V10) and the consequence

    Risk <= min{1,C_beta[(k+1)/sqrt(M)]^(1/3)}.

The reviewed candidate is:

    KNOWN_CHANNEL_stationary_binary_upper.v2.md
    SHA-256: e4b5840206bff6735b5cce4a6dfeb70d9ea2568341dc0128773fa6c68327156b

The complete draft was read and its final scope clarification was rechecked. This is a present-time binding to the current candidate, not a historical digest assertion. The author indicated that this version is frozen. The earlier v1 candidate and review are unchanged and remain valid independently.

No counterexample or substantive gap was found within the stationary binary, fixed positive-beta, known future-blind strict-Hamming-channel assumptions. The result gives a sufficient regime k=o(sqrt(M)) for uniform consistency, not a necessary budget threshold or a sharp minimax rate.

This is analytical review, not formal verification, external peer review, or novelty certification. Tool use consisted only of document reads, file hashing, and writing this review. No scientific program, numerical experiment, public write, or external literature search was performed.

## 1. Source and occupation bounds

The source assumptions are the original all-state second-order condition P^2(s,t)>=beta Pi(t), not a silently narrowed first-order model. The implications theta_u(c)>=beta pi(c) and Pi(a,b)>=beta pi(a)pi(b) are valid. On the branch with stationary minority mass m>=a, all pair masses are at least beta a^2 and every row coordinate is at least beta a.

For the stationary pair-state indicator I_t=1{S_t=u}, its lag-h covariance is exactly Pi(u)[P^h(u,u)-Pi(u)]. The minorization gives absolute value at most Pi(u)(1-beta)^floor(h/2). Summing this series yields Var(J_u)<=5M Pi(u)/beta, with room in the constant. Chebyshev then gives (V3).

The predictable-row successor error has second moment at most M Pi(u). On the event J_u>=M Pi(u)/2, the expected restricted clean add-one error is at most 2/sqrt(M Pi(u))+2/(M Pi(u)). This uses the unconditional martingale moment, not a claimed martingale property after conditioning on the occupation event.

The pathwise same-row corruption bound adds at most 6k/(M Pi(u)) on that event. On its complement the full corrupted row error is at most one, so the bad-event probability is charged once. Summing the four resulting row bounds gives exactly

    B_row=8/[sqrt(beta)a sqrt(M)]
            +(8+24k+80/beta)/[beta a^2 M].

The coordinate clipping cannot increase error against a true row in [beta a,1-beta a]. This validates (V4), uniformly over adaptive channels.

## 2. Independent initial-pair estimate

There are exactly M context pairs at end times 2,...,N-1, so J'_u/M is a probability vector with no boundary normalization discrepancy. One token edit affects at most two counted context pairs. Its TV perturbation is therefore at most 2k/M.

For the clean empirical law, Cauchy-Schwarz and the stationary variance bound give

    E TV(Pi_emp,Pi)
       <=(1/2) sum_u sqrt(5 Pi(u)/(beta M))
       <=sqrt(5/(beta M)).

This proves (V5). The lower-floor simplex is nonempty because its four lower bounds sum to beta a^2<=1. The true Pi is feasible when m>=a. L1 projection optimality and the triangle inequality therefore imply Delta<=2TV(Pi_raw,Pi), with the displayed B_init. A fixed tie rule is sufficient; the observation space is finite.

The independently fitted initial law is allowed not to be stationary for the fitted transition table. An estimator may use any normalized surrogate distribution. This is not an unauthorized relaxation of the generating-source class: the true source remains stationary throughout the risk analysis. The surrogate clean-word likelihood is a valid probability distribution because its initial law and transition rows each normalize.

## 3. Global posterior bound

True and fitted initial masses have a common lower floor beta a^2/4, and row probabilities have floor beta a/2. The global logarithm bounds in section 4 consequently hold without a small-error event. For an individual coordinate, absolute probability error is at most TV, so Delta and epsilon have the correct normalization in these bounds.

For two latent preimages of one observed word, Hamming distance is at most 2k and at most 6k historical triples differ. The unchanged triple log-ratio terms cancel. The initial contribution is at most 8Delta/(beta a^2), and the changing triple contribution is at most 24k epsilon/(beta a). This proves (V7).

The same disclosed kernel C multiplies both likelihoods, so it cancels in the posterior ratio. The argument requires no lower bound on output probability and no local or independent-edit structure. All relevant clean-word laws are positive in the m>=a branch, ensuring the fitted posterior denominator is positive for every possible true observation.

A likelihood-ratio oscillation L gives posterior ratios in [exp(-L),exp(L)] after normalization, hence TV at most 1-exp(-L)<=L. Averaging the respective next-row distributions adds at most epsilon. The comparison is pointwise at the observed z, so the estimated parameters may depend on z. Integrating gives (V8) exactly.

Future blindness is retained and is necessary for the actual prediction target to be the posterior average of the clean terminal row.

## 4. Rare-source branch and optimization

The minority-threshold argument is unchanged from the valid v1 proof. With k/M<=a/2, stationarity and the pathwise frequency perturbation give the deviation probability 20/(beta M a^2).

When m<a, both an erroneous plug-in choice and a wrong majority choice require that deviation. When a<=m<=4a, plug-in risk is controlled and the correct-majority loss contributes at most 4a. When m>4a, selecting the majority branch itself requires the deviation. Loss on an observation-selected event is bounded by the unconditional nonnegative loss of predicting the true majority; no false conditional stationarity assertion is used. This validates the conservative 40/(beta M a^2) term in (V10).

Set g=(k+1)/sqrt(M) and a=g^(1/3). In the nontrivial branch a<=1/16, k/M<=a^3/sqrt(M)<=a/2. The non-frequency terms are bounded by

    C_beta[g/a^2+g^2/a^3]
       =C_beta[a+a^3].

Also 1/(M a^2)<=a^4<=a, since g^2>=1/M. The unit-risk fallback handles a>1/16. The theorem's rate follows. For fixed k it is O_beta(M^(-1/6)), but the clean k=0 rate is better via the existing clean estimator.

## 5. Scope retained

- Uniformity is over stationary binary sources and all disclosed future-blind channels obeying the strict support budget, without any endpoint-reliability restriction.
- The constants depend on beta. Neither beta=0 nor an optimized moving-beta conclusion follows from the displayed asymptotic rate.
- Unknown initial laws, an unknown channel, and alphabets with a separate rare nuisance symbol are materially different experiments. The existing one-edit lower bounds in those settings do not contradict this theorem.
- No lower shows that k=o(sqrt(M)) is necessary for stationary binary consistency.
- The theorem does not establish efficient posterior computation, finite rational representation of arbitrary channel kernels, a neural implementation, a ternary result, or external novelty.

## Sources inspected

The complete improved candidate was checked against `KNOWN_CHANNEL_stationary_binary_upper.md`, `EDIT_OVERLAP_and_TARGET_BOUNDARIES.md`, `EPR001_endpoint_probability_interpolation.md`, `POSTERIOR_PREDICTION_channel_identifiability.md`, and the local known-channel lower-bound notes. The detailed v1 review provides additional checks of the common source, threshold, and channel-comparison interfaces.
