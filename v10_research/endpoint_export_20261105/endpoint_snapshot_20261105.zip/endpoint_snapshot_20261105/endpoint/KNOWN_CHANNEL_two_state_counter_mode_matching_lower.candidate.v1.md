# A genuinely paid counter mode reduces the matching lower to two base states

5 November 2026 UTC. Pure analytical candidate for independent review. No scientific executable checks or public writes. The reviewed eight-state proof and three-state exact compression remain unchanged. This is a different channel, not a claim of pathwise equivalence to either predecessor.

## 1. Proposed consequence

For fixed 0<beta<1, sufficiently large M, N=M+2, integer 1<=k<=M and rational rho in [0,1], the matching endpoint lower

    c_beta min{rho,(k^2/M)^(1/3)}                         (C1)

is attainable with **two base states**, plus the separately charged actual k+1-valued edit counter and the paid time-indexed table. Thus the full matching profile from the original thinning-mode proof would hold for S>=2 after independent acceptance.

The counter is never relabelled or overwritten. A genuine initial erasure costs one edit; whether that edit occurred records the mode as e=0 versus e>=1. An observable prefix branch makes its conditional prior exactly common to the two source alternatives. The tail uses two base states only to compute its time-scheduled two-symbol gates.

No lower or impossibility statement for S=1 is asserted.

## 2. Source design and initial block

Use the same rare stationary family, d=(1-beta)/64, r=4d, and a sufficiently small fixed positive dyadic tau<=min{d/4,1/256}. For k>=3 put

    h=min{k-2,floor(sqrt M)},
    q_-=1-d/h, q_+=1+d/h.

Choose t to be the largest power of two not exceeding tau(h^2/M)^(1/3). Then

    (tau/2)(h^2/M)^(1/3)<t<=tau(h^2/M)^(1/3),
    L=1/t is an integer.                                  (C2)

For sufficiently large M, uniformly over h>=1, L<=M/64. This follows from L<=2tau^(-1)M^(1/3), so L/M tends uniformly to zero.

The source rows are theta(00)(1)=theta(01)(1)=t, theta(10)(1)=r, theta(11)(1)=qt, with the already reviewed stationary law

    Pi_q(00)=u_q,
    Pi_q(01)=Pi_q(10)=u_q t/(1-r),
    Pi_q(11)=u_q t^2/[(1-r)(1-qt)].

These sources have the reviewed all-state D2(beta) certificate. The public channel uses h,L and rho, not the unknown q. Its dependence on the common design t through the integer L is allowed and explicitly paid.

## 3. Exact two-state channel

Use base states F0,F1, initialized to F0. The subscript is a gate accumulator, not an extra counter. At every step the actual edit count updates exactly by 1{x_i!=z_i}.

Initial phase: at positions 1,...,L, erase a raw one exactly when e=0. Otherwise output the raw bit. Always reset the base state to F0. This erases the first one in the block and no other bit, spending at most one edit. At L+1,L+2 output unchanged and reset to F0.

Let the tail candidates be

    J_L={L+2+3a: a>=1, L+2+3a<=N-5},
    epsilon=1/(2h).

The windows {j-2,j-1,j}, j in J_L, are disjoint and occur after the two untouched anchor positions. For current state Fb:

1. At j-2: output unchanged and move to F_(x_i).
2. At j-1: output unchanged and move to F_(b*x_i).
3. At candidate j: if b=1, x_i=1 and 1<=e<h+1, erase with probability epsilon; otherwise output unchanged. Reset to F0 after either outcome.
4. At N-3: output unchanged and move to F_(1-x_i).
5. At N-2: output unchanged and move to F_(b*(1-x_i)).
6. At N-1: if b=1 and 1<=e<k, flip with probability rho; otherwise output unchanged. Reset to F0.
7. At all remaining times, output unchanged and reset to F0.

All thinning and endpoint coins are independent auxiliary randomness. All rows are normalized rational rows, including unreachable rows. The counter guards apply to every row.

When the initial block contains no one, e=0 and the entire later channel is identity. When it contains at least one one, its first one is erased, e=1, and the later mode is active. At most h additional candidate erasures and one endpoint flip occur. Thus every input/coin realization has at most h+2<=k edits. The endpoint is changed with probability at most rho on every fixed raw word. The raw final symbol is never edited or read before the penultimate action.

The gate invariant is exactly the reviewed three-state addendum's invariant: before a tail candidate b=1{preceding raw pair11}; before N-1, b=1{preceding raw pair00}. No extra mode state is present. The distinction e=0 versus e>=1 follows from a real paid edit, and e continues to equal the exact number of changed coordinates.

## 4. An observable branch with a common, nondegenerate mode prior

Consider the observable prefix event

    B_pre={Z_1=...=Z_(L+2)=0}.

Since only the first raw one in positions1,...,L can be erased, this event is exactly: the first L raw bits contain at most one one, and the two untouched anchors X_(L+1),X_(L+2) are zero. There are no other raw preimages of this output prefix.

On this branch, define U=0 when the initial block had no one and U=1 when it had exactly one. Then the actual counter at the tail entrance is exactly U.

The raw all-zero word of length L+2 has probability

    w_0(q)=u_q(1-t)^L.

If the single one is at position1 or2, its probability is u_q t(1-t)^(L-1). If it is at any position a in {3,...,L}, its probability is u_q t(1-r)(1-t)^(L-2). Therefore the ratio of total single-one mass to zero-one mass is exactly

    R=2t/(1-t)+(L-2)t(1-r)/(1-t)^2.                    (C3)

No word in this calculation contains a context11. Every q-dependent initial mass is the same factor u_q. Thus R is exactly independent of q, not merely asymptotically so.

Since Lt=1, t<=1/256 and r<=1/16, the formula gives

    1/2<=R<=2,
    omega:=P_q(U=1|B_pre)=R/(1+R) in [1/3,2/3].        (C4)

For example the lower follows from (1-2t)(1-r)>1/2; the upper follows by replacing 1-r by1, giving (1-2t^2)/(1-t)^2<2.

The branch probability is

    b_q=P_q(B_pre)=u_q(1-t)^L(1+R)>=1/32.             (C5)

Indeed u_q>=1-3t>=1/2 and log(1-t)>=-2t imply (1-t)^L>=exp(-2); half of exp(-2) exceeds1/32.

Conditional on B_pre and either U, the tail begins from the same raw pair00 at the two anchors. The order-two Markov property makes the subsequent raw trajectory independent of U. Thus the conditional mode prior omega is common to both source alternatives and independent of the entire raw tail. The later coins retain their independence.

This exact prefix calculation is what legitimizes using the actual counter to carry mode information. A gratuitous extra counter bit or an initial visible forced flip would not give this conclusion.

## 5. Tail estimates from the fixed initial pair00

Conditional on B_pre, the tail has M-L raw symbols and starts at a fixed pair00. It is not stationary; we account for this by exact conditioning domination rather than a burn-in approximation.

Consider the same future tail under a stationary source, including its initial pair at the two anchor locations. Its conditional law given that pair is00 is exactly the fixed-start law Q_q used here. Since Pi_q(00)=u_q>=1/2, for every nonnegative functional F of this tail,

    E_(Q_q) F
       =E_(stationary q)[F 1{initial pair00}]/u_q
       <=E_(stationary q) F/u_q.                       (C6a)

The same domination applies to every tail event. No endpoint/count independence is assumed.

Under the stationary comparison, the tail count n_00 of candidate patterns11?00 has mean |J_L|u_q t^2[1+(q-1)t] and variance at most C_beta Mt^2 by the reviewed rare-window bound. Because L/M tends uniformly to zero and Mt^2>=(tau^2/4)M^(1/3), for sufficiently large M its stationary mean divided by Mt^2 lies in[9/32,11/32]. Its probability of leaving [Mt^2/4,Mt^2/2] therefore tends uniformly to zero. Apply(C6a) to that bad event to obtain

    Q_q(Mt^2/4<=n_00<=Mt^2/2) tends uniformly to1.      (C6)

Likewise every terminal-coordinate minority probability under Q_q is at most its stationary probability divided by u_q, hence at most4t. The expected number of candidate111 patterns is at most |J_L|Pi_q(11)qt/u_q<=C Mt^3.

The two fixed-start raw tail experiments have TV at most1/8 after choosing tau small. Their initial pair is identical, and only the11 row differs. Its KL is at most C d^2t/h^2. By(C6a), expected visits to11 are at most M Pi_+(11)/u_+<=C Mt^2. Hence

    KL(Q_+||Q_-)
       <=C_beta d^2 Mt^3/h^2<=C_beta d^2 tau^3.       (C7)

This is uniform in h and requires no nonstationary initial-law estimation or transient-error term.

Define the tail scaffold H by retaining all tail coordinates except the eligible candidate bits and B=X_(N-1). Eligibility depends on the two untouched noncandidate predecessors, so H is recoverable. Conditional on H the missing candidate bits are independent, independent of B, and have exactly the four odds

    o_q(00)=qt/(1-t),       o_q(01)=qr/(1-r),
    o_q(10)=q^2t^2/[r(1-t)],
    o_q(11)=q^3t^2/[r(1-qt)].                         (C8)

The fixed pair at the anchors changes only retained factors and does not alter these local conditional identities.

Write L_+=sum_j o_+j, eta=1/64, and

    D={X_(N-3)=X_(N-2)=X_N=0}
        intersect {Mt^2/4<=n_00<=Mt^2/2}
        intersect {L_+<=eta h^2}.

The reviewed pointwise comparison o_+<=4p_q, followed by the candidate111 expectation bound, gives

    E_(Q_q) L_+<=C_beta Mt^3,
    Q_q(L_+>eta h^2)<=C_beta tau^3/eta.                (C9)

Choose tau small and M_beta large. The count, terminal and odds estimates give Q_q(D)>=7/8, uniformly in h. Equation(C7) and data processing then give, for the conditional tail scaffold laws f_q,

    sum_(H in D) min{f_+(H),f_-(H)}>=3/4.             (C10)

All constants are uniform. A later beta-dependent threshold H_beta will handle the cap perturbation, and the finitely many smaller budgets will use the already reviewed two-state one-edit fallback.

## 6. The common-prior thinning calculation

Fix H in D. Ignore the tail cap only as a comparison experiment. Under U=0 the candidate output law P_q0 is a product with probabilities p_qj=o_qj/(1+o_qj). Under U=1 the law P_q1 is the product with probabilities (1-epsilon)p_qj. Define

    m_q=(1-omega)P_q0+omega P_q1,
    Lambda_q=P_q1/P_q0,
    v_q=P_q(U=1|H,Y)
       =omega Lambda_q/(1-omega+omega Lambda_q).

The exact likelihood ratio remains

    Lambda_q(Y)=(1-epsilon)^(sum Y_j)
                   product_(Y_j=0)(1+epsilon o_qj).    (C11)

All product/odds estimates from the reviewed thinning-mode proof are pointwise at H and do not need its prior to be fair. In particular

    TV(P_q0,P_q1)<=1/16,
    TV(P_+0,P_-0)<=1/32,
    TV(m_+,m_-)<=1/32.                                (C12)

The last inequality uses the same common omega under both sources. These estimates follow from the unchanged chi-square bounds exp(1/256)-1 and exp(400d^2 eta)-1.

Let E_0={1/2<=Lambda_-<=2}, and let E_z require at least n_00/2 displayed zeros among the00 sites. On E_0^c, |P_-1-P_-0|/(P_-1+P_-0)>=1/3. Since omega in[1/3,2/3], m_-<=2(P_-0+P_-1)/3, so

    m_-(E_0^c)<=4TV(P_-0,P_-1)<=1/4.

Also m_-(E_z^c)<=2t<=1/128 by Markov. Therefore, for E=E_0 intersect E_z,

    sum_(Y in E)min{m_+(Y),m_-(Y)}>=1/2.              (C13)

Exactly as in the reviewed proof,

    log Lambda_+-log Lambda_->=Delta:=d tau^3/128
        on E_z,
    0<=log Lambda_+-log Lambda_-<=10d eta<log2
        on all outputs.                              (C14)

Thus Lambda_-,Lambda_+ lie in[1/2,4] on E. The common prior odds omega/(1-omega) lie in[1/2,2], so the posterior odds lie in[1/4,8]. The logistic derivative on that interval is at least1/16. It follows that

    J(H):=sum_Y min{m_+(Y),m_-(Y)}|v_+(Y)-v_-(Y)|
       >=J_*:=Delta/32.                               (C15)

This explicitly replaces the fair-prior constant; it does not silently reuse a half-prior argument.

## 7. Actual cap and counter bookkeeping

On U=1 the tail starts with e=1. Its guard e<h+1 permits exactly h additional erasures. On U=0 it starts with e=0 and permits none. The actual endpoint guard has one edit available in the active mode because e<=h+1<=k-1.

Conditional on H,U=1 in the uncapped comparison, the number of proposed tail erasures is a sum of independent Bernoulli variables with mean at most epsilon L_+<=h/128. Hence capped and uncapped mode-one output laws have TV distance at most

    a_h=(e/128)^h.                                    (C16)

Mode zero is unchanged. For a common mode prior omega, a mode-one change of TV at most a gives

    ||m'-m||_1<=2omega a,
    sum m'|v'-v|<=4omega a.

The same minimum-weight and triangle argument as the reviewed J-perturbation lemma therefore loses at most 6omega(a_++a_-) from J. Since omega<=2/3 and both errors are at most a_h,

    J_cap(H)>=J_*-8a_h.                               (C17)

Enlarge H_beta so 8(e/128)^h<=J_*/2 for h>=H_beta. Then J_cap(H)>=J_*/2 on every H in D. This is again a perturbation of the mode-posterior functional before applying any rare endpoint factor.

## 8. Endpoint target and scaling

Conditional on B_pre,H in D, the penultimate raw bit B is Ber(t), independent of the candidate bits, mode U and tail coins. This follows from the fixed-start Markov factorization and the separation of the removed sites; U is independent of the raw tail by Section4.

For the actual capped channel put v_q=v_q^cap(H,Y), T_q=rho v_q, and W=Z_(N-1). The mode is exactly the condition e>=1 at the endpoint, and its one reserved edit is available. Therefore the exact source-specific posterior identities remain

    ell_q(1)=t+(1-2t)T_q,
    p_q(H,Y,1)=t+(r-t)t(1-T_q)/ell_q(1).

The output mass on this branch is

    b_q f_q(H)m_q^cap(Y)ell_q(1).

Retaining W=1, exact subtraction and the two-source absolute-loss inequality give

    max_q Risk_q(Q)
      >=(1/2)*(r/4)*[rho t/(rho+t)]
          *min_q b_q*(3/4)*(J_*/2)
      >=c_beta min{rho,t}.                            (C18)

The extra prefix factor is at least1/32 by(C5); it is not omitted. This argument includes rho=0 and preserves uniformity in moving rho.

For k>=3, h>=min{k,sqrt M}/3. Hence t is bounded below by a fixed beta-dependent multiple of min{(k^2/M)^(1/3),1}. Since rho<=1, (C18) proves(C1) for h>=H_beta.

Increase M_beta so floor(sqrt M)>=H_beta. Then h<H_beta implies k<=H_beta+1, a bounded range. The already reviewed two-state compression of the one-edit channel supplies c_beta min{rho,M^(-1/3)} there, which is the required lower after absorbing this bounded k factor. This also covers k=1,2. Identity and protected-budget witnesses have one base state. Thus every witness in the matching sum fits S>=2.

## 9. Resource ledger and unresolved boundary

The new family has two base states and an actual k+1-valued edit counter. Its full expanded normalized rational table is charged, conservatively

    ell=O(N*2^2*(k+1)
             *[b_rho+log(h+1)+log(N+1)+1]).

The public integer L<=N, its derivation from the common dyadic design, table expansion and generator work are included. No mode bit is supplied for free and no counter value is assigned except by actual edits. The prefix activation consumes one edit, the interior cap h more, and the endpoint one more, all within k.

This would strengthen the sufficient base-state allowance from three to two. It would not establish minimality, eliminate the counter, prove a length-independent homogeneous finite-state theorem, or identify the S=1 minimax profile. The independent audit must check the prefix likelihoods, the genuinely paid mode, uniform fixed-start tail estimates, non-fair-prior constants and small-budget fallback.
