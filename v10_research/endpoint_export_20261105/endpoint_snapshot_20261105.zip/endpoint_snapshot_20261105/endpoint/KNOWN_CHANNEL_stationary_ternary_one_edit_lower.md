# Stationary ternary sources: one known-channel edit preserves an endpoint floor

Date: 2026-11-05 UTC. Pure mathematical analysis. No scientific executable checks, public write, external novelty claim, formal verification, or computational-efficiency claim.

## Result

Let M>=64, N=M+2, beta,rho in [0,1], and k>=1. There is one explicitly disclosed, source-independent, future-blind ternary channel with strict per-word Hamming budget ONE and terminal-pair change probability at most rho, and two stationary second-order D2(beta) sources, such that every predictor has maximum source-specific posterior-prediction TV risk at least

    rho(1-beta)/128.

The same conclusion with constant 1/512 holds using two strictly positive ternary transition tables. Their smallest transition probabilities tend to zero with M. This is full support, not a fixed positive lower bound on all transitions.

Consequently the stationary known-channel contrast is already binary versus ternary, not binary versus four symbols. Together with the stationary binary upper, fixed beta>0 admits uniform consistency at k=o(sqrt(M)) for K=2, but fixed k=1 can have a constant minimax endpoint floor for K=3 whenever beta<1 and rho>0. This is a uniform minimax lower with M-dependent sources, not a claim of pointwise inconsistency for one fixed positive source.

## 1. A ternary rare clone of one binary state

Put

    delta=1-beta,
    alpha=min(delta/2,1/4),
    Q(v,v)=1/2+alpha,
    Q(v,1-v)=1/2-alpha, v in {0,1}.

Take alphabet {0,1,*}. Define the collapse c(0)=c(*)=0 and c(1)=1. For 0<=p<1 define a first-order transition table by

    T_p(x,0)=(1-p)Q(c(x),0),
    T_p(x,*)=p Q(c(x),0),
    T_p(x,1)=Q(c(x),1).

Its stationary symbol law is

    pi_p(0)=(1-p)/2, pi_p(*)=p/2, pi_p(1)=1/2.

An equivalent stationary generation is to draw the stationary binary Markov chain V with transition Q and, independently at every time having V_t=0, replace that zero by * with probability p. A one remains 1. Since the displayed ternary symbol reveals V_t, this generation has transition T_p, rather than merely being a hidden Markov source.

Use the second-order table theta_(a,b)=T_p(b,.) and its stationary initial pair law

    Pi_p(a,b)=pi_p(a)T_p(a,b).

For every x,y, including the rare clone when p=0,

    T_p(x,y)>=(1-2alpha)pi_p(y).

Therefore the pair-chain all-state certificate is

    P_p^2((a,b),(c,d))
      =T_p(b,c)T_p(c,d)
      >=(1-2alpha)pi_p(c)T_p(c,d)
      >=beta Pi_p(c,d).

Thus both hypotheses belong to the stationary D2(beta) class. For p in (0,1), every transition entry and stationary pair mass is strictly positive.

## 2. One fixed known channel

The channel inspects the input word of length N and uses this algorithm:

1. If either of its last two symbols is *, return the word unchanged.
2. Otherwise let S be the number of * symbols in positions 1,...,M=N-2.
3. If S=0, flip the final binary symbol 0<->1 with probability rho, using an independent coin; otherwise leave the word unchanged.
4. If S=1, replace its sole interior * by 0 and make no other change.
5. If S>=2, return the word unchanged.

Every realized output differs in at most one token. The only branch changing the terminal pair has change probability rho for that input word. The channel does not use p, Q, the source hypothesis, future innovations, or an estimator seed. Its full algorithm is given to the predictor, but its realized branch and coin are not.

The deterministic interior edit when S=1 is allowed even for rho=0: rho bounds terminal-pair changes, not all changes.

## 3. Exact observable masses and predictive targets

Restrict attention to observations z=(h,1), where h is an arbitrary binary word of length N-1. Write

    H(h)=P_Q(V_(1:N-1)=h),
    b=h_(N-1), r=Q(b,1),
    m=#{t in {1,...,M}: h_t=0}.

Then 1/4<=r<=3/4 and E_H[m]=M/2 exactly. Set

    s_p=(1-p)^(1{b=0}),
    w0_p=(1-p)^m,
    w1_p=m p(1-p)^(m-1),
    g_p=w0_p+w1_p,
    D_p=1+(m-1)p,
    t_p=rho w0_p/g_p=rho(1-p)/D_p.

For m=0, take w1_p=0 and g_p=1; all displayed formulas remain valid since p<1.

Exactly S=0 or S=1 can produce this binary interior. The penultimate symbol must have remained binary, supplying s_p. The original last symbol must also be binary, because a terminal * makes the channel the identity. Conditional on the collapsed prefix h, the unnormalized original-last-symbol masses are

    a_p(1)=r, a_p(0)=(1-r)(1-p).

Their sum is intentionally not normalized: the missing mass is the excluded original terminal *.

Define

    ell_p=r(1-t_p)+(1-r)(1-p)t_p.

The exact probability of the whole observed word is

    P_p^Z(h,1)=H(h)s_p g_p ell_p.                 (T1)

The exact posterior probability that the original collapsed last symbol is 1 is

    A_p(h,1)=r(1-t_p)/ell_p.                     (T2)

The next symbol is generated from the original source state, not the edited display. In particular, the source-specific predictive probability of the event {X_(N+1)=1} is

    p_p(1 | h,1)=1/2-alpha+2alpha A_p(h,1).      (T3)

No prior averaging over the two source hypotheses occurs in (T1)-(T3).

## 4. Posterior separation has one sign

Take 0<=p0<p1<1. For the same binary prefix h, write the corresponding subscripts 0 and 1. Exact subtraction gives

    d:=t0-t1
      =rho m(p1-p0)/(D0 D1)>=0,                 (T4)

and

    A1-A0
      =r(1-r)[(1-p0)d+(p1-p0)(1-t0)t1]
          /(ell0 ell1)
      >=r(1-r)(1-p0)d/(ell0 ell1).              (T5)

Thus the change in branch probabilities and the selection bias from excluding a terminal * reinforce one another on the displayed-terminal-one event. There is no approximation or discarded O(p) term.

Both s_p and g_p=P(Binomial(m,p)<=1) are nonincreasing in p. Also

    r(1-r)>=3/16, ell_i<=3/4.

Using the probability of the event {1} to lower-bound TV between the ternary predictive laws, (T1)-(T5) imply

    min(P_0^Z(h,1),P_1^Z(h,1)) TV(p_0(h,1),p_1(h,1))
      >=H(h)s_1 g_1 (alpha/2)(1-p0)d.            (T6)

Indeed min(s0g0 ell0,s1g1 ell1)>=s1g1 min(ell0,ell1), and dividing min(ell0,ell1) by ell0 ell1 yields 1/max(ell0,ell1)>=4/3.

For every estimator q, including independent randomization, pointwise triangle inequality on overlapping observation laws gives

    Risk_0(q)+Risk_1(q)
      >=sum_z min(P_0^Z(z),P_1^Z(z)) TV(p_0(z),p_1(z)).

Summing only (T6), then dividing by two, yields

    max_i Risk_i(q)
      >=alpha(1-p0) E_H[s_1 g_1 d]/4.            (T7)

## 5. A boundary source and one full-support source

Set p0=0 and p1=p=1/M. Then

    g_1 d=rho m p(1-p)^(m-1).

For m>=1, use s_1>=1-p and (1-p)^(m-1)>=(1-p)^(M-1). The m=0 contribution is zero. Since E_H[m]=M/2,

    E_H[s_1g_1d]
      >=rho p(1-p)^M E_H[m]
      =rho(1-1/M)^M/2
      >=rho/8.                                  (T8)

The last inequality holds for M>=2. Equation (T7) therefore gives

    max_i Risk_i(q)>=rho alpha/32
                    >=rho(1-beta)/128.           (T9)

Source 0 never emits *, but its transition table is defined at every state and satisfies the all-state certificate. Source 1 has full support.

## 6. Both sources have full support

Instead choose p0=1/(2M) and p1=p=1/M. Now D0<=3/2 and

    g_1 d=rho m(p1-p0)(1-p1)^(m-1)/D0.

Consequently

    E_H[s_1g_1d]
      >=(2/3)rho(p1-p0)(1-p1)^M E_H[m]
      =rho(1-1/M)^M/6
      >=rho/24.                                 (T10)

As 1-p0>=3/4 for M>=2, (T7) gives

    max_i Risk_i(q)>=rho alpha/128
                    >=rho(1-beta)/512.           (T11)

Every transition probability is positive, while the rare-clone transition probabilities are of order 1/M. Both hypotheses use exactly their own stationary initial pair law.

## 7. Scope

- This is an existential channel lower, not a lower for every known channel. Identity has no endpoint ambiguity.
- One common channel serves both source hypotheses and obeys the strict per-input-word bounds. It is source-independent and future-blind.
- The unknown is the stationary source parameter p, not a separately chosen nonstationary initial law.
- Fixing beta in (0,1) does not prevent the construction. Fixing a positive lower bound on every transition probability would prevent this particular rare-clone sequence.
- The positive constant vanishes for beta=1 or rho=0. No nonzero bound is asserted there.
- The construction remains admissible for any allowed k>=1 and embeds in larger alphabets by adding unused symbols with next-symbol law pi_p. On every word containing any added symbol outside {0,1,*}, extend the channel by returning that word unchanged. This preserves the strict per-word channel bounds, and the same all-state minorization proof applies to the extended source.
- The result does not supply a computationally efficient predictor or an executable test.

## Dependencies

- `KNOWN_CHANNEL_one_edit_lower.md`: overlap-risk inequality, raw one-edit channel conventions, and K>=4 predecessor construction.
- `KNOWN_CHANNEL_stationary_binary_upper.v2.md`: the positive fixed-beta stationary binary consistency contrast.
- `POSTERIOR_PREDICTION_channel_identifiability.md`: source-specific posterior target and future-blindness convention.

This note is an analytical construction. Independent review status is reported separately.
