# Endpoint report input preservation record

Capture began at 2026-11-05T03:46:07Z, using the session clock immediately before file copying and mechanical SHA-256 capture. The copy/hash command completed during the same work interval. This is a present-time binding, not a historical attestation.

The inputs directory contains copies of all 21 top-level Markdown files in the endpoint-risk research directory at capture time. The copy operation preserved file metadata and did not edit the original files. No claim is made that operating-system read-only flags were set. INPUT_SHA256SUMS.txt records all 21 copied inputs. Existing proof, review, and attestation versions remain preserved.

The standalone user-facing HTML intentionally omits machine paths and internal coordination details. It contains technical source identifiers, complete hashes for seven central proof inputs, primary-source links and stated evidence limitations. The full input bundle is a preservation artifact; it is not itself approved as a public upload package.

Allowed operations during authoring: reading source documents; copying snapshots; mechanical hashing; writing HTML and documentary records; independent static factual and artifact review. No executable scientific, model, simulation, HTML parser/checker, browser rendering, or test-suite run is claimed. No pre-run executable-QA gate was requested because no such QA was run.

No remote upload, GitHub blob/tree/commit/ref write, or other publication was performed by the report author.
