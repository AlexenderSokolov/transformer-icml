# Report version 2 revision notes

Version 1 is preserved unchanged. Version 2 incorporates the independent static factual review's domain corrections and editorial clarifications:

1. State k>=1 explicitly for endpoint lower-bound witnesses in sections 5.4, 6, and 7, including section 7.3. Global parameter definitions still allow k=0; its endpoint contribution is zero.
2. State beta<1 explicitly for the strictly-positive approximation using a>0.
3. Clarify that the fixed-positive-floor positive theorem requires stationary initialization, a known channel, and the true posterior target together. The unknown-channel binary heat-bath witness already has all transitions at least 1/4, and hidden-original-row ambiguity is a different loss.
4. Render s(z_N) and s(z_(N-1)) more clearly, without altering the formula.
5. Use “input snapshots” rather than “read-only copies”; no filesystem read-only flag claim is made.
6. Update version metadata and final static-review status. Delivery remains gated on completed version-2 factual and artifact reviews; no executable/visual QA claim is made.

No source proof, predecessor, version-1 HTML, or version-1 review is overwritten. No remote upload or publication occurs as part of these revisions.
