# Independent review: centered likelihood flow and suffix score control

Review time: 2026-11-05 11:08:18 UTC.

## Decision and exact binding

**PASS for the exact identities and the stated suffix-only derivative lemma.** I fully read and independently checked:

- `KNOWN_CHANNEL_one_state_centered_likelihood_flow.research.v1.md`
- SHA-256: `44d7b71bdf913e510ddb7e5115f1226aaa33d8b37f5cf5f907bae34a32624e47`.

Under its fixed-channel and deterministic suffix-support assumptions, the positive bound is exactly

`E_t |Cov_t(g_t,S_all|Z)| <= sqrt(rho L I_step(t))`,

with constant one. The note correctly leaves the general S=1 strengthening and any resulting minimax theorem unresolved. This review binds the present inspected bytes, not an inferred historical digest. The original note is not modified.

## 1. Exact one-state path representation

For binary words, the actual edit indicators d and displayed word z determine the raw word uniquely as `x=z xor d`. The prefix sum of d is exactly the actual edit counter. Under the stated one-base-state kernel interface, multiplication of the successive kernel rows therefore gives the exact probability of that channel path.

This representation has no free shared mode outside the kernel state and counter. It includes chronological cap guards and zero-probability rows without division. Summing over all legal d gives the displayed-word likelihood D. The finite-state interface, rather than an arbitrary unrecorded persistent random seed, is essential to the claim that this product describes every legal S=1 kernel.

Future blindness identifies the true next-bit target with the clean-terminal-row average under the posterior. The signed correction A therefore yields (F1) exactly. On every endpoint-preserved path its row difference is zero; elsewhere its magnitude is at most one. The triangle inequality and the joint word/output normalization give `sum_z |A_theta(z)|<=P(endpoint changed)<=rho`, proving (F2).

This is an integrated signed-correction bound. It is not a pointwise bound on `A/D`, its derivative, or the derivative of the posterior distribution of the counter.

## 2. Source-dependent stationary initial law and full centering

The source parameter changes while the entire channel stays fixed. Thus differentiating a path weight gives the source score times that weight, with no channel derivative. The complete score includes the derivative of the stationary initial-pair law as well as all transition scores.

The displayed quotient derivatives are correct on common supported outputs. The direct derivative of the reference row b cancels with the corresponding term inside the derivative of A. Normalizing D centers the complete score by its posterior mean. This gives exactly

`dot p_t=E_t[dot h_t|Z]+Cov_t(h_t,S_t|Z)`.

Subtracting the Z-measurable reference b from h inside this covariance is legitimate because the score is centered. The row difference vanishes when the terminal pair is unchanged, which proves the endpoint-centered identity (F4). Omitting the denominator derivative would remove the required centering and change the expression.

The finite-difference cross-product (F5) is also an exact algebraic identity when both normalizers are positive. It is not yet an estimate of that cross-product under either observation law. At the stated interior parameter, positivity and fixed channel support ensure the relevant posterior normalizers are positive; impossible outputs can simply be excluded.

The note's distinction between these identities and a finite-parameter, data-dependent-estimator comparison is correct.

## 3. What the suffix assumption supplies

Take a fixed integer suffix length L with `N-L>=2`. The case L=0 is trivial if included; otherwise the suffix consists of the deterministic coordinates `N-L+1,...,N`. The channel is held fixed over the source family and leaves the entire preceding prefix unchanged on every allowed path.

Consequently

`partial_t log Pi_t(X_1,X_2) + sum_(i=3)^(N-L) s_i`

is a measurable function of Z at the parameter being analyzed. Its conditional covariance with g is exactly zero. This statement includes the source-dependent stationary initial-pair score; it is not dropped on an independence or mixing assumption.

Only `T=sum_(i=N-L+1)^N s_i` remains in the covariance. There are exactly L such transition terms, including those whose context straddles the observed-prefix/suffix boundary. No extra factor for the order-two context is needed: every transition whose successor lies before the suffix already depends entirely on observed coordinates.

The proof requires a fixed deterministic suffix support, not an unexamined data-dependent set of L locations. It does not require the suffix channel to be one-state or to ignore the observed prefix. Any fixed, source-independent, future-blind channel supported on changes only in that suffix satisfies the needed measurability statement. Internal channel conditioning or adaptive suffix choices do not alter the source-score calculation as long as this support condition holds.

## 4. Martingale orthogonality and the exact second moment

For the raw source filtration, each transition score satisfies

`E_t[s_i | X_1,...,X_(i-1)] = sum_c theta_t(c|context) partial_t log theta_t(c|context) = 0`.

This follows by differentiating the normalized transition row. The finite interior family makes the operation legitimate. Scores at different transition times are orthogonal by the tower property; they need not be independent.

Stationarity makes their second moments all equal to the defined scalar `I_step(t)`. Hence `E_t T^2=L I_step(t)` exactly. No conditioning on the channel, an edit event, or an occupation event is used in this equality. The channel can correlate its suffix edits with the raw trajectory arbitrarily within the stated assumptions.

The stationary initial score is absent from T because it is actually observed through the unchanged first two raw coordinates, not because its Fisher contribution was presumed zero. The condition `N-L>=2` is what guarantees this point. No D2 mixing or positive floor is needed for this martingale calculation beyond the regularity and finite information at the parameter in question.

## 5. Conditional variance and the role of rho

At a fixed source parameter, `b_t(Z)=theta_t(S(Z))(1)` is Z-measurable, even though it is not known numerically to an estimator. Conditional variance is at most squared error from any such reference, so

`Var(g_t|Z) <= E[(g_t-b_t(Z))^2|Z]`.

The squared difference is zero when the terminal pair is unchanged and at most one otherwise. Thus the claimed bound by the posterior endpoint-change probability is valid. Here g is the source's next-bit success probability as a function of its terminal history, not the next random Bernoulli outcome itself. The latter's aleatoric variance would not satisfy this bound.

Conditional Cauchy-Schwarz gives

`|Cov(g_t,T|Z)| <= sqrt(Var(g_t|Z) Var(T|Z))`.

Unconditional Cauchy-Schwarz then bounds its expectation by the square root of the two expected conditional variances. The first is at most the unconditional endpoint-change probability. The second is at most `E T^2`. This proves (F6) with constant one.

The note assumes a **per-clean-word** endpoint certificate, which safely implies that unconditional endpoint-change probability is at most rho under the source. For this particular lemma, only that unconditional consequence is used. Unlike the separate exponential-envelope fixed-floor proof, this argument does not need a weighted per-word factorization. In particular it never asserts the generally unjustified inequality `E[1_A T^2]<=rho E[T^2]`, nor independence of endpoint edits and source scores.

## 6. Consistency checks and limitations

At L=1, the endpoint-only rare-source barrier has `rho=1/M` and `I_step` of order M. The right side of (F6) is of constant order, consistent with its nonvanishing complete-score covariance. At rho=0 the terminal row is already determined by the displayed terminal pair, so the covariance vanishes exactly. The direct row derivative remains separate in both cases.

For arbitrary remote edits, the discarded prefix score is no longer necessarily a function of the observation. The previous actual-counter examples demonstrate this. An actual edit count k alone does not supply a deterministic suffix of length k or k squared, nor make the remaining score terms orthogonal after an arbitrary data-dependent selection.

The iid one-edit barrier disproves the proposed general missing-information bound that would justify replacing the second Cauchy-Schwarz factor by `C k^2 I_step`. It does **not** by itself disprove the functional-specific conjecture (F7), because the future row is constant in that iid example. The research note preserves this distinction correctly: (F7) is neither proved nor refuted here.

Even the valid suffix lemma is a scalar infinitesimal covariance estimate, not a minimax prediction-risk theorem. A risk argument still needs control of the direct row derivative, finite parameter changes and observation measures, estimator dependence, source boundaries, and the multidimensional source parameter. The one-step Fisher quantity can diverge when transition probabilities vanish. No uniform no-floor root-M or corruption-budget risk rate follows merely by substituting an estimation error into (F6).

The exact path identities and the suffix lemma therefore provide a valid positive control while leaving the general no-floor S=1 problem open, as the candidate states.

## Method and preservation

Pure analytical reconstruction, private document inspection, exact hashing and this separate review artifact. No scientific executable checks, numerical experiments, simulations, model runs, public writes, external novelty investigation, training claims, efficient evaluation result or finite-precision certificate. The original research note remains unchanged.
