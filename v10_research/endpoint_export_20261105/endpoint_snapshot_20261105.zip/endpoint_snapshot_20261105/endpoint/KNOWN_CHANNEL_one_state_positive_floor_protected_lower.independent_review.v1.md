# Independent review: fixed-floor protected one-state lower and composition

Review time: 2026-11-05 09:31:44 UTC.

## Decision and exact file binding

**PASS.** I fully read and independently checked the protected lower and its constants. The result genuinely supplies the missing protected-budget term inside the fixed-positive-floor class, rather than importing a rare-transition witness.

Reviewed candidate:

- `KNOWN_CHANNEL_one_state_positive_floor_protected_lower.candidate.v1.md`
- SHA-256: `7107da3ab4b928047801bd3cf2798c9156f0e74331995945948a204c69f32333`.

The candidate's bound `5k/(3072M)` is valid for every stated integer `M>=1`, `1<=k<=M`. The channel has one base state and a separately paid actual edit counter, protects both final coordinates, and is the same under both sources. Every source successor probability is at least 1/4, and both sources satisfy `D2(beta)` for every `0<beta<=1`.

This is a present-byte analytical binding, not an inference about a previous historical hash. Original candidates and reviews were not edited.

## 1. Sources, channel and paid activation

For k>=2, the definitions `h=k-1`, `epsilon=h/(16M)`, `p_plus=1/3` and `p_minus=(1-epsilon)/3` give `Delta=h/(48M)`. Since `epsilon<=1/16`, the success probabilities are at least 5/16 and the failure probabilities exceed 1/4. The stated floor therefore holds with room to spare.

For an iid source viewed as an order-two source, the pair-chain two-step transition law equals its stationary pair law from every starting pair. The D2 certificate thus holds with beta=1 and hence every smaller positive beta. No nonstationary initialization is introduced.

At initialization, forcing the first output to zero makes the actual edit counter exactly `X_1`. This is a genuine charged edit when activation occurs. The inactive counter-zero path cannot activate later. The active path can make at most h further candidate erasures before the counter reaches k. There is no uncounted mode bit, raw-history gate, auxiliary counter coding or persistent random memory.

Every row is normalized. The position-1 exhausted-counter guard and the candidate `e<k` guard keep even unreachable rows within the counter domain. All increments equal actual input/output disagreements. Both last raw coordinates are passed for every row and every random outcome. Thus the strict k cap and per-word endpoint budget zero hold exactly, with no posterior or average interpretation of the certificate.

The kernel uses only M, k, time, the current input and the counter. Its rational epsilon is common to both sources. Defining a source alternative using this public epsilon does not make the attack source-dependent: the same disclosed kernel is used in the two statistical experiments.

## 2. Selected branches and exact-cap comparison

Under the plus source, select the event `X_1=1`; under the minus source, select `X_1=0`. Both display the same initial zero. The remaining raw coordinates are independent of these events because the sources are iid. The selected branch weights are respectively 1/3 and at least 2/3.

In the uncapped comparison only, thinning a plus-source candidate one with probability epsilon gives an exact iid Bernoulli `p_minus` output. This is the entire candidate-vector law of the selected inactive minus branch, not just equality of their means. The two protected final bits retain their respective source probabilities and must still be included in the observation overlap.

With preassigned raw inputs and proposal coins, the actual active channel takes the first h erasure proposals. It agrees with the uncapped output whenever `D<=h`. The expected proposal count is at most `h/48`, so

`TV(A_plus,A_plus_uncapped) <= P(D>h) <= 1/48`.

The bound is valid also at h=1; no asymptotic tail estimate or product-law assertion about the capped output is needed. Coupling the two protected terminal bits gives a further distance at most `2Delta<=1/24`. The total selected-branch distance is therefore at most 1/16, with overlap at least 15/16.

The full output distributions dominate the selected subdistributions pointwise. Taking the smaller branch weight gives full overlap at least `(1/3)(15/16)=5/16`. This argument permits unequal, source-dependent mixture weights. No common mode prior or global closeness of the full source laws is assumed.

## 3. Posterior target and exact risk constant

Under each fixed iid source, the clean next bit is independent of the entire raw history and the source-independent channel coins. Its posterior probability given the displayed history is exactly that source's p. The cap may correlate displayed coordinates, but cannot change this target identity.

The two-risk triangle inequality therefore yields

`max Risk >= (Delta/2)(5/16) = 5h/(1536M)`.

For k>=2, `h=k-1>=k/2`, giving `5k/(3072M)`. The inequality also holds for randomized predictors after conditioning on and averaging their randomization. The predictor may know the common channel and even the two candidate source parameters; it still does not know which source generated the data.

## 4. The k=1 calculation

For the identity-channel pair in Section 7, `d=1/(16sqrt(N))` and `p_0(1-p_0)=2/9`. Therefore the N-word KL is at most `9/512` and Pinsker gives TV at most `3/32`. The two-risk inequality gives exactly

`29/(1024sqrt(N))`.

The inequality `N=M+2<=3M^2` is valid for every integer M>=1, and the resulting constant exceeds `5/(3072M)`. Both iid alternatives remain inside the floor-1/4 class, even at the smallest N, and satisfy beta=1. The identity channel is rational, has one base state, and uses zero edits. No rationality assumption on the source parameters is required by the channel interface.

## 5. Exact existing materials used for composition

I also read the current uniform-rho floor upper, its independent audit and exact-byte attestation, and rechecked the current bytes of the previously independently reviewed endpoint lower. The relevant present hashes are:

- `KNOWN_CHANNEL_one_state_counter_lower.candidate.v2.md`: `81ec5725846233595bfdb803ab92640dc20d419488b68ece2460e99d43a546ce`.
- `KNOWN_CHANNEL_one_state_counter_lower.independent_review.v1.md`: `aea209b923c3c8cb0f0f60c783eaf1c20a5851597a52dfa1bc25fac22276cd2e`.
- `KNOWN_CHANNEL_positive_floor_rho_upper.candidate.v1.md`: `4f472df0857c73d4a09dfb380136a3f4f3558c994ba75ea5c3cb6579bcf5f13f`.
- `KNOWN_CHANNEL_positive_floor_rho_upper.independent_audit.v1.md`: `fdce59e69f7d84d755fc3224c60243d522cf2110c508258e06bba945b83b2e82`.
- `KNOWN_CHANNEL_positive_floor_rho_upper.present_time_attestation.v1.md`: `40ba9749c9f7bdcd80554ecd8becb1000a37cf36ce170514c6f4c3916a72c337`.

The new upper supplies `C_eta[M^(-1/2)+k/M+rho min{1,k/sqrt(M)}]`, capped at one, under stationary binary sources with a fixed positive floor and the per-clean-word endpoint certificate. Its pathwise envelope and localized posterior comparison apply to the same target as these lower witnesses. It applies to all disclosed future-blind strict-k channels, so in particular to the rational one-base-state online subclass. No additional computational or neural interpretation is needed for the comparison.

## 6. Valid full fixed-floor rate and exact quantifiers

For each fixed public floor `0<eta<=1/4`, the clean iid lower, the present protected lower, and the previously reviewed one-state endpoint lower all lie inside the fixed-floor source class and the one-base-state online channel allowance. They respectively give, up to positive fixed constants,

`M^(-1/2)`, `k/M`, and `rho min{1,k/sqrt(M)}`.

Taking the maximum of three separate witnesses bounds one third of their sum. Their edit budgets are not added. Since these terms are bounded, this gives the capped lower matching the uniform-rho floor upper:

`Theta_eta(min{1, M^(-1/2)+k/M+rho min{1,k/sqrt(M)}})`.

This statement is valid for sufficiently large M, integer `0<=k<=M`, and rational `0<=rho<=1` in the rational-channel formulation. At k=0 only the clean witness is needed. If an arbitrary real rho is treated as a budget while rational channel rows are required, a rational dyadic value in `[rho/2,rho]` for rho>0 gives the same lower order, provided its finite description is allowed and paid. The rho=0 witness is already exact. This extension does not bypass a separate imposed channel-description cap.

The same matched rate holds after intersecting the source class with a fixed `D2(beta)` condition for **`0<beta<1`**, with constants permitted to depend on beta and eta. The endpoint witness uses `gamma=(1-beta)/64>0`, and the clean/protected iid sources satisfy this condition as well. Without a specified D2 restriction, one can fix any one positive gamma from that construction to obtain the floor-class lower.

The result holds already at one base state. Any larger channel class containing these witnesses and covered by the same general upper has the same statistical rate. This includes the permitted larger-base-state online classes. It is not a claim about a fixed number of total augmented configurations or an independently imposed description bound that excludes the displayed tables.

## 7. Boundaries that must remain explicit

- **beta=1:** The protected lower remains valid, but the endpoint-amplification lower does not. Under the all-state D2(1) condition, the common-component identity forces every source row to equal the stationary symbol law, so the source is iid. The full formula with a nonzero endpoint-amplification term must not be advertised as matched for that intersection. For the present floor range, the clean and protected witnesses instead match `min{1,M^(-1/2)+k/M}`, independently of rho: the empirical displayed bit mean differs from the raw iid mean by at most `k/N`, and the latter estimates p with expected error at most `1/(2sqrt(N))`. Its target is the constant p.
- **eta=0:** The protected witness remains admissible, but the positive-floor upper does not apply. The new composition does not resolve the general no-fixed-floor, sub-square-root-budget S=1 question.
- **eta>1/4:** The current source witnesses do not establish the full rate throughout that range. A modified construction would require its own parameter and constant checks.
- **eta=1/2:** The binary source law is the fully specified iid fair law under stationary initialization; the target is exactly 1/2 and the minimax risk is zero. No positive lower can extend to this degenerate boundary.
- Constants are not asserted uniform as beta approaches one or eta approaches zero. The source class is at-most-second-order and therefore includes the first-order and iid subfamilies used by the witnesses.

## Method and scope

Pure analytical review, private file inspection, exact hashing and this separate review artifact only. No scientific executable checks, numerical experiments, model runs, public writes, external novelty investigation, training result, efficient posterior algorithm, finite-precision certificate or architectural realization is asserted. The earlier general-D2 lower/upper gap and the new fixed-floor matching theorem concern different source classes.
