# Constant width by paid base-four stack storage

5 November 2026 UTC. Analytical addendum to `KNOWN_CHANNEL_finite_state_transformer_bridge.candidate.v1.md`. No scientific executable checks, numerical experiments, public writes or optimality claims. This addendum is a new construction requiring independent review.

## Result

The growing-width circuit bank in the companion note can be replaced by two bounded base-four stack registers. For the same expanded rational finite-state channel description, fitted source, Boolean-circuit bound G, raw-token input and error 2^-r, there is an untied bounded-score causal Transformer with

    d = 64,
    L = O(N log(N+1)+G^2),
    w = O(G+r+log(N+1))

where w bounds exact rational scalar numerator/denominator lengths. All per-matrix, bias and reached per-position hidden-state norms have absolute bounds. All eligible attention scores remain exactly zero. The output is the same dyadic approximate posterior (q_r,1-q_r).

Thus constant width is available by paying greater depth and scalar bit precision. The construction is an existence upper bound, not a depth lower bound, speed recommendation, trained model, tied-weight result or IEEE stability claim. It uses the same no-normalization, simplex-coordinate-output architecture and public normalized positional scalar as the companion note.

## 1. Exact bounded stack primitives

A finite Boolean stack of known public length m is encoded as

    S = sum_(j=1)^m b_j 4^-j,  b_j in {0,1},

with b_1 at the top. Thus 0<=S<=1/3. Leading or trailing zero digits are permitted; the length is known to the unrolled public schedule and is not inferred from the real number.

Push bit b by

    Push(b,S) = (b+S)/4.

For pop, form y=4S. The following fixed ReLU function extracts the leading bit:

    Digit(y) = ReLU(3y/2-1/2)-ReLU(3y/2-3/2).

If the leading bit is zero, y belongs to [0,1/3], so Digit(y)=0. If it is one, y belongs to [1,4/3], so Digit(y)=1. In both cases the remainder

    Rest(S) = 4S-Digit(4S)

is exactly the stack of remaining digits and lies in [0,1/3]. Empty stacks are zero; the schedule never needs an unknown-length test or a data-dependent loop. These formulas use only affine maps and ReLUs with coefficients bounded by 4, on a constant number of coordinates. Every notation Digit(4S) is implemented by first storing y=4S, then applying Digit to y; it is not compiled as an unstaged coefficient-6 expression.

## 2. Read a known wire and restore memory

Let stack A contain all currently computed circuit wires in reverse creation order, newest first. Let B initially be empty. Suppose there are m wires, numbered oldest to newest, and wire a is requested.

1. Repeat exactly m-a times: pop A into a temporary bit and push that bit onto B.
2. Read Digit(4A) into a dedicated retained bit register without modifying A.
3. Repeat exactly m-a times: pop B into a temporary bit and push it onto A.

Afterward A is exactly its original stack and B is empty. The retained bit is the requested wire value. The temporary registers used by restoration are distinct from this retained bit register.

The number of moves and all addresses are public properties of the compiled Boolean circuit, so these loops are explicitly unrolled into layers. There is no free random-access operation or controller. Reading one wire takes O(G) bounded affine/ReLU primitives because m<=G.

## 3. Evaluate the complete circuit in constant width

Use the companion note's positional-equality/uniform-mean/clipped-doubling intake. After each displayed bit is recovered, push it directly onto A rather than writing a growing wire bank. The recovered value is an exact Boolean bit at every row: future positions are zero, and all available positions hold their displayed bit. Thus each row stores its own prefix-padded complete N-bit word. Then push the circuit's charged constant bits in a public order.

For each gate, use Section 2 to read its first input into u and its second input into v, preserving u during the second read. Compute AND by ReLU(u+v-1), or NOT by 1-u. Push the resulting new wire onto A. Maintain B=0 between reads. At most G gates each need O(G) stack primitives, giving O(G^2) layers.

The Boolean circuit from the companion note already includes the positive dummy denominator on the zero-evidence branch, exact integer division and final fallback selection. It outputs the r fractional bits and possible integer bit of q_r. Read those known output wires with the same restored-stack operation. To obtain the scalar probability, process fractional bits from least significant to most significant via a<-(a+b)/2, beginning with a=0, then add the integer bit. Because the represented result belongs to [0,1], the final accumulator never exceeds one. This costs O(rG)<=O(G^2).

No gate result or constant is encoded into an arbitrary real weight. The channel's discrete bits appear in the finite layer program, whose size is charged. The only packed data are finite base-four digits in reached activations, and their bit cost is explicit below.

## 4. Common architecture and uniform bounds

A concrete conservative choice is d_0=64 and FFN hidden width 128. Reserve coordinates 1-2 for the binary raw one-hot, 3 for position, 4-5 for stacks A/B, 6-7 for retained operands u/v, 8 for the current gate bit, 9 for a temporary popped bit, 10 for the positional difference, 11 for its absolute value/clipped amplification, 12 for the equality marker, 13 for the marked raw value, 14 for attention mean/recovered bit, 15 for four times a stack, 16-17 for digit-extractor scratch, 18 for the retained extracted digit, 19 for the probability accumulator, and 20 for its complement. Coordinates 21-64 are zero spare scratch. Reuse only after clearing or an explicit overwrite. This is fewer than 64 persistent coordinates; the affine-overwrite canonical identity/ReLU construction uses the FFN's 128 hidden units, not an additional persistent wire bank.

Each operation touches only this fixed register set, independently of N,S,k,ell,r and G. Canonical residual blocks implement the stated bounded affine overwrites and coordinatewise ReLUs. Each scalar stack/read/gate primitive costs a fixed absolute number of such blocks.

Every stack lies in [0,1/3], every four-times-stack intermediate lies in [0,4/3], every extracted/circuit bit is 0 or 1, each positional/intake register has a constant bound, and the output accumulator is in [0,1]. Every row obeys the same invariant, including the nonterminal prefix-padded rows. Hence the per-position Euclidean state norm is uniformly bounded. Fixed dimension plus bounded coefficients and biases give uniformly bounded matrix and bias norms.

Pointwise blocks have zero V/O attention. Intake blocks have Q=K=0 and inject the ordinary self-inclusive causal mean of exactly one marked raw bit into cleared scratch. Stack coordinates are not attention values. There is one standard softmax head per block, causal mask s<=t, and no normalization layer. The final norm-one coordinate projection reads (q_r,1-q_r).

## 5. Scalar precision and complete ledger

At all times the two stacks jointly contain no more than G bits, and each stack's denominator divides 4^G. Push/pop/extract operations remain exact finite dyadic rational operations. Intake attention has denominator t<=T, positional gates have dyadic denominator P, and the probability output has denominator dividing 2^r. Their registers are kept separate except through the explicitly stated operations. Thus every reached scalar has numerator/denominator bit lengths

    w=O(G+r+log(N+1)).

This is polynomial but substantially larger than the growing-width alternative's O(r+log N+log G). It is an exact rational execution specification, not a generic finite-precision approximation guarantee. Small rounding errors in low-order packed digits are not covered.

All non-positional coefficients come from a fixed finite rational set, including 0,1,-1,2,4,1/4,3/2 and the digit-extractor biases. Positional centers i/P have O(log N) description bits. Thus dense untied parameter storage is

    O(L d_0^2 log(N+1)) = O((N log N+G^2) log(N+1))

bits, with a corresponding charged emission cost. Circuit generation and rational-channel denominator preprocessing are as in the companion note, and the O(G^2) stack schedule is generated explicitly. No exponentially large truth table is generated.

A conservative exact-rational dense all-block evaluator costs

    O(L (T d_0^2+T^2 d_0) w^3)

bit operations under the companion note's naive exact-rational arithmetic model, plus parameter/input access and initialization. Rolling activation space is O(T d_0 w) bits, with O(T^2 w) additional space if scalar attention weights are materialized. Fixed width does not make packed memory, runtime, parameters or precision free.

## 6. Interpretation

The posterior approximation and its stationary statistical-transfer limitations are identical to the companion note. This addendum changes only the circuit storage and depth/precision tradeoff. It closes the constant-width representability gap for this paid rational finite-state subclass under exact rational evaluation; it does not establish optimal depth, optimal bit precision, floating-point robustness, efficient inference for arbitrary disclosed channels, or a matching restricted-channel minimax lower bound.
