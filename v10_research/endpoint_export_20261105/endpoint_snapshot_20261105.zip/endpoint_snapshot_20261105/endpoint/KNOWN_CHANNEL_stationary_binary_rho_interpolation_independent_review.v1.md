# Independent review: sharp stationary binary endpoint-probability interpolation

Review time: 2026-11-05 05:32:47 UTC.

## Exact binding and disposition

Candidate: `KNOWN_CHANNEL_stationary_binary_rho_interpolation.v1.md`.

Candidate SHA-256:

`70b210c5ee6c9f410fe31a4d06aff2c82eef328d80165a5f257c2f8dee40e744`

Disposition: analytical PASS for (I1)–(I16) and the stated fixed-beta, uniform-in-rho interpolation. No substantive gap remains. The shared choice of tau and onset horizon for the one-edit and general-budget constructions was explicitly clarified before freezing. This review binds the current candidate bytes, not an earlier draft or later changes.

For fixed 0<beta<1, all sufficiently large M depending only on beta, all integer 0<=k<=M, and all rho in [0,1], the accepted rate is

    Theta_beta(min{1, M^(-1/2)+k/M
                       +min{rho,(k^2/M)^(1/3),1}}),

with the endpoint term zero at k=0. Equivalently k/M can be replaced by the candidate's F_beta, using beta-dependent constants. The target is the actual source-specific posterior future law, not a posterior mixture over source hypotheses and not a latent-terminal-row loss.

This review used mathematical analysis and local document reads, hashing, and document writing only. It does not assert scientific executable checks, simulations, public writes, an efficient predictor, an all-initial-law extension, a moving-beta theorem, external peer review, or novelty certification.

## 1. Upper transfer is legitimate and one-directional

Future blindness implies

    p_(theta,C)(Z)=E[theta_(S(X))(1) | Z].

For the already reviewed latent-target estimator q_lat, conditional Jensen gives

    E|q_lat(Z)-p_(theta,C)(Z)|
      <=E|q_lat(Z)-theta_(S(X))(1)|.

Thus the EPR001 latent-target UPPER transfers to the posterior target. A latent-target lower would not transfer this way; the candidate correctly does not claim otherwise.

The EPR001 interface is an unconditional risk theorem for every allowed adaptive channel. Its repaired-channel argument, rather than a conditional protected-risk assertion, is the relevant dependency. Selecting between this estimator and the log-free known-channel estimator uses only public beta, M, k, rho and fixed constants, not the channel seed or realized edit mode. For k>=1, (k+1)<=2k gives the capped log-free bound C_beta a. The inequality

    min{1,a,b+rho} <= min{1,b+min{rho,a}}

is valid for b=s+F_beta. The k=0 clean branch is separately valid.

The upper is a composition of the accepted log-free proof and the accepted EPR001 interface. This audit checks their use and target conversion; it does not claim to re-prove every predecessor of the protected-terminal theorem.

## 2. Exact rare-output mixture, including collisions

The candidate reuses the already audited rare-family channels without changing their action. The source-dependent stationary initialization remains inside f_q(H); it is not treated as common between hypotheses. The existing full-scaffold overlap, all-state D2(beta) certificate, source-independent channel, and pathwise edit budgets therefore remain applicable.

The retained scaffold and candidate eligibility are unchanged by normalization or by editing the penultimate bit. On the typical scaffold event D, the output count identifies the normalization/erasure branch. An input outside that branch cannot have the same output center and scaffold: off-bin counts are not the center, and an input outside D cannot acquire D through these edits. The one-edit erasure output count zero has the analogous property. There is no missing mixture from colliding nonbranch inputs.

Conditionally on the retained terminal scaffold, the hidden clean penultimate bit is exactly Bernoulli(t), independent of the candidate-count edit mode. The two possible future rows are t and r under BOTH source alternatives. The output branch mass is consequently exactly

    f_q(H) g_q(H) u_H(y) ell_q(w),

with one common normalized-configuration mass u_H. For one edit it is a point mass; for general budget it is uniform on the displayed fixed-count configurations. The existing lower bounds for g_q, for the hidden-mode separation |v_+-v_-|, and for restricted scaffold overlap are independent of rho.

These facts are specific to the reviewed construction. The proof does not assume that a generic adaptive edit mode is independent of the hidden endpoint.

## 3. The posterior gap and observation mass must remain together

For displayed penultimate bit w=1, write T_q=rho v_q. The exact likelihood and posterior weight are

    ell_q=t+(1-2t)T_q,
    F_q=t(1-T_q)/ell_q.

Direct subtraction gives

    |F_+-F_-|
      =t(1-t)rho|v_+-v_-|/(ell_+ ell_-).

Multiplication by the two-source observation overlap cancels precisely one likelihood factor:

    min(ell_+,ell_-)/(ell_+ ell_-)=1/max(ell_+,ell_-).

Since max ell<=t+rho, r-t>=r/2, and 1-t>=1/2, the weighted target gap is bounded below by a constant times

    rho t/(t+rho).

Summing the common configuration mass u_H gives one. Summing min(f_+,f_-) over D gives at least 3/4. Finally, the two-source absolute-loss inequality and division by two give exactly the conservative constant 3g_* r v_*/32 in (I11).

In particular, there is no assertion that w=1 has constant probability, and no rare-output probability has been discarded. When rho is much smaller than t, the conditional target gap grows like rho/t but its observation mass is of order t. Their product is of order rho. When rho is much larger than t, the product is of order t. This is why the earlier product lower rho*t was not the sharp interpolation.

## 4. Uniformity in rho, one edit, and the budget cap

The exact identity has no nuisance parameter-replacement error. The terminal prior t and the two future rows t,r are shared by the alternatives. No error term must be made smaller than rho, so the onset horizon need not depend on rho.

At rho=0 the target gap is exactly zero while ell_q=t>0. Arbitrarily small positive rho is covered by the same formulas and constants. No conditioning on a probability-zero endpoint event or division by rho is used.

For k=1, the previously audited mutually exclusive branches erase the sole candidate one or attempt the endpoint flip. They never perform both actions on one realization, so the strict one-edit budget survives unchanged. Its hidden-mode probabilities differ by a beta-dependent positive constant on D. The common choice of tau is now explicitly required to satisfy both the one-edit and general-budget predecessor proofs.

For k>=2, h=min{k-1,floor(sqrt(M))} obeys h>=min{k,sqrt(M)}/2. Thus t=tau(h^2/M)^(1/3) is comparable, with beta-dependent constants, to a=min{(k^2/M)^(1/3),1}. The one-edit t=tau M^(-1/3) has the same comparison. The inequality

    rho t/(rho+t) >= (1/2)min{rho,t}

therefore supplies c_beta min{rho,a} uniformly over all positive budgets. At k=0 this witness is not invoked.

## 5. The protected k/M lower is genuinely a known-channel lower

The separate iid construction is valid and avoids silently importing a source-dependent or undisclosed-channel corruption lower. An iid Bernoulli source has P^2(u,v)=Pi(v) on every pair state, so it lies in every D2(beta) class with beta<=1. Its source-specific posterior future target is the constant source parameter p, even after the disclosed future-blind channel.

For k<8sqrt(M), the clean lower already dominates k/M up to a fixed factor. In the other range and for M>=4096, h=min{k,floor(M/4)} satisfies h>=4sqrt(M) and h>=k/8. The two probabilities p_+ and p_- are inside [3/8,5/8]. The channel normalizes only the first M positions and preserves both terminal coordinates on every word. Its strict edit budget is at most h<=k and its endpoint-change probability is zero.

The displayed interior count c identifies the branch without collisions. Conditional uniformity of iid fixed-count configurations and permutation-invariant normalization give the same interior output law under both alternatives. The terminal bits are independent of the interior and remain iid Bernoulli(p_i).

The constants in (I13)–(I15) check out:

    g_i >= 1-4M/(9h^2) >= 35/36;
    each terminal-pair mass >=9/64;
    restricted output overlap >=(35/36)(9/16)>1/2;
    target gap =h/(2M).

Hence max risk>=h/(8M)>=k/(64M). The same common channel is disclosed to the estimator under both alternatives and is admissible for every rho.

For fixed beta, k/M<=F_beta<=[1+log(1+beta^(-1/2))]k/M. This supplies the stated F_beta lower with beta-dependent constants only. It does not establish the moving-beta logarithmic frontier with beta-uniform constants.

## 6. Assembly and limitations

The clean, protected-normalization, and rare-endpoint experiments separately lower-bound s, k/M (equivalently fixed-beta F_beta), and min{rho,a}. Taking their maximum and then using max>=sum/3 is legitimate. It does not combine edit budgets or claim that the three obstructions occur simultaneously under one source/channel pair.

The matching rate is uniform in rho and k once beta is fixed. For 1<=k<=sqrt(M), it is comparable to s+min{rho,(k^2/M)^(1/3)}. For k>=sqrt(M), it is comparable to min{1,s+k/M+rho}. At k=0 it reduces to the clean M^(-1/2) rate.

The example k=1, rho=M^(-1/3) correctly disproves the proposed product interpolation s+F_beta+rho*a: that expression would be order M^(-1/2), whereas the accepted lower is order M^(-1/3).

The theorem is stationary, fixed 0<beta<1, and statistical/information-theoretic. It does not extend the rare lower to beta=1, give beta-uniform constants, claim a polynomial-time predictor, or establish fixed-source pointwise inconsistency.

## Present-time dependency bindings

- Log-free upper v2: `a94a259168502b550b696d970b9a577689e82703365b02b0397d5c0a6f14232f`.
- EPR001 candidate: `b8f3ae8107482f54043503ad5cc4993d8cc24566882d47ebab6c2eb34705eebe`.
- EPR001 independent review: `51decc56338fc6ef9827fc15923a0aed5b294003d95d3ee26eede9af841ad7d0`.
- Previously audited rare one-edit candidate: `49915c863da95d1b139c467c686aee5cf65a5bd408ad9ec762ed8c7408ad88c9`.
- Previously audited rare-budget candidate: `9bfc30dcf44224b238ea315a7d306e4ff4e6ef7f6108e9fd97ed68dd3fb19689`.

These bindings identify the documents used in the accepted dependency assembly. They do not certify an earlier remote commit or historical publication date.
