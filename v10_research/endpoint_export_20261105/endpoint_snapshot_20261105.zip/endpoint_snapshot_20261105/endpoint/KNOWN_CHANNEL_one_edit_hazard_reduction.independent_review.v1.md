# Independent review of the strict-one-edit hazard reduction

Review time: 2026-11-05 12:31:31 UTC.

Disposition: **PASS for the stated identities, survival and Palm bounds, source-wise high-hazard risk bound, and count-covariance reduction.** The unrestricted-position no-floor S=1 root-M minimax upper remains open. This research note neither proves it nor supplies a counterexample.

## Exact binding and scope

The complete amended file was independently read:

- `KNOWN_CHANNEL_one_edit_hazard_reduction.research.v1.md`
- SHA-256: `e649e40991eb9eccf2917b1e028950dd4a6ced0bd441c13722d827dd9abf7d52`

This approval binds the current file, including the explicit repaired-channel and conditional-Jensen justification added after the initial reading. It does not infer historical hash integrity. The reviewer has not edited the source note.

The separate endpoint-weighted Palm addendum is not included in this review's approval. It is being checked separately, including its terminal single-symbol-window boundary case.

## 1. One state means no uncharged channel memory

The channel has one base state, initial actual edit counter zero, and public time-indexed Markov rows depending only on the current input and counter. Once an edit occurs, the exhausted-counter row is identity. Under that interface, its conditional first-edit hazard factorization (H1) is exact.

No additional persistent shared seed or hidden mode can be smuggled into this representation. Such memory would require a different state description. The note does not claim that one base state is one total configuration: the actual two-valued counter is charged separately. Public time dependence, rational parameter bit lengths, and any internalized clock are also separate costs.

For a fixed displayed z, the only raw preimages are z and its N single-bit flips. The coefficient c_j for an edit at j includes survival only before j and the off-diagonal probability at j; no post-edit survival product belongs there. The coefficients in (H2), including the no-edit coefficient, are therefore correct. Zero coefficients are permitted, and no ratio to c_0 or to P(z) is introduced.

All non-endpoint preimages share z's terminal pair. This is a statement about each preimage, not an assertion that the observed prefix is globally known to be clean. Endpoint-edited preimages and early-edited preimages can coexist in one posterior.

## 2. Endpoint cross-product identity

Let A_j=c_j P(x^(j)) and B_j=c_j Q(x^(j)). Direct subtraction gives

    P_Z(p_P^Q-p_Q)
       = (1/Q_Z) sum_(j,l) A_j B_l (g_j-g_l).

Antisymmetrizing this expression gives exactly the factor 1/(2Q_Z) and the sign in (H4). P_Z has already cancelled on the left, but Q_Z remains; it must not be replaced by an endpoint-only likelihood. Only pairs with at least one endpoint leaf have nonzero g_j-g_l.

The identity requires positive P_Z and Q_Z at the displayed output. The note correctly reserves singular outputs for a separate argument. It also correctly separates the direct source-row change via (H5). A data-dependent fitted Q_z cannot be inserted into an integrated fixed-alternative argument without additional justification; the note makes no such substitution.

## 3. Forward and reverse hazard survival

The unconditional parity proof of (H6) is valid. For each selected parity, sampled pair states are two transitions apart. All previously sampled survival factors are measurable in the preceding pair-chain filtration. The two-step minorization therefore bounds the conditional expected next survival factor by 1-beta lambda_i. The first selected factor is stationary and satisfies the same bound. The full product is bounded by either parity product, and the parity with at least half the deterministic hazard mass gives exp[-(beta/2)sum lambda_i]. No independence of the raw symbols is asserted.

For (H7), write a=i-r and condition on the block starting at a. The stationary reverse pair kernel has the displayed two-step minorization on positive stationary support. Conditioning on the remainder of the future block changes only the initial distribution at the boundary pair (X_a,X_(a+1)); it does not change the reverse transition kernel before that pair. If a coordinate of the boundary pair is unspecified, it is averaged over its conditional distribution.

The retained hazards have indices h<=a-2. In either parity class, the first reverse sampled pair is at least two steps back: the nearest possible distances are two and three. For every d>=2, the reverse d-step kernel still minorizes beta Pi, by stationarity and the two-step minorization. Subsequent samples are spaced by two. Thus the parity-product argument applies uniformly to the boundary distribution.

This gap is sufficient to avoid the possible overlapping-pair error highlighted in the audit request. The proof does not condition a transition on an extra revealed coordinate inside that transition. The omitted factors are at most the r+1 indices a-1,...,i-1. Empty retained intervals cause no problem. Positive-probability conditioning windows keep the reversed chain on stationary support, where the reversal formula is defined.

## 4. Palm bound at the actual first edit

For a local word w with center c,

    P(J=i,W_i=w)
       = P(W=w) a_i(c) E[product_(h<i)(1-a_h(X_h)) | W_i=w].

This uses the actual raw window and the actual first-edit event. Stationarity supplies the common window mass, while the reverse bound supplies survival without assuming that J and the raw path are independent.

With b=beta/2 and A_i=sum_(h<i)lambda_h, omitting at most r+1 terms costs exp[b(r+1)]. The pointwise inequality pi(c)a_i(c)<=lambda_i is correct. Since 0<=lambda_i<=1, the disjoint cumulative-hazard intervals satisfy

    integral_(A_i)^(A_i+lambda_i) exp(-bt) dt
       >= exp(-b) lambda_i exp(-b A_i).

Their union is contained in [0,infinity). Consequently sum_i lambda_i exp(-bA_i)<=exp(b)/b. This verifies the exact finite constant

    C_(beta,r)=exp[(beta/2)(r+2)]/(beta/2)

in (H8) and (H9). Its lack of dependence on s is legitimate: conditioning farther into the future does not alter the reverse kernel before the boundary pair. Restricting to valid window indices only decreases the sum. Zero-probability windows and zero-marginal central symbols contribute zero.

The bound is not a law for the displayed window or for a second posterior preimage at the first preimage's edit time.

## 5. Source-wise high-hazard risk and the fixed predictor

The terminal pair changes exactly when J is N-1 or N. Hence the event is contained in survival through N-2. Taking the minimum of the given endpoint certificate and (H6) proves (H10).

The amended proof of (H11) is valid with coefficient one on the actual endpoint probability. Use the protected selected-row estimator q_1 imported from Section 2 of `EPR001_endpoint_probability_interpolation.md`. For analysis only, repair the channel by returning the raw word on endpoint-changing paths. The repaired channel is source independent, preserves endpoints, and still uses at most one edit. It need not remain S=1, because the imported protected theorem covers arbitrary allowed protected channels.

On the original endpoint-preserving event, the repaired and original observations agree. Nonnegativity bounds that event's latent-row risk by the repaired channel's unconditional protected-risk guarantee. The complementary event costs at most one per realization. Conditional Jensen then transfers the latent-row upper to the actual posterior next-bit target.

For fixed beta, the imported corruption term at k=1 is O_beta(1/M), hence is absorbed by C_beta/sqrt(M). No clipped wrapper is needed. The inspected EPR001 file has SHA-256 `b8f3ae8107482f54043503ad5cc4993d8cc24566882d47ebab6c2eb34705eebe`.

If sum_(i<=N-2)lambda_i >= (log M)/beta, the survival term is at most M^(-1/2), with the stated exponent beta/2. This is a valid source/channel region because lambda_i depends on the true marginal pi. It is not a computable source-independent test for choosing an estimator. The actual q_1 is fixed and does not use the lambda_i, so no oracle source choice has been introduced. The pointwise regional conclusion does not imply a uniform minimax bound over the remaining low-hazard sources/channels.

## 6. Count-covariance and the all-minority coordinate

Two strict-one-edit posterior preimages of the same z differ in at most two bits. Each bit can affect at most three training triples, so the count of any fixed triple differs by at most six. This fact holds for any strict-one-edit channel, not only S=1.

For independent conditional posterior draws X,X', the covariance identity has factor one half. Therefore

    |Cov(g,T|Z)| <= 3 E[|g(X)-g(X')| | Z]
                  <= 6 E[g(X)|Z],

where g is the future minority probability. Stationarity gives E g=m. This verifies the coefficient 6 in (H12), without conditioning source stationarity on a channel-selected event.

The all-state D2 certificate gives theta_ab(c)>=beta pi(c) and Pi(a,b)>=beta pi(a)pi(b). Thus Pr(abc)>=beta^2 pi(a)pi(b)pi(c). Every binary triple other than 111 contains a majority symbol, and its marginal product is at least m^2/2 for 0<=m<=1/2. Combining this with (H12) gives exactly 6 sqrt(2)/beta in (H13).

For 111 the universal lower bound is only beta^2 m^3, so this route indeed leaves a factor of order m^(-1/2) after normalization by sqrt(Pr(111)). If its actual triple probability is instead at least a fixed multiple of m^2, the same crude estimate suffices. The degenerate m=0 case has zero covariance and is harmless.

These are individual count-covariance bounds, not a completed full-score estimate, finite-alternative comparison, or risk theorem for a fitted estimator. The initial stationary-pair score and direct future-row change remain separate, as the note states.

## 7. The unresolved crossed-preimage term is real

In the reviewed rare family, the stationary identities in (H14) give

    Pr(101)/Pr(111)=r(1-qt)/(q t^2).

These formulas check. In the previously certified small-t regime with fixed positive r and q bounded away from zero and infinity, the ratio is of order t^(-2). A time-indexed one-state hazard can flip a middle zero without storing its neighbors, so it can turn a raw 101 into a displayed 111. The resulting displayed-window probability cannot be bounded by the raw 111 Palm expression merely by renaming the window.

An endpoint-edited competing preimage has the displayed early bit, while an early-edited preimage has its flipped counterpart. A local score evaluated in the endpoint preimage at the other path's edit time is not evaluated at its own stopping time. The actual-edit Palm lemma therefore cannot be applied to that crossed quantity. The full observation likelihood and the competing posterior weights in (H4) are essential to any possible compensation.

The note correctly identifies this as an unresolved finite-difference step and does not infer a lower bound, a general root-M upper, a state separation, or an extension to arbitrary fitted Q_z.

## Preservation and activity

All checks were mathematical reading and reasoning. No scientific executable checks, simulations, numerical diagnostics, public writes, or external disclosure were performed. File inspection and SHA-256 commands were used only for document reading and integrity binding. No computational-efficiency, transformer, floating-point, training, or novelty claim is approved here.
