# Independent analytical review: uniform positive-floor known-channel upper

Date: 2026-11-05 UTC. Present-time clock check: 03:43:14 UTC; final candidate SHA-256 was checked immediately afterward.

## Finding and exact file binding

The general-alphabet upper is valid within its stated stationary, fixed-floor, known future-blind channel setting. I found no substantive proof gap or counterexample. The explicit quantitative interface (U3), its positive-floor specialization, the capped bound (U1), and the D2 stationary-mass corollaries all check.

Reviewed candidate:

    KNOWN_CHANNEL_uniform_positive_floor_upper.md
    SHA-256: 93379139b31483502d4b6d9efdda02b3f122f592c8cec7274e83d36696b09b5b

The complete draft was read, and the final public-floor and log-oscillation wording was rechecked. The author confirmed that the candidate was frozen. This is a present-time binding to the named current file, not a historical digest claim.

For fixed finite K and a supplied public successor-probability floor eta>0, the proved upper is

    Risk <= min{1,C_(K,eta)(k+1)/sqrt(M)}.

Thus k=o(sqrt(M)) is sufficient for uniform stationary posterior-prediction consistency. In particular, a constant one-edit floor is impossible uniformly over this fixed-K, fixed-eta class. No necessary budget threshold, matching lower, sharp k-dependence, or optimal minimax result is established.

This was a mathematical review only. Tools were used for document inspection, file hashing, and writing this review. No scientific executable checks, numerical experiments, public writes, or external novelty investigation were performed. This is not formal verification or external peer review.

## 1. Pair-chain floors and contraction

The source is genuinely homogeneous order two. The one-step pair transition matrix has structural zeros: from (a,b), only states of the form (b,c) are reachable in one step. No one-step full matrix positivity is needed or claimed.

In two steps, there is exactly one intermediate pair for a specified target (c,d), and

    P^2((a,b),(c,d))=theta_ab(c)theta_bc(d)>=eta^2.

This holds for all starting and target pairs. Since K eta<=1, the quantity gamma=K^2 eta^2 lies in (0,1]. The two-step kernel has a common uniform-pair component of mass gamma, so its Dobrushin coefficient is at most 1-gamma. Stationarity then gives Pi(c,d)>=eta^2 by averaging the same two-step bound over the starting law.

Consequently eta alone supplies omega=eta^2 and gamma=K^2 eta^2. No extra unstated mixing hypothesis is required for the main theorem.

For the more general interface, the stated Dobrushin contraction is enough. It need not be represented by a specified Doeblin minorizing measure. With stationarity it implies TV(P^h(s,.),Pi)<=(1-gamma)^floor(h/2).

## 2. Stationary row moments and exact constants

There are M historical context pairs, ending at times 2,...,N-1. For a fixed row u,

    E J_u=M Pi(u),
    Cov(1{S_t=u},1{S_(t+h)=u})
      =Pi(u)[P^h(u,u)-Pi(u)].

The covariance series therefore gives Var(J_u)<=5M Pi(u)/gamma. Chebyshev at half the mean gives 20/(gamma M Pi(u)), as in (U7).

The successor-count error vector is a predictable-row martingale sum. Its increments have total conditional second moment at most the row indicator, so

    E||Z_u||_2^2<=M Pi(u),
    E||Z_u||_1<=sqrt(K M Pi(u)).

For add-one smoothing, the bias vector is 1-K theta_u, whose L1 norm is at most 2K. Thus the displayed TV inequality is valid. On J_u>=M Pi(u)/2, its expected restricted contribution is at most sqrt(K)/sqrt(M Pi(u))+2K/(M Pi(u)). This uses the unconditional martingale moment; it does not condition the source theorem or martingale identities on the occupation event.

The deterministic shared-count bound adds at most 3k/(J_u+K), hence at most 6k/(M Pi(u)) there. On the complement, the entire observed-row error is at most one, so the bad-count probability is charged once. This proves (U9).

Each L1 projection onto the eta/2-floor simplex increases error against a feasible true row by at most a factor two. Summing the K^2 row bounds gives exactly the candidate's B_row. Independence of different row estimates is not required.

## 3. Initial law fitting

The observed normalized context histogram J'_u/M is a probability vector. Each raw token change affects at most two counted context pairs, yielding the TV perturbation 2k/M. The variance bound and sum_u sqrt(Pi(u))<=K give

    E TV(Pi_raw,Pi)
      <=(K/2)sqrt(5/(gamma M))+2k/M.

The omega/2-floor simplex is nonempty, since K^2 omega<=1. The true Pi is feasible, and the L1 projection inequality gives the exact displayed B_init after multiplication by two. Deterministic tie-breaking provides an unambiguous estimator.

The fitted initial law need not be stationary for the fitted transition table. Their product formula nevertheless defines a normalized positive law on clean words. This is an admissible surrogate used by an estimator, not an assertion that the surrogate belongs to the true source class. The actual generating law remains stationary throughout the proof.

## 4. Uniform posterior stability for arbitrary disclosed channels

The positive fitted floors provide global bounds, without any small-error event:

    |log(Pi_hat(s)/Pi(s))|<=2Delta/omega,
    |log(theta_hat_u(c)/theta_u(c))|<=2epsilon/eta.

Here Delta and epsilon are TV errors, and an individual coordinate difference is bounded by TV, so there is no missing factor from the K-dimensional probability vectors.

Any two clean preimages of a displayed word are within 2k Hamming changes, and at most 6k historical triples differ. Identical triple log-ratio factors cancel. The initial pair contributes at most 4Delta/omega, and the changed triples contribute at most 24k epsilon/eta. This gives (U12).

The same kernel C is used in both posterior calculations, so it cancels from the likelihood ratio. No lower bound on the probability of the observed output, locality of C, independent edit mechanism, or sample-obliviousness is required. The strict Hamming support condition suffices. The positive true and fitted clean-word laws ensure a positive fitted denominator for every possible true observation.

Normalizing likelihood ratios with logarithmic oscillation at most L bounds the posterior TV distance by 1-exp(-L)<=L. Replacing the transition rows in the posterior mixture adds at most epsilon, also for K-dimensional TV. Thus the pointwise bound and its integrated version (U3) follow.

Data dependence of both fitted laws is harmless: the posterior comparison is made after fixing z. Future blindness remains essential to identify the true next-symbol target with the posterior average of the original terminal row. Neither an edit mask nor a realized channel seed is supplied.

## 5. Large k, capping, and fixed-parameter interpretation

With omega=eta^2 and gamma=K^2 eta^2, the supplied B_row and B_init formulas are correct. Expanding (U3) gives

    C_(K,eta)[(k+1)/sqrt(M)+k(k+1)/M].

Terms proportional to 1/M when k=0 are absorbed by 1/sqrt(M). The remaining terms of order k/M and k^2/M are covered by k(k+1)/M.

Set g=(k+1)/sqrt(M). For g<=1 the untruncated bound is at most a constant times g+g^2<=2g. For g>1 the unit cap gives the conclusion after choosing the constant at least one. This validates the stronger capped display (U1) for every allowed k, not just k<=sqrt(M).

The global floor-based logarithm bounds also remain valid when parameter estimation is poor, so no hidden small-k event is used. For large k the upper is simply vacuous after capping; it is not evidence of a matching obstruction.

K and eta must stay fixed for the stated asymptotic implication. The explicit formulas may be examined when they vary, but the C_(K,eta) notation cannot be treated as uniform in growing alphabets or vanishing floors.

## 6. D2 mass-floor corollaries and lower-bound comparison

Under P^2(s,t)>=beta Pi(t) with beta>0, gamma=beta and theta_u(c)>=beta pi(c). If pi(c)>=nu, stationarity gives Pi(a,b)>=beta nu^2. Thus eta=beta nu, omega=beta nu^2, gamma=beta is valid.

If Pi(u)>=omega for every pair, summing K entries gives pi(c)>=K omega, so eta=beta K omega and gamma=beta are valid with the original omega. A positive stationary mass floor without the stated D2/common-component condition does not automatically give the transition floor used by this proof; the candidate correctly avoids that extension.

I inspected the cited ternary rare-clone definitions for the comparison in section 7, rather than certifying that separate lower anew. They have T_p(x,*)=p Q(c(x),0) and pi_p(*)=p/2. In the positive variant p is of order 1/M, so both transition and stationary symbol floors vanish. The stationary mass of the pair (*,*) is p^2 Q(0,0)/2 and also vanishes. Accordingly all three fixed-floor alternatives exclude that sequence.

The upper proves more than exclusion of one witness: for each fixed K and fixed positive eta, every admissible known one-edit channel has uniformly vanishing stationary prediction risk. This does not contradict rare probabilities tending to zero, arbitrary initial-law uncertainty, an unknown channel, or the unrestricted D2 class.

## Review scope and inspected sources

The complete candidate was checked against the earlier stationary binary v2 proof, `EDIT_OVERLAP_and_TARGET_BOUNDARIES.md`, `EPR001_endpoint_probability_interpolation.md`, and the posterior target conventions. The ternary note was inspected for its probability-floor comparison, not independently recertified in full here.

The result is information-theoretic: the posterior may require summing over K^N words and uses the disclosed kernel values. No efficient or finite-rational implementation, neural realization, sharp minimax claim, or external novelty conclusion follows from this review.
