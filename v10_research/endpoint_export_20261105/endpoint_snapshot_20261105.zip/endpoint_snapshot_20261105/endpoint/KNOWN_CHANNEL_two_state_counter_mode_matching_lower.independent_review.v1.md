# Independent analytical review: genuinely paid two-state counter mode

Review time: 2026-11-05 08:47:55 UTC.

## Exact material and decision

**PASS within the disclosed rational time-indexed channel interface, with the actual edit counter charged separately.** I independently reconstructed the prefix likelihoods, counter invariant, fixed-start tail argument, common-prior constants and posterior-risk calculation, and fully read the frozen candidate:

- `KNOWN_CHANNEL_two_state_counter_mode_matching_lower.candidate.v1.md`
- SHA-256: `104b2193954650b160dd41dacd08107276098d5f109bd6b35bcc9157a4525094`.

This is a different channel from the previously reviewed fair hidden-mode channel. It is not an exact three-to-two-state pathwise compression. Its new statistical justification is necessary and is supplied by the observable prefix calculation.

The relevant unchanged predecessor files, previously independently reviewed, are:

- `KNOWN_CHANNEL_online_thinning_mode_matching_lower.candidate.v1.md`: `bd616d8ae614fbd99a312a18cd6927fbaee7d05945389342d9d953904bf8c874`.
- `KNOWN_CHANNEL_three_state_matching_lower.addendum.v1.md`: `6d7869f24ad38c5861a732f5fdbe33c391d09759946ac926499dc67198cfd82c`.
- `KNOWN_CHANNEL_online_one_edit_lower.candidate.v1.md`: `411908bdfb5385066e19daaa84edcc302fc0a80bf76eb23d258a3f7187fa6e60`.

The hashes bind present inspected bytes, without inference about earlier historical hashes. This review preserves the original artifacts.

## 1. The two states and the strictly paid mode

During the first L positions the channel erases precisely the first raw one, if present. The edit counter is consequently either zero or one at the tail entrance. Its value is not assigned arbitrarily. Thereafter a zero counter cannot activate: both interior and endpoint gates explicitly require `e>=1`. Once active, the counter stays positive because it only increments for actual disagreements.

Two base states therefore suffice for the raw-pair gate accumulator. Candidate windows are disjoint triples starting after the two protected anchors. The final candidate is at most `N-5`, so the endpoint reset/read/action triple `(N-3,N-2,N-1)` has no overlap with a candidate triple. The first predecessor overwrites the accumulator, the second takes the AND with the required raw bit, and the candidate discards it after use. A separate reset at `N-3` accumulates two raw zeros for the endpoint. No future input is queried.

The active tail starts at `e=1`. The guard `e<h+1` permits at most h additional candidate erasures, and the endpoint adds at most one. Thus `1+h+1<=k` on every input and coin path. The endpoint guard has a reserved edit on all reachable active paths, including when the interior cap is attained. Inactive paths remain inactive. Every increment equals exactly the changed-coordinate indicator; there is no spare counter bit, overwritten counter value or uncharged latent state.

The row guards prevent overflow even on unused rows. Normalization is explicit: each eligible erasure/flip has its stated probability and complementary identity probability, and all other transitions are deterministic. The only nonintegral row probabilities are the rational thinning probability and rho. Every fixed clean word has endpoint-change probability at most rho, and the final raw symbol is untouched and unavailable when the endpoint acts.

## 2. Exact prefix branch, including its initial stationary law

The observed prefix `0^(L+2)` has exactly the claimed raw preimages: no one in the first L bits, or one one there, followed by two raw zero anchors. Two or more prefix ones cannot produce this output because only the first is erased.

I independently multiplied the stationary initial-pair probability and all transition factors. The all-zero raw word has mass `u_q(1-t)^L`. A one at position 1 or 2 has mass `u_q t(1-t)^(L-1)`. A one at any position from 3 through L has mass `u_q t(1-r)(1-t)^(L-2)`, including a one at L because the two protected anchors complete its following factors. Thus the exact active-to-inactive ratio is

`R = 2t/(1-t) + (L-2)t(1-r)/(1-t)^2`.

In particular the stationary initial law has not been silently treated as uniform or q-independent. Its q dependence is the common factor `u_q`, which cancels from this ratio. There is no context 11 among these raw words. The two boundary cases at positions 1 and 2 are explicitly included, rather than incorrectly assigning them the interior word weight.

With `Lt=1`, the claimed bounds `1/2<=R<=2`, `omega=R/(1+R) in [1/3,2/3]`, and branch probability at least `1/32` are conservative and valid. Both modes end at the identical raw pair 00. By the order-two Markov property, conditional on the observed prefix the subsequent raw tail is independent of the mode, starts at that fixed pair, and has the same mode prior omega under both source alternatives.

This independence is conditional on the stated observable branch. The mode is not asserted to be globally source-independent. The actual channel uses no initial hidden random bit; its subsequent coins remain source-independent. Revealing the common design scale through the integer L is permitted: the lower compares the same disclosed channel under two still-unknown q alternatives, even if the predictor knows their common design parameters.

## 3. Fixed-start tail and uniformity

The conditioned tail is not stationary. The replacement Section 5 correctly uses exact domination rather than assuming stationarity: the raw tail started at 00 is the stationary future conditioned on its initial pair being 00. Therefore any nonnegative functional or bad event is bounded by its stationary value divided by `u_q>=1/2`.

This statement does not require a count to be independent of the starting pair. Applying it to the stationary rare-window count's bad event proves the needed concentration under the fixed start. It does not claim an unwarranted equality of stationary and fixed-start means or variances.

The removed prefix length satisfies `L/M<=2/(tau M^(2/3))` uniformly over h>=1. The candidate density thus remains asymptotically 1/3 uniformly. Together with the stationary exact pattern probability and `Mt^2 >= (tau^2/4)M^(1/3)`, this places the stationary count mean a fixed distance inside the stated interval and makes its bad probability tend uniformly to zero.

The same domination bounds each terminal minority probability by `4t`, candidate-111 expectations by a constant times `Mt^3`, and expected visits to context 11 by a constant times `Mt^2`. The fixed-start alternatives have the same initial pair. Only the 11 transition row changes, so their tail KL is at most `C_beta d^2 Mt^3/h^2 <= C_beta d^2 tau^3`, with no unaccounted initial-law term. Choosing tau small gives the stated total-variation and good-scaffold overlap bounds. The later cap threshold is a finite beta-dependent constant; the horizon can then be increased to cover it and all uniform count conditions.

The underlying complete sources remain stationary members of the reviewed all-state `D2(beta)` class. Conditioning a branch in the proof does not replace them by nonstationary alternatives in the theorem.

## 4. Conditional factorization and non-fair prior

All eligible missing sites are separated by at least three positions and lie away from the fixed initial pair and missing penultimate bit. The predecessor and successor coordinates used in their local odds remain retained. Consequently the four previously reviewed conditional odds and conditional independence identities hold under the fixed start. The scaffold is reconstructible from the displayed tail and does not reveal the activation mode.

Since the raw tail is independent of mode conditional on the observed prefix, conditioning on this scaffold leaves the common prior omega unchanged. The uncapped mode likelihood ratio is therefore exactly the original product ratio, with posterior `omega Lambda/(1-omega+omega Lambda)`.

The draft correctly changes the constants that depended on a fair prior. Specifically:

- The likelihood-ratio bad set has mixture probability at most `4 TV<=1/4`.
- The common overlap on its intersection with the many-zero event is at least 1/2, using the displayed source-overlap and Markov bounds.
- Posterior odds lie between 1/4 and 8 on this set. The logistic derivative is at least 1/16 there; the earlier fair-prior 1/10 bound need not hold at the new upper extreme.
- The likelihood-ratio log gap remains `Delta=d tau^3/128`, because its local product calculation and `Mt^3/h^2` bound do not depend on the prior. Hence `J_*=Delta/32` is valid.

The same omega must be used under both sources for the common-kernel mixture comparison. The exact prefix cancellation supplies precisely that requirement.

## 5. Chronological cap and posterior-functional transfer

In the active mode, ideal proposed erasures are independent conditional on the scaffold, with mean at most `h/128`. Couple the capped and uncapped channels with the same raw bits and potential thinning coins. They can disagree only if more than h proposed erasures occur. This yields the stated `a_h=(e/128)^h` total-variation bound. The capped law is not treated as the ideal law conditioned on a binomial event.

For a mode-one perturbation of total variation a, the weighted prior gives `||m'-m||_1<=2 omega a` and `sum m'|v'-v|<=4 omega a`. Changing both source experiments therefore loses at most `6 omega(a_++a_-)<=8a_h` from J. The candidate uses this correct non-fair-prior bound, not the previous fair-prior `6a_h` constant.

Selecting a finite H_beta makes this loss at most `J_*/2`. The perturbation is applied to the integrated mode-posterior functional before introducing the small endpoint probability factor. No absolute total-variation error is subtracted directly from a risk of order t or rho. Pointwise ordering of the capped mode posteriors is not needed.

## 6. Actual endpoint posterior and observation mass

On the good scaffold, the missing penultimate raw bit is exactly `Ber(t)`, independent of the candidate bits, activation mode and thinning coins. The reserved endpoint edit is available on every active path, so its effective flip probability is precisely `rho v_q^cap` after conditioning on the displayed candidate vector.

The draft's endpoint observation probability and source-specific future posterior follow by the same two-term Bernoulli calculation as in the previous proof. They are posteriors under each actual source and actual capped channel, not a prior mixture over the two source parameters.

The full displayed-word mass contains the prefix factor `b_q`, the scaffold factor, the capped candidate mixture and the endpoint factor. Section 8 retains all four. Multiplying the exact target gap by the minimum observation mass and then applying the two-risk inequality gives the displayed bound with `min b_q>=1/32`. In particular the visible rare endpoint branch is not treated as having constant probability, and the estimate remains uniform as rho tends to zero.

## 7. Scaling, small budgets and scope

For k>=3, `h=min(k-2,floor(sqrt M)) >= min(k,sqrt M)/3`. The chosen reciprocal power-of-two scale therefore yields the full endpoint lower `c_beta min{rho,(k^2/M)^(1/3)}` when h exceeds the fixed cap threshold. Since rho<=1, saturation at h of order sqrt M causes no loss in the stated rate.

After the horizon is enlarged so that `floor(sqrt M)>=H_beta`, smaller h means bounded k. The already reviewed two-base-state implementation of the one-edit channel supplies the required rate there after a fixed beta-dependent constant loss. This covers k=1 and k=2 without evaluating a zero-h thinning probability. The clean and protected-budget witnesses each use one base state. Combining separate witnesses by their maximum establishes the matching fixed-beta profile for an allowance `S>=2`; their edit budgets are not summed.

The result uses **two base states plus the actual k+1-valued counter**, hence at most `2(k+1)` augmented base/counter configurations, and a horizon-dependent expanded time-indexed table. The paid integer L is at most N; the common scale selection, table generation and rational probabilities are not supplied by an uncharged oracle. The stated conservative table ledger retains all these resources. This does not establish two total states, a fixed homogeneous transducer, or minimality of two base states. The S=1 statistical boundary remains unproved here.

## Method and exclusions

Pure analytical reconstruction, file inspection and cryptographic hashing only. No executable scientific checks, numerical experiments, simulations, model execution or public writes. No new training, novelty, floating-point stability or mandatory-PreLN claim is made. Original candidates and earlier reviews remain unchanged.
