# A one-state online protected-budget lower

5 November 2026 UTC. Pure analytical candidate pending independent review. No scientific executable checks or public writes.

For N=M+2, integer 1<=k<=M and every rho>=0, the disclosed normalized rational online-channel subclass has minimax posterior-prediction risk at least

    27 k/(1024 M).                                  (P1)

This witness protects both endpoint coordinates and needs only ONE channel base state, excluding the charged edit counter.

## Source alternatives

Take stationary iid Bernoulli sources

    p_-=k/(8M), p_+=k/(4M).

Viewed as homogeneous order-two sources, these satisfy P^2(s,v)=Pi_p(v) at every pair s,v and therefore satisfy D2(beta) for every 0<beta<=1. Since the next symbol is independent of the entire past and independent channel randomness, its source-specific posterior target is exactly p on every supported displayed word.

## Common known online channel

On the first M positions, output zero for a current input one whenever the edit counter is below k; otherwise output the input. Thus the channel erases the first k ones online. Leave positions M+1 and M+2 unchanged.

This is a common source-independent deterministic channel. It uses only the current input, time, and counter, has a normalized 0/1 transition table, and uses at most k edits on every input. Both terminal positions are always protected, so its per-word endpoint-change probability is zero. There is no lookahead, terminal filtering, or unobserved output delay. The one base state can remain unchanged throughout. The fully expanded time-indexed counter-dependent description is finite and paid, conservatively O(N(k+1)log(k+2)) bits.

## Overlap at one displayed word

Let S be the number of clean ones in the first M coordinates. The displayed interior is all zero exactly when S<=k. Under either alternative,

    E S=M p<=k/4,
    P(S<=k)>=3/4

by Markov's inequality. The two terminal coordinates are independent of S and have probability (1-p)^2>=9/16 of both being zero. Consequently, under both alternatives,

    P_p^Z(Z=0^N)>=27/64.                            (P2)

The target separation at this same displayed word is

    p_+-p_-=k/(8M).

For every predictor Q, retaining just this one output in the two-source absolute-loss inequality gives

    Risk_+(Q)+Risk_-(Q)
      >=min{P_+^Z(0^N),P_-^Z(0^N)}(p_+-p_-)
      >=27k/(512M).

Dividing by two proves (P1). No assertion of global observation-law closeness or latent-to-posterior lower transfer is needed.

## Combination with other online witnesses

Combining this witness, the identity-channel clean lower, and `KNOWN_CHANNEL_online_one_edit_lower.candidate.v1.md` by a maximum-of-three argument gives, for fixed beta<1 and every 1<=k<=M,

    R_online,beta(M,k,rho)
      >=c_beta min{1, M^(-1/2)+k/M+min{rho,M^(-1/3)}}.

The candidate's full growing-k endpoint lower min{rho,(k^2/M)^(1/3)} remains unresolved. The k/M term itself is now explicitly realized by a protected normalized online channel with constant base-state size.
