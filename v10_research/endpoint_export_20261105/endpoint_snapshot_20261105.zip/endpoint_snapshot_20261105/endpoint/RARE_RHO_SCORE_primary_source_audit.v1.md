# Primary-source delta audit: rare-rho S=1 lower and score barriers

Date: 2026-11-05 UTC. Focused source reading and mathematical comparison, not novelty certification or independent proof acceptance. No scientific executable checks, numerical experiments, or public writes were performed. Supplied candidates, reviews, and preceding audits remain unchanged.

## 1. Findings: three different conclusions

All three requested current files have separate analytical PASS reviews bound to the hashes below. Their conclusions should not be conflated.

1. **The rare-rho construction is a statistical lower bound.** For fixed 0<beta<1, sufficiently large M, N=M+2, integer 1<=k<=M, rational rho in [0,1], and b=min{1,k/sqrt(M)}, it establishes

       R_(S=1,beta) >= c_beta min{1,M^(-1/2)+k/M
                              +min{rho sqrt(b),b sqrt(rho)}}.

   This strengthens the earlier endpoint term rho*b. It leaves a gap to the inherited no-floor upper with endpoint term min{rho,(k^2/M)^(1/3)}. It does not establish a sharp general S=1 rate or necessity of two base states.

2. **The iid one-edit addendum is a barrier to latent-posterior and missing-information shortcuts.** It has overlap-weighted full-history posterior discrepancy Omega(d) and missing complete Fisher information Omega(M^2), but the specified two-source prediction problem has risk Theta(1/M) for fixed d. No constant predictive lower follows.

3. **The endpoint-only full-score v2 is a barrier to specified rho-weighted derivative inequalities.** It excludes E|Cov(g,S_all|Z)|<=C_beta rho^alpha k sqrt(I_step) for alpha>1/2, already at k=1. It neither proves the alpha=1/2 inequality nor supplies a new predictive minimax separation. It does not exclude bounds with a separate rho-independent baseline.

The closest newly inspected endpoint precedent is Chan–Darwiche's explicit binary conditional-belief sensitivity example, rather than only general Bayesian brittleness. The score and missing-information identities have direct Louis, Pollard, and posterior-covariance precedents. The local novelty-sensitive issues are exact channel admissibility, uniform scales, output-mass weighting, signed-count retention, and the precise method inequality being contradicted.

## 2. Common experiment and state accounting

For each fixed unknown source theta, the requested target is

    p_(theta,C)(z)=P_(theta,C)(X_(N+1)=1 | Z=z).

Loss is expected absolute error in this conditional probability. The posterior averages hidden clean histories under that fixed source; it is not a posterior over competing source hypotheses. The same disclosed normalized channel C is used under the two alternatives. Source independence means C does not receive the unknown alternative parameter, not that edits are independent of the input word or counter.

Every physical edit increments an actual counter. One base state excludes the separately charged k+1 counter values and public horizon-indexed tables. No free hidden mode, raw-history register, counter relabeling, or homogeneous one-total-state claim is supplied. The source may be first order viewed as an at-most-second-order source; an exact-order-two-only theorem is not asserted.

The rare lower records activation by the first real prefix edit. On an observable all-zero prefix, zero-one and single-one raw preimages end at a common raw-zero anchor. The subsequent tail is independent of the activation mode conditional on that branch, but its mode prior omega_a depends on a. The table uses a common design t, not the unknown a_+ or a_-. It is allowed to depend on M,k,rho and that shared design.

The iid barrier similarly uses a raw-dependent actual-counter mode: whether the first M bits contain any one. By contrast, the full-score v2 needs no activation mode at all. It passes the prefix and flips only the final historical bit with probability rho. Attributing that v2 obstruction specifically to hidden-counter memory or remote-score mixing would be incorrect.

Dey, Jaggi, Langberg, and Sarwate's causal-adversary model already permits current/past-input dependence, randomization, and hard Hamming budgets. Its communication converse does not furnish the present channel-aware posterior target or base-state accounting. The previously audited standard finite-state-channel convention counts all persistent counter memory as state. Those precedents remain applicable; the new score examples do not alter their model distinctions. [Primary causal-channel paper, sections II–III](https://arxiv.org/pdf/1204.2587).

## 3. What changes in the rare-rho lower

The first-order source is P_a(1|x)=a+rx, with fixed small r>0 and a near t. Its stationary success mass is a/(1-r); its pair-chain stationary-relative two-step minorization is at least 1-r. Thus fixed mixing is compatible with a tending to zero. The source alternatives use delta=d sqrt(t/M), and fixed-start tail KL is O(M delta^2/t)=O(d^2).

The channel spends one prefix activation edit, at most h=min{k-2,floor(sqrt(M))} interior edits, and one reserved endpoint edit. Its dyadic t is comparable to max{rho,h/sqrt(M)} up to fixed beta-dependent constants. The prefix length 1/t is public and charged. The horizon and parameter family vary; this is not failure at one fixed source and infinite-stream channel, nor uniformity as beta approaches one.

Unlike the positive-floor construction, the conditional odds for a missing candidate surrounded by 11 can **decrease** with a. The exact capped likelihood remains a positive polynomial in site odds, but its useful comparison is signed:

    G(Y)=E_-[D_00-4D_11 | H,Y,U=1],
    log Lambda_+(Y)-log Lambda_-(Y)>=(delta/t)G(Y).

The proof retains positive signed mass on a likelihood-overlap region and selects G>=0. Replacing G with the total number of edits would lose the adverse contribution and is not justified. Conditional candidates are independent after fixing the recoverable scaffold, but are not generally identically distributed. Their retained future neighbors enter mathematical likelihoods, never an earlier online decision.

The large-odds cost also matters: the expected conditional odds sum is O(M(t+r^4)), not automatically O(Mt). The thinning overlap and its scale pay for this term. The capped process is not the uncapped product law conditioned on a count event. Its exact latent-erasure polynomial supplies the small signed separation; cap coupling is used to obtain overlap and moments, not subtracted as a fixed absolute error from the final vanishing target gap.

At the endpoint, the source-specific target is a+rF(a,rho v_a). The favorable mode change and the direct changes of a and the endpoint prior have opposing signs. The proof explicitly pays the latter. Multiplication by the actual output mass, comparable to t+rho on the retained region, gives a favorable contribution of order

    h delta rho/(t+rho)

and aggregate adverse cost O(delta). The separate clean lower absorbs that root-M cost. This yields min{rho sqrt(b),b sqrt(rho)}. Taking a maximum over clean, protected, and endpoint witnesses supplies the sum up to constants; their channels and edit budgets are not combined.

For example, k of order M^(1/4) and rho of order M^(-1/8) give endpoint lower M^(-5/16), versus the fixed-floor rho*b scale M^(-3/8). This demonstrates why the fixed-floor profile cannot be extended uniformly to the whole D2 class even with S=1. It does not contradict a theorem whose constants assume a fixed positive floor.

Abraham, Gassiat, and Naulet explicitly separate fixed spectral gap from sample-size-dependent degeneracy parameters in their HMM minimax analysis. Remark 1 and theorem 1 are strong conceptual precedent: mixing does not give uniformly easy estimation near a boundary. For the current two-state raw chain, the second eigenvalue is r and the gap is 1-r while a can vanish. Their target is HMM parameter estimation with ordinary emissions, not the present posterior prediction through a disclosed strict-edit transducer; their rate does not transfer automatically. [Primary version 3, section II, remark 1, theorem 1](https://arxiv.org/pdf/2106.12936v3).

Darwiche's network-polynomial inference and the log-partition/expected-statistic identities discussed in the preceding audit remain direct precedents for the latent-set expansion. The signed-count choice, chronological-cap coefficients, and source-row cancellation still require the present model-specific argument. The UAI and JACM versions have different theorem numbering. [Primary UAI manuscript](https://arxiv.org/pdf/1301.3847); [previously inspected JACM manuscript](https://people.cs.pitt.edu/~milos/courses/cs3710/readings/differential-darwiche.pdf).

## 4. Established score identities and their exact scope

Keep the channel, horizon, and any channel-design probabilities fixed while differentiating the source parameter a. For the complete stationary source score,

    S_all = partial_a log pi_a(X_1)
              +sum_(i=2)^N partial_a log P_a(X_i|X_(i-1)),

the relevant finite-model identities are

    S_Z=E_a[S_all|Z],
    I_all-I_Z=E_a Var_a(S_all|Z),
    partial_a E_a[g_a(X)|Z=z]
      =E_a[partial_a g_a(X)|Z=z]+Cov_a(g_a(X),S_all|Z=z).

The last identity requires the direct derivative when the target itself depends on a. All supplied finite raw laws are positive at each evaluation point, with a parameter-independent channel support, so these differentiations are legitimate locally. This does not promise constants uniform along the vanishing-probability sequence.

Louis, *Finding the Observed Information Matrix when Using the EM Algorithm* (1982), section 3.1, equations (3.1)–(3.3), gives the conditional-score and missing-information formulas. His output-specific observed information is a negative log-likelihood Hessian; expected Fisher information follows after averaging under regularity. These should not be treated as identical quantities without that step. The original equations were inspected through indexed primary-paper excerpts; direct retrieval of the PDF failed, so no full-paper inspection is claimed. [Primary PDF location](https://markirwin.net/stat221/Refs/louis1982.pdf); [publisher DOI](https://doi.org/10.1111/j.2517-6161.1982.tb01203.x).

Pollard's theorem 7 shows that a statistic of a differentiable-in-quadratic-mean experiment has the conditional-expectation score, with Fisher equality exactly when the original score is measurable through the statistic. For a randomized fixed kernel, apply this to the joint law P_a(dx)C(dz|x), then project to z; its score remains the raw-source score. This gives full-information contraction, not a bound by k^2 times one-step information. Nor does Fisher equality generally imply sufficiency, as the Kagan–Shepp example discussed there illustrates. [Primary version 2, theorem 7 and section 5](https://arxiv.org/pdf/1107.3797v2).

Giordano, Broderick, and Jordan's theorem 1 and corollary 1 give exact covariance sensitivity under normalized exponential reweighting before introducing variational approximations. It is a convenient primary formulation of an established Bayesian robustness identity. Here the integrated variable is the latent raw history, not the unknown source parameter. The candidate's additional direct derivative is necessary because g_a changes with a. [Primary JMLR paper, section 2.2, equations (4)–(5), appendix A](https://jmlr.org/papers/volume19/17-670/17-670.pdf).

For a stationary Markov source, complete expected information is I_init+(N-1)I_step, because transition scores are martingale differences. It must not be replaced by I_step. In the endpoint-only example, all preterminal score terms, including the initial-law score, become observed-prefix measurable and their conditional covariances vanish. This is a proved cancellation after defining the complete score, not permission to omit those terms at the outset.

## 5. The iid barrier does not contradict ordinary posterior stability

The deterministic S=1 channel erases the first one in positions 1,...,M and protects the last two bits. For iid a_+/-=(1+/-d)/M, the full all-zero output has constant probability. Its preimages are exactly the zero word and the M singleton-one words. The hidden edit posterior is

    v_a=Ma/[1+(M-1)a].

On this branch, the erased-position distribution is uniform under either alternative, so full-history posterior TV equals the difference of these two weights. It is Omega(d), while raw KL is O(d^2). With d fixed, the discrepancy does not decay with M. If d is made smaller to shrink KL, its lower-bound constant also shrinks. There is no d-independent discontinuity as KL tends to zero.

McDonald–Yuksel's common-kernel expected posterior-TV lemma already bounds this discrepancy by a constant times raw-law TV. Pinsker gives an O(d) comparison here, fully consistent with the candidate's Omega(d) result. The refuted assertion is the stronger extra k/sqrt(M) decay for the full hidden posterior, not general expected Bayesian continuity. A finite offline kernel also fits the one-update lemma by enlarging the latent state; no sequential-emission assumption is needed for that ingredient. [Primary version 2, lemma 3.2](https://arxiv.org/pdf/1910.08463v2).

At a_0=1/M, one-step information is Theta(M), complete information is Theta(M^2), and the actual missing information is Omega(M^2). This obeys information data processing but contradicts a uniform C_beta k^2 I_step bound at k=1. Similarly, the hidden-mode derivative is order M on a constant-mass output, larger than k sqrt(I_step).

The future target, however, is identically a under each iid source. Its derivative is one; the uncertainty over erased locations has no effect on that future conditional law. The supplied pair's predictive risk is between d/(2M) and 3/M. This is not a 3/M upper over the full source class. Neither latent TV nor total missing information can be converted into a predictive lower by reversing a projection or conditional-Jensen upper bound.

## 6. The endpoint-only barrier has a very close binary precedent

Chan and Darwiche, *When do Numbers Really Matter?*, theorem 3.1 and example 3.1, give a tight derivative bound F(1-F)/[p(1-p)]. Their binary roots/equality-evidence example matches the candidate's W=1 posterior: set root probabilities p and 1-rho, so evidence probability is p(1-rho)+(1-p)rho and the conditional success is p(1-rho) divided by it. At p=rho=s, the derivative is 1/[4s(1-s)]. The candidate multiplies this by r. Thus the local amplification algebra has a direct antecedent. Their pointwise theorem does not state the stationary D2 embedding or integrated Fisher-normalized obstruction. Use the journal version for these locations. [Primary JAIR paper, pages 273–275](https://arxiv.org/pdf/1106.1814).

The candidate's complete-score covariance is exactly

    r rho(1-rho)/ell_w^2,

and its predictive target derivative is one plus that covariance. At a_0=rho=1/M, the retained event has probability pi_a(0)2rho(1-rho), while the covariance there is r/[4rho(1-rho)]. Their product is pi_a(0)r/2. The derivative comparison therefore retains, rather than drops, the rare observation mass.

Since I_step<=2M, rho^alpha sqrt(I_step) tends to zero for alpha>1/2, whereas the integrated absolute covariance stays bounded below. The squared covariance is Omega(M), excluding any positive rho exponent in the stated squared-covariance form rho^alpha k^2 I_step. Neither calculation establishes a valid replacement inequality at a boundary exponent.

Crucially, a_0=rho selects the evaluation point. Rho is held fixed when a varies; differentiating along rho(a)=a would be a different experiment. The expectation of a target derivative is also not automatically the derivative of its expectation under the changing output law.

The local source-parameter separation suggested in the note is O(1/M). Although it can produce a constant target change on the rare branch, that branch has mass O(1/M). Its integrated predictive contribution is therefore only O(1/M), below the independent clean M^(-1/2) minimax scale. A derivative obstruction by itself does not supply the finite-alternative loss/overlap proof required for a stronger minimax lower.

## 7. Bounded positioning and evidence

Describe the rare-rho result as an improved one-base-state statistical lower using a source-dependent paid-counter activation, signed capped likelihoods, and a fully weighted endpoint calculation. Describe the other two results as explicit no-floor counterexamples to specified intermediate score controls. Do not call all three predictive impossibility results.

Existing work already supplies clipping, posterior normalization, likelihood-ratio oscillation, missing-information identities, and covariance sensitivity. No first-instance, minimal-state, exhaustive priority, or novelty claim follows from this search. The results do not settle the general no-floor S=1 rate, validate an alpha=1/2 score bound, rule out all endpoint-specific methods, or contradict the fixed-floor upper.

Read in full: all three requested current files and their corresponding current independent reviews. Prior comparisons were revisited in `ONE_STATE_POSITIVE_FLOOR_primary_source_audit.v1.md`, `THINNING_MODE_primary_source_audit.v1.md`, and `QUANTITATIVE_BINARY_RATE_primary_source_audit.v1.md`. Primary sources were inspected at the cited locations, with the Louis retrieval limitation stated above.

Present-byte SHA-256 bindings:

- `KNOWN_CHANNEL_one_state_rare_rho_lower.candidate.v1.md`: `d784c6abdc1eaaae97dc5dcdd8fab478f05ea387b40c8e634b452345749503cb`
- `KNOWN_CHANNEL_one_state_rare_rho_lower.independent_review.v1.md`: `bff649fd9911b2b179b2eb445a7f4a3ecea78016897aad07aff3d1356c6e3216`
- `KNOWN_CHANNEL_one_state_iid_score_barrier.addendum.v1.md`: `624464557dacee297f0f651d1ae99e92f94f67a26a0d874d7a7673c36b6eaded`
- `KNOWN_CHANNEL_one_state_iid_score_barrier.independent_review.v1.md`: `b2556e0803a72fb6905ab0ea53d7266492665a456cf7b93ea639ffd7ae4c191f`
- `KNOWN_CHANNEL_one_state_full_score_rho_barrier.candidate.v2.md`: `18477855bd28f5a7fbfb0684801caee8bf19f75ca449296a32e4064b17cf7c06`
- `KNOWN_CHANNEL_one_state_full_score_rho_barrier.independent_review.v2.md`: `e8946e33fd497807abba0295395a440cf574a0ba55c3303543383712c9533ae7`

The analytical PASS dispositions above are reports of existing exact-file reviews. This source audit neither reissues those verdicts nor supplies scientific execution evidence.
