# Independent review of the finite-state sharp-rho upper composition

Review time: **2026-11-05 06:34:47 UTC**.

Reviewed candidate: `./KNOWN_CHANNEL_sharp_rho_transformer_composition.candidate.v1.md`.

Independently measured SHA-256: `572f4a4d36f3afe4f23d8b4f1830031e8aa1a58ef80e9b2661c6586f20492c0a`.

I read the complete candidate, the relevant EPR001 upper and review, the SC003 estimator/constant statements, and the previously reviewed full-log-free construction. The final amendment specifying a **dyadic** upper-budget substitute was checked before binding this review. This is a present-time analytical review of the listed bytes, not a historical hash inference. No scientific executable checks, numerical experiments, model execution or public writes were performed. Earlier artifacts remain unchanged.

## Disposition and exact scope

**Analytical PASS for the claimed interpolation upper and its paid implementation.** The candidate correctly combines the clipped protected estimator and the complete log-free estimator, makes a deterministic public choice between them, and incurs only one final output-approximation error.

The reviewed effective interface has exact dyadic beta=a_beta/2^p in (0,1) and exact dyadic rho=a_rho/2^q in [0,1]. The source is stationary binary order two and satisfies the all-state minorization certificate. The actual channel is a disclosed normalized rational online finite-state channel with an all-realization k-edit cap, independent auxiliary randomness and the stated per-clean-word endpoint bound. Neither the certificate nor the channel's admissibility is inferred from a single observation.

The approval does not silently broaden the exact input interface to every non-dyadic rational rho or an unnamed arbitrary real parameter. A certified dyadic upper budget can be used with its precision and excess risk charged, as the corrected candidate states.

## 1. Protected rule and exact rational clipping

The selected SC003 orientation is correct: the designated successor is the complement of the first bit of the observed terminal pair. Its lower-envelope numerator is max(C_des-6k,0), and its denominator is J'+6k+2. This is the reviewed protected estimator, not ordinary add-one applied to a potentially forged query.

Its symbol-1 probability and the pooled generated-symbol frequency lie in [0,1]. In the binary simplex, radial TV clipping is exactly

    min(zbar+1-beta, max(zbar-(1-beta), q_raw(1))).

The interval endpoints need not themselves lie in [0,1], but the nested clip of q_raw does. The common denominator D_all=M D_row 2^p is positive. The three displayed signed integer numerators are algebraically correct. The lower candidate numerator can be negative and the upper one can exceed D_all; signed comparisons select a final numerator between zero and D_all. The precision budget includes a sign/guard allowance.

Crucially, the complete rational rule is computed before its final integer division and dyadic output. There is no intermediate rounded q_raw whose error would require a second approximation allowance. The output error is below 2^-r, with the possible integer output bit retained.

## 2. Imported protected risk and posterior transfer

EPR001 supplies the stated upper coefficients from A_2=2^17 and B_2=2^19. Its proof uses a repaired endpoint-preserving channel to bound the contribution of the endpoint-preservation event. It does not apply an unconditional protected risk theorem after conditioning on a history-adaptive event.

That auxiliary repair may be offline and need not belong to the finite-state subclass being implemented. This is legitimate because the imported protected upper holds over the larger class. The repair is solely a proof device; neither its computation nor the original clean word is provided to the predictor.

Independent channel randomness and future blindness give

    p_(theta,C)(Z)=E[theta_(S(X))(1) | Z].

Since the implemented statistical rule is a deterministic function of Z, conditional Jensen transfers the latent-row **upper** unchanged to the source-specific posterior target. This neither transfers the latent-target lower nor changes the posterior into a source-hypothesis mixture.

## 3. Minorization direction and explicit common constant

The integer-defined b=2^-u is a valid downward lower bound on beta. It is used for the full log-free estimator and its constant A. The clipping radius in the protected estimator uses the exact supplied beta, so no upward-rounded certificate or unjustifiably narrow clipping radius is introduced.

Since e>=sqrt(beta)>=sqrt(b), for k>=1,

    F_beta <= (k/M)[1+log(1+2^(u/2))]
           <= (u+2)k/M.

Consequently C_lat=2^22(u+2) dominates every coefficient of s, k/M and rho in the protected posterior bound. The elementary inequality u+2<=2^(u+1) gives

    C_lat <=2^(u+23)<=C_0=2^(163+10u).

Thus C_0 simultaneously dominates the protected rule and the previously reviewed complete log-free rule. The proof does not merely assume that an unspecified large constant is sufficient. Square roots and logarithms used in this statistical comparison are not runtime primitives.

## 4. Exact public dyadic selection

The proposed s_up is the smallest relevant dyadic scale obtained from the bit length of M and obeys s<=s_up<2s. The least integer h_a with M2^(3h_a)>=(k+1)^2 gives a_0<=a_up<2a_0. Negative exponents are handled by multiplying the other side by the corresponding integer power of two, so no cube-root or real logarithm oracle is needed. A finite exponent range of length O(log N) suffices.

Both risk proxies are exact finite rationals. With L_up=s_up+k/M+rho, the selected exact estimator has risk at most C_0 min(L_up,a_up): the protected estimator is bounded by C_0 L_up whenever selected, and the log-free estimator by C_0 a_up whenever selected.

Because L_up<2(s+k/M+rho) and a_up<2a_0, this is at most

    2C_0 min(s+k/M+rho,a_0).

For k>=1, a_0<=2(k^2/M)^(1/3). The candidate's subsequent minimum inequalities are correct and yield C_int=4C_0 times

    M^-1/2+k/M+min(rho,(k^2/M)^(1/3)).

The selection is independent of the displayed trajectory. It is therefore not a data-dependent minimum of two unconditional risks. Only one selected output is ultimately used; implementing each possible output to accuracy 2^-r adds at most 2^-r, not twice that amount.

## 5. Zero budget and endpoint cases

At k=0 the strict all-realization budget forces Z=X, irrespective of rho. The separate clean add-one branch and its inherited 2^17 M^-1/2 bound are valid. No positive-budget selector or endpoint term is used. Its final dyadic approximation adds only the displayed error.

The finite positive-budget selector also remains well defined at rho=0 and rho=1. The theorem deliberately assumes beta<1, matching the fixed-beta scope of the cited sharp statistical profile; it does not use this upper to claim an endpoint lower at beta=1.

## 6. Bit, state and network costs

Charging p separately from u is essential and is done correctly. For example beta=1-2^-p may have u=1 while its exact clipping radius still requires p bits. The q-bit endpoint budget is likewise charged in the public rational comparison. Exponents cannot be treated as a compact header granting their full binary expansions for free.

The protected rule needs O(p+r+log N) integer bits: D_row<=7M+2 and D_all=M D_row 2^p. The selector needs O(q+log N) rational-comparison bits and a bounded public exponent search. The declared B_int and padded G_int safely cover those costs in addition to the complete posterior circuit. Signed clipping intermediates, final output selection and the possible integer bit are accounted for.

The existing compilers therefore apply to the enlarged Boolean circuit without changing raw inputs or introducing a previous-token port, a future symbol, an arbitrary rational decoder, or a likelihood oracle. All rows still receive valid prefix-padded words. The outputs of comparisons are Boolean, so the all-row bounded-state invariants remain valid.

The two alternatives are:

- Growing bank: d,L=O(G_int), scalar rational size O(r+log N+log G_int).
- Two stacks: d=64, FFN128, L=O(N log N+G_int^2), scalar rational size O(G_int+r+log N).

The full dense parameter, runtime, activation and optional attention-storage ledgers are retained. Large statistical thresholds are represented by counted bits and operations, not by unbounded coefficients or attention scores. Exact rational arithmetic is a different contract from generic floating-point evaluation.

## 7. What this approval does not establish

This is an explicit upper with the same fixed-beta rho profile as the broader statistical theorem. The actual channel class is strictly narrower. The offline lower witnesses and the EPR latent-target lower cannot be imported to prove matching restricted-channel posterior minimax risk. The candidate correctly makes no such claim.

The SC003 protected theorem is imported at its reviewed scope, not independently reproved in this composition audit. No all-initial-law extension, conditional-on-word risk guarantee, moving-beta sharpness, external novelty, training result, mandatory-PreLN construction, tied parameter vector, optimal depth/width/precision frontier or IEEE robustness is certified here.

With these boundaries, the candidate closes the upper-composition and public-selection implementation step for its exact dyadic-certificate interface.
