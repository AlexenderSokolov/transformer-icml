# Independent review: stationary binary log-free known-channel upper

Review time: 2026-11-05 05:23:44 UTC.

## Exact artifact and outcome

Reviewed candidate: `KNOWN_CHANNEL_stationary_binary_logfree_upper.v2.md`.

Candidate SHA-256:

`a94a259168502b550b696d970b9a577689e82703365b02b0397d5c0a6f14232f`

Outcome: the proof of (V1), through (V2)–(V29), passes this independent analytical review. No substantive gap remains. This review binds the candidate bytes identified above, not earlier drafts or subsequent changes. The earlier floor-based v1 is not the artifact certified here.

The accepted upper is

    R <= C_beta min{1, ((k+1)^2/M)^(1/3)},

for fixed 0<beta<1, M>=64, and 1<=k<=M, stationary binary homogeneous order-two sources satisfying the all-state two-step D2(beta) certificate, and every disclosed source-independent future-blind strict-k Hamming channel. The target is the actual source-specific posterior next-symbol law given the displayed word. The fitted predictor can depend on the disclosed channel and may sum over all clean preimages.

This was a mathematical audit. Local file reads, digest calculation, and writing this review are not scientific executable checks. No numerical experiments, simulations, public writes, efficient-computation certification, or external novelty assessment were performed.

## 1. Stationary geometry and the endpoint-conditioned count law

Summing the all-state certificate P^2(u,v)>=beta Pi(v) over the destination's second coordinate gives theta_u(c)>=beta pi(c). Stationarity then gives Pi(a,b)>=beta pi(a)pi(b). With minority mass m>0, every pair mass is at least beta m^2 and every triple mass at least beta^2 m^3. The proof does not silently reduce the source to first order.

The triple chain H_i=(X_i,X_(i+1),X_(i+2)) has stationary law Lambda(a,b,c)=Pi(a,b)theta_(a,b)(c). Its three-step kernel is exactly

    T^3(h,(a,b,c))
      =P^2(last_pair(h),(a,b))theta_(a,b)(c)
      >=beta Lambda(a,b,c).

Reversing the stationary chain preserves this minorization: (T_rev)^3(h,g)>=beta Lambda(g). Conditioning on the future symbol X_(N+1)=c only changes the starting distribution of the reversed chain at H_(M+1). It does not change its backward transition kernel. Each of the three reverse residue classes therefore has a beta-minorized kernel with arbitrary initial law. The training context, triple, and generated-symbol counts are sums of indicators on these classes. Summing the three concentration bounds uses no independence between classes.

This establishes the conditional count bounds without dividing by the minority probability, assuming endpoint/count independence, or applying a forward martingale inequality after conditioning on its future. Those would not have been legitimate substitutes.

## 2. Log-free regenerative concentration

For a kernel K>=beta Lambda, the residual kernel Q=(K-beta Lambda)/(1-beta) preserves Lambda. Under a fresh Lambda start, each complete regeneration cycle has an independent geometric length L and a Q trajectory with stationary one-time marginals. For its centered indicator reward W,

    E W=0,
    E|W|^j <= 2^j p E L^j <= p j! B_beta^j.

Thus the complete-cycle reward has a Bernstein moment generating function with variance scale proportional to the stationary indicator probability p.

The bounded-stopping step is valid even though cycle length and cycle reward are dependent. Use the filtration revealing the entire successive cycles. If T_n is the first cycle whose cumulative length reaches n, then T_n<=n. With a nonnegative compensator psi(lambda) bounding the cycle log moment generating function, optional stopping gives

    E exp(lambda sum_(i<=T_n) W_i - T_n psi(lambda)) <= 1,

and hence

    E exp(lambda sum_(i<=T_n) W_i) <= exp(n psi(lambda)).

No independence of T_n and the rewards, and no unproved Wald identity, is needed.

The excess part of the covering cycle after the deterministic time n is bounded by the waiting time for the next refresh coin. This has a geometric tail independent of n. In particular, the proof does not bound it by the maximum of the first n cycle lengths, which would introduce a needless log n. The possible initial block under an arbitrary initial law has another geometric tail; after its refresh the remaining deterministic horizon starts independently from Lambda. This proves the stated arbitrary-start concentration.

Tail integration then gives both the second moment O_beta(v+1) and, for v>=1 and lambda<=c_beta/sqrt(v),

    E exp(lambda |V-v|) <= 1+C_beta lambda sqrt(v).

These statements remain valid for the reverse residue-class sums after changing beta-dependent constants.

## 3. Displayed-data good event and fitted law

The add-one row and initial-law estimates are positive probability vectors. The initial-law estimate need not be stationary for the fitted rows: their product still defines a valid clean-word probability law for the surrogate posterior. The candidate explicitly defines these fitted vectors for every output, even when the actual decision uses the majority branch.

The good event G uses only displayed counts and displayed frequency, together with fixed true-source parameters in the analysis. Thus it is Z-measurable. The predictor itself does not need to know or test G.

The pathwise inequalities |J'-J|<=2k and |C'-C|<=3k remain valid for every adaptive randomized channel realization. From m>=a=A_beta((k+1)^2/M)^(1/3), all relevant coordinate means exceed B_beta(k+1)^2 once A_beta is chosen. The context and marginal failures then have unconditional probability at most C_beta/(M m^2). Charging unit loss on these failures is adequate; no globally rare triple-count accuracy event is imposed.

This measurability choice is essential. A good event depending on the hidden clean context counts could not simply be inserted into the posterior minority-weighting identity. The accepted v2 does not make that substitution.

## 4. Ordinary and inverse count moments

On G the displayed row denominator, divided by w=M Pi(u), lies in [1/2,3/2]. If the displayed successor numerator is at least v/2, its fitted row log error is bounded by normalized absolute clean count errors plus the deterministic edit and add-one terms. The count exponential-moment bounds and Holder's inequality prove (V16) for the entire exponent range 1<=ell<=256(k+1). The underlying count laws are not conditioned on G.

If instead C'+1<v/2, then the fitted coordinate is below its true coordinate, while add-one gives the deterministic inverse bound

    theta/theta_hat = v[(J'+2)/w]/(C'+1) <= (3/2)v.

The same event forces a clean successor-count deficit of at least v/4, and hence has probability at most C_beta exp(-c_beta v), under either the unconditional or future-minority-conditioned source law.

The required absorption is uniform in the coordinate mean and the edit budget. For j=k+1 and v>=B_beta j^2,

    ell log((3/2)v)/v
      <= 256 log((3/2)B_beta j^2)/(B_beta j).

For sufficiently large B_beta the right side is decreasing for j>=1 and tends to zero uniformly as B_beta increases. Therefore the inverse power v^ell is paid for by half of the exponential lower-tail exponent. The remaining contribution is bounded by C_beta ell/sqrt(v).

This resolves the critical low-count issue. Bounding the inverse likelihood ratio by a power of 1/m and using only the worst triple mean would not establish the result. The accepted proof uses the coordinate mean v itself and does not need a data-dependent transition floor.

Initial-law log ratios have the easier analogous bound on G. The constant choices are compatible: first choose the finite concentration and exponent constants, then B_beta sufficiently large, then A_beta to ensure all required mean and denominator inequalities. No constant depends on the source, channel, k, M, or rho.

## 5. Posterior comparison and correct minority weighting

Two clean preimages of one displayed word are within Hamming distance 2k. At most 6k historical triples differ. Their fitted-to-true log likelihood ratios therefore have oscillation at most 12k S_max+2D_max. The same disclosed channel factor cancels exactly. Positivity of the fitted law and of the true law when m>0 ensures common posterior support.

Although the fitted parameters depend on the displayed word, this comparison is pointwise at that word and is valid. The resulting normalized posterior density ratio and the fitted successor ratio yield

    |q(z)(c_*)-p(z)|
      <= p(z)[exp((12k+1)S_max+2D_max)-1].

There is no requirement that p(z) be bounded by the stationary minority mass m. It can be large on selected outputs.

Truncating the eight transition and four initial-law log errors by G and applying twelve-factor Holder uses exponents at most 256(k+1), within the established range. The resulting conditional exponential moment is O_beta(delta_m), where

    delta_m=(k+1)/sqrt(M m^3)+(k+1)^2/(M m^3).

Because the truncated factor is Z-measurable, the identity

    E[p(Z)F(Z)] = m E[F(Z) | X_(N+1)=c_*]

is exact. This yields the minority-weighted risk in (V26). Future blindness is used both to identify the correct next-symbol posterior average and to retain the same channel conditional on the future source symbol. Arbitrary offline history dependence and channel randomization are otherwise allowed.

## 6. Adaptation, boundaries, and final rate

For m>=a, a majority decision on G implies m<=4a and has the correct majority label. Its integrated loss on that subset is at most m, not an incorrectly asserted pointwise bound. The posterior branch contributes

    C_beta[(k+1)/(sqrt(M)sqrt(m))+(k+1)^2/(M m^2)].

At m>=Aa0 these terms are bounded by C_beta a0. The context/marginal exceptional probability is also O_beta(a0). For m<a, the frequency event with error at most a forces the correct-majority decision; its complement is controlled by the minority-count second moment and the deterministic k/M edit perturbation. The case m=0 is handled directly. If a>1/16, the unit risk cap yields the stated bound with a larger beta-dependent constant.

The theorem is scoped to fixed 0<beta<1 and k>=1. The separate k=0 clean rate remains M^(-1/2). The review does not infer a uniform-in-rho interpolation, a result for arbitrary initial laws, an efficient implementation, or a beta=1 rare-source lower.

## 7. Comparison with the independently reviewed lower

The prior rare-budget candidate has SHA-256

`9bfc30dcf44224b238ea315a7d306e4ff4e6ef7f6108e9fd97ed68dd3fb19689`

and its independent review has SHA-256

`b2ce6c9c1880034bd966c8bb2d38488f079dfb3ccd9b93ee5172fc26281f3c0d`.

That lower gives c_beta[M^(-1/2)+rho min{(k^2/M)^(1/3),1}] uniformly in the stated budgets and reliability parameters for sufficiently large M. Combining it with this accepted upper establishes the matching stationary binary known-channel minimax rate

    Theta_(beta,rho)(min{1,(k^2/M)^(1/3)})

for fixed 0<beta<1, fixed rho>0, and 1<=k<=M, for all sufficiently large M. The constants in this matching statement may depend on rho. At k=1 the rate is M^(-1/3), rather than the fixed-positive-floor M^(-1/2) rate. The previously open logarithmic factor is removed.

The comparison is a uniform minimax statement with horizon-dependent least-favorable sources and a disclosed common channel in each lower-bound experiment. It is not a pointwise fixed-source inconsistency assertion or an external novelty certification.
