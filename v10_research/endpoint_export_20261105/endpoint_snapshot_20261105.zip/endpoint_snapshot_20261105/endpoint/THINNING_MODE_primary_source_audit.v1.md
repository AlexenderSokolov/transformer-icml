# Primary-source delta audit: hidden thinning mode and the matched online rate

Date: 2026-11-05 UTC. Focused analytical source comparison, not novelty certification or a substitute for independent proof review. No scientific executable checks, experiments, or public uploads were performed. The supplied proofs, reviews, and earlier audits remain unchanged.

## 1. Finding and correction to the preceding audit's current status

The new hidden-mode thinning construction closes the growing-budget endpoint gap recorded in `ONLINE_STRICT_EDIT_primary_source_audit.v1.md`. Its exact current file has a separate **Analytical PASS**, dated 2026-11-05 08:13:23 UTC. That review accepts the endpoint lower

    c_beta min{rho,(k^2/M)^(1/3)}

for fixed 0<beta<1, sufficiently large M, all integer 1<=k<=M, and rational rho in [0,1], in the declared online class with an allowed base-state budget S>=8. Together with the already reviewed clean and protected-budget witnesses and the applicable upper, this gives

    R_online,beta(M,k,rho)
      = Theta_beta(min{1, M^(-1/2)+k/M
                              +min{rho,(k^2/M)^(1/3)}}).

The preceding audit's open growing-k rate and growing base-state requirements are therefore historical statements about the earlier construction, not current conclusions. That older construction used O(N^2) base states and attained only (k/M)^(1/3). The new witness needs eight base states, **plus** a paid edit counter and horizon-indexed tables. Neither result proves a separation between online and offline adversaries. The new result instead attains the same statistical rate in this online subclass.

The strongest literature comparisons are: mixed channels for persistent hidden modes; generic identifiability of product-Bernoulli mixtures; causal hard-budget coding attacks; expected Bayesian-update stability; near-degenerate HMM minimax theory; and thinning-based corruption lower bounds. None should be described as absent prior work. The comparison-sensitive composition here is their realization in one common disclosed rational causal kernel, with exact strict and endpoint budgets, for a source-specific clean-future posterior and the stated paid-state rate.

## 2. Experiment, target, and resource quantifiers

Let N=M+2. The clean process is a stationary binary homogeneous order-two Markov source. Its pair chain satisfies the fixed all-state two-step minorization D2(beta). The unknown source parameter is theta. The predictor receives the entire displayed word Z and the complete channel C, but not the raw history, realized hidden mode, edit counter, mask, or channel coins.

The target and loss are

    p_(theta,C)(z)=P_(theta,C)(X_(N+1)=1 | Z=z),
    E_(theta,C) |Q(Z,C)-p_(theta,C)(Z)|.

This is expected Bernoulli probability-estimation loss. It is not message-decoding error, hidden-state classification error, parameter loss, or loss against the transition row selected by the unobserved actual final raw pair. Conditioning averages hidden histories under each fixed theta. It does not put a prior on theta.

The new fair bit U is different: it is an actual persistent random mode in the disclosed channel, independent of the whole clean process. Its prior remains one-half after conditioning on the retained scaffold H, because H is a source-only statistic unchanged by the channel. The two source alternatives q_+ and q_- are a minimax proof device, not this channel-mode prior.

For k>=2, set h=min{k-1,floor(sqrt M)} and epsilon=1/(2h). In mode U=1 the channel independently proposes 1-to-0 substitutions at spaced candidate sites whose preceding raw pair is 11, stopping interior substitutions after h actual edits. At N-1, the same mode can flip the current bit with probability rho when its preceding raw pair is 00. N is untouched. At most h+1<=k substitutions occur on every clean word and every realization. Conditional on each fixed clean word, terminal-pair change has probability at most rho/2, hence at most rho.

Actions use the current raw bit, past raw pair, counter, mode, and public time. They do not use future clean inputs, including X_N at the endpoint decision. Thus this is current-symbol causal, not one-symbol-delayed. A 1-to-0 substitution is not a visible erasure-symbol channel. No output is retracted, no terminal rejection is used, and the channel is not normalized only after source averaging.

The eight base states encode (U,previous raw pair). The separately paid actual edit counter has k+1 values. Public horizon-indexed tables distinguish candidate times and the endpoint. A conservative charged description is

    ell=O(N*8^2*(k+1)
          *[b_rho+log(h+1)+log(N+1)+1]).

Rational probabilities, dense zeros, time expansion, destinations, integer arithmetic, table generation, and storage are paid. The channel uses h and rho, but not the source-design parameters t,d,r,q. Eight base states are not eight total states, constant total memory, a homogeneous length-independent channel, or a theorem for every S<8. Adding a clock to a homogeneous representation changes the ledger.

The source pair and channel family may vary with M,k. Stationarity applies to the clean source, not the entire augmented experiment. Rare transition/stationary probabilities may approach zero even with fixed beta. The constants and onset horizon depend on beta; beta=1 and a uniform positive transition floor are not covered by this rare-source witness. The small positive-budget cases use the earlier one-edit fallback. At k=0 only the clean identity result is invoked. For the computational upper, a positive rational rho can use the previously described paid upward dyadic certificate within a factor two; arbitrary real precision is not free.

## 3. What supplies the stronger rate

Put d=(1-beta)/64 and r=4d. The source alternatives have q_+-q_-=2d/h and a rare parameter t comparable to (h^2/M)^(1/3), with fixed small beta-dependent constants. Their clean-history KL is controlled at scale Mt^3/h^2. The retained scaffold separates the missing candidate likelihood factors. Conditional on H, the missing raw bits are independent but heterogeneous; their probabilities depend on their retained following pair. Future neighbors are used in this likelihood calculation, never in the earlier online action.

For the uncapped comparison experiment only, write p_qj=o_qj/(1+o_qj). The conditional displayed candidate vector Y has product law P_q0 with success probabilities p_qj in mode zero and P_q1 with probabilities (1-epsilon)p_qj in mode one. Its mode likelihood ratio is exactly

    Lambda_q(Y)=(1-epsilon)^(sum_j Y_j)
                   product_(j:Y_j=0)(1+epsilon o_qj).

The product identity

    1+chi2(P_q1||P_q0)=product_j(1+epsilon^2 o_qj)

keeps the two modes hard to distinguish on good scaffolds where sum_j o_+j<=h^2/64. Meanwhile the source change shifts log Lambda by a positive beta-dependent constant on a common observation region. With m_q=(P_q0+P_q1)/2 and v_q=P_q(U=1|H,Y), this yields

    J(H)=sum_Y min{m_+(Y),m_-(Y)} |v_+(Y)-v_-(Y)|
        >=J_*>0.

This is finite-horizon overlap and source-dependent mode-posterior separation. It is not exact equality of the two observation laws, an algebraic nonidentifiability theorem, or a mode-label permutation. U has fixed semantics: identity versus thinning. A generic mixture-identifiability theorem cannot be replaced by a claim that any hidden mixture is nonidentifiable.

### The actual cap is not conditional thinning

Given H,U=1, the uncapped proposed-edit count has mean at most h/128. Coupling with the actual chronological cap gives conditional mode-one output TV at most a_h=(e/128)^h. The actual capped output law is **not** the uncapped law conditioned on at most h edits. After the cap is reached, later bits are passed rather than thinned, so the product structure need not survive.

The proof first transfers J, not the final rare prediction risk. If a mode-one law changes by TV at most a while mode zero stays fixed and the prior is fair, its mixture and posterior satisfy

    ||m'-m||_1<=a,
    sum_Y m'(Y)|v'(Y)-v(Y)|<=2a.

The minimum-overlap functional therefore obeys J_cap>=J-6a_h for the two alternatives. For h above a fixed beta-dependent threshold, it remains at least J_*/2. Pointwise ordering of the capped mode posteriors is unnecessary. Coupling, product divergence, Chernoff tails, and integrated Bayesian continuity are established tools; the useful construction-specific step is this order of composition. Subtracting a_h directly from a final risk of order t would lose uniformity as t tends to zero at fixed h.

### The rare output's mass must remain in the loss

On the good terminal scaffold, B=X_(N-1) is Ber(t), independent of the candidate outputs and mode before the endpoint is observed. An endpoint edit remains available on every actual path. With T_q=rho v_q^cap and W=Z_(N-1),

    ell_q(1)=t+(1-2t)T_q,
    p_q(H,Y,1)=t+(r-t)t(1-T_q)/ell_q(1).

The full output mass includes f_q(H)m_q^cap(Y)ell_q(1). The lower uses the overlap-weighted gap

    sum_z min{P_+^Z(z),P_-^Z(z)} |p_+(z)-p_-(z)|,

which retains a factor comparable to rho*t/(rho+t), hence min{rho,t}. A large pointwise posterior gap on an unweighted rare event is insufficient. Conditional Jensen only transfers latent-row error to posterior error as an upper bound; it cannot convert a latent-target lower into this posterior lower.

The gain over the earlier sign/count construction is that thinning spends only a fraction epsilon=Theta(1/h) of the informative successes. Its edit scale is Mt^3/h=O(h), permitting Mt^3=Theta(h^2). The good-scaffold argument is uniform even when h is comparable to sqrt M and t does not vanish: terminal failure is uniformly small, not claimed to converge uniformly to zero. Combining separate clean, protected, and thinning witnesses uses their maximum, which bounds their sum up to a constant. It does not compose or add their edits.

## 4. Primary-source comparisons

### A. Persistent hidden channel modes already have a direct precedent

Yagi, Han, and Nomura, *First- and Second-Order Coding Theorems for Mixed Memoryless Channels with General Mixture*, defines a block kernel as a mixture of component kernels and studies stationary memoryless components. A once-selected component produces a stationary nonergodic mixed channel. Thus a persistent hidden channel mode is not itself new. Their target is communication epsilon-capacity, with input costs rather than this strict edit budget. The current time-indexed, raw-memory, capped components are not their memoryless components, and their theorem does not give the source-specific posterior rate here. See section II.A, equation (1), and theorem 1. [Primary manuscript, version 3, 2016](https://arxiv.org/pdf/1501.05887).

### B. Hidden product mixtures can be identifiable, including at fixed weights

Allman, Matias, and Rhodes, *Identifiability of Parameters in Latent Structure Models with Many Observed Variables*, theorem 4 and corollary 5, establish generic identifiability up to label swapping for product-Bernoulli mixtures with sufficiently many coordinates. The result remains valid with fixed positive mixture weights; for two components the sufficient coordinate count is three. This rules out the blanket explanation that a fair hidden mixture automatically destroys identification. Generic identification of the whole joint law is not a finite-horizon estimation bound from one vector or one path. Nor does a generic theorem automatically identify every restricted parameter subfamily. Here product form holds only for the uncapped conditional comparison; the actual cap introduces dependence. The proof needs overlap, not exact nonidentifiability, and does not use label switching. [Primary paper, 2009, section 5, theorem 4 and corollary 5](https://arxiv.org/pdf/0809.5032).

### C. Independent thinning is a classical primitive

Kella and Lopker, *On Binomial Thinning and Mixing*, defines thinning as independent Bernoulli survival of the members of a random count and distinguishes it from mixing a survival probability. The primitive and its product/moment identities are established, not a contribution of this candidate. The present conditionally heterogeneous Bernoulli vector, shared persistent mode, chronological cap, and terminal posterior target require further work. The paper does not supply that strict-cap prediction lower. See sections 1–2 and equation (1). [Authors' manuscript, dated September 13, 2022](https://offerkella.huji.ac.il/sites/default/files/ofer.kella/files/bino_final_review_wc2.pdf).

### D. Expected Bayes-update stability is directly relevant to cap transfer

McDonald and Yuksel, *Exponential Filter Stability via Dobrushin's Coefficient*, lemma 3.2 bounds the expected TV change of a Bayesian update by (2-delta(Q)) times prior TV, under dominated observations and absolute continuity. Theorem 3.3 and corollary 3.4 combine it with transition contraction. The coefficient delta is their overlap convention. For cap comparison, one can take the joint (U,Y) law as the prior and use the common deterministic observation Y, then project the posterior to U. This is an interpretation of their one-update principle, not a claimed cap theorem from the paper; the candidate's direct finite proof supplies its explicit constants. In contrast, the persistent U gives disjoint augmented transition classes, so delta(T)=0. Clean-source minorization alone cannot establish their sequential contraction condition. Their TV norm convention differs by a factor two from half-L1 TV, without changing the multiplicative bound. [Primary version 2, 2020, pages 7–9](https://arxiv.org/pdf/1910.08463v2).

### E. Nonmixing alone is not a general filter-instability argument

Van Handel, *Uniform Observability of Hidden Markov Models and Filter Stability for Unstable Signals*, obtains merging from uniform observability and absolute continuity of observation laws without requiring stable signal dynamics. Therefore persistent memory or failure of an augmented mixing condition does not by itself prove every filter unstable. In other models observations can learn a persistent mode. The candidate instead proves quantitatively that its modes remain difficult to distinguish on the finite-horizon region used. Van Handel's initial-law merging theorem is not a rate for unknown transition alternatives varying with the horizon. See definition 3.1, theorem 3.3, and proposition 3.5. [Primary paper, 2009](https://arxiv.org/pdf/0804.2885).

Chigansky and van Handel, *Model Robustness of Finite State Nonlinear Filtering over the Infinite Time Horizon*, theorem 1.1, controls expected squared filtering error under parameter perturbations for continuous-time finite-state signals in Brownian observations. Strictly positive initial probabilities and off-diagonal transition rates matter, and uniform constants are restricted to compact positive parameter sets. This is strong precedent for robustness to model misspecification, but not a theorem for a capped binary channel with persistent mode and rare parameters approaching a boundary. [Primary paper, theorem 1.1](https://arxiv.org/pdf/math/0604295).

### F. General posterior sensitivity does not replace weighted prediction loss

Owhadi, Scovel, and Sullivan's *Brittleness of Bayesian Inference under Finite Information in a Continuous World*, theorem 1, perturbs model classes and priors and conditions on finite-resolution observations. It is relevant precedent for posterior sensitivity, but its small-ball setting and posterior ranges are different from the current fixed fair mode prior, common channel, two fixed-source targets, and probability-weighted loss. [Primary manuscript](https://arxiv.org/pdf/1308.6306).

Sprungk's *On the Local Lipschitz Stability of Bayesian Inverse Problems*, theorem 8, gives posterior-TV stability under prior perturbation, with explicit dependence on the normalizing constant; section 6 discusses brittleness. This cautions against presenting denominator amplification or posterior continuity as a new general principle. The candidate's contribution-sensitive feature is maintaining an integrated mode gap before applying the rare endpoint factor. [Primary manuscript, 2020](https://arxiv.org/pdf/1906.07120).

### G. Causal hard-budget attacks and near-degenerate HMM limits remain the nearest surrounding models

Dey, Jaggi, Langberg, and Sarwate's *Upper Bounds on the Capacity of Binary Channels with Causal Adversaries* permits current/past input access, randomized hidden attack phases, and strict Hamming constraints. Its babble-and-push converse concerns coding, with the adversary selected after the code/decoder. It does not supply a posterior lower under a common kernel disclosed before inference. Hidden randomized state, causality, and strict budgeting therefore have direct precedents, while the target/disclosure/resource conjunction must be preserved. [Primary paper, sections II–III and theorem 1](https://arxiv.org/pdf/1204.2587).

Abraham, Gassiat, and Naulet's *Fundamental Limits for Learning Hidden Markov Model Parameters* already distinguishes identification and fixed mixing from uniform minimax learnability near degeneracy. Remark 1 permits sample-size-dependent regularity parameters with a fixed spectral-gap bound. Its parameter-estimation setting and ordinary emissions differ from the present clean-future posterior under strict edits. The candidate's horizon-varying source alternatives are legitimate minimax witnesses, but do not establish failure at one fixed infinite-stream source/channel. [Primary version 3, remark 1, theorem 1, and proposition 2](https://arxiv.org/pdf/2106.12936v3).

The earlier online audit retains the detailed comparisons with general causal AVCs, finite-state source/channel augmentation, stationary HMM identification, and symmetrizability. In particular, an AVC's finite alphabet of per-symbol controls is not a bound on its jammer's internal-memory states. Exact finite-state filtering with known source and channel also does not solve estimation when the source remains unknown. Those distinctions are unchanged by replacing count memory with U.

### H. A recent thinning-based adversarial lower is close in mechanism, not in experiment

Kim, Lee, and Yun, *A Jointly Efficient and Optimal Algorithm for Heteroskedastic Generalized Linear Bandits with Adversarial Corruptions*, uses selective Bernoulli reward flipping and Poisson thinning in its corruption-dependent lower. Its budget C=sum_t|c_t| is realized corruption, not only expectation. However, the attack targets the true optimal arm, whose identity changes across alternatives; knowledge of C is not disclosure of one common source-independent kernel. Its target is cumulative pseudo-regret, and its prior over instances is not a physical channel-mode prior. Appendix E.2 analyzes exhaustion but the inspected construction does not explicitly clip an overshooting unbounded Poisson removal. It should therefore be cited as budget-limited thinning precedent, not as a verified every-realization strict-cap implementation matching this candidate. [Primary version 1, 2026, section 1.1, section 3, appendix E.1–E.2, equations (158)–(162), and lemma 17](https://arxiv.org/html/2602.10971v1).

## 5. Bounded positioning

A supportable description is:

> A persistent hidden thinning mode realizes the sharp growing-budget posterior-prediction obstruction with one common disclosed normalized rational current-symbol-causal channel. The witness has eight base states, a separately charged edit counter, and horizon-indexed tables; its hard cap and per-clean-word endpoint budget hold exactly. Together with existing witnesses and the upper bound, it yields the matched fixed-beta rate for S>=8 in that paid interface.

Avoid claims of a first hidden-mode channel, first thinning adversary, first posterior instability, first identifiable-but-hard HMM, first product-divergence calculation, or first Bayesian normalization estimate. The source search does not certify priority or nonexistence of an equivalent result.

Also avoid the following stronger conclusions: exact observational nonidentifiability; every hidden mixture is unidentifiable; fixed homogeneous eight-total-state sufficiency; validity for every smaller state budget; contraction inherited from clean-source mixing; fixed-source inconsistency; positive-transition-floor hardness; beta-uniform constants; online/offline separation; optimal Transformer resources; training achievability; or floating-point correctness.

The bridge's simulation/implementation results remain distinct from the statistical rate. Neither this literature audit nor the construction's analytical review supplies scientific execution evidence.

## 6. Evidence binding and limits

Read in full: the current thinning candidate, its independent review, and the preceding online primary-source audit. Primary papers were inspected at the cited theorem/section locations. The earlier detailed audits were used to avoid repeating completed causal/HMM comparisons. This is a focused delta search, not an exhaustive priority review.

Input SHA-256 snapshots:

- `KNOWN_CHANNEL_online_thinning_mode_matching_lower.candidate.v1.md`: `bd616d8ae614fbd99a312a18cd6927fbaee7d05945389342d9d953904bf8c874`
- `KNOWN_CHANNEL_online_thinning_mode_matching_lower.independent_review.v1.md`: `21f387fa2fdad77ddeb4ca5ff4cebb057aa533fcf861004caba2e98f87a0dd07`
- `ONLINE_STRICT_EDIT_primary_source_audit.v1.md`: `66fcd434209f3a4a4f69564b47eecdfd000da49b5e308e30081667f07b0bec29`

The independent review's disposition is reported as existing exact-file evidence, not reissued by this source audit. All source URLs above are public primary-paper locations. No supplied research file was modified, no scientific executable verification was run, and no public write or upload was made.
