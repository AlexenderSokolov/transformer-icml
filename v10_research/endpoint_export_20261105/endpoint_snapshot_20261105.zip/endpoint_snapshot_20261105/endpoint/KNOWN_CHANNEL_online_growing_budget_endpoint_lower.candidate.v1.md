# An online growing-budget endpoint lower

5 November 2026 UTC. Pure analytical candidate, pending independent review. No scientific executable checks, public writes, or claim of the unrestricted offline exponent.

## 1. Result

Fix 0<beta<1. There are c_beta>0 and M_beta such that, for M>=M_beta, N=M+2, every integer 1<=k<=M, and every rational rho in [0,1], the normalized rational online finite-state channel subclass satisfies

    R_online,beta(M,k,rho)
        >=c_beta min{rho,(k/M)^(1/3)}.                (G1)

The risk is worst-disclosed-channel minimax expected absolute loss for the source-specific posterior target P_theta,C(X_(N+1)=1|Z). Each witness is one common known source-independent channel for two stationary binary homogeneous order-two alternatives in D2(beta). Both alternatives and the public channel family may depend on M,k. The large-budget witness below has O(N^2) base states, excluding its separately charged edit counter; its entire time-indexed rational description is paid.

Combining (G1) with the independently reviewed clean and protected-budget online witnesses gives

    R_online,beta(M,k,rho)
      >=c_beta min{1, M^(-1/2)+k/M
                          +min{rho,(k/M)^(1/3)}}.    (G2)

At k=1 this matches the known endpoint exponent. For growing k it does NOT match the larger unrestricted offline upper profile min{rho,(k^2/M)^(1/3)}. That gap remains open.

## 2. Constants, rational design parameter, and sources

Put d=(1-beta)/64 and r=4d. Choose a positive dyadic constant tau sufficiently small depending only on beta, with tau<=min{d/4,1/256}; further smallness conditions below are compatible with this choice.

For k>=2 set h=k-1. Choose a public dyadic t satisfying

    (tau/2)(h/M)^(1/3) <=t<=tau(h/M)^(1/3).          (G3)

For example, take the largest dyadic power 2^(-u) no larger than tau(h/M)^(1/3). The exponent is found using exact comparisons of integer cubes; no irrational channel coefficient is needed. With tau fixed, u=O_beta(log(M+1)). Its actual precision and table-generation work are charged.

Set

    q_-=1-d/sqrt(h), q_+=1+d/sqrt(h),
    theta_q(00)(1)=theta_q(01)(1)=t,
    theta_q(10)(1)=r, theta_q(11)(1)=q t.

The stationary law is

    Pi_q(00)=u_q,
    Pi_q(01)=Pi_q(10)=u_q t/(1-r),
    Pi_q(11)=u_q t^2/[(1-r)(1-q t)],

where u_q normalizes. These formulas and the all-state D2(beta) certificate are the same elementary rare-family identities reviewed in `KNOWN_CHANNEL_stationary_binary_rare_one_edit_lower.v1.md`. They hold uniformly because q lies in [1-d,1+d] and t<=d/4.

The alternatives q_+,q_- need not be rational: the source class does not impose rationality. They are never entries in the channel table. The public design constant t is shared by the alternatives, not selected after seeing which source generated the data.

The clean-word experiments are uniformly close. The transition part of their KL is bounded by

    C_beta d^2 M t^3/h <=C_beta d^2 tau^3.

Differentiation of the displayed stationary law gives |d log Pi_q(s)/dq|<=C_beta t. Hence the initial-law log ratios are O_beta(t/sqrt(h)), uniformly tending to zero since t/sqrt(h)<=tau M^(-1/3)h^(-1/6). Reduce tau and enlarge M_beta to obtain

    TV(P_+^(1:N),P_-^(1:N))<=1/8                 (G4)

uniformly in 1<=h<=M-1.

## 3. The online channel

Let J={j: j is divisible by 3, 3<=j<=N-5}. A candidate j is eligible when its preceding RAW pair is 11. Maintain the actual edit counter e, the last four raw bits, and two integer counters:

    n_00 = number of completed candidate patterns 11?00,
    S_00 = number of completed candidate patterns 11100.

A pattern centered at j is counted at time j+2, after its two following bits have arrived. Both counts are finalized by time N-3. Each lies in {0,...,M}; their updates never inspect future input.

The channel acts as follows:

1. At a candidate j, if the preceding raw pair is 11, x_j=1, and e<h, output zero and increment e. Otherwise output x_j. Thus it erases the first h eligible ones online.
2. At i=N-1, if the preceding raw pair is 00, e<k, and

       S_00 > floor(n_00 t),

   flip x_i with probability rho using independent auxiliary randomness. On a flip increment e; otherwise leave the bit and counter unchanged.
3. All other positions, including N, are output unchanged.

The raw-bit state is always updated from x_i, not z_i. Step 1 spends at most h=k-1 edits. Step 2 spends at most one further edit and includes an explicit counter guard. Thus every realization obeys the strict k budget, and for every fixed clean word the terminal-pair-change probability is either zero or rho. The independent endpoint coin may equivalently be sampled initially and kept hidden. There is no terminal acceptance/rejection factor or conditioning of the channel law.

The condition S_00>floor(n_00 t) can be precomputed for every count-state pair using the fixed dyadic t. It is an online terminal decision: all its inputs are known by N-3. In particular neither this decision nor the past00 gate reads X_N.

## 4. Finite-state and rational description accounting

One explicit base-state space has at most

    S_ch=16(M+1)^2

states: four raw bits and the two counts. The separately charged edit counter has k+1 values. Initialize to the all-zero raw memory and zero counts. Ignore pattern completions whose center is not in J, so padding before time 1 has no effect. Counts may be defined to saturate at M in arbitrary unused table rows; on every actual raw history they are exact.

Every transition row is deterministic except the endpoint coin, whose two probabilities are rho and 1-rho. Thus every row is normalized and rational. For rho=a/b let b_rho be the actual numerator/denominator bit cost. A conservative fully expanded dense time-indexed description has

    ell=O(N S_ch^2(k+1)[b_rho+u+log(N+1)+1])

bits, plus fixed public design data. This intentionally loose ledger charges zero entries, next-state encoding, rational precision, time expansion, threshold comparisons and generation work; a sparse deterministic-successor encoding can be smaller. The comparison table can be generated in polynomial time in these paid quantities.

This is a public-horizon-dependent finite-state family, not a single fixed-state or length-independent homogeneous transducer. The large-budget lower makes no constant-state claim. Only raw displayed symbols are observed; raw counts, state, edit mask and auxiliary coin are hidden.

## 5. Recoverable scaffold and exact hidden-bit law

Use the scaffold H from `KNOWN_CHANNEL_online_one_edit_lower.candidate.v1.md`: retain all raw coordinates except B=X_(N-1) and eligible candidate bits, with their missing positions marked. Eligibility is recoverable from the untouched preceding noncandidate positions. H is unchanged and recoverable from Z. Ineligible candidate bits remain in H.

No order-two likelihood factor contains two missing candidate bits, nor both a missing candidate bit and B. Conditional on H, all missing candidate bits are independent and independent of B. Their odds, according to the retained following pair (a,b), are

    o_q(0,0)=q t/(1-t),
    o_q(0,1)=q r/(1-r),
    o_q(1,0)=q^2 t^2/[r(1-t)],
    o_q(1,1)=q^3 t^2/[r(1-q t)].                   (G5)

Let S_all be their total clean-one count and L_q=sum_j o_q(j). Every odds is increasing in q. The raw S_00 tracked by the channel is exactly the sum over the n_00 missing sites whose following pair is 00. Consequently

    S_00 | H ~ Binomial(n_00,p_q),
    p_q=q t/[1+(q-1)t].                           (G6)

The observable event that all eligible candidate outputs are zero is exactly

    C={S_all<=h}.                                 (G7)

Indeed the first h eligible ones are erased, and every later eligible one remains visible. Thus outside-C inputs cannot collide with these branch outputs. On C the eligible output is the unique all-zero configuration.

## 6. Good scaffolds and conditional cap probability

Let

    A={X_(N-3)=X_(N-2)=X_N=0},
    T={M t^2/4<=n_00<=M t^2/2},
    D=A intersect T intersect {L_+<=h/64}.         (G8)

All these events are H-measurable and are used only in the proof, never as offline channel gates.

The exact stationary probability of a candidate's 11?00 pattern is u_q t^2[1+(q-1)t]. Here r<=1/16, d<=1/64 and t<=1/256 imply u_q>=1-3t. Also |J|/M lies between 1/3-2/M and 1/3. Thus, for M>=64, the mean count divided by M t^2 lies in [9/32,11/32], uniformly in h and q. In particular it stays strictly inside (1/4,1/2); no assertion that t vanishes uniformly in h is needed. The common geometric D2(beta) mixing bound gives

    Var_q(n_00)<=C_beta M t^2.

The same rare-window covariance proof as in the reviewed one-edit construction applies. Since M t^2>=(tau^2/4)M^(1/3), P_q(T^c) tends uniformly to zero. The explicit stationary law bounds the minority mass by 2t, so P_q(A^c)<=6tau<=1/32. This is a uniform bound obtained by choosing tau small, not a claim that P_q(A) tends to one when h is comparable to M.

As in the one-edit calculation, o_+/o_q<=2 and o_q<=1/8 for either source. Writing p_q(j)=o_q(j)/(1+o_q(j)) gives o_+(j)<=4p_q(j). Therefore

    E_q L_+<=4 E_q S_all
       =4 |J| Pi_q(11) q t
       <=4 M t^3<=4 tau^3 h.

Markov's inequality gives P_q(L_+>h/64)<=256tau^3. Reducing tau and enlarging M_beta, we can arrange P_q(D)>=7/8. Writing f_q for the scaffold law, data processing from (G4) gives

    sum_{H in D} min{f_+(H),f_-(H)}>=3/4.         (G9)

On every H in D, the total conditional hidden mean satisfies

    E_q(S_all | H)=sum_j p_q(j)<=L_q<=L_+<=h/64.

The Chernoff bound for a sum of independent, nonidentical Bernoulli bits consequently gives, under both sources,

    P_q(C^c | H)<=epsilon_h:=(e/64)^h.             (G10)

Here e is Euler's constant, not the edit-counter variable. In particular g_q(H):=P_q(C|H)>=1-epsilon_h.

## 7. Uniform hidden-sign separation

On T put mu=n_00 t and c=floor(mu). From (G3),

    a h<=mu<=b h,
    a=tau^3/32, b=tau^3/2.

The elementary binomial sign lemma in `KNOWN_CHANNEL_online_binomial_sign_lemma.candidate.v1.md` states that, for mu>=16,

    P_+(S_00>c | H)-P_-(S_00>c | H)
        >=delta_*:=d sqrt(a)/(8e)>0.              (G11)

For reference its proof differentiates the binomial tail exactly:

    d/dq P(Bin(n,p_q)>c)
       =n p'_q P(Bin(n-1,p_q)=c).

Throughout q in [1-d/sqrt(h),1+d/sqrt(h)], elementary Stirling bounds give the local mass at least 1/(4e sqrt(mu)), while p'_q>=3t/4. Integrating the interval of length 2d/sqrt(h) gives a lower of 3d sqrt(a)/(8e), so (G11) is conservative.

Let A_sign=1{S_00>c}, exactly the terminal selection bit used by the channel, and

    v_q(H)=E_q[A_sign | H,C].

For any [0,1]-valued variable, conditioning on an event changes its expectation by at most the probability of the complement. This follows immediately by writing the unconditional expectation as a mixture on the event and its complement. Thus (G10)-(G11) imply

    v_+(H)-v_-(H)>=delta_*-2epsilon_h.             (G12)

Choose the finite beta-dependent integer

    H_beta=ceil(max{16/a,
             log(4/delta_*)/log(64/e), 1}).

For h>=H_beta, equations (G10)-(G12) give

    g_q(H)>=1/2, v_+(H)-v_-(H)>=delta_*/2=:v_*>0. (G13)

The cap analysis uses the total hidden mean, not just the n_00 subset. It does not incorrectly replace the heterogeneous conditional bits by identical Bernoulli bits.

## 8. The exact terminal posterior and rare-output mass

On A, B|H is exactly Ber(t), independently of the hidden candidate bits, and the future-row probability is t+(r-t)B. On C the hidden selection bit has probability v_q(H). The prefix00 gate is automatically satisfied, and the interior edit count is at most h, so one endpoint edit remains available. Consequently, writing W=Z_(N-1),

    T_q=rho v_q,
    ell_q(1)=P_q(W=1 | H,C)=t+(1-2t)T_q,
    p_q(H,1)=P_q(X_(N+1)=1 | Z)
       =t+(r-t) t(1-T_q)/ell_q(1).               (G14)

The branch output mass is exactly f_q(H)g_q(H)ell_q(1). These are posterior targets formed under each fixed source, with no prior mixture over q. The final raw X_N=0 enters only the analysis of these outputs; it was never read before acting on B.

Exact subtraction, followed by multiplication by the minimum output mass, yields on D and h>=H_beta

    min{P_+^Z(z),P_-^Z(z)} |p_+(z)-p_-(z)|
      >=min{f_+(H),f_-(H)} (r v_*/8)
                                      rho t/(rho+t). (G15)

Here we used g_q>=1/2, r-t>=r/2, 1-t>=1/2 and ell_q(1)<=t+rho. Retaining the rare displayed W=1 probability is essential.

The two-source absolute-loss inequality, summed over these outputs and combined with (G9), gives

    max_q Risk_q(Q)>=(3 r v_*/64) rho t/(rho+t)
                     >=c_beta min{rho,t}.         (G16)

This calculation also holds at rho=0, when its lower is zero. All conditional denominators are positive because t>0.

## 9. Small budgets, scaling and limitations

For h=k-1>=H_beta, h>=k/2 and (G3) give t>=c_beta(k/M)^(1/3), so (G16) proves (G1).

For 1<=k<=H_beta, use the independently reviewed one-edit online witness, which gives c_beta min{rho,M^(-1/3)}. Since k is bounded by the beta-dependent constant H_beta,

    min{rho,(k/M)^(1/3)}
      <=H_beta^(1/3) min{rho,M^(-1/3)}.

Absorb this fixed factor into the constant. Together the two cases cover every k>=1. At k=0 this witness is not invoked and the clean rate applies.

To obtain (G2), take the maximum of this endpoint lower, the identity clean lower, and the separately reviewed protected k/M lower. The maximum is at least one third of their sum. This chooses one witness; it does not add the edit budgets of distinct channels.

The result depends on fixed beta<1. The source alternatives vary with horizon and their rare transition entries may vanish. It is not a single fixed-source asymptotic lower, a positive-transition-floor theorem, a beta-uniform statement, a constant-state growing-budget theorem, or a resource-optimal Transformer claim. Most importantly, it establishes the online exponent k^(1/3)M^(-1/3), not the unrestricted offline exponent k^(2/3)M^(-1/3).
