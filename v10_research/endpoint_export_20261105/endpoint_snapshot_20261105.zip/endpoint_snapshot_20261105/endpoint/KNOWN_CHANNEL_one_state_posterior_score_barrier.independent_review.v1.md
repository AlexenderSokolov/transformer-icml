# Independent review: latent-posterior and missing-score barrier at S=1

Review time: 2026-11-05 10:11:19 UTC.

## Decision and exact binding

**PASS as a method barrier, not a predictive minimax lower.** I fully read and independently checked:

- `KNOWN_CHANNEL_one_state_posterior_score_barrier.candidate.v1.md`
- SHA-256: `cf9b44e015f0998faede6e4b3200a932e102d92c060c1eaec1e365dddc36145e`.

The candidate validly rules out the two stated uniform shortcuts: an expected full-clean-history posterior-TV bound of order `k/sqrt(M)` for its raw-KL-close alternatives, and a missing-complete-source-information bound `C_beta k^2 I_step`. It also rules out the displayed bounded-mode derivative estimate. The same example has exactly protected prediction target `a+r z_N`; the latent conclusions do not transfer to a predictive lower or a one-state separation.

The construction is imported from the independently reviewed rare-source lower:

- `KNOWN_CHANNEL_one_state_rare_rho_lower.candidate.v1.md`: `d784c6abdc1eaaae97dc5dcdd8fab478f05ea387b40c8e634b452345749503cb`.
- `KNOWN_CHANNEL_one_state_rare_rho_lower.independent_review.v1.md`: `bff649fd9911b2b179b2eb445a7f4a3ecea78016897aad07aff3d1356c6e3216`.

These are present-byte bindings, without a historical digest inference. Original artifacts remain unchanged.

## 1. Valid experiment and fixed-channel differentiation

For integer `H_beta<=h<=sqrt(M)`, choosing `k=h+2` recovers exactly the prior construction's interior cap h once M is sufficiently large. Its public dyadic scale at rho=0 satisfies `t` comparable to `tau h/sqrt(M)`. The first-one activation and at most h subsequent erasures are real counted changes. With rho set to zero, both terminal coordinates are untouched. There is still one base state, a separately charged actual edit counter, and a paid time-indexed table.

The complete kernel, L, epsilon, t and the deterministic time schedule are held fixed while varying the unknown source parameter a. This qualification is explicit and essential: differentiating the design rule for epsilon or L along with the source would give a different statistical experiment and invalidate the score identity. The candidate does not do that.

The source remains stationary first-order, hence lies in the at-most-second-order D2(beta) class. Its complete word law is positive for all a in a neighborhood of t. The common channel's zero entries do not change with a, so both output support and the joint support relevant to differentiation are parameter-independent.

The initial stationary marginal also depends on a. Its Bernoulli KL is `O(delta^2/t)`, while the transition contribution is `O(M delta^2/t)`. With `delta=d sqrt(t/M)`, their sum is bounded by a constant times `d^2`. Thus the raw stationary alternatives are genuinely KL-close, not just their fixed-start tails. A fixed positive d can be chosen as small as desired; no claim of zero divergence is needed to refute a uniform rate in M.

## 2. Full observation and latent posterior discrepancy

The mode U is a parameter-independent function of the raw prefix: whether it contains any one. It is not an artificial source-independent latent coin. On the all-zero displayed prefix, its exact prior is the reviewed, source-dependent `R_a/(1+R_a)`, and the raw tail is independent of U conditional on the protected zero anchor.

The previous signed-count argument supplies the overlap-weighted mode gap before the endpoint is used. In the present rho=0 channel, the final raw bit is observed. This does not invalidate that gap: conditional on the scaffold, the final bit is independent of both U and the candidate vector for each source and for every nearby a. Consequently the mode posterior is the same after the actual full final observation is included.

On the retained good scaffolds, the final bit is Bernoulli a. Its two-source overlap is exactly `1-2delta`. Multiplying this overlap with the prefix, scaffold and candidate minimum-mass factors yields (B4). The proof therefore integrates over the actual complete output, rather than a deliberately coarsened observation that hides an otherwise available bit.

Since total variation of two clean-word posteriors dominates the difference in their probability of the same event `{U=1}`, (B4) implies both the minimum-output-mass lower and the minus-output expected lower in (B5). All source laws have the same possible output support, so the plus posterior is defined on the minus experiment's observations.

For fixed h and k=h+2, t is of order `M^(-1/2)`. The resulting latent posterior-TV lower is of order `M^(-1/4)`, not `M^(-1/2)`. The fixed raw-KL radius may be chosen arbitrarily small beforehand. Thus no constant depending only on beta can give the proposed `O_beta(k/sqrt(M))` conclusion under those assumptions. This is a comparison of source-specific latent posteriors, not an estimation-risk lower by itself.

## 3. Reconstructing the infinitesimal signed-count step

The single-source version of the prior proof is valid at the central parameter a=t. Its good-set expectations, actual-count mean, second moment and mode-overlap estimates are uniform for a in the previously allowed interval. At the central parameter no two-source minimum-mixture subtraction is necessary. The same cap and overlap estimates give a positive weighted signed expectation on `E_0 intersect {G_t>=0}`, with fixed alpha included in the constant.

The capped likelihood is a finite positive polynomial in the conditional odds, with coefficients depending on the fixed channel but not a. Differentiating its logarithm therefore gives exactly the posterior expectation of the sum of erased-site log-odds derivatives in (B8). This remains the actual capped law; it is not an uncapped experiment conditioned on its proposal count.

The 00 derivative is at least `1/(2t)`, the 11 derivative at least `-2/t`, and both mixed-neighbor derivatives are nonnegative. Hence the derivative is at least `G_t/(2t)`. The prefix log-prior odds increase with a. On the selected nonnegative-score outputs the posterior odds remain uniformly interior, so the logistic derivative supplies (B9).

The selected sets and their probability weights are used only to lower-bound the integral at a=t. They are not differentiated. Integrating the pointwise derivative with the actual central mixture, good-scaffold probability and prefix mass yields (B11). The unchanged final bit can again be integrated out because the formula for the mode posterior is independent of its value for every nearby a, not merely at the central point.

## 4. Complete score, covariance and missing information

For the complete stationary source score `S_a=d log P_a(X_1:N)/da`, source independence of the fixed channel gives

`d v_a(z)/da = Cov_a(U,S_a(X)|Z=z)`.

This identity does not assume that the actual counter or U is independent of the raw word. Their dependence is precisely why the conditional covariance can be large. Differentiation is legitimate term by term in finite positive source sums on a parameter-independent channel support.

Conditional Cauchy-Schwarz gives `|v'_a(z)|^2 <= Var(U|Z=z) Var(S_a|Z=z)`. Since the mode is binary, its conditional variance is at most 1/4. Taking expectations and then Jensen yields exactly

`E Var(S_t|Z) >= 4 E |v'_t|^2 >= 4(E |v'_t|)^2`.

Together with (B11), this proves the missing-information lower `c_beta h^2/t^2`. The observed score is `E[S_a|Z]`, so the conditional-variance quantity equals complete Fisher information minus observed Fisher information by total variance.

The candidate correctly identifies this as **missing complete-source information**. It need not equal the conditional Fisher information of the single binary mode. The latter is `E[(v'_a)^2/(v_a(1-v_a))]` on its nondegenerate support and is bounded above by missing complete-source information. Both can be large here, but their equality is not assumed or required.

## 5. Source Fisher scale and data-processing check

The stationary one-transition information is exactly

`pi_a(0)/[a(1-a)] + pi_a(1)/[(a+r)(1-a-r)]`.

It is comparable to `1/a` for fixed r and small a. The stationary initial-bit information is exactly `1/[a(1-r-a)]`. The complete word information is the initial term plus `(N-1)I_step`: transition scores are martingale differences and are orthogonal to the initial score and to each other. Thus the parameter dependence of the stationary law has been included, not suppressed.

For fixed h and k=h+2, the ratio of the missing-information lower to `k^2 I_step(t)` grows like `h^2/(k^2 t)`, which diverges. Replacing k squared by k cannot rescue the proposed inequality. Similarly, (B11) divided by `k sqrt(I_step(t))` diverges like `t^(-1/2)` for this fixed-h sequence.

There is no conflict with information data processing. In that same sequence, the proved missing-information lower has order M, whereas the complete source information has order `M/t`, namely `M^(3/2)`. The candidate does not claim missing information exceeding total source information, nor an equality giving its exact scale.

## 6. Why this is not a predictive lower

Because the endpoint is exactly protected, the last source bit is observed. For every possible output,

`P_a(X_(N+1)=1 | Z=z) = a+r z_N`.

This identity holds for the full actual channel, regardless of its complicated prefix posterior. The two predictive targets differ exactly by `2delta`, of order `M^(-3/4)` for fixed h. Their derivative with respect to a is exactly one.

Equivalently, the hidden-history transition-row value is already measurable with respect to Z. Its conditional covariance with the complete score is zero; only its direct parameter derivative survives. Large internal mode sensitivity or full-history posterior TV therefore supplies no predictive lower of the larger latent scale.

This counterexample invalidates the displayed uniform shortcuts, not every possible score-based proof. Endpoint-weighted covariance or target-specific arguments are explicitly left available. It does not establish a sharp general S=1 upper, a new minimax lower, a base-state separation, a computational obstruction or an impossibility of learning the predictive target.

## Scope and method

The proof is for fixed `0<beta<1`, the permitted large-horizon family, rational disclosed time-indexed channels, and separately paid actual counter memory. It uses a source sequence with vanishing transition probabilities and does not contradict the fixed-positive-floor results. First-order sources are included as a special case of the order-two class.

Only analytical reconstruction, private file inspection, hashing and this review artifact were used. No scientific executable checks, numerical experiments, simulations, model runs, public writes, training claims, finite-precision claims or external novelty certification.
