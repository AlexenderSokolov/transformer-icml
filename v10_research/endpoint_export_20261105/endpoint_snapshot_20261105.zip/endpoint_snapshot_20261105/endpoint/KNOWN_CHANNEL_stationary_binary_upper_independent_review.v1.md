# Independent analytical review: stationary binary known-channel upper

Date: 2026-11-05 UTC.

## Finding

The argument in `KNOWN_CHANNEL_stationary_binary_upper.md`, including the explicit finite-parameter bound (B11), is valid within its stated stationary binary, positive fixed-beta scope. I found no counterexample or substantive proof gap. In particular, it proves uniform consistency when k=o(sqrt(M)) for arbitrary disclosed, future-blind strict-k-Hamming-edit channels.

This is an independent mathematical review, not formal verification or external peer review. I inspected the completed candidate and the local source-model, row-estimation, and known-channel lower-bound documents. No scientific program, numerical experiment, public write, or external novelty search was performed for this review.

One editorial clarification was requested: state 0<beta<=1 explicitly. The source minorization itself forces beta<=1 whenever the class is nonempty. A second optional clarification is to explain that the small-error hypothesis in section 2 ensures the fitted transition coordinates are at least eta/2 even before invoking the estimator's clipping rule.

## 1. Source implications and the rare-row issue

This is genuinely a second-order binary result. The pair kernel is P((a,b),(b,c))=theta_ab(c), with the all-state condition P^2(s,t)>=beta Pi(t). Summing over the second coordinate of the target pair gives theta_u(c)>=beta pi(c). Stationarity then gives

    Pi(a,b)=sum_c Pi(c,a) theta_ca(b)>=beta pi(a)pi(b).

Therefore, when the stationary minority mass is at least a, all transition coordinates are at least eta=beta a and all stationary initial-pair masses are at least beta a^2. There is no unexamined rare pair context in this branch. The all-state quantifier also covers states outside stationary support when the minority is zero, although those sources are handled by the majority fallback rather than a likelihood ratio.

P^2 has Dobrushin contraction at most 1-beta. Hence the covariance series for a bounded symbol coordinate is summable uniformly over this source class for fixed beta. The displayed loose variance bound Var(b)<=5/(beta M) is sufficient and correct.

## 2. Simultaneous robust row estimate

I checked the imported proof in `EDIT_OVERLAP_and_TARGET_BOUNDARIES.md`, section 5, rather than treating it as an unexplained fixed-eta black box.

For pair states sampled at end times 4,6,..., each named pair has conditional probability at least eta^2. The adapted exponential-moment argument does not require independent pair samples. Since the number of samples is at least M/4, all four clean row counts are at least eta^2 M/8 except with probability at most 4 exp(-eta^2 M/32).

For each fixed row, its successor-count error around theta times its count is a martingale sum with second moment at most M. Summing the four expected absolute numerators gives 4 sqrt(M). On the simultaneous occupation event, add-one smoothing therefore contributes at most

    32/(eta^2 sqrt(M))+32/(eta^2 M).

The shared-count raw-edit inequality adds at most 3k/(J+2), hence at most 24k/(eta^2 M) there. The bad event contributes at most its probability. This proves (B7) with the displayed constants. Clipping the binary row coordinate to [eta/2,1-eta/2] cannot increase error against a true coordinate in [eta,1-eta].

Every estimate is based only on the observed word. Clean counts and the actual edit set are proof variables, not hidden inputs to the estimator. The expectation bound is uniform over fully history-adaptive channels because the count perturbation bound is pathwise.

## 3. Stationary initialization perturbation

The clipped fitted pair kernel has a strictly positive two-step kernel, so its stationary pair law is unique and positive.

For any such fitted law, stationarity of both laws and contraction by the true P^2 give

    TV(Pi_hat,Pi)
      <= TV(Pi_hat P_hat^2,Pi_hat P^2)
          +TV(Pi_hat P^2,Pi P^2)
      <=2 epsilon+(1-beta)TV(Pi_hat,Pi).

Thus TV(Pi_hat,Pi)<=2 epsilon/beta. This argument uses contraction of the true kernel only; it does not silently require the estimated kernel to satisfy the same D2 certificate.

If epsilon<=beta^2 a^2/8, each initial-pair relative error is at most 1/4. The stated initial logarithm bound 4 epsilon/(beta^2 a^2) follows. Also epsilon<=eta^2/8<=eta/2, so fitted row coordinates are at least eta/2 and their logarithmic ratios are bounded by 2 epsilon/eta.

## 4. Arbitrary known-channel posterior comparison

This is the main potentially delicate step, and it checks out.

For a fixed output z, every two latent input words in the support of C(z|.) have Hamming distance at most 2k. They therefore differ in at most 6k historical triple positions. Identical triple factors cancel from the difference of the two log likelihood ratios. The initial pair contributes at most 8 epsilon/(beta^2 a^2), and the changing triples contribute at most 24k epsilon/(beta a). This is (B5).

The same known kernel C is used in both posterior calculations, so its factors cancel. No locality, positivity lower bound, independence across edits, or obliviousness of C is needed. The source and fitted clean-word laws are positive in this branch. Thus every possible true observation has a positive fitted posterior denominator, including outputs whose probability is extremely small.

If the likelihood-ratio oscillation on the fiber is at most L, normalizing it changes it by a factor lying between its minimum and maximum. The fitted posterior therefore dominates exp(-L) times the true posterior. Their TV distance is at most 1-exp(-L)<=L. Averaging the next-row distributions adds at most epsilon.

The fitted table can depend on z. The entire statement is deterministic after fixing z, so there is no invalid use of an independent plug-in parameter estimate or a conditional-risk theorem. Integrating the pointwise bound is legitimate.

When epsilon exceeds the small-error threshold, the unit-loss bound is at most 8 epsilon/(beta^2 a^2). Combining the two cases gives exactly the advertised D=9/(beta^2 a^2)+24k/(beta a).

Future blindness is necessary for identifying the target with a posterior average of the true terminal row. This condition is explicitly retained.

## 5. Threshold and rare-source cases

Let D_freq be the event that the corrupted empirical symbol frequency differs from pi(1) by at least a. Under k/M<=a/2, the pathwise frequency perturbation and Chebyshev imply P(D_freq)<=20/(beta M a^2).

- If the true minority mass m<a, selecting the plug-in branch implies D_freq. On the majority branch, choosing the wrong majority also implies D_freq. The expected loss of predicting the true majority on any observation-selected subset is at most its unconditional loss m.
- If a<=m<=4a, the global plug-in bound is valid. The correct-majority contribution is at most m<=4a, and the wrong-majority event is contained in D_freq.
- If m>4a, selecting the majority branch requires D_freq: the minimum-frequency map is 1-Lipschitz and the branch threshold is 2a. The plug-in contribution is again bounded by the unrestricted expectation D B.

These are integrated-risk arguments. They do not assume that the future marginal or source law is unchanged after conditioning on the branch. Consequently the conservative bound 4a+40/(beta M a^2)+D B is valid uniformly, including degenerate stationary sources.

## 6. Optimized rate and scope

With a=max{M^(-1/10),(k/sqrt(M))^(1/4)}, whenever a<=1/16 one has k<=sqrt(M), k/M<=a/2, and

    M^(-1/2) a^(-4)<=a,
    (k/sqrt(M)) a^(-3)<=a.

The remaining algebraic terms in D B are absorbed by these terms because (k+1)/M<=2/sqrt(M). The frequency tail is also smaller than a. The exponential remainder is bounded by C_beta a uniformly: eta^2 M>=beta^2 M^(4/5), and any fixed polynomial factor is absorbed by this exponential. If a>1/16, the unit bound supplies the stated rate after increasing the constant. Thus (B1) follows.

This is a deliberately loose asymptotic bound. Its cap can make it vacuous at realistic finite horizons, and the exponent 1/10 is not established as optimal. The result does not supply:

- a stationary binary lower or a sharp threshold at k of order sqrt(M);
- a moving-beta or beta=0 consistency theorem;
- an arbitrary-initial-law extension;
- a ternary result;
- efficient, finite-rational, or neural implementation of the posterior calculation;
- external novelty certification.

The stationary K>=4 and binary arbitrary-start one-edit lower bounds do not contradict this result. Their mechanisms respectively retain a nontrivial predictive coordinate alongside rare nuisance mass, or hide the initial law, neither of which survives this proof's stationary binary assumptions.

## Inspected local sources

- `KNOWN_CHANNEL_stationary_binary_upper.md`: complete new candidate, equations (B1)-(B11).
- `EDIT_OVERLAP_and_TARGET_BOUNDARIES.md`: row perturbation and complete simultaneous-row bound.
- `EPR001_endpoint_probability_interpolation.md`: D2, strict Hamming budget, source/channel quantifiers.
- `POSTERIOR_PREDICTION_channel_identifiability.md`: fixed-source posterior target and future blindness.
- `KNOWN_CHANNEL_one_edit_lower.md`: comparison with stationary K>=4 and binary arbitrary-start boundaries.
- `KNOWN_CHANNEL_posterior_counterexample.md`: earlier K>=5 sqrt(M)-budget lower; not a stationary binary lower.
