# Independent review: endpoint-weighted actual-edit window

Review time: 2026-11-05 12:34:53 UTC.

Disposition: **PASS for the corrected same-preimage endpoint-weighted Palm bound.** This is not an upper bound for unrestricted one-state prediction, and it does not control crossed posterior preimages.

## Exact binding and correction

The entire corrected addendum was independently read and hashed:

- `KNOWN_CHANNEL_one_edit_hazard_endpoint_weight.addendum.v1.md`
- SHA-256: `5f8a517adbd89a4067f27a95e772f8f9dea3595b2a6752c1bb691ee4e552b479`

Its underlying hazard note remains:

- `KNOWN_CHANNEL_one_edit_hazard_reduction.research.v1.md`
- SHA-256: `e649e40991eb9eccf2917b1e028950dd4a6ced0bd441c13722d827dd9abf7d52`

The independent review of that note has SHA-256 `21203139a715ea62c95bafa4e2576c9a100597539166cdab2ad08f5831327616`.

An earlier addendum reading exposed a genuine boundary-proof omission: when r=s=0 and i=N, conditioning on the continuation X_(i-r):N reveals only X_N, whereas g_N can also depend on X_(N-1). Consequently its claimed continuation-measurability argument could not be applied at that index. The author has now excluded that index from (E2), bounded its contribution directly, and charged it to the d=0 geometric term. This resolves the omission with no increase in the stated constant. Approval here binds only the corrected hash above, not the earlier addendum bytes.

## Approved statement

Let c_* be a minority symbol with m=pi(c_*), let g_N(X)=theta_(X_(N-1),X_N)(c_*), and let W_i be a raw local window of length r+s+1 around i. For its center symbol c with pi(c)>0,

    E[g_N(X) 1{r+1<=J<=N-s, W_J=w}]
       <= [C_(beta,r) m/pi(c)+2/beta] P(W=w)
       <= [C_(beta,r)+2/beta] P(W=w),

where C_(beta,r)=exp[(beta/2)(r+2)]/(beta/2), and J is the actual first and only edit time. No endpoint-reliability parameter rho is required. The conclusion concerns the same raw path for J, W_J, and g_N.

## 1. Survival with the endpoint weight

Except at the explicitly excluded singleton terminal index, the continuation from i-r through N contains both terminal coordinates. The endpoint row g_N and the local-window indicator are therefore measurable with respect to that continuation.

Conditional on a complete positive-probability continuation, reverse-pair Markov structure leaves the same backward kernel before its boundary pair. The survival argument of H7 is uniform in the initial boundary law and remains valid when the future conditioning is a long continuation rather than a fixed-length window. The retained early hazards still start at least two reverse steps before that pair. Their bound is independent of the continuation value.

Multiplying this conditional bound by the nonnegative continuation-measurable g_N 1{W_i=w} and averaging is valid. Since a_i(X_i)=a_i(c) on the window event, this gives precisely (E2). It does not require independence of the edit time, local window, and terminal row.

## 2. Forward mixing of the future minority probability

Put t=i+s, the final coordinate of the local window. Conditional on the pair ending at t, the source after t follows the same forward pair kernel. The local window contains no later information, so conditioning on it only fixes or mixes that boundary pair.

The function g_N is in [0,1], and its stationary mean is m. The two-step Doeblin minorization gives total-variation contraction at most (1-beta)^floor((N-t)/2) after N-t pair transitions. Therefore

    E[g_N | W_i=w] <= m+(1-beta)^floor((N-t)/2).

This is an absolute mixing bound, not a relative bound divided by the window's probability. Arbitrarily rare windows are permitted. If the window is a single symbol, the missing coordinate of the boundary pair is averaged over. At t=1 a two-sided stationary extension supplies a preceding bit for this analytical conditioning; it is not information available to the channel or estimator. Such an extension exists for the stationary finite-state source. Zero-probability windows have zero contribution and need no conditional distribution.

## 3. Summation and the exact constant

The stationary part m of the preceding bound is summed by the already reviewed hazard integral comparison, giving C_(beta,r) m P(W=w)/pi(c). Omitting the exceptional index from this sum can only decrease it.

For the mixing remainder, discarding the hazard and survival factors is legitimate because each is at most one. As i ranges over its allowed deterministic positions, d=N-i-s ranges over a subset of nonnegative integers without repetition. Hence

    sum_(d>=0) (1-beta)^floor(d/2) = 2/beta.

When r=s=0 and i=N is the excluded index, its actual contribution is at most P(X_N=w), because both g_N and the edit indicator are at most one. The remaining distances are d>=1, whose geometric sum is 2/beta-1. Thus the special index consumes exactly the previously reserved d=0 unit and the coefficient remains 2/beta.

Finally, binary minority status gives m<=pi(c), proving the rightmost bound. If pi(c)=0, the window and actual edit event have probability zero. The case m=0 is also harmless. The constant's dependence on r but not s is consistent with the reverse survival gap and the forward geometric sum.

## 4. What this does not establish

The bound genuinely removes the inverse central-marginal factor after weighting by the future minority probability of the same actual raw preimage. It is uniform in the horizon and time-dependent legal one-state hazards.

It does not apply when an early edit index from one preimage is paired with a local pattern or future-row probability evaluated in another preimage. In particular, it does not control the rare displayed-111 versus raw-101 crossed term in H4. Those terms require the actual competing likelihood weights and the full observation denominator. No predictive minimax conclusion, root-M estimator, full-score bound, or state separation follows from this addendum alone.

## Preservation and activity

This was a mathematical audit using file reads and SHA-256 integrity checks only. No scientific executable test, numerical experiment, simulation, public write, or external disclosure was performed. The reviewer did not edit either source file. This review makes no historical hash inference and no computational, transformer, floating-point, training, or novelty claim.
