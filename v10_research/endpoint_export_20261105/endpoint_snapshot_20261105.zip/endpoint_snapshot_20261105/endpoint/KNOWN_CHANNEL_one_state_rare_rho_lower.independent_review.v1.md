# Independent analytical review: rare-source one-state rho lower

Review time: 2026-11-05 09:56:24 UTC.

## Decision and exact binding

**PASS as a statistical lower, with the stated fixed-beta, large-horizon and paid-channel qualifications.** I fully read and independently reconstructed the candidate:

- `KNOWN_CHANNEL_one_state_rare_rho_lower.candidate.v1.md`
- SHA-256: `d784c6abdc1eaaae97dc5dcdd8fab478f05ea387b40c8e634b452345749503cb`.

For `b=min{1,k/sqrt(M)}`, its additional endpoint lower is of order

`min{rho sqrt(b), b sqrt(rho)}`.

Combining separate clean and protected witnesses gives (R1). This does not match the general no-fixed-floor S=1 upper in the principal sub-square-root-budget regime, does not prove a state separation or minimality, and does not alter the fixed-positive-floor theorem.

The hash was independently computed for the present read. No historical hash inference is made. The original candidate and preceding proof files remain unchanged.

## 1. Constants, horizon-uniform scales and source class

The constants can be chosen without a circular dependency. First choose the absolute good-set constant K. Then choose r sufficiently small for the adverse-count fraction and with `r<1-beta`. Choose a fixed dyadic tau with `tau<=r^4/100`. Fix the required overlap tolerance zeta using the positive count coefficient and K, then take alpha sufficiently small for the count and overlap estimates. Choose d after these constants; finally take a finite count threshold H_beta and a sufficiently large horizon. The positive count coefficient can be fixed below the isolated-one lower bound before selecting the final alpha, so the zeta/alpha choice is not circular.

The integer ceiling in `B_M=ceil(sqrt(M))` makes the public scale rational. Because `t>=tau h/(2B_M)`, one has `L/M<=2B_M/(tau h M)` and `Mt>=tau h M/(2B_M)`. Uniformly for h>=1, the prefix occupies a vanishing fraction of the word, `Mt` diverges, and `delta/t=d/sqrt(Mt)` tends to zero. Thus the same sufficiently large horizon controls both alternatives for all allowed k and rational rho, including rho arbitrarily close to zero.

For `P_a(1|x)=a+rx`, the stationary law in the candidate is correct, and the minimum of the transition/stationary-marginal ratio is exactly `1-r`. The pair-chain identity therefore verifies the all-state D2(beta) condition. The complete sources are stationary first-order sources, hence belong to the at-most-second-order class. Only their conditioned tails begin from a fixed zero.

The fixed-start tail KL bound follows directly from the transition chain rule and the Bernoulli bound: both alternatives have probabilities of order t in the zero-predecessor row and are separated by `2delta`; the other row is bounded below by r. The initial tail symbol is identical, so no stationary-initial-law error is silently discarded. Choosing d small supplies the raw-tail and scaffold overlap.

There is no uniform transition floor in this sequence when t tends to zero. All constants are for a fixed beta strictly between zero and one; no uniform limit as beta approaches one is certified.

## 2. One base state, actual counter and exact activation prefix

The prefix erases only its first raw one. The inactive mode therefore has counter zero and cannot activate later; the active mode begins the candidate phase with one actual edit. The candidate guard permits at most h further edits, and `h+2<=k` reserves the endpoint edit. Every increment is a genuine changed coordinate. No raw context, auxiliary mode bit, count statistic or hidden shared random state is stored outside the actual counter.

The endpoint is at N, while all candidates end by `N-2`. The penultimate bit is untouched. For every fixed raw word, the final-pair change probability is exactly rho if the prefix contains a one and zero otherwise. The endpoint guard is available on every reachable active path, including a path reaching its interior cap. All forbidden edits are redirected to identity, including exhausted-counter rows. Every row is normalized and rational.

The table uses only the shared public design and is identical under the two sources. Its current-symbol causality does not depend on the later proof's use of retained neighbors. The full time-indexed table, rational rho/epsilon, integer L and actual `k+1` counter values remain charged.

The observable all-zero prefix has exactly zero or one raw one in the first L positions and a raw-zero anchor. I independently checked the stationary boundary calculation: an initial-position one contributes ratio `a/(1-a)` relative to the zero word; each of the other L-1 positions contributes `a(1-a-r)/(1-a)^2`. Thus (R5) is exact, including the initial stationary distribution and the last possible one just before the anchor.

The ratio is not independent of a. Its monotonic derivative is positive in the stated small-parameter range, its logarithmic derivative is `O(1/t)`, and its value stays between 1/2 and 2 once `a/t` is uniformly close to one. The prefix mass is bounded below by a constant because `La=a/t` remains bounded. Conditional on the prefix branch, the common raw-zero anchor makes the subsequent source trajectory independent of the activation mode, with prior `omega_a` that is correctly allowed to depend on the source.

## 3. Conditional candidates and the adverse odds

The deterministic candidate sites are spaced by two and are separated from B by the retained coordinate `N-1`. First-order likelihood factors therefore separate all missing bits after conditioning on the recoverable scaffold. They are independent but generally not identically distributed.

The four conditional odds in (R7), including equality of the mixed-neighbor odds, are correct. For 00 neighbors the log derivative is at least a constant times `1/t`; for 11 neighbors it can be negative with magnitude of that order. Integrating over the two alternatives gives the stated lower bounds `delta/t` and `-4delta/t`, and the common absolute upper bound. The mixed-neighbor derivative remains positive.

The conditional Fisher bound (R9) also holds uniformly over all scaffolds. In the 11 case, odds of order `r^2/t` make the conditional bit close to one, but `1-p=O(t/r^2)` cancels one inverse power in the squared score. The resulting information is `O_r(1/t)`, not a uniform positive-floor bound. Integrating square-root likelihood derivatives, or the corresponding Hellinger bound, gives conditional product-law TV at most `C_r delta sqrt(M/t)=C_r d`. Applying the identical capped channel preserves this comparison.

## 4. Good scaffolds and the large-odds overlap cost

The stationary probability of neighbors 11 around one candidate is exactly

`pi_a(1)[(1-a-r)a+(a+r)^2]`,

which is `O(a(a+r^2))`. The 00-neighbor failure probability is `O(a)`, and the expected conditional candidate success sum is the ordinary expected candidate-one count, `O(Ma)`.

For the odds sum, the three types must be treated separately. The 00 contribution is `O(Ma)`, the mixed contribution is `O(Mar)`, and the 11 contribution is `O(M(a+r^2)r^2)`. Thus `E L_o=O(M(a+r^4))` is valid. It would generally be wrong to replace this by `O(Ma)` as a tends to zero. This candidate explicitly retains the `r^4` term.

The fixed-start tail is the stationary future conditioned on a zero anchor of probability at least 1/2. Consequently every nonnegative functional and bad-event probability is bounded by twice its stationary counterpart. Applying this to the displayed expectations gives all good-set bounds under the minus source. The candidate count has density asymptotically 1/2 because L/M tends uniformly to zero, so the 00-count threshold M/4 has a fixed margin. Markov bounds and the source-TV comparison yield (R11). The proof does not require the channel to recognize, calculate or store this set.

The large 11-neighbor odds are also correctly paid in the thinning overlap. With `L_o<=KM(t+r^4)`, equation (R16) bounds the chi-square exponent by a constant controlled through alpha. The lower scale `t` of order at least `tau h/sqrt(M)` is essential here. Using only the expected total number of erased ones, or only the 00 odds, would not establish this mode overlap.

## 5. Exact capped polynomial and signed-score retention

For a fixed displayed vector Y and actual erased set E, the raw candidate word is fixed. Its probability relative to the inactive product law is the product of the odds on E. The channel coefficient depends on the chronology of E, Y, epsilon and the cap, but not on the source parameter. This proves the nonnegative polynomial representation for the actual capped law.

Taking the ratio of the two polynomials and applying Jensen under the normalized minus-source terms gives the signed score in (R13). It does not require every odds ratio to increase. The absolute degree bound gives the upper log-ratio bound for every output, and `delta h/t<=C d/sqrt(tau)` is uniform. Selecting `G>=0` is what supplies monotonicity of the likelihood ratio on the outputs later used in the endpoint argument.

For the actual cap, lost 00 erasures are bounded by `(D_total-h)_+`, with expectation at most `mu^2/h`. The expected adverse 11 count is at most its uncapped expectation. The subtraction in (R15) is therefore at most `K^2 alpha^2 h + 4K alpha h(r^2+t)`. Choosing r and alpha as prescribed leaves a fixed positive multiple of alpha h.

The actual total count is bounded by the proposed count and has the stated second moment for h above a fixed threshold. Cauchy-Schwarz bounds the signed mass lost on the likelihood-ratio bad set by `C K alpha h sqrt(zeta)`. After this loss, discarding outputs with negative G can only increase the remaining signed integral. On the selected set, `0<=G<=h`, which justifies subtracting h times the mixture L1 discrepancy when replacing the minus mixture by minimum source overlap.

The mixture discrepancy includes both the conditional product-law change and the non-common prior change `|omega_+-omega_-|<=C delta/t`. It is uniformly `O_r(d)` because `Mt>=1`. Choosing d after alpha retains the weighted positive score. The prior log odds increase with a, so they reinforce rather than cancel that score. The posterior logistic derivative on the displayed compact odds interval gives (R18).

The cap-TV comparison is used to establish overlap, not subtracted as an absolute error from the vanishing final separation. This distinction makes the small moving-rho argument valid.

## 6. Endpoint sign, changing source row and complete observation mass

On the good scaffold, the raw terminal bit is exactly `Ber(a)`, independent of candidates and activation mode. The next-bit transition is `a+rB`, and the active endpoint flip is available. The W=1 posterior formulas and derivatives in (R19)-(R20) are correct.

On the selected outputs, both mode posteriors stay bounded away from zero and one, so the endpoint mass is comparable to `t+rho` uniformly, including rho=0. Increasing the mode posterior pushes the W=1 terminal posterior downward, but increasing the source parameter pushes it upward. The candidate keeps both adverse changes: the direct intercept difference `2delta` and the changing endpoint-prior contribution of order `r rho delta/(t+rho)^2`.

The full output mass includes the prefix probability, scaffold law, capped candidate mixture and endpoint factor. For the positive signed term, the minimum mass is bounded below by a constant times `(t+rho) min f min m`. For the negative terms, the total minimum mass over the retained branch is at most `C(t+rho)`. These two estimates give a combined adverse cost at most `C delta`, rather than an incorrectly unweighted `delta/t` term or an omitted cancellation.

The retained positive mass is of order `h delta rho/(t+rho)`, giving (R21) after the two-risk inequality. Since `delta<=C_beta/sqrt(M)`, the independent clean lower legitimately absorbs the subtractive term: either the proposed endpoint expression is bounded by a fixed multiple of the clean scale, or (R21) retains a positive fixed fraction of it. No pointwise claim that the actual target gap always has the favorable sign is needed.

## 7. Scaling, boundaries and what the result does not say

The ceiling in B_M changes `h/sqrt(M)` only by a fixed factor. Splitting at `rho=h/sqrt(M)` proves (R22), with constants permitted to depend on tau and hence beta. Also `h/sqrt(M)` is within a fixed factor of `min{1,k/sqrt(M)}` outside the bounded-k fallback. When h is below its fixed threshold, the desired endpoint expression is at most `k/sqrt(M)`, so the clean witness absorbs it. This handles k=1 and k=2 without evaluating a zero-h thinning probability.

Taking the maximum with separate clean and protected witnesses gives the capped sum in (R1); their channels and edit budgets are not combined. The result is uniform in rational rho, k in the stated range and sufficiently large M, for each fixed `0<beta<1`. The paid description may grow with the exact rational rho. No independent fixed bit-budget restriction that excludes the constructed tables is being asserted away.

At rho=0 the extra endpoint term vanishes. At rho=1 or at b=1 it agrees in order with the earlier endpoint lower. When rho and b both tend to zero it can be strictly larger. The stated example has `b=M^(-1/4)`, `rho=M^(-1/8)` and endpoint term `M^(-5/16)`, compared with the fixed-floor expression `M^(-3/8)`. There is no contradiction: in this example the source floor tends to zero.

The result does not apply with a positive endpoint constant at beta=1, does not establish uniform constants as beta approaches one, and does not imply a sharp no-fixed-floor S=1 rate. The previously reviewed general upper still leaves a gap. The source model here includes first-order subfamilies; no exact-order-two-only assertion is supplied. One base state still accompanies the growing actual counter and paid public clock/table.

## Review method

Pure analytical reconstruction, private document inspection, hashing and this separate review artifact. No scientific executable checks, numerical experiments, model execution, public writes, external novelty investigation, training claim, numerical-stability proof or neural compilation result. Original artifacts remain unchanged.
