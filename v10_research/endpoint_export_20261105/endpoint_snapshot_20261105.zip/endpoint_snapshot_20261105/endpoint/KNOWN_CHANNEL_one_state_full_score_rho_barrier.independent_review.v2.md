# Independent review: endpoint-only complete-score rho barrier

Review time: 2026-11-05 10:45:52 UTC.

## Verdict and exact binding

**PASS. Recommend version 2 as the primary statement:** it proves the same obstruction with a simpler endpoint-only channel and k=1, without a hidden activation prefix.

I fully read and independently checked:

- `KNOWN_CHANNEL_one_state_full_score_rho_barrier.candidate.v2.md`
- SHA-256: `18477855bd28f5a7fbfb0684801caee8bf19f75ca449296a32e4064b17cf7c06`.

The previous version and its separate approval remain unchanged:

- candidate v1: `8d69accfcb86385a96c5fd667e96e034859b4af2133ffe72aeab48fd9f7d28e1`;
- independent review v1: `935eb99aeddb0fabe4a8b420da8f82de2e3479ddfbea51a3879aab99bcf58a40`.

These are present-byte bindings. This review does not infer a previous historical digest or replace the earlier audit. Version 2 is a rare endpoint-conditioning counterexample to specified score inequalities, not a predictive minimax lower or a specifically hidden-counter obstruction.

## 1. Source assumptions and exact channel

For each fixed `0<beta<1`, a positive rational r satisfying the displayed upper bounds exists. The source's stationary marginal and pair-chain minorization are correct: the minimum of `P_a(y|x)/pi_a(y)` is exactly `1-r>=beta`. The source is first-order, hence belongs to the at-most-second-order class. A neighborhood of `a_0=1/M` has all probabilities positive, but the source sequence has no uniform positive floor as M grows.

The channel passes the first N-1 raw bits exactly and flips the final raw bit with probability `rho=1/M`. It has one possible changed coordinate, so its strict budget is k=1 on every word and coin realization. The actual counter starts at zero, increments only for the actual endpoint flip, and has identity exhausted rows. The per-word terminal-pair-change probability is exactly rho.

The kernel is source-independent, normalized, rational and current-symbol causal. The whole channel, including rho, is held fixed while a is differentiated. No raw-history register, mode bit, source parameter or future innovation is used. The permitted time-indexed table and actual counter remain part of the interface, even though no persistent activation memory is needed in this simpler example.

## 2. Complete score, not an omitted-score proxy

The entire preterminal history H is observed. Consequently every complete stationary-source score term except the final transition score is a measurable function of H and has zero conditional covariance with the future row given Z. This includes the stationary initial-law score; it has not been ignored as a modeling assumption.

Conditional on H, `B=X_N` is Bernoulli `p=a+rX_(N-1)`. Since `dp/da=1`, the last transition score is exactly `(B-p)/[p(1-p)]`. The posterior endpoint probabilities in (B3) are the ordinary binary-noise Bayes formulas with the fixed flip probability rho.

Their posterior variances are `p(1-p)rho(1-rho)/ell_w^2`. Thus covariance with the **complete** score is exactly `r rho(1-rho)/ell_w^2`, positive for both endpoint outputs. The total target derivative is one plus this covariance. The direct source-row derivative is explicitly accounted for, and no remote/local cancellation remains unexamined.

Summing over W gives `r rho(1-rho)[1/q+1/(1-q)]`, which equals `r rho(1-rho)/[q(1-q)]`. Averaging the observed predecessor under its stationary marginal proves the exact integrated formula (B7).

## 3. Rare event mass and the numerical constants

At `a_0=rho=s=1/M`, the observable event `Z_(N-1)=0, Z_N=1` has exact mass `pi_(a_0)(0) 2s(1-s)`. On every full observation in this event the complete conditional covariance is exactly `r/[4s(1-s)]`, independently of the earlier displayed coordinates.

Their product is precisely `pi_(a_0)(0)r/2`. With `s<=1/4` and `r<=1/8`, the bound `pi_(a_0)(0)>=5/8` is conservative. It gives the stated lower `5r/16` without omitting the rare event probability.

Squaring the covariance before applying the same event mass gives `pi_(a_0)(0)r^2/[8s(1-s)]`, at least `5r^2 M/64`. This independently verifies (B12). These are actual-output expectation bounds, not values conditioned on a rare event without its probability.

## 4. Fisher information and contradicted exponents

The stationary one-transition Fisher formula (B10) is correct. At s, its first term is at most `4/(3s)`. Canceling `s/(s+r)<=1` in the second term bounds it by `64/35<2<=1/(2s)`. Therefore `I_step(s)<2/s=2M`.

For fixed k=1, `rho^alpha sqrt(I_step)` is at most `sqrt(2)M^(1/2-alpha)`. It tends to zero for every alpha>1/2, while the actual integrated absolute complete-score covariance stays at least `5r/16`. The proposed family of inequalities is therefore false uniformly over the stated class for all those exponents, including linear rho.

The L2 lower grows proportionally to M, while a candidate upper `C_beta rho^alpha k^2 I_step` is at most a constant times `M^(1-alpha)`. Thus every positive exponent alpha in this squared-covariance form fails as well. The candidate does not assert that a boundary exponent or any replacement inequality is universally valid.

The constants may depend on fixed beta through r. This is not a positive-r statement for beta=1 or a uniform assertion as beta approaches one. There is also no contradiction with a fixed-positive-floor theorem, because the transition probability s vanishes.

## 5. Prediction and finite-difference scope

The proved quantity is `E|p'_a(Z)-1|`, equivalently the complete-source covariance response of the actual predictive target. It is not itself a finite-alternative weighted-TV theorem or an estimation risk. A constant expected derivative contribution need not yield a constant prediction error when the natural source-parameter scale also shrinks.

For the suggested nearby parameters `(1+/-d)/M`, the posterior target on the retained rare branch can indeed change by a constant for fixed d, while that branch has probability of order `1/M`. This supports the stated order-`1/M` scale of its possible integrated contribution, not a clean-scale minimax separation. A formal two-source predictive theorem would still need its own complete loss and observation-overlap argument; none is claimed here.

The example does not disprove a general `O(k/sqrt(M))` predictive upper, a bound containing a separate rho-independent row-estimation term, or the alpha=1/2 L1 candidate. In particular a direct derivative baseline and global row-estimation error cannot be silently omitted when translating a score statement into a risk statement.

The obstruction is already present in a source-independent endpoint-only noise channel. It should not be attributed uniquely to a hidden counter, failure of remote-score mixing, or insufficient base states. Its precise lesson is that rare endpoint likelihood denominators prevent inserting the proposed rho power into the specified Fisher-normalized complete-score bound solely from the per-word endpoint certificate.

## Method and preservation

Pure analytical reconstruction, private file inspection, exact hashing and this separate review artifact. No scientific executable checks, numerical experiments, simulations, model execution, public writes, external novelty investigation, training claims or finite-precision certification. Both candidates and the preceding review remain unchanged.
