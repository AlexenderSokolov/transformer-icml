# A rigorous barrier to global latent-posterior and score shortcuts at S=1

5 November 2026 UTC. Pure analytical candidate. No scientific executable checks, numerical experiments, or public writes. This is a method barrier, not a new predictive minimax lower or an impossibility theorem for all score-based methods.

## 1. The two invalid shortcuts

The reviewed rare S=1 construction rules out both of the following uniform implications under only stationary binary D2(beta), a known time-indexed S=1 kernel, and an actual strict-k edit counter:

1. Raw-KL-close source alternatives have full clean-history posteriors within O_beta(k/sqrt(M)) in expected TV.
2. The missing complete-source Fisher information is always at most C_beta k^2 times the source's one-step Fisher information.

The counter is not independent of the raw history. The counter-positive mode in the counterexample comes from a genuine first-one erasure and is maintained by genuine subsequent edits.

These invalid implications concern stronger latent quantities than the requested posterior prediction target. Indeed the same example has a perfectly protected endpoint and source-specific predictive targets differing by only the small direct row perturbation. It therefore illustrates why a proof of a sharp general S=1 predictive upper must exploit the endpoint functional itself, rather than control the entire clean-history posterior or all missing source information.

## 2. The established rare one-state experiment, now with rho=0

Use the independently reviewed source and channel from

    KNOWN_CHANNEL_one_state_rare_rho_lower.candidate.v1.md
    KNOWN_CHANNEL_one_state_rare_rho_lower.independent_review.v1.md.

Fix the constants r,tau,alpha,d and the threshold H_beta allowed there. Choose any integers H_beta<=h<=sqrt(M), put k=h+2, and set rho=0. The public central scale is

    t comparable to tau h/sqrt(M),   L=1/t,
    epsilon=alpha h/(Mt),
    a_-=t-delta, a_+=t+delta, delta=d sqrt(t/M).        (B1)

The precise dyadic choice of t is the one in that reviewed proof. The stationary source is

    P_a(1|x)=a+r x,
    pi_a(1)=a/(1-r), pi_a(0)=(1-r-a)/(1-r).

Its all-state pair minorization has constant 1-r>=beta. The time-indexed one-state channel erases the first one in a prefix of length L, if present; leaves the anchor L+1 untouched; thins current ones at nonadjacent candidates with probability epsilon when the actual counter is positive, capped at h additional erasures; and never changes the endpoint because rho=0.

The kernel, prefix length, and thinning probability are fixed at their public central design t when a varies. They do not depend on the unknown source a.

The stationary raw source alternatives satisfy

    KL(P_+^(1:N)||P_-^(1:N))<=C_beta d^2.              (B2)

This is the transition Bernoulli KL calculation from the reviewed proof plus an initial-law KL of order delta^2/t. In particular the alternatives can have arbitrarily small fixed raw TV by taking d small.

Let

    U=1{the first L raw bits contain at least one one}.

This parameter-independent function of the raw word is the counter-positive mode. On the observable branch B_pre={Z_1=...=Z_(L+1)=0}, its prior omega_a is exactly the reviewed R_a/(1+R_a), uniformly bounded away from zero and one. Conditional on this branch, the raw tail starts from zero independently of U.

## 3. Finite-alternative latent-posterior obstruction

Write mu_a(.|z) for the posterior law of the entire clean word X_1:N, and v_a(z)=mu_a(U=1|z). The reviewed proof supplies a good scaffold D with overlap bounded below, a selected set of candidate outputs, and the bound

    sum_selected min{m_+(Y),m_-(Y)} |v_+(H,Y)-v_-(H,Y)|
       >=c_beta delta h/t                            (B3)

for every H in D. This is its signed actual-erasure-count estimate, before using the endpoint target.

When rho=0, the final raw bit B=X_N is displayed exactly. Given H, it is independent of U and of the candidate vector under each source. Consequently

    P_a(U=1|H,Y,B)=P_a(U=1|H,Y)

for every a: revealing B does not change the mode posterior. On the selected scaffolds the preceding retained bit is zero, so B has distribution Ber(a), and its two-source overlap is 1-2delta>=1/2.

The prefix branch probabilities are bounded below, and the scaffold overlap is at least 3/4. Retaining this branch and summing (B3), including the just-disclosed final bit, therefore gives

    sum_z min{P_+^Z(z),P_-^Z(z)} |v_+(z)-v_-(z)|
       >=c_beta delta h/t
       =c_beta h/sqrt(Mt).                            (B4)

Since total variation dominates the difference in the probability of the event {U=1},

    E_{P_-^Z} TV(mu_+(.|Z),mu_-(.|Z))
       >=c_beta h/sqrt(Mt).                           (B5)

The same lower holds with minimum output-mass weighting, which is the form directly proved in (B4). Thus it is not an artifact of averaging on disjoint observation supports.

For fixed h>=H_beta and M tending to infinity, t is of order M^(-1/2). Equation (B5) is then of order M^(-1/4), whereas k/sqrt(M) is of order M^(-1/2). No constant depending only on beta can repair the proposed O_beta(k/sqrt(M)) full-latent-posterior bound.

## 4. The prediction target is nevertheless endpoint protected

For this first-order source, and every displayed word in this rho=0 channel,

    P_a(X_(N+1)=1|Z=z)=a+r z_N,                       (B6)

because X_N=Z_N exactly and the channel is future blind. Therefore the two source-specific posterior prediction targets differ by exactly

    |p_+(z)-p_-(z)|=2delta=2d sqrt(t/M).               (B7)

For fixed h, this is of order M^(-3/4), even though the full clean-history posterior discrepancy in (B5) is of order M^(-1/4).

There is no predictive lower of order M^(-1/4) here. The counterexample instead shows that replacing the desired binary-future posterior comparison by full clean-history posterior TV can lose an unbounded factor, already for fixed edit budget, one base state, and no endpoint edits.

## 5. Infinitesimal mode sensitivity in the same actual channel

Now hold M,h,t and the entire channel fixed and let a vary continuously near t. All raw word probabilities are positive and the output support is independent of a, so ordinary finite-sample differentiation applies.

At a=t use the single-source versions of the good scaffold and selected output sets in the reviewed proof. Let

    Lambda_a(Y)=P_a1(Y)/P_a0(Y),
    G_t(Y)=E_t[D_00-4D_11 | H,Y,U=1],

where D_00,D_11 count actual capped erasures at the corresponding retained-neighbor types. The capped likelihood is exactly a positive polynomial with source-independent coefficients in the conditional odds. Differentiating that finite positive sum gives

    (d/da)log Lambda_a(Y)|_(a=t)
      = E_t[sum_(j erased) (d/da)log o_aj|_(a=t)
               |H,Y,U=1].                            (B8)

The explicit rare odds imply

    (d/da)log o_a(00)|_(a=t)>=1/(2t),
    (d/da)log o_a(11)|_(a=t)>=-2/t,
    (d/da)log o_a(01)|_(a=t)
       =(d/da)log o_a(10)|_(a=t)>=0.

Hence the right-hand side of (B8) is at least G_t(Y)/(2t). The prefix mode log odds also increase with a.

On E_0={1/2<=Lambda_t<=2}, the posterior mode odds stay in a fixed compact interval. On the selected set E_0 intersect {G_t>=0}, the logistic derivative is bounded below, giving

    (d/da)v_a(H,Y)|_(a=t)>=c G_t(Y)/t.                (B9)

The single-source signed-count retention estimate proved in the reviewed argument is

    sum_(E_0,G_t>=0) m_t(Y)G_t(Y)>=c_beta h           (B10)

on every good scaffold. It follows directly from the actual-erasure mean, second moment, cap coupling, and likelihood-ratio overlap steps; the two-source minimum-mixture subtraction is unnecessary here. The fixed alpha is included in c_beta.

The good-scaffold and prefix probabilities are bounded below. Revealing the unchanged final bit does not change v_a. Integrating (B9)-(B10) consequently proves

    E_t |(d/da)v_a(Z)|_(a=t)| >= c_beta h/t.           (B11)

This is sensitivity of a genuine raw-history-dependent counter mode, not of an artificially independent hidden bit.

## 6. Missing Fisher information must be large

Let the complete stationary source score be

    S_a(X)= (d/da) log P_a(X_1:N).

Because the channel is source independent, differentiation of the posterior gives the exact identity

    (d/da)v_a(z)=Cov_a(U,S_a(X)|Z=z).                 (B12)

Conditional Cauchy-Schwarz, Var(U|Z)<=1/4, and Jensen yield

    E_t Var_t(S_t(X)|Z)
       >=4 [E_t |(d/da)v_a(Z)|_(a=t)|]^2
       >=c_beta h^2/t^2.                             (B13)

The left side is precisely complete-source Fisher information minus observed-source Fisher information, by the score conditional-expectation identity and total variance.

For comparison the stationary one-transition Fisher information of the source is exactly

    I_step(a)=pi_a(0)/[a(1-a)]
                +pi_a(1)/[(a+r)(1-a-r)]
              asymp_r 1/a.                          (B14)

The initial stationary-bit information is 1/[a(1-r-a)], and complete information is this initial term plus (N-1)I_step(a), by orthogonality of transition martingale scores.

At a=t, the ratio of the lower bound (B13) to k^2 I_step(t) is bounded below by a constant times

    h^2/(k^2 t),

which diverges as t tends to zero when h>=H_beta is fixed and k=h+2. Thus a proposed uniform missing-information inequality

    E Var(S_a(X)|Z) <= C_beta k^2 I_step(a)

is false even in this S=1, rho=0 subclass. An inequality with k instead of k^2 is also ruled out. The bounded-statistic version

    E |d v_a(Z)/da| <= C_beta k sqrt(I_step(a))

fails by the same comparison, with divergence of order t^(-1/2).

## 7. What remains viable

The observations above do not refute endpoint-weighted score identities or a direct covariance argument for the future transition row. On the present protected example that transition row is already observable, so its conditional covariance with the complete score vanishes; only its direct derivative remains.

A successful sharp no-floor S=1 upper must retain this distinction. It must control the interaction of endpoint uncertainty with source-sensitive counter paths, while allowing rare-context score amplification such as (B11)-(B13). The actual counter is not independent of raw history, and the one-state restriction alone does not make its posterior regular in the source parameter.

The general upper remains the reviewed D2(beta) profile. The new rare-rho lower and this method barrier do not establish a matching S=1 upper or a definitive base-state separation.
