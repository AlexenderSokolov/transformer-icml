# A rare endpoint defeats linear-rho Fisher control even after all score cancellations

5 November 2026 UTC. Pure analytical candidate, pending independent exact-file review. No scientific executable checks, numerical experiments, or public writes. This concerns the combined complete-source score and the actual source-specific predictive target, not full-latent posterior TV or an isolated remote-score term.

## 1. Statement and limitation

Fix 0<beta<1 and choose a fixed rational

    0<r<=min{(1-beta)/2,1/8}.

For every integer M>=4 set N=M+2 and rho=1/M. There is a known, source-independent, online S=1 channel with at most two actual edits and per-word endpoint-change probability at most rho. For the stationary first-order source

    P_a(1|x)=a+r x,

at a_0=1/M, let S_all be the derivative with respect to a of the complete stationary raw-word log likelihood. Let g_a(X_N)=a+r X_N be the true next-bit success probability. Then

    E_(a_0) |Cov_(a_0)(g_(a_0)(X_N),S_all | Z)|
        >= r exp(-3)/32.                                  (F1)

The stationary one-step Fisher information satisfies

    I_step(a_0)<=2M.                                      (F2)

Consequently there is no uniform bound of the form

    E |Cov(g_a(X_N),S_all | Z)|
        <=C_beta rho k sqrt(I_step(a))                    (F3)

in the no-floor S=1 class, even with k=2. More generally replacing rho by rho^alpha in (F3) fails for every alpha>1/2. All remote and local source-score terms are included in (F1), so their cancellation has already occurred.

This does not disprove a general S=1 upper of order k/sqrt(M), a sqrt-rho Fisher bound, or a bound with an additional term independent of rho. It is not a new minimax rate lower: the selected output has probability of order 1/M, and its resulting two-source predictive contribution would be below the clean M^(-1/2) baseline.

## 2. Source and legal one-state channel

The stationary probabilities are

    pi_a(1)=a/(1-r), pi_a(0)=(1-r-a)/(1-r).

The pair-chain identity

    P_a^2((w,x),(y,z))=P_a(y|x)P_a(z|y)

gives the all-state D2 certificate with constant 1-r>=beta: the minimum of P_a(y|x)/pi_a(y) is 1-r. Take a in a small open neighborhood of a_0 so every probability is positive.

The actual edit count starts at zero. The channel has one base state and the following time-indexed rows:

- At i=1,...,M, if e=0 and x_i=1, output zero and increment e. Otherwise output x_i.
- At i=M+1, output x_i.
- At i=N=M+2, if e=1, flip x_i with probability rho and otherwise output it. If e=0 or e=2, output x_i.

An increment is made precisely when the output differs from the raw bit. These rules also define the unreachable and exhausted rows. The prefix spends at most one edit and the endpoint at most one more. For every fixed raw word, the endpoint-change probability is rho if the prefix contains a one and zero otherwise. The channel uses the public common design M and rho, not the unknown a, and never reads the future innovation.

## 3. Exact prefix-conditioned likelihood

Let B_pre be the observable event that the first M+1 displayed bits are zero. Its raw preimages consist of the all-zero prefix or exactly one one among positions 1,...,M, followed by the untouched zero anchor X_(M+1)=0.

Let U indicate that a prefix edit occurred. On B_pre it is the actual counter immediately before the endpoint. The no-one prefix mass and the single-one/no-one mass ratio are

    w_0(a)=pi_a(0)(1-a)^M,
    R(a)=a/(1-a)+(M-1)a(1-a-r)/(1-a)^2
        =a[M(1-a)-(M-1)r]/(1-a)^2.                    (F4)

The first term accounts for a single one at the initial position, using stationary detailed balance. Each other possible location contributes the second local factor. Thus

    b(a):=P_a(B_pre)=w_0(a)[1+R(a)],
    v(a):=P_a(U=1|B_pre)=R(a)/[1+R(a)].                (F5)

Conditional on B_pre, the endpoint raw bit B=X_N is Ber(a), independently of U, because the retained anchor is zero and the source is first order. With W=Z_N, the endpoint is

    W=B xor (U F),   F~Ber(rho),

with an independent coin F. On the single complete output z_*=0^(M+1)1, write T(a)=rho v(a). Its conditional endpoint-output probability and posterior endpoint mean are exactly

    ell(a)=P_a(W=1|B_pre)=a+(1-2a)T(a),
    F(a,T)=P_a(B=1|B_pre,W=1)=a(1-T)/[a+(1-2a)T],
    p_a(z_*)=P_a(X_(N+1)=1|Z=z_*)=a+r F(a,T(a)).     (F6)

The complete output mass is b(a)ell(a), not b(a) alone.

## 4. Differentiate the full posterior, keeping both effects

The channel and rho stay fixed while a varies. Direct differentiation gives

    F_a=T(1-T)/ell^2,
    F_T=-a(1-a)/ell^2,

and consequently

    dF(a,T(a))/da
        =rho [v-rho v^2-a(1-a)v']/ell^2.               (F7)

The first two terms are the changing endpoint-prior contribution, and the last is the changing counter-mixture contribution. They have opposite signs. Neither is dropped or bounded separately below.

At a=a_0=1/M, with rho=a_0 fixed, put D=2-r-a_0. Formula (F4) gives exactly

    R=(1-r)/(1-a_0),
    v=(1-r)/D,
    a_0 v'=(1-r-a_0 r)/D^2.                           (F8)

Substitution and cancellation yield the positive exact numerator

    v-a_0 v^2-a_0(1-a_0)v'
        =(1-a_0)[(1-r)^2+a_0 r]/D^2.                 (F9)

Because a_0<=1/4, r<=1/8 and D<=2, this is at least 1/8. Also

    ell(a_0)=a_0[1+(1-2a_0)v]<=2a_0.

Equations (F7)-(F9) therefore give

    dF(a,T(a))/da at a_0 >=1/(32a_0).                (F10)

The standard differentiation identity applies because this finite positive source family and the fixed channel have common support:

    p_a'(z)=E_a[partial_a g_a(B)|Z=z]
                 +Cov_a(g_a(B),S_all|Z=z)
            =1+Cov_a(g_a(B),S_all|Z=z).               (F11)

Combining (F6), (F10), and (F11) shows that the FULL conditional covariance on z_* is at least r/(32a_0). This is not a truncation to the prefix or to the endpoint transition score.

## 5. Actual output mass and Fisher scaling

At a_0<=1/4,

    pi_(a_0)(0)>=5/8,
    (1-a_0)^M>=exp(-2),
    b(a_0)>=exp(-3),
    ell(a_0)>=a_0.

For the second inequality use log(1-a)>=-2a on a<=1/2. Retaining the single output z_* in the integrated absolute covariance gives

    E |Cov(g,S_all|Z)|
        >=b(a_0)ell(a_0) r/(32a_0)
        >=r exp(-3)/32,

proving (F1). All rare-output weighting is present.

The ordinary stationary one-step Fisher information is

    I_step(a)=pi_a(0)/[a(1-a)]
                 +pi_a(1)/[(a+r)(1-a-r)].             (F12)

At a=a_0, the first term is at most 4/(3a_0). The second is at most

    1/[(1-r)(1-a_0-r)]<=64/35<2<=1/(2a_0).

Thus I_step(a_0)<2/a_0=2M, proving (F2). For k=2,

    rho^alpha k sqrt(I_step(a_0))
        <=2 sqrt(2) M^(1/2-alpha),                    (F13)

which tends to zero whenever alpha>1/2, contradicting (F1) under any fixed C_beta.

The same branch also gives the L2 obstruction

    E [Cov(g,S_all|Z)^2]
        >=r^2 exp(-3) M/1024.                        (F14)

Accordingly, an L2 bound C_beta rho k^2 I_step is false as well. This does not establish a universal valid replacement; it only specifies necessary limits on proposed endpoint-Fisher inequalities.

## 6. Implication for a cancellation-preserving S=1 proof

The earlier remote-score example allowed an exact cancellation on its selected branch. Here the two counter-conditioned derivative contributions are explicitly combined in (F9), yet their remainder is still of order 1/a on an output of mass order a. The per-word endpoint probability is rho=a. A proof cannot insert a linear rho factor into a Fisher-normalized combined score bound merely because the target changes only after an endpoint edit.

This leaves the general no-floor S=1 upper open. It supports separating L1 endpoint weighting, rare-parameter Fisher geometry, and any baseline row-estimation term, rather than treating cancellation as a uniform route back to the fixed-floor rho profile.
