# Independent analytical review: exact iid one-edit score barrier

Review time: 2026-11-05 10:15:57 UTC.

## Decision and exact binding

**PASS.** I fully read and independently checked every displayed identity and numerical constant in:

- `KNOWN_CHANNEL_one_state_iid_score_barrier.addendum.v1.md`
- SHA-256: `624464557dacee297f0f651d1ae99e92f94f67a26a0d874d7a7673c36b6eaded`.

This is a self-contained method barrier. It shows constant overlap-weighted full-history posterior separation and missing Fisher information of order M squared under one actual edit, while the specific two-source prediction problem has risk of order `1/M` for fixed d. It neither establishes a constant predictive lower nor resolves the general no-floor S=1 predictive rate.

The present hash was independently computed. This review does not infer a historical hash or overwrite the prior rare-source barrier or any candidate.

## 1. Exact physical channel and source class

The deterministic kernel erases the first raw one among positions 1 through M and then passes every remaining input. Its only memory is the actual binary edit counter. At counter one, every row is identity. The last two coordinates are protected regardless of input or counter. Thus every row is normalized, every path incurs at most one genuine change, and the per-word endpoint probability is exactly zero.

The channel uses no source parameter, no context history and no hidden auxiliary mode bit. It is a one-base-state, time-indexed kernel with its actual counter separately charged. The function `U=1{the first M raw positions contain a one}` is exactly whether the edit occurred. Its dependence on the raw word is retained.

The iid alternatives are stationary and satisfy the all-state pair-chain D2 condition with beta=1, hence every smaller positive beta. For `M>=4` and `0<d<=1/8`, their probabilities are strictly between zero and one. The source probabilities vanish with M, so this example lies outside any fixed-positive-floor asymptotic subclass. It does not contradict the fixed-floor results.

## 2. Complete observation branch and posterior TV

The full output `z_0=0^N` has exactly the stated raw preimages: the zero word and one-one words with the one among the first M coordinates. A second raw one would remain visible after the first edit, and a one in either protected endpoint would also remain visible. Thus no other preimage has been omitted.

Adding their iid probabilities gives

`P_a^Z(z_0)=(1-a)^N[1+Ma/(1-a)]`,

and their normalized active mass is exactly

`v_a(z_0)=Ma/[1+(M-1)a]`.

Conditional on activation and this output, the single erased position is uniform on the first M sites for every a. The two full clean-word posteriors therefore share the same two disjoint conditional components, with different mixture weights only. Their TV distance on this output is exactly the difference of the mode probabilities, not just bounded below by it.

For `a_+-a_-=2d/M`, exact subtraction gives the numerator `2d` and the product denominator in (I5). Each denominator is bounded by its corresponding `2+d` or `2-d` expression, so the product is at most four. This proves the lower `d/2`.

The mass bound is valid with the stated constants: `a<=9/(8M)`, `N<=3M/2`, and `log(1-a)>=-2a` give `P_a^Z(z_0)>=exp(-27/8)>=exp(-4)`. Hence the minimum of the two actual output masses times the exact posterior distance is at least `exp(-4)d/2`. Integrating more outputs can only increase the lower. Averaging under either individual output law also dominates this minimum-mass contribution.

The example uses the full observed word, including both protected endpoint bits. Its lower is not caused by concealing available observations or averaging on disjoint output supports.

## 3. Raw KL and the much smaller predictive problem

For the Bernoulli KL bound, `a_->=7/(8M)` and `1-a_->=3/4`. Multiplication by `N<=3M/2` gives exactly `(64/7)d^2`, which is less than `10d^2`. Pinsker consequently gives output TV at most `sqrt(5)d`. At `d<=1/8` this is less than 1/2.

The iid clean future is independent of the whole raw history and the channel operation. Its posterior target is the constant a under each source, on every possible output. The two-source absolute-loss inequality therefore supplies `d/(2M)` as claimed. This is an ordinary small parametric predictive lower, not a consequence of treating the constant latent-posterior gap as predictive uncertainty.

The displayed empirical mean differs pathwise from the raw empirical mean by at most `1/N`. Its expected predictive error is bounded by `sqrt(a(1-a)/N)+1/N<=3/M`. Thus the stated two-source risk interval is valid and has order `1/M` for fixed d. These are bounds for this pair of experiments, not a `3/M` uniform upper over all D2 sources.

The central constant estimator would also give an upper for this known pair, but the displayed-mean argument is valid without needing that observation. No correction of the conservative upper constant is required.

## 4. Exact complete and missing Fisher information

Holding the entire deterministic channel fixed, the iid complete score is

`S_a=(T-Na)/[a(1-a)]`.

The complete and per-step information formulas in (I10) follow immediately from the binomial variance. On the actual observed branch `z_0`, the raw total count T equals the hidden mode U and has only the two values zero and one. Therefore its exact conditional score variance is the expression in (I11).

At `a_0=1/M`, the mode posterior is `1/(2-1/M)`, which lies between 1/2 and 4/7 for all M>=4. Its variance is at least 1/5. Also `a_0^2(1-a_0)^2<=1/M^2`. Consequently the conditional score variance is at least `M^2/5`, and multiplying by the actual branch mass at least `exp(-4)` proves (I3).

The channel is independent of a, so the observed score is `E[S_a|Z]`. The conditional-variance quantity is precisely complete Fisher information minus observed Fisher information. It is not a proxy for prediction risk or a claim that an external hidden random variable has been supplied.

At the central source,

`I_step=M^2/(M-1)` and `I_complete=(M+2)M^2/(M-1)`.

These give the exact interval bounds in (I12). The missing-information lower is a small fixed fraction of the available complete information, so it is consistent with information data processing. Its ratio to `k^2 I_step` at k=1 is at least `(3 exp(-4)/20)M`, which diverges.

Direct differentiation of the mode posterior gives `M/(2-1/M)^2>=M/4`. Its contribution from the same observed branch proves (I13). The source-dependent posterior derivative and the identity `v'_a=Cov(U,S_a|Z)` are legitimate because all source probabilities are positive and channel support is parameter-independent. No derivative of the channel, M or the observable event is taken.

## 5. Precise method-barrier conclusion

For any fixed positive d in the stated interval, the raw KL radius is a small constant independent of M and can be made arbitrarily small in advance. Nonetheless the expected full-clean-history posterior discrepancy does not vanish. This refutes the proposed `O_beta(k/sqrt(M))` latent-posterior shortcut already at k=1. The missing-information and bounded-mode derivative comparisons fail at the same one-edit budget, even at beta=1.

The future target is the constant a and has no hidden-history posterior uncertainty. Its source derivative is one, whereas the mode derivative is of order M on a constant-mass observation. Thus the example pinpoints the loss incurred by controlling all missing information or the full latent posterior instead of the requested future functional.

No general predictive minimax lower at the latent scale, sharp general S=1 upper, state separation, necessity of additional base states or impossibility of all score-based arguments follows. Target-specific and endpoint-weighted methods remain compatible with this example.

## Method and preservation

Pure mathematical reconstruction, private file inspection, exact hashing and this separate review file. No scientific executable checks, numerical experiments, simulations, model runs, public writes, training claims, finite-precision statements or external novelty certification. The addendum and earlier barrier artifacts remain unchanged.
