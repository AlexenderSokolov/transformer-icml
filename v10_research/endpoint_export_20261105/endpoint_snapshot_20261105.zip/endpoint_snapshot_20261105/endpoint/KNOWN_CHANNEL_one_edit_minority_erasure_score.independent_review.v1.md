# Independent review: minority-erasure count and complete-score bounds

Review time: 2026-11-05 12:53:59 UTC.

Disposition: **PASS for the all-minority count-covariance bound and the stated complete stationary-source score and derivative bounds.** These remain source-wise, infinitesimal statements for the restricted channel class. No general S=1 minimax upper follows from this review.

## Exact file and scope

The entire candidate was independently read:

- `KNOWN_CHANNEL_one_edit_minority_erasure_score.candidate.v1.md`
- SHA-256: `b165999503367d3c46f9dfdb6ab6d4c140f19b923dd87ec72aec94c5bcdd5ae8`

Approval binds these current bytes. No amendment was required. It does not infer historical file integrity or extend to other source/channel classes.

The fixed public orientation is essential: the channel may erase 1 to 0 before the last two positions, and the considered source subclass has pi(1)=m<=1/2. The channel does not identify the unknown minority label or receive an unknown marginal. Endpoint edits may flip either symbol, subject to the one actual edit budget. One base state is accompanied by the separately charged true edit counter; no additional persistent seed or hidden mode is included.

The score claims concern an interior differentiable source path at the evaluated source, with one fixed source-independent channel throughout differentiation. The count statements alone also cover m=0. M>=2 is explicitly stipulated.

## 1. The sign and terminal boundary are correct

The training counts use triples ending at t=3,...,N. The split removes precisely the two indicators ending at N-1 and N. Every coordinate of the remaining T_far lies at or before N-2.

An edit at N-1 can affect the two removed indicators, and an edit at N can affect only the last one. Neither can affect T_far. An edit at or before N-2 is, by restriction, a replacement of 1 by 0. Such an edit can destroy raw 111 triples but cannot create one. Thus

    Delta=T_far(X)-T_far(Z)>=0

holds for every actual raw/output pair, including paths on which the only edit is at an endpoint. The sign is not reversed. At most three remote indicators can change, so Delta<=3.

At M=2, N=4, the two terminal indicators are well defined and T_far is the stated empty sum. The proof does not claim the displayed two-indicator formula for M=1. No unobserved clean terminal pair is provided to the estimator.

## 2. H8 is applied only to the actual raw edit

If Delta>0, the actual erased bit lies in a raw 111 triple counted by T_far. Depending on whether that bit is the first, middle, or last coordinate, its window orientation is (r,s)=(0,2),(1,1),(2,0). Every such event is contained in the corresponding valid-window event of H8. The additional restriction that the triple ends by N-2 only decreases the event.

All three actual central symbols are 1, so the denominator in H8 is pi(1)=m. Taking

    A_beta=C_(beta,0)+C_(beta,1)+C_(beta,2)

is a valid explicit choice in (S10). Its union bound gives P(Delta>0)<=A_beta p_111/m, and Delta<=3 gives E Delta<=3 A_beta p_111/m.

This is a bound under the actual joint source/channel experiment. It does not move an edit time to another posterior preimage or apply a raw-window bound to a displayed 111 created from 101. That distinction is the reason the monotonicity restriction matters.

The underlying H8 source is the reviewed hazard note with SHA-256 `e649e40991eb9eccf2917b1e028950dd4a6ced0bd441c13722d827dd9abf7d52`; its review has SHA-256 `21203139a715ea62c95bafa4e2576c9a100597539166cdab2ad08f5831327616`. The endpoint-weighted addendum is not needed for this argument.

## 3. Rare-count interpolation and all eight coordinates

Since T_far(Z) is observation-measurable, its conditional covariance with g is zero, and Cov(g,T_far(X)|Z)=Cov(g,Delta|Z). Nonnegativity of Delta and 0<=g<=1 imply the candidate's conservative bound

    E|Cov(g,Delta|Z)|<=2 E Delta.

One could sharpen the factor two, but that is unnecessary. Independently, two posterior preimages are at Hamming distance at most two, so their T_far counts differ by at most six. The conditional independent-copy covariance identity and Eg=m give the other bound 6m. Therefore the candidate correctly obtains

    min{6m,6 A_beta p_111/m} <= 6 sqrt(A_beta p_111).

For the removed part, 0<=T_end<=2 and E T_end=2p_111, so E T_end^2<=4p_111. Conditional and unconditional Cauchy-Schwarz give

    E|Cov(g,T_end|Z)|<=2 sqrt(m p_111)<=2 sqrt(p_111).

This handles arbitrary endpoint flips without evaluating either terminal indicator at an observed or counterfactual context. Thus C_111=6 sqrt(A_beta)+2 is a valid constant for the all-minority count.

For the other seven triples, the previously reviewed bounds give 6 sqrt(2)/beta times sqrt(p_abc). A common valid count constant is therefore

    C_count(beta)=max{6 sqrt(A_beta)+2,6 sqrt(2)/beta}.

For m>0, D2(beta) supplies p_111>=beta^2 m^3>0, so the marginal divisions are valid. If m=0, g=0 almost surely under the stationary source and every count covariance is zero. No score or logarithmic parameter extension to that boundary is silently claimed.

## 4. Transition score in every logit direction

At an interior source let q_u=theta_u(1), and let dot ell_u be the log-odds derivative. The transition log-likelihood derivative of the observed raw length-N word is exactly

    S_tr=sum_u dot ell_u[(1-q_u)T_(u,1)-q_u T_(u,0)].

There is no missing factor of M: the T counts already sum all M transitions. With I_u=Pi(u)q_u(1-q_u), the declared stationary transition Fisher information is I_step=sum_u I_u(dot ell_u)^2.

Applying the eight count bounds and using

    (1-q)sqrt(Pi q)+q sqrt(Pi(1-q))
       =sqrt(Pi q(1-q))[sqrt(1-q)+sqrt(q)]
       <=2 sqrt(I_u)

followed by Cauchy-Schwarz over four rows gives exactly the conservative coefficient 4 C_count(beta) in (S16). This controls any real logit direction, not merely a direction changing one row, and uses no transition floor.

## 5. Initial stationary-pair Fisher control

The extension controlling the initial stationary law is valid and is separate from the count argument. Differentiating Pi P=Pi and dividing the destination coordinate by its positive Pi mass gives

    v=P^*v+r,
    r(s)=sum_t Pi(t) dot P(t,s)/Pi(s),
    v(s)=dot Pi(s)/Pi(s).

The function r is the conditional expectation of the transition-only score dot P/P given the arrival pair. Its mean is zero because transition-row derivatives sum to zero. Conditional Jensen gives ||r||_2<=sqrt(I_step). It is not the score of the full stationary joint law; the missing initial-law feedback is exactly the v term in the equation.

Time reversal preserves the two-step minorization. Writing (P^*)^2=beta Pi+(1-beta)Q yields a stochastic residual kernel Q that preserves Pi. Such a kernel is an L2(Pi) contraction. On mean-zero functions, the rank-one Pi term vanishes, so

    ||(P^*)^n|| <= (1-beta)^floor(n/2).

The resulting Neumann series converges, has norm at most 2/beta, and is the unique mean-zero resolvent solution. v has mean zero by differentiation of normalization. Therefore

    I_initial=||v||_2^2 <= 4 I_step/beta^2.

No reversibility assumption is used: stationary time reversal and Markov L2 contraction suffice. The Hilbert-space norm is evaluated at the fixed source, so no derivative of the inner product is needed. Interior binary transitions make every pair mass positive, while the structural support of legal pair transitions remains fixed.

Since E Var(g|Z)<=E g^2<=m and E Var(S_init|Z)<=I_initial, the conditional/unconditional Cauchy-Schwarz step in (S20) is valid. Together with the transition score bound, a sufficient coefficient for (S2) is 4 C_count(beta)+2/beta.

## 6. Complete derivative and exact limits

For a source-independent future-blind kernel held fixed, differentiating the finite posterior sum gives

    dot p(Z)=E[dot g(X)|Z]+Cov(g,S_init+S_tr|Z).

All possible outputs of the fixed channel have positive probability at an interior source because every raw word has positive source mass. Outputs impossible for the channel remain zero under nearby interior sources and do not contribute. Thus there is no unhandled moving-support denominator in this local derivative identity.

The direct row derivative is q_U(1-q_U)dot ell_U. Stationarity and Cauchy-Schwarz give

    E|dot g|=sum_u I_u|dot ell_u|
       <=sqrt(sum_u I_u)sqrt(I_step)
       <=(1/2)sqrt(I_step).

Consequently adding one half to the preceding complete-score coefficient proves (S3). The stationary initial distribution has not been fixed artificially or omitted from the score.

Both expectations in these bounds use the observation law of the source at the differentiation point. Integrating them along a source path does not by itself produce a finite-alternative inequality under a single fixed observation measure. Likewise, neither a data-dependent fitted model nor a minimax estimator is supplied. The boundary-source extension is only for counts, not for the score statements.

The proof does not imply stability of the full latent posterior or bound its missing Fisher information by I_step. It controls only the future-row covariance. If interior majority-to-minority insertions are allowed, Delta need not be nonnegative and the actual raw-111 window argument no longer covers all count changes. The unrestricted S=1 crossed-preimage problem remains open.

## Preservation and activity

The candidate and earlier notes were not edited by this reviewer. Only mathematical reading and reasoning, private review writing, and file integrity checks were performed. No scientific executable checks, numerical experiment, model run, public write, or external disclosure occurred. No computational-efficiency, transformer, finite-precision, training, or novelty claim is approved.
