# Uniform-rho posterior upper under a fixed positive transition floor

Date: 2026-11-05 UTC. Pure mathematical analysis. Independent review status is recorded in the accompanying review, when present. No scientific executable checks, external writes, efficiency claim, or matching lower-bound claim.

## 1. Statement and experiment

Fix 0 < eta <= 1/2. Let X_1,...,X_(N+1) be a stationary homogeneous binary second-order Markov source, with N=M+2, M>=64, pair state S(x)=(x_(N-1),x_N), transition rows theta_u, and

    theta_u(c) >= eta, for every u in {0,1}^2 and c in {0,1}.

The unknown source is fixed when defining the target. A disclosed, source-independent observation kernel C(z|x) is future-blind, has strict raw Hamming budget k in {0,...,M}, and satisfies the per-word certificate

    sum_{z: S(z) != S(x)} C(z|x) <= rho, for every clean word x,   (1)

where 0<=rho<=1. Future-blind means that, conditional on the clean word, the channel output is independent of the next source innovation. The target is the source-specific posterior future law

    p_(theta,C)(z) = P_(theta,C)(X_(N+1) in . | Z=z).

There is a statistical predictor q_C with

    E TV(q_C(Z),p_(theta,C)(Z))
      <= min{1, C_eta [M^(-1/2) + k/M + rho min{1,k/sqrt(M)}]}.  (2)

The constant is finite for each fixed eta, uniformly in M,k,rho, the source, and the channel. This includes any stationary binary D2(beta) subclass with the stated floor; no extra D2 assumption is needed for the upper. At k=0 the endpoint contribution is exactly zero.

The predictor uses the public floor and known channel, and branches using only M,k. It need not be computationally efficient. The result improves the older floor upper O_eta((k+1)/sqrt(M)) when rho is small, without claiming an optimal rate.

## 2. Fitted parameters

Let Y_i=(X_(i+1),X_(i+2)), i=0,...,M, be the pair chain, with stationary law Pi and transition P. Set

    omega = eta^2,    gamma = 4 eta^2.

For every pair of states s,t, P^2(s,t)>=eta^2. Hence Pi(t)>=omega, P^2 dominates gamma times the uniform law, and

    delta(P^h) <= (1-gamma)^floor(h/2),                 (3)

where delta is the Dobrushin contraction coefficient. An exponent zero has value one, including h=0 and h=1 when gamma=1.

For each pair u, use the M contexts and M associated successor symbols to define clean counts

    J_u = sum_(i=0)^(M-1) 1{Y_i=u},
    C_u = sum_(i=0)^(M-1) 1{Y_i=u, X_(i+3)=1},
    T_u = C_u - theta_u(1) J_u.

Let J'_u,C'_u be the corresponding counts of the displayed word z. Put

    q'_u(1) = (C'_u+1)/(J'_u+2),
    theta_hat_u(1) = clip(q'_u(1), [eta/2,1-eta/2]),
    theta_hat_u(0) = 1-theta_hat_u(1).

Let Pi_raw(u)=J'_u/M. Project Pi_raw in L1 onto the probability simplex whose four entries are at least omega/2, with a fixed deterministic choice among minimizers. Call the result Pi_hat. This simplex is nonempty, and the true Pi is feasible. No stationarity relationship between the fitted Pi_hat and theta_hat is imposed or needed.

Write

    epsilon(z) = max_u TV(theta_hat_u,theta_u),
    Delta(z) = TV(Pi_hat,Pi).

These quantities are used only in the analysis, not as estimator inputs.

## 3. A global clean-word envelope

Define the source-dependent clean-word quantity

    O(x) = max_u |J_u-M Pi(u)|/M,
    R(x) = max_u |T_u|/M,
    W(x) = 1/M + O(x) + R(x).                          (4)

For every deterministic pair (x,z) with d_H(x,z)<=k,

    epsilon(z) <= (10/omega)[W(x)+k/M],
    Delta(z) <= 4[W(x)+k/M].                           (5)

Here and below, the clean quantities in (4) use the fixed true source. They are proof envelopes and are not observed or supplied to the estimator.

To prove (5), a token edit changes at most two counted context pairs and at most three counted triples. Thus

    |J'_u-J_u| <= 2k,    |C'_u-C_u| <= 3k.

For each binary row,

    |q'_u(1)-theta_u(1)|
       <= (|T_u|+5k+1)/(J'_u+2).                      (6)

If J'_u>=M omega/2, (6) is at most

    (2/omega)[R(x)+5k/M+1/M]
       <= (10/omega)[W(x)+k/M].

If J'_u<M omega/2, then

    |J_u-M Pi(u)|/M + 2k/M >= omega/2.

The trivial row-error bound one is therefore at most

    (2/omega)[O(x)+2k/M]
       <= (10/omega)[W(x)+k/M].

Scalar clipping cannot increase distance to the true row parameter, which is in the clipping interval. This proves the row part of (5), including arbitrarily small observed row counts.

For the initial law, the clean empirical pair law has TV distance at most 2O(x) from Pi. At most 2k of its categorical observations change, so the corrupted empirical law adds at most 2k/M in TV. L1 projection at most doubles the distance to a feasible true Pi, yielding

    Delta(z) <= 4O(x)+4k/M.

In particular, (5) is pathwise and uniform over all valid output words. No independence between the channel and clean fluctuations is asserted.

## 4. Sub-Gaussian clean fluctuations and the needed exponential moment

The envelope obeys, for every t>=0,

    P{W(X) >= 1/M+t} <= 16 exp(-c_eta M t^2),
    c_eta = gamma^2/32.                               (7)

The bound can exceed one; this is harmless. We prove it without an unproved occupation-concentration assumption.

For an indicator f_u(s)=1{s=u}, let F=sum_(i=0)^(M-1)f_u(Y_i)=J_u. Its Doob martingale for successive revelation of Y_0,...,Y_(M-1) has increments bounded in absolute value by 2/gamma. Indeed, for

    g_i(s)=sum_(h=0)^(M-1-i) P^h f_u(s),

the oscillation is bounded by

    osc(g_i) <= sum_(h>=0) delta(P^h) <= 2/gamma.

For i>=1 the Doob increment is g_i(Y_i)-P g_i(Y_(i-1)); the initial increment is g_0(Y_0)-E g_0(Y_0). Each has the asserted bound. Azuma-Hoeffding and stationarity give

    P{|J_u-M Pi(u)| >= M t}
       <= 2 exp(-gamma^2 M t^2/8).                    (8)

Also, T_u is a martingale sum with M increments

    1{Y_i=u}[1{X_(i+3)=1}-theta_u(1)]

of conditional mean zero and absolute value at most one. Consequently

    P{|T_u| >= M t} <= 2 exp(-M t^2/2).                (9)

Union bound over the four rows and use O+R>=t only if O>=t/2 or R>=t/2. Equations (8)-(9) imply (7). This also gives E W<=C_eta/sqrt(M).

For every fixed a_eta>0, uniformly over integer 1<=k<=sqrt(M),

    E[exp(a_eta(k+1)[W(X)+k/M])-1]
        <= C_eta,a k/sqrt(M).                         (10)

For completeness, put V=sqrt(M)(W-1/M), so V>=0 and P(V>=v)<=16 exp(-c_eta v^2). Hence, for each fixed B,

    E[(1+V)exp(B(1+V))] < infinity,

bounded only in terms of B,eta. With a=a_eta(k+1), we have a/sqrt(M)<=2a_eta. The inequality exp(t)-1<=t exp(t) yields

    E[exp(aW)-1] <= C_eta,a (k+1)/sqrt(M).

The deterministic extra exponent a k/M is bounded above by 2a_eta and also by 2a_eta k/sqrt(M). Expanding

    exp(a k/M) E exp(aW)-1

and using k+1<=2k proves (10). Constants here may be large as eta tends to zero; eta is fixed throughout.

## 5. Localized posterior perturbation

For fixed displayed z with a nonempty channel preimage, use its fitted parameters to define the positive surrogate word law

    P_hat_z(x)=Pi_hat(x_1,x_2)
                   product_(t=3)^N theta_hat_(x_(t-2),x_(t-1))(x_t).

Combine this law with the same known channel C(z|x) and normalize to obtain the fitted posterior nu_hat_z on x. Let nu_z be the true posterior under the fixed source. Outputs with empty channel preimages have zero probability under every source; define the predictor arbitrarily there. Define the posterior plug-in predictor on the remaining outputs by

    q_post(z) = E_(nu_hat_z) theta_hat_(S(X)).

Future-blindness gives the actual target

    p_(theta,C)(z) = E_(nu_z) theta_(S(X)).             (11)

All statements below are pointwise in z. Thus the fitted parameters may depend arbitrarily on z, as they do here.

For word probabilities in the channel preimage, the oscillation of the logarithmic likelihood ratio log(P_hat_z(x)/P_theta(x)) is at most

    L(z) = 24k epsilon(z)/eta + 4 Delta(z)/omega.       (12)

To check (12), both true and fitted transition coordinates are at least eta/2, so each transition log-ratio has absolute value at most 2 epsilon/eta. Initial pair log-ratios have absolute value at most 2 Delta/omega. Two preimage words are at Hamming distance at most 2k; at most 6k triple positions can differ. Comparing the two log-ratio sums gives 24k epsilon/eta, plus 4 Delta/omega for the initial pair.

The shared channel factor cancels when taking posterior ratios. Because its logarithmic oscillation is at most L and its posterior mean is one, the normalized posterior density h_z=d nu_hat_z/d nu_z satisfies

    exp(-L) <= h_z(x) <= exp(L).

Let A_z={x:S(x)!=S(z)}. The following localization is valid even when the fitted posterior puts much more mass on A_z:

    TV(q_post(z),p_(theta,C)(z))
      <= epsilon(z) + [exp(L(z))-1] nu_z(A_z).         (13)

For binary laws TV is absolute difference of the success probabilities. The change in the transition row under the fitted posterior costs at most epsilon. For the remaining term, normalize first and subtract the constant displayed terminal-row value:

    E_(nu_z)[(h_z-1) theta_(S(X))(1)]
      = E_(nu_z)[(h_z-1)
            (theta_(S(X))(1)-theta_(S(z))(1))].

The centered factor is zero off A_z and has absolute value at most one. This proves (13).

One must not replace exp(L)-1 in (13) by C min{1,L} in general: reweighting can amplify a tiny true posterior endpoint mass. The exponential-moment argument below is essential to this proof.

## 6. Taking expectations with the per-word endpoint certificate

For 1<=k<=sqrt(M), (5) and (12) give a fixed constant a_eta such that, for every valid pair (x,z),

    L(z) <= a_eta(k+1)[W(x)+k/M].                     (14)

Write A={S(X)!=S(Z)}. Using conditional expectation and then the pathwise envelope,

    E{[exp(L(Z))-1] nu_Z(A_Z)}
      = E{1_A[exp(L(Z))-1]}
      <= E_X{[exp(a_eta(k+1)[W(X)+k/M])-1]
                  P_C(A|X)}
      <= rho E_X[exp(a_eta(k+1)[W(X)+k/M])-1]
      <= C_eta rho k/sqrt(M).                         (15)

This is the only factorization being used. It follows from the per-word certificate (1), not from an unsupported independence assumption or from an unconditional bound P(A)<=rho alone. In particular, merely knowing E_C 1_A<=rho would not justify this step.

The row term has, by (5) and (7),

    E epsilon(Z) <= C_eta[M^(-1/2)+k/M].               (16)

Equations (13), (15), and (16) prove (2) in the small positive-budget regime.

## 7. Large budgets and zero budget

For k>sqrt(M), use the simpler fitted displayed-terminal-row predictor

    q_end(z)=theta_hat_(S(z)).

By (11) and convexity,

    TV(q_end(z),p_(theta,C)(z)) <= epsilon(z)+nu_z(A_z).

Taking expectations, (16) and (1) give

    Risk(q_end) <= C_eta[M^(-1/2)+k/M]+rho,

which is the desired large-budget branch.

For k=0, every channel output equals its clean input. Thus A is empty, and q_end has risk at most C_eta M^(-1/2). The endpoint term is exactly zero. The fitted initial-law error cannot create a spurious endpoint contribution here.

Choose q_C=q_post for 1<=k<=sqrt(M), and q_C=q_end otherwise. This branch selection uses only public M,k. Every TV loss is at most one, completing (2).

## 8. Audit boundaries

- Stationary initialization, fixed positive eta, known future-blind channel, and the per-clean-word endpoint certificate are explicit assumptions.
- The target is the posterior future law for a fixed unknown source; no prior over sources is introduced.
- The channel may depend arbitrarily on the clean word and may correlate its edits with all historical sufficient statistics. The proof handles that dependence pathwise.
- Fitted parameters are allowed to depend on the displayed word because the posterior comparison is performed after fixing that word.
- Both posterior laws use the same channel. No coupling between two source-dependent attack kernels is invoked.
- The initial-law fit need not be stationary for the fitted transition table.
- No execution, finite-precision, rational-channel, architectural, or training result follows from this purely statistical upper.
- A matching lower, optimal k/rho dependence, or uniformity as eta vanishes is not claimed here.

## Dependencies and provenance

- `KNOWN_CHANNEL_uniform_positive_floor_upper.md`: original fixed-floor estimator, initial-law fitting, and preimage likelihood-ratio argument.
- `KNOWN_CHANNEL_uniform_positive_floor_upper_independent_review.v1.md`: review of that older result.
- This note adds a localized exponential-moment refinement, supplies the required global clean-envelope proof, and checks posterior normalization explicitly.
