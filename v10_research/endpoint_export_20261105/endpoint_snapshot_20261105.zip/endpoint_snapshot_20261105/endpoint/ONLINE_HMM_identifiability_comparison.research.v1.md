# Online channel comparison: HMM identifiability, finite-state inference, symmetrization

5 November 2026 UTC. Primary-source literature comparison, not proof validation or novelty certification. No scientific executable checks or public writes.

## Main result of the comparison

The strongest additional HMM precedent is Abraham, Gassiat and Naulet's quantitative study of learning near nonidentifiability. It already separates exact identifiability from nonasymptotic minimax rates and permits shrinking regularity parameters despite fixed mixing. The new online witnesses therefore should not be positioned as the first demonstration that identifiable or mixing hidden models can be statistically difficult. Their specific contribution to compare is the strict-edit, common-disclosed-channel, clean-future posterior target and the endpoint rate under a paid online finite-state implementation.

## 1. Strong quantitative antecedent

Kweku Abraham, Elisabeth Gassiat and Zacharie Naulet, *Fundamental Limits for Learning Hidden Markov Model Parameters*, IEEE Transactions on Information Theory 69(3), 1777–1794 (2023), arXiv v3 dated 24 October 2022.
https://arxiv.org/pdf/2106.12936v3
https://doi.org/10.1109/TIT.2022.3213429

Inspected: Sections II–III, Remark 1, Theorem 1, Corollary 1, Proposition 2, and lower-bound discussion. The stationary two-hidden-state multinomial HMM class uses transition lower bound delta, distance epsilon from a singular transition matrix, and emission separation zeta. Remark 1 explicitly holds an absolute spectral-gap lower bound L fixed while allowing delta, epsilon and zeta to depend on sample size; one transition probability may vanish. Theorem 1 gives matched nonasymptotic parameter-estimation bounds. Proposition 2 bounds full-observation KL by C n times a squared statistical distance near independence, with emission probabilities bounded below. Le Cam alternatives then yield lower bounds.

Comparison: a fixed mixing assumption does not automatically give uniform learnability away from rare populations or singular observation maps. This precise phenomenon is prior art. Their model has stationary ordinary emissions and estimates parameters, whereas the local target is a source-specific clean-future posterior under a strict-edit transducer. Their formulas do not establish either local endpoint exponent.

## 2. Stronger identification theorem than linear independence alone

Grigory Alexandrovich, Hajo Holzmann and Anna Leister, *Nonparametric identification and maximum likelihood estimation for hidden Markov models*, Biometrika 103(2), 423–434 (2016); arXiv v2 dated 30 September 2015.
https://arxiv.org/pdf/1404.4210v2

Inspected: model definition, assumptions A1–A3, Theorem 1 and Example 1. Their homogeneous HMM has stationary current-state emission laws. Under a stationary latent law, an ergodic full-rank transition matrix and pairwise distinct emissions, the law of 2K+1 observations identifies the parameters up to labels. Linear independence of the emissions is not required. Example 1 demonstrates a rank-deficient nonidentifiability construction even with linearly independent emissions.

Comparison: do not imply that failing emission linear independence alone rules out all positive HMM results. Nevertheless, the local augmented channel state contains irreversible edit/count memory, and the tables have public time dependence. Appending a clock does not manufacture a stationary ergodic chain. These identification hypotheses are not justified by the clean-source D2 certificate.

Previously audited source rechecked: Gassiat, Cleynen and Robin, arXiv:1306.4657v1, Theorem 2.1 identifies stationary HMM parameters from three observations under full-rank transitions and linearly independent emissions.
https://arxiv.org/pdf/1306.4657v1

For a binary output alphabet, more than two one-symbol emission distributions cannot be linearly independent. This is an elementary dimension observation, not a claim that every block-emission representation or weaker identification theorem fails.

## 3. Finite-state representation and posterior computation are established

Henry D. Pfister, Joseph B. Soriaga and Paul H. Siegel, *On the Achievable Information Rates of Finite State ISI Channels*, IEEE Globecom (2001), pp. 2992–2996.
https://pfister.ee.duke.edu/papers/globecom2001.pdf

Inspected: Section II.B. It defines a finite-state channel by P(Y_i,Q_(i+1)|X_i,Q_i), combines it with a finite-state input source by enlarging the state, and views the output as a finite-state hidden Markov model. The section gives APP forward recursions. Its information-rate treatment assumes stationary source/channel distributions and ergodicity.

Comparison: hidden state depending on previous raw inputs is standard finite-state-channel structure, not intrinsically outside all HMM representations. The new constructions are naturally time-inhomogeneous finite-state hidden models for each fixed horizon. A homogeneous representation can add the clock, increasing state size and retaining nonstationarity. An exact forward recursion with both source and channel known does not resolve estimation when only the channel is disclosed.

Historical anchor: Bahl, Cocke, Jelinek and Raviv, *Optimal Decoding of Linear Codes for Minimizing Symbol Error Rate*, IEEE TIT 20(2), 284–287 (1974). The IBM primary abstract describes posterior state and transition estimation for a Markov source observed through a discrete memoryless channel. Only the abstract was inspected; no stronger theorem-level mapping is claimed.
https://research.ibm.com/publications/optimal-decoding-of-linear-codes-for-minimizing-symbol-error-rate

## 4. Symmetrizability is a mechanism analogy, not the claimed theorem

Imre Csiszar and Prakash Narayan, *The Capacity of the Arbitrarily Varying Channel Revisited: Positivity, Constraints*, IEEE TIT 34(2), 181–193 (1988).
https://user.eng.umd.edu/~prakash/papers/Csiszar_Narayan-IT_1988ii.pdf

Inspected: Section II, Definition 2, Theorem 1, state-constraint discussion and the opening of its proof. Symmetrizability asks for a state-selection kernel U satisfying sum_s W(y|x,s)U(s|x') = sum_s W(y|x',s)U(s|x). For the unconstrained discrete-memoryless AVC this characterizes zero deterministic-code capacity under average error. Individual-sequence state constraints change the result and introduce an input-distribution-dependent symmetrizing cost.

Comparison: hiding which input explanation generated an observation and respecting a per-sequence budget have clear antecedents. But the local construction uses one common causal channel under both source laws, requires only positive overlap, and lower-bounds posterior estimation rather than decoding capacity. It does not establish this exact symmetrizing identity. A channel-state constraint is also not automatically the local input-dependent edit constraint. Thus describe an analogy, not a reduction or an identity with AVC symmetrizability.

## 5. Application to the supplied candidates

These are deductions from the local files, not claims made by the papers:

- Four base states at k=1 excludes the separately charged binary edit counter and the public time-indexed table. It is not a four-state stationary homogeneous HMM theorem. Growing-k uses O(N^2) base states and a separate counter.
- Source independence means the same disclosed transition tables act under both source alternatives. It does not make posterior raw-count distributions source independent.
- Monotone edit/count memory need not forget old source information when the clean chain mixes. Filter contraction of the clean state alone does not automatically extend to the augmented channel state.
- The alternatives depend on horizon and approach rare-transition boundaries. Positive overlap rather than identical full output laws yields the two-point lower. No exact nonidentifiability or fixed-source inconsistency follows.
- The relevant weighted gap is sum_z min(P_+^Z(z),P_-^Z(z)) |p_+(z)-p_-(z)|. The candidate retains the rare-output mass to obtain rho*t/(rho+t), hence min(rho,t). Merely showing large posterior disagreement on a rare output would be insufficient.
- At k=1, t is of order M^(-1/3). Growing-k gives t of order (k/M)^(1/3), not (k^2/M)^(1/3). The latter offline upper profile remains unmatched by this online lower.

## Recommended bounded wording

Known finite-state channel filtering and HMM identifiability do not by themselves give uniform posterior-estimation rates when the source approaches a boundary and the disclosed causal channel carries hidden edit-allocation information. Quantitative HMM minimax work already analyzes the distinction between identifiability and learnability near degenerate regimes. Here the comparison-sensitive claim is an endpoint lower for source-specific clean-future posterior prediction through a common normalized rational strict-budget online channel: a constant-base-state one-edit witness, and a horizon-dependent polynomial-state growing-budget witness. Neither general posterior amplification, finite-state augmentation, nor near-nonidentifiable minimax lower bounds should be claimed as new.

## Inputs and limits

Read the one-edit and growing-budget online candidates, the prior posterior-channel audit, and the rho-interpolation audit. Existing posterior-stability/filter-robustness comparisons in those audits remain relevant; they are not duplicated. The online candidate files describe analytical claims and pending review status, so this literature note is not independent analytical acceptance. Exact primary locations above were inspected; no exhaustive priority search or nonexistence claim is made.
