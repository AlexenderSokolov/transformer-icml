# Independent review of two online posterior lower bounds

Review time: **2026-11-05 07:04:24 UTC**.

Reviewed current files in `./`:

1. `KNOWN_CHANNEL_online_one_edit_lower.candidate.v1.md`
   SHA-256: `411908bdfb5385066e19daaa84edcc302fc0a80bf76eb23d258a3f7187fa6e60`.
2. `KNOWN_CHANNEL_online_protected_budget_lower.candidate.v1.md`
   SHA-256: `dae5c75cd818401f8cb323c10f4e34d0754d7d5a92114fa3f7f4723d5d186fbe`.

I read both complete arguments, checked the final channel/counter/resource clarifications, and checked the cited rare-source identities and overlap mechanism. The hashes were independently measured for this present review. No historical hash assertion is inferred. No scientific executable tests, numerical experiments, model execution, or public writes were performed.

## Disposition

**Both lower bounds pass independent analytical review under their stated source and channel contracts.**

- The rare one-edit witness gives c_beta min{rho,M^(-1/3)} using four raw-pair base states and a separate binary edit counter.
- The protected witness gives 27k/(1024M) using one base state and the separately charged k+1-state edit counter.

The first closes the fixed-beta k=1 statistical endpoint rate for a time-indexed online class containing this four-base-state family and the identity channel. The second supplies the k/M term for general budgets. The growing-k endpoint lower min{rho,(k^2/M)^(1/3)} is not established by these arguments.

## 1. Online execution, state and per-word budgets

The rare channel's state contains only the previous two raw input bits and whether its one edit has been consumed. Starting that pair register at 00 is valid: the first two inputs are passed unchanged and update the register before the first candidate position 3.

At an interior candidate, the channel tests only its public index, the previous raw pair, the current input and the counter. It immediately erases the first eligible one. It does not inspect the candidate's future neighbors and cannot later retract an output.

At position N-1 it tests the current preceding raw pair and the unused-edit flag, then independently flips the current bit with probability rho. The patched rule explicitly increments the counter on a flip. Position N is always passed unchanged. Thus every realization uses at most one edit. For each fixed clean word, endpoint-change probability is exactly zero or rho. All transition rows are normalized, and the independent endpoint coin cannot reveal or depend on the future innovation.

Four base states, or eight states if the edit bit is included, suffice. This is a **public-horizon-dependent, time-indexed family**, not one fixed length-independent homogeneous transducer. The expanded rational table description O(N(b_rho+1)) pays the actual numerator/denominator lengths of rho. The dyadic specialization pays its full precision. A clock-based homogeneous implementation is a different state ledger.

The protected witness is also genuinely online: it erases a current one immediately if fewer than k interior ones have been erased, and protects the last two positions. It needs one base state plus the k+1-state counter, not one total state uniformly in k. Its time-indexed counter-dependent table and expansion are charged. Both channels are common to their respective source alternatives and use no unknown source parameter.

## 2. Recoverable scaffold and conditional independence

Rare candidates are multiples of three. Their two preceding positions and two following positions are noncandidates. For candidates no later than N-5, none of those retained positions is the potentially edited penultimate bit. Therefore eligibility is determined by untouched coordinates and is recoverable from Z.

The scaffold H retains every coordinate except the eligible candidate bits and B=X_(N-1). This is one common deterministic map of the clean word, unchanged by the channel and reconstructible from the displayed word. Missing-position marks are a mathematical description of that map, not additional information supplied by the channel.

Every order-two likelihood factor spans at most two coordinate gaps. Distinct missing candidates are at least three apart, and candidate factors end by N-3. No factor contains two missing candidate bits, or a missing candidate and B. Conditional on H, the hidden bits consequently factorize and the candidate bits are independent of B. The initial pair factor involves only retained coordinates.

This factorization does **not** make the candidate bits identically distributed. Recomputing the three factors affected by a candidate gives exactly

    future 00: q t/(1-t),
    future 01: q r/(1-r),
    future 10: q^2 t^2/[r(1-t)],
    future 11: q^3 t^2/[r(1-q t)].

All four are increasing in q. In particular the future-01 conditional success probability is not of order t. The proof correctly keeps that type instead of silently treating all sites as the earlier guarded 11?00 construction.

Because the channel erases only the first eligible one, the displayed eligible bits are all zero exactly when S<=1. If S>=2, at least one later eligible one remains visible. The eligibility mask cannot change after an earlier edit because its defining preceding coordinates are noncandidates. Thus the claimed branch has no extra preimages from S>=2 and reveals neither the original S nor the channel's edit flag.

## 3. Total-odds control and scaffold overlap

The parameter restrictions imply d<=1/64, r<=1/16 and t<=r/16<=1/256. The four conditional odds are at most 1/8. For either q alternative, their ratio o_+/o_q is at most two, including the extra (1-q t) denominator ratio in the future-11 case.

Since p_q=o_q/(1+o_q), these bounds give

    o_+ <=2o_q <=(9/4)p_q <4p_q.

Conditional expectation then yields

    E_q L_+ <=4 E_q S
             =4|J|Pi_q(11)q t <=4Mt^3.

The final inequality follows from |J|<=M/3, Pi_q(11)<=2t^2 and q<=65/64. This argument controls every future-neighbor type under both source laws, using the **same** function L_+ in the good-scaffold event.

The exact 11?00 window probability is u_q t^2[1+(q-1)t]. Its count therefore has mean asymptotic to Mt^2/3. The all-state pair minorization supplies a geometric mixing bound. For disjoint windows, conditioning at the end of the earlier window bounds their covariance by its O(t^2) event probability times a geometrically decaying term; finitely many overlapping windows also contribute O(t^2) each. Thus Var(n_00)<=C_beta Mt^2 is justified, rather than the insufficient O(M) bound.

Because Mt^2 tends to infinity, the count event T has probability tending to one. The terminal scaffold event A also tends to one since the stationary minority mass is O_beta(t). Markov's bound on L_+ and a sufficiently small fixed tau give P_q(D)>=7/8 for both alternatives.

The stationary rare-source law, all-state D2(beta) certificate and clean-history TV bound are correctly inherited from the cited source calculations. In particular the transition KL is O(d^2 Mt^3), and the initial-law KL tends to zero. The channel does not use these parameters. H is a common map, so data processing gives TV(f_+,f_-)<=1/8. Consequently the overlap restricted to the common event D is at least 7/8-1/8=3/4.

On D, the 00 sites give L_+-L_->=d tau^3/2. The denominators in v_--v_+ are at most four, giving v_--v_+>=d tau^3/8. Also g_q=(1+L_q) product(1+o_q)^(-1)>=exp(-L_q)>=e^-1. These are uniform positive constants independent of rho and M after the stated onset horizon.

## 4. Exact source-specific posterior and rare-output mass

On A, the conditional weights of B are t(1-t) and (1-t)^2, so B is Ber(t), independently of the candidate bits and of q. Its actual next-row probabilities are t and r because X_N=0.

The channel does not test X_N before acting on B. That final value enters only the subsequent mathematical conditioning. On the all-zero candidate branch, S=1 has already consumed the edit, whereas S=0 leaves it available for the independent endpoint coin. Hence T_q=rho/(1+L_q), and the displayed W=1 mass and posterior are precisely the candidate's formulas.

For each scaffold on this branch the observation mass is f_q(H)g_q(H)ell_q(1). These are probabilities under each individual fixed source, not targets averaged over a prior on q.

Exact subtraction yields the displayed posterior gap. Multiplying it by the minimum observation mass cancels only one of the two ell denominators. Since max ell<=t+rho, the remaining factor is rho t/(rho+t). This correctly retains the rare displayed-output mass. Summing the common scaffold overlap and dividing the two-risk inequality by two gives the stated constant times rho t/(rho+t), hence c_beta min{rho,M^(-1/3)}.

At rho=0 the contribution is zero and all posterior denominators remain positive because t>0. The sources and the channel rule do not need to be changed as rho approaches zero. Tau and the onset horizon depend on beta, not on rho.

## 5. Independent protected k/M witness

The iid alternatives p_-=k/(8M) and p_+=k/(4M) lie in the stated source class: P^2(s,v)=Pi_p(v) for every pair state. Their future symbol is independent of the observed past and the channel, so the source-specific posterior target remains exactly p on every supported output.

The output 0^N occurs exactly when the first M inputs contain at most k ones and both protected terminal inputs are zero. Under either source, the interior mean is at most k/4, so Markov gives probability at least 3/4 for the first event. Independence and p<=1/4 give probability at least 9/16 for the second. Their product is at least 27/64.

The target gap at that one common output is k/(8M). The two-risk inequality therefore gives

    max Risk >= (1/2)(27/64)(k/(8M))
             =27k/(1024M).

No global closeness between the clean histories or displayed laws is required. The channel is disclosed and common to both alternatives. This is directly a posterior-target lower, not a latent-row lower transferred through Jensen.

## 6. Combining witnesses and remaining boundaries

Combining identity, protected-budget and rare one-edit witnesses uses a maximum over separate admissible channels and source pairs. It does not combine their edit operations or add their budgets. Padding base states permits them to sit in the same class with a fixed base-state allowance at least four and the stated paid counter/time tables.

For k=1, the k/M term is dominated by the clean baseline, and the known statistical upper matches M^(-1/2)+min{rho,M^(-1/3)}. The exact dyadic computational upper applies directly on its input interface. For a positive general rational rho, an upper dyadic certificate between rho and min{2rho,1} preserves this order while charging its actual precision. This supports the stated order claim without retroactively changing the exact-certificate theorem.

For general k, the protected witness now supplies k/M, while the one-edit witness still supplies only min{rho,M^(-1/3)}. No matching growing-k endpoint term is proved. Nor do these results establish optimal Transformer resources, a homogeneous fixed-kernel lower, an all-initial-law extension, a fixed-transition-floor obstruction, a single fixed-source asymptotic impossibility, training achievability, numerical correctness, or external novelty.

The rare alternatives vary with the horizon and have vanishing transition entries, while retaining the stated fixed minorization certificate. The channels are online because their actions use only current/past raw inputs and paid public timing, not because the proof avoids conditioning on retained future observations. That distinction is correctly maintained in the reviewed drafts.
