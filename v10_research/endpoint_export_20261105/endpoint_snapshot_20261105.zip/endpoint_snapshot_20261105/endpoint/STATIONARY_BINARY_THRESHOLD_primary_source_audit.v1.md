# Primary-source comparison: stationary binary known-channel prediction and the square-root edit threshold

Date: 2026-11-05 UTC. Analytical literature comparison only. No novelty certification, public upload, numerical experiment, executable scientific check, or change to the reviewed theorem files. File inspection, present-time hashing, primary-source web reading, and creation of this report were the only operations.

## 1. Findings first

The two local results concern a specific uniform statistical experiment, not the general task of predicting a Markov chain through ordinary observation noise. At fixed beta in (0,1) and fixed rho>0, their combined conclusion is that uniform consistency over stationary binary D2(beta) sources and all disclosed, future-blind, strict-Hamming offline channels with per-input terminal-pair-change probability at most rho holds exactly when k=o(sqrt(M)), where N=M+2. This is a consistency threshold, not a sharp minimax risk formula.

Three closely related components have clear antecedents:

- Log-likelihood-ratio oscillation controlling conditional beliefs is established in Chan-Darwiche (2002/2005) and Hilbert-projective-metric work. Generic posterior stability and cancellation of unchanged local factors should not be presented as new.
- Conditionally independent sites selected from an independent set of a Markov random field are established machinery, including the conclique literature. The local construction must additionally arrange identical conditional Bernoulli probabilities, an eligibility rule determined by retained coordinates, and a suitable count-erasing channel.
- Universal prediction of a clean binary process from noisy observations is established, including Weissman-Merhav (2004). Its observation models and cumulative-loss conclusions do not imply the local uniform terminal-posterior theorem.

The closest inspected sources did not state the full combination of a disclosed arbitrary offline Hamming channel, stationary binary source class, model-specific clean-future conditional-law loss, and necessary-and-sufficient square-root budget criterion. This is a limited search result, not evidence of priority or a novelty certification.

The lower is a horizon-indexed two-source overlap construction. It is neither exact equality of output laws nor pointwise inconsistency for one fixed source. Ordinary robust-estimation appearances of sqrt(N) often mark where contamination starts to change the clean estimation rate, which is a different claim from failure of consistency at that budget.

## 2. Exact local experiment and conclusion

### Target and information

For a fixed stationary true source theta and a disclosed channel C, the target is

    p_(theta,C)(z) = Law_(theta,C)(X_(N+1) | Z=z).

The joint experiment factors as

    P_theta(x) C(z|x) theta_(S(x))(y).

The channel can inspect the full clean history and use independent randomness. It cannot inspect the future or share future source innovations. Corruption changes observations, not the physical source state. The target averages the latent clean history under this fixed source and channel, not a prior over unknown source hypotheses.

The estimator receives C, not the realized seed, branch, edit mask, latent count, or scrambling sign. Its loss is expected TV to the above distribution. In the binary case this is absolute error in the conditional probability. It is not the probability of guessing the next realized bit incorrectly, nor normalized cumulative decision loss, nor error in reconstructing the hidden terminal row itself.

A precise uniform formulation allows a predictor family q_M(C,z), and then takes worst-case risk over theta and admissible disclosed C at each horizon. Admissibility requires the strict per-realization edit cap and the per-input terminal reliability bound. C may depend on the public horizon. “Known” does not mean memoryless, online, invertible, sample-oblivious, or computationally easy to evaluate. “Source-independent” means the same exhibited algorithm is used for both source hypotheses, not that its output is independent of the observed sample.

### Upper and lower quantifiers

The upper v2 gives, for fixed beta>0, a channel-aware predictor with uniform risk at most

    min{1, C_beta [(k+1)/sqrt(M)]^(1/3)}.

It does not require an endpoint-reliability restriction and therefore applies to every rho. The exponent 1/3 is an upper-bound optimization, not a matching minimax rate. At k=0, the clean branch is sharper.

The lower gives, for every fixed beta in (0,1), rho>0, and a>0, a positive c_(a,beta) and an eventual horizon such that one common disclosed channel with budget floor(a sqrt(M))+1 and two stationary source alternatives have maximum risk at least c_(a,beta) rho. The onset horizon may depend on a, beta, and rho. The constant is not asserted uniform as a tends to zero, beta tends to one, or rho varies with M.

If k_M/sqrt(M) does not tend to zero, choose a subsequence bounded below by some epsilon>0 and then a smaller fixed a. Eventually floor(a sqrt(M))+1<=k_M along that subsequence. The lower prevents uniform consistency there; the upper proves consistency in the complementary little-o regime. N=M+2 does not change the square-root order.

This iff statement does not cover moving beta, moving rho, rho=0, beta=0, or causal-only channel classes. At beta=1, the certificate forces IID sources; the local note instead obtains empirical-frequency risk at most 1/(2sqrt(M))+k/M. Identity and other benign known channels are not claimed to have a square-root impossibility threshold.

## 3. What the binary lower adds relative to the earlier count construction

The earlier four-generated-symbol construction placed a separate IID nuisance coordinate beside a Markov signal and used a fifth marker. The present lower works in a single binary alphabet with genuinely second-order, stationary, uniformly positive source transitions. There is no unused marker, vanishing stationary minority mass, rare nuisance symbol, or arbitrary initial distribution.

### Exact conditional IID extraction

The clean order-two likelihood is a product of factors on consecutive triples, times the stationary initial-pair mass. Candidate sites are spaced three apart; no triple factor contains two candidates. The first two and final three positions are excluded. Eligibility depends only on four noncandidate neighbors, all required to be zero.

Consequently, after retaining the scaffold H, eligible bits have disjoint likelihood factors and a common conditional parameter

    p(q) = A(q)/(A(q)+B(q)),
    A(q) = (q-e)(q+e)(1-q-e),
    B(q) = (1-q+e)^3.

The noncandidate-neighbor restriction is essential: it makes the random eligibility mask recoverable from H without conditioning on the selected bit's own value. Conclique independence alone would not make differently situated bits identically distributed. The common zero-neighbor pattern supplies that extra fact. The final clean bit is conditionally independent of the eligible collection given the retained terminal context.

### Exact count normalization, not approximate histogram erasure

Given n and a binomial count S=s, the eligible configuration is uniform over weight-s words. Uniformly deleting ones or adding zeros to reach weight m=floor(n p0) produces a uniform weight-m word for every permitted s. For example, for s>=m and any given output subset of size m, its probability is

    binom(n-m,s-m) / [binom(n,s) binom(s,m)]
       = 1/binom(n,m).

For s<m the analogous identity is

    binom(m,s) / [binom(n,s) binom(n-s,m-s)]
       = 1/binom(n,m).

These are elementary counting identities, not executable checks. They explain exact independence of the normalized word from the old count and its sign, conditional on H and the active event. Merely replacing the count by its mean, or asserting that normalization “mostly hides” it, would not establish the required full-output factorization.

The channel acts only inside a predetermined count window of radius floor(a sqrt(M)); outside it, it returns identity. Thus its interior cost is strictly bounded on every input and realization. The terminal XOR adds at most one edit. All interior edits avoid the terminal pair, and the independent rho coin bounds the per-input terminal-change probability. The displayed centered count identifies the active event exactly without an extra symbol.

### Where the scale enters

The alternatives are q_0 +/- gamma/sqrt(M), not two fixed separated parameters. The number n of eligible bits has positive linear density, while conditional binomial fluctuations are order sqrt(M). The two count means differ at that same scale. A fixed-width window on the sqrt(M) scale therefore has positive probability and retains a positive difference in the conditional sign probability under the two alternatives.

Uniform Berry-Esseen control is applicable because n>=cM on the typical scaffold event and p(q) stays inside a compact subset of (0,1). The rounding errors are lower order. This is a binomial triangular-array argument conditional on H, not a claim that the original dependent Markov tokens are IID.

Scaffold laws are close by a chain-rule KL bound and data processing. They are not equal. The full observation mass keeps scaffold, active probability, uniform normalized-word factor, and terminal factor. The proof uses

    R_+ + R_- >= sum_z min(P_+^Z(z),P_-^Z(z))
                              TV(p_+(z),p_-(z)).

The retained variables can still carry information about the source. Positive overlap suffices. A transition-table difference tending to zero does not imply that full length-M path laws tend to each other in TV; local differences accumulate across the path. No contradiction to fixed-model consistency or ordinary parameter continuity follows.

## 4. What the binary upper localizes

At a fixed displayed z, the true and fitted latent-history posterior weights share C(z|x). Their ratio differs only through the clean source likelihood, up to a normalization constant. Let F_z={x:C(z|x)>0}. Under common positive support,

    H(post_theta,post_hat)
      = osc_(x in F_z) log(P_hat(x)/P_theta(x)),

where H is Hilbert log-ratio oscillation. Channel zeros outside F_z cause no problem; positivity is needed on the retained support.

Any two members of F_z differ at no more than 2k positions. Hence only at most 6k order-two triple factors differ when evaluating the oscillation. All other terms cancel even though the fitted transition table changes every temporal factor. The initial-pair contribution is separately controlled. This is more specific than simply perturbing a few CPTs in a fixed network: all source CPTs may change, but the compared latent paths agree except near a few edited positions.

Thus the local upper combines an established deterministic conditional-belief inequality with a Hamming-support restriction and finite-order factorization. It then inserts stationary occupation estimates, an independently fitted positive initial-pair law, and a binary minority branch. The nearly deterministic branch is important for uniformity over sources with small stationary masses. The surrogate initial law need not be stationary for its fitted table; the true generating source remains stationary.

The fitted quantities can depend on z because this comparison is pointwise at z. No observation-probability lower bound is being assumed. The predictor may require a sum over exponentially many histories. There is no efficiency theorem for arbitrary disclosed real-valued kernels.

## 5. Primary-source comparisons

### A. Conditional-belief stability and local factor changes

Hei Chan and Adnan Darwiche, *A Distance Measure for Bounding Probabilistic Belief Change*, AAAI 2002; expanded in International Journal of Approximate Reasoning 38(2), 149-174, 2005.

- Primary conference paper: https://cdn.aaai.org/AAAI/2002/AAAI02-081.pdf
- Journal identifier: https://doi.org/10.1016/j.ijar.2004.07.001

Inspected: Definition 1, Theorem 2, probability form of the conditional-odds bound, and Theorem 3 for changed local conditional tables. Their distance is the oscillation of the log ratio of two probability masses. It controls arbitrary conditional beliefs, and local table changes can determine the global distance. This is direct antecedent for the generic stability device. It does not itself state the Hamming-preimage argument, a statistical Markov estimator, or the present uniform-consistency threshold.

Samuel N. Cohen and Eliana Fausti, *Hyperbolic contractivity and the Hilbert metric on probability measures*, arXiv:2309.02413, v2 dated November 2024; journal publication not verified in this audit.

- https://arxiv.org/html/2309.02413v2
- https://arxiv.org/abs/2309.02413

Inspected in the focused source review: Theorem 5.1 and Corollary 5.2.1. Their total-variation norm is twice conventional probability-TV. Their sharp inequality therefore translates to TV(mu,nu)<=tanh(H(mu,nu)/4)<=H/4. The identification of H with the restricted posterior log-ratio oscillation above is our application, not a claimed theorem about Hamming attacks in that paper. This sharper constant would not change the local threshold order; the local proof uses a valid coarser bound.

### B. Independent-set conditional independence

Mark S. Kaiser, Soumendra N. Lahiri, and Daniel J. Nordman, *Goodness of fit tests for a class of Markov random field models*, Annals of Statistics 40(1), 104-130, 2012.

- https://arxiv.org/pdf/1205.6086
- https://doi.org/10.1214/11-AOS948

Inspected: model definition, conclique construction, and Theorem 2.1. The paper uses non-neighboring sets and establishes IID uniform generalized residuals within them. It does not state that the untransformed observations of every conclique are IID Bernoulli. That stronger property in the local lower comes from its shared retained-neighbor pattern and explicit likelihood calculation.

Andee Kaplan, Mark S. Kaiser, Soumendra N. Lahiri, and Daniel J. Nordman, *Simulating Markov Random Fields With a Conclique-Based Gibbs Sampler*, Journal of Computational and Graphical Statistics 29(2), 2020; arXiv version 2019.

- https://arxiv.org/pdf/1808.04739
- https://doi.org/10.1080/10618600.2019.1668800

Inspected: Sections 2 and 3.1. Independent simultaneous updates within a conclique exploit the same conditional-factorization principle. This supplies relevant methodological background, not an adversarial normalization or posterior-prediction lower bound. The local use of those sites to conceal a sufficient count and then scramble the terminal state is a separate construction.

### C. Predicting clean binary outcomes from noisy histories

Tsachy Weissman and Neri Merhav, *Universal prediction of random binary sequences in a noisy environment*, Annals of Applied Probability 14(1), 54-89, 2004.

- Author-hosted published paper: https://webee.technion.ac.il/people/merhav/papers/AAP158.pdf
- https://doi.org/10.1214/aoap/1075828047

Inspected: model, conditional-mixing discussion, definitions of universality, BSC results, and continuous-observation assumptions. The work studies asymptotic average decision loss for clean binary outcomes from noisy pasts. Its general framework includes joint stationary processes and some dependent noise; the concrete universal constructions inspected use structured observation models, including fixed memoryless channels. It does not license arbitrary horizon-indexed offline count normalization. Its twofold BSC universality for absolute decision loss is not identification of conditional probabilities in TV: a Bayes-optimal action can agree across different conditional probabilities. The time-average and pointwise-versus-uniform distinctions also matter.

Tsachy Weissman, Neri Merhav, and Anelia Somekh-Baruch, *Twofold Universal Prediction Schemes for Achieving the Finite-State Predictability of a Noisy Individual Binary Sequence*, IEEE Transactions on Information Theory 47(5), 1849-1866, 2001.

- https://web.stanford.edu/~tsachy/pdf_files/Twofold%20universal%20prediction%20schemes%20for%20achieving%20the%20finite-state%20predictability%20of%20a%20noisy%20individual%20binary%20sequence.pdf

Inspected: introduction and performance definitions. The benchmark is asymptotic fraction of errors for finite-state predictors under a BSC, not the local terminal distribution-estimation loss. Its parameter-free BSC result should not be described as a contradiction to known/unknown arbitrary-channel distinctions.

Tsachy Weissman, Erik Ordentlich, Marcelo J. Weinberger, Anelia Somekh-Baruch, and Neri Merhav, *Universal Filtering Via Prediction*, IEEE Transactions on Information Theory 53(4), 1253-1264, 2007.

- Author prepublication version: https://webee.technion.ac.il/people/merhav/papers/p86.pdf

Inspected: Section 2 and Theorem 1. The channel matrix is known and full row rank; observations arise through a DMC. The guarantee compares cumulative filtering loss with a finite reference class. Neither arbitrary disclosed block channels nor the terminal-posterior square-root threshold follow from it.

### D. A square-root contamination count is not necessarily a consistency threshold

Charita Dellaporta, Jeremias Knoblauch, Theodoros Damoulas, and Francois-Xavier Briol, *Robust Bayesian Inference for Simulator-based Models via the MMD Posterior Bootstrap*, AISTATS 2022, PMLR 151, 943-970.

- https://proceedings.mlr.press/v151/dellaporta22a.html
- https://arxiv.org/pdf/2202.04744

Inspected: IID setup, Section 4.3, Corollary 5; retrieved arXiv version is v3. Under Huber mixture contamination and a bounded kernel, the clean-distribution MMD error has an approximation term plus O(epsilon+n^(-1/2)). The paper identifies sqrt(n) outliers as the scale retaining the clean rate. This is a rate crossover, not a consistency impossibility threshold: epsilon tending to zero still permits vanishing error in the well-specified case. The theorem's IID mixture also does not provide a deterministic at-most-k replacement guarantee, regardless of informal outlier-count wording. Its posterior is over model parameters, unlike the local fixed-source latent-history target.

### E. Normal approximation and broad conditioning sensitivity

Irina Shevtsova, *On the absolute constants in the Berry-Esseen type inequalities for identically distributed summands*, 2011.

- https://arxiv.org/pdf/1111.6554

Inspected: classical inequality and Theorems 1-2. Uniform CDF error is controlled by the standardized third absolute moment divided by sqrt(n). For Bernoulli parameters in a compact interior interval, this gives the uniform bound needed after conditioning on H. Exact optimal constants are irrelevant here. This supports the approximation step, not the attack mechanism or threshold.

Houman Owhadi, Clint Scovel, and Tim Sullivan, *On the Brittleness of Bayesian Inference*, SIAM Review, 2015.

- https://arxiv.org/pdf/1308.6306
- https://doi.org/10.1137/130938633

Inspected in the focused source review: formal target and Theorem 1. The work concerns priors over data-generating distributions, model perturbations, and conditioning on sufficiently small observation balls. It is broad background on conditioning sensitivity. Calling the local lower merely “Bayesian brittleness” or rare-evidence denominator instability would obscure its different fixed-source target, known channel, and constant-probability overlap mechanism.

## 6. How to position the result without overclaiming

Suggested concise wording:

> Conditional-belief stability under log-likelihood-ratio oscillation and conditional independence on separated graphical-model sites are established tools. We combine a Hamming-supported posterior comparison with stationary binary estimation to obtain consistency below square-root edit budgets, and a conditional-binomial normalization channel with local source alternatives to show that this budget order is necessary for uniform consistency. The channel is disclosed, offline, and future-blind; the target is the true clean-future conditional law for each fixed source.

Do not claim novelty for the generic stability lemma, independent-set conditioning, binomial type symmetry, normal approximation, or two-point overlap method. An assessment of any narrower originality would require a broader review than this targeted comparison. Nothing here establishes a neural architecture, efficient algorithm, sharp risk exponent, fixed-source impossibility, or the same threshold for online or memoryless channels.

The prior source audit remains relevant for unknown-channel denoising, ordinary HMM identifiability, and filter robustness. Those discussions are not duplicated here. The new lower removes the earlier alphabet/marker barrier; it does not make that earlier heat-bath argument a valid proof for a disclosed channel.

## 7. Historical scope statements and provenance

The frozen upper v2 and its review correctly describe what was established when written. Their open-gap lines saying that necessity of k=o(sqrt(M)) and the stationary ternary case remain open are now superseded by the later binary lower and `KNOWN_CHANNEL_stationary_ternary_one_edit_lower.md`. This does not invalidate the upper theorem. A current synthesis should cite the later results rather than repeat those historical open-gap statements. No frozen file was edited in this audit.

Complete local upper, lower, and corresponding reviews were read. The ternary note's result/model section was inspected only to confirm this chronology. Present-time input hashes, captured during this audit, are:

- `KNOWN_CHANNEL_stationary_binary_sqrt_lower.v1.md`: `c75ef32562b08f1606189e060d3ab014c589804e210bed076aedb0f759eaa946`.
- `KNOWN_CHANNEL_stationary_binary_upper.v2.md`: `e4b5840206bff6735b5cce4a6dfeb70d9ea2568341dc0128773fa6c68327156b`.
- `KNOWN_CHANNEL_stationary_binary_sqrt_lower_independent_review.v1.md`: `24b22ae03baf29e669c6c5a4ee49d2b6d9a65cc2fc153e1bc43c542272c124d1`.
- `KNOWN_CHANNEL_stationary_binary_upper_independent_review.v2.md`: `bd324de458255b705bdfd46da46efbe36ba4b941ce1fc26f8393b0d2e8ec1141`.
- `POSTERIOR_CHANNEL_primary_source_audit.v1.md`: `be5607ea258806784392f5b3438349bbb89e45c876474f0e8b6a2872101fdb59`.

These identify the bytes read now, not an earlier historical state. The independent mathematical reviews report scoped analytical PASS; this document does not upgrade that status to formal verification or external peer review. Primary-source reading scopes are stated above; not every proof or cited reference was rechecked. Search results and secondary summaries were used for discovery, not as theorem authority. Retrieval failures on one hosted copy were resolved through author-hosted or arXiv copies; no permission boundary was bypassed. No scientific executable check or public write occurred.
