# Strict one-edit, one-state hazard reduction

5 November 2026 UTC. Analytical research note. No scientific execution, numerical diagnostics, or public writes. This note does **not** prove the proposed no-floor root-M upper and does **not** give a counterexample to it. Its new lemmas require independent review.

## 1. Question and exact scope

Let N=M+2. The source is a stationary binary homogeneous order-two Markov chain with pair kernel P, stationary pair law Pi, and the all-state certificate P^2(s,t)>=beta Pi(t), for a fixed 0<beta<1. Write pi for its one-symbol marginal and m=min(pi(0),pi(1)).

The channel has one base state, a separately charged actual edit counter e in {0,1}, public time-indexed rational rows, and no access to the future innovation. It changes at most one bit on every path. Its disclosed rows do not depend on the unknown source parameter. The requested prediction target is the source-specific posterior

    p_theta,C(z)=E_theta,C[theta_(X_(N-1),X_N)(1) | Z=z].

The open question is whether, uniformly over these channels and all endpoint certificates rho, its minimax integrated absolute error is O_beta(M^(-1/2)) without a positive transition floor. The reviewed general bound remains O_beta(M^(-1/2)+min{rho,M^(-1/3)}); the clean lower is Omega_beta(M^(-1/2)).

## 2. One hidden edit time and the exact endpoint reduction

Set a_i(x)=K_i(1-x|x,e=0). Once the counter is one, strictness forces the identity row. Let J be the first and only edit time, or infinity if no edit occurs. Conditional on a fixed raw word x,

    Pr(J=i | X=x)=a_i(x_i) product_(h<i)(1-a_h(x_h)).       (H1)

For a displayed word z define x^(0)=z and x^(j)=z with bit j flipped. Then the source-independent coefficients are

    c_0(z)=product_(i=1)^N(1-a_i(z_i)),
    c_j(z)=a_j(1-z_j) product_(i<j)(1-a_i(z_i)).            (H2)

The actual observation likelihood and target are exactly

    D_theta(z)=sum_(j=0)^N c_j(z) P_theta(x^(j)),
    p_theta,C(z)=sum_j w_theta,j(z) g_theta(x^(j)),
    w_theta,j(z)=c_j(z)P_theta(x^(j))/D_theta(z),
    g_theta(x)=theta_(x_(N-1),x_N)(1).                       (H3)

No division by c_0 or P_theta(z) is needed. All early j<=N-2 have the same terminal pair as z, so only the two endpoint leaves j=N-1,N have a distinct g value. In particular, every endpoint-edit preimage has an entirely clean prefix; every early-edit preimage has an unchanged terminal pair.

For any two fixed source laws P,Q, write p_P^Q(z)=E_(P,C)[g_Q(X)|Z=z]. A useful exact finite-difference identity, on outputs with positive P_Z and Q_Z, is

    P_Z(z)[p_P^Q(z)-p_Q(z)]
      = [1/(2 Q_Z(z))] sum_(j,l) c_j c_l
          [P(x^(j))Q(x^(l))-P(x^(l))Q(x^(j))]
          [g_Q(x^(j))-g_Q(x^(l))].                         (H4)

Only pairs with at least one endpoint leaf contribute. The direct target change is separate:

    E_(P,C)|p_P-p_P^Q| <= E_P|g_P-g_Q|.                    (H5)

Equation (H4) retains the full denominator and every early competing preimage. Singular outputs need a separate support argument. A fitted law depending on z cannot be substituted for fixed Q in an integrated bound without proving the associated measurability step.

## 3. A stationary hazard-survival bound

Define the unconditional hazard at position i by

    lambda_i=sum_(c=0,1) pi(c)a_i(c),   0<=lambda_i<=1.

Then for any deterministic interval I of consecutive raw positions,

    E product_(i in I)(1-a_i(X_i))
       <= exp[-(beta/2) sum_(i in I) lambda_i].            (H6)

Proof. Split I into its two parity classes. The full product is no greater than the product on either one class. Along positions spaced two apart, conditional on the previous pair and all earlier sampled factors, P^2>=beta Pi gives the next-bit marginal lower bound beta pi. Hence the expectation of the sampled product is at most product_(i in class)(1-beta lambda_i). The first sample is stationary, so it satisfies this same bound. At least one parity class has at least half the total lambda mass. Use 1-u<=exp(-u).

The same argument works backwards from any fixed future window. The reversed stationary pair chain satisfies

    (P_rev)^2(v,u)=Pi(u)P^2(u,v)/Pi(v)>=beta Pi(u)

on its stationary support. Fix a block W_i=(X_(i-r),...,X_(i+s)), with r,s fixed nonnegative integers and indices in range. For every block value w of positive probability,

    E[product_(h<i)(1-a_h(X_h)) | W_i=w]
       <= exp[-(beta/2) sum_(h<=i-r-2) lambda_h].           (H7)

To see this, discard the last r+1 survival factors before i. Start the reversed pair chain at (X_(i-r),X_(i-r+1)); when this pair is not fully specified by the conditioning, average over its conditional law. Each sampled pair at least two steps earlier satisfies the same uniform lower bound. The two parity argument applies for either initial distribution. Conditioning on the remainder of W_i does not alter the reverse transition kernel before this starting pair.

## 4. Palm-type domination at the actual edit time

For a fixed local window size r+s+1 and any word w with central symbol c=w_r and pi(c)>0, equations (H1) and (H7) imply

    sum_(i:r+1<=i<=N-s) Pr(J=i,W_i=w)
       <= C_(beta,r) Pr(W=w)/pi(c),                       (H8)

where one explicit finite choice is

    C_(beta,r)=exp[(beta/2)(r+2)]/(beta/2).

Here Pr(W=w) is the stationary probability of that window. In particular, for a nonnegative function f,

    E[1_{r+1<=J<=N-s} f(W_J)]
       <= C_(beta,r) E[f(W)/pi(X_center)].                (H9)

Zero-marginal symbols are omitted from the right side; they have zero actual probability.

Proof. Let b=beta/2 and A_i=sum_(h<i)lambda_h. The exponent in (H7) omits at most r+1 terms of A_i, each at most one. Thus the left side of (H8) is at most

    Pr(W=w) exp[b(r+1)] sum_i a_i(c) exp(-b A_i).

Use pi(c)a_i(c)<=lambda_i and

    sum_i lambda_i exp(-b A_i)
      <= exp(b) integral_0^infinity exp(-b t) dt
      =exp(b)/b.

For the integral comparison, each interval [A_i,A_i+lambda_i] has length at most one; its exponential integral is at least exp(-b) lambda_i exp(-b A_i). This proves (H8)-(H9). No independence between the edit time and the raw trajectory is assumed.

The bound is for the **actual raw window at the actual first edit**. It does not bound the local window in another posterior preimage or in the displayed word.

## 5. Large cumulative hazard suppresses the endpoint branch

The endpoint can change only if no edit occurred before N-1. Therefore

    Pr{terminal pair changes}
       <= min{rho, exp[-(beta/2) sum_(i<=N-2)lambda_i]}.    (H10)

Consequently the existing robust displayed-row predictor, whose protected-endpoint estimation term is O_beta(M^(-1/2)+M^(-1)), has the source-wise bound

    Risk_theta <= C_beta M^(-1/2)
         +min{rho, exp[-(beta/2)sum_(i<=N-2)lambda_i]}.     (H11)

In particular the desired root-M rate is already obtained on the source/channel region sum lambda_i >= (log M)/beta. This is a pointwise region, not a full uniform theorem: lambda_i depends on the true unknown marginal pi. No source-dependent choice of predictor is being claimed; the displayed-row predictor itself is fixed. The difficult channels/sources are those with relatively small cumulative hazard, where endpoint survival cannot simply be discarded.

For the precise import, take the protected selected-row predictor q_k from Section 2 of `EPR001_endpoint_probability_interpolation.md`, with k=1, and repair the original channel by returning the raw word whenever its terminal pair would change: the original good-set latent-row loss is bounded by the repaired channel's unconditional protected-risk guarantee, while the bad set costs at most its actual probability because the loss is at most one. Conditional Jensen then transfers this unconditional latent-row upper to the source-specific posterior target; this establishes the coefficient-one endpoint term in (H11) without conditioning the protected-risk theorem on a channel-selected event and without needing the clipped wrapper from EPR001.

## 6. Only the all-minority triple is problematic for a crude count-covariance route

Choose the minority label to be 1 for notation. Let T_abc(X) count a fixed triple abc among the M training transitions. Any two preimages of one displayed word differ in at most two bits, so their triple counts differ by at most six. With g(X)=theta_(X_(N-1),X_N)(1), stationarity gives Eg=m. For two independent posterior draws X,X' given Z,

    Cov(g,T_abc|Z)
      =(1/2) E[(g(X)-g(X'))(T_abc(X)-T_abc(X'))|Z].

It follows, for every known strict-one-edit channel, even without S=1, that

    E|Cov(g,T_abc|Z)| <= 6m.                             (H12)

The source certificate implies

    Pr(X_1=a,X_2=b,X_3=c)>=beta^2 pi(a)pi(b)pi(c).

For every triple except 111, its right side is at least beta^2 m^2/2. Thus

    E|Cov(g,T_abc|Z)|
      <= (6 sqrt(2)/beta) sqrt(Pr(abc)),   abc!=111.       (H13)

This removes seven of the eight count coordinates from one tempting Fisher-normalized proof. The stationary initial-pair score and direct future-row derivative remain distinct terms and are not covered by (H13). For 111, the only automatic probability lower bound is beta^2 m^3, so (H12) leaves a factor m^(-1/2) gap. When Pr(111) itself is already of order m^2 or larger, (H12) suffices there too.

Neither (H13) nor even a suitable full score bound would, alone, establish a minimax estimator with data-dependent fitted parameters.

## 7. Why the stopping-time lemma does not finish the proof

The posterior covariance or cross-product in (H4) pairs two raw histories. One history may use an early edit at j; the other may use an endpoint edit, so its raw bit at j is the displayed, unedited bit. The score at j in the second history is evaluated at a **counterfactual edit location**, not at its own stopping time. Equations (H8)-(H9) cannot be applied to that cross term.

This distinction is quantitatively substantial. In the reviewed rare family

    theta_00(1)=theta_01(1)=t,
    theta_10(1)=r,
    theta_11(1)=qt,

the stationary identities give

    Pr(101)=u t r/(1-r),
    Pr(111)=u q t^3/[(1-r)(1-qt)],
    Pr(101)/Pr(111)=r(1-qt)/(q t^2).                      (H14)

A legal one-state hazard that flips the middle 0 can therefore create a displayed 111 from a raw 101 whose mass is larger by order t^(-2). Any attempt to transfer (H8) directly to the displayed or synthetic window is false. The posterior weight of the competing raw history can compensate for this ratio, but that compensation must be retained inside the endpoint-weighted denominator in (H4). Merely charging the number of edits or applying raw-source mixing after conditioning on the hidden counter does not prove it.

The current narrow unresolved step is an endpoint-weighted finite-difference estimate for these rare all-minority local likelihood ratios, uniform over arbitrary time hazards, including zero survival factors. It must retain the actual observation mass, competing early-edit likelihoods, source-row changes, and source-dependent hidden-counter weights. No such bound is asserted here.

## 8. Resource and quantifier ledger

The exact representation and lemmas concern one base state plus the true two-valued edit counter. A public time-indexed table contains O(N) rows per input/counter combination; rational bit lengths and any internalized clock are separate costs. No hidden mode, raw context gate, future lookahead, or source-specific channel table was introduced.

The open upper has quantifiers: for every disclosed legal channel C, one estimator q_C independent of theta, uniformly over stationary theta in D2(beta). The source-wise survival estimate (H11) does not change those quantifiers into an estimator chosen using the unknown source. The finite comparison (H4) uses one common C under both fixed alternatives.

## Source trail

- KNOWN_CHANNEL_one_state_counter_lower.candidate.v2.md, especially its exact k=1 formula.
- KNOWN_CHANNEL_one_state_rare_rho_lower.candidate.v1.md and its independent review.
- KNOWN_CHANNEL_one_state_iid_score_barrier.addendum.v1.md.
- KNOWN_CHANNEL_one_state_full_score_rho_barrier.candidate.v2.md.
- KNOWN_CHANNEL_one_state_remote_endpoint_score_barrier.candidate.v1.md.
- KNOWN_CHANNEL_one_state_centered_likelihood_flow.research.v1.md.
- KNOWN_CHANNEL_fixed_suffix_finite_predictive_upper.candidate.v1.md.
- KNOWN_CHANNEL_stationary_binary_rho_interpolation.v1.md.
- state_suffix_bundle_20261105T113847Z/endpoint_state_suffix_supplement.zh.v3.html.
