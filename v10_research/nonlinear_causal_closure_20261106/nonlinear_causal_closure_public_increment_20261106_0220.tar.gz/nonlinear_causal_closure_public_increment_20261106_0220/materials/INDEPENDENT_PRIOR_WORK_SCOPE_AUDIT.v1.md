# Independent exact-file audit: nonlinear closure provenance and scope

6 November 2026 UTC. Verdict: PASS as a source-faithful comparison and scope statement, not a priority or external-proof certification.

Reviewed source: `PRIOR_WORK_AND_SCOPE_COMPARISON.v2.md`.
SHA-256: `adc7184b3f6229f620844c582717a3f7794ad8a3b2a300c244f2556863b47c40`.

Directly read comparison records: `../ordered_causal_memory_20261106/PRIMARY_COMPARISON.v1.md` and `../current_frontier_prior_art_20261105/CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md`. Directly checked local mathematical sources include the old terminal obstruction v2, the rare-marker low-risk terminal obstruction v2, the common-control/prefix-Lipschitz examples, the ordered public-linear collapse and PreLN compilation, and the three current final candidates.

The overlap statements are supported by those sources:

- The nonlinear prefix-energy hard function, deterministic reduction and imported randomized Gap-Hamming lower already existed. The new file changes the normalized architecture and the usable softmax margin, not the communication theorem.
- The rare-marker construction already separates low prediction risk from worst-history simulation hardness and admits exponentially accurate cheap source-average simulation. Its first invocation has a three-dimensional value vector. The current scalar-head normalized program is correctly not described as a replacement or new proof of that low-risk result.
- The earlier global-mean replacement discards the first-order harmonic statistic. The current square/Taylor analysis retains it and improves this specified simulation residual. It does not improve the prediction risk of a source estimator.
- Taylor expansion of a nonlinear row value is explicitly separated from polynomial/Taylor approximation of the exponential attention kernel. No streaming-space optimum or new attention-feature representation is claimed.
- The current mixed-difference theorem is kept at the scope of one exact additive cut. Elementary ingredients, full-domain gain accounting and the prior compiler are not represented as new general methods.
- The Markov/n-gram papers are correctly treated as prior representation mechanisms, with separate training results in restricted settings. The two current concrete programs have explicitly nonvanishing prediction risk and do not compete as estimators.

Version 2 correctly distinguishes source-access provenance. The ordered-paper primary passages were checked in the immediately preceding recorded pass. Alman–Song and Chen depend on the 5 November current-frontier record, not those fresh ordered-paper retrievals. Hahn's correction supplement was not fetched again in either this pass or that immediately preceding ordered pass. The inherited Gap-Hamming primary check is not relabeled as a new retrieval or re-proof.

No new external search or paper fetch was performed for this audit. The verdict is based on faithful comparison with the exact recorded sources and on the independently audited local statements. It neither certifies novelty nor excludes unexamined subsuming results. No numerical model execution, training, experiment or upload was performed.
