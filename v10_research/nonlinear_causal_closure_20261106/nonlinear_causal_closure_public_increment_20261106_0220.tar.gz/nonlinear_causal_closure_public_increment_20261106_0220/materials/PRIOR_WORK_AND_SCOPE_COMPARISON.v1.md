# Nonlinear closure: exact overlap and scope comparison

6 November 2026 UTC. This comparison uses the fresh primary-paper checks recorded earlier today in ordered_causal_memory_20261106/PRIMARY_COMPARISON.v1.md and the exact local sources below. It does not claim another live paper retrieval or an independent re-proof of imported communication results. No priority certification is made.

## 1. What was already established locally

- REPEATED_ATTENTION_SIMULATION_BARRIER v4: scalar prefix banks can contain linearly many recoverable bits; full-bank reconstruction is a stronger task than simulating a terminal output. Reused distinction, not a new barrier.
- TERMINAL_SIMULATION_OBSTRUCTION v2: the nonlinear clipped-prefix-energy program with two scalar zero-score reads already gives constant-error deterministic and randomized interactive terminal communication lower bounds. Its original output is projection to probability registers. The present NORMALIZED_NONLINEAR_OBSTRUCTION adds the same positive-epsilon PreLN and ordinary-softmax contract as the currently accepted model, with explicit endpoint-gap adjustment. It does not invent the reduction or prove a new Gap-Hamming theorem.
- LOW_RISK_TERMINAL_OBSTRUCTION: a rare-marker mixture already proves that low prediction risk does not rescue worst-history simulation, while its source-average simulator remains cheap. The present scalar normalized hardness example is NOT a new low-risk obstruction, and the earlier mixed-value-channel construction is not silently treated as a scalar-head result.
- Evolving common-control and prefix-Lipschitz results: global-mean replacement gave O_c(N^-1/2) residual after Lipschitz propagation. TAYLOR_PREFIX_CLOSURE instead retains the public harmonic-weighted first-order statistic R along with M; a second-order remainder improves approximation of this specific nonlinear statistic to O_c(log N/N). This is a simulation-error rate, not a source-estimation risk rate.
- Ordered causal public-linear collapse and two-read PreLN compilation: public linear mixtures collapse exactly and their bounded reference programs can be compiled with a full prepared-vector error guarantee. The present programs retain that compiler, including the correction that all padding/copies/clears precede choosing small amplitude. The physical normalized nonlinear row bank is not asserted to satisfy the reference's algebraic identities.

## 2. Primary external antecedents and exact boundaries

### Chakrabarti and Regev

Source: https://arxiv.org/pdf/1009.3460 . The old terminal-obstruction audit inspected Theorem 2.6 and the worst-case randomized communication convention. Its Omega(n) Gap-Hamming lower is imported unchanged. Ordinary softmax changes the network output margin, not this external theorem. The present comparison does not represent the externally hard input distribution as a stationary order-two source.

### Hahn

Source: https://aclanthology.org/2020.tacl-1.11.pdf , with corrected proof supplement https://www.mhahn.info/files/transformers-proof.pdf . The prior comparison checked bounded-depth sensitivity and its dependence on architectural constants. It is a close source for stability/influence thinking, not a direct proof of the present conditional variance or communication bound. Frozen per-primitive gain is compatible with growing total gain at logarithmic depth; that distinction is already established and is not new here.

### Alman–Song and Chen et al.

Sources: https://arxiv.org/html/2302.13214v1 and https://arxiv.org/html/2606.07205v1 . The current-frontier primary comparison records polynomial exponential-kernel features and deterministic Taylor-moment summaries. The new Taylor correction here is a Taylor expansion of a NONLINEAR ROW VALUE f(prefix mean), not a new approximation of the exponential attention kernel. It should not be conflated with those attention-feature complexity theorems or called a new streaming-space optimum.

### Markov and n-gram representation papers

Sources: https://arxiv.org/html/2407.17686v1 (Rajaraman et al.), https://arxiv.org/pdf/2508.07208v2 (Ekbote et al.), https://arxiv.org/html/2607.02800v1 (D'Angelo et al.). Fresh relevant primary sections were checked in the immediately preceding ordered-causal comparison, not re-fetched for this note. They already establish ordered context reconstruction, few-layer empirical conditional models and, in separate restricted settings, training analyses. The present quadratic and hard programs have explicitly NONVANISHING second-order prediction risk; they neither compete with those estimators nor establish learning behavior.

## 3. Elementary mathematics not claimed new

Taylor's theorem with a bounded second derivative, stationary covariance summation, sigmoid derivative bounds, vanishing mixed differences characterizing affine functions on a Boolean cube, net quantization, and error propagation through a bounded-gain circuit are existing elementary tools. The local contribution is a contract-audited composition and explicit boundary:

- exact additive folding can fail under even smooth square updates;
- source-average approximation can nevertheless be much cheaper than worst-history reconstruction;
- high effective curvature/amplification can support the known hard terminal functions;
- the same frozen positive-epsilon normalized model contains both cases.

The exact mixed-difference certificate is necessary/sufficient for one specified additive terminal cut, not a minimal architecture theorem, efficient verification algorithm or characterization of every low-communication simulator. The curvature condition is sufficient and source-class dependent. Canonical-surrogate sharpness does not imply universal simulation optimality.

## 4. What remains open

No source-average communication lower is established for low-risk normalized nonlinear predictors on the unknown second-order class. No arbitrary nonlinear full-row compression, better statistical prediction rate, minimum layer count, trained realization or executed finite-precision behavior is proved. These distinctions must accompany any user-facing summary or paper positioning.
