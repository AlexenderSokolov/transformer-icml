# Nonlinear prefix-energy hardness survives the fixed positive-epsilon PreLN contract

6 November 2026 UTC. Analytical candidate v2; v1 is preserved. Independent review requested after explicitly fixing the common fully prepared original/ablation domains before precision selection. The communication-hard logical function and its encoding are existing v10 results. This file only transfers that known obstruction into the current normalized common model, with the changed output margins explicitly charged.

## 1. Frozen common model and conclusion

Use N binary raw onehot rows, public normalized positions, one synthetic zero-symbol terminal, full-prefix inclusive causal softmax, fixed width and fixed finite complete-state/matrix/full-bias/primitive-gain budgets, paid sequential local depth, all-feature PreLN with epsilon=1, gain=2 and shift=0, and final ordinary affine vocabulary logits plus softmax. Exactly TWO useful scalar-value attention invocations have Q=K=0. No pair/triple feature, crop, exact last-pair channel or source kernel is supplied. Parameters are source independent.

On the same horizon sequences as the existing terminal obstruction, there is such a network with D=O(log N), per-coefficient description O(log N) and untied total description O(log^2 N), for which:

- deterministic interactive terminal simulation with uniform TV error <=1/4 requires Omega(N) worst-case bits;
- randomized interactive simulation with TV error <=1/4 and success probability >=2/3 on every history requires Omega(N) bits on the Gap-Hamming subsequence;
- the randomized conclusion also holds under expected TV error <=1/16 over coins on every fixed history.

The normative envelope is one sufficiently large fixed constant envelope containing both this construction and the already-reviewed ordered two-read PreLN construction. It is not an unchecked identification with a particular old numerical M_K. The result does not say that every network with these resources is hard, or that source-average simulation is hard.

## 2. Existing logical hard program, not a new reduction

Import TERMINAL_SIMULATION_OBSTRUCTION.candidate.v2.md and its accepted audit. Its scalar first read supplies S_t/t, where S_t=sum_{i<=t}x_i and x_T=0. A paid O(log N) bounded tent-product circuit, clipped doubling and integer plateau circuit produce

    v_t=clip(S_t,-4,4)^2/16 in [0,1]

exactly on every raw history. The second scalar uniform head gives

    E_N=(1/(16T))sum_{t=1}^T clip(S_t,-4,4)^2.

After a public baseline b_tau, paid clipped doublings give

    F_N=clip(P(E_N-b_tau),0,1),
    P=2^ceil(log2 T), T=N+1.

The logical program has bounded complete states and per-primitive norms, fixed width, two useful heads and O(log N) counted stages. It is valid on every row/history, not only the communication encodings. Its crucial intervening nonlinear row transformation prevents using the public-linear collapse identity.

For N=8(m+1), the old AA/BB-aligned eight-sign block encoding of private a,b in {0,1}^m gives

    E_N=(12+8m+24J(a,b))/(16T), J=sum_j a_j b_j,
    b_tau=(12+8m+24tau)/(16T).

At tau=0, F_N is exactly 0 for disjoint and 1 for intersecting inputs. At m=2n, N=16n+8, tau=n/2 and duplicated/complemented n-bit inputs, J=n-d_H and F_N is exactly 0 or 1 on the two Gap-Hamming promises. The exact encoding and all-row proof are inherited, not rederived as a new hardness technique. The deterministic fooling-set proof yields m bits; randomized hardness imports Chakrabarti–Regev Theorem 2.6, https://arxiv.org/pdf/1009.3460, as already primary-checked in the old audit.

## 3. Paid bounded logits and correct softmax separation

Do NOT carry over the old probability endpoints 0 and 1 after an ordinary finite-logit softmax. Instead use reference logits

    ell=(4F_N-2,0),  Q_ref=softmax(ell).

They lie in [-2,2] times the fixed coordinate basis and are obtained by one bounded paid affine stage. On the communication promise,

    Q_ref(+)=sigma(-2) if F_N=0,
    Q_ref(+)=sigma(2)  if F_N=1.

Both are separated from threshold 1/2 by more than 3/8, since exp(2)>7. Constant softmax separation, not exact binary endpoints, is the required fact.

## 4. Exact-program PreLN compilation

Apply the already-reviewed TWO_READ_PRELN_COMPILATION v4 method to THIS bounded prefix-energy reference program and its new bounded logits. No logarithm approximation is required here. Explicitly append fixed scaled-logit paired copies, norm-padding to the standard prepared norm, and every copy/clear microstep. Let zeta=T^-2 and choose padding/complete-vector/restoration tolerances as the largest permitted dyadic constant multiples of zeta, using constants for this fixed enlarged width.

The common tube radius and stage/local-error gain bounds are chosen for the ORIGINAL and BOTH single-read-ablated FULLY PREPARED reference programs, using one unchanged physical preparation/restoration schedule for all three. Only AFTER all these microsteps and common fixed tube bounds are set, define m=O(log N) and choose eta=2^-M so C eta^2 L^m<=xi for the FULL prepared-vector error. The two uniform-head error formulas and local homogeneous overwrite recurrence apply separately exactly as in the accepted compiler. All reference maps (including plateau and terminal amplification) are continuous fixed-gain affine/ReLU primitives. Physical rows are not required to remain on the exact logical integer plateaus; the entire continuous circuit's error is propagated. With M=O(log N), the existing bounded-gain amplitude restoration and affine vocabulary head give

    sup_x TV(Q_phys(x),Q_ref(x))<=zeta.

Finally the exact consuming-matrix rescaling makes every LN gain two without changing physical trajectories. Thus this construction has the SAME positive-epsilon ordinary-softmax conventions as the ordered causal example. The new source program supplies the compiler premises; no new normalization theorem is assumed.

For these horizons N>=16, zeta<=1/289. Every encoded physical output therefore remains at distance more than 1/3 from 1/2, on its correct side. Both reads remain useful by comparison with their ablated bounded logical reference programs, using the same full preparation and approximation constants. A first-read ablation makes v_t=0 and thus F_N=0; second-read ablation likewise makes F_N=0, while some encoded inputs have F_N=1.

## 5. Communication lower with its changed constants

A deterministic simulator of Q_phys with TV error <=1/4 on every history must preserve the correct threshold side on all encoded inputs, because physical margin exceeds 1/3. It therefore computes the old non-disjointness function, and the inherited deterministic lower gives C>=m=Omega(N).

A randomized simulator with per-history success probability >=2/3 at TV error <=1/4 similarly solves Gap-Hamming with error <=1/3, so the same randomized Omega(N) lower applies even with arbitrary interaction. If only expected per-history TV error <=1/16 is given, then threshold failure requires approximation error at least 1/3; Markov's inequality gives failure probability <=3/16<1/3. The old epsilon<1/2 output threshold is deliberately NOT retained.

The output is a normalized binary vector. If a protocol is allowed an unnormalized half-l1 approximant, the old scalar conversion (1+qhat_+-qhat_-)/2 bounds scalar error by the same half-l1 tolerance and gives the same threshold reduction.

## 6. Risk and averaging distinctions

This is WORST-HISTORY terminal simulation hardness, not a source-average lower. All hard words have positive probability under interior Markov sources, but that support fact does not make the hard communication law a Markov source. No such transfer is asserted.

The program is also not a useful low-risk predictor. On fair IID signs, P(|S_t|<4)=O(t^-1/2) by the elementary binomial point-mass bound. Hence E(1-E_N)=O(N^-1/2). The baselines for tau=0 or tau=m/4 stay below a fixed number less than 1/2. Thus F_N->1 in probability; boundedness gives Q_ref(+)->sigma(2) in L1, and the vanishing compiler error gives

    E_IID TV(Q_phys,(1/2,1/2)) -> sigma(2)-1/2 >1/3.

This explicit constant risk prevents misreading the communication counterexample as a negative answer about statistically good source-average prediction. The existing rare-marker low-risk counterexample is a DIFFERENT prior construction. Extending its entire mixed-coordinate first head and output under the same scalar-value restriction would require separate accounting; it is not silently included here.

## 7. Full accounting and interpretation

Two useful scalar full-prefix heads, zero scores; fixed per-row width and sufficiently large fixed full norm budgets; paid D=O(log N) including product recovery, clipping/plateaus, final amplification, logits, full padding/clears and restoration. Coefficients use O(log N) bits each, O(log^2 N) total untied description; all row state uses O(N) scalars. Skipping identically zero attention slots gives O(N^2+N log N) work, while dense execution of every dummy slot costs O(N^2 log N). No specialized prefix-sum execution is substituted.

No training, numeric compilation, model run, finite-arithmetic certificate or public mutation occurred. The local advance is exact alignment of an EXISTING nonlinear hard example with the currently audited normalized common model and output margin. It does not add a new communication lower technique, improve the statistical rate, or identify a minimal nonlinear mechanism. Smooth low-curvature nonlinear rows can still have source-average summaries, as the separate Taylor-corrected candidate demonstrates.
