# Exact additive terminal cuts: a necessary-and-sufficient certificate with limited scope

6 November 2026 UTC. Analytical candidate v2; v1 is preserved. Independent review requested after clarifying the affine-path premise and full decoder domains. This is a finite-domain algebraic characterization, not a computationally efficient universal test or a characterization of all cheap communication.

## 1. Freeze the object being certified

Choose a fixed terminal cut AFTER all distributed row updates and BEFORE a charged local terminal decoder. Let z:{0,1}^N -> R^v be the complete data-carrying vector at that cut, with fixed v and ||z(x)||<=V for every raw binary history. All other retained decoder coordinates must be public or included in z. Source-independent parameters are fixed. Downstream decoder gain and all actual neural work are separately charged, as in the public-linear collapse theorem.

The desired property is an EXACT additive representation of THIS cut:

    z(x)=z(0)+sum_i a_i x_i.                             (A)

Changing the cut or adding another summary changes the question. A nonlinear downstream decoder is allowed and need not satisfy (A).

## 2. Exact certificate

For i!=j and every assignment w of the other N-2 bits, define

    D_ij z(w)=z(w;i=1,j=1)-z(w;i=1,j=0)
               -z(w;i=0,j=1)+z(w;i=0,j=0).

Then (A) holds if and only if D_ij z(w)=0 for every i,j,w. In that case a_i=z(e_i)-z(0).

Proof. Necessity follows by canceling each affine term. For sufficiency, D_ij=0 says that the effect of turning bit i from 0 to 1 is unchanged when any other bit j is changed. Moving between any two contexts one bit at a time therefore makes that effect independent of every other coordinate, equal to a_i. Telescoping from the all-zero history to x gives (A).

This is the weakest exact condition for the narrowly specified additive representation, in the logical sense of necessity and sufficiency. Exhaustively checking it uses exponentially many histories; no efficient certification algorithm is claimed. Public input-independent ReLU activation/clipping patterns give a sufficient syntactic route ONLY when all other maps on the certified path are affine or public-linear; input-dependent softmax weights and full-feature LN remain nonlinear despite fixed ReLU masks. Under that full premise, but their resulting coefficient/norm behavior and all input channels still need checking. Algebraic cancellation can also make (A) hold even when internal masks vary, so public masks are not necessary.

## 3. Bounded message radius without a hidden sum-of-coefficients cost

Alice sends her partial z_A=sum_{i in A}a_i x_i, Bob adds z(0) and his own partial sum. Even if individual coefficients were not separately bounded, the all-history cut bound implies

    ||z_A||=||z(x_A,0_B)-z(0)||<=2V.

Thus one eta-net index in a radius-2V ball costs O(v log(1+V/eta)) bits. The decoder can project the combined estimate to the radius-V ball, which fixes the true cut. Require the decoder to be G-Lipschitz on the FULL projected radius-V ball, not merely exact reachable cut points. A G-Lipschitz decoder on that domain then gives error <=epsilon with eta=epsilon/max(1,G). This proves the same one-way logarithmic-gain communication bound with the binary N-bit fallback. It does not require nonnegative intermediate matrices or linear internal computation; it requires the terminal identity (A).

## 4. Approximate mixed-difference certificate

Suppose instead ||D_ij z(w)||<=gamma_ij uniformly over w, with gamma_ij=gamma_ji. Using a_i=z(e_i)-z(0), the same telescoping argument gives

    ||z(x)-z(0)-sum_i a_i x_i||
       <= sum_{i<j} gamma_ij x_i x_j.                   (B)

Indeed when bit i is added after earlier active bits, its effect differs from its all-zero-context effect by at most the sum of gamma_ij over those earlier active bits; each active unordered pair is counted once.

Let E0=sum_{i<j}gamma_ij. The affine surrogate cut has norm <=V+E0 on every history. Its Alice partial message radius is at most 2V+E0 by comparison with z(x_A,0_B)-z(0) and (B). If E0 is a declared fixed bounded resource, the same net simulation applies; growing E0 remains in the radius cost. Use the full radius-(V+E0) ball as a proof-side projected decoder domain containing both actual and surrogate cuts, with a uniform gain G on that ENTIRE domain, not just reachable points. Source-average output error before quantization is at most

    G sup_{P in P_c} E_P sum_{i<j}gamma_ij X_i X_j,

using binary 0/1 notation here. This is a sufficient certificate; replacing gamma by empirical sampled differences would not certify all histories. A naive uniform gamma only gives O(N^2 gamma), which may be useless.

## 5. Smooth nonlinearity already breaks exact additive collapse

For the ideal quadratic prefix statistic A_2 in TAYLOR_PREFIX_CLOSURE, use signed raw X_j=2x_j-1. For j<k<=N,

    D_jk A_2 = (8/T)sum_{i=k}^T 1/i^2 >0.               (C)

This follows by expanding each prefix square; its X_j X_k coefficient is (2/T)sum_{i>=k}i^-2 and a +/- mixed difference multiplies it by four. Thus even a bounded smooth square breaks exact additive representation at this final scalar cut.

For the concrete dyadic square interpolant with uniform statistic error <=nu<=T^-2, its D_12 differs from the ideal by at most 4nu. The ideal D_12>=2/T, so it remains positive for T>2. Hence the actual bounded affine/ReLU logical implementation also fails the exact certificate, not merely an ideal multiplication oracle.

Nevertheless the Taylor-corrected source-average simulator is cheap. This is why failure of (A) is NOT a communication lower: a different low-dimensional nonlinear decoding of public linear summaries, or a source-average approximation, can still work. Conversely, the normalized prefix-energy hard example supplies a real worst-history communication lower for a different nonlinear map, rather than inferring hardness just from a nonzero mixed difference.

## 6. Source of the argument and boundary

Vanishing mixed differences characterize degree-one functions on a binary cube; net quantization and telescoping are elementary existing tools. The local use is to state exactly what can be checked when claiming a nonlinear body still has an additive terminal cut, and to separate that claim from universal communication hardness or a minimal architecture condition. No novelty, training, numerical verification or source-estimation-rate claim is made.
