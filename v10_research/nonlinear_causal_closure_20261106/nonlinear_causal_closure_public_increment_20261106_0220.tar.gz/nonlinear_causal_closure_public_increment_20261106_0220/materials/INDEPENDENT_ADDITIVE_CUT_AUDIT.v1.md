# Independent exact-file audit: additive terminal-cut certificate

6 November 2026 UTC. Verdict: PASS for the specified complete cut and the stated full-domain decoder bounds.

Reviewed source: `ADDITIVE_CUT_CERTIFICATE.candidate.v3.md`.
SHA-256: `665cd759daf6af78276d377580119ba25f6e1047165bdc454e58833d9262651a`.

Direct comparison sources: `TAYLOR_PREFIX_CLOSURE.candidate.v2.md` and `../ordered_causal_memory_20261106/PUBLIC_LINEAR_CASCADE_COLLAPSE.candidate.v2.md`. This is an algebraic audit, not an efficient certification procedure.

## Exact representation and communication

Vanishing mixed differences are necessary for an additive Boolean-cube representation by termwise cancellation. Conversely, each zero mixed difference makes a coordinate increment invariant to changing one other bit. Connecting any two backgrounds one bit at a time makes that increment globally constant. Telescoping from zero then gives the exact representation with a_i=z(e_i)-z(0). The proof is valid for vector-valued z, not only a scalar.

The complete-cut requirement is essential and present: all data used by the later decoder must be in z. The all-history norm bound also does real work. Alice's additive partial sum equals z(x_A,0_B)-z(0), and therefore has radius at most 2V regardless of any crude sum of coefficient norms. A fixed-dimensional ball net gives the claimed logarithmic-precision message cost. Projecting the recombined estimate to the radius-V ball fixes the true point and does not enlarge its error. Version 3 explicitly requires the decoder gain on that full ball, not merely on exact reachable cut values.

Public fixed ReLU/clipping patterns are stated as a sufficient route only when the other certified operations are affine/public-linear. The candidate correctly excludes treating data-dependent attention weights or full-feature LN as affine merely because ReLU masks are fixed. Exact algebraic cancellation can make the terminal cut additive without making every internal mask public; no false converse is asserted.

## Approximate certificate

Add active bits in a fixed order. Before bit i is added, compare its increment with the all-zero-background increment by successively removing earlier active bits. Each comparison costs at most its corresponding gamma_ij; every active unordered pair is counted exactly once. Triangle inequality gives the stated pair-sum residual for vector-valued z.

The affine surrogate has norm at most V+E0, while Alice's partial affine sum has radius at most 2V+E0 by comparison with the actual cut on (x_A,0_B). The source explicitly retains growing E0 in message-radius accounting and requires a G bound on the entire radius-(V+E0) projected domain. Thus the displayed source-average decoder error follows directly without an independence assumption. This is a sufficient approximate certificate, not a claim that small sampled mixed differences certify unseen histories.

## Square-prefix example and boundary

For signed inputs X_j=2x_j-1, the X_j X_k coefficient in the averaged prefix square is (2/T) sum_{i>=k} i^(-2). Switching each binary coordinate changes the corresponding signed coordinate by two, so the mixed difference is (8/T) sum_{i>=k} i^(-2), strictly positive.

The bounded affine/ReLU logical square implementation differs uniformly in its scalar statistic by at most nu<=T^(-2). Its mixed difference changes by at most 4nu. Since the ideal D_12>=2/T, the implemented logical difference is positive for T>2. This proof is about the logical reference cut, not a claim that its exact internal identity survives physical PreLN normalization. The physical model is related by its separate uniform output approximation.

The candidate correctly states the key limit: failure of this specific additive representation is not a communication lower. A different nonlinear decoding of public summaries, source-average approximation, or a different terminal cut can behave differently. The theorem is necessary and sufficient only for the displayed additive identity at the frozen complete cut; it is neither a universal weakest architectural condition nor a polynomial-time test.

Review method: exact-source reading, comparison and analytic derivation. No candidate source edit, scientific executable, numerical diagnostic, model run, experiment, training or upload was performed. This audit binds only v3 above and does not retroactively certify the earlier versions.
