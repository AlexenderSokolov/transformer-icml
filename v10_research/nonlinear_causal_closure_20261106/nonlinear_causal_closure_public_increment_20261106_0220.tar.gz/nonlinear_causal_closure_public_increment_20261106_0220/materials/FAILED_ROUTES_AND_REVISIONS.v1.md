# Preserved failed routes and exact revision record

6 November 2026 UTC.

- Rejected as duplicate: announcing nonlinear prefix-energy or rare-marker hardness itself as new. Both already exist in the earlier reviewed packages; the current negative result only aligns the former with the fixed positive-epsilon PreLN/ordinary-softmax common model and updates its numerical margin.
- Rejected invalid endpoint transfer: finite ordinary logits do not output exact 0/1. The new reference logits (4F-2,0) give sigma(-2),sigma(2); compilation keeps a >1/3 midpoint margin. Therefore the new worst-history simulation threshold is 1/4, not the old arbitrary epsilon<1/2.
- Rejected inference: nonzero mixed differences imply high communication. They only rule out an exact additive representation of a specified cut. The Taylor example has nonzero differences and still a cheap source-average two-statistic simulator.
- Rejected naive global-mean replacement: dropping R leaves a first-order error of order N^-1/2. Retaining R cancels the first-order term, exposing a sharp logarithmic-over-N quadratic remainder.
- Rejected domain shortcut: the Taylor surrogate can lie outside the actual value range. For f(z)=z^2 it lies in [-3,1]; the sigmoid is certified on that full interval, rather than assuming the surrogate belongs to [0,1]. General continuations must declare a domain containing both.
- Rejected implicit pointwise features: extending f(m_i) to f(X_i,m_i) can create the cross-party quadratic statistic sum_i X_i m_i. It is not a free token-local moment.
- Rejected low-risk interpretation: quadratic output on a stationary lag-two source has risk tending to theta/2; normalized energy hardness has fair-IID risk tending to sigma(2)-1/2. Neither is a new consistent estimator or a source-average hardness result.
- Taylor v1 creation-time gaps corrected in v2: explicit N>=6, theta<=1-2c, physical usefulness through a common original/ablated prepared program, and a small output tolerance min{1/1000,T^-2}. The old candidate is preserved. These were proof-completeness clarifications, not an incorrect core Taylor identity.
- Normalized hardness v1 clarified in v2: original and both single-read-ablated FULLY PREPARED programs share the tube/gain bounds and unchanged preparation/restoration schedule before m,M are selected. This preserves the prior compiler correction; v1 remains archived.

No scientific executable, sampled diagnostic, model run or training occurred. Document generation and file validation are not scientific reproduction. No uploads, purchases or submissions were performed in this research task.
