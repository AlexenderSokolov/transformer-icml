# Taylor-corrected source-average closure for smooth nonlinear prefix rows

6 November 2026 UTC. Analytical candidate v2; v1 is preserved. Independent review requested after adding the horizon, witness-interiority, ablation and exact IID remainder checks. The new target is a nonlinear row-update simulation certificate, not a new estimator or statistical rate.

## 1. Frozen nonlinear two-read program

Assume N>=6 to match the current two-read normalized construction. N signed binary raw tokens, T=N+1 synthetic zero-symbol row, full-prefix inclusive causal attention, fixed width, paid local operations and source-independent parameters. Let S_i=sum_{j<=i}X_j for i<=N, and S_T=S_N. The first zero-score scalar head produces m_i=S_i/i for all i<=T. A nonlinear row map f is applied, and the second zero-score scalar head returns

    A_f=(1/T)sum_{i=1}^T f(m_i).

For the main concrete example f(z)=z^2. Its ideal terminal output is Q_f=(sigma(A_f),1-sigma(A_f)), sigma(u)=1/(1+exp(-u)); these are ordinary logits (A_f,0), not an uncharged probability projection. Section 6 gives a fixed-width positive-epsilon PreLN realization approximating this ideal with O(log N) depth. The ideal square is an analytical comparator, not an exact multiplication primitive.

The statistical class is stationary interior binary order-two P_c, fixed c in (0,1/2). Error of SIMULATION is averaged under this class. No unknown source parameter is supplied to the network or simulator.

## 2. Two public linear sufficient statistics for the approximation

Set M=S_N/N and

    R=(1/T)sum_{i=1}^T m_i
      =(1/T)sum_{j=1}^N a_j X_j,
    a_j=sum_{i=j}^T 1/i.

Both are public weighted token-local sums, even though A_f is nonlinear in distributed prefix states. Their absolute ranges are at most one. In particular sum_{j<=N}a_j/T=N/T+N/T^2<1. Alice can send quantized partial M and R; Bob adds his own partial sums. Neither party needs to know the individual cross-party m_i.

Define the Taylor surrogate

    B_f=f(M)+f'(M)(R-M).

If |f''(z)|<=L_2 on [-1,1], Taylor's integral remainder gives the PATHWISE bound

    |A_f-B_f| <= (L_2/2) V_N,
    V_N=(1/T)sum_{i=1}^T (m_i-M)^2.                     (1)

If a subsequent public output map has Lipschitz constant G on the required domain containing A_f and B_f, its output error is <=G L_2 V_N/2. Any implementation approximation to f and output must be added separately. The surrogate may be outside f([-1,1]), so its decoder domain may not be silently restricted to the actual range.

For quantized M,R, require fixed |f'|<=L_1 and |f''|<=L_2. On the square [-1,1]^2, partial_M B_f=f''(M)(R-M), partial_R B_f=f'(M), hence |partial_M|<=2L_2 and |partial_R|<=L_1. Project the combined quantized statistics into [-1,1]^2, fixing the exact pair. This yields O((2L_2+L_1)eta) pre-output error for coordinate accuracy eta, uniformly over histories. The precise bit cost is O(log(1/eta)) at fixed derivative/value budgets, or the raw-bit cap N. Curvature/decoder gains that grow with depth remain explicit resources.

## 3. Uniform second-order source-average remainder

The reviewed pair-chain minorization gives, for stationary P_c,

    Var(sum_{j=1}^i X_j)<=K_c i,   K_c=2/c^2-3.

For i<=N, both m_i and M have mean mu and

    E(m_i-M)^2<=2K_c/i+2K_c/N.

At the synthetic row m_T-M=-M/T, so its squared difference is at most T^-2. Therefore

    sup_{P in P_c} E V_N <= [2K_c(H_N+1)+T^-2]/T,        (2)

where H_N=sum_{i=1}^N 1/i. Under fair IID signs the exact identity is E V_N=(H_N-1+1/(N T^2))/T: for i<=N, Cov(m_i,M)=1/N, so E(m_i-M)^2=1/i-1/N; the synthetic contribution is 1/(N T^2) before division by T. Therefore the order log(N)/N of this canonical remainder is sharp, including its induced sigmoid discrepancy by (3). Combining (1)-(2) gives an O_c(G L_2 log(N)/N) source-average closure defect. It is o(N^-1/2) for fixed derivative/decoder budgets. More generally the displayed sufficient comparison condition at any desired scale r_N is G_N L_(2,N) log(N)/N=o(r_N), with K_c and implementation errors retained.

This is a condition, not an assertion about all nonlinear row maps. Intermediate amplification can make L_2 grow. A shared dependence on the row's own symbol f(X_i,m_i) generally creates the cross-party quadratic statistic sum_i X_i m_i in the first-order term; it does not inherit the two-scalar closure for free.

## 4. Quadratic example and a necessary-and-sufficient residual test for this surrogate

For f(z)=z^2 the Taylor identity is exact:

    A_2=2MR-M^2+V_N.

Thus B_2=2MR-M^2 lies in [-3,1], while A_2 is in [0,1]. The sigmoid derivative on [-3,1] lies between

    kappa_sigma=exp(3)/(1+exp(3))^2 >0

and 1/4. Hence on EVERY history,

    kappa_sigma V_N <= TV(Q_2,Q_Taylor) <= V_N/4.        (3)

For this PARTICULAR quadratic-program/Taylor-surrogate pair, the source-average output discrepancy is o(r_N) if and only if E V_N=o(r_N), with sup over the same source class if required. This is the strongest necessity statement made here. It is not the weakest possible closure assumption over all architectures or all simulators.

Quantizing M,R with each error at most eta gives |Bhat_2-B_2|<=6eta and output error <=3eta/2. Choosing eta<=2epsilon/3 gives a deterministic one-way protocol using

    C<=min{N,K[1+log(1/epsilon)]}

with source-average error <=epsilon+[2K_c(H_N+1)+T^-2]/(4T) against the ideal quadratic network. This is not a worst-history guarantee: a long +1 block followed by a long -1 block has V_N bounded below by a positive constant.

## 5. This is not a useful second-order estimator

On the stationary symmetric lag-two source with a fixed theta in (0,1-2c], for example theta=min{1/16,(1-2c)/2}, mu=0 and E A_2<=K_c(H_N+1)/T up to an inessential bounded synthetic-row term. Thus sigma(A_2)->1/2 in L1, while the actual next law is (1+theta X_(N-1))/2. Consequently

    E TV(Q_2,p_actual) -> theta/2.

The same holds for an o(1)-accurate physical implementation. The source-average closure is a positive result for a genuinely nonlinear distributed memory statistic, but it is not a statistical consistency or learning result. No earlier suffix-estimation rate is repackaged as a new theorem.

## 6. Concrete positive-epsilon PreLN realization and full resources

Approximate z^2 on [-1,1] via b=(z+1)/2 and the already-reviewed dyadic tent-square interpolant s_L(b). Since |s_L(b)-b^2|<=4^-L/4, the clipped value

    f_L(z)=clip(4s_L((z+1)/2)-4((z+1)/2)+1,0,1)

has |f_L(z)-z^2|<=nu=4^-L. Take L=ceil(log_2 T), so nu<=T^-2. This is a fixed-width O(log N)-depth bounded affine/ReLU program with fixed per-primitive gain and complete-state norms. Its two useful heads remain scalar and zero-score. The second answer a is in [0,1] and the reference logits are simply ell=(a,0); no logarithm approximation or probability-floor circuit is needed.

Compile this EXACT bounded reference program by the reviewed TWO_READ_PRELN_COMPILATION v4 mechanism. Explicitly append fixed scaled-logit copies, norm-padding at accuracy kappa, and ALL scratch clears BEFORE defining total m and choosing eta_small=2^-M. Choose output tolerance zeta=min{1/1000,T^-2} and xi,kappa,tau_restore as the largest permitted dyadic constant multiples of zeta. Use a common bounded tube and unchanged physical preparation/restoration parameters for the original and both single-read-ablated reference programs. The full padded program has m=O(log N); both attention steps have max-row local error O(eta_small^2); the uniform recurrence is e_l<=L_0 e_(l-1)+C eta_small^2. Choosing M=O(m+log(1/zeta))=O(log N) controls the FULL prepared vector. The existing stable amplitude restoration and ordinary affine vocabulary head then give physical logits within zeta of ell. The identical gain-two reparameterization gives every LN epsilon=1, gain=2, shift=0.

The resulting actual network has width O(1), exactly two useful full-prefix scalar heads, depth O(log N), a fixed finite full-state/matrix/full-bias/primitive-gain envelope, per-coefficient description O(log N), and total untied parameter description O(log^2 N). Both heads are useful, not just scheduled: on all-+ histories the unablated reference second answer is at least N/T, whereas ablating either read gives zero (the dyadic square interpolant is exact at z=0). Their sigmoid outputs differ by more than 1/6 for N>=6; the two compiler errors of at most zeta leave a fixed positive separation. The network parameters are source independent; no c-dependent information is needed for construction. Fixed constants in the source-average bound do depend on c.

The physical output differs from ideal Q_2 by at most zeta+nu/4 (a conservative bound). Therefore its one-way SOURCE-AVERAGE simulator has error

    epsilon + [2K_c(H_N+1)+T^-2]/(4T) + zeta+nu/4.        (4)

Taking epsilon of order N^-1/2 uses O(log N) bits and the extra residual is o(N^-1/2). This does not violate the prediction testing theorem, since Section 5 shows constant prediction risk on its lag-two witness.

Useful-head/local work is O(N^2+N log N) if zero attention slots are skipped. Dense evaluation of every dummy attention slot costs O(N^2 log N). There are O(N) distributed row scalars at fixed width. Layer arithmetic is exact-real, not a finite floating-point execution guarantee. No numerical generation, experiment, model run or training was performed. The finite normative envelope is sufficient, not identified with an unchecked preassigned numerical M_K.

## 7. Provenance and scope

Taylor's theorem, variance bounds, linear weighted summaries, tent-square approximation and the compiler are standard or previously reviewed ingredients. The local increment is their explicit source-average composition with a second-order remainder and the exact canonical-surrogate criterion (3). The prior prefix-Lipschitz comparison discarded the first-order harmonic statistic and therefore gave only O(N^-1/2); retaining R removes that term. No priority claim is made.

Dependencies: ordered_causal_memory_20261106 public-linear collapse v2 and PreLN compilation v4; evolving_common_control_20261106 prefix example and its K_c covariance proof; the tent-square circuit in the existing repeated terminal obstruction. General nonlinear memory, data-dependent attention weights, growing curvature and actual transition-count features require separate accounting.
