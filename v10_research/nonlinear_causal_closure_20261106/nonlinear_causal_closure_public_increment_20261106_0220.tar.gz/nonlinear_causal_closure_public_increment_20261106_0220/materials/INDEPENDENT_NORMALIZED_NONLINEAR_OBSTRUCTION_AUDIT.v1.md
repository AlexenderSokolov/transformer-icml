# Independent exact-file audit: normalized nonlinear prefix-energy obstruction

6 November 2026 UTC. Verdict: PASS for the specified sufficiently large fixed resource envelope and exact-real semantics.

Reviewed source: `NORMALIZED_NONLINEAR_OBSTRUCTION.candidate.v2.md`.
SHA-256: `628009aef0e5d1333e23913bb34c2d04d3b67d792e7ea5ad76d498d729f331ac`.

Dependencies directly read: `../repeated_terminal_obstruction_20261105/TERMINAL_SIMULATION_OBSTRUCTION.candidate.v2.md`; `../ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md`, its accepted final audit and its early-failure audit; the corresponding public-linear collapse and ordered suffix candidates; and the final-output routine in `../softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md`. The external Gap-Hamming lower is imported unchanged from the prior obstruction and its recorded primary-source check, not independently reproved here.

## Communication and output checks

The original prefix-energy program is an all-row bounded continuous affine/ReLU program with two scalar uniform heads, paid clipped amplification and depth O(log N). The clipped prefix sums, their squares, the synthetic-row contribution, the eight-sign ownership-compatible encoding and its 12+8m+24J energy identity are inherited correctly. This is the existing hard logical function, not a new communication reduction.

The new affine logits (4F_N-2,0) are bounded and paid. Their sigmoid output has midpoint margin greater than 3/8 on the encoded endpoints, since exp(2)>7. With N>=16, the physical TV error T^(-2)<=1/289 leaves margin greater than 1/3. Therefore uniform TV error at most 1/4 preserves the required Boolean decision. Deterministic m-bit and randomized Omega(N) lower bounds follow from precisely the imported reductions, with arbitrary interaction still allowed.

For randomized expected per-history TV error at most 1/16, a wrong threshold decision requires error exceeding 1/3. Markov's inequality bounds failure by 3/16, below 1/3. The same reduction works for an unnormalized half-l1 approximant using (1+qhat_+-qhat_-)/2, whose scalar error is at most the half-l1 error. The candidate correctly does not reuse the old epsilon<1/2 endpoint threshold after bounded softmax.

## Normalization and full resources

The candidate fixes one tube and gain/local-error envelope for the original and both single-read-ablated fully prepared reference programs. Scaled logit copies, norm-padding and all scratch clears are included before defining the complete length m and choosing M. The imported recurrence therefore controls the complete prepared vector required by radial restoration, not only the earlier logit bank.

All intermediate nonlinear row operations are continuous fixed-gain primitives; physical errors are propagated through them without assuming exact physical plateau membership. The two zero-score attention steps have the same length-independent max-row local error as in the accepted compiler. With target T^(-2), m=O(log N) and M=O(log N). The common full preparation/restoration schedule makes the ablation comparison legitimate. Either ablation gives F_N=0 in the reference, while some encoded histories give F_N=1. The constant output gap survives the same uniform physical error.

The gain-two consuming-matrix reparameterization preserves trajectories. Every LN has epsilon=1, gain=2 and zero shift, and the output is an ordinary affine vocabulary head followed by softmax. Constant width, two useful scalar-value invocations, O(log N) paid depth and per-coefficient precision, O(log^2 N) total untied description and O(N) row state are consistent. The envelope is one sufficiently large fixed full-vector/matrix/bias/gain envelope, not a silently reused numerical bound. Useful-head/local work and fully dense dummy-slot work are separately charged.

## Source-risk distinction

For fair IID signs, 1-clip(S_t,-4,4)^2/16 vanishes outside |S_t|<4 and is bounded by one. The binomial point-mass bound gives E(1-E_N)=O(N^(-1/2)), including the synthetic term. Both stated baseline sequences stay below a fixed number less than 1/2. Consequently the probability that E_N is below b_tau+1/P tends to zero, so F_N tends to one in probability. Boundedness and the vanishing compiler error give the claimed limiting prediction risk sigma(2)-1/2>1/3.

Thus the construction is explicitly not a low-risk predictor, and positive Markov-source probability of the encoded histories is not confused with a source-average communication lower. The result excludes universal cheap worst-history terminal simulation in the same normalized model, while leaving the source-average and low-risk-specific questions open.

## Scope

No improved estimation rate, new communication lower technique, trained realization, mandatory PostLN result, finite-arithmetic reliability or minimal nonlinear-mechanism theorem is certified. The relevant increment is the normalized-model alignment and its correctly changed constant margins.

Review method: direct source reading, exact-version comparison and analytic derivation only. No candidate source edit, scientific execution, numerical parameter generation, model run, experiment, training or upload was performed. This audit binds the exact v2 source above; it does not retroactively certify v1.
