# Nonlinear causal closure research

6 November 2026 UTC. This package separates exact additive folding, source-average approximation and worst-history hardness under the same fixed positive-epsilon PreLN/ordinary-softmax model. No new statistical prediction rate is claimed.

Final mathematics:
- TAYLOR_PREFIX_CLOSURE.candidate.v2.md: two public linear statistics M,R remove the first-order error of smooth row-value updates. Quadratic residual is exactly V_N, uniformly O_c(log N/N), and sharp for this surrogate. A concrete two-scalar-head normalized implementation has O(log N) depth, but constant lag-two prediction risk.
- NORMALIZED_NONLINEAR_OBSTRUCTION.candidate.v2.md: the existing nonlinear prefix-energy hard function is compiled into the same normalized model with bounded affine logits and corrected output margins. Constant-error worst-history communication remains Omega(N); no source-average or low-risk lower is asserted.
- ADDITIVE_CUT_CERTIFICATE.candidate.v3.md: vanishing mixed binary differences are necessary/sufficient for exact additive representation of a specified complete terminal cut. It is not an efficient universal test or a necessary condition for every cheap simulator. Uniform full decoder domains and growing interaction residuals are explicitly charged.

The matching independent mathematical audits are authoritative over candidate creation-time pending labels. PRIOR_WORK_AND_SCOPE_COMPARISON.v2.md distinguishes prior results and fresh-versus-inherited source checks. FAILED_ROUTES_AND_REVISIONS.v1.md preserves rejected arguments and revision history. Older candidate versions are not overwritten.

Chinese report embeds final exact texts and independent audits with hashes. HTML parse checks are not visual rendering, model execution, scientific reproduction or formal verification. No scientific executable, training, upload, purchase or submission was performed.

Still open: source-average compression or a lower bound for genuinely low-risk normalized nonlinear predictors on the common unknown second-order class. The present positive and negative examples both have explicitly nonvanishing prediction risk on a fixed witness source.
