# Independent exact-report text, privacy and static-safety audit

6 November 2026 UTC. Verdict: PASS for the text, source binding, privacy and static HTML checks below. Visual rendering was not performed or certified.

Reviewed report: `RESEARCH_REPORT.zh.v1.html`.
SHA-256: `288842241f30a76718eb496a697012962174b22c646e9ff6da6e32a499095860`.
Size: 69,103 bytes.

Reviewed body: `REPORT_BODY.zh.v1.html`.
SHA-256: `03e319ca3f2b9ce53490beda69e68eefbe4bd8ebfa847014d3098c0e9711d33b`.

## Scientific text and scope

The Chinese text accurately summarizes the accepted Taylor v2, normalized obstruction v2 and additive-cut v3 candidates. It preserves the raw-token/synthetic-terminal interface, inclusive zero-score scalar reads, fixed complete norms, paid depth and preparation, epsilon-one/gain-two PreLN, ordinary vocabulary softmax and exact-real arithmetic.

The O_c(log N/N) quantity is clearly a source-average simulation remainder, not an improved prediction risk. The exact synthetic-row contribution and fair-IID harmonic remainder are correct. The canonical-surrogate necessary-and-sufficient statement is restricted to the specified quadratic output and Taylor surrogate. Decoder-domain and growing-gain/curvature requirements are retained.

The report explicitly locates the nonzero mixed-difference calculation at the ideal statistic and its bounded dyadic-coefficient logical reference before normalization. It does not promote that internal identity to the physical PreLN state. Physical/reference comparison is through the separately proved uniform output error. The exact additive certificate remains about one complete terminal cut; nonzero mixed differences are not mistaken for a communication lower or an efficient certification result.

The normalized hard example retains its actual softmax margin, simulation tolerance 1/4, per-history randomized success requirement and expected-error threshold 1/16. Its old logical communication reduction and imported Gap-Hamming theorem are identified as existing results. The report does not convert worst-history hardness into source-average hardness. Both concrete programs' nonvanishing prediction risks are stated explicitly.

The resource table distinguishes per-coefficient from total parameter description, constant row width from O(N) distributed state, and useful-head/local work from dense execution of dummy attention slots. It does not claim trained behavior or finite floating-point reliability.

## Provenance and privacy

The literature text matches the accepted comparison v2. It distinguishes the immediately preceding ordered-paper retrievals from the 5 November Alman–Song/Chen record and explicitly says Hahn's correction supplement was not fetched again. No new live literature search, novelty certification or external proof re-verification is asserted.

The report and its eight appended research/audit texts contain mathematical constructions, resource accounts and public academic references. No personal contact data, credentials, private keys, payment details, private conversation transcript, internal user-memory paths or account identifiers were found by direct reading and targeted pattern checks. This is a content review, not authorization to publish or transmit the report.

## Independent static checks

A separate standard-library HTML parser and hash comparison were used only for document QA. The checks established:

- Valid UTF-8 decoding; no duplicate IDs, broken fragment links, nesting errors or unclosed tags.
- Eight appendices, each whose decoded preformatted text is exactly equal to its referenced source file.
- All eight source hashes agree with `REPORT_SOURCE_BINDINGS.v1.json` and with the embedded sources.
- No scripts, forms, executable event attributes, javascript/data URL attributes, embedded remote resources, external stylesheets or CSS remote-loading directives.
- The seven external HTML anchor destinations are the cited public academic URLs. No automatic external request is introduced by those ordinary links.
- No flagged credential patterns or private execution/user-note path strings.

No browser rendering was attempted, so clipping, font fallback, pagination and visual layout are not certified. The report itself discloses that visual rendering has not been accepted. Static document QA is not a numerical scientific reproduction, model run or formal proof check.

No scientific execution, experiment, training, candidate-source modification, upload or publication was performed during this audit. This verdict binds only the exact report and body hashes above.
