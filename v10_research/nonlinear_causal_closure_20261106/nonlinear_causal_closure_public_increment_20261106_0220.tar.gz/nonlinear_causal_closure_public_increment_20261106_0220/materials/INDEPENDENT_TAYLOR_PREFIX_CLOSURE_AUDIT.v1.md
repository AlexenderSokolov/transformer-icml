# Independent exact-file audit: Taylor-corrected nonlinear prefix closure

6 November 2026 UTC. Verdict: PASS for the stated stationary source class, fixed finite resource envelope and exact-real semantics.

Reviewed source: `TAYLOR_PREFIX_CLOSURE.candidate.v2.md`.
SHA-256: `2e88291ded1da043796783ccb1200f806a72b17d0c9d1727d7615d68b4e6e005`.

Dependencies directly read: `../evolving_common_control_20261106/CAUSAL_PREFIX_AVERAGE_EXAMPLE.candidate.v1.md`, `CAUSAL_PREFIX_LIPSCHITZ_CLOSURE.candidate.v3.md` and `AMPLIFIED_PREFIX_DEFECT.candidate.v1.md`; `../ordered_causal_memory_20261106/PUBLIC_LINEAR_CASCADE_COLLAPSE.candidate.v2.md`, `TWO_READ_PRELN_COMPILATION.candidate.v4.md` and its final/early-failure audits; `../repeated_terminal_obstruction_20261105/TERMINAL_SIMULATION_OBSTRUCTION.candidate.v2.md`; and Section 5 of `../softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md`.

## Checked mathematical statements

- The synthetic row is included consistently. With T=N+1, m_T=S_N/T, M=S_N/N and R=T^(-1) sum_{i=1}^T m_i, exchanging sums gives the stated public harmonic weights. Their total mass is N/T+N/T^2=1-T^(-2), less than one. The two party partial sums therefore have fixed ranges independently of N.
- Taylor expansion around the sample mean M gives |A_f-B_f|<=L_2 V_N/2 pathwise. The derivatives of B_f with respect to its two scalar inputs are f''(M)(R-M) and f'(M). Projection to the square does not enlarge either coordinate error. These are terminal-function arguments, not reconstruction of the nonlinear row bank.
- The inherited stationary covariance bound supplies E(m_i-M)^2<=2K_c/i+2K_c/N for real rows. The synthetic term is exactly M^2/T^2 before the outer average. Summing gives [2K_c(H_N+1)+T^(-2)]/T as claimed.
- Under fair IID signs, Cov(m_i,M)=1/N and E M^2=1/N. Thus the exact remainder is (H_N-1+1/(N T^2))/T. The logarithmic factor is real for this canonical remainder, not only an artifact of the upper bound.
- For the square, A_2=2MR-M^2+V_N exactly. A_2 lies in [0,1] and B_2 in [-3,1]. Sigmoid has derivative at least exp(3)/(1+exp(3))^2 on their connecting interval and at most 1/4, proving both sides of the displayed TV comparison. The resulting necessary-and-sufficient little-o statement concerns this specified program/surrogate pair only.
- The 6 eta statistic-quantization error and 3 eta/2 output error follow from the same derivative bounds. Alice can send two quantized public-weight partial sums, with no cross-party prefix reconstruction. The bit cap N is valid by sending the raw owned bits. This proves a source-average simulator, not a uniform small-error simulator.
- The lag-two witness is explicitly chosen inside P_c. Its zero stationary mean implies E A_2=O_c(log N/N), and reverse triangle inequality transfers convergence to the fair output into the claimed limiting prediction risk theta/2. The physical approximation tends to zero and does not alter this limit.

## Normalized compilation and usefulness

The tent-square implementation is a bounded, fixed-width continuous affine/ReLU program, with uniform square error at most 4^(-L)<=T^(-2). No exact multiplication primitive is inserted. The two useful heads are genuinely scalar, zero-score, inclusive prefix heads.

The full output preparation, including padding and every scratch clear, is placed before choosing the small amplitude. The candidate explicitly chooses one tube and common preparation/restoration parameters for the original and both ablated references. Thus its recurrence controls the entire prepared vector needed by the imported final-output routine, repairing the precise issue identified in the old early compiler drafts.

On all-positive histories, the reference answer is at least N/T. Either single-read ablation gives zero, since the tent interpolant is exact at zero and the second read has a fresh destination. For N>=6, sigma(N/T)-1/2>1/6. The two output errors, each at most zeta<=1/1000, preserve a fixed gap. The statement that both reads are useful is therefore justified for the physical network.

The uniform physical-to-ideal error zeta+nu/4 is conservative and sufficient. With fixed width, the charged preparation, small-amplitude restoration and square computation have depth and per-coefficient description O(log N); total untied description is O(log^2 N). Full vectors, biases, matrices and primitive gains fit a sufficiently large fixed envelope. The separate O(N^2+N log N) and fully dense dummy-slot O(N^2 log N) work ledgers are correct.

## Scope and provenance

This is a source-average nonlinear closure certificate with an explicit second-order residual. It does not prove a statistically good order-two estimator, a general nonlinear-memory simulation theorem, a stronger existing estimation rate, a mandatory PostLN implementation, or reliable finite-word execution. Its elementary ingredients and imported compiler are identified as prior work. Growing downstream gain/curvature and symbol-dependent row maps require the separate accounting stated in the source.

Review method: direct source reading and analytic derivation. No candidate source edit, scientific execution, parameter generation, numerical model run, training, experiment or upload was performed. This review binds only the exact v2 source above and does not retroactively certify v1.
