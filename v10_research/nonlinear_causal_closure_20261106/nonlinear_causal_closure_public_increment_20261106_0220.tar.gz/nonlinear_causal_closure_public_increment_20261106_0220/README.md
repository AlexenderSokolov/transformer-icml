# Nonlinear causal closure: public research increment

This is a new additive local publication candidate. All 22 available source files are exact-byte copies under materials/, with every old candidate, failure record, independent audit, HTML, script and QA retained. No sources were overwritten; no GitHub write occurred. Open materials/RESEARCH_REPORT.zh.v1.html directly for the full Chinese report. Its matching historical review is materials/INDEPENDENT_REPORT_TEXT_PRIVACY_AUDIT.v1.md.

## Scientific scope

The three final candidates are Taylor prefix closure v2, normalized nonlinear obstruction v2, and additive cut certificate v3, with corresponding exact-version analytical audits. Matching reviews do not retroactively certify older versions. This package preserves historical labels, not rewriting creation-time pending statements.

The Taylor result retains two public linear statistics to cancel first-order error, leaving a canonical quadratic source-average residual of order O_c(log N/N). This is simulation error for a specific statistic, not a new prediction-risk rate or a universal simulator optimum. The normalized hardness result imports a prior prefix-energy construction and communication theorem; ordinary softmax requires the corrected output margin and worst-history simulation threshold 1/4. It is not a source-average hardness theorem or a low-risk model. The additive mixed-difference criterion concerns exact additivity of a specified complete cut; it neither efficiently tests arbitrary networks nor characterizes all cheap simulators.

Both concrete positive and negative examples have nonvanishing prediction risk on their stated witness sources. Arbitrary nonlinear full-row compression and source-average hardness for genuinely low-risk normalized predictors remain open. Full compiler preparation, uniform decoder domains, retained dimensions, amplification and growing interaction residuals must be charged as specified. Physical normalized memory is not asserted to equal its logical reference algebra.

No training, scientific numerical execution, sampled diagnostics, model run or finite-arithmetic reproduction was performed for this package. Analytical PASS means text review, not formal verification, external peer review, empirical validation or novelty certification. Visual acceptance is NOT COMPLETED; HTML parsing is not rendering, screenshot or print review. Proof dependency closure remains OPEN. This is not recovery of the complete v10 corpus.

## Privacy and copyright

Scoped review found no apparent secrets, sensitive personal information, private correspondence or machine paths requiring neutralization. All source bytes are retained. Third-party material consists of cited original summaries/comparisons and mathematical references, not redistributed full papers, PDFs or extracted full text. No new license or rights grant is added; content review is not legal clearance. Historical fresh-versus-inherited literature checks remain distinguished, and no paper was freshly fetched by packaging.

## Verification and use

SOURCE_DERIVATION_MAP.json maps every source/public path, byte count and SHA-256. PACKAGING_QA.json contains new checks separately from immutable historical QA. independent_review/ contains the historical audit index and independent package review. SHA256SUMS covers every other package file; python verify_package.py is read-only.

Original build_report.py and check_report.py write document/QA outputs. Run them only in a disposable copy, not against this frozen package. They are document tools, not scientific reproduction scripts. The report embeds eight exact local appendices, not its external dependency corpus.
