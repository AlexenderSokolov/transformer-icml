# Dependencies and omissions

All 22 files present in nonlinear_causal_closure_20261106 are included unchanged. No historical version or failed route was suppressed; no missing version invented. Not bundled: external prior research directories, third-party paper full texts, unavailable screenshots/PDF renderings or unperformed numerical runs. This is an incremental local snapshot, not a complete recovered archive.

External proof and provenance dependencies remain OPEN, including:
- REPEATED_ATTENTION_SIMULATION_BARRIER v4 and TERMINAL_SIMULATION_OBSTRUCTION v2, including deterministic and imported Gap-Hamming reductions.
- LOW_RISK_TERMINAL_OBSTRUCTION and its different rare-marker/mixed-channel scope.
- Evolving common-control, prefix-Lipschitz, lag-two source and stationary covariance/variance bounds.
- Ordered public-linear collapse and full prepared-vector PreLN compilation, small-amplitude simulation, padding/restoration, ordinary-softmax and common ablation-tube modules.
- Existing frozen primitive/norm/resource contracts and source-average testing prerequisites where invoked.
- ordered_causal_memory_20261106/PRIMARY_COMPARISON.v1.md and CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md, including inherited external literature checks.

These are cited dependencies, not an independently certified exhaustive transitive proof graph. Their external hashes/proofs/review chains are not established by this package. The exact local HTML bindings prove appendix identity only. In particular the Hahn correction supplement and older attention-kernel checks must not be described as freshly fetched in this research pass. The scope comparison v2 preserves that correction; v1 remains historical.
