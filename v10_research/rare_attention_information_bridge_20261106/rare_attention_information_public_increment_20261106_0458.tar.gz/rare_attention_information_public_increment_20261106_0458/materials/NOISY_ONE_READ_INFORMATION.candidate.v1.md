# A limited conditional-information bound for an explicitly noisy one-read view

6 November 2026 UTC. Analytical candidate v1, awaiting independent exact-file review. This is a theorem for a NEW Gaussian observation-channel assumption, not a theorem that ordinary PreLN secretly introduces noise. No experiment, numerical test, upload, or public write was performed.

## 1. Statement with the complete visible interface

Use the stationary rare source P_(u,t) of the companion exact-information note, with known fixed 0<u<=1/100 and unknown t in [1/2,3/4]. There is exactly one useful full-prefix head invocation. Before and after it all network operations are positionwise; the synthetic terminal's pre-read state and query are public. The network is fixed across t. Score range is at most S and full head-value norm is at most V on every raw history. The head dimension d is explicitly retained.

Write o(X) in R^d for the actual, unperturbed terminal head output. In the NEW channel considered here, replace this entire output by

    M=o(X)+sigma G, G~N(0,I_d), sigma>0.               (1)

Every terminal residual injection, FFN input, copied register, final normalization, logit and output computed after this read must use M, not a clean o retained elsewhere. All pre-read terminal residuals are public. The observer may keep M and ALL terminal continuation values, and may also be given Bob's full parity observation B and the actual terminal pair E=00. Source-independent random coins can be added. Nonterminal rows are not read again. These conditions preserve every allowed terminal-visible value and state precisely which new Gaussian channel replaces the exact read. Adding noise to one copy while another copy remains clean is NOT covered.

Let Theta have ANY prior supported on an interval of length a inside [1/2,3/4]. Condition on the same-trajectory event E that the actual terminal pair is A=00. Its probability is u for every parameter, so conditioning leaves the prior unchanged. If Z is the entire noisy terminal view together with B, then

    I(Theta;Z | E)
      <= 10^6(1+m u^2)a^2
            +200 exp(4S)(1+V^2)^2/(N sigma^2),        (2)

where m is Bob's parity length. The second term is dimension-free for a fixed isotropic per-coordinate noise variance; it follows from a bounded FULL-vector radius, not coordinatewise bounds.

This is weaker than a desired rare-parameter-specific Nu^2 information inequality. It gives a fully specified, testable noisy-view theorem and shows exactly why a generic smoothing argument does not close the desired architecture/risk bridge.

## 2. Public-query decomposition of the actual bounded-score read

The sole invocation has had no earlier data-carrying communication. Thus at each real position i, its complete pre-read hidden state, normalized key and value are functions of its own raw symbol and public position only. The synthetic query is public. Include the synthetic self score s_T and subtract it from all terminal scores. With

    w_i(x)=exp(s_i(x)-s_T),
    b_i(x)=(w_i(x)v_i(x),w_i(x)) in R^(d+1),
    R=exp(S)sqrt(1+V^2),

we have

    exp(-S)<=w_i<=exp(S), ||b_i||<=R.

The synthetic contribution b_T is public, with self weight one. Set

    H=(n,z)=(1/(N+1))[sum_(i=1)^N b_i(X_i)+b_T],
    o=n/z.

Its denominator satisfies z>=exp(-S), and ||o||<=V. This augmented numerator/denominator vector is only a mathematical analysis device, not an additional neural register or a gratuitous observation.

The stationary one-symbol law is independent of t: Pr(X_i=0)=u+w and Pr(X_i=1)=2w. Define the source-parameter-independent reference

    Hbar=(nbar,zbar)
       =(1/(N+1))[sum_i E_pi b_i(X_i)+b_T],
    obar=nbar/zbar.

It may depend on u, N and the fixed network, but not on t. As with the actual ratio, zbar>=exp(-S) and ||obar||<=V.

## 3. A full-vector, same-terminal second-moment estimate

Conditioning on E and reversing the path yields P_t started at A, by the exact reversal calculation in the terminal-parity note. The transition bound

    P_t^2(x,D)>=1/4

holds for all states and all parameters in the rectangle. Thus, with rho=3/4,

    TV(mu P_t^k,nu P_t^k)<=rho^floor(k/2) TV(mu,nu). (3)

Reverse the order of the arbitrary position-dependent functions b_i as well. They remain bounded in full Euclidean norm by R. Write F_j(R_j) for those reversed functions, with R_1=R_2=0 fixed. At each j>=2 the reversed pair process has made j-2 transitions from A. Comparing with its stationary law and also retaining the first symbol gives

    ||sum_j E[F_j | E]-sum_j E_pi F_j||
       <=2R[1+sum_(k>=0)rho^floor(k/2)]
       =18R.                                       (4)

No initialization term is discarded. The synthetic contribution is public and cancels in this comparison.

For i>=2 and j>i, condition on the full reversed prefix through i. The vector conditional expectation of F_j differs from its unconditional expectation under this arbitrary-start law by at most

    2R rho^floor((j-i)/2).

Since ||F_i-EF_i||<=2R, the absolute centered inner-product covariance is at most

    4R^2 rho^floor((j-i)/2).                         (5)

The first reversed symbol is fixed and has zero covariance. Each diagonal variance is at most R^2. Since sum_(k>=1)rho^floor(k/2)=7, (5) implies

    E||sum_j(F_j-EF_j)||^2 <=57 N R^2.              (6)

This is a vector variance estimate, including cross-coordinate effects through the inner product. It does not assume independent symbols, stationary initialization after conditioning, identical positional features, or constant values of LayerNorm's row factors.

Normalize by N+1 and add the squared bias from (4). For N>=3,

    E_t[||H-Hbar||^2 | E]
       <=57 N R^2/(N+1)^2+324 R^2/(N+1)^2
       <=400 R^2/N.                                (7)

The constants are loose and uniform over t and all admissible position-dependent head maps.

The actual ratio, including its denominator dependence, obeys pointwise

    ||o-obar||
       <=exp(S)(||n-nbar||+V|z-zbar|)
       <=R ||H-Hbar||.

Combining with (7),

    E_t[||o-obar||^2 | E]
       <=400 exp(4S)(1+V^2)^2/N.                    (8)

Uniformity in t permits mixing over ANY prior without an extra between-parameter variance term: the comparison center obar is the same for every t.

## 4. Conditional Gaussian information, with Bob and all residuals retained

Let Q_0 be N(obar,sigma^2 I_d). Conditional on X (and any pre-existing source-data side information), M has law N(o(X),sigma^2 I_d). The standard reference-measure identity gives

    I(X;M | B,E)
       <= E[KL(N(o(X),sigma^2 I_d)||Q_0) | E]
       = E[||o(X)-obar||^2 | E]/(2sigma^2).          (9)

This is valid for the mixed parameter law and does not require B to be independent of Alice's symbols. It is not an illicit one-way strong-data-processing substitution for an interactive transcript.

Because the Gaussian noise is independent and the entire terminal continuation receives no other data-bearing input, its complete view is a deterministic or source-independently randomized function of (B,M,public metadata). Therefore

    I(Theta;Z | E)
       <= I(Theta;B | E)+I(X;M | B,E).              (10)

The terminal-parity theorem gives pairwise conditional KL at most 10^6(1+m u^2)(t-s)^2. Convexity against the prior mixture gives

    I(Theta;B | E)<=10^6(1+m u^2)a^2.               (11)

Equations (8)-(11) prove (2). Every terminal FFN, residual and normalization is covered by data processing only because it sees the specified noisy M and public pre-read state. This reasoning would fail with a raw terminal-symbol side port, earlier useful communication, or a later read from an unperturbed nonterminal bank. The stipulated exact actual terminal pair is already included in the conditioned experiment, rather than silently removed.

## 5. Why this does not yet yield the desired resource lower

Suppose the full terminal continuation is globally L-Lipschitz from Euclidean head error to output TV. Inserting the Gaussian replacement incurs the conservative expected output discrepancy

    E TV(Q_noisy,Q_exact)<=L sigma E||G||<=L sigma sqrt(d). (12)

All continuation gain, including every FFN and final normalization/softmax, belongs in L. The bound uses the global continuation, since Gaussian noise can reach vectors outside the original noiseless image. It asserts neither finite-word execution nor that adding noise is innocuous.

To make this discrepancy at most epsilon, choose sigma=epsilon/(L sqrt(d)). Then the second term of (2) becomes

    200 exp(4S)(1+V^2)^2 L^2 d/(N epsilon^2).       (13)

At the full-history rare averaged-risk scale epsilon of order u/sqrt(1+Nu), and Nu large, N epsilon^2 is of order u. Thus this generic bound costs order L^2 d/u, already far larger than the logarithmic information requirement. It supplies no increasing attention-call lower and does not repair the stopping-gate obstruction.

A sharper theorem would need the rare-parameter derivative structure, not merely a source-independent full-vector second moment. Conversely, the companion's constant-depth injective map proves that no such sharpening can hold for the exact unnoised output law without a new observation restriction. These two results delineate a genuine gap rather than claiming it is solved.

## 6. Scope and dependencies

- The exact counterexample is EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v1.md in this directory.
- The same-terminal reversal and parity information are from rare_statistical_resource_reset_20261106/RARE_TERMINAL_PARITY_INFORMATION.candidate.v2.md.
- The bounded-score numerator/denominator reduction follows the explicit interface of one_invocation_rate_lower_20261104/BOUNDED_SCORE_RATE_EXTENSION.candidate.v1.md, with the new conditional variance/noise proof above.

No additional communication lower, empirical evidence, training, optimality or novelty claim is made. The Gaussian assumption is explicit and cannot be silently substituted for exact arithmetic or deterministic quantization.
