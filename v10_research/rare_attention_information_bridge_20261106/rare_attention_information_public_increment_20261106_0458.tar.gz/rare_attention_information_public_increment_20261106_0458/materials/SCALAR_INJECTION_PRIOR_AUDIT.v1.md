# Exact scalar context injection: prior-art and scope audit

6 November 2026 UTC. Primary-source theorem/construction comparison. The proposed square-root injection is undergoing separate mathematical review; this note does NOT certify its number theory, raw embedding, normalization circuit or uniform resource bounds. No experiments, numerical checks, model execution or uploads.

## Decision

“One self-attention layer can preserve full context, even through a scalar” is already established prior art. If the current candidate passes review, its useful role is a concrete counterexample inside the stricter frozen actual-PreLN contract, blocking an invalid information-contraction bridge. Do not present it as a new general expressivity discovery, a statistical estimator, or proof that the mother prediction task is solved.

## Primary comparison: Kajitsuka–Sato, ICLR 2024

Sources inspected: https://arxiv.org/html/2307.14023v3 and the conference PDF https://proceedings.iclr.cc/paper_files/paper/2024/file/96ee35c170cb8720033b16259c305da9-Paper-Conference.pdf .

Theorem 2 (§3.4, printed p.6) gives rank-one, single-head, one-layer contextual mapping for finitely many tokenwise-separated sequences without within-sequence duplicates. The preceding paragraph explicitly allows scalar-head compression. The contextual object distinguishes token/context, not arbitrary permutation order without positions.

Contract differences and overlap:

- §2.2, equation (2), printed p.3 explicitly excludes LayerNorm.
- Appendix A.2, equations (29)–(30), printed p.16 selects Q/K scaling to enforce score gaps exceeding 2 log n+3. It is not a zero-score or uniformly frozen full-matrix-norm construction.
- Theorem 2 equation (8) gives potentially exponentially tiny output separation. The theorem supplies no rounded-execution or O(log n)-bit activation certificate.
- Corollary 2 and Appendix A.4 address positional encoding; its displayed encoding grows with position. Remark 1 and Appendix C (p.29) discuss masks. Thus position awareness and causal-mask compatibility are not by themselves new axes.
- Corollary 1's memorizing FFN has sample-dependent parameter cost; contextual injection does not make decoding free.

Classification: direct antecedent for scalar whole-context retention; not a checked cost-preserving implication of the proposed positive-epsilon, zero-score, rational-parameter realization.

## Current candidate: the only defensible distinction

The proposed construction fixes width eight, epsilon-one/gain-two full-feature PreLN, zero Q/K, raw positions rescaled to i/P^2, and values proportional to

    sigma_i / sqrt(5+(i/P^2)^2).

Its claimed mechanism is exact rational independence of position-specific radicals rather than score sharpening. All coefficient descriptions are claimed O(log N) bits, while computed activations use exact square roots. Ordinary terminal softmax is claimed to preserve injection. These are descriptions of the candidate under review, not results imported from Kajitsuka–Sato.

If valid, this is an implementation under stricter resource assumptions and a failure certificate for an overly strong bridge. A complete claim must still verify all N, the terminal/self-inclusive normalization factor, preparation stages, source-independent weights, every nonterminal state's full norm, final-LN monotonicity on the actual state curve, and actual paid depth. Constant depth must count preparation, not just the useful read.

Its distinction should not be advertised as a new theorem about general one-layer context memory. No exhaustive search for radical encodings or normalized algebraic injections was conducted here; exact novelty remains unestablished.

## Why statistical information and useful decoding differ

These are direct mathematical consequences, conditional on candidate injectivity, rather than literature claims:

1. On the finite set of length-N binary words, an injective deterministic statistic S has an inverse on its image. For any two source distributions P,Q on those words,

       KL(S_# P, S_# Q)=KL(P,Q),

   where S_# denotes the pushforward by S. The same holds for TV. More simply: replacing a word by its exact unique scalar label loses no statistical information. Therefore a universal O(Nu^2 Delta^2) KL bound for every such raw one-read scalar cannot follow merely from small dimension or diffuse attention, if the full word has KL of order Nu Delta^2.

2. If 2^N distinct scalar codes lie in [-B,B], their minimum pairwise distance is at most 2B/(2^N-1). A uniform bit-exact recovery promise necessarily confronts such fine separation. This pigeonhole upper bound is not a matching lower bound on the particular radical code's separation.

3. If two codes separated by eta require target outputs separated by a, any scalar decoder fitting both to error below a/4 needs Lipschitz constant at least a/(2 eta). A bounded-gain decoder need not exploit the exact information. Which close pairs have distinct prediction targets must be proved; generic packing alone does not yield the requested statistical lower.

4. Short rational coefficient descriptions do not imply short stored activations. Exact radicals and their sums may carry arbitrarily fine distinctions. The candidate's O(log N) coefficient bits cannot be relabeled O(log N) execution precision or message cardinality.

5. A one-dimensional probability output can remain injective while all its values are poor estimates of the true next-symbol law. Injection and risk accuracy are logically separate.

## Hahn and Merrill: preserve the already audited distinctions

The following comparisons use the existing full-text audits in `../execution_contract_prior_audit_20261106/ATTENTION_ACTIVATION_PRIMARY_AUDIT.md` and `FINITE_PRECISION_PRIMARY_FULLTEXT_AUDIT.v1.md`; the main publisher/arXiv records were also reopened this round. They are not fresh line-by-line re-audits.

Hahn, https://aclanthology.org/2020.tacl-1.11.pdf , Lemma 5 (p.165), proof pp.166–167, and corrected supplement §S2 equations (34)–(35): fixed-depth, bounded-position, smooth-attention single-token influence is O(1/N). This is a small-distance statement, not equality of outputs. Exact injection with tiny gaps is compatible with it. The correction's changed-attention-weight term must not be omitted. Theorem 6 concerns designated language cross-entropy tasks, not a blanket information-erasure theorem.

Merrill–Sabharwal, https://arxiv.org/html/2210.02671v7 , §2.1 Definitions 1–2, §3 Proposition 1 and §4 Theorem 2: their arithmetic gives actual states a p-bit floating datatype. Proposition 1's uniform-attention underflow threshold is log_2 log_2 N total float bits, not log N. Their logical expressivity result concerns log-precision execution. Exact-real radical injection does not contradict either. Their displayed normalization also differs from epsilon-one PreLN; nevertheless the primary mismatch here is stored-state arithmetic, not coefficient descriptions.

## Required next step

Replace the failed universal “small scalar implies small information” inference with an explicit restriction: finite message alphabet, paid quantization, noise model, decoder sensitivity, or a proved task-dependent sufficient simulation. Any such restriction must be part of the mother theorem's declared model, not silently appended after the injection counterexample. Establishing a bound for the rare-family prediction target under a legal decoder is still open after this audit.
