# One-read overall prediction with the existing output-range floor

6 November 2026 UTC. Revision 2, preserving v1 unchanged. Charges the entire useful value width even when accuracy padding exceeds N, and fixes the small-N accuracy convention. Analytical companion to `ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md`. Independent review pending. No experiments, simulations, numerical diagnostics, parameter generation, uploads or public writes. This is a derived compiler specialization of old mechanisms and an inherited statistical rate, not a new rate or novelty claim.

## 1. Precise statement

Fix a declared dyadic design clipping level 0<alpha<=1/4 and an implementation tolerance 0<epsilon<=1/16. Retain the binary stationary rare family, raw one-hot input, scalar public positions and synthetic terminal of the conditional companion. For every N>=6 there is a source-independent actual PreLN network with exactly one useful zero-score causal attention invocation and ordinary final vocabulary softmax satisfying

    R_(N,u,t)(Q)
      <=1300 u/sqrt(1+(N-2)u)
          +w(alpha-q)_+ + epsilon,                (E1)

simultaneously for 0<u<=1/100, 1/2<=t<=3/4, where q=ut/w and w=(1-u)/3.

It has a complete per-row/full-parameter envelope C_alpha, fixed after alpha and before N,u,t,epsilon vary, with

    d=O_alpha(N+epsilon^(-1)),
    d_value=O_alpha(N+epsilon^(-1)), with O(N) nonzero coordinates,
    D=O_alpha(log N+log(1/epsilon)),                (E2)

and intermediate FFN width O_alpha(N+epsilon^(-1/2)) before ordinary constant-factor padding into d. All head, full-state, matrix, bias and primitive constants are bounded by C_alpha. LayerNorm epsilon=1, gain=2, shift=0 throughout; the final head is ordinary bounded affine-softmax. Its useful attention count is one, not its total sequential depth.

For epsilon_N=min{1/16,1/N}, (E2) reduces to width O_alpha(N), depth O_alpha(log N), and implementation remainder O(1/N). The whole physical value width is charged, including inert coordinates; no special permission for rectangular narrow value projections is needed. The constants can depend on alpha. This does NOT evade the frozen output floor as alpha tends to zero: requiring alpha to vary with rarity changes the declared norm/range resource, and C_alpha is not asserted uniform in alpha.

Alpha specifies the reference predictor's interval projection. Because the physical output approximates it, this note does not assert the exact sharp realized logit span log((1-alpha)/alpha). A strict exact-span theorem would need a reserved approximation margin or an additional range-preserving argument. The physical full norms and thus some fixed realized span remain bounded by C_alpha, independently of N and epsilon.

## 2. Reuse one wide read and compute both needed row counts locally

Use the conditional companion's Sections 2-3 without change. With R^2=Q>=N and s=1/R, after the unique read and paid saturation every row j has ordered prefix coordinates

    a_(j,i,c)=s 1{i<=min(j,N)}1{X_i=c}.

Form, for (a,b) equal to A=00 and C=10, and c=0,1,

    tau_(j,i,ab,c)=ReLU(a_(j,i-2,a)+a_(j,i-1,b)
                                         +a_(j,i,c)-2s),
    f_(j,ab,c)=s sum_(i=3)^N tau_(j,i,ab,c),
    v_(j,ab)=f_(j,ab,0)+f_(j,ab,1).

These equal C_(j,ab,c)/Q and J_(j,ab)/Q. Computing all four contexts would also cost only a constant factor, but is unnecessary because rows B,D are known fair. Every input coordinate is used in a bounded number of triple gates. Complete gate/bias norms and complete states remain bounded. Each count aggregation has norm at most one, as in the companion. No context features or adjacent-token access are given externally.

## 3. Different A and C ratio branches, including exact zero fallback

For A use the companion's exact add-one table, obtaining

    r_(j,A)=(C_(j,A,0)+1)/(J_(j,A)+2),

where r denotes the next-ZERO probability.

For C use a separate 1/Q-grid selector h_m=s1{J_(j,C)=m}, m=0,...,N-2. Form

    z_(j,m)=ReLU(s f_(j,C,0)+h_m-s).

If m is inactive the gate is zero because f<=1. If m=J it equals s C_(j,C,0)/Q. Set block m=0 identically to zero. For m>=1, amplify by the public factor

    A_m=RQ/m,

through O(log N) diagonal stages of norm at most two, followed by the paid balanced sum tree. The output is exactly

    r_(j,C)=C_(j,C,0)/J_(j,C) if J_(j,C)>0,
    r_(j,C)=0 otherwise.                           (E3)

No discontinuous test or external division was inserted: zero is one branch of the finite-grid ReLU selector table. All rows have integer counts on the same grid, exactly one active selector, and 0<=C<=J. Consequently all intermediate active values are at most one and all inactive values are zero. This is a simpler all-row domain than the old terminal-only rational readout. The m=0 zero map is implemented with a zero diagonal entry; for m>=1 all multiplier factors are positive and at most two.

The rational table has O(N) entries, O(log N) coefficient-description bits per entry, O(log N) paid depth, bounded matrix norms at every stage and bounded complete states. A and C branches run in parallel with only a constant-factor full-norm increase. Set r_B=r_D=1/2 using the anchor.

## 4. Recover the actual terminal pair internally

Project the broadcast bank onto the four coordinates at indices N-1 and N. Restore their scale from s to one by log2 R paid diagonal doublings. Their complete norm stays at most sqrt(2) at every row: a coordinate is either zero or a partial amplification of one original symbol bit.

Write the resulting two symbol onehots as y_old and y_new. For each ab define

    g_ab=ReLU(y_old(a)+y_new(b)-1).

At the synthetic terminal exactly one g_ab is one and it identifies the real pair (X_(N-1),X_N). At rows j<N, the final symbol is absent, so all g_ab vanish; at rows j>=N the pair is correctly available. This fixed-index local projection occurs AFTER the one global read, so it is not a free suffix port or structural local-copy mask.

Select the next-zero estimate continuously by

    z_j=sum_ab ReLU(r_(j,ab)+g_ab-1)
                            +(1/2)(1-sum_ab g_ab). (E4)

Because g is either one-hot or all zero, (E4) equals the selected row estimate or the harmless nonterminal default 1/2. Every r is in [0,1], so the ReLU gates implement the binary selectors exactly on the reference domain. The finite sums have constant dimension and constant operator/bias norms. At the synthetic terminal this is precisely the OLD mixed estimator: add-one at A, unsmoothed zero-fallback at C, exact fair at B,D.

## 5. Projection, log preparation and physical compilation

Clip z_j to [alpha,1-alpha], yielding p_j=(clip(z_j),1-clip(z_j)). The reference is a probability vector at every row, including ablation. Use the old scaled-hinge approximation to log on [alpha,1] with

    m=O_alpha(epsilon^(-1/2))

hinges per coordinate and uniform log error at most a fixed small multiple of epsilon. Input scaling 1/sqrt(m) controls fanout and full biases, while adjacent slope differences O_alpha(1/m) control the complete output row norm. Coefficient descriptions use O_alpha(log(1/epsilon)) bits. Thus growing log precision purchases width rather than unbounded primitive norms.

Pair all coordinates, append the complete output-bank copy and scratch clear, and keep a common bounded logical tube for original and single-read-ablated programs. The reference stage count before restoration is O(log N), while its width is O_alpha(N+epsilon^(-1/2)). The common fixed Lipschitz envelope is independent of epsilon because of the scaled hinges.

Apply exactly the conditional companion's small-amplitude actual-PreLN compiler. Select eta=2^(-M) so

    C eta^2 L^(m_ref)/d <= c epsilon

and the common tube conditions hold. This requires M=O_alpha(log N+log(1/epsilon)). Add inert zeros so

    d>=C_alpha (N+epsilon^(-1)).

The inherited radial restoration and final-LN logit error are bounded by

    c epsilon+7(Z+c epsilon)^3/(12d).

With constants sufficiently large, the final ordinary-softmax prediction differs from the projected reference by at most epsilon in TV on EVERY input word, for both original and ablated network. No execution-time log/division primitive, nonzero sqrt(d)-norm padding, arbitrary terminal decoder, or uncharged clearing is added.

## 6. Statistical envelope and physical usefulness

The old full averaged theorem in `../u_blind_full_averaged_20261103_2147/full_averaged_tv_bound_v1.html` gives the mixed reference risk at most

    1300 u/sqrt(1+(N-2)u).

The old projection comparison in `../rare_statistical_resource_reset_20261106/RARE_OUTPUT_RANGE_ASSESSMENT.candidate.v1.md` applies because alpha<=1/4: A and fair rows lie inside the allowed interval, while the C-row target q has the only possible range deficit. Pointwise projection therefore gives

    R(projected reference)<=1300 u/sqrt(1+(N-2)u)
                                              +w(alpha-q)_+.

The pathwise implementation error proves (E1) without any independence assumption between terminal pair and counts. Statistical estimation, same-history dependence handling and this projection inequality are inherited results, not new proofs.

Deleting the single read removes all recovered symbols and counts. In (E4) all pair selectors then vanish and the reference returns 1/2 at every row. On the all-zero word the actual terminal pair is A, and the unablated next-zero estimate is (N-1)/N>=5/6. Its projected value is at least 3/4 because alpha<=1/4. Thus ideal separation is at least 1/4. With epsilon<=1/16, the two actual physical outputs remain separated by at least 1/4-2epsilon>=1/8. The attention is genuinely useful in this implementation.

## 7. Charged resources and limits

Let W=O_alpha(N+epsilon^(-1)), D=O_alpha(log N+log(1/epsilon)), and b=O_alpha(log N+log(1/epsilon)). Conservative dense accounting gives:

- parameter coefficients O(D W^2), parameter-description bits O(D W^2 b), including all LN gains/shifts;
- rolling all-row real states O(NW), plus O(N^2) score slots if attention is materialized;
- dense projections/FFN work O(D N W^2);
- useful attention products O(N^2 W), charging the complete physical value width even though only O(N) value coordinates are nonzero; dummy slots densely evaluated cost O(D N^2 W);
- public positions O(N log N) bits and explicit mask O(N^2) bits if stored.

For epsilon_N=min{1/16,1/N} these become the same O_alpha(N)-width, O_alpha(log N)-depth and O_alpha(N^3 log N) dense-work orders as the conditional witness, with an O(1/N) implementation remainder.

These are exact-real mathematical constructions. A sufficient additive sublayer error radius is polynomially small in N and epsilon by the same global Lipschitz propagation argument as the companion, so its negative logarithm is O_alpha(log N+log(1/epsilon)). This is not a finite machine arithmetic, accumulator, trained-network or emitted-parameter certificate.

If a known rarity floor rho is declared and alpha is chosen below every allowed q, the range term vanishes. The associated alpha-dependent norm and log-approximation constants must then be charged as rho-dependent resources. No uniform-in-rho fixed norm/range theorem is claimed. Conversely, for fixed alpha and u tending to zero, the floor tends to alpha/3 and cannot be removed by this or any other bounded-logit history processor.

The purpose of this extension is to show that one useful attention invocation can implement the old statistical-plus-range envelope under complete, explicitly paid actual-PreLN resources. It does not claim a better estimator, width optimality, a fixed-width separation, a matching information budget, or external novelty.


## Revision 2 correction record

1. Version 1 stated the useful value dimension as O(N) while allowing model-width padding O(epsilon^(-1)). That is realizable with rectangular value maps but needlessly relies on that architectural convention. This version charges the full standard-head value width O(N+epsilon^(-1)); only its nonzero coordinate bank is O(N). The main epsilon_N=O(1/N) specialization remains linear width either way.
2. Version 1 allowed epsilon<=1/16 but discussed epsilon=1/N for all N>=6. The uniform specialization is epsilon_N=min{1/16,1/N}, which is always at most 1/N and leaves all stated resource orders unchanged. Neither change modifies the reference predictor, statistical bound or physical compilation.
