# From rare-context statistical information to actual attention resources

2026-11-06. Target: the original unknown second-order prediction problem, not execution-noise robustness.

## Frozen mother contract

The source is the stationary binary rare family A=00,B=01,C=10,D=11 with pi=(u,w,w,w), w=(1-u)/3, q=ut/w, and transition rows (1-t,t,0,0),(0,0,1/2,1/2),(q,1-q,0,0),(0,0,1/2,1/2). Current statistical bridge uses 0<u<=.01 and .5<=t<=.75. The query is the real terminal pair of the same observed trajectory. Main loss is expected next-token TV, with terminal-A conditional loss explicitly separate.

The actual network uses raw symbols and public normalized positions, epsilon-one PreLN with gain2, bounded complete states and complete affine-map norms, causal softmax attention, residuals, ordinary final LN plus softmax, and paid positionwise ReLU computation. N-dependent public parameter families are allowed, but their coefficient description, full width/value dimension, and total depth must be charged. Exact-real execution is not interchangeable with a finite activation alphabet.

## Prior result used, not restated as innovation

The earlier bridge proved total interactive-bit lower c u 2^-b/sqrt(1+Nu²). At full-history statistical accuracy this requires only order log(1/u) bits, which one sufficiently precise scalar message may already carry. It does not imply multiple attention invocations. Generic quantization composed with this lower alone is therefore insufficient.

## Two candidate tests

1. Raw exact-information upper bound test. Is information in a bounded-width, bounded-score single actual attention read necessarily of order Nu² rather than Nu? Candidate counterexample uses position-dependent positive-epsilon LN square-root weights, zero scores and a scalar value. Algebraic independence may make the scalar injective on all finite raw histories while all model coefficients have logarithmic description length. If correct, exact output KL can retain full-history KL even when final readout has bounded sensitivity and no useful prediction accuracy. This distinguishes statistical information of an exactly observed real number from computationally accessible target information.

2. Useful statistical readout test. Reuse the audited wide broadcast, then relocate triple-count computation to terminal-local paid FFNs instead of a second attention aggregation. Width O(N) can hold all position-tagged raw symbols, form local triples and sum them within one row. This may reduce useful invocation count to one at depth O(logN), with full-matrix/full-state bounds. The inherited rare conditional-risk rate is a benchmark, not a new estimator. Ordinary fixed-logit output still imposes the known C-row floor on overall risk; any claimed overall upper must show that floor or declare a permitted rarity/output range.

## Failed implications that must remain rejected

- Injectivity of a real scalar does not imply a cheap decoder or low prediction risk.
- A constant-Lipschitz output can still be injective on a finite but exponentially crowded codebook. KL of exactly observed outputs is invariant under injective maps and need not obey a small-gain information contraction.
- O(logN) coefficient bits do not imply O(logN) arithmetic or activation bits: square roots and softmax may be exact irrational values.
- Reconstructing all 2^N histories losslessly needs N representation bits by counting, but parameter estimation at the target risk may require fewer. A worst-history coding bound is not a source-average statistical lower.
- A width-O(N) construction is not a fixed-width counterexample, and one wide value vector is not a scalar message.
- Terminal-A accuracy cannot be labeled a vanishing full rare-u risk under a uniformly bounded ordinary final-logit range.

## Novelty gate

One-layer contextual mapping and even scalar full-context compression already have direct precedents, notably Kajitsuka–Sato (ICLR2024). A construction satisfying this project's more restrictive actual positive-epsilon PreLN and fixed-score/full-norm contract would be a precise obstruction to this proof route, not a new general expressivity discovery. The project’s existing wide compiler and normalized arithmetic must be credited as dependencies.

All candidates and revisions are retained, independently checked before final claims. No scientific experiments, upload or publication are part of this step.
