# One actual PreLN read already carries the rare-A statistical information

6 November 2026 UTC. Analytical candidate; independent exact-file review pending. No scientific experiment, numerical enumeration, model execution, parameter-generation run, upload, or public write. This note reuses the already reviewed wide broadcast and positive-epsilon PreLN compiler. Its narrow addition is moving the rare-row counting into the terminal's paid, wide positionwise computation, thereby removing the second useful attention invocation for this conditional statistical task.

## 1. Main result and strict scope

Use the stationary binary rare family from `../rare_statistical_resource_reset_20261106/RARE_PARITY_INFORMATION.candidate.v1.md`: pair states A=00, B=01, C=10, D=11, stationary law (u,w,w,w), w=(1-u)/3, q=ut/w, 0<u<=1/100, 1/2<=t<=3/4. The next-one probability at the ACTUAL terminal pair A is t. There are N raw symbols and one source-independent synthetic terminal, N>=6, n=N-2 observed transitions.

There is a sufficiently large ABSOLUTE finite envelope, fixed before N,u,t vary, and a source-independent, length-dependent untied family Q_N with:

- actual positive-epsilon full-feature PreLN residual blocks, epsilon=1, coordinate gain 2 and zero shift;
- self-inclusive causal ordinary softmax attention; exactly ONE useful invocation, one head, zero scores; all other attention outputs are identically zero;
- model width and FFN intermediate width O(N), useful value dimension O(N), paid sequential depth O(log N);
- bounded complete per-row state/value Euclidean norms, matrix operator norms, full bias-vector norms and primitive Lipschitz constants, all independent of N,u,t;
- an ordinary final epsilon-one gain-two LayerNorm, bounded affine binary vocabulary head and ordinary softmax;
- the actual-terminal conditional risk bound

    sup_t E_(u,t)[ |Q_N(1)-t| | (X_(N-1),X_N)=A ]
       <= min{1,157/sqrt(1+(N-2)u)} + C/sqrt(N).       (1)

The network is NOT given u, t, the terminal pair, paired input features, counts, or any data-dependent weights. Its only public input beyond raw symbols is scalar position i/P, P=2^ceil(log2(N+1)), and a constant anchor. In fact this construction estimates the A-row parameter on every history; it does not need to test whether the terminal pair is A. Conditioning in (1) is on the actual event in the source law, not a supplied feature or independent query.

This is NOT an overall rare-family prediction upper bound. On C the correct next-zero probability is q=Theta(u), and the frozen bounded-logit output contract cannot attain overall risk O(u/sqrt(1+Nu)) uniformly as u tends to zero. That old obstruction remains unchanged. The result addresses exactly the terminal-A information event used in the new communication lower.

Gain 2 is the diagonal operator 2I of norm 2; the Euclidean norm of its d-entry parameter vector is not separately required to remain constant. Such an extra requirement would exclude the inherited growing-width model itself. The family has exact-real evaluation semantics. See Section 8 for the precision charges and limitations.

## 2. Reused first-read broadcast, with its costs retained

Let R be the smallest power of two with R^2>=N, s=1/R, and Q=R^2. Then N<=Q<4N. The construction of `../parallel_width_depth_20261104/CANDIDATE.v2.md`, Sections 1-2, starts with local raw symbols x_j(c), c=0,1, and the scalar position p_j=j/P.

At every row j and for i=1,...,N, form d_i=s|p_j-i/P|, apply H=log2 P paid clipped doublings d_i<-min(s,2d_i), and let g_i=s-d_i. The resulting selector is s exactly when j=i, and zero otherwise. Form

    b_(j,i,c)=ReLU(s x_j(c)+g_i-s).

The whole selector/token fanouts have norm at most s sqrt(N)<=1; the complete selector and gate bias norms are bounded. All apparent sharpness is purchased by H sequential bounded-gain stages. At the synthetic row x_(N+1)=0, every source pulse is zero.

One zero-score full-prefix attention with value coordinates b_(j,i,c) gives

    a_(j,i,c)=s 1{i<=j} 1{X_i=c}/j.

Value/output maps have bounded operator norms and the full value vector is bounded; there are 2N logical value coordinates, not N uncharged heads. Another H paid clipped doublings a<-min(s,2a) yield

    a_(j,i,c)=s 1{i<=min(j,N)} 1{X_i=c}.              (2)

At every row the complete broadcast bank has norm at most s sqrt(N)<=1. This source-selection and broadcast operation is OLD. It already leaves the entire ordered history in the terminal's wide bank. The second attention in the old full-history compiler was used after each original row formed its own triple. It is unnecessary if those triples are formed INSIDE the wide terminal bank instead.

No destination selector, predecessor port, or external pair binding is supplied here.

## 3. Paid local triple binding and norm-one count aggregation

For every i=3,...,N and c=0,1, at every row j form

    tau_(j,i,c)=ReLU(a_(j,i-2,0)+a_(j,i-1,0)
                                  +a_(j,i,c)-2s).   (3)

By (2), this equals s times the indicator of the observed triple 00c ending at i, provided i<=j; otherwise it is zero. If one required position is absent, at most two s terms remain, so the gate is zero. Thus no fake boundary transition is introduced.

The linear map feeding all these gates has bounded operator norm: every source coordinate appears in only a fixed number of gates, and each gate has three inputs. The complete bias vector has norm 2s sqrt(2(N-2))<=2sqrt(2). The complete output bank has norm at most s sqrt(N)<=1, since at most one c is active per i.

Now compute the two scalars

    f_(j,c)=s sum_(i=3)^N tau_(j,i,c)=C_(j,c)/Q,
    v_j=f_(j,0)+f_(j,1)=J_j/Q.                    (4)

Here C_(j,c) counts the 00c triples in the visible prefix, and J_j=C_(j,0)+C_(j,1). The two aggregation rows have disjoint supports, each with Euclidean norm s sqrt(N-2)<=1. Consequently this is a norm-at-most-one linear map, NOT a norm-sqrt(N) uncharged sum. The extra multiplication by s makes the result a frequency with public denominator Q.

At all rows, 0<=C_(j,c)<=J_j<=N-2 and the quantities lie on the exact 1/Q lattice. Thus this local computation obtains the two rare-row transition counts up to one public scale, after only ONE attention invocation. Its FFN width O(N), full state bound, and constant number of local stages are all charged.

## 4. Paid add-one ratio without an external division decoder

We specialize the OLD denominator-selector construction, now using the public grid 1/Q rather than 1/(N+1). For m=0,...,N-2, start

    d_m=s|v_j-m/Q|,

apply log2 Q clipped doublings at cap s, and set h_m=s-d_m. Because v_j=J_j/Q at EVERY row, h_(J_j)=s and every other h_m=0. The scaled scalar fanout, centers and cap biases have bounded full norms. There is no rounding operation or discontinuity.

For c=0,1 form

    z_(j,m,c)=ReLU(s(f_(j,c)+1/Q)+h_m-s).           (5)

Only m=J_j survives, with value s(C_(j,c)+1)/Q. Indeed inactive blocks vanish because f_(j,c)+1/Q<1. Multiply block m by

    A_m=RQ/(m+2),

factoring this public positive rational into O(log N) diagonal stages with each diagonal norm at most 2 (powers of two, a final rational factor in [1,2), and identity fillers). Every coefficient has an O(log N)-bit rational description. During amplification the active coordinates never exceed their final values, which are at most one. Exactly one block is active at every row.

A paid balanced sum tree, each stage of operator norm sqrt(2), gives the binary vector

    B_(j,c)=(C_(j,c)+1)/(J_j+2).                   (6)

All intermediate complete vectors are bounded. At the synthetic terminal, B_(T,1) is exactly the historical rare-A add-one estimator. If the single attention is ablated, its new broadcast bank remains zero, every tau and count is zero, and (6) is (1/2,1/2) at every row. Thus the ablated reference also stays in the same bounded domain.

This is a length-dependent rational table, not a uniform constant-cost division primitive. The table width, coefficient descriptions, selector depth, factored gains and final tree are paid.

## 5. Ordinary softmax output and actual positive-epsilon PreLN

Clip B_(j,1) to [1/2,3/4], call the result z_j, and set p_j=(1-z_j,z_j). Projection cannot increase |z_j-t| for t in [1/2,3/4]. Both coordinates are in [1/4,3/4]. These are bounded affine/ReLU stages.

Apply the already reviewed log interpolation of `../nonlinear_statistical_frontier_20261106/WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md`, Section 3, at fixed floor a=1/4. O(N^(1/4)) scaled hinge coordinates approximate both log probabilities with uniform error at most N^(-1/2)/256. Scaling each fanout/hinge by 1/sqrt(m) and charging its output weights keeps complete matrices, biases and state vectors bounded. Coefficients have O(log N)-bit dyadic descriptions. This is a paid ordinary two-layer-ReLU computation, not a logarithm oracle.

Copy the prepared logits into a designated output bank and clear all other logical registers, including positions, tokens, selector banks, count blocks, interpolation banks and scratch. Clear the anchor last. Pair every logical coordinate with its negative. The complete reference ends at

    z_ref=(ell_0,-ell_0,ell_1,-ell_1,0,...,0).

The whole reference, including all clears, has m_ref=O(log N) bounded affine/ReLU/zero-score-attention stages. Both the intact and single-read-ablated reference have uniformly bounded complete state norm Z and common dimension-free primitive Lipschitz envelope L>=2. Zero inert coordinates give a physical width d=Theta(N), with a sufficiently large absolute multiplicative constant.

The exact compiler mechanism is reused, not newly asserted: initialize the paired physical vector as h=eta z, eta=2^(-M), through a bounded raw-symbol/position embedding. For gain-one epsilon-one LN on the paired mean-zero subspace,

    LN_1(eta z)=eta s_eta(z)z,
    s_eta(z)=(1+eta^2 ||z||^2/d)^(-1/2),
    |1-s_eta(z)|<=eta^2 Z^2/(2d).

Homogenize affine biases with the maintained anchor. A homogeneous residual branch implementing F-I then deviates from the ideal overwrite F by O(eta^2/d) in complete logical-vector norm. The unique attention has zero queries/keys, so it is genuinely uniform. Its source-row normalization factors give the same O(eta^2/d) maximum-row local error, including the full growing value vector.

The bounded-tube induction is

    e_l<=L e_(l-1)+C eta^2/d,
    max_(l<=m_ref) e_l<=C' eta^2 L^(m_ref)/d.        (7)

Choose one eta, common to the intact and ablated references, so the right side is at most

    xi_N=min{N^(-1/2)/1024,s/16}

and the common tube constraints hold. This requires M=O(log N), with absolute constants. Physical selectors need not remain exactly on logical lattices; their continuous full-vector errors are covered by (7). Replace each interior gain-one LN by gain two and halve the consuming first FFN/value matrix. This exact reparameterization makes all actual LNs have the prescribed gain two.

After complete preparation and clearing, use M paid local amplitude-restoration steps

    h_(k+1)=h_k+h_k/sqrt(1+||h_k||^2/d).

They are ordinary gain-two-PreLN FFN residual blocks using a signed-ReLU linear identity and one-half gain. The reviewed geometric error calculation gives, for h_0=2^(-M)u_0 with ||u_0-z_ref||<=xi_N,

    ||h_M-u_0||<=||u_0||^3/(12d).

A final prescribed gain-two LN and head (1/2)P_out have logit error at most

    xi_N+7(Z+xi_N)^3/(12d).

Take the constant in d=Theta(N) sufficiently large, and allocate the interpolation error similarly, so the physical ordinary-softmax output differs from p_j by at most C/sqrt(N), and, when useful for ablation, by less than 1/32 for every N>=6. This includes approximate scratch clearing; no residual coordinate is discarded for free.

All physical states remain bounded. There is no unbounded one-shot 1/eta gain, nonzero norm-padding of size sqrt(d), singular normalization, custom probability readout or free decoder. The construction satisfies the actual frozen PreLN syntax.

## 6. Conditional statistical prediction and genuinely useful read

The inherited exact same-history result is Section 8, equation (8.5), of

    ../u_blind_full_averaged_20261103_2147/full_averaged_tv_bound_v1.html.

For the exact estimator in (6), it proves

    E_(u,t)[ |B_(T,1)-t| | terminal A ]
       <=min{1,157/sqrt(1+(N-2)u)}.

Its reversed-chain flow proof explicitly handles terminal dependence. We do not assume conditional iid transition counts or an independent query. Projection and the uniform physical implementation error give (1). This statistical bound, estimator and constant 157 are OLD.

The one actual read is pathwise useful. Take the length-N prefix of 001001001..., N>=6. Every observed departure from 00 is to 1, and at least two such transitions occur. Hence B_(T,1)>=3/4, and its clipped value is 3/4. The ablated reference returns 1/2. Both physical outputs are within 1/32 of their respective reference probabilities under the SAME eta, width and restoration schedule. Their separation is therefore at least 1/4-2/32=3/16. This witness has positive probability under every u,t in the family, although usefulness only requires a legal raw word.

This proves one useful invocation suffices for the conditional statistical task. It does not prove one is necessary, nor that the overall rare-rate task is solved.

## 7. The very logarithmic parameter information needed by the bit lower

Let Theta be uniformly distributed on the interval centered at 5/8 with length

    a_u=1/[10000 sqrt(1+m u^2)],

where m is Bob's parity length in the communication theorem. Let E be the actual terminal-A event. Since Pr(E|Theta)=u, conditioning on E leaves this prior unchanged.

Choose horizons N=Theta_order(u^(-2)), meaning c_1 u^(-2)<=N<=c_2 u^(-2) for fixed positive constants c_1,c_2 and sufficiently small u. Then a_u is bounded above and below by positive constants, and (1) implies

    D_u=E[|Q_N(1)-Theta| | E]<=C_* sqrt(u).

The same Laplace maximum-entropy inequality used in the communication lower gives

    I(Theta;Q_N(1)|E)
       >=log(a_u/(2e D_u))
       >=(1/2)log(1/u)-O(1) nats.                 (8)

The new parity-plus-terminal information theorem bounds Bob's local baseline by 1/100 under this prior. If V is Bob's parity observation, then

    I(Theta;Q_N(1)|V,E)
       =I(Theta;Q_N(1),V|E)-I(Theta;V|E)
       >=(1/2)log(1/u)-O(1).                      (9)

Thus this ONE actual read supports a genuine estimator whose statistical output contains the growing conditional parameter information used by the lower. It is not merely an arbitrary injected code. There is no conflict with the finite-bit communication lower: the value dimension, positional addressing and decoder cost here grow. A simulation transmitting the whole wide message is much more expensive than O(log(1/u)) bits; (8)-(9) are information lower statements, not a claim of a matching short distributed protocol.

There is also a direct ordered-data statement. At the intermediate stage immediately after the paid saturation following the only attention, (7) makes the designated physical bank divided by eta within s/16, in full Euclidean norm, of (2). At the synthetic terminal, comparing each pair of coordinates with s/2 uniquely recovers every X_i. Hence this clean intermediate terminal state is injective on raw histories. That threshold is only a mathematical information witness; it is not inserted as a network decoder. The network's actual continuous statistical decoding is Sections 3-5.

## 8. Full resource and precision ledger

For fixed absolute accuracy constants:

- useful attention invocations: exactly 1; useful head count: 1; logical value dimension: 2N, with constant-factor paired physical representation O(N);
- physical model and intermediate FFN width: O(N); paid pre-read selector depth O(log N), post-read saturation O(log N), local triple/count stages O(1), denominator/select/amplification/tree O(log N), log preparation O(1) at O(N^(1/4)) width, clears O(1), restoration O(log N); total actual depth O(log N);
- all per-token complete states, values, matrices, biases and primitive Lipschitz constants are bounded by one fixed absolute envelope; the global continuation Lipschitz constant is at most L^(O(log N))=N^O(1), not O(1);
- public positions use O(N log N) total description bits; parameter values use O(log N)-bit rational/dyadic descriptions, including eta; the public count-table/positional information is included;
- conservative dense untied coefficients O(N^2 log N), coefficient-description bits O(N^2 log^2 N), including O(dD) LN gain/shift entries;
- rolling all-row real activations O(N^2); explicit attention scores or mask O(N^2) additional slots/bits;
- dense projection/FFN scalar work O(N^3 log N); one useful dense attention product O(N^3), or O(N^3 log N) if dummy attention slots are evaluated densely.

These are not good total-compute claims. A streaming empirical-count baseline is vastly cheaper; this witness addresses the logical inference from total information to invocation count.

Precision has THREE distinct meanings:

1. Coefficient/public-input description lengths are O(log N). This alone is not an arithmetic guarantee.
2. The clean intermediate physical history-bank separation is at least a constant times eta/R=N^(-O(1)); immediately after the read and before paid saturation it is smaller by a further factor at most N+1. Thus sufficiently fine O(log N)-scale fractional resolution is consistent with distinguishability, but a free infinitely accurate bounded scalar is not the stated resource.
3. A sufficient adversarial execution-error radius can also be charged without claiming a floating-point implementation. Every complete actual sublayer is dimension-free Lipschitz in maximum-row Euclidean norm; uniform attention and epsilon-one LN retain this property. For additive perturbations of radius delta after each residual sublayer, output error is at most C delta L_*^(2D+1), with an enlarged fixed L_*>1. Since D=O(log N), choosing delta=N^(-A) for sufficiently large fixed A makes extra TV error O(N^(-1/2)). A larger fixed A also preserves intermediate history-bank separation. This is a robust error-radius statement p=-log2 delta=O(log N), NOT a machine word-length, rounded-LN/softmax, accumulator-size or complete finite-arithmetic theorem.

If all-dyadic parameters are wanted, round the rational table with zero support and paired antisymmetry preserved, to N^(-A) coordinate error. Operator errors cost at most d times this precision, and the polynomial continuation sensitivity is absorbed by a sufficiently large fixed A. This gives the same asymptotic approximate output, not exact ratio evaluation. It changes none of the information or invocation conclusions.

At N=Theta_order(u^(-2)), the paid width is Theta(u^(-2)), depth O(log(1/u)), and sufficient coefficient/error-radius exponents are O(log(1/u)). Dense storage/work costs remain as above. The construction therefore gives no fixed-width or equal-total-resource separation against repeated attention.

## 9. What changed, what did not, and the stopping implication

Old material reused verbatim at the mechanism level:

- scaled positional addressing and single wide full-history broadcast;
- bounded-gain selector/denominator table and balanced reductions;
- small-amplitude paired positive-epsilon PreLN compilation, complete scratch clearing, dimension-diluted restoration, and ordinary-softmax logit preparation;
- the rare-A add-one statistical rate and entropy-distortion inequality.

The narrow derived change is that after the first wide broadcast, positionwise shifted channel accesses (3) and the norm-one weighted sum (4) compute the rare-row counts at the terminal. This removes the second useful attention for the conditional statistical task while charging every local operation. No novelty or priority claim is made. This is an analytical composition, not a compiled/executed model.

The earlier one-invocation width-Lipschitz lower is not contradicted: its charge includes value dimension and global continuation sensitivity. This family pays linear value dimension and polynomial continuation sensitivity. Its binary rare-A conditional task also differs from that lower's full-source overall risk task.

Consequently, the new logarithmic bit requirement cannot be converted into an increasing useful-attention count by ignoring width, source positional encoding, post-read FFN computation or precision. A next theorem must fix or charge those resources, and must separately resolve the old ordinary-softmax range obstruction if it claims the full overall rare rate.
