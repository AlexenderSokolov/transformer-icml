from pathlib import Path
import html,re,hashlib
p=Path(__file__).parent

def inline(s):
 s=html.escape(s)
 return re.sub(r'https://[^\s<>]+',lambda m:'<a href="'+m[0]+'">'+m[0]+'</a>',s)
def md(s):
 out=[];para=[];code=[]
 def flush():
  if para:out.append('<p>'+inline(' '.join(para))+'</p>');para.clear()
  if code:out.append('<pre>'+html.escape('\n'.join(code))+'</pre>');code.clear()
 for line in s.splitlines():
  if line.startswith('    '):
   if para:flush()
   code.append(line[4:]);continue
  if code:flush()
  if not line.strip():flush();continue
  if line.startswith('#'):
   flush();n=min(5,len(line)-len(line.lstrip('#')));out.append(f'<h{n}>'+inline(line[n:].strip())+f'</h{n}>')
  else:para.append(line)
 flush();return '\n'.join(out)
body=md((p/'REPORT_MAIN.zh.v5.md').read_text())
files=[('A 固定宽度标量的完整反例','EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md'),('B 一次宽读出的条件统计预测','ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md'),('C 具有范围地板的总体风险','ONE_READ_CLIPPED_OVERALL_EXTENSION.candidate.v2.md'),('D 先行文献原文定位','PRIOR_REPORT_APPENDIX.zh.v1.md')]
for title,f in files:
 s=(p/f).read_text();s='\n'.join(x for x in s.splitlines() if not x.startswith('6 November 2026 UTC.'))
 body+='<section class="appendix"><h2>'+html.escape('附录 '+title)+'</h2>'+md(s)+'</section>'
style='body{max-width:980px;margin:48px auto;padding:0 24px;font:17px/1.8 system-ui,"Noto Sans CJK SC",sans-serif;color:#17202b;background:#fff}h1{font-size:32px;line-height:1.35;margin:36px 0 24px}h2{font-size:25px;margin:42px 0 18px}h3{font-size:20px;margin:28px 0 12px}p{margin:14px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:15px/1.7 ui-monospace,monospace;padding:16px;background:#f5f7f9}a{color:#145c9e;overflow-wrap:anywhere}.appendix{margin-top:64px}@media(max-width:600px){body{padding:0 16px;font-size:16px;margin:24px auto}h1{font-size:27px}pre{font-size:13px}}@media print{body{max-width:none;margin:0;font-size:11pt}.appendix{break-before:page}h1,h2,h3{break-after:avoid}}'
out='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>一次真实注意力调用能够保留多少稀有转移信息</title><style>'+style+'</style></head><body>'+body+'</body></html>'
f=p/'RESEARCH_REPORT.zh.v3.html';f.write_text(out)
print(f.name,len(out.encode()),hashlib.sha256(out.encode()).hexdigest())
