# One-read witness: scope, comparison and rejected shortcuts

6 November 2026 UTC. Analytical documentation only.

## Files and status

- `ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md`: one actual PreLN read, linear width and logarithmic paid depth, inherited terminal-A add-one statistical rate, and Omega(log(1/u)) conditional parameter information at N of order u^(-2). Independent review pending at this file's creation.
- `ONE_READ_CLIPPED_OVERALL_EXTENSION.candidate.v2.md`: the old full mixed estimator and output projection implemented after that single read. Actual overall risk is at most the inherited 1300u/sqrt(1+(N-2)u), plus w(alpha-q)_+ and a declared implementation tolerance. For epsilon_N=min{1/16,1/N}, full model/value width is O_alpha(N), depth O_alpha(log N), and approximation remainder at most 1/N. Independent review pending at this file's creation.
- Overall extension v1 is preserved. V2 avoids an unnecessary rectangular-head assumption by charging complete value width, and makes the small-N epsilon convention consistent.

## Narrow increment versus inherited work

The old wide source broadcast ALREADY placed the whole ordered history in the terminal bank after one read. The new observation used here is only that shifted channel conjunctions and a norm-one scaled sum can compute the rare-row counts locally inside that wide terminal bank. Hence a second useful read is unnecessary for these implementations. Small-amplitude PreLN, all-row bounds, denominator selectors, scratch clearing, restoration, log interpolation, statistical rates and entropy inequalities are inherited. None is being rebranded as a new theorem of general statistical optimality.

The resulting total resources are large: linear full width and value dimension, logarithmic paid depth and parameter precision, quadratic all-row state, and conservative cubic-times-logarithmic dense work. A streaming count estimator remains a cheaper baseline. This is a counterexample to an invocation-count conclusion that ignores these costs, not an across-the-board efficient architecture.

## Rejected or limited routes

1. **Pure overall rare rate under globally fixed ordinary-softmax range.** Impossible as u approaches zero, even with unlimited history computation. The C-row target next-zero probability tends to zero while a frozen bounded-logit head has a positive probability floor. We did not change the final interface or silently grow its bounds.
2. **Use the old all-row add-one network without changing C.** Invalid for the inherited u-scaled TV target. The extension explicitly computes the unsmoothed empirical C ratio with zero-count fallback before projection.
3. **Import the old two-read wide compiler and call it a new one-read theorem.** Insufficient. The local triple binding, bounded aggregation, ratio branches and actual terminal pair recovery are spelled out separately; the old first broadcast and PreLN machinery are identified as reused.
4. **One scalar of sufficient numerical precision proves the statistical claim.** No such shortcut is used. The only useful attention has a paid full value dimension proportional to the model width. Its statistical output acquires the lower-bound information because the internal continuous decoder computes real counts and estimates t.
5. **Constant information per useful invocation.** The conditional witness directly contradicts that claim for the declared growing-width class: at N of order u^(-2), the terminal statistic alone has at least (1/2)log(1/u)-O(1) nats of information about the local parameter prior.
6. **Parameter bits equal machine word length.** Not established. The records separately charge coefficient descriptions, clean representation separation and a sufficient additive execution-error radius. There is no rounded-LN, softmax, summation-order, accumulator or floating-point certificate.
7. **Conditional-A success implies overall success.** False. The conditional theorem isolates the information event used by the bit lower; the overall extension retains the actual old range floor and approximation error explicitly.
8. **Matching sharp physical logit span.** Not claimed by the overall extension. Alpha is the reference design clipping level, while the physical network approximates that reference. Exact realized span would require a margin or a separate range-preserving proof.
9. **Novelty or fixed-width frontier.** Not claimed. The next useful lower must charge width/value dimension, local continuation sensitivity, precision and distributed state, or impose an equal-resource subclass. This witness does not resolve the fixed-width repeated-attention question.

## Useful implementation-error specialization

For x=Nu>=1,

    (1/N)/(u/sqrt(1+Nu))=sqrt(1+x)/x<=sqrt(2).

Replacing N by n=N-2 changes only a universal factor for N>=6. Thus the 1/N implementation remainder is absorbable into the inherited rare statistical rate once Nu>=1. When Nu<1 it should remain explicit; neither a data-dependent choice of epsilon nor knowledge of u is used by the network. The separately retained output floor is unaffected.

## Evidence discipline

Only source reading, mathematical derivation, file writing and SHA-256 bookkeeping occurred. No scientific program was run. Candidate parameters were not emitted, no actual network was evaluated, and no user material was uploaded or published. The source bindings identify inspected historical proof artifacts rather than a new formal or machine-executed verification.
