# Independent final report audit, revision 3

6 November 2026 UTC.

## Verdict and binding

PASS within the analytical and static-review scope below. No blocking issue remains in the final report.

- Artifact: `RESEARCH_REPORT.zh.v3.html`.
- Bytes: 65,739.
- SHA-256: `25b85968a539f9b5593f9de3bad08b34f8b8a189a3405d0c99418299fd478919`.
- Main source: `REPORT_MAIN.zh.v5.md`, SHA-256 `ca7e34db4dbf2dd24d940f321067bab27421159e9155be7622d3a83cb10e43bd`.
- Static comparison and complete appendix bindings: `INDEPENDENT_REPORT_INTEGRITY.v3.json`.

## Mathematical dependencies and interpretation

The scalar branch relies on the separate exact-version analytical review `INDEPENDENT_SCALAR_PRELN_INJECTION_AUDIT.v3.md`, SHA-256 `0d74e21f0fb03ecb407070eaa19b3b1bd413c3240483af733698650be01b118a`, which binds scalar candidate v2. The final summary is consistent with that review: it presents exact-real injection and preservation of observation-law KL/TV, not an accurate next-token predictor or a finite-arithmetic realization. Its constant risk floor explicitly prevents an information-to-risk conflation. The N≥3 conditional-KL qualification and the N=2 zero-information exception are present.

The conditional wide branch is covered by `INDEPENDENT_ONE_READ_RARE_A_AUDIT.v1.md`. The overall extension is covered by `INDEPENDENT_CLIPPED_OVERALL_AUDIT.v1.md`, binding extension v2. Their final Chinese descriptions preserve the distinction between actual-terminal-A conditional risk and same-history overall risk. They do not supply an independent query, external pair port or free division decoder. The single useful attention count is not confused with logarithmic local sequential depth, linear width/value dimension, or large all-row dense work.

The information conclusion for the wide predictor is derived from its conditional estimation guarantee and an entropy-distortion inequality with the parameter-independent terminal-event probability. It is not inferred merely from scalar injectivity or a KL lower. The text leaves the charged architecture-to-communication bridge and equal-budget invocation frontier unresolved.

The overall extension correctly retains both the output-range floor and implementation error. Its design alpha is now explicitly dyadic, matching the finite coefficient-description premise. The full physical value dimension is charged as O_alpha(N+epsilon^(−1)), not only its O(N) active coordinates. The main specialization epsilon=1/(16N) is legal for every N≥6 and has the claimed linear-width/logarithmic-depth orders. The appendix uses the equivalent legal order epsilon_N=min(1/16,1/N).

Alpha-dependent constants are not asserted uniform in rarity. The interval is a reference-projection design, not an exact sharp physical-output-span guarantee. The text does not claim uniform vanishing overall rare risk as u tends to zero under the frozen bounded-logit envelope.

The scalar ledger now distinguishes O(N) persistent row-state slots from additional O(N²) workspace when dense score/weight arrays are materialized. Exact-real algebraic values are not relabeled as O(log N)-bit execution states. Wide coefficient descriptions and sufficient error-radius statements remain distinct from a machine-word or rounded-LN/softmax certificate.

## Literature and excluded branches

The adapted prior appendix acknowledges existing single-layer contextual mapping and scalar compression. Its architecture-specific distinctions are not promoted to first-discovery, priority or publication claims. Hahn's distance sensitivity and Merrill–Sabharwal's actual floating precision are not conflated with exact-real information loss. The scalar primary-source coverage is supplied by the separate prior audit; this final pass does not repeat the external search or independently certify every primary theorem.

The optional Gaussian observation-channel branch is absent from the report and is not used as an exact-model architectural premise. Brief execution-accuracy caveats in the wide construction remain qualifications of that exact-real construction, not a replacement of the mother problem by a noisy observation model.

## Source integrity, links and privacy

An independent HTML parser separated the main body and all four appendices. Their decoded content matches the bound Markdown sources after the documented removal of introductory dated candidate-status lines and normalization of Markdown formatting whitespace. Mathematical source text is preserved. These are adapted/rendered appendices, not raw-byte source embeddings; the integrity record explicitly distinguishes source hashes, sanitized Markdown hashes and rendered-text equality.

All four hrefs are complete and match cited URLs. No truncated-link pattern remains. Static checks found no script, iframe, object, embed, form, input, event-handler attribute or JavaScript URL; no private absolute execution path, internal retrieval identifier, stale pending/unreviewed status, private-key marker or secret-key pattern. Manual review found no internal coordination messages or personal sensitive information requiring removal. Relative research-source identifiers remain provenance citations.

Two final presentation corrections were verified: the dyadic alpha restriction and dense-workspace qualification. Earlier report versions are not the artifact accepted here.

No visual rendering was attempted or retried. No experiment, model execution, parameter generation, upload or public write was performed. This is neither formal verification nor external peer review, and acceptance applies only to the exact bytes bound above.
