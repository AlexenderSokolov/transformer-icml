# Independent clipped-overall one-read audit

6 November 2026 UTC.

Target: `ONE_READ_CLIPPED_OVERALL_EXTENSION.candidate.v2.md`, SHA-256 `d93eb8694364f9bf600537fc53811f50fe401753426cfb8035c93be296deaa54`.

Dependency: `ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md`, SHA-256 `94d478e8a8b7488af15d420c99853913ab3ef8aee9612ed68756895ccd4bab52`, checked in `INDEPENDENT_ONE_READ_RARE_A_AUDIT.v1.md`.

Verdict: the overall statistical-plus-range upper and one-useful-read construction are supported under the fixed-alpha, exact-real, growing-width contract. Revision 2 correctly charges full physical value width and handles the small-N tolerance convention. It does not establish a sharp physical output span, a rarity-uniform frozen-envelope rate or a fixed-width result.

## Counts, zero denominator and terminal selection

The one-read broadcast produces the ordered prefix bank at every row. Adding the C=10 triple gates to the A=00 gates changes all fanout, bias and complete-state bounds only by fixed factors. At most a fixed number of outputs use each source coordinate; the scaled sums give integer counts divided by Q. There is no dependence on unknown u or t in these operations.

The C table handles m=0 by an identically zero diagonal block. For m≥1, the public multiplier RQ/m is polynomial in N, so bounded-gain diagonal factorization has O(log N) depth. Exactly one count block is active on every reference row, and its final value C/J is at most one. No division by zero, discontinuity, or unbounded intermediate vector is concealed. A and C branches in parallel have bounded full norms. The A branch produces the next-zero add-one estimator, which is consistent with the complementary next-one convention of the conditional companion.

The four coordinates for positions N−1 and N are projected from the internally read bank and restored by paid log2 R doublings. Their norm is at most sqrt(2). Before position N the final symbol is absent, so all pair gates vanish; from position N onward they select the correct terminal pair. The final row-selector formula returns the chosen estimate when the pair is one-hot and returns 1/2 when no pair is available. Its gates and sums have constant dimension. All reference outputs, including nonterminal and ablated outputs, therefore belong to [0,1]. The pair is not a free externally supplied feature.

## Arbitrary implementation tolerance and actual output

Fixing alpha in (0,1/4] bounds the log interpolation domain away from zero. Scaled hinge fanout and adjacent-slope weights give width O_alpha(epsilon^(−1/2)) while keeping complete matrix, bias and state bounds independent of epsilon. The prepared logical depth remains O(log N); approximation precision is purchased in parallel width and coefficient descriptions, not through a logarithm oracle.

All output copies and scratch clears precede choosing eta. The original and read-ablated programs have a common bounded reference tube. The same physical PreLN error calculation applies, with eta chosen so the amplified error is a sufficiently small fraction of epsilon. The required restoration length is O_alpha(log N+log(1/epsilon)). Adding inert zero coordinates until d is a sufficiently large multiple of N+epsilon^(−1) makes both radial restoration and mandatory final-LN errors O(epsilon). The resulting ordinary affine vocabulary head and softmax incur the stated uniform TV implementation error. No uncharged terminal decoder or singular normalization appears.

A full-width signed identity or padded FFN may use O(d) intermediate width; the smaller pre-padding logical FFN bank is not a claim that full restoration is free. The physical width ledger explicitly permits this padding. Gain-two normalization uses the inherited operator-norm convention; it is not a constant Euclidean bound on the full gain parameter vector.

Alpha is the reference projection level. Approximation does not force every physical output into exactly [alpha,1−alpha], so the candidate correctly refuses to assert the sharp exact physical contrast log((1−alpha)/alpha). The fixed-alpha physical norm envelope does imply some fixed contrast bound, and thus preserves the qualitative rare-boundary obstruction. The alpha/3 limit refers to the reference range term, not a proved exact physical boundary constant.

## Statistical composition and usefulness

At the actual terminal row, the logical predictor is the archived mixed estimator: A add-one, C unsmoothed empirical ratio with zero fallback, and B,D fair. The old same-history overall theorem therefore applies. Since alpha≤1/4, projection cannot increase error on A, B or D; on C its extra pointwise error is at most (alpha−q)+. Stationarity weights this by w. Adding the uniform implementation error gives the displayed bound without treating the terminal query as independent.

The all-zero word has terminal A and next-zero add-one estimate (N−1)/N≥5/6. Projection keeps at least 3/4, while deleting the read removes the internally recovered pair and produces the uniform reference. For epsilon≤1/16, physical separation is at least 1/8. Thus the single invocation is genuinely useful. This witness differs appropriately from the conditional companion's clipped-next-one usefulness witness.

The result includes an implementation remainder and a range floor. Choosing a known rarity floor and an alpha below all legal q removes the latter only while paying alpha-dependent resources. No full overall rare rate uniformly as u tends to zero is asserted with a fixed alpha envelope.

## Resource corrections and scope

Revision 2 charges d_value=O_alpha(N+epsilon^(−1)), even though only O(N) coordinates are nonzero. It therefore does not rely on permission for rectangular narrow value projections when model-width accuracy padding exceeds N. The dense attention cost O(N²W) matches this convention.

The specialization epsilon_N=min(1/16,1/N) is legal for every N≥6 and gives width O_alpha(N), depth O_alpha(log N) and remainder O(1/N). The previous epsilon=1/N wording failed the stated tolerance range for 6≤N<16; the correction preserves all asymptotic claims.

The dense coefficients, all-row memory, work and parameter-description bounds are consistent with W and D. Polynomially small additive execution errors can be controlled by full-program Lipschitz propagation, but this remains an error-radius statement, not finite-word attention/LN/softmax or accumulator certification.

This audit verifies a composition using inherited statistics and compiler mechanisms, not a new rate, optimality frontier, trained model, executable parameter set or priority claim. No numerical experiment, model execution, upload or rendering was performed.
