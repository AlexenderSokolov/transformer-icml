# One raw PreLN scalar can retain the entire rare-source experiment

6 November 2026 UTC. Analytical candidate v1. Independent review pending. No scientific executable, numerical diagnostic, source simulation, training, upload, or public write was performed. This is an exact-real information obstruction, not an accurate statistical predictor and not a resource lower bound.

## 1. Main result

Fix N>=3 and P=2^ceil(log2(N+1)). There is a genuine raw-symbol, full-prefix causal PreLN network with:

- physical width eight;
- one useful head invocation, identically zero scores, and a scalar head value;
- a bounded initial affine embedding, one complete ordinary PreLN block with zero FFN, a final full-feature LayerNorm, bounded affine logits and ordinary binary softmax;
- every LayerNorm having epsilon=1, scalar gain two and shift zero;
- fixed, N-independent full-state, full-matrix, full-bias, value and primitive-Lipschitz bounds;
- O(log N) binary description length per coefficient, with only the dyadic coefficient 1/P depending on N;

whose final normalized probability vector is an injective function of the ENTIRE binary word X_1:N.

Consequently the exact law of that single scalar read, its complete terminal state, and its final probability output all retain the full finite-history KL divergence between any two positive source laws. The counterexample has constant continuation Lipschitz constant, not merely unbounded decoding gain. This refutes a universal O((1+Nu^2)(t-s)^2) KL bound for exact one-read outputs under fixed width, fixed depth, bounded scores, bounded primitive gains and short coefficient descriptions alone.

There is no contradiction with known statistical risk lower bounds: exact mutual information/KL permits arbitrarily fine tests of an observed real number. The network's bounded-Lipschitz output is not asserted to estimate the rare parameter. Finite activation precision, additive noise, or a restriction on the downstream estimator changes the observation experiment.

## 2. Exact raw implementation, retaining every register

Use binary raw symbol onehots. Put sigma_i=+1 for symbol 1 and -1 for symbol 0; the synthetic row T=N+1 has sigma_T=0. The only positional input is the public p_i=i/P. A counted affine embedding produces

    h_i=(sigma_i,-sigma_i,r_i,-r_i,0,0,0,0),
    r_i=p_i/P=i/P^2.

This embedding uses no adjacent-symbol feature, historical encoder, pair port, or precomputed statistical feature. Its full operator norm is at most two. All eight coordinates enter every LayerNorm. They have zero mean.

The cited standard-PreLN raw contract uses p_i=i/P. If instead the public coordinate is i/(N+1), the equally bounded dyadic embedding coefficient (N+1)/P^2 gives the same r_i and still has O(log N) description length. This is an initial counted affine embedding, not an assumption that a PreLN residual FFN performs an exact unnormalized rescaling.

For a real row i<=N, with LN denoting epsilon-one/gain-two LayerNorm,

    ||h_i||^2=2+2r_i^2,
    LN(h_i)_1=4 sigma_i/sqrt(5+r_i^2).

Take W_Q=W_K=0 and W_V=(1/4)e_1^T. Thus the real-row scalar value is

    v_i=sigma_i/sqrt(5+r_i^2)
       =P^2 sigma_i/sqrt(5P^4+i^2).

The synthetic value is exactly zero: its first coordinate is zero, whatever its different normalization denominator. Self is included in every full-prefix average. At physical row t the one head returns

    A_t=(1/t)sum_(i<=min(t,N)) v_i.

Let W_O write A_t and -A_t into the previously zero fifth and sixth coordinates. The attention residual is therefore exactly

    u_t=(sigma_t,-sigma_t,r_t,-r_t,A_t,-A_t,0,0).

The FFN branch is identically zero, but its full-feature positive-epsilon input LayerNorm remains present in the complete block. There is no residual deletion, normalization shortcut, or ignored stale register. In particular, the nonterminal rows retain their own raw-symbol and position pairs and their updated prefix averages. No later operation reads those rows; all remaining operations are positionwise and output is terminal-only.

All |v_i|<=1/sqrt(5), so |A_t|<=1/sqrt(5). Since r_t<=1/P and P>=4, every reached u_t has squared norm at most 2+2/P^2+2/5<3. W_O has norm sqrt(2); all other matrices and biases are bounded by fixed constants. The final full-feature LN and affine head also have fixed full-norm bounds. No coordinatewise bound is substituted for a full-vector bound.

At T the residual is public except for A=A_T. The final LN's fifth coordinate is

    f_N(A)=2A/sqrt(1+(r_T^2+A^2)/4).

Choose ordinary vocabulary logits (f_N(A),0), followed by binary softmax. Thus

    q_1(A)=1/(1+exp(-f_N(A))), q_0(A)=1-q_1(A).

Both coordinates are strictly positive and sum to one exactly on every word. This uses the actual final full-feature normalization, including both copies of A and the retained position pair. Since

    f_N'(A)=2(1+r_T^2/4)/(1+(r_T^2+A^2)/4)^(3/2)>0,

the final probability is strictly increasing in A. Also f_N'<=2 globally, so the continuation A->q is globally 1/2-Lipschitz in binary TV. The primitive LN maps are globally two-Lipschitz. The useful attention count, complete sequential depth and every continuation gain remain constant.

Ablating W_O makes the terminal output exactly (1/2,1/2), whereas an all-symbol-1 input gives A>0 and q_1>1/2. The single invocation is genuinely useful to this map, though the map is not a good estimator of t.

The failure as a predictor is quantitative. Since |A|<=1/sqrt(5), its logit contrast has magnitude |f_N(A)|<1. Both predicted probabilities exceed 1/(1+e)>1/4. On the rare family's terminal C=10, the true next-zero probability is q_t<=1/44. Consequently its SAME-history averaged prediction risk is at least

    w(1/4-q_t)=(1-u)/12-ut>=3/40.                    (0)

Thus this ordinary-softmax probability output simultaneously retains the complete exact-history experiment and has prediction risk bounded away from zero throughout the rare family. Exact information preservation is not an accurate task decoder.

## 3. A finite-coefficient algebraic injectivity proof

Set n_i=5P^4+i^2 for i=1,...,N. These are distinct positive integers. Write each uniquely as

    n_i=d_i a_i^2,

where d_i is a positive squarefree integer and a_i is a positive integer. The d_i are pairwise distinct. Indeed, if n_i=d a^2<n_j=d b^2 had the same squarefree part, then b>=a+1 and

    n_j-n_i=d(b^2-a^2)>=d(2a+1)
             >2 sqrt(d n_i)>=2 sqrt(5) P^2.

But n_j-n_i=j^2-i^2<N^2<P^2, a contradiction.

The square roots of distinct positive squarefree integers are linearly independent over Q. One proof takes the multiquadratic field generated by the finitely many primes occurring in those integers. Independent sign changes of the prime square roots are its automorphisms; the distinct squarefree radicals carry distinct characters of this sign group. Averaging a putative relation against each character isolates its coefficient. The squarefree integer 1, if present, corresponds to the trivial character. Equivalently these radical monomials form the usual rational basis of that multiquadratic field.

Since 1/sqrt(n_i)=sqrt(d_i)/(a_i d_i), the numbers 1/sqrt(n_i) are also Q-linearly independent. Therefore two distinct words sigma,tau in {-1,+1}^N satisfy

    sum_i (sigma_i-tau_i)/sqrt(n_i) != 0.

The actual terminal scalar is

    A(sigma)=P^2/(N+1) sum_i sigma_i/sqrt(n_i),

so it is injective. The final q_1 is strictly monotone in A and hence injective too. No generic transcendental coefficient, learned position table, exponentially many initial features, unbounded score, or unpaid positional precomputation is used. The irrational radicals arise from the mandatory ordinary epsilon-one LayerNorm applied to raw symbol and public position coordinates.

The multiquadratic fact is an algebraic lemma, not an assertion that a bounded-depth network implements the inverse map. No inverse is needed to identify the exact probability law of an injective statistic.

## 4. Full rare-source information survives, including the actual terminal

Use the same stationary rare family as RARE_PARITY_INFORMATION and RARE_TERMINAL_PARITY_INFORMATION v2:

    pi=(u,w,w,w), w=(1-u)/3, q_t=ut/w,
    P_t=[[1-t,t,0,0],[0,0,1/2,1/2],
         [q_t,1-q_t,0,0],[0,0,1/2,1/2]],
    0<u<=1/100, 1/2<=t<=3/4.

States are A=00,B=01,C=10,D=11. The stationary initial-pair law pi is the same for the compared t,s at fixed u. Every finite binary word has positive probability. The exact path KL is

    KL(P_t^X || P_s^X)
      =(N-2)[u kl(t,s)+w kl(q_t,q_s)].                 (1)

Here kl is Bernoulli KL; the coordinate orientation of the C row is immaterial. In this rectangle, Pinsker and the elementary chi-square upper bound give

    2(N-2)u(t-s)^2 <= KL(P_t^X || P_s^X)
                     <= 8(N-2)u(t-s)^2.              (2)

For the upper, kl(t,s)<=16(t-s)^2/3. Also q_s<=1/44 and q_s>=u/(2w), so w kl(q_t,q_s)<(88/43)u(t-s)^2. Their sum is below eight.

Any injective deterministic map on this finite common sample space preserves KL exactly. Thus (1)-(2) also hold with X replaced by A_T, the full terminal state, or the final ordinary-softmax probability vector. The hidden all-row updates and final FFN/residual pathway have not been discarded.

More generally, for ANY parameter prior and any pre-existing side information B, injectivity gives the exact equality

    I(Theta;Q_N | B,E)=I(Theta;X_1:N | B,E)

whenever the conditioning event E has positive probability. This equality, rather than a claimed mutual-information rate inferred solely from pairwise KL, is the corresponding MI statement.

### 4.1 Terminal A conditioning is not a free stationarity assumption

Let E={X_(N-1)=X_N=0}. Its probability is exactly u for every parameter. As proved directly in the terminal-parity note, reversing a stationary path conditional on E produces the same symbol source P_t initialized at pair A. It is an identity of conditional finite-history laws. Thus the conditional path KL is the sum of transition KLs along a P_t chain started at A, not equation (1) blindly divided by u.

For every state x,

    P_t^2(x,D)>=1/4,  P_t^2(D,A)=q_t/2.

Therefore

    P_t^4(x,A)>=q_t/8>=3u/16.                        (3)

For N>=3 the first reversed transition starts at A and contributes kl(t,s)>=2(t-s)^2. For each reversed transition whose pre-transition pair has taken at least four steps, (3) gives another contribution at least (3u/8)(t-s)^2. There are (N-6)_+ such transitions. Consequently

    KL(P_t^(X|E) || P_s^(X|E))
      >=[2+(3/8)(N-6)_+ u](t-s)^2.                  (4)

For a matching order upper, the common atom P_t^2(x,D)>=1/4 implies

    TV(P_t^j(A,.),pi)<=(3/4)^floor(j/2).

The expected number of A visits before the N-2 transitions is at most (N-2)u+8. Bound A-row KL by 16(t-s)^2/3 and every C-row KL by 7u(t-s)^2, using w>=33/100 and 88/(43w)<7. The other rows contribute zero. A loose consequence is

    KL(P_t^(X|E) || P_s^(X|E))
       <=60(1+Nu)(t-s)^2.                            (5)

The scalar and final output remain injective on the restricted set of histories ending in A, so they preserve this conditional KL exactly as well. Thus the O(1) terminal transient does not rescue an O((1+Nu^2)(t-s)^2) exact-output bound. For example, N of order u^(-2) makes (4) grow as (t-s)^2/u, while the proposed parity-scale upper would remain O((t-s)^2).

These are observation-channel information claims. They neither turn the displayed network into a good next-token predictor nor provide an efficient inverse/estimator from its code.

## 5. Precision ledger: short coefficients are not short activations

Only the coefficient 1/P varies with N. It is dyadic with O(log N) ordinary binary description length. All other embedding/head/LN coefficients are fixed rationals. Nevertheless the intermediate values and final probabilities are evaluated with exact-real square-root, division and exponential semantics. Coefficient descriptions do not imply an O(log N)-bit state register.

Constant width and depth do not mean constant total distributed memory or work: there are N+1 physical rows and O(N) real activation registers. The one full-prefix head has O(N^2) dense work if evaluated by the usual all-row dense causal attention implementation. All of those rows and updates belong to the construction; no cached history-free replacement is assumed.

There are 2^N distinct A values in [-1/sqrt(5),1/sqrt(5)]. If delta_N is their minimum separation, then

    delta_N <= (2/sqrt(5))/(2^N-1).                   (6)

To robustly reconstruct every word from an adversarial absolute-error observation A+e with |e|<=eta, one needs 2eta<delta_N (at equality, two permitted observation intervals can meet). Any finite-alphabet observation that is injective on every word must have at least 2^N symbols, hence at least N bits. These are all-history injectivity statements; they are not lower bounds on precision needed merely to estimate t under the rare source.

For completeness an extremely loose algebraic separation bound is available. Put n_max=5P^4+N^2 and B=2N n_max^((N-1)/2). For a nonzero difference vector e_i in {0,+2,-2},

    beta=sum_i e_i product_(j!=i) sqrt(n_j)

is a nonzero algebraic integer in a field of degree at most 2^N. Every conjugate has absolute value at most B. Its nonzero integer norm has absolute value at least one, so

    |beta|>=B^(-(2^N-1)).

It follows that

    delta_N >= [P^2/(N+1)]
                 B^(-(2^N-1)) n_max^(-N/2).           (7)

This only supplies a very inefficient sufficient precision of O(N 2^N log N) fractional bits for preserving all distinct scalar codes under sufficiently accurate evaluation. It is not a claim about finite-arithmetic implementation, a tight separation rate, or efficient parameter generation.

### 5.1 The informative fine distinctions are uniformly tiny

Let C=sum_i sigma_i and define the simple token-count code

    A_0=C/[(N+1)sqrt(5)].

The mean-value theorem for z->(5+z)^(-1/2) yields, on EVERY word,

    |A-A_0|
      <= [1/(2*5^(3/2))] N^2/P^4
      <= [1/(2*5^(3/2))] N^(-2).                    (8)

The final actual softmax output is consequently within

    1/[4*5^(3/2) N^2]

in TV of q(A_0). The latter is computed by applying the same mathematical continuation to the count code. This is an approximation/comparison statement, not an additional uncounted neural operation.

At N of order u^(-2), this discrepancy is O(u^4), much smaller than the full-history rare-risk scale u^(3/2). Exact KL nevertheless retains all the Nu information. This sharply demonstrates why closeness of two scalar values, bounded continuation sensitivity, or equality of means cannot be converted into an exact-information statement without an explicit observation model.

### 5.2 An explicit regularized statement for this example

If the data-carrying scalar is REPLACED by Y=A+sigma Z, Z standard normal independent of the source, and every subsequently visible copy is computed from Y rather than a retained clean A, then for any parameter prior and any pre-existing source-data side information or conditioning event independent of the added Z (including the actual terminal pair),

    I(X;Y | C,side information)
       <= E[(A-A_0(C))^2]/(2 sigma^2)
       <= 1/[1000 N^4 sigma^2].                     (9)

Proof: conditional on X, Y is Gaussian with mean A; compare each such law to N(A_0(C),sigma^2). The expected reference KL upper-bounds conditional mutual information. Conditioning only changes the history weights, not the pointwise bound (8). The same bound holds for parameter information by data processing. All terminal residuals were public before this read, so the entire noisy terminal continuation is a function of Y and public metadata. Giving even one clean copy of A would invalidate this noise-channel conclusion. Gaussian replacement is an ADDITIONAL observation assumption, absent from the exact original contract.

## 6. Consequences and the correct stopping boundary

1. A fixed-dimensional additive statistic can have full rare-transition information. Equality of its one-symbol means, or a variance calculation, does not constrain its exact law enough.
2. Raw positive-epsilon PreLN itself supplies the position-dependent algebraic weights. One need not appeal to an expensive full-history positional encoder to refute a width-only exact-information claim.
3. Fixed paid continuation sensitivity does not bound unregularized KL: the final bounded-Lipschitz ordinary-softmax output here is injective. A lower bound on estimation by bounded-sensitivity decoders must retain that decoder restriction throughout its statistical comparison.
4. This does NOT contradict the old one-invocation gain/depth/risk theorem, the parity-channel theorem, or the total-bit lower. Those statements concern different observation/computation restrictions and do not grant arbitrary exact inversion for free.
5. The next meaningful bridge must state which representation is physically observable, its noise/precision model, and whether every residual or duplicate clean channel is covered. The companion Gaussian theorem supplies one limited, explicit noisy-view upper, not an exact-model resource separation.

## 7. Read dependencies

- rare_statistical_resource_reset_20261106/RARE_PARITY_INFORMATION.candidate.v1.md.
- rare_statistical_resource_reset_20261106/RARE_TERMINAL_PARITY_INFORMATION.candidate.v2.md.
- rare_statistical_resource_reset_20261106/RARE_INTERACTIVE_BITS.candidate.v1.md and ATTENTION_BRIDGE_STOPPING_GATE.v1.md.
- source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md.
- standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md, for the actual full-feature epsilon-one/gain-two convention.
- one_invocation_rate_lower_20261104/BOUNDED_SCORE_RATE_EXTENSION.candidate.v1.md and stationary_one_invocation_20261105/STATIONARY_ONE_INVOCATION_LOWER.candidate.v2.md, for the public-query/additive-sketch interface and paid-continuation distinction.

The explicit algebraic encoding and its conditional rare-source information accounting are proved above rather than imported from a full-history compiler. No literature priority claim is made.
