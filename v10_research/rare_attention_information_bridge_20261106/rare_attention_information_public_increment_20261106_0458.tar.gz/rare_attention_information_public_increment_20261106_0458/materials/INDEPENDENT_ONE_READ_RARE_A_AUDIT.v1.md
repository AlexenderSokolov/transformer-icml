# Independent one-read rare-A statistical witness audit

6 November 2026 UTC.

## Exact target and verdict

Target: `ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md`, SHA-256 `94d478e8a8b7488af15d420c99853913ab3ef8aee9612ed68756895ccd4bab52`.

Verdict: the analytical construction is supported under the stated existential fixed-envelope, growing-width, exact-real PreLN contract. No blocking proof gap was identified. It provides one useful wide read for actual-terminal-A conditional prediction, not uniform rare-family averaged prediction or a fixed-width result. No implementation, numerical execution or novelty is certified.

Checked inherited sources:

- `parallel_width_depth_20261104/CANDIDATE.v2.md`, SHA-256 `d69f471e0bf6c6f585b0772bdbdea688113cdaeefdd2028bd8b1c6b8b65eaf71`, scaled selectors, wide broadcast and denominator mechanisms.
- `nonlinear_statistical_frontier_20261106/WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md`, SHA-256 `28d7230b9b6b131daa05f6d5a58b3a26d562ca54845e09db13ff9785f5d39e0e`, Sections 3–5, complete logit preparation, paired PreLN error control and final normalization.
- `u_blind_full_averaged_20261103_2147/full_averaged_tv_bound_v1.html`, SHA-256 `459d6d842bc9d9d4c3df89a41891818bd967ab50cf9da1a84055dc76f587e049`, Section 8 equation (8.5), the inherited constant-157 actual-terminal conditional bound.

These are relative research provenance identifiers. The statistical result remains inherited; this audit checks its matching estimator, initialization and use here rather than claiming a newly proved rate.

## 1. Raw input and one actual read

The scaled positional selector uses distinct grid points separated by at least 1/P. Its H clipped doublings distinguish them exactly in the logical circuit. Scaled token fanout and all selector/gate biases have bounded full norms, not merely bounded coordinates. The terminal zero-symbol row contributes no pulse.

A zero-query/zero-key self-inclusive causal head really gives the stated prefix average, including division by the current row index. H further clipped doublings saturate every positive pulse to s because the index is at most P. No row-dependent inverse denominator is supplied. This works at all original rows as well as at the synthetic terminal; inaccessible future positions remain zero. The broadcast norm is at most s sqrt(N), and the useful value dimension is explicitly 2N before pairing.

## 2. Local triples and full norms

The three-input ReLU gate produces s exactly on an available 00c triple. If a position is absent, at most two inputs equal s and the output is zero. There is no false boundary or future transition.

The triple map has bounded row and column incidence: each output has three inputs, and each input coordinate enters at most a fixed number of gates. For example the zero rail appears in at most five such gates, giving a dimension-independent operator bound via row/column sums. The complete threshold bias has norm at most 2sqrt(2). At most one output symbol rail is active for each end position, so the complete triple bank remains bounded.

The two count-aggregation rows have disjoint support and each norm at most s sqrt(N−2)≤1. Their extra s factor is essential: counts are represented as C/Q, not as unbounded integers or an uncharged norm-sqrt(N) sum. At every row both counts are integers on the same 1/Q lattice, with total at most N−2.

## 3. Ratio table and nonterminal states

The denominator selector takes log2 Q bounded-gain stages and distinguishes every lattice count. At all rows exactly one block survives. Inactive blocks in (5) vanish because f_c+1/Q≤(N−1)/Q<1. The active block equals (C_c+1)/(RQ).

The public amplification RQ/(m+2) is at least one and at most polynomial in N. Factoring it into gains in [1,2] uses O(log N) bounded diagonal stages. The active coordinates grow monotonically to values at most one; all other blocks remain zero. A balanced sum tree with bounded stage norm produces the exact add-one vector at every row. Consequently the reused denominator module does not rely on an unproved off-grid or nonterminal simplex assumption. Its table width, rational coefficients and sequential gains are paid.

Ablating the only read gives zero counts at every row and the uniform reference output. Both the intact and ablated programs stay inside the same bounded reference domain.

## 4. Positive-epsilon PreLN and ordinary output

Clipping the next-one estimate to [1/2,3/4] contracts error for the allowed t interval. Its complement lies in [1/4,1/2], so the fixed-floor logarithm module has absolute constants independent of rarity u. Scaled parallel hinges control both full fanout and output-row norms. Choosing a larger fixed interpolation constant supports the stated accuracy allocation without changing asymptotics.

The complete logical program, including logs, output copies and all scratch/anchor clears, is fixed before eta is selected. Its primitive max-row Lipschitz envelope is dimension independent; its overall continuation sensitivity may be polynomial in N, and the resource ledger explicitly admits that distinction. Each overwrite is homogenized with the anchor and represented by a bounded residual FFN. Constant scratch banks can be reused; no O(log N) accumulation of uncleared full-norm banks is required.

Pairing produces exact zero coordinate mean on clean executions. The true full-feature LN radial factor is retained, including the source-row factor inside the wide uniform attention. Its full-vector local error is O(eta²/d), independent of value dimension under the verified operator/state bounds. The common bounded-tube argument applies to both intact and ablated programs; physical counts need not stay on the ideal lattice. Selecting eta after complete preparation gives O(log N) amplitude exponent and uniform intermediate error, including the stronger s/16 requirement.

The paid restoration uses the inherited geometric, rather than depth-times, O(1/d) error sum. Final gain-two LN, the bounded half-projection vocabulary head and ordinary softmax are all explicit. Approximate scratch-clearing error is retained through restoration. There is no free external division/log decoder, singular normalization, unbounded single-step amplification or nonzero sqrt(d) padding. A sufficiently large fixed multiple in d=Theta(N) supplies the claimed accuracy and ablation margins. This is an existential sufficiently-large envelope, not containment in every preassigned numerical budget. The gain convention is operator norm of 2I, not a constant Euclidean norm for the entire gain parameter vector.

## 5. Conditional statistical risk and ablation usefulness

The computed terminal estimator is exactly the inherited A-row add-one statistic over N−2 transitions. Stationary actual-terminal-A conditioning matches the archived theorem. Neither independent row samples nor an independent terminal query are substituted. Projection and uniform implementation error prove the displayed conditional bound. The construction does not need to observe or test terminal A; the event defines evaluation, not a free input.

The 001001... witness has at least two observed 00-to-1 transitions for N≥6 and no 00-to-0 transition, so its clipped reference next-one probability is 3/4. Its ablation is 1/2. With both implementations within 1/32 under identical parameters, the separation is at least 3/16. The witness need not itself end in A to establish pathwise usefulness, and it has positive probability under the legal stationary source. An all-zero witness would not suffice after this clipping, but the candidate does not use one.

The C-row output floor prevents the full uniform rare averaged rate. No claim here removes that obstruction, establishes one-read necessity, or compares equal total resources with a repeated-read construction.

## 6. Information and precision claims

At N of order u^(−2), the conditional risk bound gives D_u=O(sqrt(u)). The chosen local prior width remains between positive constants as u tends to zero, and its distribution is unchanged by conditioning on A because Pr(A)=u is parameter independent. The entropy-distortion lower therefore yields the stated one-half log(1/u) information in the statistical output. Equation (9) is the exact mutual-information chain rule followed by I(Theta;output,V|A)≥I(Theta;output|A) and the independently proved baseline bound I(Theta;V|A)≤1/100. It does not assume marginal independence.

The intermediate injectivity statement follows from the full-vector s/16 logical error: every individual history-bank coordinate lies on the correct side of s/2 after division by the known eta. This threshold is only an information argument, not an inserted network operation. The actual predictor uses the continuous paid circuit.

For arbitrary additive sublayer errors, pairing may be broken, but the full-feature epsilon-one LN remains dimension-independent Lipschitz; zero Q/K retain uniform attention. Fixed complete matrix norms and residual structure give a fixed max-row Lipschitz constant per sublayer. Polynomially small error radius thus controls the O(log N)-depth continuation, including restoration and output. A sufficiently large fixed exponent also preserves the polynomially small history-bank separation. This robust-radius statement is not a finite-word execution theorem. The text properly separates it from coefficient descriptions, internal arithmetic and accumulator precision.

The all-dyadic option is an approximation claim: full operator perturbation costs the matrix dimension, and polynomial continuation sensitivity requires choosing a sufficiently large exponent. It does not preserve exact rational ratio evaluation or certify rounded LN/softmax execution.

## Limits

The witness purchases linear width/value dimension, logarithmic paid local depth, and large dense all-row state/work costs. Its conditional information content does not contradict a finite-bit lower; it invalidates only an inference that growing statistical information alone forces more useful reads while those other resources are ignored. No fixed-width frontier, overall rare-risk upper, numerical model, training claim or priority conclusion follows. No simulation, enumeration, upload or rendering was performed for this audit.
