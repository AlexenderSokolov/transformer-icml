# Attention information bridge result registry

2026-11-06. No public write, training or scientific execution.

## Main results and dependencies

1. EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md: explicit width-eight, zero-score, one-scalar-read positive-epsilon PreLN map injective on all raw binary histories; normalized final probability preserves full KL/MI while overall rare prediction risk remains at least3/40. Independent algebra, all-row norms and actual-terminal path law audited. Finite coefficient description does not provide finite execution precision.
2. ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md: old wide broadcast plus paid terminal-local triples/ratios/logits needs one useful read, widthO(N),depthO(logN), old terminal-A risk157/sqrt(1+(N−2)u)+O(N^-1/2). Independently accepted. Depends on already audited broadcast, standard PreLN compiler and rare estimator; no new statistical rate.
3. ONE_READ_CLIPPED_OVERALL_EXTENSION.candidate.v2.md: old mixed estimator, internal terminal selection and projection give overall risk1300u/sqrt(1+(N−2)u)+w(alpha−q)+ +epsilon. Fixedalpha complete norm envelope; arbitrary tolerance complete value/head width fully charged. At epsilon=min(1/16,1/N), widthO_alpha(N),depthO_alpha(logN),remainder≤1/N. Independently accepted.

## Scope and failure records

PROBLEM_CARD_AND_FAILED_TARGETS.v1.md and ONE_READ_SCOPE_AND_FAILURES.v1.md preserve rejected inferences. Scalar exact-information bounds cannot be deduced from small dimension or bounded output Lipschitz constants. The wide construction cannot settle fixed-width invocation complexity. Neither eliminates the ordinary-output range floor.

The scalar initial generic-transcendental idea was superseded by an explicit dyadic-position construction, not used as a final dependency. Main scalarv1 contained an optional Gaussian-observation aside;v2 removes it. The separate noise candidate remains archived as an unadopted model extension and is excluded from the report. It does not change the frozen exact-real task.

Overall extensionv1 omitted full-head-width costs for arbitrary epsilon and allowed epsilon=1/N outside its epsilon≤1/16 statement at smallN. Version2 corrects both. All versions retained.

## Prior art

SCALAR_INJECTION_PRIOR_AUDIT.v1.md: Kajitsuka–SatoICLR2024 Theorem2 and scalarcontext discussion are direct general antecedents. The positive-epsilon, zero-score, short-rational-coefficient implementation is a specific model obstruction, not certified novel general expressivity. Hahn small-distance bounds and Merrill actual-state finiteprecision results remain compatible. ONE_READ_SOURCE_BINDINGS.v1.json records inherited compiler/statistical sources.

## Delivery

RESEARCH_REPORT.zh.v3.html contains a Chinese synthesis and four sanitized/adapted appendices. It is not a byte-identical copy of source candidates. No Gaussian/noise extension is part of the report. Static HTML and privacy QA only; no rendering retry. Formal verification and external expert review have not occurred.

Reportv1 omitted the declared dyadic-alpha qualifier in the Chinese synthesis. Version2 restores it. Version3 explicitly adds materialized dense attention workspace to the scalar resource ledger. Source candidates and all earlier reports remain unchanged.
