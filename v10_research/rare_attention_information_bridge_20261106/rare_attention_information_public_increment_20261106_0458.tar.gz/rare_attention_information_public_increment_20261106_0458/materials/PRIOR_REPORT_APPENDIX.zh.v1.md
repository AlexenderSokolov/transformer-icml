# 原文定位与覆盖范围

Kajitsuka–Sato，ICLR 2024：Theorem 2 与 §3.4（第 6 页）已有单层低秩 contextual mapping 及标量上下文压缩。§2.2 式 (2)（第 3 页）省略 LN；附录 A.2 式 (29)–(30)（第 16 页）使用 Q/K 缩放；其输出分离可以很小。位置和 mask 扩展亦已有覆盖。因此本轮只能声称指定正 ε PreLN 契约中的具体反例，不能声称首次发现单层编码全部上下文。

https://arxiv.org/html/2307.14023v3

https://proceedings.iclr.cc/paper_files/paper/2024/file/96ee35c170cb8720033b16259c305da9-Paper-Conference.pdf

Hahn，2020：Lemma 5 的 O(1/N) 单符号影响控制的是输出距离，不要求相同输出。其补充修订 §S2 也需计入改变注意力权重的项。这里的极细单射与该小影响现象相容。

https://aclanthology.org/2020.tacl-1.11.pdf

Merrill–Sabharwal：§2.1 定义的是实际 p 位浮点执行。Proposition 1 的均匀注意力下溢门槛是 log₂log₂N 总浮点位，不能改写成 logN。短参数描述与准确保存代数实数的状态精度并非同一资源。

https://arxiv.org/html/2210.02671v7

以上是针对命题与模型的定位，不是穷尽式新颖性认证。平方自由编码是否存在更直接的文献先例仍未获得优先权审定；本报告不依赖其新颖性来成立。
