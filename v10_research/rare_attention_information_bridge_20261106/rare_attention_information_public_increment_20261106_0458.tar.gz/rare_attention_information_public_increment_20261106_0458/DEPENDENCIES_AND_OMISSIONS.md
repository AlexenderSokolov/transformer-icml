# Dependencies and omissions

All 33 available files are included unchanged, including the superseded scalar v1, unadopted noise extension, clipped-extension v1/v2, independent audit v1-v3, report main v1-v5 and HTML v1-v3. No historical failure or qualifier was removed, and no missing result was fabricated.

External dependencies remain OPEN: earlier wide broadcast and paid terminal-local triples/counts/ratios/logits, rare terminal-A estimator and mixed-estimator statistics, full-state positive-epsilon PreLN/softmax compiler, precision/norm/ablation machinery, declared rare source family, and primary scalar-context/finite-precision literature. ONE_READ_SOURCE_BINDINGS.v1.json retains inherited-source identities but does not bundle or reprove those modules.

No third-party paper full texts, absent numerical/floating-point certificates, model/training outputs, screenshots/visual acceptance or missing prior v10 records are included. Exact real encoding does not prove resource-bounded usable prediction. Adapted report appendices are not raw source embeddings, and the archived noise extension does not change the adopted model.
