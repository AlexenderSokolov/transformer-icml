# Rare attention information bridge: public increment

All 33 available source files are preserved byte-for-byte: candidates and revisions, failed targets, scope/resource ledgers, prior-art audits, independent reviews, registry versions, report main v1-v5, HTML v1-v3 and scripts. No originals were overwritten and no GitHub action occurred. Open materials/RESEARCH_REPORT.zh.v3.html for the final report. Its four appendices are documented Markdown adaptations, not byte-identical source embeddings; original and adapted hashes remain in the integrity record.

## Information retention is not a useful predictor

The explicit fixed-width, zero-score, one-scalar-read positive-epsilon PreLN injection preserves exact-real history information, KL and mutual information in its normalized output. It is not a paid efficient decoding/prediction construction and does not establish low risk: the stated overall rare prediction risk remains at least 3/40. Finite coefficient descriptions do not provide finite execution precision. Exact real discrimination must not be recast as floating-point robustness or computable prediction at the declared resources.

The one-read statistical witness instead pays O(N) width and O(log N) depth, with the inherited terminal-A conditional risk bound 157/sqrt(1+(N-2)u)+O(N^(-1/2)). The clipped overall extension retains 1300u/sqrt(1+(N-2)u)+w(alpha-q)_+ +epsilon, with fixed dyadic alpha and its full norm envelope. Its ordinary-output range floor remains; it does not establish overall convergence for arbitrary u. At the stated epsilon=min(1/16,1/N), resource costs and the 1/N remainder are preserved. Arbitrary-accuracy full value/head widths must be charged. Neither wide witness settles fixed-width invocation complexity or supplies a new statistical rate.

## Historical alternatives and limitations

The generic-transcendental injection idea was superseded by the explicit dyadic-position construction. Scalar v1's optional Gaussian-observation aside is removed from v2. NOISY_ONE_READ_INFORMATION remains an archived unadopted model extension and is not part of the report or the frozen exact-real task. It must not be promoted as an adopted theorem merely because the file is archived.

Overall v1 omitted arbitrary-epsilon full-head width and used an invalid small-N epsilon choice; v2 repairs both. Report v1 omitted the dyadic-alpha qualifier; v2 restores it; v3 adds materialized dense attention workspace. Original historical bytes remain unchanged. Exact-version audit scope and creation-time labels are retained rather than silently upgrading earlier drafts.

Prior scalar-context/expressivity constructions are explicitly credited. The specific positive-epsilon implementation is not certified as a first general expressive mechanism. Novelty and full literature coverage remain uncertain. No scientific simulations, finite execution, numerical validation, parameter-generation run, model training or visual acceptance is claimed. Visual acceptance is NOT COMPLETED. External estimator/compiler dependencies remain OPEN; this is not a recovered complete v10 corpus.

## Privacy and verification

Scoped review found no secrets, sensitive personal information, private correspondence or machine paths requiring redaction. Papers are cited and summarized, not redistributed in full. No new license is added; this is not legal clearance.

SOURCE_DERIVATION_MAP.json records source/public sizes and hashes. PACKAGING_QA.json separates fresh static checks from preserved historical QA, including four adapted-Markdown hashes. independent_review/ contains review records. SHA256SUMS and python verify_package.py are read-only integrity verification. Original build scripts write reports and should run only in disposable copies. Original relative dependency references may not resolve after relocation.
