# Audit: universal deterministic rewrite conservation

6 November 2026 UTC.

## Exact source binding

Reviewed `UNIVERSAL_REWRITE_CONSERVATION.candidate.v1.md`.
SHA-256: `9fa0a82cf43eca5bb231feaf765516ad9fb4c8dce87e003acfa23ac50beb484d`.

## Verdict

Pass for the stated symbolic theorem. No architecture separation, efficient algorithm, task-risk lower bound, or stationary-only theorem is established.

## Proof checks

1. The quantifier order is essential: a single fixed bijection of the finite path space preserves every source in the specified class. For a bijection, measure preservation implies equality of each path's mass with its image's mass.
2. Taking the initial-pair law to be a point mass is allowed by arbitrary initialization. Strictly positive row transitions then force the image to retain that initial pair.
3. The four independent transition parameters range over an open product interval. Holding three fixed reduces likelihood equality to constancy of `p^u(1-p)^v`. Its logarithmic derivative is zero only when both integer exponent differences vanish. This identifies all eight triple counts without requiring boundary transitions.
4. Equal initial pair and all triple counts suffice by direct likelihood factorization, including zero transition probabilities. No division by a zero boundary probability is used in this converse.
5. The displayed expression for total ones counts the initial two symbols once and each subsequent symbol through its incoming triple once. It is correct.
6. For a specified terminal suffix of length b, with N>b>=2, change any of the N-b preceding bits while retaining the suffix to obtain different total-one counts. Each permitted rewrite, its inverse, and any composition preserve this count. Consequently a Markov chain selecting only these rewrites cannot converge from every starting history to the uniform distribution over that entire suffix fiber. This conclusion also holds if the allowed selection probabilities depend on the current history, since no count-changing move exists.

## Scope and cost checks

- The source class is binary, homogeneous, second-order, arbitrary-initial, finite-horizon. The target is a permutation of histories, not a causal predictor or physical execution architecture.
- Source-dependent choices of a different permutation for each law are outside the necessity theorem's universal fixed-permutation premise.
- Stationary-only initialization is not covered by the initial-pair argument. The candidate explicitly avoids that extension.
- The proof contains no computation of an orbit average, conditional law, type-class enumeration, or partition function. It does not hide an efficient implementation claim; it provides no such implementation at all.
- The conclusion is an orbit obstruction for exact universal rewrites, not a lower bound on risk-preserving task replacement. A task can ignore conserved information or remove it by separate output algebra.
- No physical-to-logical compilation is supplied or required. No inference about communication, circuit resources, or model width follows.
- The result does not assume the desired lower bound. Its only obstruction is the explicitly proved invariant.

## Optional clarification

“Cannot be uniformly mixing” can be replaced by “cannot converge from every initial history to the uniform distribution on the entire fixed terminal-suffix fiber” to avoid ambiguity between a uniform target distribution and a uniform mixing-rate guarantee. This wording clarification does not change the mathematical result.
