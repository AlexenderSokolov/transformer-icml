# Audit: finite local groups and task counterexamples

6 November 2026 UTC. Symbolic proof review and targeted verification of the closest cited averaging result. No numerical experiment or physical implementation validation was performed.

## Exact source bindings

- `FINITE_GROUP_LOCAL_TASK_FOLDING.candidate.v1.md`: SHA-256 `6e493a102ee4aa385227eb6ee534692fd8515b074da67201d66dcc210c387078`.
- `INVARIANCE_DOES_NOT_FORCE_SUFFIX_DOMINATION.candidate.v1.md`: SHA-256 `fd0e1cad3e82691876d1931168b7c0cffd5755641194f00aa3db9b9d2c8deab0`.
- `INVARIANT_TASK_COUNTEREXAMPLE_FAILURES.candidate.v1.md`: SHA-256 `b4f706db5fdea023f129d525ba7dfdc8c411b02ddc894783b82f07435bdae59f`.
- `PRIOR_COMPARISON.v1.md`: SHA-256 `eb477ef41dd55009922d7c14d2c150e5a73574f91cd31f9e8b0f845550af39e5`.

Background read: `LOCAL_TYPE_INVOLUTION_CERTIFICATE.candidate.v2.md` and `SYMMETRIC_QUADRATIC_NUISANCE_REMOVAL.candidate.v1.md` from the preceding task-oriented simulation collection. Their physical compiler dependencies remain inherited rather than independently re-proved in this audit.

## Verdict

Pass for the stated symbolic claims, with two small notation clarifications below. The general group-average argument is standard. The explicit multi-phase construction and risk comparisons are valid logical examples; they are not a newly constructed physical multi-phase network. The count example excludes exact suffix-only sourcewise domination. The spin example excludes zero communication. Neither supplies the missing lower bound against arbitrary cheap interactive task replacement.

## Finite-group proof checks

1. Initial-pair and triple-count preservation give exact likelihood equality for every homogeneous order-two source, including arbitrary initial laws with zeros. Final-suffix preservation fixes the history-dependent target. Convexity and change of variables then yield exact sourcewise domination by the group average without needing positivity or the good event.
2. Transitivity plus orbit-stabilizer counting yields a uniform phase barycenter on the good event. Off that event both outputs remain in the convex hull of branch distributions, so their TV distance is at most the branch diameter. The exceptional-event term is correct. The invariant-event hypothesis is sufficient, though stronger than needed for this direct pointwise calculation.
3. First-hit selection in a fixed word library is unchanged by a regular label action. Disjoint banks ensure commuting actions. Matching both boundary pairs and internal triple counts handles every cross-boundary triple. No independence of block occurrences is required for repeated conditional minorization by the sum of distinct word probabilities.
4. The finite-state criterion is a valid sufficient algebraic certificate if the block identity holds on every reachable incoming state, the later transition commutation identities hold on the states they are applied to, and the readout intertwines the actions. Checking on all states avoids reachability-domain ambiguity. Encoding a full position clock makes the certificate finite, not necessarily small or efficient.
5. The two eight-bit words have matching boundary pairs and internal triple counts. For a block beginning immediately after an even time, the odd local positions carrying a one are 3 and 5 respectively. Their phase increments are S and S+1; equal even total-one count preserves outgoing parity. Resetting each zone eliminates cross-zone phase contributions by definition. Each successful bank flips precisely its own coordinate.
6. On any history, averaging over all group elements averages the hit coordinates and leaves the others fixed. For a missing coordinate, its two branch logits differ by 2ρ_j; sigmoid Lipschitz constant 1/4 bounds the branch gap by ρ_j/2. Replacing a fixed branch by its midpoint costs at most ρ_j/4. Averaging other coordinates cannot increase the bound. Telescoping and taking expectations prove the displayed coordinate-weighted excess without independence between banks.
7. The uniform sign sum has mean zero and second moment Σρ_j². Taylor remainder bounded by |u|²/8, using |sigmoid''|≤1/4, proves the barycenter-to-baseline bound Σρ_j²/8. Averaging logits is not silently equated with averaging probabilities.
8. Empty banks cause no contradiction: the corresponding no-hit probability bound is one and the all-hit event can be empty. A nonvacuous 2^r-phase orbit requires all banks nonempty. For the displayed r=2 equal-bank example this means N-b-2≥16.

## Computation and physical scope

The communication protocol really sends only the suffix bits, with b/2 bits in the stated aligned AA/BB setting. It uses a public source-independent evaluator, not an oracle for the unknown transition law. Its local computation need not be cheap: direct multi-phase averaging has 2^r branches, and the candidate explicitly charges that work. The inexpensive unperturbed sigmoid incurs the stated quadratic amplitude error.

No task-risk lower bound is an assumption of the proof. No full-type conditional expectation or exponential enumeration is hidden in the claimed cheap baseline. The general finite-phase criterion alone does not supply an efficient branch evaluator. The cited physical baseline requires its previously established compilation; a new physical multi-phase reference remains conditional on its own uniform approximation theorem. Approximate physical suffix dependence must not be promoted to exact logical invariance. The original source, target, ordinary-softmax architecture, total-row work, precision costs, and randomization-inside-TV distinction remain explicit.

## Majority counterexample checks

For the two IID endpoint sources, total count determines the likelihood ratio. Under absolute error in the next-one probability, a posterior majority endpoint is Bayes-optimal over all reported probabilities. The midpoint is also optimal at a tie. Randomization cannot improve this pointwise minimum.

The mixture Bayes risk is Δ e_n. Posterior probabilities form a martingale. For even n, the tie event; for odd n, the event with count (n+1)/2, has positive probability and admits two-step continuations whose posteriors lie on opposite sides of one half. The concave posterior Bayes-error function therefore decreases strictly on that event. This verifies e_(n+2)<e_n; monotonicity extends the strict gap to every N≥b+2. A suffix-b rule has mixture risk at least Δ e_b, so at least one source has excess at least g=Δ(e_b−e_N)>0.

Universal invariance of this majority rule already follows from preservation of the single IID Bernoulli(c) measure: different counts have different path masses. Its c-dependence is public class dependence, not dependence on the unknown source. The logical bounded-gain sign computation has O(log N) stages and is valid on the finite count grid, including ties. Physical transfer needs error below g, with the corresponding precision paid. Its total-count communication is logarithmic, so it is not a general cheap-communication obstruction.

## Spin counterexample checks

The stationary initial pair gives two independent symmetric parity chains. Their transition innovations are independent signs with mean θ; hence all lag-two products are independent. Subsampling each chain by two transitions produces correlation θ², proving equality of each party's marginal at θ=±h. Bob owns the terminal pair under the stated alignment, and the two next-one targets differ by h for each Bob input. Pointwise triangle inequality and the common marginal prove worst-source zero-communication risk at least h/2, also with independent shared/private randomness.

The full-data empirical lag-two correlation has variance at most 1/(N−2). Multiplication by the known terminal spin and the factor one half give the stated TV risk bound. Counts and terminal pair determine this estimator, but its universal invariance under every source-preserving map is not asserted. Separate marginal equality gives no quantitative interactive communication lower bound.

## Literature check and novelty boundary

Independently inspected Chen, Dobriban and Lee, [A Group-Theoretic Framework for Data Augmentation](https://www.jmlr.org/papers/volume21/20-163/20-163.pdf), Lemma 1 (printed p.15) and Proposition 2 (printed p.16). They establish orbit conditional averaging, covariance reduction, and convex-loss improvement under exact invariance. The comparison's attribution and page locations are correct. Applying this to a history-dependent prediction target requires the explicit target-invariance step, supplied here. Group averaging itself is not new.

The remaining references were reviewed for the scope of the comparison, not exhaustively re-searched or independently theorem-checked. The comparison appropriately distinguishes multiset first-order Markov bases from one-history fixed-suffix order-two rewrites, and explicitly labels inaccessible theorem detail and secondary verification. No priority certification follows.

## Small clarifications recommended

- Replace “All zone start times are even” with “Each zone begins immediately after an even time.” The first included symbol indices are odd. The displayed phase calculation uses the correct convention.
- State `0<h≤1−2c` explicitly when introducing the two spin parameters ±h; the claimed positive separation requires h>0.

These clarifications do not change the proved results. No scientific or architecture-level claim beyond the narrow scopes above is certified.
