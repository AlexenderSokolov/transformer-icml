# Retained limits and a genuine zero-communication task obstruction

6 November 2026 UTC. Private analytical candidate v1. No experiments, mathematical execution, training, or upload.

## A. A useful full-type statistic whose parameter sign is invisible locally

Use spins X_i in {-1,+1} and a stationary homogeneous order-two law

 P_theta(X_i=z | X_(i-2)=u,X_(i-1)=v)=(1+theta zu)/2,

with initial pair independent uniform and |theta|<=1-2c. The two parity subsequences are independent stationary symmetric Markov chains with one-step correlation theta. Under AA/BB raw ownership each party sees every other site in each parity chain. Its marginal transition correlation is theta^2. Consequently Alice's full local marginal, and Bob's full local marginal, are each IDENTICAL at theta=+h and theta=-h.

Bob owns the final pair when N is divisible by four. The next-one probability is (1+theta X_(N-1))/2. Any zero-communication prediction at Bob (with independent shared/private random coins permitted) therefore has

 max{R_(+h),R_(-h)} >= h/2.

Proof: Bob's input and coins have the same law at the two parameters. For each such input the two target probabilities differ by h. Sum the two absolute losses and use the triangle inequality, then integrate under that common law.

Yet useful invariant full-data prediction is elementary. The lag-two products Y_i=X_i X_(i-2), i=3,...,N, are independent signs with mean theta: they are precisely the independent transition innovations of the two parity chains. Let theta_hat=(N-2)^(-1)sum Y_i and report (1+theta_hat X_(N-1))/2. Its TV risk is

 (1/2)E|theta_hat-theta| <= 1/[2 sqrt(N-2)].

This estimator factors through complete triple counts and the final pair, so it is invariant under the specific local rewrite and every endpoint-preserving type move. Thus actual useful task information can survive type projection and be invisible to either party alone.

Scope: this proves only a ZERO-communication obstruction. It does not prove a superlogarithmic interactive lower, a fixed-width PreLN realization, or universal invariance under all source-preserving maps. Deriving a quantitative distributed-testing lower at h of order N^(-1/2) would require an additional argument not supplied here. Identical separate marginals alone never imply a large interactive communication lower.

## B. Rejected routes

1. Parity of C_111 is type-invariant and can encode inner product on a selected AA/BB raw-history family. That is whole-output / exact-statistic hardness, not task-risk hardness. A predictor may discard the parity without hurting its task loss. The encoded distribution also is not the homogeneous Markov source law.
2. Reusing the old within-type quadratic nuisance fails because the local rewrite deliberately flips its phase. Its replacement is already cheap by the reviewed orbit midpoint proof.
3. Adding a new invariant nuisance to a consistent estimator does not establish useful distributed hardness. Its deletion remains a legal task replacement unless a separate prediction-risk separation is proved.
4. O(log N)-bit description of Markov types does not imply cheap distributed acquisition. Conversely, linear exact acquisition cost does not imply that all useful functions of the types are expensive.
5. The full-count majority counterexample in the companion candidate proves a real task-risk failure of suffix-only domination, but total count itself has logarithmic communication. It cannot honestly be promoted into a counterexample to arbitrary cheap communication folding.
6. An exponentially small strict Bayes gap cannot be transferred to a physical compiler with only inverse-polynomial error unless the error is below that gap. Required accuracy and precision must remain paid.

## C. Unresolved deliverable

No rigorous same-model counterexample was obtained in which a locally invariant fixed-width actual PreLN/softmax predictor has useful risk that every cheap interactive task replacement fails to match. The narrow suffix-domination theorem is proved; the general task-folding obstruction remains open here.
