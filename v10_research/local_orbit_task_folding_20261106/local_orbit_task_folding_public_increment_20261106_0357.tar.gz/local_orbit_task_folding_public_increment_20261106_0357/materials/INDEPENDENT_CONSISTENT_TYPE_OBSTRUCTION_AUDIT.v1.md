# Audit: consistent empirical-type suffix obstruction

6 November 2026 UTC.

Reviewed `CONSISTENT_TYPE_ESTIMATOR_SUFFIX_OBSTRUCTION.candidate.v1.md`, SHA-256 `83b42f71263b46a22e462b808bde2344dbd68c3938e970847074175653e857d9`.

## Verdict

Pass for the symbolic statistical statement. It strengthens the earlier suffix-only obstruction by using a predictor uniformly consistent over the full positive homogeneous order-two class with arbitrary initialization. It does not prove a physical PreLN realization or a lower bound against arbitrary interactive task communication.

## Uniform risk proof

- The selected context pairs start at positions 3,5,...,2L+1 and end at 2L+2≤N−1, so every one is a context counted by D_v. Their transitions occur after the initial pair.
- Given the raw history preceding one selected pair, the probability of its two specified bits is at least c². This also bounds the conditional probability given earlier block events. Repeated exponential-moment conditioning therefore gives the displayed binomial-dominated lower tail without assuming independent blocks. The conservative Chernoff constant 1/8 is valid.
- Each summand of Z_v is an indicator measurable before X_i times X_i−p_v and has conditional mean zero. Distinct increments are orthogonal. Conditional variance is at most 1/4 times the indicator; E Z_v²≤(N−2)/4 follows. The coarser E|Z_v|≤sqrt(N)/2 is valid.
- On D_v≥Lc²/2, the empirical ratio's error is bounded by 2|Z_v|/(Lc²). Clipping to the known admissible interval cannot increase distance to p_v. Off that event the error is bounded by one, including D_v=0.
- The terminal pair is random and correlated with the estimates. Bounding the selected error pointwise by the sum over four contexts is valid and explicitly avoids an unjustified independence step.
- L is positive for N≥6 and asymptotic to N/2. Consequently the claimed B_N is O_c(N^−1/2), uniformly over kernels and arbitrary initial laws. A displayed bound exceeding one at small N is harmless.

## Suffix separation proof

For b≥1, the all-ones event under Bernoulli(c) is a strict erroneous-majority event with probability c^b. Thus e_b≥c^b. The stated logarithmic upper bound on b gives c^b≥N^−1/4, with the inequality direction correct because log(c)<0.

The two-source mixture lower bound applies to all suffix-only reported probability vectors, including randomized rules. Uniform consistency bounds each witness risk of the empirical-type predictor by B_N. For fixed c and sufficiently large N, (1−2c)N^−1/4−B_N is positive. Averaging rules out simultaneous domination at both witnesses and gives the stated excess on at least one witness. Choosing the largest power of two below the threshold preserves logarithmic order and the earlier alignment domain for large N.

The predictor depends on public c but not the unknown source parameter or initial law. It factors through triple counts and terminal context and is invariant under the specified endpoint-preserving moves. This statement should not be strengthened to every universally preserving map unless terminal-context preservation is separately supplied.

## Approximation and scope

Uniform output error ζ adds at most ζ to each source risk. A positive gap survives when ζ is strictly below the stated gap. This is conditional transfer, not a physical construction; exact invariance need not survive approximate compilation. No uncharged source-dependent operation, presumed resource lower bound, or type-class enumeration enters the statistical proof. Acquisition of empirical counts in the distributed model is not shown cheap, and hardness of exact acquisition would not establish hardness of all task replacements.

## Initial report-body review

Also read `REPORT_BODY.zh.v1.html`, SHA-256 `cfa1b95922ccb7ed6668683526904bcbc6b68c96e5ba1309b3ca5b0f9ac24ff0`. Its existing finite-group, majority, spin, resource, and novelty summaries faithfully preserve the audited distinctions. It does not yet include the present strengthened empirical-type result. A revised body should identify this as a separate predictor; the earlier two-source majority rule itself is not globally consistent on the whole order-two class. This is semantic source review, not rendered layout validation or a binding to a later assembled report.
