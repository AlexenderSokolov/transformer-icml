# Final semantic and integrity audit

6 November 2026 UTC.

## Frozen deliverable

`RESEARCH_REPORT.zh.v3.html`

- Bytes: 116748.
- SHA-256: `783dda0107cd255fc918b532dced71469e34279a314cb38cb46037eec9c799d0`.
- Body source: `REPORT_BODY.zh.v2.html`, embedded exactly.
- Detailed independent integrity results: `INDEPENDENT_REPORT_INTEGRITY.v3.json`.

Verdict: pass for mathematical-summary fidelity, source embedding, version bindings, and the scoped privacy/static checks below. This is not visual-render acceptance, scientific execution, or a complete re-proof of inherited physical compilers.

## Content review

The Chinese body preserves all material distinctions from the independent source audits:

- Exact sourcewise convex-risk improvement belongs to the orbit average. The implementable suffix predictor pays an exceptional-event term, and physical comparisons additionally pay uniform approximation errors.
- Finite-group transitivity and a suffix-computable barycenter are explicit sufficient structural conditions. They are not a universal characterization or a generic resource frontier.
- The reset-zone multi-phase construction is a logical reference function. Neither its physical PreLN realization nor an architecture-preserving arbitrary averaging compiler is asserted.
- Exact suffix transfer uses b/2 communicated bits in the aligned domain. Direct multi-phase averaging retains its exponential local computation. The unperturbed sigmoid pays the quadratic amplitude term.
- Universal-rewrite type conservation invokes arbitrary initial laws. No stationary-only converse is asserted.
- The majority counterexample refutes exact suffix-only sourcewise domination and still has logarithmic count communication. Its failure of full-class consistency is expressly retained.
- The separate empirical-transition estimator strengthens the counterexample to a uniformly consistent full-class predictor. Its O_c(N^−1/2) upper and the short-suffix witness lower are correctly distinguished. No actual fixed-width physical construction or general interactive lower is inferred.
- The spin example proves only a zero-communication obstruction.
- The novelty discussion correctly credits classical invariant convex-risk averaging. Mathematical results are separated from inherited physical resource guarantees and from numerical or training claims.

## Added majority section: independently re-reviewed

The delivered `INVARIANCE_DOES_NOT_FORCE_SUFFIX_DOMINATION.candidate.v2.md` has SHA-256 `d11854f28b3640172114b6595b447509d00999a40180a14fa2f2fb4553aa9af1`.

Its added Section 7 is valid. For b≥1, the all-ones event under Bernoulli(c) implies e_b≥c^b. Hoeffding bounds the majority error including half-weight ties by exp[−2N(1/2−c)^2]. Their difference yields the stated gap lower bound. For b=Theta(log N), c^b is inverse polynomial and dominates the exponential term, giving g≥Delta c^b/2 eventually. The displayed accuracy choice is a target with O_c(log N) logarithmic precision demand, not a completed physical compilation. The full-class consistency limitation remains explicit.

The original majority version 1 is restored and preserved at its previously audited SHA-256 `fd0e1cad3e82691876d1931168b7c0cffd5755641194f00aa3db9b9d2c8deab0`. Both versions are embedded separately. Earlier audit hashes therefore have their original exact referents. The superseded assembled report version 2 is not the deliverable certified here.

## Independent embedding and privacy checks

Parsed the assembled HTML independently and decoded every preformatted appendix. All 14 appendix texts equal their named source files exactly, each appears once, all on-disk SHA-256 values equal the source-binding manifest, and each declared hash occurs in the report. The body equals its complete source as an exact substring.

No script, iframe, object, embed, form, input, event-handler attribute, or javascript URL was found. The report consists of research prose, mathematical formulas, source filenames, hashes, and cited public literature links. Review found no credentials, personal sensitive records, private absolute workspace paths, or coordination identifiers. Relative research-document references are provenance, not private machine paths. These content and pattern checks do not certify every possible privacy property.

No visual rendering was requested or performed. No mathematical enumeration, simulation, model execution, training, or upload was performed for this audit. Static HTML parsing and hashing are document-integrity checks only.
