# Scope and failed routes

6 November 2026 UTC. This round extends the explicitly structured task-risk argument; it does not solve the general T1/T2 resource frontier.

The common prediction task is the next-symbol distribution at the actual terminal pair of an unknown homogeneous binary second-order source with all transitions in [c,1-c]. The main stationary interior source class is included. The rewrite results hold more broadly for arbitrary initial-pair laws; the necessity-of-type-conservation argument uses that broader requirement and must not be asserted from stationary invariance alone. Loss is expected terminal total variation, not training loss or a proper-score replacement.

1. Failed: source-preserving transformations alone imply cheap averaging. They preserve full Markov type and may leave computationally important statistics untouched. A proved suffix-computable orbit barycenter and its evaluator cost are separate obligations.
2. Failed: mixing generators automatically produce uniform orbit averaging. Accessibility, stationary law and periodicity would require proof. The candidate uses exact finite-group averages and algebraic phase equivariance instead.
3. Failed: many phases are a free extension of a real single-phase Transformer. The reset-zone example is proved as a reference function; no new physical multi-phase network has been compiled. A comparison to a physical network is conditional on a separately proved uniform error bound. The existing suffix baseline is genuinely compiled under its inherited contract.
4. Failed: group size affects no resources because communication is b/2. Direct evaluation uses 2^r sigmoids in the example and growing r needs a ledger. The alternate single-sigmoid rule pays sum rho_j^2/8, rather than claiming exact equality.
5. Failed: invariance of a useful statistic refutes all cheap task replacements. A suffix-only domination obstruction is narrower than an arbitrary-message communication lower bound. In particular a global count can be sent using logarithmically many bits.
6. Failed: additive loss comparison implies a sourcewise multiplicative guarantee. It does not without a corresponding positive sourcewise risk lower bound.
7. Failed: the invariant convex-risk averaging lemma is a new result. It is standard Rao–Blackwell/group averaging machinery; targeted primary-paper comparison is recorded separately.
8. Failed: make O(risk^-2) generic suffix cost into O(depth) for every low-risk network. The previous equivalence shows that this substitutes the unproved resource lower bound for the missing structural argument.

No new finite-precision numerical execution theorem, optimized resource rate, learned parameters, training guarantee or exhaustive novelty determination is provided. There is no mathematics executable in this round. Document build/HTML static inspection, if performed, is not a numerical or model experiment. Existing dependencies are reused with explicit scope, not transitively re-proved.
