# Universal deterministic rewrite conservation

6 November 2026 UTC. Candidate v1. Symbolic statement; independent review pending. No architecture or communication conclusion is implied by this lemma.

Fix N>=3 and binary homogeneous second-order path laws with arbitrary initial-pair distribution μ and four independent transition probabilities p_ab in the open interval (c,1-c), 0<c<1/2. Let τ be a bijection of {0,1}^N that preserves EACH such path measure. Then τ preserves the initial pair and every triple count. Conversely every bijection with these properties preserves every homogeneous second-order path measure, even with zero probabilities.

Proof. In a finite space, preservation by a bijection means P(x)=P(τx). Concentrating μ on x's initial pair proves that τx has the same initial pair: every path with that pair has positive probability, all other initial pairs have probability zero. Write A_ab=C_ab1(x), B_ab=C_ab0(x), and primed versions for τx. Equality of path masses gives

  product_ab p_ab^(A_ab) (1-p_ab)^(B_ab)
  = product_ab p_ab^(A'_ab) (1-p_ab)^(B'_ab).

Fix the other three row parameters. For each row this says p^u(1-p)^v is a positive constant throughout an open interval, with integer u=A-A' and v=B-B'. Logarithmic differentiation yields u/p-v/(1-p)=0 throughout that interval, hence u-(u+v)p=0, so u=v=0. All counts agree. The converse follows directly from the likelihood factorization.

The total number of ones is x_1+x_2+sum_ab C_ab1. Hence every such rewrite preserves that count. In particular no family of universally preserving bijections can mix across different values of this statistic. A chain or group built only from such bijections cannot be uniformly mixing on the whole set of histories sharing a terminal suffix: that suffix class contains differing counts whenever N>b>=2.

This is a limitation on an exact universal orbit-to-suffix reduction for arbitrary functions. It is NOT a lower bound on task risk, nor a proof that a count-dependent predictor lacks some other cheap risk replacement. The assumed arbitrary initial laws are essential to the stated initial-pair proof; this lemma is not asserted from preservation of the stationary-only source class alone. Positive row parameters on an open interval are enough; no boundary transition is used in the necessity proof.

Failure retained: a broad attempt to infer whole suffix-fiber mixing solely from universal probability preservation fails because the full Markov type is conserved. Additional output algebra, rather than source preservation alone, must make an orbit barycenter suffix-computable.
