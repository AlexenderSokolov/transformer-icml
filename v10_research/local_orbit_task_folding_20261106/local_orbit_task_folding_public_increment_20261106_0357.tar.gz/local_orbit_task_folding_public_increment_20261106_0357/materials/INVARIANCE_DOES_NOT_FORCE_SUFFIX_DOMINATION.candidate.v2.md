# Universal local invariance does not imply suffix-only risk domination

6 November 2026 UTC. Analytical candidate v2; v1 is preserved. This version adds the scaling and full-class limitation in Section 7. Symbolic proof; no mathematical executable, training, upload, or public mutation. This is a narrow task-risk counterexample, not a communication lower bound or a new statistical rate.

## 1. Precise conclusion

Fix 0<c<1/2 and integers N>=b+2, b>=1. There is a source-independent binary next-symbol predictor Q_N, invariant under every probability-preserving bijection common to all homogeneous binary order-two source laws, for which NO predictor depending only on the final b symbols has risk no greater at both IID Bernoulli(c) and IID Bernoulli(1-c).

The same conclusion holds for the specific local involution in LOCAL_TYPE_INVOLUTION_CERTIFICATE.candidate.v2.md whenever its horizon restrictions are met. Thus even exact invariance under all universal type moves does not imply exact sourcewise domination by a prescribed short suffix predictor. The loss is actual prediction TV; a replacement may output arbitrary distributions and need not reconstruct Q_N.

This does NOT refute cheap general distributed task folding. Indeed Q_N can be evaluated with O(log N) communication by exchanging counts. It also does not refute minimax domination with slack or a constant-factor risk allowance.

## 2. Two sources and a fully invariant predictor

Let P_- be IID Bernoulli(c), P_+ be IID Bernoulli(1-c). Both are stationary homogeneous binary order-two sources in the usual interior class P_c. They have constant next-one probabilities c and 1-c. Put Delta=1-2c and S(x)=sum_i x_i.

Define Q_N's probability of one to be c when S<N/2, 1-c when S>N/2, and 1/2 on a tie. This is one predictor, independent of the actual source.

The complete Markov type determines S:

 S=x_1+x_2+sum_(a,b) C_ab1.

Consequently Q_N is full-type invariant and invariant under the reviewed local rewrite. More strongly, suppose a bijection j preserves every source law in the model. Finite-space measure preservation gives P_-(x)=P_-(j(x)); since c!=1/2, equality of c^S(1-c)^(N-S) forces S(j(x))=S(x). Hence Q_N is invariant under every such bijection. This statement concerns bijections, not arbitrary measure-preserving randomized kernels.

## 3. Bayes TV risk, including arbitrary replacement outputs

Introduce an equal prior on the two sources only as a proof device. Given an observed word of length n, the likelihood ratio is

 L_n=((1-c)/c)^(2S-n).

For posterior probability pi of P_+, the conditional TV loss of a reported probability q is

 pi |q-(1-c)|+(1-pi)|q-c|.

Clipping q to [c,1-c] cannot increase this loss. On this interval it is affine in q; its minimum is Delta min(pi,1-pi), achieved at the more probable endpoint (and every point of the interval when pi=1/2). Thus majority is a Bayes-optimal TV predictor, not merely an output classifier. Randomized predictions cannot do better, by the same pointwise minimization or convexity.

Write

 e_n = Pr_(Bin(n,c))(S>n/2) + (1/2) Pr_(Bin(n,c))(S=n/2).

Symmetry between the two sources gives equal-prior optimal prediction risk Delta e_n. The full-history Q_N attains Delta e_N. Under IID sources the final b symbols are just a length-b IID experiment, so every suffix-b predictor Q_s satisfies

 (R_-(Q_s)+R_+(Q_s))/2 >= Delta e_b.

## 4. Strict improvement from at least two additional observations

Bayes error cannot increase with more observations: the later observer can ignore them. It strictly decreases between n and n+2.

For even n, the event S=n/2 has positive mixture probability and posterior pi=1/2. Two additional observations have nonzero probabilities of 00 and 11 under both sources. These yield posterior values on opposite sides of 1/2. The posterior is a martingale, and min(pi,1-pi) is concave with a strict corner at 1/2. Conditional expectation of this function is therefore strictly smaller after the two observations on that event.

For odd n, use the positive-probability event S=(n+1)/2, whose likelihood-ratio exponent is +1. Two observations 00 yield exponent -1, whereas 11 yield exponent +3. Their posterior values again lie strictly on opposite sides of 1/2, giving strict Jensen improvement. Other old observations cannot increase expected Bayes error. Thus e_(n+2)<e_n.

It follows that N>=b+2 implies e_N<e_b. Set g=Delta(e_b-e_N)>0. If one suffix predictor sourcewise dominated Q_N at both sources, averaging those two inequalities would imply Delta e_b<=Delta e_N, a contradiction. In fact every suffix predictor has at least one source on which its excess risk over Q_N is at least g.

No assertion that g stays bounded away from zero is made. For fixed c and large b, this gap can be very small; it is not a new minimax rate.

## 5. Architecture and approximation boundaries

There is a simple bounded-gain constant-width LOGICAL uniform-head program for Q_N. With the actual synthetic zero-symbol terminal, a zero-score scalar full-prefix attention read returns r=S/(N+1). Subtract N/[2(N+1)]. Repeated fixed-gain doubling with clipping to [-1,1], for ceil(log2(2(N+1))) stages, maps every nonzero grid offset to its sign and preserves a tie as zero. All states and primitive gains remain bounded; depth is O(log N). Use final logits (a t,0), a=log((1-c)/c), with t the resulting sign. Ordinary softmax returns exactly the desired probabilities, including 1/2 at a tie. This is a logical circuit, not an independently audited all-feature PreLN realization.

The reviewed small-amplitude paired-state compiler is a possible physical route. This note does not assert a new complete physical theorem or exact physical invariance. If a separately verified physical construction has uniform TV error zeta, then its risk differs from Q_N by at most zeta at each source and its rewrite modulus is at most 2zeta. If zeta<g, NO suffix-b predictor can sourcewise dominate that physical output either, by the same mixture gap. Exact equality of physical outputs on orbits does not follow from uniform approximation.

The necessary accuracy is tied to g. Selecting zeta<g without charging log(1/zeta), preparation, amplitude, restoration, final normalization, and parameter precision would conceal costs. In particular no O(log N) physical claim is obtained here when b grows with N. No claim about useful-head ablations is supplied.

## 6. Why this is not the missing communication counterexample

Under AA/BB ownership Alice sends her number of ones in ceil(log2(N/2+1)) bits; Bob adds his count and evaluates Q_N. Hence the example is cheap in ordinary interactive communication. It proves that local invariance does not force suffix-only sourcewise domination, but leaves open a general efficient task-folding theorem that may use other cheap statistics.

References read: ../task_oriented_simulation_20261106/LOCAL_TYPE_INVOLUTION_CERTIFICATE.candidate.v2.md; ../task_oriented_simulation_20261106/UNIVERSAL_MARKOV_TYPE_PROJECTION.candidate.v1.md; ../nonlinear_statistical_frontier_20261106/IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md.

## 7. Nontrivial scaling and the full-class limitation

The strict gap need not demand exponentially many bits in N. For b>=1 the all-ones sample is an error under Bernoulli(c), so e_b>=c^b. Hoeffding's bound gives e_N<=exp[-2N(1/2-c)^2]. Hence

 g >= Delta {c^b-exp[-2N(1/2-c)^2]}.

Take N divisible by four and b=Theta(log N), with b a power of two if the prior suffix convention requires it. For all sufficiently large N, g>=Delta c^b/2, an inverse-polynomial lower bound in N. Choosing zeta<=Delta c^b/4 then requires log(1/zeta)=O_c(b)=O_c(log N). This is a justified accuracy/description target, not by itself a completed PreLN compiler audit. The logical circuit has no variable-input logarithm stage; its terminal logit scale a depends only on fixed c. Any physical transfer must still verify full preparation, normalization, restoration, and complete-state error at this tolerance.

Q_N is useful and Bayes-optimal on the two IID witness sources. It is NOT claimed to be consistent over the entire unknown order-two class P_c: global count majority would generally discard the terminal-context dependence needed there. A theorem claiming sourcewise suffix domination for every invariant predictor is disproved by these two witnesses. A theorem restricted to globally consistent or minimax-rate-optimal predictors, or allowing statistical slack, needs a different argument.
