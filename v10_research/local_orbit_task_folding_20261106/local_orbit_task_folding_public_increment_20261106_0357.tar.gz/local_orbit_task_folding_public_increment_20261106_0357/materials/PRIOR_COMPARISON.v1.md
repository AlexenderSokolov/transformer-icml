# Local rewrite orbit folding: targeted prior comparison

6 November 2026 UTC. Targeted web verification, not an exhaustive novelty search. Baseline read: task_oriented_simulation_20261106/README.v1.md and LOCAL_TYPE_INVOLUTION_CERTIFICATE.candidate.v2.md. This document does not certify any proposed generalization's proof.

## 1. Closest averaging result: explicitly not new

Shuxiao Chen, Edgar Dobriban, Jane H. Lee, **A Group-Theoretic Framework for Data Augmentation**, JMLR 21(245):1–71, 2020.

- Landing page: https://jmlr.org/papers/v21/20-163.html
- Full paper: https://www.jmlr.org/papers/volume21/20-163/20-163.pdf
- Verified full-text locations: Lemma 1, printed p.15; Proposition 2 and Rao–Blackwell discussion, printed p.16 (PDF pages indexed 14–15).
- What it establishes: Under exact distributional invariance, group averaging is orbit conditional averaging, preserves expectations, reduces covariance, and decreases expected convex functions. Proposition 2 applies the principle to estimators and convex loss. The paper separately studies approximate invariance.
- What it does not supply for this project: a binary order-two fixed-suffix rewrite construction, cancellation of this history phase, or a communication-cheap implementation of the averaged predictor. Its fixed parameter estimation formulation also requires an explicit adaptation when the prediction target depends on the history: the target must remain fixed along each orbit.

Thus source-preserving group averaging plus Jensen, including the two-element involution case, must be presented as standard machinery, not the contribution. Merely replacing C2 by a larger finite group does not change that assessment.

## 2. Count-preserving moves and conditional sampling

Akimichi Takemura and Hisayuki Hara, **Markov chain Monte Carlo test of toric homogeneous Markov chains**, Statistical Methodology 9 (2012), 392–406; preprint https://arxiv.org/abs/1004.3599 ; full text https://arxiv.org/pdf/1004.3599 .

Verified §2.2, §2.3, Theorem 1: the sufficient statistics are initial-state frequencies and aggregate transition counts for a multiset of first-order paths. Their moves preserve these statistics; crossing-path swaps and other moves connect fibers in the stated cases. Theorem 1 treats two states and arbitrary length; another result treats arbitrary states and length three. These include degree-one moves, so it would be wrong to say all their operations require multiple paths.

Important differences: connectivity of a contingency-table fiber is not itself a bijective fixed-suffix map on one binary order-two history, a phase-cancellation identity, or an inexpensive barycenter. Encoding order-two histories by pair states gives a four-state graph with forbidden transitions. The two-state theorem cannot simply be imported into that constrained four-state problem.

Related source: Hara and Takemura, **A Markov basis for two-state toric homogeneous Markov chain model without initial parameters**, 2011: https://www.jstage.jst.go.jp/article/jjss/41/1/41_1_033/_article/-char/en ; https://arxiv.org/abs/1005.1717 . Abstract verified: degree at most three suffices for their two-state model without initial parameters. This is a different model from preservation of an arbitrary initial-pair law.

Foundational reference: Persi Diaconis and Bernd Sturmfels, **Algebraic algorithms for sampling from conditional distributions**, Annals of Statistics 26(1), 363–397 (1998). Verified institutional record: https://statistics.stanford.edu/technical-reports/algebraic-algorithms-sampling-conditional-distributions . Search-accessible paper: https://www.math.ucdavis.edu/~deloera/MISC/LA-BIBLIO/trunk/Diaconis/Diaconis8.pdf . The general subject is Markov-chain sampling conditional on discrete exponential-family sufficient statistics. The PDF opened but yielded no extractable text here; no theorem-number claim is based on it.

## 3. Finite-group cancellation and random walks

Persi Diaconis, **Group Representations in Probability and Statistics** (1988), verified bibliographic DOI: https://doi.org/10.1214/lnms/1215467407 ; institutional preprint record: https://statistics.stanford.edu/technical-reports/group-representations-probability-and-statistics . The publisher page did not expose readable chapter text here.

Accessible secondary verification: https://math362.cjgg.me/notes/characters/fourier-theory.html , Remark 9.1 and §9.2. Uniform group averaging is the Reynolds projection onto invariant vectors. The notes attribute the finite-group Fourier upper-bound lemma to Diaconis (1988), Lemma 3.1. Nontrivial irreducible components vanish under uniform averaging. Random-walk convergence is a separate quantitative question, not a consequence of merely naming a finite group.

Application cautions developed for this project: a nonuniform single-step generator average need not be the uniform orbit projection. Periodicity or a proper generated subgroup can prevent the claimed cancellation. If noncommuting rewrites are sampled, prove stationarity, accessibility and the needed contraction or use exact finite-group averaging. A general finite-state transducer can be noninvertible and need not define any group action. Its aggregation requires separate source-preservation and target-invariance proofs. A sufficient exact projection identity can avoid invoking mixing altogether.

## 4. The meaningful additional composition/resource question

The candidate claim worth proving is more specific than the inherited averaging lemma:

1. Explicit local rewrites preserve every homogeneous order-two source likelihood, including arbitrary initial law; this requires initial pair, triple counts and boundary compatibility.
2. On a source-uniform high-probability event, the reachable output orbit has a barycenter depending only on the retained suffix, with no hidden prefix state.
3. The exceptional-event probability has a proved uniform bound under the stated positive-transition assumption.
4. The suffix-only map is actually implementable within the declared communication and physical architecture budget, including approximation errors.

These four obligations can turn standard averaging into a concrete resource separation. Finite orbit size, a short orbit description, or small sufficient statistics alone do not establish cheap evaluation. Exact risk domination belongs to the orbit average; the implementable suffix replacement generally pays an exceptional-event term and physical compilation error. Neither full-output hardness nor a universal low-risk-network replacement theorem follows from this composition.

Recommended phrasing: “We combine classical invariant convex-risk averaging with an explicit type-preserving local rewrite certificate and a separately proved suffix-computable orbit barycenter.” Novelty and priority remain unverified; do not call Jensen averaging, Reynolds projection, or count-preserving moves new.

No uploads, purchases, training, model experiments, or numerical tests were performed for this comparison.
