# A globally consistent type-invariant predictor need not admit suffix domination

6 November 2026 UTC. Private analytical candidate v1. Symbolic result; no executable, training, upload, or new-rate claim. This strengthens the consistency scope of INVARIANCE_DOES_NOT_FORCE_SUFFIX_DOMINATION.candidate.v1.md, without giving an actual PreLN construction or an arbitrary-message communication lower.

## 1. Full-type empirical predictor and uniform risk

Fix 0<c<1/2. Let P_c contain homogeneous binary order-two kernels with every transition probability in [c,1-c], with any initial law. For each context v in {00,01,10,11}, define

 D_v=sum_(i=3)^N 1{(X_(i-2),X_(i-1))=v},
 A_v=sum_(i=3)^N 1{(X_(i-2),X_(i-1))=v} X_i.

Use A_v/D_v when D_v>0 and 1/2 otherwise, clipped to [c,1-c], as p_hat_v. Report p_hat_(X_(N-1),X_N) as the next-one probability. This predictor factors through full triple counts and the final pair. It is exactly invariant under the reviewed local type rewrite, and all endpoint-preserving type moves.

Here is an elementary uniform risk bound, included to avoid hiding a statistical assumption. Put L=floor((N-3)/2), and assume N>=6. Among the context pairs counted in D_v are the L disjoint pairs (X_3,X_4),(X_5,X_6),...,(X_(2L+1),X_(2L+2)). Conditional on all symbols preceding any such pair, its probability of equaling v is at least c^2. For their indicators B_j, iterated conditioning gives, for every t>0,

 E exp[-t sum_j B_j] <= (1-c^2+c^2 exp(-t))^L.

The usual one-line exponential Markov optimization (the binomial lower-tail Chernoff bound) therefore gives

 Pr(D_v<Lc^2/2) <= exp(-Lc^2/8).

Let p_v=p(1|v) and Z_v=A_v-p_v D_v. Its summands are martingale differences relative to the raw history filtration, so E Z_v^2<= (N-2)/4 and E|Z_v|<=sqrt(N)/2. On D_v>=Lc^2/2,

 |p_hat_v-p_v| <= 2|Z_v|/(Lc^2).

Clipping cannot worsen the error, and off this event the error is at most one. Hence

 E|p_hat_v-p_v| <= sqrt(N)/(Lc^2)+exp(-Lc^2/8).

The actual final context is random; no independence with the estimator is assumed. Bound its error by the sum of the four context errors to obtain

 sup_(P in P_c) R_P(Q_type)
 <= B_N := 4sqrt(N)/(Lc^2)+4exp(-Lc^2/8)
 = O_c(N^(-1/2)).

The loose constants and classical rate are not claimed as new. Arbitrary initial laws do not affect this proof because the selected pair blocks begin after the initial pair.

## 2. Every sufficiently short suffix loses on at least one IID witness

For equal-prior IID Bernoulli(c) and Bernoulli(1-c), the companion proof shows that every suffix-b predictor has mixture TV risk at least Delta e_b, where Delta=1-2c and e_b is the optimal majority-testing error. In particular e_b>=c^b by the all-ones event under Bernoulli(c).

Choose any integer b>=1 with

 b <= log N/[4 log(1/c)].

Then c^b>=N^(-1/4). Consequently every suffix-b predictor Q_s satisfies

 [R_-(Q_s)+R_+(Q_s)]/2 >= Delta N^(-1/4),

while the globally consistent Q_type satisfies both witness risks <=B_N=O_c(N^(-1/2)). For all sufficiently large N, Delta N^(-1/4)>B_N. No suffix-b predictor can then sourcewise dominate Q_type, even just on these two sources.

Moreover some witness has excess risk at least Delta N^(-1/4)-B_N. Choosing b to be the largest power of two below the displayed bound retains b=Theta_c(log N), and N may remain divisible by four.

This is a real task-risk separation allowing arbitrary randomized replacement outputs. It does not depend on approximating Q_type's original outputs. It also withstands uniform output perturbations zeta<Delta N^(-1/4)-B_N, but such a perturbation only gives approximate invariance, not exact physical invariance.

## 3. Exact scope

This result invalidates blanket suffix-only sourcewise domination even when the invariant predictor is uniformly consistent over the full interior order-two class. It does not establish any architecture/resource advantage: no bounded-width actual PreLN realization is proved here. The known packed-suffix decoder could motivate a separately charged O(N)-depth route, but that is not a theorem of this note.

Exact distributed acquisition of all transition counts is difficult under the old ownership split, but this does not imply that a different low-cost predictor cannot match the task risk. No superlogarithmic interactive task lower is claimed. The missing arbitrary-message task-folding counterexample remains missing.
