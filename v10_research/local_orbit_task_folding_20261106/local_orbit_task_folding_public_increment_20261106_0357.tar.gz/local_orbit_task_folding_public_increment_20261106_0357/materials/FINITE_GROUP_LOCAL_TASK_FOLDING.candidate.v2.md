# Finite local rewrite groups and sourcewise task-risk folding

6 November 2026 UTC. Symbolic candidate v2; v1 is preserved. This version clarifies that a zone begins immediately after an even time, rather than calling its first symbol index even. No scientific executable, numerical check, training, physical-network construction, external write or upload accompanies this note. Administrative shell file reads/writes are not scientific execution. This is a sufficient structural criterion and a nontrivial multi-phase example, not a generic evolving-memory resource frontier or novelty claim.

## 1. Frozen contract

The source is an arbitrary homogeneous binary order-two Markov law P_(p,mu), with arbitrary initial-pair law mu and c <= p(y|a,b) <= 1-c for fixed 0<c<1/2. Input is the actual raw N-bit sample. The target on that history is tau_p(x)=p(.|x_(N-1),x_N). Risk is E_P TV(Q(X),tau_p(X)), with TV inside any predictor-randomness expectation. All predictors constructed below are deterministic and independent of p,mu.

Retain the final b-bit suffix Z, b>=2. For the original AA/BB physical comparison keep N divisible by four and b a power of two, 4<=b<=N/2. Alice owns positions 4i-3,4i-2, Bob positions 4i-1,4i. Physical claims concern the same positive-epsilon, full-feature real PreLN model with an ordinary final vocabulary softmax, and require a separately established uniform end-to-end approximation bound. A symbolic new phase decomposition is not a physical realization theorem.

## 2. General finite-group criterion

Let H be a finite group, |H|=h, acting by explicitly specified bijections T_g on all length-N words. Suppose:

1. Every T_g preserves the initial pair, all eight overlapping triple counts, and the final b-bit suffix.
2. A public finite phase set A and public map Phi:{0,1}^N -> A give a decomposition Q_ref(x)=q(Z(x),Phi(x)), where each q(z,a) is a probability vector.
3. There is an H-invariant good event G and an H-action on A such that Phi(T_g x)=g.Phi(x) for x in G, all g. The H-action on A is transitive. (More generally each orbit may be identified by a public suffix-computable label; average over that labeled orbit.)

Define

  Q_H(x) = (1/h) sum_(g in H) Q_ref(T_g x),
  M(z) = (1/|A|) sum_(a in A) q(z,a).

Then for every p,mu separately,

  R_P(Q_H) <= R_P(Q_ref).

Indeed homogeneous likelihood is mu(x_1,x_2) times the product of transition probabilities raised to the triple counts. Thus each T_g preserves P exactly, including when mu has zeros, and it preserves the target. Jensen's inequality followed by change of variables proves the claim. This part needs neither positivity nor G.

On G, orbit-stabilizer counting gives Q_H(x)=M(Z(x)): every phase appears h/|A| times in the group sum. The stabilizer need not be trivial; transitivity is the requirement. Let D(z)=max_(a,a' in A) TV(q(z,a),q(z,a')). Both Q_H(x) and M(z) are convex combinations of these branch vectors at the same z, even off G. Hence

  TV(Q_H(x),M(Z(x))) <= D(Z(x)) 1_(G complement),
  R_P(M) <= R_P(Q_ref) + E_P[D(Z)1_(G complement)].       (1)

If sup_x TV(Q_phys(x),Q_ref(x))<=zeta_h, add zeta_h to the right side with Q_phys replacing Q_ref. If a suffix evaluator returns M within uniform TV eta, add eta as well. The expensive orbit predictor Q_H is only a proof device; the task protocol evaluates M directly.

This is a finite algebraic criterion, not an assumption of cheapness. An arbitrary q(z,a) can be computationally hard and its table can have 2^b|A| entries. A large group or phase set can destroy local efficiency even while communication remains small. Section 5 records every such dependence.

## 3. Verifiable local certificates

A block replacement preserves homogeneous order-two likelihood if old/new words have the same first two and last two symbols and identical internal triple-count vectors. Cross-boundary triples are then identical for every surrounding word. Blocks must lie after the initial pair and before the retained suffix.

A useful construction uses a family of distinct same-length words W={w_a:a in K}, all with those boundary/type identities. Let a finite group K act regularly on their labels. At a prescribed bank of disjoint aligned blocks, select the first block belonging to W; replace w_a by w_(g a), leaving unmatched histories unchanged. This is a genuine K-action, since membership and first-hit selection are unchanged. Actions in disjoint banks commute, giving a product group. A union of several K-orbits of words also works when the action is explicitly defined on each and selection membership is invariant.

Phase equivariance must be verified, not inferred from type preservation. One general finite-state verification method is as follows. A public deterministic phase evaluator has finite state S and symbol transitions U_(t,y), allowing a public position clock. For a proposed block rewrite w -> w', find a state permutation V representing its intended phase action. Check the block transformation identity U_w'=V U_w on every reachable incoming state (or all states, which is stronger), and check that all later transitions commute with V. Check that the final readout obeys readout(Vs)=g.readout(s). This proves whole-history equivariance, including later suffix effects. A finite clock can encode all positions for fixed N; this makes verification finite, not necessarily efficient. Multiple generators must additionally satisfy their group relations on states or directly on the full-word maps. We do not infer commuting rewrites merely because their phase labels commute.

For a bank of m disjoint L-bit trials and a membership library of q distinct words, every next trial belongs to the library with conditional probability at least q c^L, regardless of previous failure and initial law. Repeated conditioning gives

  P(no hit in bank) <= (1-q c^L)^m.                       (2)

No block independence is assumed. A union bound over banks supplies the exceptional probability when G requires all banks to have hits. This is valid for fixed c; large L or a growing number of banks may make it ineffective. Variable trial lengths have a product bound with their corresponding q_i c^(L_i). Empty banks have failure probability one.

## 4. Explicit r-phase example

Take r>=2 and nonnegative integers m_1,...,m_r with 8 sum_j m_j <= N-b-2. Starting just after time 2, allocate consecutive disjoint zones I_j of lengths 8m_j. Each zone starts immediately after an even time; its first symbol index is odd. Unused pre-suffix bits and the suffix are outside the zones. In zone j define the RESET quadratic phase

  F_j(x) = sum_(k in I_j, k odd) x_k sum_(ell in I_j, ell<k) x_ell mod 2.

Resetting at zone boundaries is part of the definition, not a discarded cross term of the original full-history phase. Each F_j is a finite-state stream computation using local parity and its accumulated phase; the public clock chooses its zone. This example changes the reference nuisance to r phases. It does not assert that the original one-phase physical network secretly implements r phases.

Partition each zone into its m_j eight-bit blocks. Use

  w=00110000,    w'=00011000.

Both begin/end with 00. Their internal triples are 001,011,110,100 once each and 000 twice. Both have two ones. The involution T_j interchanges w,w' in the first matching block of zone j and is the identity if none match. These r involutions commute because their selection and edits use disjoint zones. They define H=(Z/2)^r on all histories, with group size 2^r.

Let E_j be the event of a hit in zone j. If the incoming within-zone parity is S, the block contributions to F_j are S for w and S+1 for w', because the selected odd local positions are respectively 3 and 5. The outgoing within-zone parity is unchanged (two ones), so all later phase contributions are unchanged. Thus T_j flips F_j on E_j and leaves every other phase unchanged. This also proves the identity in the presence of preceding blocks in the same zone. On G=intersection_j E_j the phase vector ranges over every element of {0,1}^r under H exactly once, so this is a genuinely 2^r-branch orbit rather than a relabeled two-branch example. G is invariant.

For public rho_j>=0 and public suffix function d define

  q(z,a)(1)=sigmoid(d(z)+sum_j rho_j(2a_j-1)),
  q(z,a)(0)=1-q(z,a)(1),
  M(z)(1)=2^(-r) sum_(a in {0,1}^r)
                       sigmoid(d(z)+sum_j rho_j(2a_j-1)).

No assumption is made that the rho_j are equal. If a fixed bounded-logit/state envelope is desired, impose the additional public bound sum_j rho_j<=R for fixed R; this controls the perturbation magnitude but does not itself prove any PreLN compilation or fixed-width implementation. For example r=2 with distinct positive rho_1,rho_2 gives four distinct branch logits and a group of order four. Set m_1=m_2=floor((N-b-2)/16) for an immediate explicit family. All four phases occur on every good orbit, regardless of the source.

Write gamma=1-2c^8 and let gamma^0=1. Equation (2) gives P(E_j complement)<=gamma^(m_j), hence P(G complement)<=min(1,sum_j gamma^(m_j)). A diameter-only application of (1) gives excess at most min(1,sum_j rho_j/2) times that failure bound.

A sharper bound avoids requiring every phase hit. At any x, Q_H averages exactly the hit coordinates and holds each missing coordinate at its observed value. Symmetrizing one missing coordinate changes the first probability by at most rho_j/4: the two branch logits differ by 2rho_j, sigmoid is 1/4-Lipschitz, and a midpoint is half the branch gap. This estimate remains valid after averaging any other coordinates. Telescoping over missing coordinates yields

  TV(M(Z(x)),Q_H(x)) <= sum_j (rho_j/4)1_(E_j complement),
  R_P(M) <= R_P(Q_ref)+sum_j (rho_j/4)gamma^(m_j),
  R_P(M) <= R_P(Q_phys)+zeta_h+sum_j (rho_j/4)gamma^(m_j). (3)

The last line is conditional on a proved physical uniform comparison for this r-phase reference. It is not evidence of such a compilation.

An alternative cheap suffix rule is q_0(1|z)=sigmoid(d(z)). Let independent uniform signs epsilon_j define U=sum_j rho_j epsilon_j. Since E U=0, E U^2=sum_j rho_j^2 and |sigmoid''|<=1/4, Taylor's theorem gives

  TV(M(z),q_0(z)) <= (1/8)sum_j rho_j^2.                 (4)

Therefore the original separately compiled one-head baseline for the SAME d, with error zeta_b, obeys the conditional comparison

  R_P(Q_base) <= R_P(Q_phys)+zeta_h+zeta_b
                +sum_j (rho_j/4)gamma^(m_j)
                +(1/8)sum_j rho_j^2.                  (5)

Unlike enumerating M, using q_0 does not require 2^r branch evaluations. The price is the explicitly displayed quadratic amplitude term. If total variance sum rho_j^2 is large it need not be small. No sourcewise multiplicative ratio is inferred from these additive bounds.

## 5. Resource ledger and model boundary

Under aligned AA/BB ownership, Alice transmits exactly b/2 suffix bits in public order; Bob reconstructs Z and evaluates the public suffix rule. For general alignment at most b bits suffice. Group size does not multiply communication because phases and original prefix are never transmitted. This is worst-case deterministic one-way bit communication, with no real-valued transmissions or free silence/timing channel.

For a general finite phase table, evaluation costs C_M(b,|A|), not automatically O(b). A direct algorithm computes the suffix once, then enumerates |A| branches with total cost C_Z(b)+sum_a C_q(a)+O(|A|) vector arithmetic; public group/phase description size must be added to any parameter ledger. If only a group-indexed branch description is supplied, the naive sum has h terms and may repeat phases; no free orbit reduction is assumed. The selection-and-rewrite proof maps can be implemented by scanning banks, but Q_H still invokes the original reference up to h times and is not claimed cheap.

For the explicit logistic example, enumerate 2^r sign vectors. Compute d once, compute each signed sum in O(r) arithmetic operations, and evaluate one sigmoid per branch. This gives O(C_d(b)+r2^r) arithmetic work and 2^r sigmoid evaluations, using streaming accumulation and O(r) amplitude storage, in addition to the suffix and evaluator workspace. Gray-code reuse can lower arithmetic overhead but is not needed for this bound. Amplitude/phase descriptions cost at least the supplied description of r amplitudes and zone boundaries. If r grows, exponential local work remains real. The q_0 alternative requires only C_d(b) and one sigmoid, with error (4).

For the imported d, the prior symbolic ledger is O_c(b) exact-real local primitive work plus sigmoid, constant-many O(log b)-bit count registers, and a one-head physical baseline with width O_c(1), depth O_c(log N+b), per-coefficient description O_c(log N+b), untied total description O_c((log N+b)^2). These baseline bounds are inherited only for that same d and its separately correct PreLN compilation. Its physical all-row work still includes N+1 rows and the useful dense head, O(N^2+ND) when zero heads are skipped; constant width is not constant total memory/work.

No multi-phase physical width, depth, compiler precision, useful-head count, parameter-description or finite-arithmetic theorem is established here. Neither an average of 2^r softmax outputs nor deleting nuisance banks is automatically legal inside the frozen ordinary-softmax full-feature PreLN architecture. Equation (5) uses the already separately compiled baseline and assumes a proved new hard-family approximation if such a family is later supplied. Full-feature LN coupling is not ignored.

## 6. Failed routes and precise limits

- A measure-preserving rewrite need not change any nuisance, and a nuisance-flipping rewrite need not preserve Markov likelihood. Both certificates are essential.
- The shorter five-bit signed-kernel paths 11000 and 01100 are not substituted for a local source-measure-preserving permutation: their first two bits differ, so cross-boundary triple counts can change. Signed cancellation and exact permutation averaging are different mechanisms.
- Merely averaging logits does not equal M. The only permission to replace M by q_0 here is the paid Taylor error (4).
- Transitivity cannot be dropped: different phase orbits can have different means depending on unrevealed prefix information. An orbit label must be suffix-computable, or this route does not yield a suffix predictor.
- Independent block occurrences are not assumed; the failure bound is conditional minorization. Zero transition bounds preserve exact orbit domination but remove useful exponential decay.
- Repeating the original phase r times would not create r independent group coordinates. The reset-zone definition and separate phase-flip proof are what establish the multi-phase example.
- If r grows with N with balanced m_j roughly (N-b)/(8r), the union bound scales as r exp(-a_c(N-b)/r), not exp(-a_c(N-b)) with a uniform constant. The sharper excess scales with the amplitudes but still has this zone-length deterioration.
- The companion UNIVERSAL_REWRITE_CONSERVATION.candidate.v1.md proves that preservation of every source with arbitrary initial law and independent kernel rows ranging over an open interior forces any deterministic bijection to preserve the initial pair and all triple counts. Thus universal rewrite groups cannot mix the entire suffix fiber, whose histories can have different total counts. Output algebra is indispensable. This necessity statement is not asserted for the stationary-only source class, and is not a task-risk lower bound.
- No architecture-preserving universal Rao-Blackwellization, minimax improvement, new output-simulation lower, necessity of the criterion, or generic task-risk/depth frontier follows.

## 7. Read provenance and status

Read in full:
- UNIVERSAL_REWRITE_CONSERVATION.candidate.v1.md: necessity of Markov-type conservation under arbitrary initial laws, and the consequent obstruction to unrestricted suffix-fiber mixing.
- ../task_oriented_simulation_20261106/LOCAL_TYPE_INVOLUTION_CERTIFICATE.candidate.v2.md: exact eight-word local type-preserving involution, prefix-domain/empty-event conventions, original physical-scope distinctions.
- ../task_oriented_simulation_20261106/SYMMETRIC_QUADRATIC_NUISANCE_REMOVAL.candidate.v1.md: source contract, signed-versus-permutation distinction, AA/BB suffix costs, midpoint-to-baseline comparison, inherited separate PreLN compiler ledger.

New in this note: the finite-group sufficient criterion; local regular-word-library construction; a finite-state equivariance check; r reset-zone phase example; coordinate-weighted exceptional bound; variance-based baseline comparison; explicit group-size cost ledger. All new mathematical claims are symbolic proofs. No finite enumeration, scientific test, execution or independent review has yet checked them. The files above are primary provenance for inherited statements; their downstream neural compilation dependencies are not independently re-read or re-proved here.
