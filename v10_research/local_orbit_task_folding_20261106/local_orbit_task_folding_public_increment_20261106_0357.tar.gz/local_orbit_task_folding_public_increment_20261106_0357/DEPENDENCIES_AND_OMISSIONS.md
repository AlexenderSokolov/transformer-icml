# Dependencies and omissions

All 30 available source files are included unchanged. Report/body versions, old and corrected candidates, failed routes, audits, scripts and historical QA remain. There is no full report v1 in this source snapshot; body v1 is preserved. No missing version is invented. The original augmented candidate snapshot embedded in historical report v2 is additionally extracted without alteration and explicitly not substituted for current candidate v1.

External dependencies remain OPEN: earlier task-risk replacement equivalence; local Markov-type and symmetric quadratic nuisance certificates; prior suffix estimators and empirical transition risk bounds; actual positive-epsilon PreLN/ordinary-softmax baseline and compiler; source/sample-floor and communication prerequisites; primary literature comparisons. Original candidate references identify their scope but do not certify a complete transitive proof graph or supply the external files.

Not included: third-party paper full texts, external dependency corpus, absent numerical/training/multiphase physical runs, unavailable screenshots/visual acceptance, or missing earlier v10 records. Appendix hashes prove exact text identity only. Historical report v2 binds its old embedded snapshot, whereas final v3 binds the currently preserved standalone versions.
