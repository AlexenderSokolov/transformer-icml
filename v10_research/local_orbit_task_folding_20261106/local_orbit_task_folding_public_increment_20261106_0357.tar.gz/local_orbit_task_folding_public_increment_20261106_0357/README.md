# Local orbit task folding: public research increment

All 30 available source files are preserved byte-for-byte, including all candidate versions, failures, scoped audits, report/body versions, scripts and QA. No original was overwritten and no GitHub action occurred. Open materials/RESEARCH_REPORT.zh.v3.html directly for the final report with 14 exact local appendices.

## Historical report v2 binding caveat

Historical report v2 is retained unchanged. It embedded a then-augmented candidate under INVARIANCE_DOES_NOT_FORCE_SUFFIX_DOMINATION.candidate.v1.md, including section 7. The source v1 was subsequently restored to its original reviewed bytes and section 7 placed in separate candidate v2. Therefore report v2's historical bindings must not be represented as matching the current standalone v1. The historical embedded snapshot is preserved in the unchanged report and additionally extracted under historical_embedded/ with its own hash in PACKAGING_QA. Final report v3 embeds both current versions correctly. Historical QA remains historical evidence, not a current validation of all standalone files. Run neither old builders nor checkers against the frozen package.

## Scientific conditions and boundaries

Finite-group local rewriting yields sourcewise task-risk folding only under the declared source- and target-preservation, high-probability phase-transitivity and suffix-computable orbit-barycenter hypotheses. Probability preservation alone does not supply a suffix-computable barycenter. Universal source-preserving bijections must preserve the complete Markov type under the stated family allowing arbitrary initial-pair laws and independently varying interior kernel rows; this is not silently a stationary-only assertion.

The explicit r-phase example uses b/2 communication bits but direct evaluation costs 2^r sigmoid evaluations. The exceptional-risk term is bounded by sum_j rho_j(1-2c^8)^(m_j)/4. Replacing the phase mixture by one sigmoid pays an additional sum_j rho_j^2/8. Small communication must not be presented as cheap computation. A new actual multiphase PreLN realization is not proved; comparisons with the existing actual one-read baseline retain their conditions and charges.

Full-count majority and the strengthened empirical-transition estimator show lack of domination by a specified sufficiently short suffix. The separate spin example supplies the zero-communication obstruction. The empirical-transition estimator retains inherited O_c(N^-1/2) risk over the full interior order-two class. These statistical reference examples are not lower bounds against arbitrary cheap interactive communication, and do not establish a general resource frontier. Group averaging, Rao-Blackwellization and statistical rates are not claimed newly invented.

## Status, rights and use

Only symbolic proofs and document checks were performed: no mathematical enumeration, numerical diagnostic, model execution, parameter generation or training. Visual acceptance is NOT COMPLETED. No floating-point reliability, formal verification, external peer review or exhaustive novelty certification is claimed. General T1/T2 resource questions and external proof dependency closure remain OPEN. This is not recovery of a complete v10 corpus.

Privacy/copyright inspection found no secrets, sensitive personal information, private conversations or machine paths requiring redaction. Literature is cited/summarized, not full-text redistributed. No new license is granted; this is not legal clearance.

SOURCE_DERIVATION_MAP.json maps every unchanged source/public file. PACKAGING_QA.json records fresh byte and binding checks separately from immutable historical QA. Independent review and historical audit index are in independent_review/. SHA256SUMS and python verify_package.py supply read-only integrity checks. Existing scripts write documents and should only run in a disposable copy, with the historical v2 mismatch understood. Relative dependencies retain original-source meaning and may not resolve after relocation.
