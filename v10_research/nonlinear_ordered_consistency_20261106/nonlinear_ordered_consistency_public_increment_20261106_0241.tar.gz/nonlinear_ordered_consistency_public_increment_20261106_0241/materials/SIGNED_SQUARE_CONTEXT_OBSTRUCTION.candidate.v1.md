# Sign-erasing square bottleneck cannot predict the lag-two witness consistently

6 November 2026 UTC. Candidate v1. Elementary symmetry obstruction, not a new statistical minimax theorem. This states exactly why the positive ordered code in the constructive example cannot be replaced by an arbitrary signed prefix square.

## Contract

Let X_t in {-1,+1} be the stationary homogeneous second-order source with initial pair uniform and independent, and
 P_theta(X_t=x | X_(t-2)=a, X_(t-1)=b)=(1+theta a x)/2,
where 0<theta<=1-2c. Thus it belongs to P_c, and its actual next-plus probability is p_theta(x)=1/2+theta x_(N-1)/2. The law of the length-N history is invariant under simultaneously negating every symbol: its density is (1/4) product_(t=3)^N (1+theta x_(t-2)x_t)/2.

Suppose a predictor's complete data-dependent input to its terminal decoder is invariant under this global negation. A sufficient example is any collection of squared homogeneous PUBLIC linear forms (sum_j a_(ij) X_j)^2, followed by arbitrary deterministic computations, and public constants. No unaccounted raw-symbol, position-symbol, signed anchor or previous unsquared-value channel may enter the terminal decoder. Positions alone are harmless. Input-dependent coefficients or nonzero additive offsets need a new symmetry check.

## Risk lower bound

Such a predictor q satisfies q(x)=q(-x). Write q for its plus probability. For every paired histories x,-x,
 |q(x)-p_theta(x)|+|q(-x)-p_theta(-x)|
 >= |p_theta(x)-p_theta(-x)|=theta.
By the invariant history law, E TV(q,p_theta)>=theta/2, for every N>=2. The constant predictor 1/2 attains theta/2 on this source, so this fixed-source symmetry bound is sharp.

If q is only approximately invariant, define A=E |q(X)-q(-X)|. The same triangle inequality gives
 E TV(q,p_theta)>=(theta-A)/2,
with the lower bound clipped at zero. In particular if a physical output is uniformly within zeta of an exactly invariant reference, A<=2zeta and its risk is at least theta/2-zeta. This conclusion needs an end-to-end approximation guarantee; we do not assume physical PreLN preserves the logical sign symmetry internally.

## Application and limits

A pure square of a signed packed suffix has this obstruction if the decoder sees no unsquared channel. The positive code d in {1,2} is an affine encoding of signs, and its squared value includes cross terms that distinguish global sign reversal. The constructive pure-square decoder therefore lies outside the obstruction. It really recovers the terminal ordered pair rather than estimating the marginal mean.

This is one explicit loss-of-context counterexample, not a characterization of every nonlinear update. It does not rule out injective nonlinear positive coding, biased features, additional signed channels, multiple statistics that break the symmetry, or an appropriate known kernel with different invariance. It does not establish a communication lower bound. No empirical experiment or training is needed for the argument.
