# Independent exact-file audit: pure-square radix revision 2

6 November 2026 UTC. Verdict: PASS in the stated exact-real, sufficiently large fixed-envelope contract. This audit supersedes the v1 audit's version/provenance status, not its preserved mathematical derivations.

Reviewed source: `PURE_SQUARE_RADIX.candidate.v2.md`.
SHA-256: `3d7b4ebd319f296618e08309b6c14ac8f8d507a8cd6294014d484696a561b7cd`.

The complete v1 proof audit is retained in `INDEPENDENT_PURE_SQUARE_RADIX_AUDIT.v1.md`, SHA-256 `81af20c928dc7ed3e53075bf9d08cea0a8e5da7fc5c86373d38dc68876222a11`. The exact source diff was inspected. No recurrence, tolerance, risk, depth, or compiler step from the mathematically accepted v1 has changed.

## Revision checks

1. The exact counting onehots are now explicit: z_1=1-C_2, z_2=C_2. The zero branch becomes the all-default word for counting but remains h=P=D=Dsq=0 for residual decoding. This makes the all-row count-lattice premise explicit.
2. The floor is explicitly the largest negative power of two a<=c. Thus the inherited finite coefficient-description claim does not require storing an arbitrary exact real c.
3. The new implemented-cut mixed-difference proof is correct. Expanding Y in its first two digit coordinates gives D_12 Y=2B^-3 W_2. Since h_1=BY/W_1, its mixed difference is (2/B^2)(W_2/W_1). The already proved W_1/W_2<=43/18 gives 36/(43B^2). Uniform error e_1 over the four histories changes a mixed difference by at most 4e_1. For b>=4, (7)-(8) give e_1 <=3 eta_0/(64*49^b), so this lower bound is strictly positive by a large margin. This certifies the actual finite-dyadic logical h_hat_1 cut, not only an ideal square oracle.
4. The fixed positive scale and nonadditivity are correctly scoped to logical coordinates. The source explicitly disclaims a horizon-independent amplitude or mixed difference for unscaled physical coordinates after multiplication by eta. Its physical result remains the uniform compiled-output approximation.
5. Section 7 now identifies the finite enumeration as author-run, not an independent audit, and names the preserved executed command, readable equivalent, stdout, and provenance record. Read-only inspection confirms that the recorded code enumerates 16, 16 and 256 suffixes and checks the ideal exact-rational recurrence; it does not execute the square approximant, finite dyadic perturbations, classifier ramps, count/readout circuit, or normalized Transformer. The revised claims preserve this distinction and do not use the enumeration to prove those missing components.

The changed source resolves the v1 clarity issues. `PRIOR_WORK_AND_FAILED_ROUTES.v2.md` corrects the package's old blanket no-experiment statement, retaining the earlier text as history. No failed mathematical route has been silently promoted or erased.

All mathematical conclusions remain as in the v1 audit: exact suffix recovery and legal all-row words, useful original/ablation paths, the inherited order-two risk plus 2zeta, O_c(log N+b) paid depth, fixed per-row width and complete norm envelope, growing finite parameter precision, and terminal communication by output equivalence or at most b suffix bits. These do not establish a new statistical rate, a generic nonlinear collapse, a Taylor simulator for this energy, a trained realization, or finite-arithmetic robustness.

This auditor used source reading and analytic derivation only, did not rerun the author's computation, and made no author-source edit or upload.
