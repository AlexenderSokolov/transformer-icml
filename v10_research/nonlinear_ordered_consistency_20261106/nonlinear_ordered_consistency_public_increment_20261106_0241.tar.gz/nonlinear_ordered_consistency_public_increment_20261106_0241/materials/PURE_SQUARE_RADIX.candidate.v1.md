# Pure-square causal memory with a bounded quadratic radix decoder

6 November 2026 UTC. Analytical candidate v1, awaiting independent audit. This is an alternative transport/decoding construction for the EXISTING suffix estimator, not a new estimator, rate, minimum head count, training method, or priority claim. The nonlinear middle cut is not claimed additive or Taylor-collapsible. The final logical output is exactly the old additive-code estimator by decoded-word equivalence.

## 1. Frozen contract and first two reads

Use the contract and paid source-position program of `../ordered_causal_memory_20261106/TWO_READ_ORDERED_SUFFIX.candidate.v3.md`: N>=6, T=N+1, power-of-two 4<=b<=N-2, B=16, s=N-b+1, binary digits d_j in {1,2}, and a synthetic zero-symbol terminal. Every raw row is supplied. Let

    C_k = sum_{j=1}^k d_j B^(-j),  C_0=0,
    k(i)=min(i-s+1,b) for s<=i<=T.

The existing paid bounded-width geometric position program writes v_i=d_(i-s+1) B^(-(i-s+1)) on s<=i<=N and zero elsewhere. Its depth is O(log N+b). First zero-score scalar full-prefix read:

    r_i = (1/i) sum_{l<=i} v_l.

Multiply r_i by the PUBLIC INTEGER s with paid bounded doublings and one final dyadic factor in [1,2). This gives u_i=0 before s and

    u_i=(s/i) C_(k(i)),  0<=u_i<=2/15.

All intermediate amplification states are bounded by 2/15. Apply a paid dyadic tent-square circuit f_L on [0,1], with f_L(0)=0 exactly and uniform error at most nu. The square is the ONLY value sent into read 2; there is no linear bypass into that head. Read 2 is another scalar zero-score full-prefix average. At the ideal-square comparator its terminal answer is

    z_T = Y/T,
    Y = sum_{i=s}^T w_i C_(k(i))^2,  w_i=(s/i)^2.       (1)

The terminal synthetic self-row i=T is included. The actual logical circuit uses f_L, not an exact multiplication primitive. The final decoder uses only the second read's terminal-gated output and public parameters, not any retained first-read row or raw symbol. Raw shadows may be retained solely until the synthetic marker gate.

Since second-read answers lie in [0,1], gate them with the exact synthetic marker e_i by ReLU(z_i+e_i-1). Every nonterminal row then has EXACT zero decoder input. The square approximation can be clipped to [0,1], fixing zero and not increasing its error.

## 2. Exact quadratic radix identity

Define public tails

    W_k = sum_{i=s+k-1}^T w_i,  1<=k<=b.

The last tail W_b includes BOTH i=N and i=T. Suppose digits before k have been recovered, and put

    P_(k-1)=sum_{j<k}d_j B^(-j),
    J_(k-1)=sum_{j<k} W_j [2 P_(j-1) d_j B^(-j)+d_j^2 B^(-2j)].

Telescoping C_j^2-C_(j-1)^2 proves the exact identity

    Y=sum_{j=1}^b W_j [2 P_(j-1) d_j B^(-j)+d_j^2 B^(-2j)].  (2)

Do NOT store J or calculate a fresh square at each round. Instead maintain the normalized residual

    h_k=B^k (Y-J_(k-1))/W_k.

For i>=s+k-1, write C_(k(i))=P_(k-1)+B^(-k)t_i. Then

    d_k<=t_i<=d_k+2/15,
    h_k=sum_{i=s+k-1}^T (w_i/W_k)
                 [2P_(k-1)t_i+B^(-k)t_i^2].             (3)

After correctly recovering d_k, update

    h_(k+1)=clip(q_k [h_k-2P_(k-1)d_k-d_k^2 B^(-k)],0,1),
    q_k=B W_k/W_(k+1),
    P_k=P_(k-1)+d_k B^(-k),                            (4)

for k<b. The clip never alters the exact reference. Initial h_1 is obtained from the terminal-gated z by scaling R=BT/W_1. As W_1>=s^2(b+1)/T^2, 16<=R<=16T^3/[s^2(b+1)]=O(N^3); R is implemented in O(log N) bounded doublings with clip [0,1], followed by one bounded factor. No growing matrix is used.

For i=s+k-1>=3 and k<b, W_(k+1) includes the next two rows. Therefore

    W_k/W_(k+1) <= 1+(i+2)^2/(2i^2) <=43/18<3,
    16<=q_k<48.                                       (5)

All q_k are public. Exact harmonic-square rationals are NOT embedded for free; Section 4 specifies finite dyadic replacements.

## 3. Fixed-margin classifiers and no paid generic products in the decoder

At k=1, P_0=0, so the exact digit intervals from (3) are

    d_1=1: h_1 in [1/16,289/3600],
    d_1=2: h_1 in [1/4,64/225].                        (6)

Take a ReLU plateau classifier C_1 equal to one on [3/64,3/32] with support [1/32,1/8], and C_2 equal to one on [15/64,5/16] with support [7/32,3/8]. Each is zero outside its support and has fixed bounded ramps. These disjoint supports also make both outputs zero at h_1=0.

At k>=2, P=P_(k-1) satisfies 1/16<=P<2/15. Classify y_k=h_k-3P. For digit 1,

    y_k <= -(11/15)P+B^(-k)(17/15)^2
          <= -11/240+289/57600 = -2351/57600 < -0.0408,
    y_k >= -3P > -2/5.

For digit 2,

    y_k >= P+4B^(-k) >=1/16.

Also every exact h_k lies in [0,1]: h_1<=64/225, while for k>=2,

    h_k<=2(2/15)(32/15)+B^(-2)(32/15)^2=44/75<1.

Thus digit-2 y_k<=44/75. Take later C_1 equal to one on [-1/2,-1/32] with support [-3/4,-1/64], and C_2 equal to one on [1/32,3/4] with support [1/64,1]. They both vanish on a neighborhood of y=0. All exact true-digit intervals have margin greater than 1/1000 inside the required plateaus.

Set D=C_1+2C_2 and Dsq=C_1+4C_2. When these are exact onehots, D=d and Dsq=d^2. As P in [0,1], the fixed ReLU gate

    G(P,C)=ReLU(P+C-1)

equals P*C for C in {0,1}. Hence P*d=G(P,C_1)+2G(P,C_2), and every operation in (4) is a constant-size bounded affine/ReLU circuit. There is NO uncharged multiplication and no O(b)-precision product circuit per decoded digit. P updates use the exact dyadic coefficients B^(-k), so P remains exact as long as the classified digits agree.

On every nonterminal row, h=P=0 initially, both classifiers give zero, and equations (4) preserve h=P=0. At the terminal, ablating either read also yields this exact zero branch because f_L(0)=0. For counting ONLY, digit zero is converted into default symbol 1, exactly as in the prior construction. It is not substituted by 1 in the residual or P update. This distinction prevents the zero branch from acquiring fictitious packed digits. Exact nonterminal/default rows have legal all-default b-words for the imported counting and divider program.

## 4. Finite square precision and dyadic coefficient robustness

Put eta_0=1/1000. Let every q_k and the final bounded factor gamma in R=2^m gamma be replaced by dyadics to absolute accuracy delta, with gamma_hat in [1,2] and q_hat in [0,49]. Choose

    delta <= eta_0 / [16 b 49^b],
    nu <= eta_0 s^2 / [64 B T^2 49^b].                 (7)

The first multiplication by s is exact with dyadic coefficients. Only b+1 rows have nonzero u_i, and f_L(0)=0. Consequently the square error in z_T is at most (b+1)nu/T. Since W_1>=s^2(b+1)/T^2 and gamma_hat/gamma<=2, the initial decoded-code error is conservatively bounded by

    e_1 <= 2 B T^2 nu/s^2 + delta.                     (8)

The final-factor rounding term is bounded by delta because the exact initial code is less than one. Intermediate clipping is nonexpansive relative to the exact amplification path, which stays in [0,1].

Assume classified digits agree through round k. Then P and the known subtraction in (4) are exact. Clipping is nonexpansive relative to exact h_(k+1), and q_hat<=49, giving

    e_(k+1)<=49 e_k+delta.                            (9)

Here the exact pre-radix residual is at most one; the tighter bound 1/16 is unnecessary. From (7)-(9),

    max_{k<=b} e_k <=49^(b-1)(e_1+b delta)<eta_0.

The plateau margins in Section 3 then make every classified digit EXACT, closing the induction. The exact zero branch is also preserved by all dyadic replacements. Thus the finite-coefficient affine/ReLU/square-approximant reference returns precisely the original suffix word on every binary history and all-default words at every other physical row.

The tent-square interpolant can attain nu with L=O(log(1/nu))=O(log N+b) bounded stages and constant width. Equation (7) requires only O(b+log b) fractional bits for the q_k and gamma replacements. Position encoding, exact s multiplication, dyadic B^(-k), and the square approximant have per-coefficient description O(log N+b). This is an exact-real execution theorem with finite parameter descriptions, NOT a floating-point/edgewise rounding theorem.

If the optional simplification b<=N/2 is imposed, s/T>=3/7 and W_1>=(9/49)(b+1), so square accuracy O(49^(-b)) already suffices. This simplification is NOT required for (7) or the stated general construction.

## 5. Statistics, terminal folding, and substantive nonlinear signal

Feed the exact recovered word to the prior paid sequential triple counter and restoring divider with G=b. It recovers the ordered final pair and the established suffix transition estimate q. The inherited bound is exactly the old one:

    sup_(P,mu) E TV(q,p_actual)
       <=13 sqrt(32/(b-1))+1/b.                        (10)

There is no improved estimation theorem here. Equality of decoded words proves pointwise equality of q to the old one-read and ordered-two-read additive-code estimators on every Boolean history. Therefore their existing PUBLIC ADDITIVE terminal-output simulator can be used unchanged for q. This is semantic equivalence of final outputs. It is NOT additive reconstruction of Y, approximation of intermediate nonterminal square rows, or the raw-prefix Taylor theorem.

Alternatively Alice can send precisely her owned selected-suffix bits, using at most b bits, and Bob evaluates the public logical estimator. This simple exact protocol is independent of the cut and source and does not claim a new communication result.

The square is evaluated on active u_i at a fixed positive logical scale, not r_i=O(1/N): when b<=N/2,

    u_i>=(s/T)/16>=3/112 for every active row,
    Y/(b+1)>=9/(49*256).

The only second-read value path is u_i^2. With either read ablated the complete word becomes all-default; an all-digit-2 suffix yields the old opposite estimate and its fixed output separation. Thus both reads remain useful in this implementation. This is not a lower bound or a claim that two reads are necessary, because the old one-read predictor already suffices. Nor is nonlinearity itself necessary for the statistical task: the final function deliberately equals the old estimator.

For b=o(N), let U=T^(-1)sum_i u_i. Then U<=2(b+1)/(15T), whereas the squared contribution at the energy normalization is bounded below as above. The constant-prefix-mean square surrogate would satisfy

    [T/(b+1)] U^2 <=4(b+1)/(225T) ->0.

Thus after this normalization the square signal cannot be dismissed as a vanishing Taylor remainder around the global mean. This is a boundary observation, not a lower bound for every nonlinear simulator. In particular it does not contradict the different raw-sign prefix-average Taylor theorem.

## 6. Positive-epsilon PreLN and complete resource ledger

Use the already-reviewed `../ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md` mechanism on THIS finite-dyadic reference program. All reference primitives above have one fixed gain/state/matrix/full-bias envelope: square tent slopes, classifier slopes, radix at most 49, conditional gates, bounded doubling, and existing count/division routines. Choose one common widened tube for the original program and both exact all-default single-read ablations. Physical perturbations need not stay on the digit/count lattice; the actual continuous primitive circuits propagate their errors.

For a fixed interior floor c, append the old floor/log readout with zeta=min(1/1000,1/(100b^2)). Include ALL scaled-logit copies, norm-padding primitives, and scratch clears in the prepared reference length m BEFORE choosing small amplitude. Choose padding/restoration/complete-vector tolerances as fixed allowed dyadic multiples of zeta; then m=O_c(log N+b). Paired small-amplitude states h=eta z have both zero-score attention local errors O(eta^2), including the data-dependent full-feature normalization factors. With the common max-row tube, the full prepared recurrence is

    e_l<=L_0 e_(l-1)+C eta^2,
    e_m<=C' eta^2 L_0^m.

Choose eta=2^(-M), M=O_c(m+log(1/zeta)), so the FULL prepared-vector error meets the imported output-restoration condition. Apply its paid bounded restoration, final LN, and ordinary affine vocabulary head/softmax. The gain-two reparameterization gives EVERY LN epsilon=1, gain=2, shift=0. This is an explicit reuse of that compiler, contingent on its accepted dependencies and independent checking of this enlarged fixed tube; it is not a new compiler or a mandatory-PostLN claim.

The physical terminal output differs from the logical floor/log reference by at most zeta uniformly over histories and both single-read ablations. Flooring does not worsen binary prediction risk for kernels with both next-symbol probabilities at least c. The old log approximation contributes another zeta, giving

    sup E TV(Q_phys,p_actual)
       <=13 sqrt(32/(b-1))+1/b+2 zeta.                 (11)

A common output tolerance preserves the old fixed positive separation between the original all-digit-2 word and either all-default ablation. Final-output folding is to the same old additive-code estimator INCLUDING the identical floor/log circuit; physical PreLN only has the proven approximation, not an exact additive intermediate identity.

Resource ledger:
- Exactly two useful full-prefix scalar zero-score attention invocations; no extra memory read, pair/triple input, suffix crop, supplied counts, or external predictor.
- Constant width, including raw shadows until gating, two fresh head destinations, square scratch, P/h/classifier registers, and the existing lag/count/readout banks.
- Paid reference depth and physical PreLN depth O_c(log N+b). There is one O(log N+b) square approximation, NOT one per digit; radix decoding is O(b).
- One sufficiently large fixed c-dependent envelope for complete reachable states, matrices, full biases, primitive gains, and LN gains. No unchecked identification with a predetermined numerical M_K.
- Per-coefficient binary description O_c(log N+b); at constant width and depth, untied total parameter description O_c((log N+b)^2).
- T=N+1 rows and therefore O(N) distributed state despite constant per-row width.
- Useful-head/local work O(N^2+N D) if dummy zero-attention slots are skipped; dense evaluation of every dummy attention slot costs O(N^2 D).
- With b=Theta(log N), depth remains O_c(log N) and risk O(1/sqrt(log N)), precisely the OLD orders.
- Exact-real arithmetic and finite coefficient descriptions only. No executed model, training, parameter-generation runtime, or floating-point implementation guarantee.

## 7. Checks and limits

A small independent exact-rational sanity check enumerated every binary suffix for (N,b)=(6,4),(8,4),(16,8). All digits were recovered by (2)-(4), including the synthetic self-row. The largest observed radix gains were 29.282, 27.675, and 25.654, below the proved 48 bound; digit-1 later y maxima were -0.04850, -0.04762, and -0.04471, below the proved -0.0408. These finite checks do not replace the proof and are NOT transformer training or numerical model execution.

Main dependencies remain the existing bounded geometric position program, exact ordered count/readout estimator, and reviewed positive-epsilon PreLN output compiler. What is new locally is only the explicit positive-code square transport and constant-work quadratic radix identity. No literature novelty is asserted. A smooth nonlinearity on arbitrary signed first-read values is not covered: squaring can lose signs, and neither this positive-code decoder nor the raw-prefix two-statistic Taylor argument applies automatically.
