# Independent final report text, privacy, and static-source audit

6 November 2026 UTC. Verdict: PASS for the frozen report below. This is a content, privacy, source-binding, and static-HTML audit, not visual rendering, formal verification, external peer review, or scientific reproduction. The report was not edited by this auditor.

Authoritative reviewed report: `RESEARCH_REPORT.zh.v2.html`.
Size: 110,813 bytes.
SHA-256: `20835c1a436a27df336ed6826a7a782afb474866e0e56246d16bdbf5371709d2`.

Related frozen files:
- `REPORT_BODY.zh.v2.html`: `42115dacb8a6698484ecad632430b29708af33d5f74bf7fc0143df8fdd6068ab`.
- `REPORT_SOURCE_BINDINGS.v2.json`: `6b77292d19699ee600b638ac86b8fb7c4ba5a632f176ce12238cbba27f7379b7`.
- `REPORT_HTML_QA.v2.json`: `2aac789512c1f133eda707de2d0af1437e4da25d66e3ae5eee0f67b8621dee6b`.

The preserved report v1 was also inspected at hash `b68d9f2778bc76a3dc17e7cc1825a27128f2538e58939ebea9fa346beaff913c`. The final v2 adds the exact executed command and the superseded prior-work disclosure to its appendices, while retaining v1 unchanged. This audit certifies v2, not any later altered file.

## 1. Mathematical text and scientific scope

The Chinese narrative matches the accepted exact-version proofs. It uses the sufficient b<=N/2 subdomain for fixed positive logical energy, while the underlying main radix proof covers the broader stated domain. It distinguishes the ideal energy, the implemented finite-dyadic logical code, and the eta-scaled physical states.

The initial code's strictly positive mixed difference is tied to its proved uniform error bound. No horizon-independent magnitude is asserted for raw physical hidden coordinates. The physical conclusion uses full prepared-vector error, not an exact square or additive identity for normalized K/V.

The main depth is O_c(log N+b), with the inherited O((log N)^(-1/2)) risk at b of logarithmic order. The old endpoint-polynomial O(log N+b^2) candidate is clearly labeled as a preserved slower candidate rather than the final theorem. The original estimator, risk, count/readout machinery, and normalization compiler are explicitly inherited. No new rate, minimum number of reads, training method, or novelty certification is claimed.

The mean-centered energy remainder is explicitly different from final prediction error. Its positive lower bound is not used as a communication lower. The cheap final-output simulation is justified by exact estimator equality or short suffix support, with the extra physical approximation error stated.

The sign-erasing square theorem is the fixed stationary lag-two symmetry result, with sharp lower bound theta/2 and the approximate physical extension theta/2-zeta. Its complete-input restriction is retained. The appendix specifies 0<theta<=1-2c. Repeating that range in the Chinese summary would be optional clarity, not a mathematical correction, since the report's common source contract and complete bound proof already provide it.

The resource ledger retains constant per-row width versus O(N) distributed state, per-coefficient versus total untied descriptions, and useful-head/local versus all-dummy-slot dense work. It does not infer floating-point robustness from finite coefficient descriptions.

## 2. Provenance and failed-version handling

The report states that an author-run exact-rational recurrence enumeration actually occurred over 16+16+256=288 suffixes. It includes the original command, readable script, captured stdout, and disclosure. It distinguishes this ideal recurrence check from square approximation, finite parameter perturbations, classifier implementation, the full count/readout program, complete Transformer execution, training, parameter generation, and finite-arithmetic validation.

The corrected blanket no-experiment statement and the old radix wording remain accessible in explicitly historical appendices. Current prose and audits identify the correction, rather than silently replacing the record. The author-run check is not called an independent audit in the current proof; the preserved older wording is clearly versioned. The independent mathematical audits do not rely on its finite cases.

The report accurately says literature comparisons reuse prior recorded primary inspections. This audit did not fetch those external papers again. The unresolved general nonlinear-memory, optimality, training, source-average lower-bound, and mandatory-PostLN questions remain open.

The current `README.v2.md` points to this authoritative v2 report and its matching hash; the old README is retained as history.

## 3. Independent static and exact-source checks

An independent read-only HTML-parser/hash check, separate from the supplied checker, established:
- UTF-8 content is readable and the reported byte size and SHA-256 match.
- All 16 appendix bodies, after HTML entity decoding, equal the corresponding source files exactly, including whitespace and complete text.
- Every appendix file hash matches `REPORT_SOURCE_BINDINGS.v2.json`; no stale source binding was found.
- Eight section IDs are unique, and every internal fragment link resolves.
- Tags are properly nested and closed in the static parse.
- No active script, iframe, form, object, embed, event-handler attribute, or external src reference is present.
- The embedded CSS has no external URL or import fetch.
- The only external hyperlinks are the four disclosed public primary-paper URLs. They are links, not automatic resource loads.

The report visibly discloses that visual rendering has not been completed. No browser, screenshot, renderer, or alternate rendering route was invoked in this audit. Static parsing cannot certify typography, layout, or printing behavior.

## 4. Privacy and delivery boundary

Manual reading and targeted static inspection found no credentials, authentication tokens, private cryptographic material, personal sensitive information, private user-message content, internal note contents, or unrelated private-file references in the report. Repository-relative research filenames identify the disclosed mathematical sources and are not private memory links. All code in the appendices is escaped inert text; it is not executed on opening the HTML.

This finding concerns the frozen report's content. It does not authorize publication, upload, repository mutation, document sharing, or new access permissions. None was performed by this auditor.

No remaining correction is required for the reviewed report. This audit remains a separate file so that adding it does not alter the frozen report hash.
