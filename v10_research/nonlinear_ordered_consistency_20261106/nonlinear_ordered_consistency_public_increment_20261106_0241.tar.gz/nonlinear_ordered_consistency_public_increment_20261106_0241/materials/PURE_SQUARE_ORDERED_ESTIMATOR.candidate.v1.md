# Pure-square causal memory with a consistent ordered second-order decoder

6 November 2026 UTC. Candidate v1, not yet independently accepted. This is an architectural compatibility construction using the EXISTING suffix estimator, not a new statistical rate, training result, or optimal attention-depth theorem. All arithmetic is exact-real; bounded dyadic parameter descriptions are separately accounted for.

## 1. Frozen contract

Fix c in (0,1/2), N>=16, and a power of two 4<=b<=N/2. Let T=N+1, s=N-b+1, B=16. Inputs are N binary raw-symbol rows plus one synthetic terminal. No pair, counts, cropped suffix or prefix statistic is supplied. Sources are the common homogeneous binary second-order class P_c; the inherited logical suffix estimator also permits arbitrary initial-pair laws. All parameters depend only on public N,b,c. Use two scalar zero-score full-prefix causal attention invocations. Fixed width includes all work registers and raw shadows. All local operations must be bounded affine/ReLU primitives. The actual target is the previously reviewed epsilon-one, gain-two, zero-shift PreLN model with ordinary vocabulary softmax.

Old dependency: ordered_causal_memory_20261106/TWO_READ_ORDERED_SUFFIX.candidate.v3.md, TWO_READ_PRELN_COMPILATION.candidate.v4.md, and their audits; terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md. The imported estimator has risk R_b=13 sqrt(32/(b-1))+1/b. Nothing below improves that estimator.

## 2. Nonlinear body, without a linear signal bypass

Use the old paid position program to place v_i=d_i B^{-j} at i=s+j-1, j=1,...,b, d_i in {1,2}; other values, including the synthetic input, are zero. Read 1 writes r_t=(1/t)sum_{i<=t}v_i. Multiply by the PUBLIC s in O(log N) bounded doubling/final-factor steps, clipping to [0,1]. No exact state is clipped: u_t=s r_t<=2/(B-1). The only value channel sent into read 2 is an approximation to u_t^2. There is no channel transmitting r_t or u_t through read 2 to the decoder.

Write C_k=sum_{j<=k}d_{s+j-1}B^{-j} and C_{b+1}=C_b. The ideal square-body terminal statistic, after a paid factor T/(b+1), is

 E=sum_{k=1}^{b+1} w_k C_k^2,
 w_k=(s/(s+k-1))^2/(b+1).

The k=b+1 term is the synthetic self and MUST be included. Since s>=N/2 and T=N+1, s/T>=1/3, so

 1/[9(b+1)]<=w_k<=1/(b+1),  0<E<=4/(B-1)^2.

Square is implemented by the established dyadic tent-square interpolant on [0,1]. A later tolerance choice makes the implemented energy uniformly accurate. Terminal marker gating is applied after the second read. No outside-suffix symbol is used in this logical terminal statistic.

The nonlinear body is not a vanishing correction: E>=1/(9B^2). More sharply, representing two suffix digits by d_j=1+x_j, its mixed finite difference at positions j<l is

 D_{jl}E=2 B^{-(j+l)}sum_{k=l}^{b+1}w_k>0.

For j=1,l=2 and b>=4 this is >=8/(45 B^3), independent of N,b. Thus this energy cut has no exact additive token-local representation, and its curvature contribution does not vanish as N grows. This does NOT imply large communication; all its relevant bits lie in a short suffix.

## 3. Lexicographic interval decoder: exact ideal proof

Suppose digits before j have been recovered. Let p=sum_{l<j}d_l B^{-l} and E_past=sum_{k<j}w_k C_k^2. Consider two suffix completions sharing that prefix:
 L: digit j is 1 and every later digit is 2;
 U: digit j is 2 and every later digit is 1.
At every row k>=j, C_k(U)-C_k(L)>=B^{-j}(1-1/(B-1))=(14/15)B^{-j}. Both codes are >=1/B, so their squared difference is >=(28/(15B))B^{-j}. All weights are positive. Consequently

 E(U)-E(L) >= g,
 g=B^{-(b+2)}/[9(b+1)].

This deliberately loose bound holds uniformly over all prefixes and j<=b. Monotonicity of positive codes shows that any actual continuation with digit 1 has E<=E(L), and any continuation with digit 2 has E>=E(U). The midpoint H_j=(E(L)+E(U))/2 therefore classifies digit j with margin at least g/2.

Crucially H_j can be computed in constant workspace. If q_k denotes the publicly specified completion code starting at j, then
 E(completion)=E_past+A_j p^2+2 B_completion p+C_completion,
 A_j=sum_{k>=j}w_k,
 B_completion=sum_{k>=j}w_k q_k,
 C_completion=sum_{k>=j}w_k q_k^2.
All three coefficients are public bounded scalars. Their j-indexed values are parameters, NOT extra input features or data-dependent advice. After classifying digit d_j, update p to p+d_j B^{-j}, and E_past to E_past+w_j p_new^2. Maintain only p,E_past,E plus temporary arithmetic registers and the old count/lag registers. Each recovered digit is immediately fed into the existing exact sequential triple-count and final-pair accumulator. This recovers the ACTUAL ordered suffix, not marginal frequencies.

## 4. Finite parameters and paid approximate arithmetic

Choose eta to be the largest dyadic number not exceeding
 B^{-(b+2)}/[10^5(b+1)^2].
Use dyadic approximations to every bounded public weight/threshold coefficient with error at most eta/100. Coefficients B^{-j} are exact dyadics. Evaluate each bounded square/product in the threshold and past-energy updates with absolute error at most eta/100 using the previously reviewed tent-square/polarization primitives. Each such routine costs O(1+log(1/eta))=O(b+log b) bounded-gain stages at constant width. Exact-real affine addition introduces no execution rounding error.

For the row square choose uniform error nu<=eta/(100T). This costs O(log N+b+log b) stages, not b copies. Approximate the final bounded factor in the paid T/(b+1) scaling so its accumulated output error is <=eta/100; sufficient coefficient error eta/(100T) is used. The resulting terminal energy error is <eta. All unscaled/partly scaled states remain bounded, using clipping on a fixed expanded domain containing the exact targets. The s amplification is public integer/dyadic and exact in this semantics.

Past-energy error grows by at most eta per recovered step. On the correct-digit induction, p is exact, since it is updated using exact dyadic coefficients and exact digit outputs. Endpoint evaluation and energy error together are conservatively <=10(b+1)eta<g/16. Therefore each approximate comparison retains absolute margin >g/4. Implement the comparison using O(log(1/g)) paid clipped doublings followed by a continuous plateau: choose a power of two L>=8/g, form clip(L(Ehat-Hhat),-1,1), then map -1 to digit 1 and +1 to digit 2. Every terminal output is exactly a digit. There is no discontinuous comparator or unbounded weight.

At every nonterminal row force the recovered bit to zero using the preserved exact synthetic marker e_t: for a comparator bit chi in [0,1], use chi-ReLU(chi-e_t). Thus nonterminal rows produce default digit 1 at every step even if their comparisons lie in transition bands. This guarantees the old all-row exact count lattice. The terminal induction proves that the finite dyadic logical network returns EXACTLY the old suffix estimator, for every history.

No hidden table exponential in b is used: there are O(b) bounded coefficients, each requiring O(log N+b+log b) bits. Their rational formulas define a mathematical architecture; parameter-generation computation has not been executed or assigned free runtime. Each of b decoding rounds costs O(b+log b), so the logical depth is D_0=O(log N+b^2), constant width.

## 5. True PreLN/softmax compilation and risk

Apply the accepted TWO_READ_PRELN_COMPILATION v4 argument to THIS fully bounded logical program. It applies because every local stage above is continuous affine/ReLU with a fixed primitive gain, every exact row state is bounded, both reads have zero scores and scalar values, and all-row count validity has been established. Insert all serial fixed-floor logit routines, scaled copies, norm padding, and scratch clears BEFORE defining the complete prepared length m. The added square and comparison stages enlarge m and the fixed tube constants; they may not be omitted.

Take zeta=min{1/1000,1/(100b^2)}. The inherited log routine costs O_c(b), padding costs O_c(log b), and m=O_c(log N+b^2). With a common bounded tube for the original and both single-read ablations, choose the largest permitted dyadic preparation/restoration tolerances proportional to zeta. The established recurrence e_l<=L_0 e_{l-1}+C eta_small^2 then permits eta_small=2^{-M}, M=O_c(m+log(1/zeta)). Both uniform-head local errors are O(eta_small^2) independent of N. The full prepared-vector error, not merely a logit-bank error, is controlled before radial restoration. Reparameterize consuming matrices exactly as v4 to make every LN epsilon=1, gain=2, shift=0. Output ordinary affine vocabulary logits and softmax.

Result, contingent on the cited accepted compiler and new proof review:
 sup_{P in P_c} E TV(Q_phys,p_actual)<=R_b+2zeta.

The inequality uses the old estimator and old fixed-floor argument verbatim. It is consistent for b->infinity. It is NOT a new statistical rate. For b a power of two of order sqrt(log(N+1)), D=O_c(log N) and the inherited risk is O((log N)^(-1/4)), WORSE than the old O((log N)^(-1/2)) available with linear packing and the same depth order. At general b the structural price is quadratic decoding depth.

Both reads are useful in this implementation. Ablating either yields energy zero; each computed threshold corresponds to positive codes and the comparison induction yields the all-default digit word. On an all-symbol-2 suffix, the unablated estimator and all-default estimator differ by at least 1/2 before normalization, as in the old proof. The common-tube compiler and log tolerances retain a positive constant gap. This is path usefulness, not a claim that two heads or square are statistically necessary.

## 6. Communication and resource ledger

A deterministic one-way protocol sends Alice's raw suffix bits in publicly known position order, at most b bits. Bob supplies his own suffix bits and computes the logical nonlinear estimator. Thus exact logical terminal simulation costs <=b, and simulation of the physical network has worst-history TV error <=zeta (relative to the bounded-log reference). If further output quantization is required, its accuracy is separately charged. This is a finite suffix-support certificate, NOT an additive cut, a Taylor moment protocol, or a new communication theorem. Nonadditivity is compatible with low communication.

Full budget:
- exactly two useful full-prefix scalar zero-score heads;
- fixed width and one sufficiently large fixed c-dependent complete-state/full-matrix/full-bias/primitive-gain envelope, not an unchecked numerical M_K;
- D=O_c(log N+b^2), including position preparation, row square, comparisons, counts, division, logs, normalization padding/restoration;
- per-coefficient description O_c(log N+b^2), dominated by compiler M; untied total O_c((log N+b^2)^2);
- T physical rows, O(N) distributed state; useful-head plus local work O(N^2+ND) if zero-attention slots are skipped; O(N^2D) if every dummy slot is densely evaluated;
- exact-real semantics including LN and softmax; parameter precision does not certify floating-point execution;
- source-independent weights with known c only for the fixed probability floor/output envelope.

## 7. What this does and does not combine

This answers compatibility positively for a genuinely nonadditive, nonvanishing pure-square distributed memory followed by true ordered second-order prediction. It does NOT retain the previous two-moment Taylor communication proof: that proof controls small smooth-output errors, whereas this decoder has exponentially small digit margins and paid growing gain. We instead certify short suffix support. Ignoring the decoder gain would be false bookkeeping.

Recent Markov/n-gram papers already exhibit multi-layer ordered estimators. The immediate repository prior already has a one-read consistent estimator and a two-read linear version. This result is only a scoped existence/closure-boundary example. No improved rate, learned realization, generic nonlinear communication collapse, sharp lower frontier, minimum layer count or originality priority is asserted. No training, numerical model execution, parameter generation run, upload or publication occurred.
