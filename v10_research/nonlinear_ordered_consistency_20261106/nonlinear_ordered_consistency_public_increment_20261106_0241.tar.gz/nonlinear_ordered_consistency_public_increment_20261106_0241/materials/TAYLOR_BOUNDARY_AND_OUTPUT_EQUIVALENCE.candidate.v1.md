# Nonvanishing energy remainder versus exact terminal output equivalence

6 November 2026 UTC. Candidate v1. Conditional on the pure-square decoder proof passing review. This note distinguishes three inequivalent meanings of communication folding.

## 1. Pure-square body and an explicit failed Taylor route

Use the pure-square construction's notation: T=N+1, b selected suffix symbols, s=N-b+1, B=16, u_i=s C_k/i at its b+1 active rows (including the synthetic terminal), and u_i=0 elsewhere. Assume 4<=b<=N/2. Then 1/(3B)<=u_i<=2/(B-1) on every active row, for every history. Let U=T^{-1}sum_i u_i. The paid normalized energy is E=(b+1)^{-1}sum_i u_i^2.

The Taylor first-order surrogate of f(u)=u^2 about the common mean U, averaged over all T rows and multiplied by T/(b+1), is
 E_mean=T U^2/(b+1).
Its residual is the exact nonnegative identity
 E-E_mean=(b+1)^{-1}sum_i (u_i-U)^2.
Uniformly over histories,
 E>=1/(9B^2),
 E_mean<=4(b+1)/[(B-1)^2 T].
Therefore if b=o(N), liminf(E-E_mean)>=1/(9B^2)>0. This also holds after expectation under every source distribution, including the stationary interior second-order class. The source-average energy remainder is not small.

This is NOT a contradiction to TAYLOR_PREFIX_CLOSURE v2: its O_c(log N/N) estimate concerned prefix averages of stationary raw spins with bounded curvature and bounded downstream gain. The present states use source-position gating, paid s amplification, and a paid T/(b+1) normalization, followed by a growing-gain ordered decoder. The hypotheses and output sensitivity differ. A Taylor formula itself always holds, but importing the old numerical remainder/risk conclusion would be invalid.

This lower bound concerns THIS mean-centered energy surrogate only, not all possible linear statistics, all simulators, or the final predictive output. It is not a communication lower bound and is not a lower bound on prediction risk.

## 2. Nonadditive internal energy can have an additively representable output

For two suffix symbols j<l represented by d_j=1+x_j, d_l=1+x_l, the exact energy has mixed difference
 D_{jl}E=2B^{-(j+l)}sum_{k=l}^{b+1} w_k>0.
In particular the first two digits give a uniformly positive lower bound independent of N,b. The complete scalar ENERGY cut cannot be represented exactly as a constant plus a sum of token-local terms. This follows from the previously reviewed additive-cut criterion and says nothing about a later lossy map.

If the pure-square decoder correctly recovers all suffix digits, its final exact count estimator q(x) equals, on every Boolean history, the q(x) returned by the already-reviewed TWO_READ_ORDERED_SUFFIX v3 linear harmonic-code construction. That prior complete terminal signal IS a public weighted token-local sum. Both computations can use the identical fixed-floor and serial-log routines after q, so their bounded-log reference output distributions are exactly equal on all histories.

Thus the nonlinear network's terminal OUTPUT has an exact reference representation through the old additive code even though its internal energy does not. This is an explicit semantic equivalence of two fully specified programs, not a blanket theorem that nonlinear row memory is linear. Proving the decoder is essential; low rank or small curvature alone does not establish this equality.

The old simulator therefore transfers at the output, with its fully charged public decoder gain and parameter description. Alternatively Alice sends her suffix bits, at most b bits, and Bob reconstructs q exactly. The physical PreLN program differs from the bounded-log reference by the separately certified zeta, so the same protocols incur at most zeta additional worst-history TV error. This requires the full prepared-vector compiler proof; physical internal K/V are never asserted to equal their logical references.

## 3. Risk interpretation and non-claims

The statistic actually used for prediction is the empirical triple-count conditional at the recovered final ordered pair, not E, U or the marginal symbol average. Hence consistency follows ONLY from the old suffix-estimator risk theorem after exact decoding and controlled physical approximation. The preserved raw nonlinear energy itself is not a predictor of the next-symbol law.

This result would provide a compatibility example with nonvanishing internal curvature, low-risk second-order output, and cheap terminal simulation. It would not improve the statistical rate, prove a general nonlinear source-average lower bound, show training can find the weights, or certify finite-arithmetic execution. The strong distinction between nonadditive intermediate state and additively representable final output is the structural conclusion, not a new estimation theorem.
