# Independent exact-file audit: prior work, failures, and provenance

6 November 2026 UTC. Verdict: PASS as a scoped comparison using recorded earlier primary checks, with the corrected execution provenance explicitly retained.

Reviewed source: `PRIOR_WORK_AND_FAILED_ROUTES.v2.md`.
SHA-256: `57a17fa9d175cb545cc3db71e1b05924fef0b7d4fecb8c060af8054c177515f6`.

Direct comparison sources read: the full `../ordered_causal_memory_20261106/PRIMARY_COMPARISON.v1.md`; `../nonlinear_causal_closure_20261106/PRIOR_WORK_AND_SCOPE_COMPARISON.v2.md`; the accepted ordered-suffix and PreLN sources; the constant-width estimator; and this package's revised radix, Taylor/output-equivalence, signed-square, and finite-check provenance files. No external paper was fetched again in this audit.

## Prior work and scope

The Rajaraman, Ekbote, D'Angelo and Hahn summaries match the earlier recorded inspected sections and versions. The source does not convert those recorded inspections into a fresh literature retrieval or exhaustive priority search. It correctly distinguishes the inspected two/three attention-layer representation results, restricted training assumptions, sharpening, and zero-epsilon homogeneous normalization from the present fully charged fixed-positive-epsilon contract. Different resource assumptions are not treated as a novelty certificate or superiority result.

The local estimator, ordered count/final-pair program, statistical risk, prior logarithmic-depth consistency, and positive-epsilon compiler are all correctly credited to existing sources. The new square radix transports the same estimator rather than inventing a new prediction rate. The nonlinear Taylor statistic and communication-hard energy example have their own nonvanishing prediction-risk limitations; neither is silently used as the current low-risk result.

The cited fixed nonvanishing mixed difference is at the implemented LOGICAL h_hat_1 cut, as now proved in radix v2. It must not be read as a horizon-independent magnitude for the physically eta-scaled hidden coordinate. The current source and report should retain radix v2's explicit logical/physical qualification whenever that observation is summarized.

## Failure retention and provenance

The slower endpoint-polynomial candidate remains present and unaccepted as a separate mathematical deliverable. Its O(log N+b^2) depth and slower logarithmic-depth risk must not be substituted for the accepted radix result, or described as a failure of the new recurrence. The unamplified small-signal route is correctly marked unsuitable for a nonvanishing logical-nonlinearity claim. The rejected Taylor transfer, inference from nonadditivity to communication hardness, and uncharged precision/preparation shortcuts are all retained.

The v1 opening's blanket 'no experiment' statement was too broad relative to the author's actually executed rational enumeration. The v2 opening and section G explicitly correct it while preserving v1. Read-only inspection of `EXACT_CHECK_EXECUTED_COMMAND.v1.txt`, `check_pure_square_radix_exact.py`, captured stdout, and `EXACT_CHECK_PROVENANCE.v1.md` is consistent with an author-run ideal exact-rational recurrence check over 288 suffixes. The source uses fractions for recurrence/assertions and float conversion only for displayed metrics. This auditor did not observe the original execution directly or rerun it; its occurrence is supported by the author's confirmation and retained output.

The revised scope correctly excludes full model execution, parameter generation, a finite-arithmetic certificate, training, benchmarking, and statistical simulation. It also no longer calls the author-run check an independent audit. The analytical proof and independent review establish the general theorem, not those finite cases.

The unresolved training, arbitrary nonlinear-memory, source-average lower-bound, optimality, and PostLN questions are accurately retained. No new primary retrieval, computation, experiment, source overwrite, upload or publication was performed by this auditor.
