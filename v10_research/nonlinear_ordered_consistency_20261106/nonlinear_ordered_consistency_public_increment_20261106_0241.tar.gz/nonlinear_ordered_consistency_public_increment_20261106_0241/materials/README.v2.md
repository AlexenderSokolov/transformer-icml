# Pure-square ordered consistency research increment

6 November 2026 UTC. Local research only; no upload, publication or purchase performed during this research pass.

Read RESEARCH_REPORT.zh.v2.html for the Chinese self-contained report after its bound text/privacy audit. Main proof: PURE_SQUARE_RADIX.candidate.v2.md. Exact-version independent audits determine acceptance; candidate headers and older audits retain their historical wording.

## Outcomes

1. Two useful scalar uniform causal reads, with a pure-square-only second-read value channel, can transport the ordered suffix through a bounded quadratic radix decoder. Depth O_c(log N+b), fixed width, positive-epsilon gain-two PreLN and ordinary softmax. It returns the existing second-order suffix estimator with the existing risk R_b+2zeta, not a new statistical rate.
2. The logical energy and implemented logical initial code are nonadditive, with a positive early mixed difference at fixed logical scale. Raw physical paired states are scaled down by the compiler; no horizon-independent raw physical amplitude claim.
3. A naive mean-centered Taylor energy surrogate has a constant residual when b=o(N), yet the final output equals the old additive-code estimator. This is specific output equivalence and short suffix support, not generic nonlinear folding.
4. A sign-invariant square-only bottleneck on raw signed forms has risk at least theta/2 on the fixed symmetric lag-two source. Positive digits avoid that information-loss obstruction.

## Provenance and preservation

The old estimator, suffix/count/readout machinery and exact normalization compiler remain imported dependencies, named and linked relatively in each proof. Current external-paper comparison reuses the prior primary checks; there was no new live literature retrieval or priority certification.

All source versions are preserved, including the initial slower endpoint-polynomial candidate, radix v1, prior-work v1's corrected overbroad execution statement, historical audits and author exploratory note. The author exploratory file named INDEPENDENT_SIGNAL_LIMITS is not the separate mathematical audit of its own radix proposal.

A finite author-run fractions.Fraction algebra check really executed once for (6,4),(8,4),(16,8), totaling 288 suffixes. Its original command, formatted script, captured stdout and provenance record are preserved. No rerun was used to manufacture a new execution history. The checker verifies ideal recurrence/digit identities, not finite-dyadic square error, full Transformer execution, normalization, training, parameter generation, statistics, or floating-point robustness.

Document build/HTML static checks are separate from scientific checks. Visual rendering was not established and no previously denied rendering workaround was attempted. Exact source hashes bind versions, not mathematical correctness or external peer review.

Open: general nonlinear source-average resource frontier, optimality, training, finite arithmetic, general bank compression and mandatory PostLN. No stronger conclusion follows merely from this positive example.

Report v2 preserves v1, adds the original executed command and corrected prior-work v1 to its 16 exact appendices, and removes an unnecessary rendering-process sentence. It has 110,813 bytes and SHA-256 20835c1a436a27df336ed6826a7a782afb474866e0e56246d16bdbf5371709d2. Its final text/privacy audit remains separate so the reviewed report hash is not changed.
