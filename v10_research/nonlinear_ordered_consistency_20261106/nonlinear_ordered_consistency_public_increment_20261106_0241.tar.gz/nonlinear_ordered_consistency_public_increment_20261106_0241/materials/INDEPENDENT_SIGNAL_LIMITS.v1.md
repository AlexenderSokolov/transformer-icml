# Independent signal-scale check and a nonvanishing alternative

6 November 2026 UTC. Research-only check of ordered two-read suffix v3 and Taylor prefix closure v2. No upload, model training, or novelty claim.

## Useful finding

The proposed small-signal map r -> r+r^2 is compatible with the old decoder, but its quadratic part vanishes at the old decoder's initial normalization. This does not imply that the same bounded-primitive O(log N+b) budget excludes substantive nonlinear transport. Paid O(log N) amplification before the square, followed by a quadratic radix decoder, gives a square-ONLY second-read value path at fixed active-row LOGICAL signal scale. The complete constructive proof is `PURE_SQUARE_RADIX.candidate.v2.md`, submitted for independent audit; v1 is preserved. The later PreLN compiler uses small physical amplitudes, so this is not a lower bound on unscaled physical coordinate magnitudes.

## 1. What the small-signal calculation actually proves

Use B=16, s=N-b+1, T=N+1 and the prior packed prefix r_i=C_(k(i))/i, with C_k<=2/15. Suppose f(0)=0 and |f''|<=L on the used interval. Removing the linear term leaves

    |f(r_i)-f'(0)r_i| <= (L/2) r_i^2.

Only b+1 rows are active. For the original ordered decoder scale R=BT/a_s, a_s=sum_(i=s)^T 1/i, the initial normalized residual is at most

    R/T * (L/2)(b+1)[2/(15s)]^2
       <= 2 B L T/(225s^2).                           (1)

Thus for b=o(N) and fixed L it is O(L/N). If the old downstream digit sensitivity times this quantity is below its plateau margin, the output is EXACTLY the old estimator, not a new nonlinear statistical correction. A fixed nonzero f(0) can be removed as a known public offset before applying this statement.

Equation (1) is a bound at that SPECIFIC decoder normalization, not a theorem about every allowed decoder or every multilayer bounded-primitive program. Overall decoder gain may grow with depth. Moreover the map r -> (s r)^2 has curvature 2s^2 in r even though it is computed by O(log N) gain-two primitives plus a bounded square circuit. A fixed per-primitive matrix envelope does not bound the curvature of a growing-depth composition by a constant.

## 2. A constructive escape that does not add a linear bypass

Paid multiplication by public s produces u_i=(s/i)C_(k(i)), bounded by 2/15. The second scalar read receives ONLY a tent approximation to u_i^2. Write

    Y=sum_(i=s)^T (s/i)^2 C_(k(i))^2,
    W_k=sum_(i=s+k-1)^T (s/i)^2.

Given decoded prefix P, the residual code h_k=B^k(Y-J_(k-1))/W_k has the exact next-digit update

    h_(k+1)=B(W_k/W_(k+1))[h_k-2P d_k-d_k^2 B^(-k)],
    P <- P+d_k B^(-k).

There is no fresh generic product per round: d_k is a discrete onehot, so P*d_k is an exact bounded ReLU gate. For k>=2, h_k-3P is <=-2351/57600 on digit 1 and >=1/16 on digit 2. The first-round intervals are [1/16,289/3600] and [1/4,64/225]. Fixed plateaus decode all digits. The radix is below 48; O(log N+b) square precision and O(b+log b) ratio precision preserve exact onehots. Nonterminal and read-ablated states stay exactly on the zero/default branch.

This proves, conditional on the established imported counter and output compiler, the same constant width, two scalar useful reads, O(log N+b) paid depth, finite per-coefficient description O(log N+b), and old suffix-estimation rate. The author-run exact-rational checks in the candidate enumerate (N,b)=(6,4),(8,4),(16,8), totaling 288 suffixes; these are executed finite mathematical sanity checks, not independent mathematical audits or numerical transformer experiments. The original command, script, captured stdout and provenance are preserved alongside the candidate.

For b<=N/2 every active u_i>=3/112 and Y/(b+1)>=9/(49*256). Hence this route does not rely on a quadratic perturbation disappearing after the signal's own normalization. It does NOT prove nonlinear advantage or necessity: its final estimator is deliberately identical to an existing linear-code estimator.

## 3. Precisely what collapses

The squared middle energy is not supplied with an additive identity in this proof. The final logical output equals the old additive-code output on EVERY Boolean history because the decoded word is identical. Consequently the old additive terminal simulator reproduces this final output exactly. This is final-function equivalence, not a Taylor approximation to intermediate nonlinear rows. The physical PreLN network inherits only the uniform approximation certified by the full prepared-state compiler.

There is also the simpler b-bit exact protocol: Alice sends her owned selected-suffix bits and Bob evaluates the public estimator. Neither protocol establishes a new general nonlinear-memory communication bound.

The raw-prefix Taylor source-average theorem cannot simply be imported here. Its concentration condition concerns empirical raw-sign prefix averages around their full-sample mean with fixed derivative/output budgets. Here the positive packed code and paid amplification create a different signal. If U=T^(-1)sum_i u_i, then for b=o(N),

    [T/(b+1)]U^2 <=4(b+1)/(225T) ->0,

while Y/(b+1) stays bounded below. The naive mean-centered square surrogate loses a nonvanishing normalized contribution.

## 4. A precise limit on overbroad square-only claims

If the sole predictive information is the square of raw SIGNED prefix averages m_i, global sign reversal x -> -x leaves every m_i^2 and their second-read average unchanged. No decoder of that statistic alone can be uniformly consistent even over IID binary sources.

Proof: take IID signs with P_+(X=+1)=1/2+delta and P_-(X=+1)=1/2-delta, where 0<delta<1/2-c if an interior c is required. Global sign reversal pushes P_+ histories to P_- histories, while preserving the predictor output. Its output distribution is therefore the same under both sources. Pointwise triangle inequality against the two fixed next-symbol probabilities gives

    E_+ TV(Q,p_+) + E_- TV(Q,p_-) >=2delta,

so at least one risk is >=delta for every N. This restriction assumes no separate sign-bearing raw-symbol, skip, or terminal-context input to the decoder. The positive-digit suffix encoding avoids the obstruction: {1,2} codes are not closed under sign reversal, and the square transport is injective after the explicit causal radix reconstruction.

## Conclusion

Nonvanishing nonlinear transport and the old consistent order-two estimator can coexist in the same asymptotic budget. What has been established is a carefully decoded positive-code example with output-level folding, not a general mild-nonlinearity Taylor theorem, statistical improvement, or claim that arbitrary square-only causal predictors work.
