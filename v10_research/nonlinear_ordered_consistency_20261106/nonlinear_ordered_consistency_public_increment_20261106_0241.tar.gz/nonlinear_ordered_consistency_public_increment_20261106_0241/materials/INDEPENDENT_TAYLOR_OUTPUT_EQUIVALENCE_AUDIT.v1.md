# Independent exact-file audit: energy remainder and output equivalence

6 November 2026 UTC. Verdict: PASS as the explicitly CONDITIONAL mathematical statement in the source. The pure-square decoder and its complete positive-epsilon compilation remain separate obligations; this note does not certify them.

Reviewed source: `TAYLOR_BOUNDARY_AND_OUTPUT_EQUIVALENCE.candidate.v1.md`.
SHA-256: `e887f99efb2272dc12688c032b7b98cd42b53d9ba7dfef6abb082246b1bf0726`.

Directly checked dependencies: `../ordered_causal_memory_20261106/TWO_READ_ORDERED_SUFFIX.candidate.v3.md` (SHA-256 `8447990d0957bab96b473a256cf108b2a13a9d2d397c65da13549d40a4d56c75`); `TWO_READ_PRELN_COMPILATION.candidate.v4.md` in that directory (SHA-256 `a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2`); and the prior nonlinear closure package's `TAYLOR_PREFIX_CLOSURE.candidate.v2.md` and `ADDITIVE_CUT_CERTIFICATE.candidate.v3.md`.

## Analytic checks

- There are exactly b+1 active rows, including the synthetic self. At each, C_k is at least 1/B and s/i is at least 1/3, while C_k is at most 2/(B-1). Thus the displayed positive lower and upper bounds on u_i hold on every history.
- Writing U=(1/T) sum_i u_i gives sum_i (u_i-U)^2=sum_i u_i^2-T U^2. Dividing by b+1 proves the exact displayed normalized residual, including the factor T/(b+1) in the Taylor surrogate.
- The active support bound gives U <= 2(b+1)/[(B-1)T], hence E_mean <= 4(b+1)/[(B-1)^2 T]. Together with E >= 1/(9B^2), this proves the claimed history-uniform positive liminf when b=o(N). Taking expectations cannot remove that uniform lower bound.
- This is specifically the expansion of the squared sparse, amplified rows about their common mean U. It is not the previous raw-spin-prefix expansion about M=S_N/N. The note correctly distinguishes the hypotheses and retains downstream amplification rather than importing the former O_c(log N/N) conclusion.
- Expanding C_k^2 gives mixed binary difference 2 B^{-(j+l)} sum_{k>=l} w_k. It is strictly positive. For j=1,l=2, the prior bound is at least 8/(45 B^3), so the ideal scalar energy cut is not additive and its early curvature does not vanish with the horizon.
- Exact recovery of the actual suffix, followed by the same count/readout program, is sufficient for pointwise equality of q with the old harmonic-code program. The same deterministic floor/log schedule then gives pointwise equality of bounded-log reference distributions. This statement does not require the nonlinear energy itself to factor additively.
- The prior additive-code terminal simulator can therefore simulate that identical reference output. Alternatively, at most b raw suffix bits suffice exactly for the reference output, with the public ownership partition and parameters known to both parties. A separately proved uniform physical/reference error zeta adds at most zeta by the triangle inequality.

## Scope retained

The phrase output representation means representation THROUGH the old additive code with its charged nonlinear decoder. It does not mean the output distribution itself is an additive function of tokens. Likewise, nonadditivity is asserted here for the ideal energy identity; extension to the implemented dyadic or physical internal cut requires its own error comparison. Neither caveat affects the stated conditional semantic equivalence.

The energy remainder is not a prediction-risk lower or a lower against all linear summaries, Taylor centers, or communication protocols. Consistency still depends on the established ordered triple-count estimator and exact decoding, not on interpreting the energy as a predictor.

No failure requiring source revision was found. This audit used source reading and analytic derivation only. No scientific experiment, model execution, parameter-generation run, source-file overwrite, upload, or publication was performed.
