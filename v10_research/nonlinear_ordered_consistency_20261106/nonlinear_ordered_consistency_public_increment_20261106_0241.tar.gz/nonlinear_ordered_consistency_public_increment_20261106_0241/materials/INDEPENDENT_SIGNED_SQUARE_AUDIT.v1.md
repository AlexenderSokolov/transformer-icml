# Independent exact-file audit: sign-erasing square obstruction

6 November 2026 UTC. Verdict: PASS for the specified complete-terminal-input global-negation symmetry, with the displayed approximate extension.

Reviewed source: `SIGNED_SQUARE_CONTEXT_OBSTRUCTION.candidate.v1.md`.
SHA-256: `df30dc1624541d7db1a70373bc4b63104bbbd3a886cc6ed3a9ac1ac80a3b8977`.

## Mathematical checks

The given pair transition sends (a,b) to (b,x) with probability (1+theta*a*x)/2. Summing over a under the uniform pair law gives probability 1/4 for every next pair (b,x), establishing stationarity directly. For 0<theta<=1-2c, both next-symbol probabilities belong to [c,1-c], so the source belongs to the stated homogeneous interior order-two class.

The path probability is unchanged by replacing every x_t by -x_t: each product x_(t-2)*x_t is preserved and the initial pair is uniform. The actual next-plus probabilities at paired histories are 1/2+theta*x_(N-1)/2 and 1/2-theta*x_(N-1)/2, separated by theta.

If the complete decoder input is invariant under global negation, its deterministic output q is invariant too. The pathwise triangle inequality gives the sum of the two binary TV errors at least theta. The invariant source law makes their expectations equal, proving risk at least theta/2. The constant predictor 1/2 incurs exactly theta/2, so the fixed-source symmetry bound is sharp.

Without exact invariance, inserting |q(x)-q(-x)| into the same triangle inequality gives 2*risk+A>=theta. The nonnegative bound is max(0,(theta-A)/2). Uniform TV error zeta to an invariant reference implies A<=2zeta by two applications of the triangle inequality, proving the stated physical lower bound theta/2-zeta when positive.

## Scope checks

Every squared homogeneous public linear form of signs is invariant under global negation, as are arbitrary deterministic functions of such forms and public constants. The requirement that this is the COMPLETE data-dependent decoder input is essential. Unsquared signed channels, nonzero offsets, or data-dependent coefficients are not silently included.

The positive d in {1,2} encoding is affine rather than odd in the underlying sign. Squaring its nonzero-offset code can retain sign-dependent cross terms, so it does not satisfy this obstruction. The positive-code constructive theorem and this restricted impossibility theorem are compatible.

No lower bound for all nonlinear updates, communication, attention count, or training follows. The approximate physical consequence requires the stated end-to-end error certificate and does not assume that full-feature PreLN has exact internal sign symmetry.

No correction was needed. This audit used source reading and pencil derivation only; no experiment, model run, source edit or upload was performed.
