# Independent exact-file audit: pure-square quadratic radix

6 November 2026 UTC. Mathematical verdict: PASS for the stated exact-real logical circuit and its reuse of the accepted positive-epsilon PreLN compiler in one sufficiently large fixed c-dependent envelope. The separate package-level provenance issue below must be reconciled; the mathematical proof does not depend on finite checks.

Reviewed source: `PURE_SQUARE_RADIX.candidate.v1.md`.
SHA-256: `6cfd97155834dfafb79fff32facc25d1d7c47f103b9877420a6cde6e7fb74fb8`.

Frozen prior contract directly read: `../ordered_causal_memory_20261106/TWO_READ_ORDERED_SUFFIX.candidate.v3.md`, hash `8447990d0957bab96b473a256cf108b2a13a9d2d397c65da13549d40a4d56c75`; and `TWO_READ_PRELN_COMPILATION.candidate.v4.md` in that directory, hash `a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2`. Their independent audits and the full `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md` were also read. Existing statistical and normalization lemmas are inherited, not re-proved as new results.

## 1. Exact signal and recurrence

The first head gives C_k/i, including C_b/T at the synthetic row. Exact paid multiplication by s therefore gives the stated u_i. Summing squared values over the second full-prefix head gives Y/T, with both N and T contributing to the final suffix tail. No selected source or synthetic self term is missing.

Interchanging the finite sums in C_k^2=sum_{j<=k}(C_j^2-C_{j-1}^2) gives equation (2). After subtracting J_(k-1), the contribution of each remaining active row is C_(k(i))^2-P_(k-1)^2. This proves equation (3), rather than assuming that Y itself is a simple square of the complete code.

Subtracting the recovered digit's exact contribution and multiplying by B W_k/W_(k+1) gives equation (4). Its exact residual is nonnegative. The quoted bound h_(k+1)<1 makes the clip harmless. Since the next tail contains rows i+1 and i+2, W_k/W_(k+1) <= 1+(i+2)^2/(2i^2) <=43/18 for i>=3. Thus every radix is below 48, independent of N and b.

Initial gain R is positive, at least 16 and polynomially bounded by 16T^3/[s^2(b+1)]. Its bounded-gain factorization costs O(log N). Every exact partial amplification is at most the final h_1<=64/225, so intermediate clipping fixes the exact path.

## 2. Classifiers, all-row legality, and zero ablations

The first-round intervals are exactly bounded by [1/16,289/3600] and [1/4,64/225]. Both lie strictly inside their respective displayed plateau intervals, with margins much greater than 1/1000. Their supports are disjoint and avoid zero.

For k>=2, 1/16<=P<2/15 and h_k is the weighted average in (3). For digit one, y=h_k-3P is between -2/5 and -2351/57600; for digit two it is at least 1/16 and no greater than 44/75. Those intervals lie inside the later plateaus with margins greater than 1/1000. The loose bound h_k<=44/75 follows from 2(2/15)(32/15)+(1/256)(32/15)^2=44/75. No terminal history is omitted.

Once a classifier is an exact onehot, ReLU(P+C-1) equals P*C on the declared P domain. Hence the digit-times-prefix operation is an exact bounded gate, not an approximate generic multiplication. P remains exact under the correct-digit induction.

The synthetic gate annihilates every nonterminal decoder input. At h=P=0 both classifiers vanish, D=Dsq=0, and the recurrence preserves h=P=0. First-read ablation also reaches this branch because the square interpolant fixes zero exactly; second-read ablation reaches it directly. Counting alone converts this zero branch to symbol one. An explicit implementation is z_1=1-C_2, z_2=C_2 on every exact reference state, equivalently using C_0=1-C_1-C_2. Thus every row supplies a legal b-word to the inherited exact count lattice and restoring divider.

## 3. Finite coefficients and error induction

Only b+1 square inputs are nonzero. Therefore the terminal second-read square error is at most (b+1)nu/T. Nonexpansiveness of every clipped doubling, gamma_hat/gamma<=2, and the exact pre-final-factor state being below one give the stated e_1 <=2BT^2 nu/s^2+delta. This comparison remains valid even if an approximate amplification path clips.

Given correct previous classifications, P and the subtraction are exact. The difference between the rounded and exact radix updates is bounded by 49e_k+delta, because the exact pre-radix residual is in [0,1]. The displayed choices give

    e_1 <= eta_0/(32*49^b)+delta,
    49^(b-1)(e_1+b*delta)
        <= eta_0/(32*49)+(b+1)eta_0/(16*b*49)
        < eta_0.

Hence the classifier-margin induction closes on every suffix; it is not an inference from the finite checks reported in Section 7. Zero branches remain exactly zero under the coefficient replacements.

The q/gamma accuracy costs O(b+log b) fractional bits. The square accuracy has log(1/nu)=O(log N+b), using s>=3. The one square approximant costs O(log N+b), while all b radix rounds cost only O(b). Exact dyadic position weights, paid integer s amplification, and prior source-position routines have the claimed O(log N+b) descriptions. Execution arithmetic is still exact-real.

## 4. Whole-program PreLN and statistics

Every new primitive has bounded fixed width, full coefficient and bias norms, and complete reachable states: tent-square stages, gates, fixed plateau slopes, radices at most 49, bounded doublings and clips. Their fixed enlarged tube can contain original and both ablated reference trajectories. A physical perturbation need not stay on a classifier or count lattice; the accepted compiler propagates error through the actual continuous circuits.

The source includes floor/log work, all scaled copies, norm-padding microsteps and clears before choosing eta. Its m=O_c(log N+b) is therefore a complete prepared-program length. The two uniform attention local errors are O(eta^2) without a horizon multiplier. Choosing M=O_c(m+log(1/zeta)) controls the full prepared vector, which is the premise required for paid radial restoration and the final ordinary affine vocabulary softmax. The gain-two reparameterization preserves trajectories. No exact physical square or additive K/V identity is used.

The inherited finite-description floor is the largest negative power of two a<=c, as specified by the referenced compiler; the phrase 'fixed interior floor c' should be read as invoking that construction, not storing an arbitrary exact real c as a finite-bit coefficient. Making a explicit in a future revision would remove ambiguity.

Exact decoded-word equality supplies the actual ordered terminal pair and triple-count estimate, not a marginal frequency estimate. The source-independent arbitrary-initial suffix risk is therefore inherited unchanged. The floor cannot worsen binary risk against targets with coordinates at least c; log and physical approximation add at most 2zeta. On all-digit-two versus all-default suffixes, the inherited pre-floor separation is 1-2/b>=1/2, and the common output tolerances preserve a fixed positive gap after compilation. This establishes usefulness of both paths in this program, not necessity for the estimation task.

## 5. Communication and complete resource scope

The terminal function equals the old estimator, so its old additive-code representation can simulate the output with the old charged decoder. Alternatively, sending owned suffix bits costs at most b bits exactly for the logical reference. Adding the uniform physical/reference error incurs zeta. Neither statement is a Taylor approximation of the energy or a reconstruction of the evolving physical row bank.

The ledger consistently charges two useful heads, O_c(log N+b) paid depth, constant per-row width, a sufficient fixed c-dependent full-norm envelope, O_c(log N+b) per-coefficient bits and O_c((log N+b)^2) untied total bits. O(N) distributed state, O(N^2+ND) useful-head/local work, and O(N^2D) work for densely evaluated dummy attention slots remain distinct. The rate/depth orders match old results, and no finite-arithmetic, trained-realization, PostLN or general nonlinear simulation claim is certified.

## 6. Provenance issue retained

Section 7 of the reviewed v1 reports an executed exact-rational recurrence enumeration. The author confirmed that Python fractions.Fraction was used and that no further checks would be run. The contemporaneous `PRIOR_WORK_AND_FAILED_ROUTES.v1.md` opening says no experiment occurred in this pass, so package-level reporting needs clarification rather than silently dropping the recorded computation. The author is preserving its script and captured output. This audit did not execute or rely on that enumeration. It is not a mathematical counterexample or failure of the proof.

The slower `PURE_SQUARE_ORDERED_ESTIMATOR.candidate.v1.md` was inspected only as historical fallback and is not independently accepted by this audit. No author source was overwritten. No scientific computation, model execution, parameter-generation run, upload or publication was performed by this auditor.
