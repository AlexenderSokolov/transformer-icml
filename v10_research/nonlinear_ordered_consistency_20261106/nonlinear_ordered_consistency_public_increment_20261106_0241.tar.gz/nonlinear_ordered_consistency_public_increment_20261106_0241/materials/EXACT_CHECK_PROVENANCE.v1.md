# Finite mathematical-check provenance

6 November 2026 UTC. The exact-rational recurrence check was actually executed once in this research pass. Its results were captured before this record was written. It enumerated all 16, 16, and 256 binary suffixes respectively at (N,b)=(6,4),(8,4),(16,8), using Python fractions.Fraction throughout the recurrence and assertions. The printed summary metrics alone were converted to floating-point for display.

The exact original shell command including its Python heredoc is preserved in `EXACT_CHECK_EXECUTED_COMMAND.v1.txt`. A standalone script with formatting and a descriptive module comment only is `check_pure_square_radix_exact.py`; the captured stdout is `check_pure_square_radix_exact.stdout.txt`. It was not rerun when these files were saved.

This was an executed finite mathematical sanity check. It was not a trained model, full logical or physical transformer execution, finite-precision robustness experiment, parameter-generation program, benchmark, or statistical simulation. Blanket descriptions claiming that no scientific or mathematical computation occurred should not be used. The proof, rather than the finite checks, establishes the general claim.
