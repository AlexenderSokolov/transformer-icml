# Prior work, rejected routes, and provenance

6 November 2026 UTC. Local analytical follow-on. No new literature retrieval, full Transformer execution, training, publication or novelty certification occurred in this pass. A finite exact-rational check of the ideal radix recurrence was actually executed for (N,b)=(6,4),(8,4),(16,8), covering 16, 16 and 256 suffixes. Its script and observed output are preserved; it is not an executed parameter-generation pipeline, full model implementation, finite-arithmetic validation or statistical experiment. The earlier v1 blanket no-experiment wording was too broad and is retained as a corrected version. External comparisons reuse the primary checks explicitly recorded in ordered_causal_memory_20261106/PRIMARY_COMPARISON.v1.md and nonlinear_causal_closure_20261106/PRIOR_WORK_AND_SCOPE_COMPARISON.v2.md.

## Closest local results and exact differences

1. CONSTANT_WIDTH_CONSISTENCY v3 already constructs the one-read packed-suffix estimator, exact triple-count/final-pair update, paid division, and risk 13 sqrt(32/(b-1))+1/b. Those are dependencies, not new results here.
2. TWO_READ_ORDERED_SUFFIX v3 and TWO_READ_PRELN_COMPILATION v4 already transport the same suffix through two public linear prefix reads, decode harmonic-radix digits, and compile to positive-epsilon PreLN with ordinary softmax. They already achieve depth O(log N+b), constant width and consistency. The current candidate inserts a pure-square distributed value update and changes the decoder, not the estimator.
3. TAYLOR_PREFIX_CLOSURE v2 supplies an O_c(log N/N) source-average simulation residual for smooth functions of stationary raw-spin prefix means, but its quadratic example has limiting risk theta/2 on the lag-two witness. The new construction uses paid positional scaling and an ordered packed code, not that marginal statistic or its error bound.
4. ADDITIVE_CUT_CERTIFICATE v3 identifies mixed differences for a specified complete cut. It does not prohibit a nonadditive intermediate code from being decoded to an output representable by a different additive code.
5. NORMALIZED_NONLINEAR_OBSTRUCTION v2 compiles a known pure-energy communication obstruction with two scalar heads into the same normalization/output contract. It is not low-risk. The present suffix-supported energy is not hard in communication: sending the suffix costs at most b bits. Neither example implies the other's risk or distributional theorem.
6. LOW_RISK_WEAK_ANCHOR_COMPOSITION adds a small extra interaction around a completed predictor. The present pure-square body instead carries the only second-read signal and has an N-independent internal mixed difference. Nevertheless the final estimator remains identical to the old one, so this does not establish statistical necessity or advantage of nonlinearity.

## Closest external work, without a new priority claim

- Rajaraman et al., https://arxiv.org/html/2407.17686v1 : earlier primary inspection of Theorem 5.1 records a three-one-head-layer Markov construction. Ordered empirical prediction is already prior work. The current result is not a first multilayer Markov estimator or minimum-layer theorem.
- Ekbote et al., https://arxiv.org/pdf/2508.07208v2 : earlier inspection of Theorem 3 records two one-head layers, width 6S+3, relative positions, sharpening and a normalization v/||v||. Its restricted first-order training result assumes a correct MLP, and is not training of the entire second-order construction. The current positive-epsilon bounded-gain compilation is a different explicitly budgeted contract; this does not establish superiority or novelty.
- D'Angelo et al., https://arxiv.org/html/2607.02800v1 : earlier inspected induction/n-gram representation passages already treat ordered context. No claim that nonlinear memory first becomes useful for Markov prediction here.
- Hahn, https://aclanthology.org/2020.tacl-1.11.pdf : bounded-depth sensitivity depends on gains and depth; this construction pays logarithmic-depth amplification and growing coefficient precision. The corrected supplement was not freshly fetched in this pass or the preceding ordered-causal pass. No contradiction to fixed-resource sensitivity bounds is asserted.

The new square-code radix identity, if independently accepted, is a concrete algebraic compatibility example. Elementary algebra, plateau coding, tent-square approximation, one-hot ReLU gates, and the old normalization compiler are not asserted to be novel mathematical tools. An exhaustive priority search has not been performed.

## Preserved attempts and limits

A. Small-signal route considered before writing the main candidate: use f(r)=r+r^2 with unamplified packed prefix r=O(1/N). Its normalized decoder perturbation can be made harmless, but bounded curvature then contributes only O(1/N) to the initial decoder code. This would be an asymptotically affine example, not an answer about nonvanishing nonlinear memory. It is not used as evidence of a strong nonlinear effect. No unreviewed claim of an improved rate is retained.

B. PURE_SQUARE_ORDERED_ESTIMATOR.candidate.v1.md is preserved as the initial slower endpoint-polynomial construction. Its tentative O(log N+b^2) decoder repeatedly approximates products. The later radix route exploits digit one-hots to make prefix-times-digit exact and aims to reduce this overhead to O(b). The slower file's header remains historically 'candidate'; it must not be silently cited as independently accepted. Its projected O((log N)^(-1/4)) rate at D=O(log N) is not the final radix result.

C. Wrong generalization rejected: applying the old stationary raw-prefix Taylor variance bound to position-gated, amplified suffix code. The explicit normalized-energy residual in TAYLOR_BOUNDARY_AND_OUTPUT_EQUIVALENCE demonstrates why the naive mean-centered replacement stays inaccurate.

D. Wrong inference rejected: positive mixed differences at the internal energy cut imply expensive terminal communication. Correct decoding can erase the distinction, and short suffix support itself gives a b-bit protocol.

E. Wrong resource shortcut rejected: treating growing decoder gain, exact harmonic rational coefficients, a supplied suffix/count port, or final normalization as free. All are either avoided or explicitly paid. Complete padding/clears must precede selecting the physical small amplitude, as corrected in the earlier accepted compiler.

F. Open: training, actual parameter generation and numerical model execution, finite-arithmetic error, arbitrary nonlinear banks, low-risk source-average lower frontier, optimality and mandatory PostLN. The public-linear and low-risk pure-square examples alone do not settle these.

G. Provenance correction: the radix author actually ran the finite rational check described above. It was not an independent audit, randomized statistical test or full scientific reproduction. Do not translate it into either a blanket no-execution claim or a claim of trained/model validation.

H. Signed square is a different case: SIGNED_SQUARE_CONTEXT_OBSTRUCTION v1 pairs globally negated histories and gives risk at least theta/2 when the decoder sees only sign-invariant statistics. Positive offset digits break that symmetry. This elementary counterexample does not rule out the positive-code construction.
