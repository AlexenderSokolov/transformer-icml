"""Exact script executed once during the 2026-11-06 algebraic sanity check.

This is a preserved recurrence check, not a trained or normalized transformer
implementation, a parameter generator, or a finite-arithmetic robustness test.
All recurrence calculations and assertions use fractions.Fraction. Only the
three printed summary metrics are converted to float for display.
"""

from fractions import Fraction as F
from itertools import product

for N, b in [(6, 4), (8, 4), (16, 8)]:
    s = N - b + 1
    T = N + 1
    B = 16
    W = [F(s, i) ** 2 for i in range(s, T + 1)]
    tail = [sum(W[k:]) for k in range(b)]
    maxerr = 0
    ratios = []
    gaps1 = []
    gaps2 = []
    for digs in product([1, 2], repeat=b):
        p = F(0)
        Y = F(0)
        for k, d in enumerate(digs, 1):
            p += F(d, B ** k)
            Y += W[k - 1] * p * p
        Y += W[-1] * p * p
        h = F(B) * Y / tail[0]
        p = F(0)
        for j, d in enumerate(digs, 1):
            val = h if j == 1 else h - 3 * p
            if j == 1:
                dd = 1 if val < F(1, 8) else 2
            else:
                dd = 1 if val < 0 else 2
                (gaps1 if d == 1 else gaps2).append(val)
            assert dd == d, (N, b, digs, j, val)
            inc = 2 * p * d + F(d * d, B ** j)
            p += F(d, B ** j)
            if j < b:
                ratio = B * tail[j - 1] / tail[j]
                ratios.append(ratio)
                h = ratio * (h - inc)
    print(N, b, 'histories', 2 ** b, 'maxgain', float(max(ratios)),
          'd1max', float(max(gaps1)), 'd2min', float(min(gaps2)))
