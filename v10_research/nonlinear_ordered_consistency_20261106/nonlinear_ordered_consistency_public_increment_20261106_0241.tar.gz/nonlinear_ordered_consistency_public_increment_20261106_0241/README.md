# Nonlinear ordered consistency: public research increment

All 32 available source files are represented under materials/, including every candidate version, failed route, author exploratory note, independent review, HTML version, script and historical QA. Thirty files are exact copies. Only an internal role-attribution phrase in README.v1/v2 was neutrally reworded, with no scientific or execution-status change. Original sources remain unchanged. This is a new local additive package, not a GitHub publication.

Open materials/RESEARCH_REPORT.zh.v2.html directly for the latest complete Chinese report; v1 is retained. The matching final text/privacy audit is separate, preserving the report hash. Both versions embed escaped inert source text; opening the HTML does not execute the appended Python.

## Executed exact-rational check: preserve its actual scope

A historical author-run Fraction algebra check was actually executed once over 288 suffixes: (N,b)=(6,4),(8,4),(16,8), with 16+16+256 cases and B=16. The exact original heredoc command, readable equivalent script, captured stdout and provenance record are all preserved byte-for-byte. See EXACT_CHECK_FILES.json for direct paths and hashes. Parameters are present in the original command/script, not newly invented. Recurrence/assertions use exact fractions; only printed metrics are converted to floats.

Packaging did not rerun this check or manufacture a new execution history. Its original execution is documented by retained author provenance and output, not directly witnessed again by the packaging reviewer. It checks ideal digit recurrence, not finite-dyadic square error, classifier ramps, full count/readout circuitry, physical Transformer execution, parameter generation, training, statistics or floating-point robustness. Therefore it would be false to say no mathematical computation occurred. The finite enumeration is not the general proof or an independent mathematical audit.

## Scientific and review boundaries

The pure-square second-read route returns the existing suffix estimator at the existing risk R_b+2zeta. It is not a new statistical rate or a minimum-head/layer theorem. Two useful scalar reads coexist with O_c(log N+b) paid depth and inherited fixed-positive-epsilon PreLN/ordinary-softmax machinery. Nonadditivity is stated at logical scale; compiled physical states shrink and have no horizon-independent raw-amplitude claim.

A naive Taylor energy surrogate can have constant residual while this particular output still equals an earlier additive-code estimator. This is specific output equivalence, not general nonlinear folding. The signed-square bottleneck obstruction and positive-digit workaround retain their stated source/symmetry scope.

INDEPENDENT_SIGNAL_LIMITS.v1.md is an author exploratory note despite its filename; it is not an independent audit of its own radix proposal. Separate exact-version reviews determine acceptance. Old candidate labels, failed shortcuts, the slower endpoint-polynomial proposal and the corrected overbroad execution statement in prior-work v1 remain historical artifacts.

No physical floating-point validation, trained realization, statistical simulation or visual acceptance is established. Visual acceptance is NOT COMPLETED. External proof dependency closure remains OPEN. Analytical PASS is not formal verification, external peer review or novelty certification. This package is not recovery of a complete v10 archive.

## Privacy, copyright and verification

Scoped review found no actual secrets, sensitive personal information, private correspondence or machine paths in the materials. Only the two README role phrases were neutralized. Third-party papers are cited or summarized in original comparisons, not redistributed in full. No new license/rights grant is introduced; this is not legal clearance.

SOURCE_DERIVATION_MAP.json records every original/public path, byte count, hash and edit. PACKAGING_QA.json separates new checks from immutable historical QA. independent_review/ holds historical review classification and a new independent package review. SHA256SUMS and the read-only verify_package.py check integrity. Existing report build/check scripts write outputs and must be run only in a disposable copy. Exact scientific-check provenance must not be overwritten by a rerun.
