# Dependencies and omissions

No available file in the source directory was omitted. All 32 files, reports v1/v2, original exact-check command, parameters, script, captured output and provenance are included. Only README role wording differs; originals and their hashes are preserved in the mapping. No absent version or missing experiment was fabricated.

External dependencies remain unclosed: earlier suffix estimator/risk proof, suffix/count/division/readout machinery, positive-epsilon PreLN small-amplitude/full-prepared-vector compiler, padding/restoration/ordinary-softmax modules, common original/ablated program tubes, lag-two source/symmetry witnesses, and earlier primary literature comparisons. Consult original candidate relative references for identifiers. Their entire proof graph and exact-byte corpus are not bundled or re-established here.

Third-party full papers/PDFs are not included. Neither physical floating-point/training results nor screenshots/visual-render acceptance exist in this source snapshot. Local HTML bindings establish appendix identity, not mathematical truth or external dependency closure. This snapshot does not recover a complete prior v10 corpus.
