"""Read-only verification of published package files; no source corpus required."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
records = json.loads((root / 'SOURCE_DERIVATION_MAP.json').read_text())['entries']
for item in records:
    payload = (root / item['public']).read_bytes()
    assert len(payload) == item['public_bytes'], item['public']
    assert hashlib.sha256(payload).hexdigest() == item['public_sha256'], item['public']
for line in (root / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
print(f'PASS: {len(records)} material mappings and all SHA256SUMS entries.')
print('This is byte-integrity verification, not scientific, visual, or dependency-closure validation.')
