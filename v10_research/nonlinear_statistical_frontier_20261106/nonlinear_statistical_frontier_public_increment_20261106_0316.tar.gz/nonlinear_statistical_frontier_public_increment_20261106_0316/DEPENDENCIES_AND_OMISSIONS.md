# Dependencies and omissions

All 40 available source files are represented. The three sensitive-attribution originals and original unneutralized HTML v1 are not redistributed; exact source hashes/sizes and neutral derivatives preserve provenance and all scientific content. No failure or revision is suppressed. No missing version is invented.

External dependencies remain OPEN: earlier source-average testing, AA/BB ownership/communication reduction prerequisites, suffix estimator and risk/count machinery, lag-two context witness, full-history wide estimator, positive-epsilon PreLN compiler and full prepared-vector/padding/restoration/ordinary-softmax modules, common ablation tubes, nonlinear communication antecedents, and previously checked primary literature. Source-relative paths retain original-source meaning and may not resolve from relocated materials. They do not establish a complete transitive proof graph here.

Not bundled: third-party full papers/PDFs, unavailable earlier dependency corpus, absent model or numerical runs, and unperformed screenshot/visual acceptance. No complete-corpus recovery or standalone scientific reproducibility claim is made. The historical original v1 bindings/QA are retained evidence, not hashes for its neutral public derivative; see HISTORICAL_V1_PUBLIC_BINDINGS.json.
