# Independent exact-file audit: IID quadratic nuisance hardness

6 November 2026 UTC. Analytical mathematical review by a reviewer separate from the candidate author. Source reading, paper derivation, textual diffs, documentary hashes and this new review only. No scientific executable, numerical diagnostic, parameter generation, model execution, training, upload or public repository mutation was performed.

## Verdict and accepted binding

**PASS for candidate v3, conditional on its explicitly imported suffix-estimation and complete PreLN preparation/restoration lemmas. No blocking mathematical gap remains in the main theorem or the two stated optional variants.**

Accepted file: `IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md`.

SHA-256: `ef9ce668cd9815e45501194198177c7acdc369894a50e3b31aebb5baaa340767`.

I read v1 in full and inspected every v1-to-v2 and v2-to-v3 change. The earlier versions remain preserved. The conclusion is an exact-real, fixed-width, low-risk predictor whose COMPLETE terminal output is hard to simulate under fair IID input at a sufficiently small fraction of its own risk. It is not a minimax statistical lower, an improved estimator, a two-scalar-read theorem, a finite-arithmetic certificate, or a literature-priority finding.

For the main choice b=Theta(log N), the accepted result has three useful scalar-value uniform attention invocations, depth O_c(log N), actual worst-source risk Theta_c((log N)^(-1/2)), and the explicit communication lower

    C+b >= N/4-5/2

at expected terminal TV error at most kappa_c rho/100. The expectation includes BOTH input histories and simulator coins, with TV inside the expectations. The fixed old AA/BB ownership pattern is retained.

## 1. Corrections and clarifications made before acceptance

1. Candidate v1 incorrectly inferred a 100rho risk envelope. If log2(b) is odd, rho=1/sqrt(2b), so the leading inherited risk bound divided by rho tends to 104, rather than the stated value below 85. The missing factor was independently identified during review. Candidate v2 and retained v3 use the safe envelope 200rho and the corresponding actual-risk fraction kappa_c/20000. Their displayed bound 26 sqrt(128/3)<170 is now correct; the remaining terms fit within 30rho.
2. The optional merged first invocation kills BOTH the prefix mean and suffix code when ablated. Its usefulness cannot be imported from the main three-scalar-head ablations. Candidate v3 adds its own all-symbol-2 versus default-word logit gap, along with a common fully prepared original/two-ablation compilation. The resulting gap is positive even at nuisance amplitude one.
3. During development I requested the old AA/BB split rather than relying only on odd/even ownership, the output-bit adjustment for Bob-local terminal decisions, explicit synthetic-row inclusion, and the correct input-and-coin expected loss. All are present in the frozen accepted version.

Preserved bindings:

- v1: `5d73942aff9d760d6d85dfdf0d01e4e7aaa2ac1206609ba6376157351132b6f4`.
- v2: `83d7c573809ca6c3f633654c61a2210b1c1552f3d6f4b4887850de39dc7d68f7`.

## 2. Polynomial identity and communication rank

Each pair x_j x_k with j<k appears in binom(S_i,2) exactly when i>=k. The inclusive synthetic row therefore gives coefficient T-k+1=N+2-k. For even N its parity is precisely the parity of k. This verifies the candidate's quadratic polynomial on EVERY raw history, with no special communication encoding or rare event.

The odd/even matrix is strictly lower triangular of rank N/2-1. More importantly, under the original AA/BB split and N=4n, ordering party coordinates by parity gives the cross matrix

    [ J  L ]
    [ U  0 ],

where U is upper triangular with diagonal ones and L is strictly lower triangular with rank n-1. Swap row blocks and eliminate the lower-left block using invertible U. The rank is n+(n-1)=N/2-1. Alice-only and Bob-only quadratic terms multiply rows and columns of the sign matrix by signs; they do not alter its spectral norm.

After conditioning on a suffix of power-of-two length b>=4, complete ownership blocks are removed. Since N-b is divisible by four, the remaining cross matrix has exactly the same form and rank (N-b)/2-1. Cross terms with fixed suffix bits become local linear phases, and fixed suffix-only terms become a constant. The conditional spectral argument is therefore valid uniformly over every suffix.

## 3. Discrepancy, interaction, and coins

For d uniform bits per party and a cross matrix of rank r, binary character orthogonality gives the stated Gram matrix. Its equal-coset blocks have size 2^(d-r), so the sign matrix operator norm is 2^(d-r/2). Cauchy-Schwarz for arbitrary rectangle indicators yields normalized rectangle correlation at most 2^(-r/2).

A standard deterministic C-bit protocol has at most 2^C transcript rectangles. Bob's private-input-dependent decision may vary inside a transcript rectangle. Appending one output bit, or splitting each rectangle into its two Bob-output sets, gives at most 2^(C+1) constant-output rectangles. Thus distributional error at most 1/4 implies C>=r/2-2. Candidate v3 includes this adjustment rather than silently assuming every transcript leaf already has a constant output.

For a randomized protocol, fix all public and private coins after obtaining the distributional classification bound. Some fixed tape has no larger average error. Worst-case communication remains bounded on that tape because the original cost guarantee holds on every input and tape. This supports arbitrary interaction and unrestricted local computation. Expected communication, uncharged timing, and coin randomness dependent on the sample are not covered.

Fair IID raw bits give precisely the required independent uniform party inputs and belong to every stipulated P_c. Knowing that the source is fair IID does not help simulate a network output containing this parity. This is materially different from inferring a source-average result merely because a worst-case hard word has positive source probability.

## 4. All-row bounded parity circuit

The first scalar inclusive read gives S_i/i, including at the synthetic row. Multiplication by public i/P produces S_i/P. The cancellation-preserving square-difference product is particularly useful: M_L(a,0)=0 exactly, because its two square inputs coincide. This removes an ablation ambiguity that a generic approximate multiplier would otherwise create.

The square interpolant has its standard error nu and bounded serial realization. Product error is at most 2nu. The derivative estimate for (z^2-z/P)/2 and a further square error give the candidate's conservative value error below 4nu. The exact-grid values are nonnegative and at most one half, so clipping to [0,1] cannot increase this error.

The second read includes the synthetic row's value binom(S_N,2)/P^2. Its terminal average, multiplied by the bounded dyadic T/P, approximates U/P^3 to error at most 4nu. Excluding that value would change the parity polynomial; the accepted candidate does not exclude it.

After this read the synthetic marker gates nonterminal decoder inputs to zero. Every row's remaining inputs lie in [0,1]. The 3 log2(P) tent folds have total Lipschitz factor P^3, while each individual fold has fixed gain two. With nu<=1/(128P^3), their error is at most 1/32. The fixed plateau then returns the exact reference parity on every Boolean history. There is no unbounded U register, growing single-step matrix, discontinuous modulo primitive or exponential-width table.

All square/product/tent scratch registers can be maintained in fixed width with paid O(log N) depth. All-row state bounds, not merely terminal bounds, are supplied. Either parity-read ablation yields F=0 exactly in the logical program; x_2=x_3=1 and all other bits zero gives an unablated F=1.

## 5. Statistical risk and baseline-aware decoding

The estimator remains the imported one-head suffix estimator. Its floor/log conversion and the nuisance shift give the stated upper risk bound, now safely bounded by 200rho. Since rho lies between 1/(2sqrt(b)) and 1/sqrt(b), this is the old statistical order, not a new rate.

Conditioning on the suffix leaves parity bias at most 2^(-r'/2), where r'=(N-b)/2-1. Both nuisance branches consequently have conditional probability at least (1-delta_N)/2. Their probability separation is at least 2kappa_c rho. The triangle inequality against the fair target 1/2 yields conditional risk at least (1-delta_N)kappa_c rho. Subtracting the uniform physical approximation error proves the candidate's fair-IID risk lower kappa_c rho/2 for sufficiently large N, uniformly over b<=N/2. Thus actual risk, not just an advertised upper bound, has order rho for the main amplitude choice.

The simulator reduction correctly sends Alice's suffix bits after running the original simulator. Bob reconstructs the suffix-only LOGICAL logit baseline and thresholds at the midpoint of its two nuisance branches. This does not assume the actual physical normalized baseline is suffix-only; its possible outside-suffix dependence is included in the uniform physical error.

A wrong threshold decision requires scalar error at least kappa_c rho from the reference probability. Expected simulation error plus physical error is at most 2kappa_c rho/100, giving error at most 2/100. Applying the discrepancy result to the augmented C+b-bit protocol proves the stated lower. The arbitrary-two-vector half-l1 conversion is correct as well.

TV must remain inside the coin expectation. A metric based on TV of the coin-averaged predictor would not justify this classification argument. The accepted text expressly distinguishes these metrics.

## 6. PreLN compilation and main head usefulness

The candidate recompiles one enlarged logical program, rather than concatenating independent normalized physical networks. Its new local primitives are continuous bounded-gain affine/ReLU operations, and all three useful reads are zero-score uniform averages. Their normalized source factors are retained in the max-row local error bound; full-feature LayerNorm coupling is not ignored.

The chosen log tolerance is bounded below by a c-dependent constant times b^(-2), so its serial-log cost is O_c(b), despite the minimum involving kappa_c rho. All padding, output-bank copies and scratch clears are appended BEFORE defining the complete reference length and choosing eta. Common tube/gain constants include the original and all three individually head-ablated fully prepared programs. The complete-vector recurrence therefore yields eta with O_c(log N+b) description and paid restoration depth.

The imported bounded-logit output preparation/restoration proof applies to the resulting bounded paired bank. Uniform physical TV error at most zeta then transfers the reference separation. Gain-two reparameterization and ordinary final affine logits/softmax retain the stipulated positive-epsilon all-feature PreLN syntax. No PostLN claim is made.

Both parity-head ablations leave q_b unchanged and suppress F; their 2kappa_c rho reference margin survives 2zeta. The suffix-head ablation gives the inherited default word. Its floored baseline separation of at least one half survives two nuisance shifts, log approximation and physical errors. All original/ablated networks use identical parameters except for the specified zeroed attention output. These checks support exactly three useful scalar invocations.

This review checks application of the imported compiler to this new bounded program. It does not independently rebuild its full transitive padding/restoration or suffix-statistical proof chain.

## 7. Optional variants

The inverse-polynomial-amplitude variant correctly keeps baseline SERIAL LOG accuracy at O(b^(-2)) and tightens only physical comparison, padding and restoration. Otherwise a log approximation at inverse-polynomial accuracy could require polynomial depth. With O(log N) coefficient descriptions, this variant keeps O_(c,K_0)(log N+b) depth and gives hardness at a sufficiently small constant multiple of alpha_N. It does not claim total risk Theta(alpha_N) when alpha_N is below the baseline risk scale.

The two-invocation variant merges raw-bit and token-local suffix-code averages into a first value dimension of TWO, followed by one scalar read. The preserved prefix bank remains bounded while the suffix is decoded. Logical scheduling and fixed-width/full-norm bounds remain valid. It is not a two-scalar-head result.

Candidate v3 separately handles the merged first-head ablation. The original all-symbol-2 baseline and ablated default baseline have logit gap at least 2log(3). Log errors and possibly opposite nuisance shifts leave a gap at least 2log(3)-4epsilon_log-2alpha>0.19 for alpha<=1 and epsilon_log<=1/1000. Its positive fixed-interval sigmoid derivative converts this to a margin larger than two physical errors. The second-head ablation is the previous F=1 witness with the baseline unchanged. A fresh common fully prepared original/two-ablation tube and identical physical parameters are required and explicitly supplied.

## 8. Exact dependencies and scope

Documentary bindings checked:

- `../ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md`: `a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2`.
- `../local_memory_adaptive_reads_20261105/LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md`: `d51e74e89a452411d6eb6ffd6ab393fc3417f95aaed75e8a10dd20f4a970b5cb`.
- `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`: `ea1c3788f4eed06ccba9e19db3ee0d9a3e792bda7d3d620c0326cc4a07cecbb6`.
- `../softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md`: `6d61e56d8e9ecea7c1a4a76c6e839f3cdc91576161e99f133febedfe03b5faa5`.
- `../normalized_stationary_frontier_20261105/NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md`: `624219c736392dc9fc755f9d6e32e33b40cf13005436589b85df0a6e4ac90770`.
- `../nonlinear_causal_closure_20261106/NORMALIZED_NONLINEAR_OBSTRUCTION.candidate.v2.md`: `628009aef0e5d1333e23913bb34c2d04d3b67d792e7ea5ad76d498d729f331ac`.

Relevant earlier local source-average and weak-anchor records were inspected for scope. The rare-marker example is source-average cheaply simulable, and the older normalized prefix-energy example explicitly gives only worst-history hardness and has constant fair-IID prediction risk. Neither supplies this accepted fair-IID low-risk output-hardness statement merely by relabeling its prior result. No fresh external literature search or global novelty certification was performed.

The construction blocks generic cheap simulation of the entire output at a SMALL risk-proportional error. It does not block the known generic suffix simulation at a constant multiple GREATER THAN ONE of prediction risk, and it does not settle the fixed-width statistical minimax frontier. Its distributed O(N) state, O(log N) coefficient precision, paid logarithmic depth, stated dense work, and artificial nuisance must remain visible in every summary.

Acceptance binds only the exact v3 hash above and the stated imported lemmas. Later edits require renewed review.
