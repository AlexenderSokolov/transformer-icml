# Prior overlap, failed proof routes, and the remaining statistical question

6 November 2026 UTC. Analytical research only in this increment. No model, parameter-generation, numerical/statistical or finite-rational experiment was executed in this increment. The preceding pure-square increment separately preserves its actually executed 288-case ideal rational check; that historical check does not validate any new theorem here. No upload or publication was performed. External comparisons reuse the explicitly recorded prior primary-paper inspections, not a new live literature search or priority certification.

## 1. Output-equivalent square coding is not statistical improvement

PURE_SQUARE_RADIX v2 established a nonadditive logical cut and exact recovery of the old suffix word. The final logical distribution is pointwise identical to the old estimator. Hence no output-dependent loss can improve merely by this re-encoding. Its value was to separate internal additive structure from final-function equivalence. It never proved that the old suffix risk was optimal among other fixed-width networks.

Rejected inference: calling nonvanishing logical curvature a better statistical resource rate. Another rejected inference: claiming that two useful reads are necessary, when the older one-read code already produces the identical estimator.

## 2. The terminal-context depth barrier was already proved

Direct predecessors are terminal_context_obstruction_20261104_0822/BOUNDED_SCORE_TERMINAL_CONTEXT.md; logdepth_matching_private_20261104/MATCHING_ORDER.v2.md; terminal_suffix_extension_20261104_1854/SUFFIX_EXTENSION.v2.md; and standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md with its audits. They already contain nonlinear multihead sensitivity, weighted lag-two context pairing, the synthetic-terminal recurrence, all nontrivial fixed-target extension and positive-epsilon inheritance.

The current aggregate-QKV derivation clarifies that full concatenated operator/vector budgets yield head-count-independent constants, whereas separate per-head budgets do not. It is an accounting extension. It does not create a new logarithmic-depth lower or a risk-depth theorem beyond the already stated fixed-target obstruction. The elementary IID sample floor is likewise already implicit in the earlier source-testing results; it is not a new minimax lower-bound technique.

## 3. Growing width was already a statistical advantage in the logical contract

parallel_width_depth_20261104/CANDIDATE.v2.md and MATCHING_ORDER.v2.md already achieved full-history add-one estimation, width O(N), two useful uniform reads, depth O(log N), and risk O(N^-1/2), with explicit full-norm/dense-work accounting. The current wide witness only closes its actual positive-epsilon PreLN/ordinary-softmax interface.

Rejected shortcut: reusing the fixed-width compiler's nonzero padding of size sqrt(d) in a growing-width model while asserting a uniform full-state norm. The new route instead counts inert zeros in d and proves restoration distortion 7Z^3/(12d). Inert width is not free: full dense parameter bits, activation storage and matrix work grow accordingly.

Rejected shortcut: forgetting that the old nonterminal probability registers need not form a simplex. The wide log preparation clips every coordinate to [a,1] and asserts floor contraction only at the actual terminal.

Rejected shortcut: calling width O(N), wide values and O(N^3 log N) dense work the same complete resource budget as the old constant-width/scalar-value program. The shared normalization, norm and mask contract does not make width and work equal. The wide example refutes a width-blind R^2 D claim, not the open fixed-width frontier.

## 4. Genuine-source average versus encoded hard histories

The earlier TERMINAL_SIMULATION_OBSTRUCTION v2 encodes hard communication words into balanced blocks; its lower is worst-history. The later LOW_RISK_TERMINAL_OBSTRUCTION v2 adds a rare marker: it remains uniformly consistent while worst-history communication is hard, but admits a source-average simulator with exponentially small error. NORMALIZED_NONLINEAR_OBSTRUCTION v2 aligns the hard program with true PreLN/softmax, yet its standalone prediction risk remains nonvanishing.

The new parity route, if accepted, differs in the averaging law: the hard input is the ACTUAL fair IID source, already in P_c. Its quadratic parity has linear-rank cross interaction under the existing AA/BB ownership. This is not a transfer of a communication-hard distribution to a Markov source by analogy. The direct discrepancy proof uses the actual product measure.

To make risk vanish, a public small logit perturbation carries this nuisance parity on top of the old consistent suffix predictor. It is deliberately statistically unnecessary. A simulator accurate at a small constant multiple of that nuisance amplitude must recover it, while a predictor may ignore it. Therefore this is an obstruction to a universal output-SIMULATION proof strategy, not a statistical-resource lower, new estimator, or nonlinear predictive advantage.

The simulator metric must be expected TV over BOTH genuine history and protocol coins. It is not TV after averaging the protocol's output over coins. A Bob-local final decision is charged as an extra output bit in the rectangle argument. The suffix-baseline information sent during the reduction is charged explicitly.

## 5. External antecedents and no novelty certification

The previously inspected Rajaraman paper (https://arxiv.org/html/2407.17686v1), Ekbote paper (https://arxiv.org/pdf/2508.07208v2), and D'Angelo paper (https://arxiv.org/html/2607.02800v1) already cover few-layer ordered Markov/n-gram representations and separately scoped learning results. None supports claiming that this hand-designed construction is trained or the first ordered predictor.

Hahn's sensitivity analysis (https://aclanthology.org/2020.tacl-1.11.pdf) is a close antecedent for bounded-depth influence reasoning. The current logarithmic-depth programs pay growing total amplification. The corrected supplement has not been re-fetched in this or the preceding comparison rounds.

Triangle/tent folding, interpolation error, positive-epsilon radial normalization, inner-product/Hadamard discrepancy, two-point testing and nuisance perturbations are standard tools. Tent iteration was already explicitly used by the local rare-marker construction. The new parity proof should be evaluated as a contract-checked combination with an explicit fair-IID averaging law, not an originality certification of those ingredients. No exhaustive search establishes priority for the final combination.

## 6. Remaining target

The strong unresolved question is a genuine risk-versus-resources statement for low-risk fixed-width evolving-memory predictors, or a genuinely different estimator that improves the existing fixed-width risk order. Universal exact-output simulation can be too strong because a predictor may carry irrelevant hard output noise. A future lower must either tolerate/remove that noise at a quantified cost, restrict the output class for a substantive reason, or use a method not requiring approximation of every predictor's exact output. No arbitrary restriction or assumed cheap simulator is smuggled in here.
