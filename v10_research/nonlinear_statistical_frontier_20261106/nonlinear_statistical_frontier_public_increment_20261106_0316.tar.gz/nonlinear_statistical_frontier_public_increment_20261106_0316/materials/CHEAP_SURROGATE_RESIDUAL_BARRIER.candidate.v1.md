# A direct residual barrier for cheap complete-output surrogates

6 November 2026 UTC. Candidate v1. Immediate triangle-inequality corollary of the independently reviewed IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md; no new communication theorem or statistical minimax lower. No experiment or model execution.

## Statement at the actual risk scale

Use exactly that theorem's source-independent fixed-width physical predictor Q_N, N divisible by four, old AA/BB ownership, public b=Theta(log N), rho=Theta(b^-1/2), and fixed positive kappa_c. Its actual worst-source prediction risk is Theta_c(rho). Let P_0 be the fair IID source.

Let Q_s(X) be any publicly specified normalized deterministic surrogate output, and suppose a randomized interactive simulator of Q_s communicates at most C bits on every input/coin tape and satisfies

 E_(X~P_0,coins) TV(Qhat_s(X),Q_s(X)) <= epsilon.

Define the output residual

 Delta_0=E_(X~P_0) TV(Q_s(X),Q_N(X)).

If C+b < (N/2-1)/2-2, then necessarily

 epsilon+Delta_0 > kappa_c rho/100.                    (1)

Proof: if the sum were at most that threshold, triangle inequality would make the same protocol a simulator of Q_N satisfying the main theorem's error hypothesis. Its communication conclusion would contradict the displayed strict upper bound on C+b. The simulator's coins are averaged INSIDE TV. No equivalence between output averages and average output error is used.

In particular, if epsilon<=kappa_c rho/200, then Delta_0>kappa_c rho/200. Any uniform source-class residual Delta=sup_(P in P_c) E_P TV(Q_s,Q_N) is at least Delta_0. Thus no such low-communication COMPLETE-OUTPUT surrogate has Delta=o(rho).

## Relation to the previous evolving-memory certificates

The prior COMMON_CONTROL_SIMULATION and AVERAGE_DEFECT_TRANSFER give a source-independent simulator for a certified closed surrogate and a sufficient weighted row-error certificate B(X) for its final TV discrepancy. If that surrogate and simulator fall below the communication threshold above at epsilon=O(rho) with a sufficiently small constant, then

 E_(P_0) B(X) >= Delta_0 > kappa_c rho/200.

Therefore that particular certificate cannot establish an o(rho) residual for this family. This does not invalidate the hybrid theorem; it shows why its small-residual hypothesis cannot follow from uniform statistical consistency alone. A row approximation that does not purport to control the complete final output is outside (1). A surrogate whose simulation cost is already Omega(N) is also outside the cheap-surrogate conclusion.

For the optional inverse-polynomial amplitude alpha_N family, apply the same argument with the corresponding derivative constant and alpha_N threshold. Its risk is bounded by the old suffix risk plus O(alpha_N), and alpha_N->0 preserves consistency. Choosing an amplitude at a proposed inverse-polynomial residual scale can therefore block a generic claim of an o(alpha_N) complete-output residual with only polylogarithmic communication. Its total prediction risk need NOT be Theta(alpha_N) unless alpha_N is comparable to the old suffix risk; do not conflate those scales.

This corollary proves a failure of a universal simulation-based proof route, not a risk-resource impossibility theorem for statistically useful prediction. Ignoring the removable parity nuisance recovers the old cheap suffix predictor. A future lower can still use a statistical comparison that tolerates the nuisance, or a different method, provided the error scale and conclusion are justified rather than assumed.
