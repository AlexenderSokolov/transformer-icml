# Independent exact-file audit: growing-width PreLN statistical witness

6 November 2026 UTC. Analytical review, independent of the candidate author. No experiment, model execution, numerical diagnostic, parameter-generation run, training, or upload was performed. Shell activity was limited to source inspection and file hashing; this report is documentation.

## Verdict

PASS for `WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md`, SHA-256 `28d7230b9b6b131daa05f6d5a58b3a26d562ca54845e09db13ff9785f5d39e0e`, under its explicit exact-real, fixed-interior-source, growing-width, bounded-operator/full-state contract and imported statistical theorem.

The accepted conclusion is a source-independent binary family with positive-epsilon full-feature PreLN, ordinary vocabulary softmax, O_c(N) width, O_c(log N) paid depth, two pathwise useful uniform-attention invocations, uniformly bounded complete per-row and primitive norms, and inherited O_c(N^(-1/2)) actual-terminal TV risk. This closes this particular normalization/output-interface gap for the wide construction. It is not a new estimator, rate, fixed-width result, execution certificate, or novelty certification.

## Preserved earlier qualification

Version 1 is unchanged at SHA-256 `4c6dbbc92c3811c446cd0e5dfc9ad118775be276cef578dcac4ac8e6f0435154`. Its main compilation and risk calculations checked, but its assertion of two useful reads lacked common approximation control for the physical ablations. `INDEPENDENT_WIDE_PRELN_EARLY_AUDIT.v1.md`, SHA-256 `4401670eec0a98d97ac11b50ad9044d8e0963340c3970536d44ddc851975b6b9`, preserves that qualification. Revision 2 fixes it rather than retroactively changing version 1. There was no discovered counterexample to the principal norm/risk construction.

## 1. Imported reference and all-row bounds

The exact logical input interface is raw local symbols, public positions, and one synthetic terminal. All predecessor extraction, triple counting, context selection, denominator selection, amplification, and reduction occur inside the paid network. The imported scaled selectors and token fanouts have bounded full norms; diagonal saturation and balanced reduction charge their O(log N) sequential stages. Two wide uniform reads suffice.

The old logical output is a simplex only at the terminal. At other rows its at-most-two supported denominator blocks keep the complete state bounded but need not normalize the output. Revision 2 correctly clips every coordinate to [a,1] before the logarithm. At the terminal this equals lower flooring of add-one and preserves the binary TV contraction for true probabilities at least a. No all-source, zero-floor, ordinary-bounded-logit consistency is asserted.

The inherited full-history expected-TV bound is for the actual terminal context of the same observed history, with arbitrary initial-pair law. No independent query pair or conditional-binomial assumption is inserted during composition.

## 2. Parallel logarithm and parameter norms

For a fixed interval [a,1], the secant interpolation error is at most `(1-a)^2/(8a^2 m^2)`. Adjacent slope changes have absolute size at most `(1-a)/(m a^2)`. Dividing every hinge input by R=Theta(sqrt(m)) makes the full fanout and bias norms bounded. The corresponding output coefficients R c_j have squared sum O_c(1), so their complete output-row norm is bounded as well. Both the FFN hidden vector and the final logit vector are uniformly bounded, not only their individual coordinates.

Rounding b,s_0,c_j to absolute error at most m^(-3) introduces at most `(m+1)m^(-3)<=2m^(-2)` function error. Hence the revision's `K_c=2+(1-a)^2/(8a^2)` and `m>=sqrt(128K_c) N^(1/4)` imply the displayed `N^(-1/2)/128` logit bound. Knot, scale, and rounded coefficient descriptions use O_c(log N) bits. No logarithm primitive is hidden at execution time.

The parallel stage costs O_c(N^(1/4)) extra coordinates and only a constant number of ordinary affine/ReLU stages. This is precisely why the serial logarithm's O(N^(1/4)) depth is unnecessary in a family already paying linear width.

## 3. Homogeneous shallow FFNs and the complete prepared state

Replacing bounded affine biases by columns multiplying a preserved anchor has bounded full operator norm because the original full bias vector is bounded. Signed-ReLU identities implement linear cancellation with fixed operator overhead independent of dimension. Selective ReLU overwrites similarly use bounded affine forms together with signed copies of the overwritten coordinates. Thus a fixed number of standard shallow FFN blocks implements each primitive; an uncharged deep decoder is not being inserted.

Pairing all registers makes the full feature mean exactly zero, including scratch and attention destinations. On this invariant subspace the normalization factor is exactly `(1+eta^2 ||z||^2/d)^(-1/2)`. Positive homogeneity gives the stated residual update, and its deviation from the logical overwrite is O_c(eta^2/d). Each uniform read has the same order of local error in maximum-row full-vector norm, independently of its value dimension.

The common reference program includes both reads, all logarithm work, copies, and every scratch clear. Clearing the anchor last is legitimate because no later reference bias consumes it. The physical clears may leave nonzero errors; the proof bounds their entire vector before selecting restoration. A common bounded tube for the original program and both ablations makes the error recurrence valid without assuming physical selectors or counts remain on an exact lattice. With O_c(log N) stages, the smallest adequate small-amplitude exponent M is O_c(log N).

Changing interior gain one to gain two and halving each consuming first FFN/value matrix is exact. Queries and keys are zero. Both branch-input LNs remain present even in blocks whose corresponding branch is zero.

## 4. Restoration and final conventional output

I independently derived the geometric restoration estimate before reading the candidate. With `h_0=2^(-M)u`, each step is radial and has gain at most two, so `||h_k||<=2^(k-M)||u||`. Comparing with ideal doubling gives

    delta_(k+1)<=2 delta_k+||h_k||^3/(2d).

Summing with the later doubling weights gives exactly

    delta_M<=||u||^3(1-4^(-M))/(12d).

The final gain-two LN followed by half-projection adds at most `||u||^3/(2d)` beyond that restoration error. Including preparation error xi yields `xi+7||u||^3/(12d)`. No M/d term, sqrt(d)-norm padding register, inverse-eta matrix, or ignored residual scratch is required.

The chosen `d>=256(Z+1)^3 N` and `xi<=N^(-1/2)/256` give

    xi+7(Z+xi)^3/(12d)
      <=[1/256+7/3072]N^(-1/2)
      <N^(-1/2)/128.

Every physical restoration state has norm at most ||u||, and final-LN outputs have norm at most 2||u||. This reachable bound, rather than the generic 2 sqrt(d) ceiling, proves the required uniform full-vector control. The actual output is a bounded affine vocabulary head followed by ordinary softmax; it is not an approximate probability register interpreted as already normalized.

## 5. Physical usefulness of both reads

Deleting the first logical read leaves its broadcast bank zero. Saturation keeps it zero, destination gates vanish, and predecessor and triple/count rails vanish. Deleting the second read leaves its fresh histogram bank zero. In both cases the zero-count denominator branch returns (1/2,1/2) at every row, with legal bounded states.

On the all-zero N-symbol history, the intact add-one estimate is `((N-1)/N,1/N)`. After floor a<=1/4 its second probability remains at most 1/4, so its TV separation from uniform is at least 1/4. The same eta, width, and restoration schedule approximate each of the three complete programs within `N^(-1/2)/64<1/32` in TV of its ideal floored output. Each physical single-read ablation therefore changes the output by at least 3/16. This resolves the version-1 qualification. It establishes usefulness in this implementation, not a minimum required head count.

## 6. Resource and precision accounting

The dimensions and O(log N) stages give conservative dense parameter coefficients O(N^2 log N), description bits O_c(N^2 log^2 N), rolling all-row real states O(N^2), and dense projection/FFN work O(N^3 log N). Explicit LayerNorm gain/shift storage O(dD) is included. Dummy attention evaluated densely also costs O(N^3 log N); skipping it or exploiting exact uniform prefix sums is a separately stated execution convention. Sparse coefficient storage includes O(N log N) nonzero entries and can also pay their O(log N)-bit indices without changing its stated bit order.

The gain convention is explicit: scalar gain two represents a diagonal operator of norm two. The theorem does not satisfy a different rule bounding the Euclidean norm of the entire length-d gain-parameter vector. Likewise, the per-token state bound is not a bound on all-token Frobenius norm or total distributed memory.

The optional all-dyadic parameter approximation correctly aggregates coordinate errors into O(d delta_N) matrix-operator error and O(sqrt(d) delta_N) bias error. A fixed sufficiently large exponent absorbs O(log N)-stage polynomial sensitivity and can allocate the approximation within the same error budget. Pairing, anchors, and zero attention scores can be retained exactly. The rounded core is only an approximation to the exact rational reference. Neither version certifies arithmetic rounding during actual evaluation, exact finite-word LN/softmax, or trained realization.

## 7. Scope of the consequence

The accepted family has `risk^2 * depth = O_c(log(N)/N)`. It therefore refutes a positive width-independent risk-squared-times-depth lower for this sufficiently permissive growing-width contract. It does not refute bounds charging width, head value dimension, decoder gain/precision, distributed state, or total work, and does not settle the fixed-width/scalar-value arbitrary nonlinear memory problem.

The rate comes from the old add-one theorem. Combined with the separate elementary IID sample lower, it gives the familiar N^(-1/2) minimax order for the now-admissible sufficiently large resource class. The inherited fixed-error context lower remains compatible with O(log N) depth. No sharp width-depth-risk frontier or external priority claim follows.

## Exact dependency bindings inspected

- Parallel logical construction: `../parallel_width_depth_20261104/CANDIDATE.v2.md`, SHA-256 `d69f471e0bf6c6f585b0772bdbdea688113cdaeefdd2028bd8b1c6b8b65eaf71`.
- Full-history terminal TV theorem: `../terminal_tv_constant_20261104_0800/terminal_tv_direct_bound.candidate.v1.md`, SHA-256 `483c68261576aba3ecd3ea4a1ca197eb69159a77ae146bd82b6d8514060ac574`.
- Earlier unnormalized composition: `../logdepth_matching_private_20261104/MATCHING_ORDER.v2.md`, SHA-256 `518cb4544ed227bfdb1e808c5d685a669a0d7ba6fe81632e847175af024eb82a`.
- Fixed-width PreLN baseline: `../standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md`, SHA-256 `b71f919d6ad1f9c5038270090a3ca724b4e7cb7f9074ecf060433a1961b737e5`.
- Fixed-floor ordinary softmax baseline: `../softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md`, SHA-256 `6d61e56d8e9ecea7c1a4a76c6e839f3cdc91576161e99f133febedfe03b5faa5`.
- Complete-preparation/two-read precedent: `../ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md`, SHA-256 `a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2`.

These bindings identify the inspected sources, not a closed reproduction bundle or independent reproof of every historical dependency. Acceptance applies only to the exact candidate bytes above.
