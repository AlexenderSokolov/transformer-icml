# Independent exact-file audit: cheap-surrogate residual barrier

6 November 2026 UTC. Analytical review only. No scientific executable, numerical diagnostic, model execution, parameter generation, upload or public mutation was performed.

## Verdict and binding

**PASS.** This is a valid triangle-inequality corollary of the accepted IID nuisance theorem, with its stated error scale, ownership, communication model and output metric retained. No correction is required.

Reviewed file: `CHEAP_SURROGATE_RESIDUAL_BARRIER.candidate.v1.md`.

SHA-256: `de92ba9186fe27dd36c1f9323640b83cfd2fe0401c55b39cc9a8550fe5424475`.

The main dependency remains unchanged:

`IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md`, SHA-256 `ef9ce668cd9815e45501194198177c7acdc369894a50e3b31aebb5baaa340767`.

Its exact-file acceptance, inherited-lemma conditions and preserved v1 numerical correction are recorded in `INDEPENDENT_IID_QUADRATIC_NUISANCE_AUDIT.v1.md`. This corollary does not expand that theorem's architecture or statistical scope.

## 1. Direct reduction and strict inequalities

Let Q_s be the publicly specified deterministic normalized surrogate and let its simulator output Qhat_s. Pointwise triangle inequality gives

    TV(Qhat_s,Q_N) <= TV(Qhat_s,Q_s)+TV(Q_s,Q_N).

Averaging over the SAME fair-IID history and independent simulator coins yields expected error at most epsilon+Delta_0. Because Q_s is deterministic, the second term has precisely the stated history-only expectation. The simulator can be reused without changing its messages, output, bit cost or coin law.

If epsilon+Delta_0 were at most kappa_c rho/100, the accepted main theorem would imply C+b>=(N/2-1)/2-2. This contradicts the corollary's strict upper bound on C+b. Therefore its conclusion is the strict inequality

    epsilon+Delta_0 > kappa_c rho/100.

The threshold's strictness is correctly oriented. In particular epsilon<=kappa_c rho/200 implies Delta_0>kappa_c rho/200, including the equality case for epsilon. Since fair IID belongs to P_c, the supremum source-class output residual is at least Delta_0. For b=Theta(log N), any polylogarithmic communication bound is eventually below the linear threshold.

The result concerns expected TV with the loss inside the simulator-coin expectation. TV of a coin-averaged output, or a distance between unconditional output marginals, would not support this implication. The corollary preserves this distinction. It also retains worst-case cost on every input and coin tape, not expected communication or an uncharged timing channel.

## 2. Weighted row-error certificates

I inspected the current `AVERAGE_DEFECT_TRANSFER.candidate.v3.md`. Under its hypotheses it proves the pathwise bound

    TV(Q_s(X),Q_N(X)) <= B(X).

Consequently E_(P_0) B>=Delta_0, which is all the corollary needs. If the certified surrogate's simulator satisfies the small-error and communication premises, its certificate must therefore have expectation strictly greater than kappa_c rho/200. It cannot certify an o(rho) complete-output residual on this family.

This application is expressly conditional on the earlier certificate's full hypotheses, including common initial terminal state, matching read schedule and self terms, declared full-prefix masks, bounded interpolated banks, appropriate off-trajectory domains, and gains controlling the complete normalized output. The new corollary does not assert that an arbitrary row approximation automatically has such a B. It does not require the closed surrogate to be physically realizable as a network.

The earlier common-control simulator is one-way, which is included in the new hardness theorem's larger interactive model. Thus no invalid one-way information inequality is being substituted for a two-way transcript theorem here.

Current documentary bindings:

- `../evolving_common_control_20261106/AVERAGE_DEFECT_TRANSFER.candidate.v3.md`: `b5635587be993ddb209c5f0ea54c72ca7d362c13a57cc0b35b25dd654e92cd29`.
- `../evolving_common_control_20261106/COMMON_CONTROL_SIMULATION.candidate.v2.md`: `fd8024b004920fceaa91147cffed4216bbb13e29aba26d3ba9d54deb882c9c15`.

The certificate's published probability-testing consequence and full transitive simulation proof are not needed anew for the direct triangle corollary. The application only uses its stated simulability and pathwise B bound under their existing hypotheses.

## 3. Amplitude variant and limits

For the optional inverse-polynomial amplitude alpha_N, the same argument uses the corresponding positive derivative constant and an error threshold proportional to alpha_N. A claimed o(alpha_N) residual together with a sufficiently accurate polylogarithmic-cost simulator would eventually contradict that threshold. This is conditional on the simulator's own error being a sufficiently small fraction of alpha_N; a large O(alpha_N) constant alone would not suffice.

The candidate correctly does not infer total risk Theta(alpha_N) when the old suffix-estimation error dominates. The main rho choice has actual risk Theta_c(rho), while the amplitude variant merely preserves consistency when alpha_N tends to zero and b tends to infinity in the stated regime.

Finally, this blocks only universal cheap COMPLETE-OUTPUT surrogates at the specified fine error scale. It does not disprove the old hybrid transfer theorem, force statistical information to be expensive, or establish a fixed-width risk-resource lower. A nuisance-tolerant statistical comparison can discard the removable parity perturbation and remains outside the claimed obstruction. The frozen candidate states these limits correctly.

Acceptance binds the exact corollary and dependency hashes above. The main v3 candidate was not modified.
