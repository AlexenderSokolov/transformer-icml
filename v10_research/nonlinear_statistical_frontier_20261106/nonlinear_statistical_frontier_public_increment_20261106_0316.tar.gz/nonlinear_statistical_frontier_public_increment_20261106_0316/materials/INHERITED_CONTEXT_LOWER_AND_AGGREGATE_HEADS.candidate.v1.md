# Inherited terminal-context lower and aggregate multihead accounting

6 November 2026 UTC. Analytical candidate and provenance clarification. No model execution, simulation, numerical experiment, training, upload, or repository mutation was performed. Creating these local notes and hashing inspected source files is documentation only. This is NOT a new statistical rate or a newly discovered logarithmic-depth obstruction. The terminal-context mechanism, source weighting, synthetic-terminal recurrence, positive-epsilon inheritance, and fixed-target extension already occur in the sources listed below. The explicit aggregate-QKV calculation in Section 2 fills out a resource interpretation, not a new statistical frontier. Independent exact-file review of this note is still required.

## 1. Contract and the head-count distinction

There are N raw-symbol rows and a synthetic row T=N+1 initialized from public metadata only. Each observed initial row depends on its own symbol and public metadata. Replacing one symbol changes that row's complete initial vector by at most Delta. No uncharged local pair feature, terminal-symbol side port, or other-row readout is supplied. Every useful attention mask is the full self-inclusive prefix. Parameters can depend on N and even on the source, but are fixed during a prediction. All row-local operations are uniformly Lipschitz, with their number charged to depth. This includes nonlinear FFNs and full-feature positive-epsilon LayerNorm.

For one standard multihead block let z=LN(h), let Q(z), K(z), V(z) be the FULL concatenations of all head query/key/value vectors, and let W_O act on the full concatenated attention output. Assume, uniformly over all relevant rows and blocks,

    ||Q(z)|| <= Q0, ||K(z)|| <= K0, ||V(z)|| <= V0,
    Lip(Q o LN) <= LQ, Lip(K o LN) <= LK,
    Lip(V o LN) <= LV, ||W_O|| <= O.

Every head logit row has range at most B; put C=exp(B). Logits are the standard scaled dot products plus public position biases. A head's scale tau_h=1/sqrt(d_h) is at most one. Public biases do not change when the history changes. Set SQ=K0 LQ and SK=Q0 LK. All the displayed constants are frozen independently of N, depth, width, and the number H of heads.

These assumptions follow from frozen operator and FULL bias norms for the CONCATENATED Q/K/V maps, frozen complete hidden norms, and a positive fixed LN epsilon with bounded gain/shift. They do NOT follow merely from separate bounds on each head. Bounding every displayed head matrix by M permits the concatenated operator norm to grow as sqrt(H). A growing-H claim must state which convention is frozen.

For LN(h)=diag(gamma) P h / sqrt(epsilon+||P h||^2/d)+beta, with P the orthogonal mean-centering projection, its global Euclidean Lipschitz constant is at most ||gamma||_infinity/sqrt(epsilon). This follows by differentiating the radial map after P: its tangential eigenvalue is at most 1/sqrt(epsilon), and its radial eigenvalue is smaller. It is dimension independent. For epsilon=1 and scalar gain two the bound is two.

## 2. Full-concatenation sensitivity, with no H factor

Compare two reachable histories, and write delta_i=||h_i-h'_i||. Let s_i=(s_hi)_h be the vector of all head scores to one source position i. By splitting the bilinear score difference and applying Cauchy-Schwarz across head blocks,

    ||s_i-s'_i||_2 <= SQ delta_t + SK delta_i.              (A1)

For example, the query-change term is bounded by

    [sum_h ||q_ht-q'_ht||^2 ||k_hi||^2]^(1/2)
      <= K0 ||Q_t-Q'_t|| <= SQ delta_t.

No factor sqrt(H) enters. Independent per-head softmaxes are retained; they are not replaced by one softmax over head/position pairs.

Interpolate only the two score arrays: s(u)=(1-u)s+u s'. Each head score range remains <=B, so alpha_hi(u)<=C/t. Hold the primed values fixed during this interpolation, and write o_h(u)=sum_i alpha_hi(u) v'_hi. Each head value and o_h(u) have norm <=V0, because each block of a bounded full value vector has norm <=V0. The softmax derivative is exactly

    d o_h(u)/du = sum_i alpha_hi(u) (v'_hi-o_h(u)) (s'_hi-s_hi).

For a fixed source i, the Euclidean norm of the concatenated summand is at most

    (C/t) || ((v'_hi-o_h(u))(s'_hi-s_hi))_h ||_2
      <= (2CV0/t) ||s'_i-s_i||_2.

Minkowski and (A1), followed by integration, bound the score-change part of the complete concatenated output by

    2CV0 SQ delta_t + (2CV0 SK/t) sum_(i<=t) delta_i.

The value-change part is bounded by

    ||sum_i diag_h(alpha_hi)(v_i-v'_i)||_2
      <= (CLV/t) sum_(i<=t) delta_i.

Thus the full multihead attention output obeys

    ||o_t-o'_t||_2 <= 2CV0 SQ delta_t
                       + C(LV+2V0 SK)/t sum_(i<=t) delta_i.  (A2)

This proof uses endpoint value vectors and interpolation of logits only; it does not assume that a hidden-state interpolation is a reachable network state. It also includes attention-weight variation, not only value variation.

Let F bound the Lipschitz constant of the subsequent row-local residual FFN, including its LN. For a standard two-affine/ReLU FFN one valid choice is

    F = 1 + ||W_2|| ||W_1|| Lip(LN).

Including attention residual, output projection and FFN yields

    delta_t^(ell+1) <= a delta_t^ell
                         + (b/t) sum_(i<=t) delta_i^ell,   (A3)
    a = F(1+2OCV0 SQ),
    b = F O C(LV+2V0 SK).

These a,b are independent of H under the aggregate assumptions. More general row-local nonlinear primitives can replace the FFN provided their uniform Lipschitz constant is charged, and a fixed number of primitives per stage can be absorbed into fixed constants. An N-dependent deep circuit cannot be hidden in F.

If instead only each head has bounds V, V_L, S_Q, S_K, the same proof separately per head gives a valid weaker alternative

    a_H = F(1+2 O sqrt(H) C V S_Q),
    b_H = F O sqrt(H) C(V_L+2V S_K).

The historical sum-norm recurrence with H instead of sqrt(H) is also valid. Frozen H makes either constant uniform. If H grows and only per-head budgets are frozen, retain the H-dependence; no H-uniform logarithmic-depth conclusion has been established by these inequalities. Full norms of projected reachable states alone do not supply the missing aggregate derivative bound.

## 3. Conventional vocabulary softmax is a valid readout

Let final logits be W_out LN_out(h_T)+b_out, or W_out h_T+b_out if there is no final LN. Write L_out=Lip(LN_out), or L_out=1 in the second case. For any logit direction v and probability p=softmax(z),

    ||D softmax(z) v||_1
      = sum_j p_j |v_j-sum_k p_k v_k|
      <= sqrt(Var_p(v)) <= ||v||_2.

Integrating along the segment gives

    TV(softmax(z),softmax(z')) <= (1/2)||z-z'||_2.

Therefore the terminal readout is G-Lipschitz into TV with G=||W_out|| L_out/2. This bound is dimension independent; it does not rely on target distributions having a positive floor. A separately counted row-local readout stack multiplies G by its actual Lipschitz product or can be included in the depth recurrence. A discontinuous argmax or uncharged inverse-small-signal decoder is not permitted.

## 4. Existing three-row and source-average argument

Replace only X_(N-1)=X_(T-2). Causality forces equality before T-2, and the synthetic row starts equal. Applying (A3) to the remaining three rows, let c_T=a+b/(T-2). The old nilpotent expansion gives the output-TV upper bound

    E_T(D)=G Delta [ bD/T c_T^(D-1)
                + b^2 binom(D,2)/(T(T-1)) c_T^(D-2) ].    (A4)

Omit the second term when D=1. At D=0, b=0, G=0, or Delta=0 the terminal influence is zero; no negative powers are evaluated in those cases. One can always enlarge a to a positive constant before using the displayed expression. Nonuniform per-layer constants can be bounded by the same frozen a,b.

Use the already established stationary lag-two source

    X_t=X_(t-2) XOR E_t, E_t iid Bernoulli(q), 0<q<1/2,

with uniform independent initial pair. Its pair stationary law is uniform and its two-step Doeblin coefficient is at least 4q^2. For N>=4 condition on (X_1,...,X_(N-2),X_N). The two possible values of X_(N-1) have probabilities q and 1-q, in some order, not generally 1/2 and 1/2. This is because E_(N-1) is independent of E_N and the preceding prefix. The two target laws have TV distance 1-2q. Triangle inequality and the smaller conditional weight prove

    E TV(output,p_actual) >= q[1-2q-E_T(D)]_+.             (A5)

At N=3 the weights are 1/2,1/2 and the weaker q-weight bound remains valid. The result holds with source-dependent weights, so it also holds for unknown-source predictors. Independent random seeds are handled by conditioning first, provided the architectural constants hold seedwise.

For q=1/4, the asymptotic floor under D=o(log N) is 1/8. For any fixed r<q(1-2q), risk<=r requires E_T(D)>=1-2q-r/q>0. With frozen a,b this implies D=Omega(log N); one may enlarge a to any fixed a'>max(1,a) to avoid degenerate inversion. This is exactly the old terminal-context lower with its already-known source weights, now using the explicit aggregate-head constants. It is not a width lower or an accuracy frontier once D is logarithmic.

## 5. Interior-source specialization is also inherited

The current binary ordinary-softmax constructions use a fixed c in (0,1/2) and transition probabilities in [c,1-c]. The q=1/4 witness belongs only when c<=1/4. Do not silently use it for a larger c. One may use q=c for every 0<c<1/2, obtaining the positive threshold c(1-2c) in (A5).

The already-existing terminal-suffix extension yields the stronger fixed-target range without inventing a new mechanism. Set lambda=1-2c and choose the stationary refresh-copy source

    p_u = lambda delta_u + (1-lambda) Uniform({0,1}).

Its transition probabilities are exactly c and 1-c. Hide the last k symbols of the parity chain ending at X_(N-1), while conditioning on the earlier prefix and the other parity chain. Their terminal hidden bit has law lambda^k delta_u0+(1-lambda^k) Uniform({0,1}). The exact constant-output conditional Bayes risk is

    R_* = lambda(1-lambda^k)/2.

Every completion differs only within the final 2k observed rows. The inherited suffix influence envelope is

    E_(T,D,k)=G Delta (2kbD/T)
                         [a+2kb/(T-2k)]^(D-1),

and risk >=[R_*-E_(T,D,k)]_+. For every fixed r<1/2-c, choose fixed k with R_*>r, obtaining D=Omega(log N) under (A3). The uniform predictor has worst-case TV <=1/2-c over binary rows in [c,1-c], so this covers all nontrivial fixed targets for that interior source class. It remains an immediate specialization of SUFFIX_EXTENSION.v2, not a new depth/accuracy theorem. Use N>=2k+2 and handle zero-depth/zero-influence cases separately.

## 6. What remains open and what must not be claimed

This does not distinguish one, two, or many useful attention invocations at paid depth O(log N). It does not improve the inherited suffix estimator's rate, prove an accuracy-dependent width lower, or show a statistical limitation of arbitrary nonlinear evolving memory at the already-feasible logarithmic depth. Worst-history communication hardness does not become a source-average prediction lower merely because every hard history has positive source probability. Positive epsilon and standard output softmax do not turn that invalid inference into a valid one.

The aggregate-H extension is conditional on bounded CONCATENATED maps. The historically frozen source contract initially permitted one head; adding arbitrary many independently budgeted heads changes the comparison class. Fullnorm language must be resolved at the concatenation boundary before treating (A3) as a same-model statement. For fixed bounded H, the original multihead argument already suffices without this refinement.

There is no new statistical improvement in this candidate. Its value is to prevent duplicate work and to spell out head accounting, output-softmax regularity, and the correct interior-source witness.
