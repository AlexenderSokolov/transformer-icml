# Nonlinear statistical frontier: source-average simulation counterexample

6 November 2026 UTC. Local analytical increment only. No upload, publication, purchase, model execution, numerical/statistical experiment, finite-rational enumeration, parameter-generation execution or training occurred in this increment. Document build/static validation is separate. The prior increment's preserved 288-case algebra check does not certify the present results.

## Main source and result

IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md, with its exact-version independent audit, constructs a fixed-width actual positive-epsilon PreLN/ordinary-softmax predictor with three scalar uniform reads, O_c(log N) depth, and actual risk Theta_c(1/sqrt(log N)). Under genuine fair IID input and the old AA/BB ownership, small-risk-fraction average output simulation still requires Omega(N) communication. The metric averages TV inside both input and protocol-coin expectations. An optional two-invocation version has value dimensions (2,1), not two scalar heads.

The hard component is deliberately useless vanishing logit noise. This disproves a universal cheap COMPLETE-OUTPUT simulation claim, not a statistical minimax lower or a new estimator/rate. Removing the noise recovers the old suffix predictor. CHEAP_SURROGATE_RESIDUAL_BARRIER states the direct consequence for o(rho) complete-output residual certificates.

## Other scoped findings

- WIDE_PRELN_STATISTICAL_WITNESS v2 closes the old O(N)-width, O(log N)-depth full-history estimator in the actual LN/softmax contract, with inherited O_c(N^-1/2) risk. It uses zero coordinates and dimension-diluted restoration, not forbidden growing-norm padding. It refutes width-blind R^2D bounds only; dense work and state are much larger.
- INHERITED_CONTEXT_LOWER_AND_AGGREGATE_HEADS v1 clarifies aggregate versus per-head norm budgets. The Omega(log N) context-depth lower and positive-epsilon inheritance were already established; this is not a new frontier.
- STATISTICAL_SCOPE_AND_SAMPLE_FLOOR v1 explains why pointwise-equivalent pure-square coding cannot improve output loss, and states the standard architecture-free N^-1/2 sample floor.
- PRIOR_WORK_AND_REJECTED_INFERENCES plus CONTEXT_ROUTE_PROVENANCE_AND_FAILURE preserve exact prior overlap and failed inference routes.

## Preservation and limitations

All candidates and audits are exact-version bound. Preserve IID v1's incorrect 100rho envelope and its failure audit; v2 fixes it to 200rho; v3 additionally checks the merged-head ablations. Preserve wide v1 and its missing-usefulness qualification; wide v2 supplies the common original/ablation tube and physical margins. Historical pending labels are not final acceptance statements.

The source and document contain no claim of a better statistical rate, trained realization, optimal fixed-width frontier, generic nonlinear compression, finite-precision reliability, PostLN inclusion, exhaustive novelty certification or external peer review. External-literature comparisons reuse explicitly recorded previous primary checks rather than pretending a fresh retrieval.

The final report is RESEARCH_REPORT.zh.v1.html, accompanied by REPORT_SOURCE_BINDINGS.v1.json, REPORT_HTML_QA.v1.json and a separate text/privacy audit. It embeds exact proof/audit texts; hashes only bind sources and versions. No visual-render acceptance is claimed.
