# A full-history statistical witness with growing width in the actual PreLN model

6 November 2026 UTC. Analytical candidate v2, awaiting independent exact-file review. Version 1 is preserved at SHA256 4c6dbbc92c3811c446cd0e5dfc9ad118775be276cef578dcac4ac8e6f0435154. This revision makes both reads' ablation usefulness explicit and charges LayerNorm parameter storage. No experiment, model execution, parameter-generation run, external publication, or repository upload was performed. The statistical estimator and its rate are inherited. The extension proved here is a growing-width, bounded-full-norm positive-epsilon PreLN compilation with an ordinary vocabulary softmax.

## 1. Statement, source class, and frozen contract

Fix c in (0,1/2). Let P_c be the homogeneous binary second-order kernels for which both probabilities in every transition row are at least c, with arbitrary initial-pair distributions. Observe raw one-hot symbols X_1,...,X_N, N>=4, followed by one synthetic zero-symbol row T=N+1. Public positions are t/P, with P=2^ceil(log2 T). All other input registers are zero except a public constant anchor. There are no supplied pairs, counts, suffixes, target rows, or sample-dependent weights.

There is one sufficiently large finite envelope C(c), frozen independently of N, and a source-independent, length-dependent, untied family with:

- actual causal PreLN residual blocks, each LayerNorm having epsilon=1, coordinate gain 2 and shift zero;
- ordinary self-inclusive full-prefix softmax attention, one head per block, exactly two useful attention invocations, and identically zero scores;
- complete model width d=O_c(N), FFN intermediate width O_c(N), and actual counted sequential depth D=O_c(log N);
- all complete per-token state/value Euclidean norms, all matrix operator norms, full bias-vector Euclidean norms, and primitive Lipschitz bounds at most C(c);
- an ordinary final gain-two epsilon-one LayerNorm, bounded affine vocabulary logits, and ordinary vocabulary softmax;
- expected actual-terminal prediction risk

    sup_(P in P_c, mu) E TV(Q_N(X_1:N), p_(X_(N-1),X_N))
      <= min{1, 13 sqrt(32/(N-1)) + C_c N^(-1/2)}.       (1)

Here mu denotes the arbitrary initial-pair law. The envelope is existentially fixed large enough to contain the displayed primitives; no containment in an unchecked preassigned numerical budget is claimed. Gain 2 means the diagonal gain operator 2I has operator norm 2. If instead one additionally bounded the Euclidean norm of the length-d gain-parameter vector, prescribing gain 2 at every coordinate would itself exclude growing d. That different, inconsistent-with-this-family convention is not used.

All computations have exact-real semantics. O(log N)-bit coefficient descriptions are not a finite-precision execution guarantee. A growing-width family is explicitly being purchased; this is not a fixed-width claim.

## 2. Imported full-history logical construction and statistical bound

The deterministic logical circuit is the binary specialization of

    ../parallel_width_depth_20261104/CANDIDATE.v2.md
    SHA256 d69f471e0bf6c6f585b0772bdbdea688113cdaeefdd2028bd8b1c6b8b65eaf71.

Its scaled positional selectors, one wide uniform-prefix broadcast, coordinatewise bounded-gain saturation, destination selectors, balanced binary sum trees, and paid amplitude restoration recover both predecessor symbols at every row. It uses O(N) width and O(log N) bounded affine/ReLU stages. Scaled fanout rather than unscaled duplication controls the full vector, full bias, and operator norms. One head with a wide value vector suffices; growing head count is unnecessary.

Internal triple indicators and the second uniform-prefix attention produce the empirical triple histogram. Internally recovered predecessor rails select the actual terminal context. Its length-dependent denominator selectors and factored bounded diagonal multiplications then give, exactly at T,

    B_j=(C_j+1)/(J+2), j=0,1,

where C_j counts all observed transitions from the actual terminal pair and J=C_0+C_1. The reference is valid on every word. At every nonterminal row at most two denominator selector blocks have support, and each amplified block coordinate is bounded by 2. Consequently the full state remains bounded even though the nonterminal output need not be a probability vector. In particular no claim of a simplex output at every row is imported.

The whole-state bounds, not bounds on individual coordinates alone, and the O(log N) stage count are the properties needed here. Raw shadows, anchors and a constant number of scratch banks add only a constant factor. Converting bounded affine/ReLU primitives to constant-depth residual FFN overwrites also has a fixed factor: a two-layer ReLU branch can retain/cancel old registers using signed ReLU pairs, and each affine bias is represented by a bounded anchor column. The branch that writes F(z)-z is positively homogeneous after this homogenization. Matrix and full-vector norms remain bounded independently of the number of coordinates.

The imported terminal statistical result is

    ../terminal_tv_constant_20261104_0800/terminal_tv_direct_bound.candidate.v1.md
    SHA256 483c68261576aba3ecd3ea4a1ca197eb69159a77ae146bd82b6d8514060ac574.

It gives, for all homogeneous binary second-order kernels and all initial laws,

    E TV(B,p_actual) <= min{1,13 sqrt(32/(N-1))}.          (2)

The source class P_c is a subclass. No independence between the chosen terminal pair and its observed counts is assumed. The reviewed theorem composition in ../logdepth_matching_private_20261104/MATCHING_ORDER.v2.md, SHA256 518cb4544ed227bfdb1e808c5d685a669a0d7ba6fe81632e847175af024eb82a, already combined this logical circuit and this risk rate. Neither the estimator nor the rate is new here.

## 3. Parallel bounded-norm logit preparation

### 3.1 All-row clipping and terminal risk

Choose a fixed negative power of two a with 0<a<=min{c,1/4}. At EVERY row clip each logical output coordinate to [a,1]. Write x_j=clip(q_j,a,1). This is a constant number of bounded affine/ReLU stages. The upper clipping is essential to the all-row log-domain argument because the imported nonterminal q need not be a simplex vector.

At T, q=B is a probability vector, so x_j=max(B_j,a). Define

    Q_floor = softmax(log x_0, log x_1).

For binary p with each coordinate at least a, flooring and renormalizing moves a changed probability toward p without overshooting. For example, if B_0<a, its new value is a/(1+a-B_0), which lies between B_0 and a<=p_0. The other endpoint is symmetric. Thus, pathwise,

    TV(Q_floor,p_actual) <= TV(B,p_actual).               (3)

This contraction is asserted for binary outputs only. The source floor is substantive: uniformly bounded logits cannot uniformly approximate deterministic target distributions with vanishing error. The theorem does not extend (1) to all kernels merely because the unnormalized reference estimator does.

### 3.2 A norm-controlled parallel piecewise-linear logarithm

Put K_c=2+(1-a)^2/(8a^2) and Gamma_c=max{1,sqrt(128 K_c)}. Let m be the smallest power of two at least Gamma_c N^(1/4), so m=O_c(N^(1/4)). Set Delta=(1-a)/m and t_j=a+j Delta, j=0,...,m. Let L_m interpolate log at these knots. With

    s_j=(log t_(j+1)-log t_j)/Delta,
    b=log a-s_0 a,
    c_j=s_j-s_(j-1), j=1,...,m-1,

its hinge representation is

    L_m(x)=b+s_0 x+sum_(j=1)^(m-1) c_j (x-t_j)_+.

Since |(log x)''|<=a^(-2) on [a,1],

    ||L_m-log||_infinity <= Delta^2/(8a^2),
    |s_0|<=1/a,  |c_j|<=Delta/a^2.                     (4)

Choose a power of two R with sqrt(m)<=R<2sqrt(m). Compute all hinges as

    r_j=ReLU((x-t_j)/R).

The scalar fanout matrix has norm sqrt(m-1)/R<=1. Its complete bias vector has norm at most sqrt(m-1)/R<=1. Its complete output vector has norm at most 1 on [a,1]. Combining the hinges with weights R c_j has Euclidean row norm bounded by

    R sqrt(m-1) Delta/a^2 <= 2(1-a)/a^2.               (5)

The direct x coefficient and bias are also O_c(1). Two symbol coordinates only change constants. A constant number of affine/ReLU/residual stages therefore implements both interpolated logs with O(m) extra width, bounded complete states and full parameter norms. There is no hidden norm-sqrt(m) fanout or unbounded final fan-in.

Finite descriptions cause no problem. Approximate b,s_0 and each c_j by dyadics of absolute error at most delta=2^(-p)<=m^(-3), with p=ceil(3 log2 m) plus a fixed constant. The output error from these approximations is at most (m+1)delta=O(m^(-2)). The bound (5) changes by at most R sqrt(m)delta=O(m^(-2)); it remains uniform. All knots, 1/R, and scaled rounded hinge coefficients have O_c(log N)-bit dyadic descriptions. Computing these coefficients is not an executed parameter-generation claim.

Let ell=(ell_0,ell_1) be these approximate logits. Their range and Euclidean norm are bounded solely by c, and at T

    ||ell-log x||_infinity <= K_c m^(-2)
                              <= N^(-1/2)/128.         (6)

For two logits, ordinary softmax followed by TV is Lipschitz with respect to their infinity norm, with constant at most 1. Therefore Q_ref=softmax(ell) has

    TV(Q_ref,p_actual) <= TV(B,p_actual)+C'_c N^(-1/2). (7)

### 3.3 The complete reference must precede amplitude selection

Append copies of ell into a dedicated output bank and clear EVERY other reference register, including old tokens, positions, anchor, histograms, selector banks, hinge banks and scratch. Pair each logical coordinate with its negative. The complete final reference vector is

    z_ref=(ell_0,-ell_0,ell_1,-ell_1,0,...,0).

Clearing the anchor is the last operation; no later reference affine bias requires it. Until then it is exactly preserved. All copies/clears are paid bounded linear/ReLU overwrites. The complete prepared logical program, including both reads, logs and all clears, has length

    m_ref=O_c(log N)

and uniformly bounded complete per-row norm. Also consider its two single-read ablations, each replacing just that read's output by zero and leaving every other parameter and stage unchanged. As proved in Section 5.1, both ablated references have legal all-row count states and return the default uniform output. Choose a common fixed tube radius Z and fixed primitive max-row Lipschitz constant L>=2 for all THREE complete prepared programs before selecting the small amplitude. Adding paired inert zero coordinates makes the actual even model width d satisfy

    256(Z+1)^3 N<=d<=C_c N,

without changing any nonzero vector's norm. These coordinates are counted as width and in dense resources. No nonzero norm-padding coordinate proportional to sqrt(d) is used.

## 4. Small-amplitude PreLN compilation, with full-vector error

Use the paired physical representation h=eta z, where eta=2^(-M). The bounded initial symbol/position embedding supplies the scaled paired raw shadows and anchor. Pairing is maintained by all output branches, including attention; hence the complete vector has exactly zero coordinate mean throughout. On this invariant subspace, epsilon-one gain-one LayerNorm is

    LN_1(eta z)=eta s(z)z,
    s(z)=(1+eta^2||z||^2/d)^(-1/2).

For x>=0, 0<=1-(1+x)^(-1/2)<=x/2. Therefore on the fixed tube

    |1-s(z)| <= eta^2 Z^2/(2d).                        (8)

For a homogeneous residual branch implementing G=F-I, gain-one PreLN gives exactly

    z_new=z+s(z)(F(z)-z).

Its deviation from the desired overwrite F(z) is at most C eta^2/d, using uniform complete-state and branch bounds. This identity does not assume that perturbed counts, selectors or gates retain their exact logical lattice values. Their physical errors are propagated through the continuous affine/ReLU primitives.

For either useful uniform read, the reference update has the form

    z'_t=z_t+B_0 (1/t) sum_(i<=t) A_0 z_i.

The physical normalized update gives instead

    z'_t=z_t+B_0 (1/t) sum_(i<=t) A_0 s(z_i) z_i.

Their local max-row difference is at most

    ||B_0||||A_0|| eta^2 Z^3/(2d),                     (9)

independent of N and of growing value width. Zero Q and K ensure genuinely ordinary softmax weights equal 1/t. The complete source-row normalization factor is retained in (9), not replaced by a token-local shortcut.

A complete standard block has zero dummy attention for a local operation, or zero FFN for an attention operation. A fixed number of standard blocks implements each reference primitive. With e_l the maximum over rows of complete logical-vector error, there are common fixed constants C,L, valid for the original and both ablated programs, with

    e_l<=L e_(l-1)+C eta^2/d,
    e_(m_ref)<=C' eta^2 L^(m_ref)/d.                   (10)

The constants depend on c and the fixed primitive types, not on width or N. Take xi to be the largest dyadic value at most N^(-1/2)/256, and choose the smallest M>=1 for which the coarse sufficient bound C' 2^(-2M)L^(m_ref)<=xi and the common tube constraints hold. Use this SAME eta=2^(-M), width and restoration schedule for all three programs. Because m_ref=O_c(log N),

    M=O_c(log N).

Tube induction is valid because the error stays below a fixed margin about uniformly bounded reference states. Crucially (10) is the error AFTER every output copy and scratch clear. Write the actual final physical vector as

    h_0=2^(-M) u,  ||u-z_ref||<=xi,  ||u||<=Z+xi.     (11)

Approximate scratch clearing causes no gap: its complete-vector residual is included in xi and will be restored along with the output bank.

Convert every interior gain-one LayerNorm to gain two and halve its consuming FFN first matrix or attention value matrix. Q/K remain zero. This exact reparameterization leaves the trajectory unchanged, and all matrices stay uniformly bounded. All actual LayerNorms therefore use the same epsilon=1, gain=2 and shift=0.

## 5. Dimension-diluted amplitude restoration and conventional final output

This is the new replacement for the fixed-width nonzero norm-padding route. Starting from (11), apply M paid local residual steps

    h_(k+1)=h_k+h_k/sqrt(1+||h_k||^2/d), k=0,...,M-1. (12)

Each step is an actual gain-two PreLN FFN residual block whose branch consumes one half of the LayerNorm output. A two-layer signed-ReLU identity implements that linear branch with bounded operator norms. It acts on the complete paired vector, keeps the mean exactly zero, and uses no attention. Inert zeros remain zero.

Let y_k=2^(k-M)u be ideal doubling, and delta_k=||y_k-h_k||. From (12), ||h_k||<=||y_k||=2^(k-M)||u||. Applying (8) at the physical amplitude and comparing to ideal doubling gives

    delta_(k+1)<=2 delta_k+||h_k||^3/(2d), delta_0=0.

Hence the geometrically weighted accumulated error is

    delta_M
      <= sum_(k=0)^(M-1) 2^(M-1-k) 2^(3k-3M)||u||^3/(2d)
       = ||u||^3(1-4^(-M))/(12d)
       <= ||u||^3/(12d).                               (13)

There is NO M/d loss. Earlier local errors are smaller by the cube of their smaller amplitude; their later amplification leaves a convergent geometric sum. All physical states in (12) have norm at most ||u||, uniformly in M,N,d.

Let P_out project to the positive ell_0,ell_1 coordinates. Apply the mandatory final gain-two LayerNorm and the affine vocabulary head W=(1/2)P_out, bias zero. Actual logits are

    ell_phys=P_out h_M/sqrt(1+||h_M||^2/d).

Since ||P_out||=1, (11), (13), and the same scalar inequality imply

    ||ell_phys-ell||_2
      <= xi + ||u||^3/(12d)+||u||^3/(2d)
      <= xi + 7(Z+xi)^3/(12d).                         (14)

With the chosen d and xi, (14) is at most N^(-1/2)/128. An ordinary vocabulary softmax produces Q_N. Its TV error from Q_ref is at most the same quantity. Together with (6), each original/ablated physical output is within N^(-1/2)/64<1/32 in TV of its own ideal floored reference. Combining (2), (7), and (14) proves (1).

The final output is not projection onto a presumed normalized probability bank. It includes the actual final LayerNorm, bounded affine logit map, and ordinary vocabulary softmax. No singular division, unbounded one-shot 1/eta amplification, nonzero sqrt(d) padding, or custom readout is used.

### 5.1 Both useful reads survive actual PreLN compilation

If the first logical read is ablated, its broadcast bank remains zero through every saturation step. Each destination gate is then ReLU(g-s)=0, since every selector g is at most s. Both predecessor rails are zero at every row, so every triple indicator and selected count is zero. If the second read is ablated instead, its fresh histogram bank is zero, again making every selected count zero. In either case j=0 at every row, the denominator selector picks only its zero-count block, and the reference output is exactly (1/2,1/2). Thus the ablations have legal counts and bounded all-row states; they are not being evaluated outside the imported decoder's proved domain.

For an all-zero observed word, the unablated terminal estimate is ((N-1)/N,1/N). At N>=4 and a<=1/4, flooring and renormalizing leaves its second coordinate at most 1/4. Its TV distance from the ablated uniform output is therefore at least 1/4. The common-tube compilation just proved makes each physical output less than 1/32 from its ideal floored reference, so the separation after either physical read ablation is at least 1/4-2/32=3/16. Both invocations are useful to this implementation. This does not prove two heads are necessary for the statistical task.

## 6. Parameters, sparse versus dense resources, and execution limitations

For fixed c, d=O(N), D=O(log N), one wide useful head followed by one histogram head, and O(log N) restoration steps are all paid. The attention count is two useful invocations, not two total sequential layers.

The logical reference's rational parameters have O(log N)-bit binary descriptions; the log coefficients and eta are dyadics with O_c(log N)-bit descriptions. Pairing, signed identity, and gain-halving only add fixed coefficients. Per-coefficient description is therefore O_c(log N). Rational descriptions are exact-real parameters, not floating-point guarantees.

If an all-dyadic parameter version is required, it also exists at the same order. Round the core matrices and biases, preserving their zero support, to coordinate accuracy delta_N=N^(-A) for a sufficiently large fixed c-dependent A. A d-by-d matrix's operator perturbation is at most d delta_N, and its full bias perturbation at most sqrt(d)delta_N. The O(log N)-stage reference has only polynomial total sensitivity L^(O(log N)). Thus choosing A large enough makes its complete output-vector error O(N^(-1/2)), while changing primitive norms by o(1). Anchor entries and pair antisymmetry can be retained exactly. Include this perturbation error in xi, or allocate separate fixed fractions of the same error budget. This is a mathematical approximation argument with O_c(log N) coefficient bits, not an executed compiler or an arithmetic-rounding theorem.

Conservative dense accounting, including zero entries in untied matrices:

- O(N^2 log N) parameter coefficients and O_c(N^2 log^2 N) parameter-description bits; explicitly storing every LayerNorm gain/shift also costs O(dD)=O(N log N) coefficients, dominated by this bound;
- O(N^2) rolling all-row real activation slots, plus O(N^2) attention-score slots if matrices are materialized;
- O(N^3 log N) dense projection/FFN scalar work;
- O(N^3) work for the two useful full-width attention products, or O(N^3 log N) if every dummy attention slot is also densely evaluated;
- O(N log N) bits for public positions, and O(N^2) mask bits if a full causal mask is explicitly stored.

For a declared sparse representation the construction's diagonal operations, bounded-fanout gates, trees, anchor columns and signed identity branches use only O(N log N) nonzero coefficients, hence O_c(N log^2 N) stored coefficient bits. Local sparse work is O(N^2 log N). The naive wide attention products still cost O(N^3); exploiting their exactly uniform prefix structure permits prefix-sum evaluation in O(N^2) arithmetic instead. These are alternative execution conventions, not interchangeable counts. The theorem uses neither sparse savings nor free dummy attention to hide its dense cost.

Coefficient generation, LN square roots, and the exact-real attention/softmax arithmetic have not been numerically executed or given a finite-word stability certificate. There is no training, learned realization, tied-weight, mandatory PostLN, or width-optimality claim.

## 7. Consequence for a proposed statistical depth frontier

Let R_N denote the worst-source risk in (1). Then

    R_N^2 D_N = O_c((log N)/N) -> 0.                  (15)

Consequently a purported lower bound R^2 D>=constant>0, asserted uniformly over arbitrary width under this same frozen positive-epsilon PreLN/ordinary-softmax full-norm contract, is false. Width and dense work cannot be omitted from such an unrestricted claim. More generally, (15) prevents this particular depth-only lower frontier from being rescued by the final normalization/output interface alone.

It does NOT contradict or improve the previous fixed-width suffix construction's depth-risk tradeoff. It does not establish the optimal width-depth-risk frontier, improve the inherited full-history statistical rate, or give a general low-risk simulation theorem for arbitrary evolving nonlinear row banks. The family trades O(N) width and much larger state/parameter/work resources for logarithmic depth. Its core computation is the already-existing parallel logical estimator; real PreLN introduces nonlinear radial factors, but this note does not claim that nonlinearity is statistically necessary or advantageous.

The old fixed-error logarithmic-depth sensitivity lower can also be applied after freezing the new primitive constants, since epsilon-one LayerNorm and bounded full-vector maps have dimension-independent Lipschitz bounds. This observation is not a new sharp constant theorem and does not prove width optimality. The essential new comparison here is the inclusion of the wide upper in the actual normalization/output contract.

## 8. Prior overlap and failed shortcuts preserved

1. The original parallel width-depth candidate already supplies the full-history counts, exact add-one output, two useful uniform reads, bounded full-vector norms, width O(N), depth O(log N), and dense/sparse distinction. Its output was coordinate projection without mandatory LayerNorm or vocabulary softmax. Relabeling that result as an actual PreLN theorem would have been a gap.

2. The reviewed fixed-width compiler in ../ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md, SHA256 a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2, already supplies paired homogenization, the two uniform-read error recurrence, complete preparation before precision choice, gain reparameterization and ordinary-softmax statistical transfer. Those techniques are dependencies, not new tools asserted here.

3. Its nonzero padding register approximately sqrt(3d/2-1-||v||^2) is O(sqrt(d)). At fixed d that is harmless; at growing d it violates the present uniform complete-state norm requirement. Simply reusing it was rejected. Sections 4-5 instead keep the entire norm bounded and dilute LayerNorm variance by paid inert dimensions.

4. A crude O(M/d) restoration estimate would still be small for d~N, but it obscures the actual mechanism and can be too weak in other regimes. The precise geometric sum (13) proves O(1/d), independently of restoration depth.

5. Serial constant-width interpolation of log at error N^(-1/2) would add O(N^(1/4)) depth and spoil the desired logarithmic-depth upper. The scaled parallel hinges in Section 3 pay O(N^(1/4)) width while keeping every full norm bounded.

6. Unscaled hinge fanout has operator/bias norm of order sqrt(m). Using scaled fanout but forgetting to rescale the output is also wrong. Equation (5) is the needed compensation: curvature makes the slope jumps O(1/m), so the rescaled output row still has bounded Euclidean norm.

7. Controlling only the logit bank before later copies/clears is insufficient. Equation (11) controls the actual FULL prepared vector. Physical scratch residuals are neither assumed zero nor ignored during restoration/final LayerNorm.

8. Bounded ordinary logits force a positive output floor. Thus this normalized witness uses fixed P_c, even though its imported add-one statistical theorem covers zero transition probabilities. No zero-floor all-source consistency is claimed.

9. No fresh exhaustive external priority search was conducted. Earlier local literature comparisons already identify multilayer Markov/n-gram estimators and bounded-attention sensitivity precedents. This note is a local contract closure and a qualified counterexample to an overbroad depth-only frontier, not an originality certification.

10. Version 1 established the compiler/risk mathematics but called the reads useful without explicitly carrying the single-read ablations through the common approximation budget. This revision includes all three reference programs when fixing the tube and eta, fixes conservative log/width/error constants, and supplies the constant output-separation argument. Version 1 remains unchanged rather than being silently upgraded.
