# Statistical scope of output-equivalent nonlinear codes and the universal sample floor

6 November 2026 UTC. Candidate v1. Elementary minimax bookkeeping, not a new estimation theorem. Conditional architectural upper statements below require a separate accepted wide positive-epsilon compiler. No computation, model execution, training, or upload was performed for this note.

## 1. What pure-square output equivalence cannot improve

The accepted PURE_SQUARE_RADIX v2 recovers exactly the same suffix word and returns exactly the same logical estimator q_b(x) as the existing linear packed-code construction, for EVERY Boolean history. With an identical probability floor and log approximation, the two bounded-log reference distributions also agree pointwise.

Therefore every source-specific expected loss that depends only on the terminal output and target is identical for those logical references. This includes TV risk, cross-entropy where defined, and any other specified scoring rule. The square transport cannot have a better reference statistical rate, a better constant for the identical q_b, or a different worst-source prediction law. The two physical compiled outputs may differ by their separately bounded implementation errors; those differences do not constitute a proved statistical improvement.

The local theorem concerns representability and communication scope: a nonadditive internal code can have an output represented through a different additive code. It says neither that arbitrary nonlinear codes have this property nor that all predictors at this resource budget are limited to q_b. The old suffix rate was an UPPER bound, not a fixed-width optimality theorem. Equality of one construction to it cannot prove an impossibility theorem for other architectures.

## 2. A universal sample-size floor, independent of architecture

Let P_c contain all stationary binary IID sources with plus probability p in [c,1-c], as a subclass of the common unknown homogeneous second-order family. Fix N>=1 sufficiently large that delta=1/(8 sqrt(N)) <=1/2-c. Put p_+=1/2+delta, p_-=1/2-delta. The N-history laws are IID product laws P_+^N,P_-^N; their actual next-plus probabilities are constants p_+,p_-.

For any predictor q(X) in [0,1], with arbitrary depth, width, heads, side-independent random coins, and source-independent parameters,
 R_N(q)=sup_(P in P_c) E_P |q(X)-p_P(X)| >=1/(16 sqrt(N)).

Proof. Since delta<=1/8, certainly delta<=1/4, and
 KL(Ber(p_+) || Ber(p_-))
 =2delta log((1+2delta)/(1-2delta)) <=16delta^2.
For example integrate 2/(1-u^2) from 0 to 2delta to obtain the displayed loose bound. Product additivity gives KL(P_+^N||P_-^N)<=1/4. Pinsker then gives TV(P_+^N,P_-^N)<=sqrt(1/8)<1/2.

Integrate the pointwise inequality |q-p_+|+|q-p_-|>=2delta against the common sub-probability measure min(P_+^N,P_-^N). The sum of the two risks is at least 2delta(1-TV), so their maximum is at least delta(1-TV)>=delta/2. Independent random coins can be included with the same law in both experiments without changing their TV. This proves the claim.

This is an elementary two-point sample lower already implicit in the earlier source-testing results with their min(C+1,N) cap. It introduces no architectural resource dependence and is not a new minimax-rate claim. The theta used in the separate lag-two context-sensitivity witness serves a different purpose and is not substituted for this IID testing parameter.

## 3. Conditional wide-model composition and the rejected depth-only inference

Suppose the separate WIDE_PRELN construction succeeds under one fixed full-norm, score, LN epsilon/gain and primitive-gain envelope, using width W_N=O_c(N), two useful wide uniform reads, total paid depth D_N=O_c(log N), and source-independent ordinary vocabulary softmax, with risk <=C_c/sqrt(N). Combined with Section 2, this establishes the order N^-1/2 for minimax risk over that sufficiently permissive W_N,D_N family. It does NOT establish optimal width, optimal depth constant, fixed-width minimax risk, or a new statistical estimator.

It would imply R_N^2 D_N=O_c(log N/N)->0. Thus a bound R_N^2 D_N>=constant cannot hold uniformly over arbitrary growing WIDTHS in this norm-normalized architecture. The same warning applies to any resource S=poly(D,H) that ignores growing representation dimensions and remains polylogarithmic on this family. A fixed head invocation count does not mean a fixed head value dimension.

This is not a counterexample to the already proved public-linear/fixed-feature communication theorem. Its resource there includes feature/value dimension, decoder gain and precision. Nor is it a counterexample to a theorem whose WIDTH or per-head feature dimensions are explicitly frozen. Enlarging the width budget is a material change to that subclass and must remain visible in every comparison.

The relevant same-model statement concerns common raw-input access, causal mask, positive-epsilon PreLN/softmax syntax, bounded FULL norms, counted primitive stages and source class. Width, value dimension, total parameters, distributed state and work are changed and charged, not silently kept equal. If the research question instead requires constant width and scalar values throughout, this wide witness does not solve that problem.

## 4. What remains open after either outcome

No bound of the form risk versus fixed width, arbitrary evolving causal memory, depth and effective head dimensions has been established by this note. The existing Omega(log N) terminal-context depth obstruction is valid for arbitrary nonlinear updates under uniform sensitivity budgets, but by itself says nothing sharp about risk beyond a fixed error threshold. The sample-size lower is universal but also insensitive to architecture.

A meaningful remaining frontier must either prove a low-cost source-average simulator for the ENTIRE low-risk network with charged nonlinear memory, or give another architectural information bound, or construct a genuinely different fixed-width estimator. Neither repeated re-encoding of q_b nor an energy-only Taylor calculation answers this. Any wide normalization result is an explicit scope check, not completion of that fixed-width frontier.
