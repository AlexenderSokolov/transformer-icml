# Terminal-context route: prior work and failure to produce a new frontier

6 November 2026 UTC. Source-reading and analytical review only. No experiment or model execution. This note reports a negative novelty finding, not a negative theorem about all possible research directions.

## Immediate conclusion

The proposed route "flip the penultimate symbol, exploit 1/N late causal influence, pair histories under a stationary lag-two source, obtain a constant expected-TV floor below logarithmic depth" is already in local v10 research, including arbitrary nonlinear Lipschitz row updates and bounded head count. It cannot be presented as the requested new arbitrary nonlinear source-average lower. The accompanying candidate merely exposes the aggregate-QKV/head-count accounting and ordinary-softmax inheritance explicitly.

## Exact primary local precedents

1. `../terminal_context_obstruction_20261104_0822/BOUNDED_SCORE_TERMINAL_CONTEXT.md`, Sections 1–4, especially lines 11–59 and 80–104: raw-symbol terminal-only nonlinear multihead class; derivative term for changed weights; two-row terminal-penultimate recurrence; stationary noisy-lag-two source; exact q/(1-q) conditional weighting; risk >= q[1-2q-epsilon_N]_+ and q=1/4 asymptotic 1/8. Section 7 records Hahn/Chiang–Cholak primary-source positioning.

2. `../logdepth_matching_private_20261104/MATCHING_ORDER.v2.md`, Section 4, lines 67–94: synthetic terminal T=N+1, three-row nilpotent recurrence, N=3 conditional-weight correction, fixed-risk Omega(log N). Section 6, lines 118–122, explicitly warns that increasing head count under merely per-head budgets changes the sensitivity constants and proposes aggregate multihead control as the appropriate condition. Its mathematical audit is `../logdepth_matching_audit_20261104/INDEPENDENT_MATCHING_ORDER_AUDIT.md`.

3. `../terminal_suffix_extension_20261104_1854/SUFFIX_EXTENSION.v2.md`, Sections 3–6, lines 36–136: K-symbol stationary refresh-copy source, exact conditional Bayes risk, fixed terminal-suffix sensitivity, and all nontrivial fixed targets r<1-1/K. The binary interior-source version in the accompanying note is a direct specialization lambda=1-2c. The prior review is `../terminal_suffix_extension_20261104_1854/independent_review/INDEPENDENT_SUFFIX_REVIEW.md`.

4. `../standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md`, Section 1 line 7, Section 8 lines 238 and 258: explicit extension to positive-epsilon LN primitives with frozen full norms and imported sensitivity lower. `STANDARD_PRELN.critical_audit.v1.md`, Section 6 line 107, and `STANDARD_PRELN.third_review.v1.md` already audit this transfer. Their upper used probability-register projection, but the lower's Lipschitz premise is also satisfied by a bounded standard vocabulary head and softmax as derived in the accompanying note. This is a regularity check, not a new source-average obstruction.

## Requested older directories: relevance and nonidentity

- `../growing_depth/GD001_lower_derivation.md`, Sections 1–4: bounded primitive influence gamma_D<=C^D is reused inside a QUANTIZED terminal-cut / arbitrary-decoder model, with an exact finite boundary label and paid local windows. Its log-log depth threshold at Q~sqrt(M) is not the raw-token context-obstruction theorem. The boundary label may already reveal the missing penultimate symbol; transplanting the raw-token lower would violate that input contract.

- `../mixing_depth/MD001_theorem.md`, lines 7–9 and Sections 3–4: fixed width/head/boundary/locality budgets, finite output cut, and a mixing-dependent compander threshold. Again this is not the present terminal-context lower, and does not supersede its raw-input assumptions.

- `../terminal_symbol_corruption/EP001_endpoint_corruption.md`, Section 3: an adversary erases the final symbol and a weighted conditional Bayes argument gives a positive floor. This is an information-loss corruption experiment with an unrestricted estimator, not a clean-history bounded-sensitivity architecture theorem. Its conditional-weight technique is related, but it cannot supply a clean-model lower by omitting the attacker.

- `../allrow_frontier_audit_20261104/sources/MATCHING_THEOREM.v2.md`, Sections 1 and 3: exact all-row separated lag recovery at logarithmic primitive depth with a width/transcript packing lower. Its task is stronger than source-average terminal prediction. Section 1 explicitly states effective channel dimension/norm assumptions. It cannot be relabeled as a terminal expected-risk lower. Its transcript source already cites the penultimate logarithmic-depth sensitivity route as a different known mechanism.

## Failure ledger for the proposed new-result claim

- Proposed novelty: arbitrary nonlinear multihead terminal-context floor. Failure: already proved for uniformly Lipschitz nonlinear updates and fixed H in the first precedent.
- Proposed novelty: synthetic-terminal logarithmic-depth theorem. Failure: already derived with the three-row recurrence in MATCHING_ORDER.v2.
- Proposed novelty: positive-epsilon PreLN transfer. Failure: already stated and reviewed in STANDARD_PRELN v2.
- Proposed novelty: all nontrivial fixed target risks. Failure: already covered by the terminal-suffix conditioning experiment. Interior-floor specialization is immediate.
- Possible useful clarification: growing H under aggregate QKV norms. The accompanying note supplies a conditional dimension-free concatenated-head derivative calculation. It must not silently replace per-head resource budgets with aggregate budgets or be sold as the new statistical frontier.
- Still missing: a genuinely stronger source-average lower at the feasible D=Theta(log N) regime for arbitrary nonlinear evolving memory, an accuracy-dependent multi-invocation/width constraint, or a different estimator/rate within the exact same frozen contract.

## Scope and reproducibility

Only local source reading, paper derivation, documentation, and file hashing occurred. No literature source was freshly retrieved in this subtask; external URLs cited inside prior files retain their earlier inspection provenance. No claims of literature priority, formal verification, independent review of the new note, trained realization, finite arithmetic, or public publication are made. Source hashes in `CONTEXT_ROUTE_SOURCE_HASHES.v1.txt` bind the exact inspected local files, not their full dependency graph.
