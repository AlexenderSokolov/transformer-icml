# Independent report text, privacy and static-source audit: revision 1

6 November 2026 UTC. Document inspection only. No mathematical script, scientific enumeration, parameter generation, numerical model, training, browser render or upload was performed. An independent standard-library HTML parse, source-byte comparison and documentary hashing were used for static validation.

## Verdict

Scientific summary and exact appendix bindings: PASS, subject to the two clarity improvements below. Static structure: PASS. Scoped sensitive-data/copyright inspection found no secrets, personal sensitive data, private correspondence or copied third-party papers.

Delivery revision required: two non-scientific attribution phrases in embedded audit texts should be replaced by neutral review language in explicitly identified delivery derivatives or new review revisions. Preserve original sources and hashes; do not silently edit the accepted scientific files or represent changed derivative bytes as original bytes. The report should be rebuilt as a new version and independently bound again before delivery.

This is not a visual-render acceptance, formal proof certificate, external peer review or legal clearance.

## Exact inspected files

- `RESEARCH_REPORT.zh.v1.html`: 243,251 bytes; SHA-256 `e48913cc721be160e62600590a65e50a448c47ef43a62cdbf9eaaa75baf02e8d`.
- `README.v1.md`: SHA-256 `8bcf4164b52f96f472e1139f89ba7492c9ec2f55584ec7423281e3b09876cbfe`.
- `REPORT_BODY.zh.v1.html`: SHA-256 `967583260fa24f21da8850c74acddb1be5eae336902d22622aff8f30a7f93999`.
- `REPORT_SOURCE_BINDINGS.v1.json`: SHA-256 `6e408de3c1eb500fd1af31274db47e3447018dc0000f4e04e7b24c1ccd522347`.
- `REPORT_HTML_QA.v1.json`: SHA-256 `9b5badf2682c35f5a6004baaba521282935ce8efea646b999f2f974c4a1a2626`.

## Scientific-summary checks

1. The principal claim is low-risk COMPLETE-OUTPUT simulation hardness on actual fair IID histories under the old AA/BB ownership, not a statistical minimax lower or predictive advantage. The Chinese text repeatedly preserves this distinction and identifies the hard component as removable nuisance.
2. The report uses the corrected `kappa_c rho/2 <= R_N <= 200rho` envelope, not the rejected 100rho constant. It gives the correct `C+b >= (N/2-1)/2-2` lower and the small tolerance `kappa_c rho/100`, with TV inside both history and protocol-coin expectations. The suffix information used in reduction is explicitly charged.
3. Three scalar useful invocations are distinguished from the optional two-invocation value dimensions (2,1). The report correctly notes that the parity-head output effect shrinks with rho and does not assert a fixed nonvanishing usefulness margin.
4. The optional inverse-polynomial amplitude variant does not inherit a two-sided risk-at-amplitude claim. Separate baseline-log and physical-comparison precisions are correctly explained.
5. The cheap-surrogate residual paragraph correctly preserves the strict inequality and the sufficiently-small simulator error condition. It does not invalidate the old closure-transfer theorem or claim that every row approximation has the required output certificate.
6. The wide upper visibly pays O(N) width, wide values, O(N^2) distributed state and O(N^3 log N) conservative dense work. Its inherited rate and actual PreLN/output-interface role are accurately separated. Its risk-squared-times-depth consequence is restricted to width-blind claims.
7. Pure-square output equivalence, inherited context lower, aggregate versus per-head norms, and the architecture-free IID sample floor are reported at their accepted scopes. No better fixed-width estimator, optimal frontier, trained realization, finite-word certificate or novelty finding is asserted.
8. The README accurately tracks accepted exact revisions and preserved failures. Historical pending labels in appendices are explained rather than silently upgraded. The accepted IID v3 audit and residual-corollary audit are included and bind their respective source files.

## Requested delivery and clarity changes

- In `INDEPENDENT_IID_QUADRATIC_EARLY_FAILURE_AUDIT.v1.md` and `INDEPENDENT_IID_QUADRATIC_NUISANCE_AUDIT.v1.md`, replace the two process-specific attribution sentences with neutral language such as “The arithmetic error was independently identified during review.” This changes no mathematical finding. Preserve originals; bind any delivered derivative and record its relation to the original.
- Make the source initialization scope explicit: the main IID-hardness theorem uses the stationary interior class P_c, which includes fair IID. The wide upper additionally permits arbitrary initial-pair laws. The present common-contract paragraph is underspecified on this distinction rather than mathematically contradictory.
- After the wide restoration formula using gain-one notation, state that the actual gain-two blocks realize it by halving the consuming branch. This avoids an apparent conflict with the report's opening requirement that every actual LN has gain two. The accepted proof already supplies the exact reparameterization.

## Independent static and binding results

The independently parsed report is valid UTF-8 and contains eight h2 sections and eighteen expandable appendices. For every appendix, its HTML-decoded preformatted UTF-8 content equals the named source bytes exactly; the computed SHA-256 equals both the JSON binding and displayed appendix hash. The binding-name set equals the appendix-name set.

No duplicate IDs, broken internal fragment links, tag-nesting errors or unclosed tags were found. No active scripts, iframes, forms, object/embed elements, event-handler attributes, external media, CSS imports or CSS URL requests were found. There are four ordinary public-paper hyperlinks, matching the cited arXiv and ACL URLs. No absolute workspace/home/temp paths or email-like addresses were found in the rendered document source.

All sixteen other appendices remain unmodified original source bytes in this inspected version. Any revised delivery should retain that property while explicitly identifying the two attribution-only derivatives if that route is chosen. The final text/privacy audit should remain a separate artifact rather than being recursively embedded after its own report hash is established.

## Privacy, provenance and unperformed checks

The inspected material contains mathematical constructions, source references, documentary hashes and research reviews. No actual credential, authentication token, financial identifier, government identifier, health record, personal contact information or private correspondence was found. The external content is four public-paper links and comparative summaries, not full-paper redistribution. Relative research-source paths are documentary references, not access links.

Static parsing and hashing are document checks only. They do not execute the mathematical circuits or establish numerical reliability. The prior increment's 288-case rational check is correctly not used as evidence for this increment. Visual layout was not rendered or accepted, and no publication or upload occurred during this review. The transitive external proof/dependency graph remains inherited rather than closed by the HTML appendix bundle.
