# Independent scope and provenance audit

6 November 2026 UTC. Read-only source comparison and analytical review. No new literature search, theorem experiment, numerical execution, model run, training, or upload was performed.

## Verdict and exact scope

PASS for the comparative claims in `PRIOR_WORK_AND_REJECTED_INFERENCES.v1.md`, SHA-256 `bc6f3ec0547d2b28bbbb9f2afc079d1585320e6d473b66072af045ed046bf918`.

This is a scope/provenance acceptance, not an independent proof audit of the new IID parity theorem. At this inspection the candidate `IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v2.md`, SHA-256 `83d7c573809ca6c3f633654c61a2210b1c1552f3d6f4b4887850de39dc7d68f7`, was awaiting its separate mathematical review. The comparison correctly says "if accepted". Its new source-average obstruction must remain conditional until that exact candidate or a subsequently revised candidate receives its own review. This report does not upgrade pending mathematical status.

## Comparisons checked

1. **Output equivalence is not an estimation improvement.** The prior pure-square source explicitly recovers the same old suffix word and outputs the same logical estimator. Thus output-dependent loss is unchanged. The comparison correctly distinguishes internal nonadditivity, useful paths inside a selected implementation, and necessity of those paths for the statistical task. It does not turn the old suffix upper bound into a fixed-width optimality theorem.

2. **The context mechanism is inherited.** The older terminal-context obstruction, synthetic-terminal matching note, suffix extension, and standard PreLN note already contain the sensitivity/source-pairing argument and its stated extensions. The new concatenated-QKV calculation clarifies the aggregate norm convention. It does not create a new logarithmic-depth mechanism or an accuracy frontier at already logarithmic depth. This is consistent with the separately accepted aggregate-context audit.

3. **The wide rate was already logical.** The old parallel construction and matching composition already supply width O(N), O(log N) paid depth, full-history add-one output, and O(N^(-1/2)) risk. The newly accepted wide PreLN candidate changes the normalization/output admissibility, with a bounded-norm parallel logarithm and inert-dimension restoration; it does not introduce the estimator or rate. The comparison correctly rejects importing the fixed-width sqrt(d)-size padding into a growing-width uniformly bounded-state claim, and correctly records the nonterminal-simplex issue. Its width-blind risk-squared-times-depth conclusion does not preserve the fixed-width/scalar-value/work budget.

4. **Three different hardness claims remain separate.** The old terminal simulation construction uses balanced encoded hard histories and establishes worst-history terminal hardness. The rare-marker construction is uniformly consistent and still hard on those exceptional histories, but explicitly has an O(log N)-bit simulator with exponentially small source-average error. The normalized prefix-energy construction aligns the old hard function with positive-epsilon PreLN and ordinary softmax, but its fair-IID prediction risk tends to a positive constant. The comparison states each of these distinctions accurately. In particular, it does not use full support of a source as a substitute for a distributional communication proof.

5. **The new parity comparison is genuinely conditional and source-specific.** The inspected candidate proposes a quadratic function of the actual fair IID sample under the same AA/BB ownership, rather than a communication encoding asserted to resemble a Markov source. It perturbs an old suffix predictor by a public vanishing nuisance amplitude. If its separate proof is accepted, the conclusion concerns approximating the complete output at a sufficiently small amplitude-scale tolerance, not improved prediction or a minimax risk lower. The comparison correctly keeps expected TV inside both history and protocol-coin expectations, charges the extra output bit in the rectangle argument, and charges suffix information in the reduction. I verified these as statements of the candidate's intended contract, not by duplicating its full algebraic, architectural, or discrepancy proof.

6. **The remaining question is not declared solved.** A simulator may discard nuisance output at a coarser statistical tolerance. The comparison therefore does not conclude that every useful predictor requires linear communication or that the fixed-width risk-versus-resources frontier is closed. It asks for an argument that tolerates such nuisance, a justified output restriction, or a different direct statistical method. No arbitrary restriction is presented as a proved property of the full class.

## External antecedents and execution provenance

The Rajaraman, Ekbote, D'Angelo, and Hahn claims are appropriately tied to the older primary-comparison records. Those records distinguish empirical conditional representation from training guarantees, singular versus positive-epsilon normalization, sharpening scores versus bounded scores, and probability-register versus ordinary-softmax output. The current note does not claim another live paper retrieval, freshness of the corrected Hahn supplement, exhaustive priority search, or theorem certification for those papers.

Tent folding, interpolation, radial normalization, discrepancy, two-point testing, and nuisance perturbations are described as standard tools rather than discoveries. The older rare-marker note indeed explicitly uses tent iteration. This supports the comparison's elementary-tool/contract-combination framing without establishing originality of the final combination.

The preceding pure-square increment's historical 288-case exact-rational check is clearly separated from the present analytical increment. It supplies no execution evidence for the wide, context, sample-floor, or IID-nuisance claims. The statement that no new experiment was run is consistent with this review's read-only work.

## Principal source bindings

- Old encoded terminal obstruction v2: SHA-256 `703ba671e0a469ad74a122f093c1935e10c185645d73708c6baa1e2258411c14`.
- Old rare-marker low-risk obstruction v2: SHA-256 `e22084b823555b46924146aae98f3ad9cd2835a6f115215381bbc2facc57b154`.
- Old normalized nonlinear obstruction v2: SHA-256 `628009aef0e5d1333e23913bb34c2d04d3b67d792e7ea5ad76d498d729f331ac`.
- Ordered-causal `PRIMARY_COMPARISON.v1.md`: SHA-256 `14e6b70797cbf49b359a3a9330eef6e06dfaf7485f471f2e7347421681dee618`.
- Nonlinear-closure `PRIOR_WORK_AND_SCOPE_COMPARISON.v2.md`: SHA-256 `adc7184b3f6229f620844c582717a3f7794ad8a3b2a300c244f2556863b47c40`.
- Current wide PreLN v2: SHA-256 `28d7230b9b6b131daa05f6d5a58b3a26d562ca54845e09db13ff9785f5d39e0e`.
- Current context/aggregate-head v1: SHA-256 `1a217af2b96cbaf48abdb540f43a758458ebd59e1691ff240b31b40e3362f716`.
- Current statistical-scope/sample-floor v1: SHA-256 `07ed93c961aa9be6b09fc8ecf19e93ac1ef6f461dc9efe5835f2fe340616895b`.

Earlier independent audits in this directory bind the older pure-square, parallel, context, suffix, and compiler dependencies. This source comparison is not a closed dependency bundle or an audit of every historical file. No required correction to the inspected comparison was found.
