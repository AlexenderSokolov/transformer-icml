# Independent final report audit: text, privacy and source bindings

6 November 2026 UTC. Independent document review only. Source reading, textual comparison, standard-library HTML parsing and documentary hashing were performed. No scientific script, mathematical enumeration, parameter-generation program, numerical model, training, browser render or upload was executed.

## Final verdict

PASS for the scientific summary, declared editorial derivatives, scoped privacy inspection and static/source-binding checks of the exact report v2 identified below. The delivery qualifications recorded for report v1 are resolved. No further required correction was found.

This acceptance covers report v2, README v2 and its explicitly mapped delivery sources. It does not approve publishing an arbitrary recursive copy of the working directory, the superseded pre-delivery report v1, or unmapped originals in place of the specified delivery copies. Original scientific sources and historical failures remain preserved locally.

No visual-render acceptance, formal proof, external peer review, execution-precision certificate or legal clearance is asserted.

## Exact accepted artifacts

- `RESEARCH_REPORT.zh.v2.html`: 245,908 bytes; SHA-256 `471b6d6fb7ae5b49cea957b58802421a69609aa2a8bd2b1c968cd7d5603b0491`.
- `README.v2.md`: SHA-256 `988f89da172e0f10540651421d02cb03a1d13d9531d37be9b32857f6697daaae`.
- `REPORT_BODY.zh.v2.html`: SHA-256 `dca2befe6d8698d56d56eeec0b0dc3921d1b38a34140db710dd219cb13f80c04`.
- `REPORT_SOURCE_BINDINGS.v2.json`: SHA-256 `08bc0a6a4edb5c0a7f5322e15703e21130de35b63f44abb8cd48b7a0d038996c`.
- `DELIVERY_SOURCE_MAP.v1.json`: SHA-256 `7f62a83e4da5c3fd10e0025302080492b60343b43c238bcfcf33d0f03f522a10`.
- Independently generated document-check record `INDEPENDENT_REPORT_STATIC_CHECK.v2.json`: SHA-256 `19e7df17dabacb78009c983fe5e68028c4a32755a330861437e75e96aa57b25b`.

## Scientific text and revision review

The Chinese report and README accurately preserve the main theorem's scope: a fixed-width actual PreLN/ordinary-softmax network with removable low-amplitude nuisance has linear COMPLETE-OUTPUT simulation cost under fair IID input and the old AA/BB ownership at a sufficiently small risk-proportional TV tolerance. This is not a statistical minimax lower, predictive advantage, better estimator or new rate. The two-sided risk bound uses the corrected 200rho envelope. The additional b-bit suffix information and the location of TV inside both input and coin expectations remain explicit.

Three scalar invocations are distinguished from the optional two-invocation dimensions (2,1); shrinking nuisance-head usefulness is not misrepresented as a fixed margin. The inverse-polynomial amplitude variant separates serial-log accuracy from physical approximation and does not claim total risk at the smaller amplitude scale. The cheap-surrogate residual corollary retains its small-error condition, strict inequality and complete-output scope rather than contradicting the old conditional transfer theorem.

The wide model explicitly pays linear width, wide values, quadratic distributed state and cubic-logarithmic dense work. Its statistical rate is inherited. The context-depth and sample-size lower bounds are identified as existing or elementary and do not become a sharp fixed-width risk frontier.

Both requested clarity changes are present: the IID main risk class is explicitly stationary and interior, whereas the wide upper additionally permits arbitrary initial-pair laws; the gain-one restoration notation is explicitly implemented by actual gain-two LN with a halved consuming branch. These changes align the prose with the accepted sources without altering any theorem.

Historical v1/v2 failures, exact-version acceptance and remaining inherited dependencies remain visible. The final accepted IID v3 and residual-corollary audit are embedded. Older pending labels are correctly historical, not contrary current statuses. No current-round mathematical experiment, training, fresh external retrieval or visual acceptance is invented.

## Exact editorial-derivative verification

I compared each of the three original/delivery pairs in full. Each pair differs only by its single declared neutral wording replacement. No formula, assumption, constant, conclusion, accepted theorem hash, proof argument or failure finding changed. The originals retain their prior hashes.

The mapping's original byte counts and SHA-256 values, delivery byte counts and SHA-256 values all match the files independently. Accepted delivery hashes are:

- `delivery_sources/INDEPENDENT_IID_QUADRATIC_NUISANCE_AUDIT.v1.md`: `f2a955c45e60acd31463be60e1522016e36d86d3b57f5c82af1ce435f97945b4`.
- `delivery_sources/INDEPENDENT_IID_QUADRATIC_EARLY_FAILURE_AUDIT.v1.md`: `2a8513e0816278ed4c87318bda9a8e3b9c423a80704f8ed389dfe86d0c2f86d3`.
- `delivery_sources/STATISTICAL_SCOPE_AND_SAMPLE_FLOOR.candidate.v1.md`: `05f9da2a0dd99f2ccc6659a5ed9f287d690dc3c38e96e0081fa7f3362a1528d3`.

The report and README disclose these derivatives and the source-to-copy mapping. They do not mislabel derivative bytes as untouched originals. The source map itself is included as the nineteenth exact appendix. Its text describes the editorial change neutrally without reproducing the removed attribution wording.

## Independent static validation

The report is valid UTF-8. Its eight sections and nineteen expandable appendices were independently parsed. Every decoded appendix equals its specifically named file byte-for-byte, and every calculated hash matches both the displayed hash and JSON binding. The binding-name set matches the appendix-name set. This covers fifteen unchanged proof/review sources, three neutral copies, and one source map.

No duplicate IDs, broken internal fragment links, invalid nesting or unclosed tags were found. No scripts, iframes, forms, active object/embed elements, event handlers, external media, CSS imports or CSS URL requests were found. The four ordinary external hyperlinks are the cited public arXiv/ACL papers. No absolute workspace/home/temp paths or email-like addresses were found. The targeted editorial-role scan is clear in the final report.

This audit remains separate and was not recursively embedded after establishing the report hash. The static check record is document QA, not an execution of any scientific construction.

## Scoped privacy, copyright and limits

The inspected deliverable contains mathematical research, documentary references, hashes and reviews. No actual secret, credential, authentication token, financial/government identifier, sensitive personal record, private correspondence or personal contact detail was found. External-paper material is cited through public links and comparative summaries, not reproduced full papers. Relative research paths are source locators, not exposed absolute filesystem locations or promised online access links.

No browser render was performed, so typography, pagination and visual layout remain unaccepted. Source identity does not close the full historical dependency graph, prove the mathematical results formally, establish global novelty or certify finite-word execution. These limitations are accurately disclosed. No report or source was uploaded or published during this review.
