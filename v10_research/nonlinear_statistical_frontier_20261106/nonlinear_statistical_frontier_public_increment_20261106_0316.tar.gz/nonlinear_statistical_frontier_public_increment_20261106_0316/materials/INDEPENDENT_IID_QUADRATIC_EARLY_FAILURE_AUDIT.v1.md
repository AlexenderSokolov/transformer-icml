# Preserved early audit failure: nuisance risk-envelope constant

6 November 2026 UTC. Analytical review only. No scientific executable, numerical diagnostic, model execution or upload was performed.

## Rejected exact revision

File: `IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v1.md`.

SHA-256: `5d73942aff9d760d6d85dfdf0d01e4e7aaa2ac1206609ba6376157351132b6f4`.

Verdict for the displayed numerical claim: **NOT ACCEPTED as written.** The discrepancy/parity mechanism was not the problem; the advertised upper risk constant was not supported by its arithmetic.

## Exact issue

The candidate defines rho=2^(-ceil(log2(b)/2)). For a power-of-two b whose exponent is odd, rho=1/sqrt(2b), not 1/sqrt(b). Consequently

    13 sqrt(32/(b-1)) / rho = 104 sqrt(b/(b-1)),

which exceeds 104 and tends to 104 along these b. The candidate's bound of less than 85rho for this term drops a factor. Its weaker inequality 1/sqrt(b)<2rho yields the safe leading coefficient 26 sqrt(128/3)<170, not 13 sqrt(128/3)<85.

This does not prove that the actual predictor's risk exceeds 100rho. It proves that the supplied argument does not establish its stated 100rho envelope. The related claim that tolerance (kappa_c/10000) times actual risk is covered also depends on that unsupported envelope.

The arithmetic error was independently identified during review. The author was asked to preserve v1 and correct the constant rather than changing the intended construction.

## Verified remedy and current status

Candidate v2 changes the safe envelope to 200rho and the actual-risk fraction to kappa_c/20000. Candidate v3 retains that correction and adds the separate merged-first-head ablation proof for its optional two-invocation variant.

- v2 SHA-256: `83d7c573809ca6c3f633654c61a2210b1c1552f3d6f4b4887850de39dc7d68f7`.
- v3 SHA-256: `ef9ce668cd9815e45501194198177c7acdc369894a50e3b31aebb5baaa340767`.

The final exact-v3 acceptance and complete mathematical scope are recorded separately in `INDEPENDENT_IID_QUADRATIC_NUISANCE_AUDIT.v1.md`. This preserved failure record does not revive the rejected v1 numerical claim or extend the final verdict beyond its stated imported dependencies.
