from pathlib import Path
import html,hashlib,json
D=Path(__file__).parent
items=[('真实IID源平均硬例主证明','IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v3.md'),('宽模型真实PreLN见证','WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md'),('已有上下文下界与多头核算','INHERITED_CONTEXT_LOWER_AND_AGGREGATE_HEADS.candidate.v1.md'),('统计范围与样本下界','STATISTICAL_SCOPE_AND_SAMPLE_FLOOR.candidate.v1.md'),('先行工作与被否定推论','PRIOR_WORK_AND_REJECTED_INFERENCES.v1.md'),('重复路线溯源与失败记录','CONTEXT_ROUTE_PROVENANCE_AND_FAILURE.v1.md'),('廉价完整输出替身的残差障碍','CHEAP_SURROGATE_RESIDUAL_BARRIER.candidate.v1.md')]
for p in sorted(D.glob('INDEPENDENT*.md')):
 if 'REPORT' not in p.name:items.append(('精确版本独立审阅',p.name))
items += [('保留的IID候选v1：风险常数错误未修订','IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v1.md'),('保留的IID候选v2','IID_QUADRATIC_NUISANCE_HARDNESS.candidate.v2.md'),('保留的宽模型候选v1','WIDE_PRELN_STATISTICAL_WITNESS.candidate.v1.md')]
assert (D/'INDEPENDENT_IID_QUADRATIC_NUISANCE_AUDIT.v1.md').exists(), 'Wait for final IID audit.'
mapping=json.loads((D/'DELIVERY_SOURCE_MAP.v1.json').read_text())
lookup={x['source']:x['delivery'] for x in mapping['files']}
items=[(title,lookup.get(name,name)) for title,name in items]
items.append(('中性交付副本版本映射','DELIVERY_SOURCE_MAP.v1.json'))
body=(D/'REPORT_BODY.zh.v2.html').read_text()+'<section id="appendix"><h2>八 完整证明与独立审阅原文</h2><p>候选创建时的待审状态以对应精确版本审阅为准。下列原文可离线核对，哈希仅用于版本绑定，不是科学执行或机器证明。</p>'
bind={}
for title,name in items:
 data=(D/name).read_bytes();h=hashlib.sha256(data).hexdigest();bind[name]=h
 body+=f'<details><summary>{title} · {html.escape(name)}</summary><p class="hash">SHA-256 {h}</p><pre>{html.escape(data.decode())}</pre></details>'
body+='</section><footer><p>中文报告 v2 · 2026 年 11 月 6 日 UTC。本增量无数学枚举、模型执行或训练；未完成视觉渲染验收。</p></footer>'
style='''body{font-family:system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;color:#171717;max-width:980px;margin:auto;padding:40px 24px;line-height:1.8}h1{font-size:2rem;line-height:1.4}h2{font-size:1.5rem;margin-top:2.6rem}h3{font-size:1.15rem;margin-top:1.8rem}nav{margin:24px 0}a{color:#145a88}.eq{font-family:Cambria,Georgia,serif;padding:12px 0;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%}td,th{border:1px solid #d9d9d9;padding:12px;text-align:left;vertical-align:top}th{background:#e8edf1}tr:nth-child(even){background:#f8f9fa}details{margin:22px 0}summary{cursor:pointer;font-weight:600;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.65 ui-monospace,monospace}.hash{overflow-wrap:anywhere;font-size:.85rem}footer{color:#555;margin-top:40px}@media(max-width:600px){body{padding:20px 16px}h1{font-size:1.6rem}td,th{padding:8px}}@media print{body{max-width:none;padding:0}nav{display:none}h2{break-after:avoid}tr{break-inside:avoid}a{color:inherit}}'''
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>非线性更新下的源平均模拟反例与统计资源界</title><style>'+style+'</style></head><body>'+body+'</body></html>'
(D/'RESEARCH_REPORT.zh.v2.html').write_text(page)
(D/'REPORT_SOURCE_BINDINGS.v2.json').write_text(json.dumps(bind,indent=2,ensure_ascii=False)+'\n')
print(len(page.encode()),hashlib.sha256(page.encode()).hexdigest(),len(items))
