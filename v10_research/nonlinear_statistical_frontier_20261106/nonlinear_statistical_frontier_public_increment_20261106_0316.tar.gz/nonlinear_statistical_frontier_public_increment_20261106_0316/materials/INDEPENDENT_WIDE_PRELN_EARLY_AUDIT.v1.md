# Independent early audit: wide PreLN witness v1

6 November 2026 UTC. Analytical exact-file review. No experiment, model execution, numerical test, training, or upload was performed.

Reviewed file: `WIDE_PRELN_STATISTICAL_WITNESS.candidate.v1.md`.

SHA-256: `4c6dbbc92c3811c446cd0e5dfc9ad118775be276cef578dcac4ac8e6f0435154`.

## Verdict

The main growing-width compilation, full-history risk upper, and stated resource orders pass this review. One qualification prevents an unqualified acceptance of the exact full statement: the phrase "exactly two useful attention invocations" is not yet backed by common error control for the two physical single-read ablations. A revision is requested to establish usefulness in the pathwise ablation sense, or to weaken that phrase to two nonzero attention slots.

This is a missing usefulness justification, not a failure of the depth, norm, output, or risk calculation. The author independently identified this point and proposed the same repair before this audit was saved. Preserve v1 and this review rather than retroactively treating v1 as a hash-certified v2.

## Checked main calculations

- The imported all-row logical bounds do not require its nonterminal output to be a simplex. Clipping every coordinate to [a,1] fixes the log-domain issue while preserving terminal floor conversion.
- Scaled hinge fanout has bounded full norm. The curvature bound gives slope jumps O(1/m), so rescaling the output by R=Theta(sqrt(m)) still gives a bounded output-row operator norm. The coefficient rounding error O(m delta)=O(m^(-2)) is correctly paid.
- Homogenized affine/ReLU overwrites can be represented by bounded shallow residual FFNs, including signed-ReLU copies and cancellation. Their full bias columns are bounded because the original full bias vectors are bounded. Pairing is exact and preserves zero full-feature mean.
- The two useful uniform-read local errors are O(eta^2/d) in maximum-row full-vector norm. No off-grid physical count equality is assumed. All copies and approximate clears precede the final complete-vector estimate and the choice of the amplification length.
- Restoration obeys delta_(k+1)<=2 delta_k+||h_k||^3/(2d), giving the geometric sum `||u||^3(1-4^(-M))/(12d)`. Final gain-two LN with a half-projection head adds at most `||u||^3/(2d)`. Thus the total output bound `xi+7||u||^3/(12d)` is correct and has no hidden M factor.
- All restoration and final-LN reachable vectors are bounded by constant multiples of ||u||, rather than by the irrelevant generic sqrt(d) ceiling. No nonzero sqrt(d) padding is used.
- The exact-real rational-parameter theorem and optional all-dyadic parameter approximation are distinct from a finite-execution certificate. Operator perturbation aggregation costs O(d delta_N), not only an entrywise error; O(log N) depth has polynomial sensitivity, so sufficiently many O(log N) coefficient bits suffice for the stated parameter approximation.
- Conservative dense parameter, work, and storage orders charge the growing dimensions. The sparse ledger is explicitly a different representation/evaluation convention.

## Requested repair and its available proof

In the exact logical circuit, ablating either uniform read makes the terminal counts zero and gives B=(1/2,1/2). For the all-zero history, the original B equals `((N-1)/N,1/N)`. After the fixed floor a<=1/4, its first coordinate is at least 3/4 for N>=4, so its TV separation from uniform is at least 1/4.

To transfer this to the actual compiled networks, choose one fixed state tube and primitive envelope for the original and both single-read ablations. Enlarge the fixed interpolation/width factors and reduce the fixed small-amplitude target factor so that each complete physical-plus-log approximation error is below 1/32 on all three networks. The all-zero physical separation is then at least 1/4-2/32>0. These changes preserve O_c(N) width, O_c(log N) depth, and the risk order. They must appear in the revised exact file before this stronger usefulness assertion is accepted.

The author was also asked to state explicitly that stored LayerNorm gains and shifts cost O(dD) coefficients, already dominated by the conservative dense ledger. The shared gain is a bounded diagonal operator, not a bounded-Euclidean-norm length-d parameter vector; v1 already distinguishes those conventions correctly.

## Boundaries

This review gives no new statistical rate, trained realization, numerical reliability, mandatory PostLN result, novelty claim, or constant-width frontier. The source floor and growing width are essential parts of the contract.
