# Independent audit: statistical scope and sample floor

6 November 2026 UTC. Analytical, exact-file review. No experiment, numerical model execution, training, or upload was performed.

## Verdict

PASS for the elementary sample lower, the logical-output-equivalence implication, and the explicitly conditional architectural scope statement. The wide-model upper remains conditional on its separate exact-file audit. This review does not establish a new minimax rate or any constant-width lower.

Reviewed file: `STATISTICAL_SCOPE_AND_SAMPLE_FLOOR.candidate.v1.md`.

SHA-256: `07ed93c961aa9be6b09fc8ecf19e93ac1ef6f461dc9efe5835f2fe340616895b`.

## Mathematical checks

1. Pointwise equality of logical outputs implies equality of every loss determined only by those outputs and the same target. The source file correctly keeps separately compiled physical outputs outside this exact-equality assertion. I inspected the relevant decoded-word and output-equivalence statements in `../nonlinear_ordered_consistency_20261106/PURE_SQUARE_RADIX.candidate.v2.md`, SHA-256 `3d7b4ebd319f296618e08309b6c14ac8f8d507a8cd6294014d484696a561b7cd`. This is a check of the implication and its stated dependency, not a new complete audit of the radix decoder.

2. For delta=1/(8 sqrt(N)), binary KL equals `2 delta log((1+2 delta)/(1-2 delta))`. Since delta<=1/8, the stated loose upper `16 delta^2` is valid. Product KL is at most 1/4, and Pinsker gives TV at most sqrt(1/8), strictly less than 1/2. Integrating the two absolute losses against the common sub-probability measure gives maximum risk at least `delta(1-TV) >= 1/(16 sqrt(N))`. Independent predictor coins preserve the testing TV when included identically in both experiments.

3. The two IID laws are admissible for each fixed `0<c<1/2` once the stated size condition holds. At c=1/2 no positive delta can meet that condition, so the claimed nonzero lower does not cover that singleton source class. The source's sufficiently-large-N condition already excludes this endpoint; the surrounding binary frontier uses c in (0,1/2).

4. Conditional on the separate upper, the lower and upper give order N^(-1/2) for a sufficiently permissive growing-width/depth class, because the lower holds for unrestricted predictors. The calculation `risk^2 D=O(log(N)/N)` is then valid. It refutes a positive uniform depth-only product lower over that growing-width class, not over fixed-width, scalar-value, fixed-dimensional-cut, or different source/input contracts.

5. Section 4 correctly leaves the fixed-width arbitrary nonlinear evolving-memory frontier open. Output equivalence of one deliberately inherited estimator is not an information lower for all other estimators.

## Review boundaries

This exact-file acceptance covers the mathematical implications actually stated. It does not convert the pending wide compiler into an accepted theorem, certify execution precision, or establish novelty. No candidate correction was required at this inspected revision.
