# IID source-average simulation hardness from bounded quadratic prefix memory

6 November 2026 UTC. Analytical candidate v3, frozen for independent mathematical review; v1 and v2 are preserved. Revision 2 corrected the risk-envelope rounding arithmetic to 200rho and the actual-risk fraction to kappa_c/20000. Revision 3 supplies the distinct merged-first-head ablation proof and common preparation requirement for the optional two-invocation variant. No scientific executable, numerical diagnostic, model execution, training, upload, or public mutation was performed. This note supplies a different logical hard function from the existing encoded-word prefix-energy example. Its distributional lower is elementary. It makes no literature-priority claim and no new statistical estimation-rate claim.

## 1. Claim and deliberately limited consequence

Fix c in (0,1/2) and the existing stationary interior binary second-order source class P_c, which includes the fair IID source. Use the existing raw binary onehot input, public normalized positions, synthetic zero-symbol terminal, inclusive full-prefix causal mask, paid local affine/ReLU stages, and positive-epsilon all-feature PreLN/ordinary-vocabulary-softmax contract. All parameters are source independent.

For N divisible by four and sufficiently large, choose a power-of-two b with 4<=b<=N/2. There is a constant-width, three-useful-scalar-head family with depth O_c(log N+b), fixed complete-state/full-matrix/full-bias/primitive-gain bounds, and terminal worst-source expected TV risk R_N such that

    kappa_c rho/2 <= R_N <= 200 rho,
    rho = 2^(-ceil((log2 b)/2)).                         (1)

The lower inequality holds already on fair IID input. Under the OLD AA/BB ownership pattern, every randomized interactive terminal simulator with worst-case communication C and

    E_(fair IID input, coins) TV(Qhat,Q_phys)
        <= kappa_c rho/100                              (2)

must satisfy

    C+b >= (N/2-1)/2 - 2.                              (3)

Here kappa_c>0 is explicit in Section 6. Taking b=Theta(log N) gives fixed width, D=O_c(log N), exactly three useful scalar heads, R_N=Theta_c((log N)^(-1/2))->0, per-coefficient description O_c(log N), untied network-parameter description O_c(log^2 N), yet C=Omega(N). In particular (3) holds if the error guarantee is alpha_c R_N with alpha_c=kappa_c/20000, by the upper bound in (1).

The result obstructs generic polylogarithmic communication simulation of the ENTIRE low-risk predictor at sufficiently small risk-proportional error. It is NOT a statistical risk lower, a superior estimator, or a claim that useful prediction intrinsically needs linear communication. The hard component is an artificial vanishing nuisance in the final logits. Omitting it recovers the already-known easily simulated suffix estimator. No assertion is made about simulators at a larger constant multiple of risk, or about statistical lower-bound methods allowed to discard nuisance components.

## 2. An integer quadratic statistic on the actual IID sample

Write N=2m, T=N+1, P=2^p=2^ceil(log2 T), and K=P^3. Let raw bits x_1,...,x_N be zero or one and x_T=0. Define

    S_i=sum_(j<=i) x_j,
    U=sum_(i=1)^T binom(S_i,2).

The synthetic self-row S_T=S_N is INCLUDED. The first scalar zero-score full-prefix read gives r_i=S_i/i. Public input a_i=i/P lies in [0,1]. Local multiplication recovers z_i=a_i r_i=S_i/P up to a controlled approximation. The second scalar read averages the local values

    f(z_i)=(z_i^2-z_i/P)/2=binom(S_i,2)/P^2.

Its ideal terminal value is o_T=U/(P^2 T). Multiplication by the public DYADIC T/P, which is at most one, gives U/K. No integer-valued U register and no growing amplification matrix are used. Since 0<=U<=T N(N-1)/2<K/2, this normalized input is in [0,1/2].

Counting how often a pair enters the prefix gives, over the field F_2,

    F=U mod 2
     =sum_(1<=j<k<=N) (T-k+1)x_j x_k mod 2
     =sum_(odd k) x_k sum_(j<k)x_j mod 2.               (4)

The final equality uses N even: T-k+1=N+2-k has parity k. All bits in (4) are ordinary IID sample bits, with no communication-specific encoding or exceptional event.

## 3. Bounded ReLU realization with exact logical parity

### 3.1 A paid approximate product

On [0,1] let

    g(t)=2t-4 ReLU(t-1/2),
    s_L(t)=t-sum_(j=1)^L 4^(-j) g^j(t).

This is the standard dyadic square interpolant: s_L(0)=0 and sup|s_L(t)-t^2|<=4^(-L)/4. It has constant width, O(L) bounded affine/ReLU stages, bounded complete intermediate states, and dyadic coefficients of O(L) bits. Running two copies serially or in fixed parallel banks does not change these orders.

Choose the least L for which nu=4^(-L)/4<=1/(128 K), so L=O(log N). For a,r in [0,1], use

    M_L(a,r)=clip(s_L((a+r)/2)-s_L(|a-r|/2),0,1).

The exact difference of squares is ar, so |M_L(a,r)-ar|<=2nu. The absolute value is an ordinary fixed ReLU circuit. Importantly M_L(a,0)=0 EXACTLY, because both square inputs then coincide. Let zhat_i=M_L(a_i,r_i).

Set the actual second-read value to

    vhat_i=clip((s_L(zhat_i)-zhat_i/P)/2,0,1).

On the exact grid z_i=S_i/P, f(z_i)>=0 and f(z_i)<=1/2. Therefore clipping cannot increase its error. The derivative bound |f'|<=3/2 on [0,1] gives

    |vhat_i-f(z_i)| <= (3/2)(2nu)+nu/2 <4nu.          (5)

The value is exactly zero when the first read is ablated to zero. The second read is an ordinary scalar uniform average into a fresh bank, so its terminal error is at most 4nu. Multiplication by T/P does not enlarge that error.

### 3.2 Paid bounded tent folding and the terminal gate

At every row the actual second-read result is in [0,1]. Multiply it by T/P, then gate with the exact synthetic marker e_i through ReLU(y_i+e_i-1). This preserves the terminal value and makes every nonterminal decoder input exactly zero. All subsequent parity states remain in [0,1]. The marker is computed from protected raw-onehot shadows, as in the existing ordered-suffix construction.

For every integer 0<=u<=K, the elementary tent identity is

    g^(log2 K)(u/K) = u mod 2.                         (6)

For completeness, g(u/K)=min(u,K-u)/(K/2). Thus the first fold replaces u by min(u,K-u) and K by K/2; because K is even, numerator parity is preserved. Repeat until denominator one. The value is then zero or one with the asserted parity. Equivalently, the piecewise-linear graph of the L-fold tent alternates zero and one on the 2^-L grid.

Each fold has Lipschitz constant two and maps [0,1] into itself. Its log2 K=3p folds amplify the input error by at most K, giving final error

    4K nu <=1/32.                                    (7)

Apply the fixed plateau H(t)=clip(2t-1/2,0,1). It equals zero for t<=1/4 and one for t>=3/4. Hence the final LOGICAL output is EXACTLY F on EVERY Boolean history. Every nonterminal row outputs zero. No discontinuous modulo primitive, exponential-width lookup, or hidden unbounded coefficient occurs: the modulo description is justified by the paid continuous tent-and-plateau circuit.

The complete two-read logical program has fixed width and O(log N) stages. With either read individually ablated it returns F=0. Some histories have F=1, for example x_2=x_3=1 and all other bits zero. Thus both reads are useful in this program. Exact logical parity does not assert exact physical parity after normalization; Section 8 compares the full physical output uniformly instead.

## 4. Distributional communication hardness, including the old AA/BB split

### 4.1 Odd/even form and rank

If Alice owns odd positions a_q=x_(2q-1) and Bob owns even positions b_r=x_(2r), then

    F(a,b)=h(a)+sum_(r<q) a_q b_r mod 2,
    h(a)=sum_(p<q) a_p a_q.

The m-by-m strict lower triangular cross matrix has rank m-1: rows 2,...,m and columns 1,...,m-1 contain an invertible triangular minor. This is already a fair-IID product input law, rather than a special encoded distribution.

### 4.2 Preserve the AA/BB ownership contract

No change of the old ownership split is needed. Put N=4n. Alice owns positions 4r-3 and 4r-2; Bob owns 4s-1 and 4s. Ordering each party's odd coordinates before its even coordinates, the cross matrix in (4) is

    M = [ J  L ]
        [ U  0 ],

where J is the all-ones n-by-n matrix, L_(r,s)=1{r>s}, and U_(r,s)=1{r<=s}. The block U is invertible and L has rank n-1. Reordering row blocks gives a block lower triangular matrix with diagonal blocks U and L, so

    rank(M)=2n-1=N/2-1.                               (8)

Alice-only and Bob-only quadratic terms contribute row and column signs to the communication matrix and do not change its spectral norm. This observation is why the proof below allows both local quadratic phases.

### 4.3 Elementary rectangle bound

More generally, let both parties hold d independent uniform bits and

    F(a,b)=h(a)+a^T M b+k(b),   rank(M)=r.

For A_(a,b)=(-1)^F, row/column signs reduce its norm to that of the bilinear matrix. Orthogonality of binary characters gives

    (A_0 A_0^T)_(a,a')=2^d 1{M^T(a+a')=0},
    ||A||_op=2^(d-r/2).

Thus every rectangle R=X times Y has uniform correlation bounded by

    |E[1_R (-1)^F]| <=2^(-r/2).                       (9)

A deterministic C-bit interactive protocol has at most 2^C transcript leaves, each a rectangle. If Bob's output is allowed to depend on his own input at a leaf, append one output bit (equivalently split that rectangle into two Bob-output subrectangles). There are then at most 2^(C+1) constant-output rectangles. Its correlation with (-1)^F is at most 2^(C+1-r/2). Distributional error at most 1/4 gives correlation at least 1/2, so

    C>=r/2-2.                                        (10)

For a randomized protocol of worst-case cost C and average error at most 1/4 under the same uniform input, fix all public/private coins to obtain a deterministic protocol with no larger distributional error. Hence (10) applies without restricting interaction or local computation. The protocol is a standard binary communication tree, with the worst-case bit budget valid on every input/coin tape and no free timing or silence channel. This proves the claimed bound for the actual fair-IID source. An expected-cost model needs its own truncation adjustment and is not silently substituted for worst-case communication.

In particular the standalone two-head parity predictor with logits (2(2F-1),0) has fixed output margin, constant fair-IID prediction risk, and Omega(N) source-average terminal simulation cost at a sufficiently small constant mean-TV tolerance. The low-risk construction below is strictly stronger in its statistical scope.

## 5. Compose with the existing one-head suffix estimator

Use CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md and its accepted count/readout audits. With one scalar uniform read, constant width, and O(log N+b) local stages, it produces the old terminal suffix estimator q_b, depending ONLY on the last b raw symbols, with

    sup_(P in P_c) E TV(q_b,p_actual)
        <=13 sqrt(32/(b-1))+1/b.                       (11)

The source program operates on all raw rows, not a supplied cropped suffix. Its paid position selector, packed-code decoder, exact sequential triple counter, actual final-pair selection and restoring division are unchanged. Its reference all-row legality is inherited. Binary bits are simply relabeled as the old symbols 1 and 2.

Build ONE combined logical program rather than concatenating separately normalized physical networks. Compute the two-head parity branch, store F in a reserved bank, then compute q_b using protected raw/position shadows and a third fresh attention destination. Each logical branch ignores the other's working registers. Width grows only by a fixed number of banks. No b-wide workspace or fourth read is needed.

Let a be the largest negative power of two not exceeding c; then a<=1/4. Append the existing fixed-floor bounded-log circuit to get ell_b with

    ||ell_b-log(max(q_b,a))||_infinity <= zeta.

Choose rho as in (1), so 1/(2sqrt(b))<rho<=1/sqrt(b). Define reference logits and probability

    L=(ell_(b,1)+rho(2F-1), ell_(b,2)),
    Q_ref=softmax(L).                                 (12)

All logit bounds depend only on c. The old floor/renormalization inequality does not worsen binary risk for targets with both probabilities at least c. Binary softmax is conservatively one-Lipschitz in the max-logit error, and changing one logit by rho changes its probability by at most rho/4. Therefore

    sup E TV(Q_ref,p_actual)
        <=13 sqrt(32/(b-1))+1/b+zeta+rho/4.            (13)

This is a nuisance perturbation of an OLD estimator. It supplies no statistical gain and no reason to predict with this particular nuisance.

## 6. Baseline-aware simulation reduction

Fix B_c=log(1/a)+2 and

    kappa_c = min_(|t|<=B_c) sigmoid'(t) >0.

Choose zeta as the largest positive dyadic power of two at most

    min{1/1000, 1/(100 b^2), kappa_c rho/100}.         (14)

With zeta<=1/1000, rho<=1/2, and ell_b's displayed error, both perturbed logit differences are in [-B_c,B_c]. For a fixed suffix s let d_s=ell_(b,1)(s)-ell_(b,2)(s), and define

    p_+(s)=sigmoid(d_s+rho),
    p_-(s)=sigmoid(d_s-rho),
    t_s=(p_+(s)+p_-(s))/2.

The branch separation is

    p_+(s)-p_-(s)>=2 kappa_c rho.                     (15)

Suppose Section 8 supplies sup_x TV(Q_phys,Q_ref)<=zeta. Given any simulator satisfying (2), first run it and then let Alice send all her suffix bits, at most b extra bits. Bob now knows the exact b-symbol suffix and public circuit, hence can evaluate the SAME ell_b, p_+, p_-, and midpoint t_s without further communication. Local computation has no charge in communication complexity. His thresholded simulator output classifies F.

If Bob outputs the wrong sign, its scalar error relative to Q_ref is at least kappa_c rho. Thus, averaging over the actual IID input and the simulator's coins,

    Pr(error)<= [E TV(Qhat,Q_phys)+zeta]/(kappa_c rho)
              <=2/100 <1/4.                          (16)

Equation (10) applied to the total C+b communication proves (3). Neither the baseline nor its statistical error is assumed negligible: Bob explicitly reconstructs its suffix-dependent value. No outside predictor or source kernel is supplied to the NETWORK by this reduction. Bob's reconstruction is solely a communication-protocol step.

The simulator is understood to return a normalized binary distribution. If it instead returns an arbitrary two-vector measured by half-l1 error, the scalar (1+qhat_1-qhat_2)/2 differs from the reference first probability by at most that half-l1 error, yielding the same proof.

The loss is E_history E_coins TV(Qhat,Q_phys), with TV INSIDE the coin expectation. It is not TV(E_coins Qhat,Q_phys), nor an error comparing only the two unconditional marginal laws. The latter metrics do not justify (16). Bob reconstructs the suffix-only LOGICAL baseline ell_b, not an allegedly suffix-only physical normalized baseline; full-feature LN may give the latter small dependencies outside the suffix, already covered by (19).

## 7. The actual risk is Theta(rho), not just an upper envelope

Take N=4n, power-of-two b>=4, b<=N/2, and condition on the final b bits s. Removing these b bits removes complete AA/BB blocks. The remaining prefix still has cross rank

    r'=(N-b)/2-1.

The fixed suffix adds only local linear terms and a constant to the prefix quadratic form. Its Alice/Bob local quadratic phases remain admissible in Section 4.3. Applying (9) to the whole remaining rectangle gives

    |E[(-1)^F | suffix=s]| <=delta_N=2^(-r'/2).       (17)

This bound is uniform in s. Under the odd/even split, where Bob has no local quadratic phase, a sharper 2^(-r') cancellation bound is also available; that stronger assertion is NOT needed for AA/BB.

Conditional on s, both branches have probability at least (1-delta_N)/2, and the target for fair IID is exactly 1/2. The triangle inequality and (15) give

    E[|Q_ref(1)-1/2| | s]
       >=(1-delta_N)/2 (|p_+(s)-1/2|+|p_-(s)-1/2|)
       >=(1-delta_N) kappa_c rho.                     (18)

For all sufficiently large N, delta_N<=1/4. Uniform physical error zeta<=kappa_c rho/100 then gives fair-IID physical risk at least kappa_c rho/2. This is a lower bound for THIS intentionally perturbed predictor, not for all predictors.

Combining (13) with physical error zeta gives

    R_N<=13 sqrt(32/(b-1))+1/b+rho/4+2zeta<=200rho

for b>=4. For example 1/sqrt(b)<2rho and b/(b-1)<=4/3 bound the leading coefficient by 26 sqrt(128/3)<170; the other terms fit comfortably in the remaining 30rho. This proves (1). Actual risk and the hardness tolerance are consequently comparable up to constants depending only on c.

## 8. Complete positive-epsilon PreLN compilation and useful-head margins

Use the accepted paired small-amplitude mechanism from TWO_READ_PRELN_COMPILATION.candidate.v4.md, with the three-uniform-head error calculation in LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md. The preparation-order correction in the former is REQUIRED. This is a new reference program compiled by that existing machinery, not a new normalization theorem.

All local maps above are continuous bounded-gain affine/ReLU programs. Tent folds have fixed slope two, square coefficients are at most one, the product uses fixed contractions/absolute value, values are clipped to [0,1], and the terminal classifier has fixed slope two. The only new length-dependent scalar multiplier T/P is at most one. The exact logical parity plateau is helpful but the compiler NEVER assumes perturbed physical parity or count registers stay on an exact lattice.

First choose zeta by (14), and choose complete-vector/padding/restoration dyadic tolerances as the largest allowed fixed multiples of zeta satisfying the existing final-output inequality

    C_out[2xi+7(C_pad kappa_pad+C_norm xi)+2tau_restore]
        <=zeta.

Append ALL scaled-logit copies, norm-padding square/product/root primitives and scratch clears to the logical reference BEFORE defining its complete prepared length m_pre and selecting small amplitude. Choose one common fixed widened state tube and per-stage gain L_0>=2 for the combined reference and its three individually head-ablated references. The floor/log circuit has depth O_c(zeta^(-1/2))=O_c(b), by (14), and padding costs O_c(log(1/zeta)). Thus

    m_pre=O_c(log N+b).

Represent every register in paired coordinates with preserved logical anchor and raw/position shadows: h=eta z, eta=2^(-M). At gain-one epsilon-one interior LN,

    LN(h)=eta s(z)z,
    s(z)=(1+eta^2||z||^2/d)^(-1/2).

Homogenized local reference overwrites give z_new=z+s(z)(F_local(z)-z), with local error O_c(eta^2) on the common tube. For EACH of the three uniform heads the reference and physical normalized step are respectively

    z'_t=z_t+B(1/t)sum_(i<=t)A z_i,
    z'_t=z_t+B(1/t)sum_(i<=t)A s(z_i)z_i.

The max-row local error is O_c(eta^2), uniformly in N,t, including full-feature normalization's dependence on every bank. Hence the complete prepared-vector recurrence is

    e_j<=L_0 e_(j-1)+C_0 eta^2,
    e_(m_pre)<=C_1 eta^2 L_0^(m_pre).

Choose the smallest M meeting the complete-vector error xi and fixed tube requirements. Then M=O_c(log N+b), not an uncharged arbitrary precision. Apply the existing paid bounded radial restoration, final LN and ordinary affine vocabulary logits/softmax. The final comparison is

    sup_x TV(Q_phys(x),Q_ref(x))<=zeta.                (19)

Finally replace each interior gain one by gain two and halve every consuming first FFN matrix and attention value matrix. Q/K are zero. This preserves the physical trajectory, so EVERY LN uses epsilon=1, gain=2, shift=0. The final LN already has this convention. No mandatory-PostLN extension is claimed.

All three heads remain useful. If either parity head is individually ablated, its logical F becomes zero while q_b is unchanged. On a history with F=1, the reference terminal probability changes by at least 2 kappa_c rho; the common error bound 2zeta preserves a positive physical difference. If the suffix head is ablated, the inherited plateau argument yields the all-default q_b; on the all-symbol-2 suffix the old floored baseline distributions differ by at least 1/2. The same parity perturbation acts on both runs and changes each probability by at most rho/4. The two log errors and physical errors leave separation at least 1/2-rho/2-4zeta>0. The original and all three ablations use the SAME small amplitude, padding schedule, restoration and final head, not separately retuned approximations.

## 9. Resources, provenance and failure boundaries

Resources for b=Theta(log N):
- Exactly three useful full-prefix scalar-value attention invocations; Q=K=0. The standalone parity branch uses two. All local operations, dummy-attention blocks, log arithmetic, full preparation/restoration and conventional final output are counted.
- Fixed per-row width and fixed FFN width, including the old count/lags, fresh head destinations, preserved raw/public-position/anchor shadows, parity bank, product/tent and final-output scratch. No widening with N or b.
- Paid depth O_c(log N+b)=O_c(log N). One common sufficiently large c-dependent envelope for complete states, full matrices/full biases, primitive gains and normalization gains. No containment in an unrelated preassigned numerical envelope is asserted without recalculation.
- Per-coefficient description O_c(log N+b), including tent-square coefficients, public dyadic T/P and 1/P, suffix packing, rho, logarithm/restoration tolerances and eta. Untied fixed-width network parameter description O_c((log N+b)^2). The prescribed public position input i/P is not an uncharged learned N-row embedding table.
- T=N+1 physical rows and O(N) distributed state. Useful dense heads plus local work cost O(N^2+ND) when identically zero attention slots are skipped. Dense execution of EVERY dummy attention slot costs O(N^2D).
- Exact-real arithmetic with finite coefficient descriptions only. No floating-point/edgewise-rounding implementation, training, benchmark, parameter-generation runtime or executed model certificate is provided.

Read dependencies:
- ../ordered_causal_memory_20261106/TWO_READ_PRELN_COMPILATION.candidate.v4.md: complete preparation before amplitude selection, full-feature two-head recurrence and ordinary-output compiler.
- ../local_memory_adaptive_reads_20261105/LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md: three-uniform-head max-row calculation and common original/ablation parameters; its old weak witness is NOT the parity branch here.
- ../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md and inherited audits: old one-head suffix estimator, exact counts/readout and general-b risk.
- ../nonlinear_causal_closure_20261106/NORMALIZED_NONLINEAR_OBSTRUCTION.candidate.v2.md: OLD encoded-word worst-history obstruction, explicitly insufficient by itself for the present IID-average claim.
- The accepted INTERIOR_SOFTMAX v2 / STANDARD_PRELN v2 routines named in the above compiler remain inherited dependencies; this note does not replace their proofs.

Rejected shortcuts and limits:
1. Full support of a Markov source does not transfer a worst-case communication encoding to its average law. Here the polynomial (4) is evaluated on the actual fair IID bits instead.
2. Small prediction risk does not force the complete output to have a cheap simulator at a smaller comparable tolerance. A nuisance can consume that tolerance while contributing only the same small order to risk.
3. A simulator may know the source is fair IID and still face the lower: it must approximate the network's output, not merely output the correct next-bit distribution 1/2.
4. A predictor-specific risk lower is not a statistical minimax lower. This witness does not close the fixed-width risk/depth frontier or beat the old suffix estimator.
5. Nonlinear parity extraction consumes logarithmic depth and O(log N) coefficient precision; it is not a constant-depth or fixed-precision construction.
6. Direct physical concatenation of old normalized networks is invalid because full-feature LN couples the banks. The combined reference and enlarged common tube are essential.
7. No public-linear/additive-cut theorem is contradicted. The quadratic causal row update creates cross terms; a terminal-only simulator of this particular output is precisely what the rank bound rules out at (2).
8. The communication lower is for the stated AA/BB (or odd/even) split, arbitrary interaction, worst-case bit cost, and mean terminal TV over input AND simulator coins. Different splits, expected costs or weaker error targets require separate statements.

The local advance is the elementary IID-distribution quadratic parity witness and its explicitly risk-scale nuisance composition under the already reviewed normalization contract. Independent exact-file review remains required before treating this candidate as accepted.

## 10. Optional tolerance and two-invocation variants

### 10.1 Other inverse-polynomial simulation tolerances

For fixed K_0>0, replace rho by a public negative power of two alpha_N with N^(-K_0)<=alpha_N<=1. Keep the baseline log approximation tolerance epsilon_log=1/(100 b^2), independently of alpha_N. Tighten only the PHYSICAL comparison tolerance to the largest dyadic zeta_alpha<=min{1/1000,epsilon_log,kappa_c alpha_N/100}, enlarging the fixed logit interval by one if necessary and correspondingly shrinking the fixed positive derivative constant. The same nuisance reduction forces Omega(N) communication at mean-TV error O_c(alpha_N), while

    R_N <=13 sqrt(32/(b-1))+1/b+epsilon_log
                   +alpha_N/4+zeta_alpha.

This keeps D=O_(c,K_0)(log N+b): the serial baseline-log circuit still costs O_c(b), and only padding/restoration/amplitude precision sees log(1/alpha_N)=O_(K_0)(log N). Arbitrarily tightening the baseline SERIAL LOG approximation to zeta_alpha would instead give polynomial depth and would be an invalid shortcut. Arbitrary dyadic alpha_N with the same magnitude bound is also allowed if its binary description is explicitly O(log N); a hidden very long numerator/denominator is not free.

With b=Theta(log N) and alpha_N->0 this remains a low-risk family. When alpha_N is smaller than b^(-1/2), the actual total risk need not be Theta(alpha_N); only the main alpha_N=rho choice has that two-sided comparison. This variant refutes a generic simulation bound polynomial in D and log(1/epsilon) even when epsilon is any chosen inverse-polynomial scale, but still does not obstruct dropping a nuisance when only a coarser statistical approximation is needed.

### 10.2 Two invocations with the first value dimension explicitly two

One may compute the token-local packed-suffix values before any read, then combine their uniform average and the raw-bit uniform average in a single zero-score attention invocation whose value dimension is TWO. Its two fresh destinations retain both scalar answers. Preserve the raw-prefix-average bank while running the old suffix decoder and floor/log circuit in separate fixed banks. Then form the quadratic values from the preserved prefix average and use one second, scalar-value, uniform attention invocation. Finish with the same parity folds and nuisance logits.

All schedules remain causal and all-row bounded: the old suffix code/count circuit retains its inherited legal virtual-word invariant, the preserved raw average lies in [0,1], and the quadratic branch has the bounds in Section 3. Fixed-bank concatenation at the LOGICAL level increases full matrix/state norms only by a constant; one combined PreLN compilation is still necessary. The uniform-head error bound is unchanged in order with the fixed two-dimensional A/B maps. Width, depth, precision and communication/risk conclusions are as above.

The useful-head proof needs a separate check because ablating the first merged head kills BOTH averages. Its zero suffix code decodes to the all-default word, while its zero raw average makes F=0. On the all-symbol-2 history, the original and default floored baseline logit differences have opposite signs and separation at least 2log(3). The two baseline-log approximations lose at most 4epsilon_log in that logit-gap comparison (epsilon_log=zeta in the main construction). Even allowing nuisance amplitude alpha<=1 to change adversarially between the two branches loses at most 2alpha. Thus the remaining logit gap is at least 2log(3)-4epsilon_log-2alpha>0.19, since epsilon_log<=1/1000. On the fixed c-dependent logit interval its reference probability gap is at least 0.19 times the positive minimum sigmoid derivative; the physical tolerance at most that derivative times alpha/100 leaves positive separation. The second-head ablation leaves q_b unchanged and makes F=0; the history x_2=x_3=1, with all other bits zero, has F=1 and retains the old 2kappa_c alpha margin.

For this variant, choose a new common fixed tube and elementary gains for its original reference and BOTH actual single-invocation ablations. Include their full logit/padding/copy/clear preparation before choosing eta. Use one identical eta, restoration/padding schedule, tolerances and final head for all three runs. It would be incorrect simply to quote the main three-scalar-head ablation proof for the merged first head.

This is TWO useful invocations with value dimensions (2,1), not two scalar heads. The main theorem deliberately retains THREE scalar invocations so its scalar-value accounting is unambiguous.
