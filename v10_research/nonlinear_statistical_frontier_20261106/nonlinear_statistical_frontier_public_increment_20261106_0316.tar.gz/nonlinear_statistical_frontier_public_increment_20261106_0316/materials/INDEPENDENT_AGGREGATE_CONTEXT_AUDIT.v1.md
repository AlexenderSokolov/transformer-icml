# Independent audit: aggregate heads and inherited context lower

6 November 2026 UTC. Analytical exact-file review only. No scientific computation, model execution, simulation, training, or upload was performed.

## Verdict and exact files

PASS for the displayed aggregate-head sensitivity derivation, smooth-softmax readout bound, three-row context argument, and binary interior-source suffix specialization, under their explicitly frozen aggregate hypotheses. These are inherited lower mechanisms and resource clarifications, not a new statistical frontier.

- `INHERITED_CONTEXT_LOWER_AND_AGGREGATE_HEADS.candidate.v1.md`: SHA-256 `1a217af2b96cbaf48abdb540f43a758458ebd59e1691ff240b31b40e3362f716`.
- `CONTEXT_ROUTE_PROVENANCE_AND_FAILURE.v1.md`: SHA-256 `949bca9cde70b755febc89f7610d6874e980e10913f49b197250e6b1f6d9c087`.
- Associated source-hash list `CONTEXT_ROUTE_SOURCE_HASHES.v1.txt`: SHA-256 `da102b067e8c339ee78b119fc1cb6c9ef4d98193fddfca4a27f69e76cf2d4d59`.

## Independent checks

1. Mean-centering is an orthogonal projection. The epsilon-regularized radial map has Euclidean derivative norm at most 1/sqrt(epsilon), and the diagonal gain multiplies this by its infinity norm. This proves the dimension-independent LayerNorm regularity used here. Positive epsilon alone would not suffice if the gain or surrounding map norms grew with N.

2. For full concatenated Q/K, summing squared head score changes and applying Cauchy-Schwarz gives (A1), with no head-count factor. In the score-interpolation derivative, each head value-minus-average block has norm at most 2V0. Multiplying by the vector of head score differences thus has full concatenated norm at most `2 V0 ||Delta s_i||_2`. Together with alpha_hi<=C/t, this proves the weight-variation part of (A2). The block-diagonal weight operator has norm at most C/t, giving its value-variation part. These steps require the specified concatenated map bounds, not just separately bounded head matrices.

3. Convex interpolation of endpoint logits preserves each row's score range, so no claim that interpolated hidden states are reachable is needed. The proof genuinely includes changed attention weights. Composing the attention residual, bounded output projection, and uniformly Lipschitz local FFN yields (A3). The displayed sqrt(H) alternative under per-head assumptions is a valid weaker bound, and its H dependence cannot be dropped.

4. For softmax probabilities p, `sum_j p_j |v_j-E_p v| <= sqrt(Var_p(v)) <= ||v||_2`. Integration proves the stated terminal TV Lipschitz factor. This is sufficient rather than sharp, and covers a conventional final LN plus affine vocabulary head.

5. Restricting (A3) to rows T-2,T-1,T gives diagonal domination by c_T and a strictly lower-triangular matrix R with `R_31=b/T` and `(R^2)_31=b^2/[T(T-1)]`. Its nilpotent expansion proves (A4). The explicit zero-depth/zero-influence exclusions avoid negative-power problems.

6. Under the lag-two source, conditioning on the earlier prefix and X_N leaves the penultimate bit's probabilities q and 1-q for N>=4. The target separation is 1-2q, and the weighted triangle inequality gives (A5). The N=3 exception is correctly handled. Setting q=c is legitimate throughout 0<c<1/2; using q=1/4 for c>1/4 would not be.

7. For the binary refresh-copy chain with lambda=1-2c, after hiding k same-parity symbols the terminal bit has law `lambda^k delta_u0+(1-lambda^k) Uniform`. Its exact constant-output TV Bayes risk is `lambda(1-lambda^k)/2`. All completions differ in at most the final 2k observed rows. The stated suffix envelope follows by bounding their maximum row discrepancy and then summing its contributions to the initially unchanged terminal. For any fixed r<lambda/2, a fixed k gives a positive gap, forcing logarithmic depth under frozen a,b. This agrees with the older suffix proof and does not add a risk-versus-depth frontier beyond fixed target error.

## Provenance checks and limits

I directly read the pertinent old terminal-context obstruction, `MATCHING_ORDER.v2.md`, `SUFFIX_EXTENSION.v2.md`, and standard PreLN compiler. They contain the nonlinear Lipschitz setting, correct source weighting, synthetic-terminal recurrence, suffix extension, and positive-epsilon inheritance described in the provenance note. The new note appropriately rejects presenting these as newly discovered lower mechanisms.

The old sources distinguish raw-token smooth-terminal contracts from quantized-cut/arbitrary-decoder contracts and paid local-pair interfaces. The accompanying note preserves those distinctions. This review does not independently reopen every historical proof or certify every file in the prior dependency graph, nor verify external literature priority. No candidate correction was required at this inspected revision.
