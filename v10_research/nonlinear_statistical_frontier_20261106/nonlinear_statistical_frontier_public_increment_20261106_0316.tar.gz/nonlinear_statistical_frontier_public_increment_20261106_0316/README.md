# Nonlinear statistical frontier: public research increment

This additive local package represents all 40 available source files, including all failures, candidates, revisions, audits, source maps, report versions, scripts and QA. No source was overwritten and no GitHub publication occurred. Open materials/RESEARCH_REPORT.zh.v2.html for the unchanged final report. Its 19 appendices and matching final audit retain exact binding.

## Neutral delivery and historical v1

Three original files contain process-specific attribution and are represented publicly by their existing neutral delivery copies, exactly as DELIVERY_SOURCE_MAP.v1.json specifies. Both public root filenames and delivery_sources paths contain those safe bytes. Original private-source bytes are retained outside this package; their original hashes and sizes are disclosed in both maps. No mathematical statement or failure finding was removed.

Historical HTML v1 is also a public derivative: its three affected escaped appendices use the mapped neutral copies and their displayed hashes are updated. No other content changed. HISTORICAL_V1_PUBLIC_BINDINGS.json binds this public v1. The original REPORT_SOURCE_BINDINGS.v1.json, REPORT_HTML_QA.v1.json and v1 text review are preserved unchanged AS HISTORICAL RECORDS FOR THE ORIGINAL V1 BYTES, not certification of the public derivative. This distinction is essential: the original v1 checker would not validate the neutral root copies against historical hashes. Use new PACKAGING_QA and the public binding sidecar for the derivative. HTML v2 and its bindings/QA are unchanged and match the delivered files.

## Scientific scope

The IID nuisance result gives a fixed-width positive-epsilon PreLN/ordinary-softmax predictor with removable vanishing nuisance, actual risk Theta_c(1/sqrt(log N)) and linear complete-output simulation cost under fair IID at sufficiently small risk-proportional expected TV error. It uses three scalar reads; the optional two-invocation form has value dimensions (2,1), not two scalar heads. This is not a statistical minimax lower, improved estimator/rate, predictive benefit or optimal fixed-width frontier. Removing useless nuisance recovers the prior suffix predictor. The complete-output residual corollary retains its strict small-error condition.

The wide estimator has inherited O_c(N^-1/2) risk and explicitly pays O(N) width/wide values, O(N^2) distributed state and conservative O(N^3 log N) dense work. It rebuts width-blind statements, not fixed-width bounds. Context-depth and sample-floor results are inherited or elementary. Stationary-interior main-class scope versus arbitrary initial pairs in the wide upper, and actual gain-two restoration reparameterization, remain visible in v2.

IID v1's unsupported 100rho envelope remains a failed proof claim; v2 uses 200rho and v3 checks merged-head ablations. Wide v1's missing-usefulness qualification and v2 repair remain. Pending labels are historical; exact-version reviews do not retroactively pass old proofs.

## Execution, dependencies and rights

No model execution, numerical/statistical experiment, finite-rational enumeration, parameter generation or training occurred in this increment. The earlier separate 288-case check does not certify these results. Packaging performed document parsing/hashing only. Visual acceptance is NOT COMPLETED; no floating-point reliability, formal verification, external peer review or novelty certification is claimed. External proof dependency closure remains OPEN. This is not restoration of a complete v10 corpus.

Scoped privacy review found no secrets or sensitive personal data; attribution wording is neutralized as documented. Relative research paths, including legacy names, are provenance identifiers rather than private machine paths or promised accessible links. Third-party works are linked/summarized, not full-text redistributed. No new license is granted; review is not legal clearance.

SOURCE_DERIVATION_MAP.json supplies original/public identity and exact transformation records. SHA256SUMS and verify_package.py supply read-only final integrity checks. Existing report scripts write outputs and must only run in a disposable copy; historical v1 source-hash constraints differ as explained above. Independent package review and historical audit index are in independent_review/.
