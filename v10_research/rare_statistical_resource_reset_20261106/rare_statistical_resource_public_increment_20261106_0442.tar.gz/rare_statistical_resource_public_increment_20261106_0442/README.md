# Rare statistical resource reset: public increment

All 27 available source files are represented, including every proof version, result registry, failed route/stopping gate, resource discussion, literature audit, independent review, report/body version and script. Twenty-six are exact copies. Only one service-operation sentence in the primary audit is neutralized, preserving the optional retrieval failure and successful evidence route. Originals remain untouched. No GitHub write occurred.

Open materials/RESEARCH_REPORT.zh.v3.html for the unchanged final report. It contains Chinese main text and five adapted technical appendices, NOT raw-byte source embeddings. Historical integrity JSON records original source hashes and sanitized-Markdown hashes; the public audit derivative has a different source hash but identical report-adapted text. New PACKAGING_QA verifies that distinction. Old reports retain their historical omissions/formatting defects rather than being silently corrected.

## Scientific scope

Exact two-step filtering and rare-posterior derivative control establish information loss in a specified parity observation channel under the declared stationary family and parameter range. Known-u parameter estimation and the separate u-blind support obstruction are distinct. Stationary reversal plus terminal transient control gives the stated parity-plus-real-terminal information/risk result. The terminal v1 intermediate constant-chain error remains preserved; v2 corrects 145u to 149u and 63075 to 66603 without changing the final KL constant.

The interactive extension gives a risk floor of order u*2^(-b)/sqrt(1+m*u^2) for the declared total-bit protocol model, even when known u and the real terminal pair are given freely to both parties. A communication-bit lower bound is NOT a multiple-attention, layer/depth, width or gain lower bound. A single sufficiently precise scalar message can be compatible with it. No actual-network resource simulation bridge has been established, and the explicit stopping gate remains binding on interpretation.

The output-range assessment uses inherited statistics and pointwise interval projection with alpha<=1/4. It is not a new estimation theorem or actual network compilation. Exact trajectory comparisons retain N-2; the full-history parameter comparator is an attainable upper bound, not a newly proved minimax identity. Model scope, known/unknown-u assumptions and parameters must not be broadened.

## Evidence and limits

Classical filtering, derivative recursion, KL/data-processing and weak-identifiability methods are credited as prior tools. The targeted HMM comparison does not prove an equivalent positive-emission representation or establish novelty. Inaccessible theorem assumptions and optional retrieval failure remain documented. Literature coverage and external proof dependencies remain OPEN.

No mathematical enumeration, scientific simulation, numerical diagnostic, model run, parameter-generation execution or training occurred. No floating-point validation, formal verification, external peer review or visual acceptance is claimed. Visual acceptance is NOT COMPLETED. This is not a recovered complete v10 corpus.

Privacy/copyright inspection found no actual secrets, personal sensitive records, private correspondence or machine paths. Third-party papers are cited/summarized rather than reproduced in full. No new license is introduced; this is not legal clearance. Historical unpublished-candidate/pending labels retain their creation-time meaning, while result registry and exact-version reviews specify current analytical status.

SOURCE_DERIVATION_MAP.json records every original/public hash, byte count and exact edit. PACKAGING_QA.json separates packaging checks from historical QA. independent_review/ contains review records. SHA256SUMS and python verify_package.py provide read-only integrity checks. Build scripts write reports, so run only in disposable copies. Relative external references retain original-source meaning and may not resolve here.
