# Independent output-range audit

6 November 2026 UTC. Target: `RARE_OUTPUT_RANGE_ASSESSMENT.candidate.v1.md`, SHA-256 `5b2f10dbda68bc13bcf8dc59172b89d0213ba421358bd34561a144a76db73f0f`. This is a proof and scope review, not an architectural construction or novelty certification.

Verdict: the new algebraic claims in Sections 3–5 are valid under the stated inherited stationary-family risk theorem. The assessment correctly labels them as output-only technical refinements rather than a new statistical rate or a compiled PreLN estimator.

For a binary contrast bound Lambda, the attainable interval is exactly [alpha,1−alpha], alpha=(1+exp(Lambda))^−1. On terminal context C, every prediction incurs at least (alpha−q)+. Stationarity weights this by w, independently of the dependence between the history, predictor and query. Randomization does not change this pointwise bound. Inverting alpha≤q+r/w gives the displayed logarithmic lower when q+r/w<1/2.

Substitution r=C u/sqrt(1+nu) gives the displayed identity and log(1/u)+O_C(1) uniformly in n as u tends to zero, with t in its fixed compact interval. The target q itself is order u. Consequently an additional one-half log(1+nu) is not necessary merely for output representability.

For alpha≤1/4, the A, B and D targets belong to the permitted interval. At C, q≤1/4 and scalar interval projection satisfies the claimed absolute-error inequality. Weighting the possible added error by the actual stationary terminal probability gives (3). The supremum over t places the range floor at t=1/4. Combining the inherited statistical lower and this range lower gives the maximum in (4), and their maximum is comparable to their sum. A single projected u-blind inherited predictor provides the upper. There is no independent-query substitution.

For rho≤u≤1/10, the smallest common-row target is 3rho/[4(1−rho)]. This lies below 1/4, and its exact contrast is log((4−7rho)/(3rho)). Projection is nonexpansive around every legal target, so this output-only constraint adds no risk. This valid counterexample to stronger output-range necessity is not a counterexample to a separate computational lower bound.

The conditional A discussion preserves the distinction between the rare-row conditional task and full averaged risk. A frozen final-state/readout norm cannot obtain an increasing contrast merely by increasing depth or width. The proposed network target appropriately leaves raw context construction, the unsmoothed C estimator, projection, logit conversion and all rarity-dependent resources unproved.

Inherited full-history upper/lower rates, constants and stationarity are used as archived premises, not re-proved here. Their cited reconciliation agrees with the family and initialization used in the candidate. No arbitrary-initial extension, deterministic arithmetic guarantee or new statistical-information lower follows from this review. No numerical experiment, model execution, upload or rendering was performed.
