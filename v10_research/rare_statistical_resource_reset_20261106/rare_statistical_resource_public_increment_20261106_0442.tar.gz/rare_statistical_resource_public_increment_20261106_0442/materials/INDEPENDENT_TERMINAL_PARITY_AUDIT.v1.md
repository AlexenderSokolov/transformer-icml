# Independent same-terminal parity audit

6 November 2026 UTC.

Target: `RARE_TERMINAL_PARITY_INFORMATION.candidate.v2.md`, SHA-256 `a9d0119a917ea0f35cf99eac6dce85eb102c0cd568339660a582dac682b24588`. The companion stationary filter is reviewed in `INDEPENDENT_RARE_PARITY_AUDIT.v1.md`.

Verdict: the conditional KL bound and actual-terminal averaged risk lower are supported on the stated parameter rectangle. This review binds revision 2, not the superseded displayed arithmetic of revision 1.

The reverse pair kernel is correctly calculated using the common stationary distribution. Swapping states B,C transforms it exactly into P. Conditional on the actual last pair 00, the reversed symbol process therefore starts from the deterministic pair 00 and follows P. This is exact finite-path reversal, not a stationary approximation after conditioning.

The parity indexing is correct. Observations R2,R4,... start with known hidden pair A and z=1. Observations R1,R3,... first incur the exceptional R3 probability 1−t; conditional on its outcome the current hidden state is A or B, after which ordinary two-step filtering applies. There is at most one such exceptional random emission, and its derivative magnitude is one. Both fixed terminal symbols are respected.

The contraction 0≤F_z≤32/49 holds for every z in [0,1]. Comparing with a zero-initialized algebraic filter gives z_k≤(2/3)^k+7u. Following an observed one, the subsequent zero resets both filters identically, so it cannot invalidate the bound. The fixed-z derivative bounds imply |F_t|≤4z+19u. The resulting recursion is solved by 4k(2/3)^(k−1)+141u; reset derivatives are smaller and preserve the estimate.

Revision 1's displayed emission remainder 145u did not follow directly from these intermediate estimates: 141u+(7u)/2+4u=148.5u. Revision 2 correctly uses 149u. Its squared remainder is 3·149²=66603. The sums of the decaying terms are correctly evaluated as 1053/125 and 9/5, giving an ordinary-emission derivative-square sum below 406+66603 m u². The extra boundary contribution is at most one. Multiplication by the Bernoulli KL constant 16/3 remains below 10^6(1+m u²). The final stated KL constant and rate are unaffected by the correction.

The chain rule uses conditional probabilities at the same fixed observed prefix under both parameters. The initial conditioned pair is parameter independent. Ordinary and exceptional random emissions remain in [1/4,1/2], so no denominator degeneracy is hidden.

For the two-point reduction, h=1/[10000 sqrt(1+m u²)] stays in the parameter rectangle and ensures KL≤1/100. Randomized predictors are covered by the same testing argument. At terminal A the next-one target is t, and Pr_t(A)=u for both alternatives. For each alternative, overall risk is at least u times its conditional-A risk. Taking the maximum therefore yields the stated positive constant times u/sqrt(1+m u²). This is a genuine same-history averaged lower, not an unjustified multiplication of an unconditional parameter bound by a rare-event probability.

The known-u upper from the companion is equivalent in order because min(1,1/(u sqrt(m))) and 1/sqrt(1+m u²) differ only by absolute constants. Short histories can use a clipped constant estimate. The result remains an observation-interface lower: extra data messages can expose information absent from Bob's parity sample, and no attention-resource simulation is proved here.

No numerical experiments, model execution, upload or rendering were performed. This is an independent analytical check, not formal verification or novelty certification.
