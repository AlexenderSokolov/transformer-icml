# Independent interactive communication audit

6 November 2026 UTC.

Target: `RARE_INTERACTIVE_BITS.candidate.v1.md`, SHA-256 `d8310e69296d6d8b963b2c9903259dccf7714cd475520880861f5f7f7b54e934`.

Dependency: `RARE_TERMINAL_PARITY_INFORMATION.candidate.v2.md`, SHA-256 `a9d0119a917ea0f35cf99eac6dce85eb102c0cd568339660a582dac682b24588`, independently checked in `INDEPENDENT_TERMINAL_PARITY_AUDIT.v1.md`.

Verdict: the total-bit interactive lower is valid under the explicitly stated standard binary-protocol-tree model. Its statistical observation and terminal-conditioning terms are charged. It does not yet imply a number-of-rounds, attention-invocation, width or depth lower.

The local uniform prior has interval length a=1/[10000 sqrt(1+m u²)] and lies inside the allowed parameter range. Its maximum pairwise conditional KL is at most 1/100 by the terminal theorem. Convexity in the reference distribution bounds the mutual information in Bob's parity observations by the same number. Crucially, terminal A has probability exactly u at every parameter; conditioning on that event leaves the uniform prior unchanged. The source-independent protocol coins also remain independent.

For a binary protocol tree of worst-case depth at most b, the complete leaves are prefix free and number at most 2^b. Conditional on Bob's local observation and public/private coins, Alice's randomness does not increase this number. Thus the complete interactive transcript contributes at most b ln 2 nats. The claim counts both directions and excludes uncharged stopping, timing or speaker-control channels, so the entropy bound does not rely on an unproved received-bits-only convention. Public and Bob-private randomness contribute no baseline parameter information.

For absolute estimation loss D under the terminal-A prior, the conditional differential-entropy bound h(T|Z,A)≤ln(2eD) follows by comparison to a Laplace density centered at the estimator and using common scale D. The finite information bound excludes exact estimation D=0. It follows that D≥a exp(−I)/(2e), yielding the stated exp(−1/100)/(20000e) constant and 2^(−b) factor. The argument applies to arbitrary randomized normalized predictions; there is no hidden estimator regularity assumption.

Binary TV on A equals the absolute error of the predicted next-one probability. Multiplying the conditional prior risk by u and discarding the other nonnegative row losses gives the prior-average overall lower, hence the supremum lower. This is valid because of the parameter-independent terminal probability checked above.

Solving the lower against C u/sqrt(1+Nu) gives the displayed necessary bit budget. Replacing m by N weakens the result in the correct direction. At N of order u^(−2) or larger, the ratio has order 1/u, so the half-logarithmic rarity requirement is correct up to additive constants. When the displayed right side is negative it adds nothing beyond b≥0.

The simulator corollary correctly uses triangle inequality and requires a normalized prediction. For an unnormalized two-coordinate approximation with expected half-l1 error epsilon, clipping the next-one coordinate gives the safe factor 2epsilon, not epsilon. A real-valued unlimited-precision message is outside the finite-bit model. No efficient architecture-to-protocol simulation, source-dependent free data, or claim that one call carries only one bit is implicit in this result.

This proof uses standard information and entropy mechanisms composed with the newly checked conditional observation bound. It is not a novelty certification or a complete architectural theorem. No numerical experiment, model execution, upload or rendering was performed.
