# Same-terminal rare parity lower: transient filter correction

Private analytical candidate, 6 November 2026 UTC. Exact-file review pending. Companion to RARE_PARITY_INFORMATION.candidate.v1.md. No experiments, simulation, uploads, or public writes. This is a lower bound for a specified observation channel, not for general communication or repeated attention.

## 1. Statement

Retain its stationary rare family, 0<u<=1/100 and 1/2<=t<=3/4. Bob observes either parity subsequence of X_1:N, of length m, and is additionally given the actual terminal pair T=(X_(N-1),X_N). Conditional on T=A=00,

    KL(Law_(u,t)(Bob | T=A) || Law_(u,s)(Bob | T=A))
      <= 10^6 (1+m u^2)(t-s)^2.                    (T1)

Therefore, for any ONE normalized predictor using these observations (even if given u),

    sup_t E_(u,t) TV(Q_N,p_(u,t)(.|T))
      >= c u/sqrt(1+m u^2),                        (T2)

with an absolute c>0. It suffices that the prediction rule is the same for the compared t values. The actual terminal pair is from the observed trajectory, not resampled independently. The prefactor u in (T2) is its exact stationary probability.

The known-u upper in the companion gives the matching order u/sqrt(1+m u^2), within absolute constants and trivial small-horizon conventions. Unknown u is a separate quantifier: the companion's support argument rules out a u-blind uniform full-history rare rate with only this observation channel.

## 2. Why reversing the terminal-conditioned history is legitimate

Let the stationary pair chain's reverse kernel be Q. Direct stationary reversal gives, in states A,B,C,D,

    Q=[[1-t,0,t,0],[q,0,1-q,0],
       [0,1/2,0,1/2],[0,1/2,0,1/2]].

Swapping B,C converts Q exactly into P. Equivalently, reversing the stationary symbol sequence yields the same homogeneous order-two source. Conditional on terminal pair 00, the reversed symbols R_i=X_(N+1-i) therefore form a forward P-source initialized with R_1=R_2=0. This is an identity of the conditional finite-path law, not an approximation by stationarity. Its initialization has no dependence on t.

The reversed Bob subsequence is either R_2,R_4,... or R_1,R_3,.... For the first case R_2=0 is deterministic and its hidden pair is known to be A, so the parity filter starts at z_0=1. In the second case R_1=0 is deterministic, while the first nonconstant observed symbol R_3 has probability 1-t of being zero. Given R_3=0 the hidden pair is A; given R_3=1 it is B. Thereafter the same two-step filter applies. Thus this second case introduces just one exceptional Bernoulli transition, whose parameter derivative has magnitude one and whose probability lies in [1/4,1/2]. Both terminal zeros have been conditioned on; neither is silently discarded or assumed independent.

## 3. A global filter contraction with a decaying transient

Use the companion notation

    F(z,t)=[z(1-t)^2+(1-z)q(1-t)]/[z r_A+(1-z)r_C],
    r_A=(1-t)^2+t/2,
    r_C=q(1-t)+(1-q)/2,
    dot q=u/w.

The bounds 7/16<=r_A,r_C<=1/2 hold on the whole parameter rectangle, independently of z. In particular the proof of

    0<=F_z<=32/49<2/3                              (T3)

holds for ALL z in [0,1], not just z=O(u).

Put a_0=2/3. Compare the filter initialized at z_0=1 with an auxiliary filter initialized at zero and driven by the same observed sequence. The latter remains bounded by 3q<=7u, by the companion's invariant. On a zero update their difference contracts by at most a_0. An intervening observed one resets both filters equally at the subsequent zero. Consequently, after k two-step updates, whenever the current symbol is zero,

    z_k <= a_0^k+7u.                               (T4)

This comparison is purely algebraic; the auxiliary filter need not describe the actual initial distribution.

At fixed z, write n=z(1-t)^2+(1-z)q(1-t) and d=z r_A+(1-z)r_C. On the whole unit interval,

    |partial_t n| <= z+4u,
    |partial_t d| <= z/2+4u,
    0<=n<=d, d>=7/16.

Hence

    |F_t| <= 4z+19u.                               (T5)

The true z_0=1 has derivative zero. Combining (T3)-(T5), the derivative D_k=|partial_t z_k| satisfies, between resets,

    D_(k+1) <= a_0 D_k+4a_0^k+47u.

A reset has derivative at most 7u, so the following bound holds also across resets by induction:

    D_k <= 4k a_0^(k-1)+141u,                       (T6)

where the k=0 first term is defined to be zero.

The emitted next-zero probability after a zero has total derivative bounded by

    |p'_k| <= D_k |r_A-r_C|+z_k/2+4u
            <=4k a_0^(k-1)+(1/2)a_0^k+145u.        (T7)

After a one its derivative is dot q/2<2u, also below the displayed envelope. All ordinary emitted probabilities are in [1/4,1/2]. If the first nonconstant observed symbol is R_3, restart the index k after it; conditioned on either result the initial hidden state is known and its derivative is zero. Its own extra derivative-one contribution will be added separately.

## 4. Conditional KL calculation

The square-summability needed here is uniform in the finite horizon:

    sum_(k>=0) k^2 a_0^(2k-2)
      =(1+a_0^2)/(1-a_0^2)^3=1053/125,
    sum_(k>=0) a_0^(2k)=9/5.

Using (x+y+z)^2<=3(x^2+y^2+z^2), (T7) gives for at most m ordinary transitions

    sum_k sup_t |p'_k|^2
       <=48*(1053/125)+(3/4)*(9/5)+63075m u^2
       < 406+63075m u^2.

Include at most one extra derivative-one Bernoulli transition. The mean-value theorem for each fixed observed prefix, the Bernoulli KL bound with denominator at least 3/16, and the exact conditional likelihood chain rule now yield

    KL <= (16/3)(407+63075m u^2)(t-s)^2
        <=10^6(1+m u^2)(t-s)^2.

This proves (T1) without applying the stationary-initialized Bob KL to a terminal-conditioned law. The O(1) term is the explicit transient information in the terminal-conditioned reversed start.

## 5. Risk reduction retaining the rare factor

Choose t_0=5/8-h/2 and t_1=5/8+h/2, with

    h=1/[10000 sqrt(1+m u^2)].

Both belong to [1/2,3/4]. By (T1), the conditional observation KL is at most 1/100 and conditional TV at most 1/sqrt(200). At terminal A, the actual next-one probability is exactly t. Thus the predictor's next-one coordinate is an estimator of t under this conditional experiment. The two-point absolute-loss bound gives

    max_i E_(u,t_i)[TV(Q_N,p_(u,t_i)(.|A)) | T=A]
      >= h(1-1/sqrt(200))/4.

For either model Pr(T=A)=u. Nonnegativity of the loss on other terminal states gives (T2), for example with

    c=(1-1/sqrt(200))/40000.

This lower remains true with u known. It does not hold against a protocol receiving unrestricted data messages from Alice, and therefore supplies no standalone positive-bit communication lower. Such a proof must still quantify what messages can recover from the hidden intervening symbols.

## 6. Interpretation for the proposed resource bridge

The concrete odd/even observation channel has conditional rare information of order 1+m u^2, including its terminal transient, rather than 1+m u. On this subfamily Bob alone does not attain the full-history rare rate. The earlier identifiability warning is correct but insufficient to discard all rare-family communication reductions.

A future reduction must now include the Bob/terminal baseline information of this scale, a separate message-dependent information term, and an architecture-to-protocol simulation. The current derivation covers neither message interaction nor repeated useful attention. It is analytical progress on one prerequisite and an exact boundary, not a completion of the architectural theorem.
