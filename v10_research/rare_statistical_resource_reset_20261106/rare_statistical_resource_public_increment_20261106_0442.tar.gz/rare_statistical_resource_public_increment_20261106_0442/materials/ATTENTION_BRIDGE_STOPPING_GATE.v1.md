# Why the bit lower does not yet force multiple attention calls

6 November 2026. Analytical scope check; no new theorem beyond the accepted bit inequality.

At N of order u^(-2), the full-history overall target is of order u^(3/2). The new lower requires at least (1/2)log2(1/u)-O(1) total protocol bits. This is a genuine growing information requirement, but a single message with O(log(1/u)) bits can already exceed it. It does not force two or more messages, let alone an increasing number of effective attention calls.

Moreover, a generic bounded scalar uniform-output simulator at accuracy of order u^(3/2) naturally pays order log(1/u) quantization bits even for one scalar. Combining such an upper simulation with the current lower can therefore be entirely compatible with a single useful attention call. This observation does not prove that one actual PreLN call solves the statistical task. It proves that the present bit lower, without a sharper per-call information or distribution-sensitive simulation theorem, does not rule it out.

The relevant next target must be one of:
1. A source-average conditional information bound for actual multi-row attention updates which charges each call more sharply than arbitrary message length, including all raw/residual access; or
2. A concrete equal-budget architecture separating one invocation from repeated invocations, proved under the same rare family and risk.

Stop if the only next step would compose generic O(log(1/epsilon)) scalar quantization with the logarithmic bit lower and call the resulting constant lower a depth-resource frontier. The known wide full-history compiler remains a counterexample to width-blind depth claims. No general lower can ignore value dimension or all N updated rows.
