# Rare-terminal information requires communication bits

Private analytical candidate, 6 November 2026 UTC. Depends on RARE_TERMINAL_PARITY_INFORMATION.candidate.v2.md, not yet independently accepted at creation. No experiments, simulations, uploads, or public writes. This is a communication lower bound, NOT an attention-call, depth, width, or gain lower bound.

## 1. Exact experiment and theorem

The source is the stationary rare binary family in the two companion notes, with fixed known 0<u<=1/100 and unknown 1/2<=t<=3/4. Alice receives one parity subsequence of X_1:N, and Bob receives the other, of length m. The actual terminal pair S=(X_(N-1),X_N) may be supplied freely to BOTH parties. This strengthening avoids hiding a terminal-access cost in the lower. The source law is not otherwise provided; in particular a protocol must be the SAME for all t.

Allow arbitrary local computation, independent private randomness, public randomness independent of the source, and arbitrary interactive communication represented by a standard binary protocol tree with worst-case total cost at most b bits. Bob outputs a normalized binary next-token distribution. Source-independent here means independent of t; the protocol may know the fixed u and N, which makes the lower stronger.

There is an absolute constant c>0 such that every such protocol obeys

    sup_(1/2<=t<=3/4) E_(u,t) TV(Q,p_(u,t)(.|S))
       >= c u 2^(-b)/sqrt(1+m u^2).                 (B1)

For example c=exp(-1/100)/(20000e) is valid under the companion's conditional KL constant. The theorem does not assume one-way communication or unchanged party marginals.

## 2. Local prior with bounded baseline information

Let T be uniform on the interval centered at 5/8 with length

    a=1/[10000 sqrt(1+m u^2)].

This interval lies inside [1/2,3/4]. Write E for terminal event S=A=00. Its probability is exactly u for every parameter. Consequently conditioning on E leaves the prior on T UNCHANGED and independent of all protocol coins.

The terminal companion proves for all t,s in this interval

    KL(P_(V|T=t,E) || P_(V|T=s,E))
       <=10^6(1+m u^2)(t-s)^2 <=1/100.

Here V is Bob's entire parity observation, and the fixed terminal pair A is already part of the conditional experiment. If Pbar_V is the mixture under the uniform prior, convexity of KL in its second argument gives

    I(T;V|E)
      = E_t KL(P_(V|t,E)||Pbar_V)
      <=E_(t,s) KL(P_(V|t,E)||P_(V|s,E))
      <=1/100.                                    (B2)

This explicitly charges Bob's t-dependent marginal and the terminal conditioning. No common-marginal reference law is used.

## 3. Interactive transcript information

Let R be public coins, R_B Bob's private coins, and Pi the complete transcript. Conditioned on R,R_B and V, a worst-case b-bit binary protocol has at most 2^b complete transcripts: the binary tree has depth at most b, and its leaves form a prefix-free set. Random stopping or speaker changes must be represented by the standard protocol tree; no uncharged timing or control channel is permitted.

R and R_B are independent of (T,V,E), so Bob's full view Z=(V,R,R_B,Pi), with the fixed terminal pair A implicit, satisfies

    I(T;Z|E)
      =I(T;V|E)+I(T;Pi|V,R,R_B,E)
      <=1/100+H(Pi|V,R,R_B,E)
      <=1/100+b ln 2.                             (B3)

Alice's private randomness does not alter the transcript-cardinality bound. Bob's outgoing messages are counted in b. A version charging only received bits requires the additional standard simulation/cardinality argument that Bob's own messages and all stopping decisions are determined by his local view and those received bits; that variant is NOT needed or claimed here.

## 4. Absolute-loss entropy inequality

Let that(Z) be Bob's predicted next-one probability on E. The correct probability there is T. Put D=E[|T-that(Z)| | E]. The uniform prior has differential entropy h(T|E)=ln a. The maximum differential entropy at a fixed first absolute moment is attained by a Laplace density; equivalently, nonnegativity of relative entropy against a Laplace density centered at that(Z), followed by Jensen, gives

    h(T|Z,E) <= ln(2eD).

The inequality also follows directly using one common Laplace scale D before averaging over Z, so no regularity of the estimator is required. If D=0, finite mutual information in (B3) rules it out by a limit argument. Therefore

    ln a-I(T;Z|E) <= ln(2eD),
    D >= [a/(2e)] exp(-I(T;Z|E))
      >= [exp(-1/100)/(20000e)]
          2^(-b)/sqrt(1+m u^2).                    (B4)

Normalized binary TV on terminal A is exactly |that-T|. Multiply (B4) by Pr(E)=u, discard nonnegative risk on the other terminal states, and bound the maximum risk below by its prior average. This proves (B1). The prior-average step uses the unchanged uniform T prior conditional on E; it would not be valid without that check.

## 5. Necessary bits at the full-history rare rate

If a protocol has, for every t in this subfamily,

    E TV(Q,p_(u,t)(.|S)) <= C u/sqrt(1+Nu),

then (B1) implies

    b >= (1/2) log2[(1+Nu)/(1+m u^2)] + log2(c/C).

Since m<=N, the weaker horizon-only consequence is

    b >= (1/2) log2[(1+Nu)/(1+Nu^2)] - O_C(1).     (B5)

This becomes (1/2)log2(1/u)-O_C(1) when N is of order u^(-2), and stays of that order for larger N. It is a necessary COMMUNICATION BIT budget. It is not a lower on the number of messages or rounds: one real-valued unrestricted message could carry unbounded information, and one sufficiently long binary message could satisfy this bit budget.

The floor/truncation b>=0 is understood when the right side is negative. Constants are intentionally loose, and the fixed-u subfamily lower does not require an architecture to be supplied u.

## 6. Source-average simulation consequence and remaining gap

Suppose a source-independent network predictor Q has expected TV risk at most r, and a b-bit interactive simulator has expected half-l1 approximation error at most epsilon under every source in this subfamily. If its output is normalized, triangle inequality lets (B1) apply with risk r+epsilon:

    r+epsilon >= c u 2^(-b)/sqrt(1+m u^2).

For an unnormalized binary simulator, clip its next-one coordinate to [0,1] to define a Bernoulli prediction. Coordinate error is at most the full l1 error, giving instead a safe bound using r+2epsilon. No unnormalized-output factor is silently dropped.

To turn this into an attention-resource result one must prove an appropriate source-average finite-bit simulation with a cost b expressed in charged width, depth, gains, precision, and number of useful attention invocations. The bit lower alone does not supply such a simulation and does not rule out efficient repeated attention. The present argument answers a narrower open question: the rare-family odd/even split can yield a nonzero, growing interactive bit requirement despite its t-dependent Bob marginal, once that marginal and the actual terminal event are handled correctly.
