# Independent final report audit, revision 3

6 November 2026 UTC.

## Verdict and exact binding

The final report passes this mathematical-scope, dependency, static-integrity and privacy review. Earlier issues identified during review are corrected. This is not a novelty certificate, formal verification, new primary-source search or visual-layout acceptance.

- Report: `RESEARCH_REPORT.zh.v3.html`.
- Size: 62,039 bytes.
- SHA-256: `771777981149b924b91784a14036d42044bf7fa5e2e5e4f485d70aed609926b2`.
- Main source: `REPORT_MAIN.zh.v4.md`, SHA-256 `9ab08f0ab5bc9ee23a8d3e9a2eb1ea762c3b696871424f394c5fe8b94c0af694`.
- Detailed static results and all five appendix source hashes: `INDEPENDENT_REPORT_INTEGRITY.v3.json`.

## Mathematical and scope checks

The report preserves the stationary initialization, restricted t interval, common fixed u in KL comparisons and source-independent prediction rules. It distinguishes unconditional parity estimation, terminal-A conditional observations and actual-terminal averaged prediction risk. The transient term in conditional KL is retained, as is the exact rare probability u in the testing reduction.

The parity statistical rate and known-u terminal-aware upper agree with the independently checked proofs. The unknown-u support obstruction is stated only for the restricted observation interface with no extra data message. The report does not claim a u-blind full-history optimal predictor from this interface or apply the no-message argument to arbitrary communication.

The new interactive result correctly charges Bob's nonzero marginal information. Its binary protocol-tree hypothesis counts total bits and prohibits uncharged timing/control channels. The local prior is unchanged by terminal-A conditioning. The information/absolute-loss entropy argument therefore supports the stated growing bit requirement. The report does not turn bits into message counts or attention calls. The simulator corollary distinguishes normalized output error r+epsilon from the safe unnormalized coordinate-clipping bound r+2epsilon, and warns that an absolute simulation tolerance may be too large on the rare-risk scale.

The output-range projection upper now explicitly requires alpha≤1/4, equivalently Lambda≥log3. Without that assumption the original Chinese summary omitted possible A-row projection error; this is corrected. The full-history KL comparison now uses N−2 exactly and qualifies equivalence with Nu by N≥3. The full-history parameter estimation comparison is described as an attainable inherited bound rather than an unverified restricted-subfamily minimax assertion.

The terminal proof appendix uses revision 2 with the corrected 149u derivative remainder and 66603 squared coefficient. The obsolete 145u step is mentioned only in the transparent revision history, not used as a proof premise. The output-range appendix's stale unreviewed status is replaced with a scope-limited reviewed status.

The architecture gap remains explicit: a real PreLN network accesses more than the parity stream, and no charged finite-bit simulation for repeated multi-row attention is supplied. Known u arithmetic, finite description bits, activation precision, history length, total updated rows and attention invocations are not conflated. The report makes no training or implementation claim.

## Literature and provenance

Read the HMM comparison appendix and its Chinese summary. The summary faithfully preserves the reported two-state/positive-emission assumptions, the nonautomatic nature of generic derivative constants, and the fact that deterministic emissions alone do not exclude the general filter theorem. The u=0 parity process is correctly identified as dependent rather than IID. Missing full-theorem access for Le Gland–Mevel remains disclosed as a limit, with no theorem-level claim based on that source. This final review checks consistency with the supplied primary-source audit; it does not independently re-fetch or certify every cited primary theorem.

Standard filtering, KL, testing and entropy mechanisms are acknowledged as antecedents. No unmatched-contract argument is promoted to a novelty or publication claim.

## Static integrity and privacy

An independent HTML parser verified the main body's decoded text against its Markdown source and each of five appendices against its documented sanitized source, with only formatting whitespace normalized. Sanitization removes historical candidate-status/provenance lines, updates the output-range review status and replaces the internal access-log tail with a concise public source-access limitation. Mathematical proof text is preserved.

These are rendered, sanitized appendices, not byte-identical raw source embeddings. The integrity record binds both the original source hashes and sanitized Markdown hashes and records the comparison method. It does not mislabel normalization as raw byte equality.

All five external hrefs now match complete URLs in the cited source text. The earlier regular-expression truncation is absent from this report. No script, iframe, object, embed, form, input, event-handler attribute or JavaScript URL was found. Static scans found no private absolute execution paths, internal retrieval-reference identifiers, tool-provider access logs, secret-key patterns or stale pending/unreviewed status. Manual body/appendix review found no personal sensitive information or internal coordination messages requiring removal. The relative research-source citations are provenance references, not private absolute execution locations.

No visual rendering was attempted or retried. No upload, scientific experiment or model execution was performed. Acceptance is limited to the exact report bytes above and the stated analytical/static review scope.

## Separate attention-bridge stopping gate

`ATTENTION_BRIDGE_STOPPING_GATE.v1.md` is outside the assembled report. Its scope judgment is valid: at N of order u^(−2), the risk target has order u^(3/2), while both the necessary total-bit lower and ordinary bounded-scalar quantization cost have logarithmic order in 1/u. These orders do not force multiple messages or attention invocations. A sufficiently long message exceeding a necessary lower is not asserted to solve the task. The note correctly leaves per-call information, all-row simulation and actual network feasibility unproved. The wide-compiler warning is a dependence caveat, not a new rare-optimal implementation claim.
