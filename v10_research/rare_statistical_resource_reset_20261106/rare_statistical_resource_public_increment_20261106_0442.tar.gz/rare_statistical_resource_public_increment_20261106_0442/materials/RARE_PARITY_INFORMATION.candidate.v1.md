# Rare-context parity information: a finite-sample leakage theorem

Private analytical candidate, 6 November 2026 UTC. No scientific executable, simulation, numerical test, upload, or public write. Exact-file independent review pending. This proves a statistical observation-channel result, not an attention-resource lower bound.

## 1. Main result and the correction it makes

Use the stationary rare-context family with pair states A=00, B=01, C=10, D=11,

    pi=(u,w,w,w), w=(1-u)/3, q=ut/w,
    P=[[1-t,t,0,0],[0,0,1/2,1/2],
       [q,1-q,0,0],[0,0,1/2,1/2]].

For this note restrict 0<u<=1/100 and 1/2<=t<=3/4. Bob observes one parity subsequence Y_1,...,Y_m of a stationary history. For every t,s in this interval, at the SAME u,

    KL(Law_(u,t)(Y_1:m) || Law_(u,s)(Y_1:m))
       <= 100000 (m-1) u^2 (t-s)^2.                 (1)

The initial observed-symbol marginal is t-independent. There is no discarded initialization or Bob-marginal term.

Consequently, even if u is supplied to Bob, the minimax absolute error for estimating t from this parity subsequence has order

    min{1, 1/(u sqrt(m))},                         (2)

with absolute constants and the usual m>=2 convention (constant rate for m=1). This is slower in the rare-mass regime than the full-history rate min{1,1/sqrt(mu)}. Thus population identifiability does NOT establish that Bob attains the full-history rare rate. For a fixed u it does establish the ordinary m^(-1/2) exponent, but the constant grows as 1/u, not 1/sqrt(u).

Equation (1) permits, rather than proves, a repaired communication argument with an explicitly charged marginal leakage term. At a full-history local separation (t-s)^2 of order 1/(Nu), Bob's KL is only O(u), whereas the full-path information can be O(1). A proof still needs the message-dependent information inequality, terminal conditioning, and a charged simulation of the network. None is supplied by (1).

## 2. Exact two-step hidden filter

At a parity-observation time let S denote the underlying pair ending at that time. If the observed symbol is zero, S is A or C. If it is one, S is B or D. Crucially P^2 has identical B and D rows:

    P^2(B,.)=P^2(D,.)=(q/2,(1-q)/2,1/4,1/4).

On states A,C, transitions whose next parity symbol is zero form

    H=[[a,t/2],[b,(1-q)/2]],
    a=(1-t)^2, b=q(1-t).

Write r_A=a+t/2 and r_C=b+(1-q)/2. Throughout our parameter rectangle,

    7/16 <= r_A,r_C <= 1/2,
    q <= (25/11)u,  dot q=partial_t q=u/w <= (100/33)u.

Given a parity history ending in zero, let z be the posterior probability S=A. The probability of another zero and the updated posterior are exactly

    d(z,t)=z r_A+(1-z)r_C,
    F(z,t)=[z a+(1-z)b]/d(z,t).                    (3)

After an observed one, the next symbol is zero with probability 1/4+q/2; conditional on that zero, its posterior is reset to

    z_reset=2q/(1+2q).                             (4)

At the first parity observation, conditional on zero,

    z_initial=u/(u+w)=3u/(1+2u),                   (5)

independent of t. Stationarity provides this formula whichever parity is observed. One can use an auxiliary stationary backward extension if the first observed index is 1; this adds no observation or parameter information.

### 2.1 A posterior bound on every history

Claim: 0<=z<=3q<=7u for every history ending in zero.

Equation (5) has z_initial/q=(1-u)/(t(1+2u))<=2, and (4) is at most 2q. If z<=3q, then a<=1/4, b<=q/2, and d>=7/16 imply

    F(z,t) <= [(3q)/4+q/2]/(7/16)=20q/7<3q.

This proves the invariant by induction. It is a pathwise posterior bound, not an average statement.

### 2.2 Uniform derivative control

All finite-history likelihoods are positive and differentiable on the parameter rectangle. Differentiating (3) with respect to z,

    F_z=(a r_C-b r_A)/d^2,
    a r_C-b r_A=(1-t)((1-t)-q)/2 >=0.

Also a r_C<=1/8 and d>=7/16, so

    0<=F_z<=32/49<2/3.                            (6)

In the following partial derivatives z is held fixed. Since z<=7u,

    |partial_t (z a+(1-z)b)|
      <= z + dot q/2 + q < 11u.

Similarly r_A'=-2(1-t)+1/2 has magnitude at most 1/2, while

    r_C'=dot q(1/2-t)-q,
    |partial_t d| <= z/2 + dot q/4 + q <7u.

The numerator of F is between zero and d. Therefore

    |F_t| <= (11u+7u)/(7/16)<42u.                (7)

The initial derivative is zero, and the reset derivative is

    |d z_reset/dt|=2 dot q/(1+2q)^2<7u.

Combining (6)-(7) inductively gives, for every finite history,

    |d z/dt|<=126u.                              (8)

For the emitted probability d after a zero, the TOTAL derivative is bounded by

    |d d/dt| <= |z'| |r_A-r_C|+|partial_t d|
                <=133u.                         (9)

After a one, its zero probability 1/4+q/2 has derivative dot q/2<2u. All emitted zero probabilities lie in [1/4,1/2].

## 3. KL bound and matching parameter-estimation order

For a fixed observed prefix, the mean-value theorem and (9) give

    |Pr_t(next zero|prefix)-Pr_s(next zero|prefix)|
        <=133u|t-s|.

For Bernoulli probabilities p,r in [1/4,1/2],

    KL(Ber(p)||Ber(r)) <= (p-r)^2/[r(1-r)]
                       <= (16/3)(p-r)^2.

The first observation has probability (1+2u)/3 of zero, independent of t. Applying the exact likelihood chain rule to the remaining m-1 observations proves (1), since (16/3)*133^2<100000. This calculation conditions on the SAME observed prefix under both models; no hidden-state distribution is supplied to Bob.

For the lower in (2), take t_0=5/8-h/2 and t_1=5/8+h/2, where

    h=min{1/8,1/(1000u sqrt(m))}.

Equation (1) makes their KL at most 1/10, hence their TV at most sqrt(1/20). The ordinary two-point testing reduction gives maximum absolute-estimation risk at least h(1-sqrt(1/20))/4. This remains true when u is known, and therefore cannot improve when u is unknown.

For the upper, assume u known and use

    Jbar=(1/(m-1)) sum_(j=1)^(m-1) 1{Y_j=0,Y_(j+1)=0},
    that=projection_[1/2,3/4]((u+w/2-Jbar)/u).

Stationarity gives E Jbar=u(1-t)+w/2. The archived pair-chain bound

    sup_mu TV(mu P^k,pi) <= (7/8)^floor(k/2)

implies Var(Jbar)<=C/(m-1), with an absolute constant: the covariance of two bounded lag-two indicators separated by k parity indices is bounded by a constant times (7/8)^(k-1), by conditioning at the end of the earlier indicator. Summing this geometric covariance series gives the stated variance. Projection is nonexpansive, so E|that-t|<=C/(u sqrt(m-1)); projection also bounds the error by 1/4. This proves (2), without assuming independent parity samples.

## 4. Actual terminal context and averaged risk

The source's actual next-symbol probabilities depend on the same-trajectory terminal pair: row A uses t, row C uses q, and rows B,D are fair. A parameter-estimation lower is NOT automatically an A-conditional or source-average prediction lower. In particular, conditioning Bob's entire observation on the rare terminal event A can change its information by an inverse rare-mass factor, and adding even the missing terminal bit changes the observed experiment. Equation (1) is not asserted for those augmented laws.

For a known u, one can give an upper comparison with all costs explicit: Alice reveals the one missing terminal symbol (at most one bit), so Bob knows the actual pair; Bob estimates t from his parity subsequence as above and uses qhat=u that/w. This is a statistical protocol, not an architectural implementation.

The same estimator has conditional absolute error <=C min{1,1/(u sqrt(m))} given EACH terminal pair. To justify this without substituting an independent query: run the stationary pair chain backward from the specified terminal pair. The archive supplies the reverse-kernel common-atom bound Q^2(x,D)>=1/8. It implies geometric contraction from every reverse start. For the bounded parity-pair indicators, the conditional average has bias O(1/m) relative to its stationary mean and variance O(1/m). The bias follows by summing the geometric distance to stationarity. For the variance, condition at the end of the earlier block in reverse time; conditional expectations of a later bounded block from two possible states differ geometrically, which bounds its covariance under an arbitrary reverse start. Adjacent/overlapping blocks contribute only O(m) to the variance sum. Hence the conditional MSE is O(1/m), uniformly in the terminal pair. At m=1 use any clipped fixed estimate.

The SAME-history averaged loss of this known-u protocol is consequently

    u E[|that-t| | terminal A]
      +w E[(u/w)|that-t| | terminal C]
      <= C u min{1,1/(u sqrt(m))}
      = C min{u,1/sqrt(m)}.                       (10)

The rare factor u is retained. Equation (10) is worse than the full-history u/sqrt(1+Nu) rate when u is small and Nu is large. It does not show that this parity split invalidates every rare-family communication lower.

All of (1)-(10) assume stationary initialization. Arbitrary starts are not silently covered; the existing all-zero-start obstruction remains applicable to u-scaled finite-horizon risk claims.

## 5. An additional obstruction when u is unknown

A stronger, different statement concerns protocols with NO data message except disclosure of the missing terminal symbol. Let Q_N be ONE source-independent normalized predictor using only Bob's parity subsequence and the actual terminal pair, with optional source-independent randomness. It is not given u or t.

There cannot be a finite universal C such that for every N, 0<u<=1/100, and t in [1/2,3/4],

    R_(N,u,t)(Q_N) <= C u/sqrt(1+Nu).             (11)

Proof. Fix N and t and let u decrease to zero. The finite observation law converges to the well-defined stationary u=0 law supported on pair states B,C,D. Under this limit q=0, so the correct next-zero probability at terminal C=10 is zero. The RHS of (11) tends to zero. Nonnegativity of loss therefore forces Q_N's predicted next-zero probability to vanish almost surely on every observation ending in C that has positive probability at u=0, including its randomized expectation.

Every combinatorially consistent parity-history/terminal-C observation has positive u=0 probability. To see this, assign all unobserved symbols to 1 except the prescribed terminal zero if it is unobserved. This completion has no adjacent zeros. Its initial pair lies in B,C,D, each of stationary probability 1/3, and every transition along it has positive probability at u=0 (the C->B transition has probability one; the B,D exits have probability 1/2). Thus Q_N must predict next-zero probability zero on ALL possible observations ending in C, under every u>0 as well.

For every u,t this alone contributes

    Pr(terminal C)*q=wq=ut>=u/2

to averaged TV. Choose N large enough that C/sqrt(1+Nu)<1/2 to contradict (11).

This is not a contradiction with the known-u estimator or the full-history u-blind upper. A known-u estimator changes with u. The full history can exhibit adjacent 00, an event absent at u=0, whereas every parity observation compatible with terminal C remains possible at u=0. Arbitrary Alice messages can also reveal such events and escape this support argument. No general positive-bit communication bound follows from it.

## 6. Scope and prior-work relationship

Read locally: rare_context_reconciliation_20261104_2104/RECONCILIATION.v2.md; the binary lag-two one-invocation candidate; source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md; prior_art/comparison.md; and the archived original ICML research plan. The current statement is neither the previous lag-two opposite-sign source (whose party marginals match exactly) nor the prior-art counting/normalized-statistics construction. It extends the rare-family reconciliation's population identifiability observation to a concrete finite-sample information bound and a precise known/unknown-u distinction.

The lower endpoint t=1/2 is deliberate. For t=1/4, long all-zero parity runs can amplify the posterior rare state: at u=0 the competing hidden persistence scales are (1-t)^2=9/16 and 1/2. Thus the pathwise O(u) filter bound used here does not extend by the same argument to the original entire t interval. We do NOT infer that KL necessarily exceeds O(Nu^2) there; a separate average-likelihood argument would be needed.

Remaining bridge: bound the information in Alice's message conditional on Bob's dependent parity history, account for terminal events and rare loss, and simulate repeated useful attention with all resource charges. None of the present results supplies that bridge, an architectural upper implementation, or a novelty certification.
