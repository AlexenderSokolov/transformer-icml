# Independent rare-parity information audit

6 November 2026 UTC.

Target: `RARE_PARITY_INFORMATION.candidate.v1.md`, SHA-256 `3ecd8e9b9d998996f3ea3a4271c7d45e1899bab78834ac63b8e2004ec7f7191e`.

Verdict: the stated observation-channel KL inequality, known-u estimation order, terminal-aware upper comparison, and separate unknown-u support obstruction are mathematically supported on the specified stationary parameter rectangle. They do not provide an architectural or general positive-message communication lower bound. No blocking correction was found.

## Hidden filter and constants

Multiplying the displayed pair kernel twice gives the identical B,D rows (q/2,(1−q)/2,1/4,1/4). The A,C rows restricted to next observed zero are exactly ((1−t)^2,t/2) and (q(1−t),(1−q)/2). Thus the denominator, posterior update and observed-one reset all use the correct hidden states.

On 0<u≤1/100 and 1/2≤t≤3/4, q≤25u/11 and q'=u/w≤100u/33. Both zero-transition row sums lie in [7/16,1/2]. The stationary first-zero posterior is 3u/(1+2u), independent of t, and at most 2q. A zero following an observed one resets the posterior to 2q/(1+2q)≤2q. For z≤3q, the numerator is at most 5q/4, so the next posterior is at most 20q/7<3q. This establishes the pathwise z≤3q≤7u invariant.

The determinant in the fractional-linear derivative is (1−t)(1−t−q)/2, nonnegative on this rectangle. Bounding it by 1/8 and the squared denominator below by 49/256 gives 0≤F_z≤32/49<2/3. The printed fixed-z derivative estimates hold: numerator derivative magnitude is less than 11u; denominator derivative magnitude less than 7u. Since the numerator is at most the denominator, |F_t|≤18u/(7/16)<42u. The reset derivative is below 7u; the initial derivative is zero. The recursion therefore preserves |z'|≤126u. Adding the explicit emission derivative yields the conservative 133u bound. No parameter-dependent history or hidden-state information is revealed in this comparison.

All prefix-conditioned emitted zero probabilities lie in [1/4,1/2]. The first marginal is t-independent. The Bernoulli relative-entropy bound has constant 16/3, and (16/3)133²<100000. Applying the chain rule on common observed prefixes gives the stated directed KL for m−1 updates, including zero KL at m=1. An auxiliary stationary extension at the left edge is legitimate and does not alter Bob's observation.

## Parameter estimation and terminal query

The chosen local alternatives remain inside [1/2,3/4]. Their separation h=min(1/8,1/(1000u sqrt(m))) ensures KL≤1/10. Pinsker and the two-point testing reduction give the stated lower, with the factor 1/4 a valid conservative constant. Source-independent randomization cannot circumvent this argument, since it is a common Markov kernel applied to the observed experiment. This is a known-u lower at a fixed common u.

For the known-u upper, the pair-indicator expectation u(1−t)+w/2 is exact. Indicators separated by a parity lag are bounded functions of finite pair-chain blocks. Conditioning at an earlier block endpoint and applying the archived geometric contraction controls nonoverlapping covariances by a summable geometric sequence; overlapping blocks add only a constant per index. Hence the variance is O(1/m), without an independent-sample assumption. Inverting the expectation costs 1/u, and interval projection caps the risk, proving the claimed order.

The candidate correctly refuses to infer an A-conditional prediction lower from unconditional parity KL. Disclosure of the missing terminal bit and conditioning on the rare terminal event change the statistical experiment. No conditional KL bound is supplied or used.

For the terminal-aware upper only, the stationary reverse-chain argument is sufficient. Starting the reverse pair chain from each fixed terminal state gives an O(1/m) bias and O(1/m) variance for the bounded block average, by the same uniform contraction and covariance argument. This does not require an independent terminal query. The reverse common-atom claim is consistent with the displayed kernel: Q has rows (1−t,0,t,0), (q,0,1−q,0), (0,1/2,0,1/2), (0,1/2,0,1/2), so Q²(x,D)≥1/8 on the stated range. Multiplying the A error by u and C error by w·u/w produces C min(u,1/sqrt(m)), as claimed. This upper uses known u and one terminal-symbol disclosure, and remains a statistical protocol rather than a network.

## Unknown-u support obstruction

For each fixed N, the same predictor must work for every positive u. As u tends to zero, finite observation probabilities converge. Nonnegative loss tending to zero forces the predictor's mean next-zero output to be zero on every positive-limit observation ending in C.

Every consistent parity observation with terminal C has such positive limiting probability: assign unobserved symbols to one, except a prescribed unobserved terminal zero. The resulting history has no adjacent zeros and follows only positive transitions among B,C,D at u=0. The fixed terminal pair contributes no contradiction to this completion. Consequently all possible terminal-C observations force output zero even at positive u. Their risk is wq=ut≥u/2, contradicting the desired full averaged envelope for sufficiently large N at any fixed legal u.

The reasoning remains valid for source-independent randomized predictors, because zero expected nonnegative output forces almost-sure zero output at each observation. A predictor allowed to depend on u, or a message exposing a previously hidden adjacent-zero event, escapes the argument. Therefore the obstruction is specific to the stated observation interface and is not a general communication lower.

## Scope

Stationary initialization and the restricted t interval are essential to these proofs. They do not establish the same pathwise filter bound for t=1/4, arbitrary-start u-scaled risk, a message-dependent information inequality, or any width/depth/precision necessity. The full-history comparison is an inherited statistical premise. Identifiability alone was insufficient to settle the rare-mass sample complexity; this audit supports the finite-sample refinement, not a novelty or publication claim.

No numerical enumeration, scientific executable, model execution, upload or rendering was performed.
