from pathlib import Path
import html,re,hashlib
p=Path(__file__).parent

def inline(s):
 s=html.escape(s)
 return re.sub(r'https://[^\s&lt;]+',lambda m:'<a href="'+m[0]+'">'+m[0]+'</a>',s)
def md(s):
 out=[];para=[];code=[]
 def flush():
  if para: out.append('<p>'+inline(' '.join(para))+'</p>');para.clear()
  if code: out.append('<pre>'+html.escape('\n'.join(code))+'</pre>');code.clear()
 for line in s.splitlines():
  if line.startswith('    '):
   if para: flush()
   code.append(line[4:]);continue
  if code:flush()
  if not line.strip():flush();continue
  if line.startswith('#'):
   flush();n=min(5,len(line)-len(line.lstrip('#')));out.append(f'<h{n}>'+inline(line[n:].strip())+f'</h{n}>')
  else:para.append(line)
 flush();return '\n'.join(out)
body=md((p/'REPORT_MAIN.zh.v2.md').read_text())
files=[('A 完整奇偶滤波证明','RARE_PARITY_INFORMATION.candidate.v1.md'),('B 真实终端条件证明修订版','RARE_TERMINAL_PARITY_INFORMATION.candidate.v2.md'),('C 任意交互总通信位数证明','RARE_INTERACTIVE_BITS.candidate.v1.md'),('D 输出范围修订与依赖','RARE_OUTPUT_RANGE_ASSESSMENT.candidate.v1.md'),('E 先行文献逐条核验','PARITY_HMM_PRIMARY_AUDIT.v1.md')]
for title,f in files:
 s=(p/f).read_text()
 lines=s.splitlines()
 lines=[x for x in lines if not x.startswith('Private analytical candidate') and not x.startswith('Read locally:')]
 s='\n'.join(lines)
 if f.startswith('PARITY_HMM'):
  s=s.split('## Access limits')[0]+'\n## Additional primary-source limit\n\nLe Gland–Mevel (2000), https://doi.org/10.1007/PL00009861 , was located but its full theorem assumptions were not accessible. It is not used as theorem-level evidence. The present audit is targeted, not exhaustive.\n'
 body+='<section class="appendix"><h2>'+html.escape('附录 '+title)+'</h2>'+md(s)+'</section>'
style='body{max-width:980px;margin:48px auto;padding:0 24px;font:17px/1.8 system-ui,"Noto Sans CJK SC",sans-serif;color:#17202b;background:#fff}h1{font-size:32px;line-height:1.35;margin:36px 0 24px}h2{font-size:25px;margin:42px 0 18px}h3{font-size:20px;margin:28px 0 12px}p{margin:14px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:15px/1.7 ui-monospace,monospace;padding:16px;background:#f5f7f9}a{color:#145c9e;overflow-wrap:anywhere}.appendix{margin-top:64px}@media(max-width:600px){body{padding:0 16px;font-size:16px;margin:24px auto}h1{font-size:27px}pre{font-size:13px}}@media print{body{max-width:none;margin:0;font-size:11pt}.appendix{break-before:page}h1,h2,h3{break-after:avoid}pre{break-inside:auto}}'
out='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>稀有二阶预测中的子采样信息损失</title><style>'+style+'</style></head><body>'+body+'</body></html>'
f=p/'RESEARCH_REPORT.zh.v1.html';f.write_text(out)
print(f.name,len(out.encode()),hashlib.sha256(out.encode()).hexdigest())
