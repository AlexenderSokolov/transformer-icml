# Rare statistical resource reset result registry

2026-11-06. Latest report: RESEARCH_REPORT.zh.v3.html. No public write or training claim.

## Accepted analytical dependency chain

1. RARE_PARITY_INFORMATION.candidate.v1.md
   Exact two-step filter, stationary pathwise rare posterior, predictive derivative, KL ≤100000(m−1)u²Δ². Matching known-u parameter-estimation rate. Separate u-blind support obstruction. Independently checked by INDEPENDENT_RARE_PARITY_AUDIT.v1.md.
2. RARE_TERMINAL_PARITY_INFORMATION.candidate.v2.md
   Depends on 1 and exact stationary reversal. Global filter contraction plus summable terminal transient. Conditional-A KL ≤10^6(1+mu²)Δ²; actual overall parity-plus-terminal risk lower. Independently checked by INDEPENDENT_TERMINAL_PARITY_AUDIT.v1.md. v1 preserved with intermediate constant-chain error; v2 corrects145 to149 and63075 to66603, without changing finalKL constant.
3. RARE_INTERACTIVE_BITS.candidate.v1.md
   Depends on 2, standard KL convexity, binary protocol-tree cardinality, and Laplace maximum-entropy inequality. Risk ≥c u2^-b/sqrt(1+mu²), with knownu allowed and real same-history terminal pair given freely to both parties. Independently checked by INDEPENDENT_INTERACTIVE_BITS_AUDIT.v1.md.
4. RARE_OUTPUT_RANGE_ASSESSMENT.candidate.v1.md
   Depends on inherited full-history statistical risk and pointwise interval projection with alpha≤1/4. No new statistics or actual network compilation. Independently checked by INDEPENDENT_OUTPUT_RANGE_AUDIT.v1.md.

## Prior art

PARITY_HMM_PRIMARY_AUDIT.v1.md: targeted original statements in AGN 2106.12936v3 Prop2, AGN2306.16293v2 AppBProp11, Tadic–Doucet2020 Ass2.1–2.3/Thm2.1–2.2. General methods are established. No equivalent two-state positive-emission representation of the concrete parity process has been proved. No priority certification.

## Failures and next gate

PROBLEM_CARD_AND_FAILURES.v1.md preserves the earlier zero-marginal-information failure, identifiability-vs-rate distinction, restricted t range, and missing actual-network simulation. ATTENTION_BRIDGE_STOPPING_GATE.v1.md explains that the logarithmic total-bit lower can be compatible with a single sufficiently precise scalar message, so it does not force multiple attention invocations.

## Report versions

Reportv1 missed alpha≤1/4 in the Chinese projection summary, retained an obsolete review status in one adapted appendix and contained truncated hrefs. Reportv2 corrected these. Reportv3 also explicitly preserves N−2 in exact trajectory KL and labels the full-history parameter comparator as an attainable upper bound. Original candidates and reports remain unchanged.

The HTML contains a Chinese main discussion and five sanitized technical appendices. It is not a byte-identical embedding of source candidates. Static QA has been performed; visual rendering was not performed. No scientific simulations, training, finite enumerations or formal verification were used.
