# Rare-family statistical risk and the output-range budget

6 November 2026 UTC. Analytical assessment and elementary corollary candidate, not independently reviewed. No numerical experiments, model execution, parameter generation, uploads or public writes. No new statistical rate or priority claim.

## Decision first

The frozen bounded ordinary-final-logit contract cannot attain the old full averaged rate uniformly over arbitrarily small u. This is explicitly already proved in the local TV/KL boundary archive. Rebranding that impossibility as a new mother theorem would duplicate work.

The suggested necessary contrast log(1/u)+(1/2)log(1+nu) does NOT follow. It is a sufficient scale for a crude additive-clipping bound, and is unnecessarily large as an output-range requirement. The correct weighted common-row range obstruction is w(alpha-q)_+, not w alpha. Projection onto the permitted binary interval supplies a matching statistical-plus-range envelope at the unrestricted full-history level. The actual PreLN implementation of that envelope remains a separate, potentially useful research target.

## 1. Plans, comparison contract and source lineage

Original user plan: `../../v10_intake/source/sources/research-plan/ICML_研究总计划.md`, especially T1/T2 and the rare-context family. Second user plan HTML located at `../../plan_verification_20261104_2102/space_plan_1.html`; its readable local extraction is `execution_plan_text.txt` beside it. The second plan prioritizes joint T1/T2, actual-terminal TV, rare but uniformly mixing contexts, same-resource comparisons, and full antecedent audit before novelty claims. It explicitly rejects algebra alone as novelty.

Recent primary-work audit: `../execution_contract_prior_audit_20261106/MARKOV_NGRAM_EXECUTION_CONTRACT_AUDIT.v1.md`, `CORRECTIONS_AND_CLAIM_LIMITS.v1.md`, and `FROZEN_COMPARISON_CONTRACT.v1.md`. That frozen contract is an interior-source execution-error theorem, not a rare-u theorem. For this new task retain its actual raw-token architecture but do not import its interior source floor or turn execution noise into the statistical objective. Existing Markov/n-gram work already includes source-independent same-history estimation, terminal suffix conditioning, normalization, smoothing, and precision discussion. The remaining possible increment must be a complete costed network/risk connection, not those broad features.

Retained architecture obligations: N raw symbols plus one synthetic terminal; no free contexts, counts or suffix ports; self-inclusive full-prefix causal softmax; actual positive-epsilon full-feature PreLN; paid full state, value, matrix, bias and primitive bounds; final ordinary affine vocabulary softmax. The old constant-envelope version freezes those bounds before N varies. A growing final-logit budget is an explicitly changed resource, not obtainable for free from increasing width or depth under frozen full-state/readout norms. Weights remain source-independent, though may know a declared class boundary rho and N.

Family and theorem source: `../rare_context_reconciliation_20261104_2104/RECONCILIATION.v2.md`, and `../u_blind_full_averaged_20261103_2147/full_averaged_tv_bound_v1.html`. Set n=N-2, A=00, B=01, C=10, D=11, w=(1-u)/3, q=ut/w, 0<u<=1/10, 1/4<=t<=3/4. Initialize stationarily; query is the terminal pair of the same history. The pair stationary law is (u,w,w,w). The common-atom two-step bound and uniform geometric mixing are inherited, not newly proved. They do not authorize arbitrary-start risk bounds.

Inherited unrestricted full-history minimax order is

    s(n,u)=u/sqrt(1+nu),
    c s(n,u) <= inf_g sup_t R_n(u,t;g) <= 1300 s(n,u),
    c=(1-1/sqrt(6))/32.

The upper uses one u-blind mixed predictor: add-one at A, unsmoothed empirical ratio with zero fallback at C, and exact fair B,D. The lower remains valid even when u is known.

## 2. What is already old

1. `../tv_kl_boundary_20261103_2201/TV_KL_boundary_obstruction.v3.md`, Sections 3–5 and 9: at each fixed finite n, every single u-blind finite-logit softmax rule has a positive boundary floor and cannot satisfy the pure s(n,u) envelope uniformly in u. Strict positivity alone suffices, even without a deterministic common range bound. The loss-support obstruction is stronger than the frozen-range specialization.
2. Same source Section 6 and `../clipped_joint_risk_20261103_2217/clipped_joint_risk_derivation.v2.md`, Sections 6–7: clipping at delta gives additive delta/3, exact fixed-n boundary TV delta/3, finite forward KL, and a clipping-specific logarithmic KL penalty. Do not call this a new clipping method or new rate.
3. `../softmax_readout_20261105_0002/SOFTMAX_READOUT.candidate.v2.md`, Sections 2–3: sharp general bounded-softmax TV radius, statistical-plus-range lower/upper, and range versus precision distinction already exist.
4. `../softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md`, Section 9: exact minimum span for a whole interior simplex is already stated. The recent wide actual PreLN witness uses an interior projection idea as well: `../nonlinear_statistical_frontier_20261106/WIDE_PRELN_STATISTICAL_WITNESS.candidate.v2.md`, Section 3.1.

The specialization below is useful bookkeeping, not evidence of novelty or a claim that no archive ever states it.

## 3. Exact necessary common-row contrast

Let Lambda>=0 bound the realized binary logit contrast |z_0-z_1| on every history, and put

    alpha=1/(1+exp(Lambda)).

Every output probability of next-zero lies in I_alpha=[alpha,1-alpha]. Since the true C-row probability is q, stationarity gives, without independence,

    R_n(u,t) >= w (alpha-q)_+.                       (1)

This applies even to predictors knowing u,t and randomized predictors. It is therefore an output range obstruction, not an information or computation bound.

To have R_n(u,t)<=r, necessarily alpha<=q+r/w. When 0<q+r/w<1/2 this is exactly

    Lambda >= log((1-q-r/w)/(q+r/w)).                (2)

If q+r/w>=1/2, (1) supplies no positive contrast lower. If r=C s(n,u), the right side, when nontrivial, equals

    log(1/u)+log w-log(t+C/sqrt(1+nu))
      +log(1-u(t+C/sqrt(1+nu))/w).

Thus for fixed C it is log(1/u)+O_C(1) as u tends to zero, uniformly over n. Increasing nu does not add (1/2)log(1+nu): q itself remains order u and dominates the required interval endpoint. As r tends to zero at fixed u,t, (2) converges to log((1-q)/q), a finite constant.

For any fixed Lambda, taking u down to zero in (1) gives boundary lower alpha/3. Hence a frozen output tuple cannot recover the pure old rate even if unlimited depth, width or history processing were granted.

## 4. Matching output-only statistical envelope

Assume Lambda>=log 3, so alpha<=1/4. Apply the scalar interval projection Pi_alpha to the inherited mixed predictor at every terminal context. The true A-row probability lies in [1/4,3/4], the fair rows lie in I_alpha, and q<=1/4<=1-alpha. For every x in [0,1],

    |Pi_alpha(x)-q| <= |x-q|+(alpha-q)_+.

For all other rows the projection cannot increase error. Therefore

    R_n(projected mixed;u,t)
      <=1300 s(n,u)+w(alpha-q)_+.                    (3)

This sharper inequality does not require independent query selection. It follows pointwise and then uses Pr(terminal=C)=w. The projected rule is u-blind for any fixed Lambda; it uses only the inherited counts and declared output budget.

Let M(n,u,Lambda) be minimax over t, constrained ONLY by output in I_alpha, allowing all measurable full-history predictors. Then

    max{c s(n,u), w(alpha-u/(4w))_+}
      <= M(n,u,Lambda)
      <=1300 s(n,u)+w(alpha-u/(4w))_+.                (4)

The lower combines the inherited statistical lower with (1) at t=1/4. The upper uses (3) and the smallest q. Thus M is within universal constants of s plus that floor. The upper is attained by a single u-blind family for fixed n,Lambda; the lower allows knowledge of u. This is NOT a network compilation theorem, nor a fresh minimax-rate discovery.

## 5. Declared rarity range and false stronger necessity

If the task specifies rho<=u<=1/10, choose

    alpha_rho=3rho/[4(1-rho)],
    Lambda_rho=log((4-7rho)/(3rho)).                  (5)

Then alpha_rho<=q for every allowed u,t, and alpha_rho<=1/4. Projection creates no risk increase at all. The inherited full-history rate holds uniformly over the truncated class with a fixed-in-n output range Lambda_rho=log(1/rho)+O(1).

This is a direct counterexample, at the output-budget-only level, to any asserted necessity of log(1/u)+(1/2)log(1+nu). It is not a counterexample to an additional computational lower under the actual network contract; such a lower would need independent proof.

Choosing alpha of order s(n,u) would make the old crude additive bound of order s, giving the stronger sufficient log range. That choice uses u unless a class bound is substituted. It is unnecessary because projection toward an interior true q does not introduce alpha-sized error. For uniform 0<u<=1/10 at any fixed n, no finite source-independent Lambda(n) restores the pure rate. A declared rho(n)>0, an additive range floor, or a different output interface is mandatory.

## 6. Rare A conditional versus overall risk

Conditioned on terminal A, the statistical order is 1/sqrt(1+nu), and the target next-zero probability stays in [1/4,3/4]. For alpha<=1/4, projection has NO approximation floor on this conditional task. Exact range coverage of the entire target interval requires only Lambda>=log3, independent of u and n. Smaller Lambda creates an endpoint approximation gap (alpha-1/4)_+.

The rare A contribution to full risk carries factor u. The common C contribution carries w approximately 1/3 and its target q tends to zero. This is why an A-conditional resource theorem can remain feasible under frozen output logits while the same claimed overall rare-u rate fails. Neither result may be silently substituted for the other.

## 7. Nonduplicate candidate target and stopping gate

The useful target is a fully charged ACTUAL PreLN implementation of (3), not a new proof of (1):

    R_network <= C s(n,u)+w(alpha-q)_+ + epsilon_impl,

with all raw pair binding, histogram/count extraction, C zero-count fallback, division, interval projection, logit conversion and final-LN interaction compiled. Declare either a known rho (with Lambda_rho) or the additive range-floor formulation. Report resources as functions of N, Lambda/rho and epsilon_impl, including width, effective value dimension, depth, full norms, parameter description and any actual arithmetic assumptions. An epsilon_impl of order s must be justified uniformly on the declared class, not chosen using unknown u.

The existing wide compiler uses an add-one estimator across rows and an interior c-dependent envelope. It cannot simply inherit the sharper rare-family rate: smoothing C reintroduces the old finite-n floor, and c-dependent bounds can diverge as rho shrinks. A successful compiler must explicitly replace the C branch with the unsmoothed zero-fallback estimator followed by projection, and charge all rho-dependent gains/log approximation costs. If the final head and normalized full state remain frozen absolutely, growing Lambda is impossible; identify which resource grows.

Novelty gate: even this would be a specialized compiler/risk composition with inherited statistics. Compare against the recent primary-contract audit and existing logit-conversion compiler before claiming a contribution. The more ambitious fixed-width optimal depth/width/range frontier remains open; (4) is not an architectural lower. Stop if the result is merely another re-expression of clipping or of the already established bounded-logit obstruction.
