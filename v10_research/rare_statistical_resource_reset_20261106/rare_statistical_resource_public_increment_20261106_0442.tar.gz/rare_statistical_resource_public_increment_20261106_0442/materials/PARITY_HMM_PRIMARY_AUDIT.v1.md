# Primary-source audit: rare-u parity information loss and HMM antecedents

6 November 2026 UTC. Targeted primary theorem/assumption inspection, not exhaustive priority certification or independent verification of the parity candidate. No experiment or public write.

## Candidate scope

The proposed comparison is KL of one parity subsequence O(N u^2 Delta^2), versus complete raw trajectory O(N u Delta^2), in the stationary binary rare-context family, 0<u<=.01 and t in [.5,.75]. The subsequence can be represented by a four-state hidden pair chain with transition P^2 and deterministic emission of one coordinate. This is a statistical observation-interface comparison, NOT yet a Transformer resource lower bound. A proof that a network receives only that interface, with all other accesses charged, would be additional work.

## 1. Abraham–Gassiat–Naulet: Fundamental limits

Primary inspected: https://arxiv.org/html/2106.12936v3 (24 October 2022), Section II, Section IV Proposition 2, and proof Section VIII-B.

The setting is a stationary TWO-hidden-state HMM with multinomial emissions. Proposition 2 assumes every entry of both models' emission densities is at least c>0 and max(|phi_2|,|tilde phi_2|)<=epsilon_0(c), where phi_2=1-p-q. It bounds observation-path KL by C(c)n rho^2, with rho their explicit reparametrized statistical distance. Proposition 1 relates rho to the three-observation law. The proof uses conditional predictive laws and KL/chi-square control; these methods are clear antecedents.

Classification: close methodological antecedent, NOT direct application to the displayed four-state deterministic-emission realization. Its positive-emission premise fails for that realization, and no equivalent admissible two-state realization has been established. Merely having a binary observed alphabet does not provide two hidden states. Recasting the model would require a proved equality of all observation-path laws and verification of every constant, not a matching two-point moment alone.

## 2. Abraham–Gassiat–Naulet: Frontiers

Primary inspected: https://arxiv.org/html/2306.16293v2 (15 July 2025), Section 1.2, Section 2, Appendix B Proposition 11 and B.1. Journal record: https://www.jmlr.org/papers/v26/24-2230.html .

This paper studies two hidden states with emission densities on [0,1]. Appendix B explicitly attributes Proposition 11 to Proposition 2 of the earlier paper, extending probability masses to densities. It requires both models' densities uniformly bounded below by c>0 and states KL<=Cn rho^2. Its printed statement does NOT repeat the earlier small-|phi_2| restriction; B.1's lower-bound construction does impose small epsilon. This audit does not repair or certify that broader printed formulation. Either way, its two-state positive-density setting does not directly cover the displayed parity representation. Theorems about estimating transition/emission parameters, with smoothness and distance-to-independence factors, are not the requested parity-vs-full observation experiment.

Classification: strong ancestor for boundary-sensitive KL/minimax analysis and its tools, not a checked direct corollary producing this four-state parity result. No novelty certification follows from this distinction.

## 3. Filter derivatives: Tadić–Doucet

Primary inspected: https://www.stats.ox.ac.uk/~doucet/Tadic_Doucet_stabilityoptimalfilterhigherorderderivatives.pdf , Stochastic Processes and their Applications 130 (2020), 4808–4858; Section 2.3, printed pp.4812–4813, Assumptions 2.1–2.3 and Theorems 2.1–2.2.

Assumption 2.1 requires the observation-weighted transition kernel r_theta(y,x'|x) to lie between epsilon and epsilon^{-1} times one reference measure mu_theta(dx'|y), uniformly over starting x. Assumption 2.2 controls parameter derivatives relative to r_theta; 2.3 supplies domination. Theorem 2.1 establishes differentiability, while 2.2 provides derivative forgetting bounds depending on derivative order and epsilon, with the displayed observation-dependent factors.

Deterministic emissions alone do NOT violate this formulation: the reference measure may have observation-dependent support. However its generic constants do not automatically give the desired u-uniform O(u) predictive derivative. One must verify the actual filtered recursion and track rarity rather than simply invoke generic differentiability/forgetting.

Classification: established general filter-derivative machinery. An O(u) derivative invariant for this special reachable filter is an application-specific calculation, not a new general technique.

## 4. Direct checks on the proposed model (our algebra, not claims imported from papers)

For state order A=00,B=01,C=10,D=11, the two-step probabilities include

    P^2(A,A)=(1-t)^2,   P^2(B,A)=q/2,   q=ut/w.

For the emitted coordinate that gives A emission zero, taking the reference-measure comparison on the singleton {A} forces

    epsilon^2 <= P^2(B,A)/P^2(A,A)=q/[2(1-t)^2].

Thus any such full-state comparison epsilon must vanish as u tends to zero. This does NOT refute filter stability on the reachable posterior set; it prevents treating the generic theorem's epsilon-dependent constants as automatically u-uniform. A tailored low-dimensional filter calculation could exploit the stationary initial posterior and its invariant region.

The boundary observed process is not IID. Using the existing exact parity identity, at u=0,

    Pr(Z_i=0)=1/3,
    Pr(Z_i=0,Z_(i+1)=0)=1/6 != 1/9.

The disappearing object is the t-dependence of this observation law, not dependence of the observations themselves. Consequently the AGN interpretation as distance to the IID boundary is not a literal identification of the current parameter u, even though both problems involve weakly identifiable boundaries.

## 5. Exact obligations before claiming the statistical separation

1. Prove predictive conditional probabilities stay bounded away from zero and one uniformly over reachable parity histories, u and t in the declared interval.
2. Prove their t-derivatives are O(u) uniformly in history length, including the stationary initial filter and the parameter dependence of q. A bound on one marginal moment is insufficient.
3. Apply KL chain rule to the same observation history under both parameters. Show the first-observation KL is zero or otherwise include it. The derivative bound plus Bernoulli KL control then gives the candidate upper.
4. Preserve the complete-trajectory comparison and its actual number of transitions. An O(Nu^2 Delta^2) upper alone is not a matching-order KL theorem; distinguish lower bounds or estimation consequences requiring further work.
5. For architectural use, account for all information outside the parity stream. No network lower follows merely because one party's observation is statistically weak.

The narrow defensible contribution would be a checked, uniform information-loss calculation for this concrete fast-mixing family, plus a justified use in the mother problem. Calling HMM filtering, derivative recursion, KL chain rule, or weak-identifiability minimax reasoning new would be incorrect.

## Access limits

Le Gland–Mevel, Exponential Forgetting and Geometric Ergodicity in Hidden Markov Models (2000), DOI https://doi.org/10.1007/PL00009861 , was located at its publisher. The accessible page exposes only an abstract and a subscription preview; its theorem assumptions were NOT audited. No purchase or login was attempted. It remains a historical lead, not theorem-level evidence here. The independently accessible Tadić–Doucet primary theorem was inspected instead.

One optional targeted extraction was unavailable. Existing web retrieval successfully supplied both AGN primary statements and the derivative paper; no research conclusion depends on the failed extraction. This audit is a targeted check of named results, not a complete search of parity subsampling, deterministic-emission HMMs or all possible equivalent hidden representations.
