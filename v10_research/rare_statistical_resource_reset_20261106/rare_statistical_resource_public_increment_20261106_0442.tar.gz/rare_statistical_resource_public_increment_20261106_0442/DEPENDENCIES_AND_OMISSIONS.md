# Dependencies and omissions

All 27 available source files are represented, including report main v1-v4, HTML v1-v3, terminal candidate v1/v2, failures and stopping gate. Only a service-operation detail in one primary audit is neutrally rephrased; no science or evidence-access limitation is removed. Original-source hashes remain explicit.

External dependencies remain OPEN: prior rare-family reconciliation and full-history statistical rates, source-average simulation boundary, communication and entropy inequalities, exact family/source contract, and primary filtering/HMM theorems with their stated assumptions. The proposed attention-to-bit-cost bridge remains unproved. Report adaptations are documented, not advertised as raw source embeddings.

Not included: third-party full papers, missing theorem-access evidence, absent numerical/training/finite-execution results, unavailable visual screenshots, or missing earlier v10 materials. This is not exhaustive literature coverage, novelty certification or dependency-closed recovery.
