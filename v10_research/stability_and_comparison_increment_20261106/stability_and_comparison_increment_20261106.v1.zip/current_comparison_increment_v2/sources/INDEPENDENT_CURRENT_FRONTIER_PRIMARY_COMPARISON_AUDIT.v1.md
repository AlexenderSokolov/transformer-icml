# Independent audit of the current-frontier primary comparison, v1

5 November 2026 UTC. Analytical, read-only primary-source comparison. This is not a novelty or priority certificate, an independent verification of every cited proof, or a validation of scientific executables. No scientific checks were run, and no public repository was changed. The comparison and earlier research materials were not overwritten.

## 1. Exact target and verdict

Reviewed file: `CURRENT_FRONTIER_PRIMARY_COMPARISON.v1.md` in this directory.

SHA-256: `b014d51666f4cd3d84befe3b3ce172d00852c5181ff6729d40577ec32da6c74e`.

**Verdict: the principal overlap judgments and restrained conclusions are supported by the primary passages inspected. One mandatory bibliographic correction remains: Alman–Song's purported Theorem 1.1 is the wrong locator for the specified version. Preserve v1 and issue a corrected version before treating the comparison as locator-clean.** This correction does not overturn its mathematical comparison. An optional precision improvement is to add Kozachinskiy's Theorem 2 to the checked-location list when mentioning SUM2.

No claim of firstness, general Transformer coverage, optimal repeated-read compression, or a solved general repeated-attention frontier follows from this review. In particular, failure to identify a direct implication in a finite set of passages is not evidence of priority or of impossibility of a cost-preserving reduction.

## 2. Primary checks and the quantifiers that matter

### 2.1 D'Angelo et al.: same-history and source-independent overlap is real

Version: [arXiv:2607.02800v1](https://arxiv.org/html/2607.02800v1), 2 July 2026. Freshly inspected Proposition 3.1, equation (8), Sections 3.2.1–3.2.3, and Appendix E's statement of scope.

Proposition 3.1 is quantified over arbitrary input strings. Its counts and query context come from that same string. The free matching/smoothing parameters can be selected independently of a generating kernel. Thus same-history estimation and source independence are genuine overlap, not distinctions from this paper. For order two, its first layer has two copy heads and its second layer one matching head: three head uses in total, despite only two layers. Fixed order and alphabet give constant representation dimension.

The copy proof sends its sharpening parameter to infinity; Section 3.2.2 separately hardens suppression of early positions. Finite matching coefficients do not bound those other score spans. Section 3.2.3 selects a probability block linearly from a concatenated stream; it is not the target's complete positive-epsilon PreLN/PostLN plus final affine vocabulary-softmax contract. Appendix E preserves symmetry under its assumptions, rather than proving generic optimization convergence. Retain these distinctions, but do not present them as proof that no reduction exists.

### 2.2 Akman et al.: protected static banks and source-class overlap

Version: [arXiv:2610.41038v1](https://arxiv.org/html/2610.41038v1), 29 October 2026. Freshly inspected Assumptions 3/6, Proposition 7, equations (17)–(25), Lemmas 17/18/20/23/24, Theorems 25–27, and Section 5.3.

Equations (19)–(21) preserve position/token coordinates; Lemma 17 states the invariance. Queries and keys read positions only, and values read the original token coordinate. These are prior repeated static-bank reads with public queries, even though gathered coordinates evolve. Do not require other rows' gathered coordinates to stay zero for this argument.

Theorem 26 uses one training trajectory, a separate independent test trajectory, and ordered limits over sample, implementation, quantization, and window resources. Theorem 27 instead samples independent training windows and also requires an independent test. Its bound is quantitative expected TV under further stated assumptions. The source-trained setting differs from one common untrained same-history predictor. Dimensions, interpolator width and sharpening are not uniformly frozen as the approximation is refined.

The current report correctly rejects blanket source-class disjointness. Assumption 3 constrains emission densities, not merely observed transition probabilities. Section 5.3 also prevents reducing the paper's coverage to geometrically stable cases only. No faithful positive-emission representation of the entire local source class or its lag-two hard witness was established here.

**Independent elementary overlap check.** Take one constant latent state and iid Bernoulli(p) observations, p in [c,1-c]. With the binary discrete metric and uniform reference measure, the two emission densities are 2p and 2(1-p), hence at least 2c; they are Lipschitz. Identity quantization has cell masses 1/2. The latent process is stationary and ergodic. The observed law is stationary, belongs to the local binary order-at-most-two interior class, and satisfies the stated emission assumptions. This suffices to refute disjointness, without establishing inclusion of the entire class in either direction.

### 2.3 Rajaraman et al.: normalized constant-width counting is prior art

Version: [arXiv:2407.17686v1](https://arxiv.org/html/2407.17686v1), 25 July 2024. Freshly inspected Theorem 5.1, Remarks 4.2/5.2, the surrounding architecture discussion, and Appendix C.1–C.3's normalization and matching construction.

Theorem 5.1 states three layers, one head per layer, relative positions, layer normalization, and O(S) embedding dimension for conditional k-grams. The main text explicitly says it also holds for the original displayed architecture, although its proof uses a rearranged one. A comparison cannot dismiss the result merely because that proof rearranges normalization.

Appendix C.1 uses paired signs and replaces the normalization notation by v/||v||. The matching construction takes a concentration limit. This is substantial normalization/width/mechanism overlap, without providing the local fixed-positive-epsilon, globally bounded full-resource contract. Remark 5.2 explicitly does not prove finite-bit approximation error for Theorem 5.1; its informal sufficiency discussion must not be promoted into such a proof. Here k denotes context order, not the local paid continuation depth. Neither the representation statement nor the stated finite-precision lower-bound setting directly establishes the local stationary same-history minimax risk-depth theorem.

### 2.4 Ekbote et al.: two-use representation, restricted training analysis

Version: [arXiv:2508.07208v2 PDF](https://arxiv.org/pdf/2508.07208v2), 14 November 2025. Freshly inspected printed pages 7–9, Theorem 3, Remark 2, its proof sketch, and Section 5 assumptions.

Theorem 3 states two layers with one head each, MLPs, relative positions, normalization and embedding dimension 6S+3 for conditional k-grams. The proof sketch sharpens the second attention to a limiting selection. Remark 2 asserts a precision/error scale, not the local implementation contract. Section 5 studies first-order data with a reduced parameterization and assumes an optimal MLP; it is not generic training of the entire higher-order construction. The comparison's expressivity-versus-training distinction is correct. Neither a three-use witness nor Markov-counting existence is a defensible new mechanism on this evidence.

### 2.5 Chen et al.: moment summaries and finite-bit bookkeeping already occur

Version: [arXiv:2606.07205v1](https://arxiv.org/html/2606.07205v1). Freshly inspected Section 2.1, Theorem 2.1, Section 5.1, Lemma 7.3 and its proof, and the quantifier in the randomized coreset statement.

The paper explicitly discusses classical Taylor-moment summaries. Lemma 7.3 stores weighted polynomial features, rounds their aggregate, and controls evaluation throughout a bounded query domain. Thus even finite-bit summary accounting, in broad form, is prior art. A deterministic uniform summary can support an adaptively selected query; this observation itself is not a new representation technique. Theorem 2.1 assumes growing dimension and a specified inverse-polynomial accuracy regime, so its main tight exponents cannot simply be imported into fixed-dimensional, exponentially fine local tolerances. A randomized guarantee for each fixed query cannot silently become simultaneous adaptive-query success. The report correctly treats the local simulation as a specialized application, not first attention compression or an optimal space theorem.

### 2.6 Alman–Song: confirmed technique lineage, wrong theorem number in v1

Version: [arXiv:2302.13214v1](https://arxiv.org/html/2302.13214v1). Freshly inspected Definition 1.1, Theorems 1.3/1.4, Lemmas 3.2/3.4–3.6 and the section heading identifying Theorem 3.8.

**Required correction:** in the comparison's checked-location sentence, replace “Theorem 1.1's regime” with “Theorems 1.3/1.4's regimes (formal Theorems 4.6/3.8).” In this specified version, 1.1 is a definition of exact attention computation, not the claimed theorem. The lower result is conditional on SETH; the upper result has its own bounded-entry/dimension/accuracy regime.

Polynomial factorization and exponential/denominator approximation are genuine antecedents. These results concern computation time, not the local statistical paid-depth risk. No new polynomial-kernel technique or tight compression result follows from changing the ownership accounting or normalizing moment sums. The comparison's substantive distinction survives the locator correction.

### 2.7 Hahn and Kozachinskiy: do not overclaim the lower-bound lineage

[Hahn, TACL 2020 journal PDF](https://aclanthology.org/2020.tacl-1.11.pdf): freshly inspected Lemma 5, Theorem 6 and their surrounding discussion, printed pages 165–166. The single-token influence bound carries parameter/depth-dependent constants, and the proof discussion explicitly fixes depth independently of input length. The next-symbol conclusion concerns the specified formal-language distributions and cross-entropy. It is not the local inverse-square-root growing-depth TV lower. The corrected supplement was not independently read in this pass; no full proof revalidation is claimed.

[Kozachinskiy, arXiv:2412.20195v1](https://arxiv.org/html/2412.20195v1): freshly inspected Definition 1, Theorem 1 and its input-split proof, plus Theorem 2's statement. The terminal token has softmax attention followed by a charged ReLU decoder and a Boolean threshold. Theorem 1 concerns composition; Theorem 2 concerns SUM2. The local report should not imply ordinary probability-output softmax is the final decoder here. Infinite precision with decoder complexity and numerator/denominator splitting are established antecedents, but their tasks and quantifiers do not directly yield the local statistical theorem. Add Theorem 2 to the locator list if maintaining the SUM2 reference.

### 2.8 Information dependencies: identity and scope, not proof closure

Freshly accessed [Hadar–Liu–Polyanskiy–Shayevitz, STOC 2019](https://people.lids.mit.edu/yp/homepage/data/cc_estcorr.pdf), DOI 10.1145/3313276.3316332, and [Caputo–Menz–Tetali, AFST 24(4), 2015, pp. 691–716](https://www.numdam.org/item/AFST_2015_6_24_4_691_0.pdf). Only identity and opening scope were independently checked here. The former's experiment has iid correlated pairs and interactive communication; the latter addresses weak-dependence entropy tensorization. This review supplies neither a fresh proof of those results nor the dependent-transcript reduction needed locally. Existing conditional qualifications remain in force.

## 3. What can remain, and what must be withdrawn

The following can remain as explicitly limited comparison findings:

- The complete frozen F contract was not verified to follow directly from the selected prior theorem statements.
- R is a specialized simulation using established polynomial summaries and stability/protocol accounting; A is an elementary branching or separable-lift extension.
- The causal witness establishes compatibility; the weak low-risk composition is an estimator perturbation with growing anchors and unchanged rate, not evidence that repeated attention improves the statistical frontier.
- Source class, test experiment, normalization convention, output map, total head uses and resource growth must be compared together.

The following must be removed from any older description still used as current evidence; v1 already rejects them:

- First same-history/source-independent Transformer Markov estimator, first smoothing or conditional-count mechanism, first normalized constant-width representation, or first repeated-static-bank construction.
- Separation from Akman solely by stationarity, positivity, or a blanket claim of disjoint source classes.
- First bounded-attention polynomial sketch, first infinite-precision or decoder-sensitive lower bound, or a new general communication/entropy technique.
- A general repeated-self-attention frontier, fixed-anchor consistency, optimizer guarantee, finite-arithmetic certification, or priority inferred from this finite comparison.

The locator error in Section 2.6 is the only required correction identified within the current comparison's substantive scope. The strong broad claims above are not new errors in v1; they are precisely the claims it appropriately withdraws.

## 4. Local version bindings and review limits

The following exact local targets were hash-checked to prevent silently changing the comparison problem. Paths below are relative to `v10_research/`. Their proofs were not all independently rederived during this literature pass.

- `normalized_stationary_frontier_20261105/NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md`: `624219c736392dc9fc755f9d6e32e33b40cf13005436589b85df0a6e4ac90770`.
- Its `NORMALIZED_STATIONARY_FRONTIER.candidate.v2.independent_audit.v1.md`: `7d1ab539cf2e51c80412634f09d7fb12d1483e7412ffb371c261fef08b2e3d72`.
- `local_memory_adaptive_reads_20261105/LOCAL_MEMORY_ADAPTIVE_READS.candidate.v3.md`: `18a9be386641c2831e3f8cb7559c018a34451e7421772029fdf6005a5750c703`.
- In that same directory, `ANCHORED_MEMORY_EXTENSION.candidate.v1.md`: `b805fe74f02bbd61f2f27a59506aff98bf3ebf8942c90acb1d0521f898d71acb`.
- `CAUSAL_PRELN_ANCHOR_WITNESS.candidate.v1.md`: `1ff194ebc9faad5dd8513efb84863df764277e42906c632b8def9edb35b9d43c`.
- `LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md`: `d51e74e89a452411d6eb6ffd6ab393fc3417f95aaed75e8a10dd20f4a970b5cb`.

Public-paper evidence is bound by the exact versioned URLs and theorem/section locators above, or the identified journal/conference PDF where there is no arXiv version suffix. It is not bound by independently captured external PDF byte hashes. No claim of publisher/arXiv byte identity, exhaustive citation coverage, current-latest-version coverage, or complete dependency proof closure is made. Local SHA-256 verification establishes file identity, not mathematical correctness.

This audit preserves the distinction between what a cited paper states, the passages actually inspected, elementary deductions made here, and unresolved transfer or proof obligations. Correcting the locator does not turn any of these limited findings into a firstness certification.
