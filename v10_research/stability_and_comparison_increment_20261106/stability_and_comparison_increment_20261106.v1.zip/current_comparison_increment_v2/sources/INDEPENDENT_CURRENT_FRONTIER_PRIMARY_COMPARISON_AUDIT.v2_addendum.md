# Independent audit addendum: primary comparison v2

5 November 2026 UTC. This is a limited revision review, not a new full literature pass or a priority certificate. No scientific executable was run. Earlier comparison and audit files remain unchanged.

## Exact bindings

- Reviewed `CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md`: SHA-256 `a3cf80d2de833745587ad0da82eb9374655e6c16cad0e0f6e6e0f2e90b2d0aba`.
- Preserved `CURRENT_FRONTIER_PRIMARY_COMPARISON.v1.md`: SHA-256 `b014d51666f4cd3d84befe3b3ce172d00852c5181ff6729d40577ec32da6c74e`.
- Preserved `INDEPENDENT_CURRENT_FRONTIER_PRIMARY_COMPARISON_AUDIT.v1.md`: SHA-256 `19c9e31ae63c0e47db0f24736de843c3b220061af8b255cf6f7d331bf94eacc0`.

All three identities were independently checked. The complete textual difference between the comparison versions was read.

## Changes checked

1. The title and revision note identify v2 and accurately limit the new work to the previous audit's corrections.
2. Alman–Song now cites Theorems 1.3/1.4, corresponding to formal Theorems 4.6/3.8, instead of the nonexistent Theorem 1.1 locator in the specified version. The lower runtime result is explicitly conditional on SETH, while the upper runtime result retains its separate parameter regime. This matches the primary passages already inspected in [arXiv:2302.13214v1](https://arxiv.org/html/2302.13214v1).
3. Kozachinskiy now identifies Theorem 1 as composition and Theorem 2 as SUM2. The readout is accurately described as terminal softmax attention followed by a charged ReLU decoder and Boolean threshold, not an ordinary probability-output softmax decoder. This matches Definition 1 and the inspected theorem statements in [arXiv:2412.20195v1](https://arxiv.org/html/2412.20195v1).
4. No other substantive comparison claim changed. In particular, the same-history/source-independent overlap, protected static-bank precedent, interior-IID source overlap, and all limits on broad novelty or architecture claims are retained.

## Verdict

**PASS for these limited corrections and the resulting targeted comparison.** The sole mandatory locator correction from the v1 audit is closed, and its optional readout/SUM2 clarification is also incorporated. No remaining blocking issue was identified within this revision review.

This verdict incorporates the scope and limitations of the v1 audit. It does not certify all external proofs, a complete dependence-source embedding, local imported-lemma closure, latest-version or exhaustive literature coverage, external PDF byte identity, or novelty/priority. The residual claim remains only that the inspected statements were not verified to directly imply the complete frozen local contract. Nothing in this addendum upgrades that observation into a firstness claim.
