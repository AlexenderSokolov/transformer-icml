# Current normalized frontier and restricted repeated reads: primary-source comparison

5 November 2026 UTC. Targeted theorem-contract audit, not a priority certificate or proof verification of external papers. Primary passages were freshly read through read-only web tools. Older comparisons are preserved, not silently updated. No scientific executable, numerical diagnostic, model run, upload, or public repository change occurred. No private research text was transmitted externally; only public URLs were fetched.

## 1. Freeze the CURRENT comparison target

The comparison target is no longer the older nonstationary ternary marker theorem.

**F: normalized stationary one-use frontier.** NORMALIZED_STATIONARY_FRONTIER.candidate.v2.md, with its accepted exact audit, fixes known c in (0,1/2), stationary binary homogeneous order-two kernels with every conditional probability in [c,1-c], raw symbol onehots, public t/P, and an extra zero-symbol terminal. One source-independent network is evaluated on the same history used to estimate the unknown kernel. Loss is expected TV at that history's actual terminal context. There is no independent training sample or claimed optimizer. Width, query/key/value dimensions, full-state/matrix/full-bias norms, score spans and per-primitive Lipschitz bounds are frozen. Positive-epsilon full-feature PreLN or PostLN and ordinary affine vocabulary softmax are included. There is at most ONE useful physical attention invocation total, with all continuation depth charged. The accepted matching order is 1/sqrt(min(D,N)) above a logarithmic-depth threshold, under a sufficient common resource tuple; it is not an unrestricted-depth or unrestricted-resource statement.

**R: restricted repeated-read simulation.** LOCAL_MEMORY_ADAPTIVE_READS.candidate.v3.md proves a worst-history one-way simulation for token-local K/V banks, even with terminal-adaptive queries. Its cost is O(H(d+1)[D+log(1/epsilon)+1]^(k+1)), capped by N. Public queries remove the polynomial feature factor. Conditional risk conclusions import the separately accepted source-average testing inequality.

**A: anchored extension.** ANCHORED_MEMORY_EXTENSION.candidate.v1.md allows banks depending on their own token and a public anchor set. General dependence costs s_A+2^(s_B) times a branch summary; bounded separable dependence permits a lifted-dimension alternative. Its INDEX example is explicitly abstract and not low-risk. Neither result addresses arbitrary evolving full-row memory.

**W: witness and weak composition.** The accepted causal PreLN witness only proves a nontrivial structural intersection. The accepted LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md combines the known suffix estimator with an asymptotically negligible interaction, using three useful reads and s=b+1 growing anchors. Risk and depth orders are unchanged. This is not evidence of statistical gain from repeated attention.

These four targets must not be merged into a single claimed general theorem. All later novelty judgments refer to these exact scopes.

## 2. Fresh primary-paper ledger and comparisons

Each subsection identifies checked theorem locations, overlaps and the decisive unmatched obligation. Statements about what was not found are limited to those locations, not the entire literature.

### D'Angelo et al., Induction Heads Interpolate N-Grams

Primary: https://arxiv.org/html/2607.02800v1 . Checked Section 2.1, Proposition 3.1/equation (8), Sections 3.2.1-3, Corollary 4.1, Appendix E; the earlier PDF locator is printed pp. 5-10, 29-37.

Proposition 3.1 is pathwise for arbitrary input strings. Its weighted-count estimator is source-independent and uses the SAME history; it is not merely a source-trained lookup. Fixed order/alphabet gives constant representation width. Additive smoothing and partial-context interpolation therefore cannot be local novelty claims. At order two it uses three useful head invocations. Copying and early-context suppression use hardening limits; finite matching beta does not bound those other scores. Its disentangled model uses concatenation, relative-position scores and a linear selector, rather than F's complete normalized/output contract. Appendix E gives symmetry preservation, not general optimization convergence.

**Comparison:** same-history/source-independence is overlap, not a separation. Frozen full-resource accounting, one-total-use restriction, synthetic-terminal interface and the actual-terminal minimax depth-risk theorem remain unmatched in the checked statements. W cannot be marketed merely as a three-use Markov circuit; that broad mechanism is already prior art.

### Akman, Feldman Starosta, Saldi and Yüksel

Primary: https://arxiv.org/html/2610.41038v1 . Checked Assumption 3, Proposition 7, Theorems 25-27, Section 5.3, equations (19)-(24), Lemmas 23-24.

Theorem 26 treats stationary ergodic training trajectories and independent tests through iterated limits; Theorem 27 gives quantitative expected-TV bounds. Section 5.3 includes non-geometric stability. Their M gatherers preserve token/position coordinates, read those coordinates for K/V, then interpolate with width R^M-1; embedding dimension is 2M+R+1. The supplied window is unmasked, with final-token softmax. Sharpening and resources grow. The target is source-specific/source-trained, not F's source-independent same-history estimator.

**Newly emphasized overlap:** equations (19)-(21) are an explicit prior repeated-static-bank architecture. R's structural vocabulary is not itself new. Those gatherers have public queries; their increasing dimension/norm/sharpening prevents substitution into frozen constants.

**Correction to obsolete separation:** F is now stationary/interior. The old ternary zero-transition and nonstationary-initialization exclusions do not apply. Positive observed transition probabilities neither prove nor disprove a faithful positive-emission hidden representation. IID interior sources demonstrably overlap. Independent training/resource/target differences suffice; no blanket source-class disjointness is asserted.

### Rajaraman et al., Transformers on Markov Data: Constant Depth Suffices

Primary: https://arxiv.org/html/2407.17686v1 . Checked Theorem 5.1, Remarks 4.2/5.2, Section 6 and Appendix C.1-C.3; prior locator for attention-only results is Theorems 4.4-4.5.

Theorem 5.1 gives three layers, one head per layer, relative positions, normalization and O(S) embedding dimension for empirical conditional k-grams. The construction uses concentrated selection, and Appendix C redefines normalization as v/||v|| after paired-sign embedding. Thus fixed-width normalized Markov counting, paired signs, and the importance of paid local decoding all have close antecedents. Their parameter k is source order, not F's history horizon or paid continuation depth. Their precision remarks do not establish the present exact epsilon-one/global-Lipschitz contract.

**Comparison:** this is a stronger overlap than saying that earlier work only studies unnormalized attention. The unresolved transfer is the complete frozen positive-epsilon normalization/score/resource contract and F's statistical experiment. Its finite-precision representation lower is not a same-history expected-TV lower. W's three-use existence statement alone is substantially weaker than this established representation result.

### Ekbote et al., What One Cannot, Two Can

Primary PDF: https://arxiv.org/pdf/2508.07208v2 . Checked printed pp. 7-9: Theorem 3, Remark 2, the following construction and reduced-model training assumptions; Appendix A.1 is recorded in the prior audit.

Theorem 3 improves empirical conditional k-gram representation to two layers, one head each, embedding dimension 6S+3. Its construction describes a sharpening limit and relative-position machinery. Remark 2 states a precision/error claim; it must not be conflated with a certification of the current finite-arithmetic implementation. The training analysis is for a reduced first-order model, with specified data assumptions and an already-correct MLP component, not the whole higher-order construction from generic initialization.

**Comparison:** fewer layers, ordinary causal representation, and Markov estimation mechanisms are not our novelty axis. The source paper already separates expressivity from optimization. F supplies a different frozen-resource risk-depth question, not an improvement in minimum layer count; W has no competitive layer-count or learning claim.

### Chen et al., Towards Tight Bounds for Streaming Attention

Primary: https://arxiv.org/html/2606.07205v1 . Checked Section 2.1, Theorem 2.1, Lemmas 5.1/7.3 and their proofs, Section 7.

The paper explicitly describes the classical constant-dimensional Taylor-moment method, with binomial(d+t,t) moments. Its weighted polynomial feature identity and stored summaries are direct antecedents of R. Main tight theorems have growing-dimensional and accuracy regimes; some randomized coreset guarantees are for fixed queries, whereas deterministic polynomial approximation is uniform over a bounded query ball.

**Comparison:** R's adaptive-query guarantee follows from a uniform deterministic summary plus ordinary error propagation; query adaptivity does not make the polynomial sketch a new representation. Its finite-dimensional quantization, off-trajectory projections and one-way ownership accounting are local adaptations. Do not import the paper's tight main space exponents into fixed-k, exponentially small local tolerances. Conversely, do not advertise R as first bounded-attention compression. The elementary INDEX barrier in A has extensive communication precedent; this paper itself employs INDEX in a more demanding streaming reduction.

### Alman and Song, Fast Attention Requires Bounded Entries

Primary: https://arxiv.org/html/2302.13214v1 . Checked Lemmas 3.2, 3.4-3.6 and Theorem 1.1's regime.

Polynomial inner-product kernels admit finite-rank feature factorizations; approximation of exponential weights and denominators yields approximate attention. The main result concerns runtime and entry-size/dimension regimes, not a statistical prediction depth theorem.

**Comparison:** R's monomial lift and A's separable-key lift are built from established algebraic machinery. Normalizing averaged moments removes a length factor in radius, but does not create a new kernel technique. R's displayed exponent is deliberately coarse; no matching or optimal-compression claim is justified. An architecturally specialized corollary remains useful documentation, not evidence of technique novelty.

### Hahn, Theoretical Limitations of Self-Attention in Neural Sequence Models

Primary: https://aclanthology.org/2020.tacl-1.11.pdf . Checked Lemma 5 and Theorem 6, printed pp. 165-166. The prior local comparison also records the author's corrected attention-weight proof supplement, https://www.mhahn.info/files/transformers-proof.pdf ; that supplement was not freshly retrieved in this pass.

Single-token sensitivity and its consequences for next-symbol loss are established. Constants depend on parameters and fixed depth. This is the appropriate lineage for the small-signal witness, not a novelty claim for influence decay.

**Comparison:** F's inverse-square-root paid-depth lower uses a different information/testing argument rather than following merely from the O(1/N) sensitivity statement. R/W's bounded-stage error propagation is standard analytic bookkeeping. Explicitly carrying a growing D and uniform full-vector constants matters, but cannot be called the first Transformer loss limitation.

### Kozachinskiy, Lower bounds on transformers with infinite precision

Primary: https://arxiv.org/html/2412.20195v1 . Checked Definition 1 and Theorem 1/proof.

The paper replaces precision restrictions by output-ReLU complexity for one-layer terminal-output softmax models, using VC dimension for composition and SUM2. The numerator/denominator decomposition across an input split is explicit.

**Comparison:** exact-real semantics plus a charged decoder is established lower-bound practice. Its tasks and output criterion do not directly yield F's stationary statistical bound. F should not be described as the first infinite-precision or first decoder-sensitive attention lower bound. A's abstract random-access example is likewise not a new communication problem.

### Existing information-theoretic dependencies

Fresh primary access: Hadar–Liu–Polyanskiy–Shayevitz, https://people.lids.mit.edu/yp/homepage/data/cc_estcorr.pdf ; Caputo–Menz–Tetali, https://www.numdam.org/item/AFST_2015_6_24_4_691_0.pdf . The former concerns communication-limited correlation estimation; the latter approximate entropy tensorization under weak dependence. This pass checked identities and scope, not their complete proofs.

F/R inherit local adaptations of these information tools. The IID interactive result does not automatically apply to an interleaved dependent Markov transcript; the accepted source-average package already records that gap. Their existence also precludes presenting communication-risk scaling or entropy tensorization as new general methodology here.

## 3. Which current claims survive, and which should be downgraded

### Explicit overlap check, not a universal source embedding

Our own elementary check for the source warning is as follows. Fix p in [c,1-c]. Take a single deterministic latent state and independent Bernoulli(p) observations, with uniform reference measure on the two-symbol observation space. Emission density is at least 2c; on the discrete metric it is Lipschitz, and each nonempty singleton cell has reference mass 1/2. This stationary IID observation law belongs to F's source class. Thus categorical source-class disjointness is false. This construction does not embed the genuinely second-order lag-two lower witness and establishes no such embedding.

### Candidate residual scientific claim

F has a narrow, nontrivial complete contract: the same stationary interior binary experiment, one source-independent same-history predictor, one total useful invocation, fixed width and complete norms, both genuine positive-epsilon normalized architectures, standard softmax, and a matching paid-depth/risk order over the stated depth range. None of the checked theorem statements was verified to imply that whole conjunction directly.

This is a statement about the result of this comparison, not a priority finding. The statistical exponent, estimation method, communication technique, normalization pairing and matching-order composition are individually inherited. A shorter generic derivation or unexamined theorem could still cover the conjunction. Do not make lack of a search match part of the proof.

### Supporting results with high derivability/overlap risk

1. **R's static-bank simulation:** classify as a specialized corollary/application of polynomial attention summaries plus explicit stability and protocol accounting. The conditional risk transfer is a composition with the local statistical lower, not a new independent estimator theorem.
2. **A's branching and separable lift:** elementary protocol transformations under a useful structural certificate. Its exponential branch necessity is a standard random-access argument. Do not present either as a new general lower-bound principle.
3. **Causal witness:** a correct concrete compatibility check. It demonstrates nonempty intersection, not a novel prediction mechanism; its original risk is bounded away from zero even on suitable interior IID sources.
4. **Weak low-risk composition:** a controlled perturbation of an existing estimator, with growing anchors and unchanged rate. Its exact-support proof closes a technical membership gap, but the statistical existence conclusion should be treated as a corollary rather than a new main theorem.
5. **Source-average equivalence:** useful to expose circular reasoning, but an equivalence assembled from a testing lower and generic suffix upper is not evidence that the general architectural conjecture has been solved.

### Claims that should not appear

- First same-history/source-independent Markov estimator in a Transformer.
- First TV-prediction, smoothing, finite-memory, normalized, fixed-width, infinite-precision, or trained-Transformer theorem.
- First repeated-static-memory architecture or bounded-attention polynomial sketch.
- A general repeated-self-attention depth frontier, fixed-anchor consistency, or practical learned/finite-precision guarantee.
- A separation from prior work based solely on stationarity, positivity, use of ordinary softmax, or a head count stated per layer instead of total uses.

## 4. Contract tests for any purported subsumption

A future paper or proposed corollary should be tested against the following before concluding overlap or separation:

1. Is the kernel unknown to one common predictor, or encoded through parameters/training? Which independent observations are available before testing?
2. Is loss at the realized terminal context on the same estimation history, or at an independently sampled query/window? Is it expected TV, worst-word representation error, KL, or prior-averaged loss?
3. Are stationary initialization and fixed c retained? Are all source constants uniform over the claimed supremum?
4. Is attention use counted across all layers? Do nonterminal K/V evolve from other tokens, or remain protected local banks?
5. Are width, FFN width, full vector norms, biases, Q/K norms and score spans uniformly frozen while N,D and accuracy vary?
6. Does normalization have fixed positive epsilon and globally controlled gain? Is the final ordinary probability output computed inside the charged graph?
7. Are supplied windows, relative-position tables, sharp-selection limits, precision, coefficient descriptions and local computation charged?
8. Does an existence/representation theorem include training convergence, or is that a separate claim?

No one difference automatically establishes novelty. Several different models can still imply each other by a cost-preserving reduction; that reduction must be written and checked.

## 5. Audit provenance and limits

The prior nearest-paper audit dated 4 November compared a ternary/nonstationary frontier. Its primary locators remain useful, but its source-exclusion paragraphs cannot substitute for this updated comparison. Earlier matching-depth and all-row audits address different targets and are not silently promoted to F.

Fresh reads in this pass used the public versions linked above, with exact numbered theorem/section locators. HTML mathematics occasionally has broken cross-references; explicit theorem numbers and the Ekbote PDF were used rather than inferring content from abstracts. No byte-identity assertion with publisher PDFs is made. No exhaustive citation-graph traversal or search for every newer version was performed.

Local targets read include the accepted normalized frontier, source-average README.v3 and tradeoff/equivalence results, local-memory/anchored accepted candidates, the causal witness and weak-composition exact audits. Prior records consulted: nearest_paper_audit_20261104_2102/{dangelo_audit.md,akman_audit.md}, matching_novelty_audit_20261104/NOVELTY_ASSESSMENT.md, prior_art/comparison.md, and closest_literature_comparison_20261105_0157/ALLROW_SINGLE_INVOCATION_PRIMARY_COMPARISON.v1.md.

The report deliberately separates external theorem facts from our contract comparison and from unresolved implications. It does not independently certify every external proof or identify every possible corollary.
