# Current frontier primary-source comparison, preserved versions

This increment preserves comparison v1 and v2, the independent v1 audit, its v2 addendum, and both source hash-binding lists. All six source files are byte-identical to the retained originals. Version 1 is historical: its Alman–Song theorem locator required correction. Version 2 corrects that locator and clarifies the Kozachinskiy SUM2 theorem and readout; the addendum reports a limited PASS for those revisions. The historical error and review are not removed or retroactively rewritten.

The comparison distinguishes the normalized stationary one-use frontier, restricted token-local repeated reads, anchored extensions, and the weak growing-anchor composition. It records checked primary-source locations, overlap, and unresolved implications. It is not an exhaustive novelty search, priority certificate, independent verification of every external proof, or a proof of a general repeated-attention advantage.

Historical statements about no upload or repository mutation describe the time of the source reports, not this subsequent archive. Packaging did not access external sources or execute scientific code. Referenced research dependencies remain separate.
