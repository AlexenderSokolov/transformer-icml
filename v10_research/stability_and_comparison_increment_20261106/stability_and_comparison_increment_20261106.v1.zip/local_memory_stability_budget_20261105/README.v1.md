# T1/T2 resource ledger: weighted adaptive reads and endpoint reconciliation

This package makes one supporting resource-proof refinement and explicitly reconciles it with an older stronger endpoint obstruction. It is not a new main theorem for general repeated self-attention.

## Scientific status

- STABILITY_BUDGET.candidate.v1.md: replace H A^D by the certified weighted budget W. Communication scales with J F_k(2+log(1+W)+log(1/epsilon)); the risk inversion retains log(J+1). Exact independent audit: PASS conditional on inherited local-bank/off-trajectory/testing assumptions.
- ENDPOINT_TRANSFER.candidate.v1.md: apply the earlier accepted endpoint-risk argument to the same W. Fixed nontrivial accuracy requires W=Omega(N); nonexpansive terminal dynamics imply H=Omega(N), even for growing J. This is a corollary of existing methods, not a new endpoint principle. See its separate exact-version audit for status.
- The fixed-J bounded-W inconsistency statement in the first candidate is valid but weaker than the endpoint transfer. Do not advertise it as a separate stronger result. The communication lower can still matter after W is large enough that the endpoint lower is vacuous.
- The prior logarithmic-depth startup threshold already exists in MATCHING_ORDER.v2.md. Its rediscovery was rejected and documented.

## Deliverable

RESEARCH_REPORT.zh.html contains a Chinese synthesis and the full exact English proofs and audits. Documentary build_report.py assembles it. HTML source structure is checked; browser visual inspection has not been performed. No visual QA pass is claimed.

All candidates and logs are versioned. No earlier research material was overwritten. No scientific executable, numerical experiment, training, public upload, repository mutation or purchase occurred. The report generator and manifest checks are documentation actions, not theorem verification.

## Main unresolved obligation

A resource-controlled source-average simulation or strict counterexample for genuinely evolving nonterminal memory above the already-known endpoint threshold remains open. Neither weighted error propagation nor static-bank polynomial moments supplies that missing structural theorem. These results concern exact-real forward expressivity/resource necessity, not training or floating-point reliability.
