# Stability-weighted adaptive reads: when more calls cannot yield consistency

5 November 2026 UTC. Analytical candidate v1, pending independent exact-file audit. This is a conditional refinement of the reviewed token-local-bank communication argument, not a result for evolving all-row memory, a claim that normalization is contractive, or a new approximation technique. No scientific executable, parameter generation, simulation, training or public mutation was performed.

## 1. Contract and error-propagation budget

Inherit the source-independent raw binary input, normalized binary terminal output, fixed key dimension k, value dimension d, norm bounds, exact-real protocol semantics and token-local nonterminal bank restriction of LOCAL_MEMORY_ADAPTIVE_READS.candidate.v3.md. The H useful terminal reads use J distinct COMPLETE nonterminal banks, 1<=J<=H<=D. Banks include position-dependent maps, are independent of earlier terminal answers, and may depend on public N and architecture parameters. Bob recomputes terminal self K/V. Adaptive queries are allowed.

Replace the coarse common stage gain A by explicit certificates as follows. Write the extended terminal computation as D stages F_s. On the proof-side projected domains (including perturbed trajectories), for every fixed raw history each F_s is a_s-Lipschitz in the dynamic terminal state, uniformly in histories. The nonnegative a_s are public, source independent and may vary with N and depth. Public fixed coordinates may be removed from the metric only if their common values are hardwired and the exact and simulated stages preserve this affine slice. No sample-dependent coordinate may be omitted.

At each read stage s, replacing its attention answer by an approximation of Euclidean accuracy delta incurs local output error at most b_s delta at the SAME input state. The public b_s>=0 includes the output projection and any same-stage continuation. Other stages are exact. Require these local certificates uniformly on the same projected domain. Primitive attention reads have b_s=1; bounded output projections or complete blocks supply a fixed finite b_s from their displayed maps. This is a checkable sufficient condition, not an assertion about all residual or LN blocks.

Define the actual error-propagation budget

    W = sum_(s a read) b_s product_(l=s+1,...,D) a_l,
    U = 2 + log(1+W).

Empty products are one. All logs are natural. W uses gains of the exact extended maps, NOT derivatives only on the exact trajectory and NOT the Lipschitz constant of the quantized simulator. W may be zero.

## 2. Communication theorem

For F_k(t)=t[t/log(e+t)]^k and 0<epsilon<=1, one deterministic source-independent one-way protocol satisfies worst-history terminal TV error <=epsilon using

    C <= min{N, K J(d+1) F_k(U+log(1/epsilon))}.             (1)

K depends only on the frozen norm bounds and k, not on N,D,H,J,W or the individual a_s,b_s. When W=0 zero communication suffices, although (1) is a valid loose estimate. If all queries are public data-independent and there are J_q distinct complete (bank,query) pairs, then

    C <= min{N, K J_q(d+1)[U+log(1/epsilon)]}.              (2)

J_q need not equal J: shared banks with different public queries are distinct pairs. This distinction prevents an unjustified public-query reuse claim.

Proof. Let e_s be the state error after stage s. Comparing the approximate stage at its own simulated input with the exact extended map at that same input yields

    e_s <= a_s e_(s-1) + 1_(read s) b_s delta.

The initial terminal state is public, so e_0=0. Induction, valid also for zero gains, gives e_D<=delta W. Final Euclidean projection onto the binary simplex fixes the exact output, is nonexpansive, and binary TV is at most Euclidean error. Choose delta=epsilon/(1+W), hence e_D<=epsilon. When W=0 any bounded approximate attention answers yield zero final error by the same recurrence, so Bob needs no message.

For W>0 use the reviewed factorial-normalized monomial moments, with one eta-net index per distinct bank. Their radius exp(R_k^2/2)sqrt(V^2+1) is independent of N and polynomial degree. Uniform numerator/denominator error is bounded by

    sqrt(V^2+1) exp(B) B^(m+1)/(m+1)! + exp(R_q^2/2) eta,
    B=R_q R_k.

The true denominator is at least exp(-B). The reviewed ratio estimate and projection of answers into the value ball turn local augmented error at most c delta into answer error at most delta, with fixed c small enough also to preserve the denominator floor. Choose eta=c' delta and use the reviewed factorial lemma with L=O(1+log(1/delta)). Thus m+1=O(t/log(e+t)), t=U+log(1/epsilon)>=2, and each index costs at most K(d+1)F_k(t). Reuse the same sketch at all calls of its complete bank; uniform query approximation handles adaptive choices without independence or a union bound. Multiplying by J and choosing exact raw-bit transmission whenever cheaper proves (1). B=0 permits exact degree zero.

For (2) use one augmented weighted-sum vector for each distinct public (bank,query) pair. No polynomial expansion is needed, and radius/net arguments give O((d+1)t) bits per pair. The same recurrence proves the result. All local computation remains unrestricted exact-real protocol computation, not a numerical neural implementation guarantee.

## 3. Stationary source-risk consequence

Fix known c in (0,1/2), N>=3, and the same stationary interior binary second-order class P_c as the normalized one-use frontier. All predictors and protocols are independent of the unknown source. Risk is expected TV at the actual terminal pair, followed by supremum over P_c. Define

    v = 2 + log(1+W) + log(J+1),
    S = min{(J+1) F_k(v), N}.

Then every predictor satisfying the above certificates obeys

    sup_(p in P_c) E_p TV(Q_N,p_actual) >= a_c / sqrt(S).   (3)

The positive constant depends also on k,d and the frozen norm bounds. No dependence on the variable stability budget W or J is hidden in it. For W=0 the stronger zero-message constant-risk bound applies. A public-query version follows with J replaced by J_q and k=0.

Proof. Advertise uniform risk r=a/sqrt(S), choose epsilon=r and a<=1/256. Further shrink a so the lag-two testing witness h=16r belongs to P_c. Import exactly the reviewed one-way testing inequality

    (2r)^2 min(C+1,N) >= c0,  c0=1/(16384 ln 2).

If S=N the left side is at most 4a^2. Otherwise S=(J+1)F_k(v)<N. Since v>=2, log(e+v)>=1, and log(J+1)<=v,

    log S <= log(J+1)+(k+1)log v <= C_k v.

Consequently t=U+log(1/r)<=C_k[1+log(1/a)]v; also t need not be >=v. The latter point matters: if t<=v, monotonicity gives F_k(t)<=F_k(v); if t>v, the exact quotient gives F_k(t)/F_k(v)<= (t/v)^(k+1). Hence in both cases

    F_k(t) <= C'_k[1+log(1/a)]^(k+1) F_k(v).

Equation (1) therefore bounds C+1 by K'[1+log(1/a)]^(k+1)S. The testing left side is at most K''a^2[1+log(1/a)]^(k+1), tending to zero as a decreases. One fixed small a contradicts the testing inequality in both branches. This is an advertised-envelope contradiction, not insertion of an unknown actual risk into the construction. The additional log(J+1) is necessary in this inversion absent a separate relation between J and W.

## 4. Three interpretable regimes

(a) General bounded gains. If a_s<=A for fixed A>=2 and b_s<=b, then W<=b H A^D. With H<=D, U=O(D+1). Since log(J+1)<=log(D+1), (1) and (3) recover the earlier factorial refinement up to fixed constants. This is a refinement, not a contradiction of it.

(b) Nonexpansive dynamics. If every a_s<=1 and b_s<=b, then W<=bH. For a fixed number J of reusable banks, (3) gives

    risk >= const / sqrt(min{F_k(2+log(1+H)),N}).           (4)

For H tending to infinity and the resource branch below N, this is order

    [log log H]^(k/2) / [log H]^((k+1)/2),

with the displayed F formula used for small H. Thus fixed-bank nonexpansive recurrence requires substantially more calls than the coarse depth-only bound reveals. For k=0 or fixed public-query pairs, the rate is inverse square root of log H. This is a necessary condition, not a matching constructive rate.

(c) Contractive read stages. If every nonread stage has a_s<=1, every read stage has a_s<=rho<1, and b_s<=b, then after the j-th read there are H-j later reads. Therefore

    W <= b sum_(j=1,...,H) rho^(H-j) <= b/(1-rho).

For fixed J, rho,b and norm/dimension budgets, (3) supplies a strictly positive lower bound independent of N,D,H. Increasing history, intervening nonexpansive depth or the number of such contractive reads cannot yield uniform source-class consistency. More generally any uniformly bounded W and J have this obstruction. It does not preclude pointwise accuracy for a particular known source or an easy subclass.

## 5. Interpretation and limitations

This makes a stability-versus-information tradeoff explicit inside the EXISTING restricted token-local-bank proof: preserving only finitely many uniformly stable reusable summaries limits how much unknown transition information can be extracted. It is not a new general streaming lower bound. The statistic is terminal expected risk; worst-history approximation is used only as a sufficient simulation tool.

Neither positive-epsilon LayerNorm nor bounded scores imply a_s<=1 or rho<1 for a whole residual block. PostLN can have gain greater than one; PreLN has identity paths. Frozen norms alone do not supply (b) or (c). Conversely a model may satisfy a better W certificate than a crude product of full operator norms. Off-trajectory uniformity and all data-carrying coordinates must still be checked. Public fixed anchors can be held fixed, but suppressing varying scratch or past answers in the metric would invalidate the theorem.

Evolving nonterminal K/V, anchor-conditioned banks without their extra communication costs, unbounded read-injection gains, a growing number of distinct banks, or a growing key dimension do not fall under the fixed-J conclusion. A stable architecture outside this subclass may be consistent. Network parameters may depend on N, but cannot encode the unknown transition kernel. The result concerns representation/resource necessity only, not gradient training, learned parameter recovery or optimization.

## 6. Provenance and preserved alternatives

Dependencies read: local-memory adaptive v3 and audits; factorial refinement v1 and its exact-version PASS audit; source-average simulation v2; normalized stationary frontier v2; anchored and weak causal composition notes. Both authoritative Space plans were read through the library tool. Latest repository main was observed at f5ad033f03a2b8fdfc3a5a8576ab9e7b7b253dcb (2026-11-05 21:03:39 UTC), an archival scientific-label correction. No public write was performed.

Prior-work status: exponential Taylor features, norm-ball nets and perturbation recurrences are existing methods, already attributed in CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md. The local increment is an explicit sensitivity-weighted refinement and the associated conditional consistency obstruction. No new literature-priority claim or claim of a sharp bound is made. A current primary-source novelty check is still required before treating it as a contribution.

Rejected shortcut: replacing D directly by log(1+W) in the old risk bound without adding log(J+1) is unjustified when J grows independently of W. The proof above retains it. Rejected stronger interpretation: declaring standard LN networks contractive from their normalization labels; full extended-stage certificates are required.
