# Endpoint acquisition dominates the fixed-bank stability obstruction

5 November 2026 UTC. Analytical T1/T2 addendum, pending independent review. This explicitly reuses an older accepted endpoint argument and downgrades a tempting novelty claim. No new general lower-bound principle or T3 mechanism is claimed.

## 1. Why this addendum is needed

STABILITY_BUDGET.candidate.v1.md proves a weighted communication refinement and concludes that bounded propagation budget W and a fixed bank count J preclude uniform consistency. Internal reconciliation subsequently found a stronger directly applicable argument: BOUNDED_SCORE_TERMINAL_CONTEXT.md (4 November) already proves an actual-terminal expected-TV obstruction from a penultimate-symbol replacement bound. MATCHING_ORDER.v2.md already turns that obstruction into a logarithmic-depth threshold. These older results must not be rediscovered as new claims.

The only local step here is to calculate that replacement bound for the current multiple adaptive token-local-bank class, using the new W ledger. The resulting necessary condition does not require fixed J and is stronger than the communication-derived constant-risk obstruction when W=o(N). It does not replace the communication lower at larger W or answer the unrestricted repeated-attention frontier.

## 2. Finite theorem in the same contract

Inherit exactly the stages, uniform off-trajectory gain certificates a_s,b_s, norm bounds R_q,R_k,V and budget W from STABILITY_BUDGET.candidate.v1.md. Set T=N+1, B=R_q R_k and L0=4V exp(2B). For any two histories differing in one raw token,

    TV(Q_N(x),Q_N(x')) <= L0 W/T.                         (1)

There is no restriction on J beyond the inherited J<=H<=D, and the banks may be distinct at every read. They must remain token-local and terminal adaptation must enter only through the terminal computation.

For fixed c in (0,1/2), choose

    h=(1-2c)/2,  q=(1-h)/2,
    p_h(+1 | a,b)=(1+h a)/2,

with a stationary uniform initial pair on {-1,+1}². Then h in (0,1/2), q in (1/4,1/2), and this source belongs to P_c. For N>=4,

    E_h TV(Q_N,p_h_actual) >= q [h-L0 W/(N+1)]_+.         (2)

Thus any advertised risk at most qh/2 requires, when L0>0,

    W >= h(N+1)/(2L0).                                  (3)

When L0=0, risk is at least qh at every N. Formula (2) is a bound on one fixed stationary strongly mixing source, so it implies the same minimax bound over P_c. It concerns acquisition of the actual penultimate symbol and would hold even if the source were known to the network.

## 3. Proof of the replacement estimate

Fix the SAME projected terminal state z and two histories differing at position i. Every nonterminal K/V pair other than i is unchanged, and the query and terminal self contribution are identical. Each attention score lies in [-B,B]. Write the attention output as A/b using sums divided by T. Both denominators b,b' are at least exp(-B), both outputs have norm at most V, and

    ||A-A'|| <= 2 exp(B)V/T,
    |b-b'| <= 2 exp(B)/T.

Consequently

    ||A/b-A'/b'||
      <= [||A-A'|| + ||A'/b'|| |b-b'|]/b
      <= 4 V exp(2B)/T = L0/T.

The denominator bound is for all eligible T entries, including self. For a full read-containing stage the corresponding local change is at most b_s L0/T. Compare two exact terminal trajectories by inserting the exact map for one history at the other trajectory's state; the common same-history Lipschitz certificate supplies a_s. Therefore

    e_s <= a_s e_(s-1) + 1_(read s)b_s L0/T,
    e_0=0,  e_D<=L0 W/T.

Both outputs are normalized binary probability vectors, and TV<=Euclidean norm. This proves (1). Public position dependence and adaptive queries do not change the same-input comparison. This argument would fail for evolving nonterminal memory: one raw edit could then change many K/V entries at the same read.

## 4. Reuse of the accepted source argument

The two parity subsequences of this stationary source are independent symmetric binary chains with flip probability q. The source is genuinely second order for h>0. Its two-step pair kernel satisfies P²(z,z')>=q², and stationary pi(z')=1/4, hence P²>=4q² pi. This is a fixed uniform geometric-mixing witness with every allowed transition in [c,1-c].

Condition on all observed symbols except X_(N-1). Its conditional law depends only on X_(N-3), because X_(N-1) is the final observed symbol in its parity subsequence. Both signs therefore have conditional probability at least q. The two completed histories differ at one raw position, and their oracle next-symbol distributions differ by TV exactly h. Triangle inequality and (1) show that the sum of the two prediction losses is at least h-L0W/T. Multiplying by the smaller conditional probability and using nonnegativity gives (2) conditionally, then unconditionally after averaging. N>=4 ensures the stated predecessor is present; no claim about a missing predecessor is needed.

The definition h=(1-2c)/2 implies q=(1+2c)/4>=c and 1-q<=1-c. The uniform pair law is stationary by summing over the first symbol. Thus the same stationary interior class used in the normalized frontier is retained, with constants depending on c.

## 5. Resource implications and limits

If every a_s<=1 and b_s<=b, then W<=bH. Any risk <=qh/2 requires H>=h(N+1)/(2bL0), for positive bL0. This holds even with a growing number of distinct banks. If read stages are contractive as in Section 4(c) of the stability candidate, W<=b/(1-rho), so the risk has liminf at least qh, without fixing J. More generally W=o(N) forces this constant-risk liminf.

Under coarse fixed gains a_s<=A, b_s<=b, H<=D and A>=2, W<=bD A^D. Equation (3) implies D log A+log D>=log(N+1)-O(1), hence D=Omega(log N). That logarithmic threshold is ALREADY established more generally in the older fixed-target result; it is only a compatibility check here.

The communication refinement remains useful for precision/resource accounting after terminal identity is available and amplification is large enough. It can yield a nontrivial lower where (2) is zero. But its fixed-J bounded-W inconsistency corollary should not be presented as a stronger new obstruction. This addendum supersedes that interpretation while preserving the original candidate and its independent audit unchanged.

The result does not supply the actual terminal context to the model, does not prove unknown-source estimation is hard once the context is given, does not improve the one-use matching risk exponent, and does not prove linear-depth necessity for arbitrary evolving full-row attention. The linear-H claim needs nonexpansive terminal dynamics AND token-local banks.

## 6. Exact provenance and next boundary

Read sources:
- ../terminal_context_obstruction_20261104_0822/BOUNDED_SCORE_TERMINAL_CONTEXT.md and INDEPENDENT_EXACT_FILE_AUDIT.md: accepted conditional penultimate replacement argument, stationary stochastic source and actual-terminal expected risk.
- ../logdepth_matching_private_20261104/MATCHING_ORDER.v2.md: existing fixed-target logarithmic-depth theorem and general repeated full-prefix sensitivity ledger.
- STABILITY_BUDGET.candidate.v1.md: current public off-trajectory propagation certificates.

Hahn's bounded-attention sensitivity method is already attributed by those sources. The endpoint conditional-risk conversion is also an INTERNAL antecedent, not a new invention here. This addendum is an explicit corollary and reconciliation. No external novelty search, scientific numerical execution, training or public mutation was performed.

The remaining main gap is not this startup threshold. It is a resource-controlled risk bound for repeated useful attention with genuinely evolving nonterminal K/V, at depth above the endpoint-acquisition threshold. Existing source-average and worst-history counterexamples must still be respected. A next claim should specify which extra structural property controls this evolution rather than obtain another generic sensitivity corollary.
