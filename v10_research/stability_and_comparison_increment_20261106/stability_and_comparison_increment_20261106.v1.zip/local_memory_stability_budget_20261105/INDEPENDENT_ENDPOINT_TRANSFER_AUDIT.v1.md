# Independent exact-file audit: endpoint transfer addendum v1

5 November 2026 UTC.

Reviewed candidate: `ENDPOINT_TRANSFER.candidate.v1.md`.

Exact SHA-256: `586deaefac73ba3df39014552b713e8f221f9be021299ceb277ab49cc0620448`.

**Verdict: PASS, conditional on the inherited token-local-bank structure and uniform off-trajectory stage/local-injection certificates. No mathematical correction is required.**

This is an internal analytical audit of the exact artifact. It is not formal verification, numerical validation, external peer review or novelty certification. The candidate and all antecedent records were preserved unchanged. The addendum is correctly classified as a T1/T2 resource corollary and reconciliation, not a new T3 research line.

## 1. Same-state attention replacement bound

Fix a projected dynamic terminal state z, public model parameters and two raw histories differing at one observed position i. Token locality ensures that only the ith nonterminal key/value pair changes in each complete bank. All other entries are identical. The terminal query and self K/V are identical because they are computed from the same z and public maps. This property holds for every read bank separately, so no common-bank or fixed-J assumption is needed.

All T=N+1 exact weights lie between exp(-B) and exp(B), with B=R_q R_k. Writing numerator and denominator as sums divided by T gives b,b'>=exp(-B). The sole altered entry obeys

    ||A-A'|| <= 2V exp(B)/T,
    |b-b'| <= 2 exp(B)/T.

These are loose valid bounds even if both the key and value change. The remaining output is a convex average, so ||A'/b'||<=V. Therefore

    ||A/b-A'/b'||
      <= (||A-A'||+||A'/b'|| |b-b'|)/b
      <= 4V exp(2B)/T.

This argument includes the attention-weight/denominator change, rather than bounding the value change alone. Self inclusion is essential for the displayed normalization by T, and it is part of the inherited contract. There is no approximation or Taylor truncation here.

The primitive read's bound passes through a complete read-containing stage with multiplier b_s because the two compared attention answers are substituted at the same dynamic state. This uses the inherited uniform local certificate, including same-stage continuation. It also uses the exclusion of any other history-dependent terminal input channel. A stage could not secretly reread raw symbols outside its attention answer and still satisfy this use of the inherited contract.

## 2. Full trajectory recurrence and endpoint sensitivity

For a nonread stage, the maps for the two raw histories are identical; only their terminal inputs differ. For a read stage, insert the exact stage map for one history evaluated at the other trajectory's input. The uniform same-history Lipschitz constant controls the state-change term, while Section 1 controls the different-history term at the same input. Hence

    e_s <= a_s e_(s-1) + 1_(read s) b_s L0/T,
    L0=4V exp(2B).

The synthetic terminal initialization is public, so e_0=0. Unrolling gives e_D<=L0 W/T with precisely the candidate's W. No additional H, J, degree, or dimensional factor enters. Final normalized binary outputs satisfy TV<=Euclidean distance, proving the one-edit TV bound.

Off-trajectory certification is needed here too: an exact state for one history need not be an exact reachable state for the other history. The candidate inherits certificates uniform on the same proof-side projected domain, so the inserted mixed-history evaluation is legitimate. Merely checking derivatives on each history's own trajectory would not suffice.

Adaptive queries do not change this calculation because they are compared at the same terminal state before state differences are charged through a_s. Evolving nonterminal memory would invalidate the one-entry change premise and is correctly excluded.

## 3. Interior stationary source and conditional law

For c in (0,1/2),

    h=(1-2c)/2=1/2-c in (0,1/2),
    q=(1-h)/2=(1+2c)/4 in (1/4,1/2).

The kernel p_h(y|a,b)=(1+h a y)/2 is a lag-two symmetric chain with flip probability q. Uniform initialization of (X_1,X_2) gives two independent stationary parity subsequences. Summing over the first predecessor sign establishes the uniform stationary pair law directly.

Both possible transition probabilities are q and 1-q. Since q-c=(1-2c)/4>0, all rows belong to [c,1-c]. Thus this is a single fixed member of P_c, independent of N, with genuine second-order dependence because h>0. Its two-step pair transition is a product of two factors at least q, hence every two-step entry is at least q^2=4q^2 pi(z'). This proves the claimed fixed geometric-mixing certificate.

For N>=4, conditioning on all observed symbols except X_(N-1) fixes its preceding parity symbol X_(N-3). There is no later observed symbol in that parity chain, and the opposite parity chain is independent. Equivalently, the innovation generating X_(N-1) is independent of the observed prefix and of the innovation generating X_N. The two conditional probabilities are exactly q and 1-q, in an order set by X_(N-3), not merely bounded below by q. The stated horizon restriction avoids the missing-predecessor endpoint.

The two possible target distributions p_h(.|X_(N-1),X_N) have binary TV separation exactly h. This h need not satisfy the small-amplitude testing restriction used in the separate communication theorem: no testing or entropy-contraction inequality is used in this addendum.

## 4. Conditional risk conversion and constants

Let ell_+,ell_- be the two nonnegative prediction losses under the completed histories. Triangle inequality and the one-edit output bound imply

    ell_+ + ell_- >= h-L0 W/T.

Both conditional history probabilities are at least q. Thus conditional expected loss is at least q times the sum of the losses, and nonnegativity yields

    E[loss | all other symbols] >= q[h-L0 W/T]_+.

Averaging proves the finite expected-TV inequality on the actual terminal pair. This is exactly the accepted antecedent's conditional argument, with its replacement modulus supplied by W.

If risk<=qh/2 and L0>0, then necessarily L0 W/T>=h/2. This holds whether the positive-part expression vanishes or is positive, so no branch is omitted. It gives W>=h(N+1)/(2L0). If L0=0, the finite bound is risk>=qh, with no division by zero. The same lower applies to the supremum over P_c because the chosen source lies in that class.

The proof does not use ignorance of h, q or the kernel. It remains valid for parameters chosen with knowledge of this source, provided they do not depend on the realized history and the same structural and norm certificates hold. The obstruction concerns acquiring the actual endpoint sign.

## 5. Resource consequences and provenance

Under a_s<=1 and b_s<=b, W<=bH. For bL0>0, the necessary W bound therefore gives

    H >= h(N+1)/(2bL0),

even when J grows with H. With contractive reads and nonexpansive intervening stages, W<=b/(1-rho), so the risk lower has liminf at least qh independently of J. More generally W=o(N) gives the same liminf because L0 is fixed by the frozen norm budgets. This is strictly stronger than the fixed-J, bounded-W communication corollary in the stated regime.

For fixed coarse gains A>=2 and b>0, W<=bD A^D. Success at risk<=qh/2 consequently requires

    D log A+log D >= log(N+1)-O(1),

for positive depth and fixed positive bL0. This entails D=Omega(log N). Zero-influence budgets cannot meet that risk target and do not create a missing logarithmic case.

The inspected antecedents already establish the conditional endpoint-risk mechanism and logarithmic-depth threshold. `BOUNDED_SCORE_TERMINAL_CONTEXT.md` uses the final observed row and a two-position recurrence; `MATCHING_ORDER.v2.md` explicitly handles the synthetic terminal with a three-position recurrence, including evolving causal rows. The current proof does not incorrectly transplant the earlier two-row influence formula. It derives a fresh restricted-class replacement modulus and reuses only the valid conditional loss conversion. Its novelty downgrade is therefore warranted.

The communication lower and this endpoint lower have different useful regimes. This endpoint bound becomes vacuous once its modulus reaches h; it does not subsume the communication resource bound there. Conversely, the fixed-J bounded-W inconsistency statement must not be presented as a stronger new endpoint obstruction. Any informal reference to terminal identity being available should mean internally acquired within the retained contract; externally granting an endpoint port would change the contract and require a separate theorem.

No result follows here about unknown-source estimation after an exact context is supplied, a new matching risk exponent, linear depth for arbitrary evolving rows, or general repeated-attention risk above the startup threshold.

## 6. Inspected evidence and actions

Read in full:

- `ENDPOINT_TRANSFER.candidate.v1.md`.
- `../terminal_context_obstruction_20261104_0822/BOUNDED_SCORE_TERMINAL_CONTEXT.md`.
- `../terminal_context_obstruction_20261104_0822/INDEPENDENT_EXACT_FILE_AUDIT.md`.
- `../logdepth_matching_private_20261104/MATCHING_ORDER.v2.md`.

The inherited `STABILITY_BUDGET.candidate.v1.md` and its local-memory dependencies were read and independently audited in the preceding exact-file review. That stability candidate has SHA-256 `291a3acc3313cd5f406284157723880463757b04ad76c9467e193382e0c2ae67`.

No historical numerical outputs, witness programs or parameter files were executed or treated as fresh evidence. Actions were local text inspection, paper derivation, checksum binding and writing this audit. No scientific execution, numerical experiment, model run, public write, upload, permission change, or edit to an existing candidate occurred. Literature priority was not independently searched or certified.
