# Research log: resource sensitivity and endpoint reconciliation

5 November 2026 UTC.

1. Read both authoritative Space plans, local adaptive v3, factorial v1 and exact audits, normalized frontier v2, source-average v2, anchored/weak composition and current nearest-paper comparison. Observed current public main f5ad033f03a2b8fdfc3a5a8576ab9e7b7b253dcb read-only. No public mutation.
2. Selected a narrow T1/T2 proof-resource refinement: replace the coarse H A^D error amplification by W=sum b_s product subsequent a_l. This is not a standalone T3 normalization/noise project. Off-trajectory certificates, complete dynamic state and raw-token restrictions are retained.
3. Preserved STABILITY_BUDGET.candidate.v1.md. Independent exact-version analytical review passed with no correction. The simulator precision cost depends on log(1+W); the varying-bank risk inversion must retain log(J+1).
4. An apparent opportunity to derive a new logarithmic-depth startup threshold was rejected after internal search found the accepted terminal-context obstruction and MATCHING_ORDER.v2. Those precedents already establish that threshold; do not count its rederivation as progress.
5. Prepared ENDPOINT_TRANSFER.candidate.v1.md to apply the older accepted one-edit conditional-risk lemma to W. This yields the stronger resource requirement W=Omega(N) for a fixed nontrivial terminal risk target. Nonexpansive terminal dynamics then require H=Omega(N), with no fixed-J assumption. This is explicitly an inherited-method corollary, not a new endpoint lower-bound principle.
6. Downgraded the original candidate's bounded-W/fixed-J inconsistency interpretation: the endpoint corollary is stronger and needs no fixed bank count. The polynomial communication bound remains potentially useful at large W after endpoint access is no longer the bottleneck.

Rejected shortcuts are retained in the candidates: dropping log(J+1); inferring contraction from LN labels; promoting one-way/local-bank results to evolving all-row self-attention; treating a repeated discovery of the old startup threshold as novel.

No scientific code or numerical experiment was run. Documentary scripts only assemble/inspect the HTML report and record hashes. No model execution, training, purchases, upload or repository writes occurred. Historical numerical executions are not claimed as evidence here.

The next substantive gap remains architecture-controlled source-average simulation for genuinely evolving nonterminal memory above the known startup threshold. Another generic stability corollary is unlikely to close it. Prioritize an explicit structural theorem or a source-average counterexample, retaining the existing quantifier and interaction boundaries.
