# Independent exact-file audit: stability-weighted adaptive reads v1

5 November 2026 UTC.

Reviewed file: `STABILITY_BUDGET.candidate.v1.md`.

Exact SHA-256: `291a3acc3313cd5f406284157723880463757b04ad76c9467e193382e0c2ae67`.

**Verdict: PASS, conditional on the stated token-local-bank and uniform off-trajectory certificates, and on the imported reviewed one-way source-average testing theorem. No mathematical correction is required.**

This is an independent analytical audit of the exact candidate, not formal verification, an empirical or numerical validation, external peer review, or novelty certification. The candidate was not edited. This is solely a T1/T2 resource-proof refinement within the existing restricted communication argument, not a separate T3 research line.

## 1. Error recurrence and the meaning of the certificates

Fix one raw history throughout the comparison. Let x_s and xhat_s be the exact and simulated extended terminal states. The comparison must be split through the exact map at the simulated input:

    ||Fhat_s(xhat_(s-1)) - F_s(x_(s-1))||
      <= ||Fhat_s(xhat_(s-1)) - F_s(xhat_(s-1))||
         + ||F_s(xhat_(s-1)) - F_s(x_(s-1))||.

The first term is at most b_s delta at a read and zero otherwise. The second is at most a_s e_(s-1). Iterating from the public initial terminal state gives exactly

    e_D <= delta sum_(s a read) b_s product_(l>s) a_l
         = delta W.

No Lipschitz bound on Fhat_s is needed. The certificates are for the exact extended maps and for the local answer substitution at the same state. Thus quantization discontinuities do not invalidate the recurrence. Zero gains are valid and require no division. Biases or public constants do not introduce an extra error term.

The off-trajectory condition is substantive, not optional: all compared states and substituted bounded answers must lie in the domains on which the two certificates hold. Euclidean projections provide one extension mechanism, but the candidate correctly does not infer contractivity from projection alone. If fixed public coordinates are removed from the metric, both extended computations must preserve the same hardwired affine slice. Varying scratch registers, past answers, or other sample-bearing coordinates cannot be suppressed. In particular, a derivative bound along only the exact history trajectory would not establish the stated theorem.

The inherited exclusion of other terminal data channels and public synthetic-terminal initialization are essential. Under that inherited contract, Bob can execute every nonread operation locally and there is no uncharged source-dependent initial state.

The choice delta=epsilon/(1+W) gives delta<=1 and final Euclidean error at most epsilon. The final simplex projection is nonexpansive and fixes the true probability vector; binary total variation is at most Euclidean distance. This closes the literal output-TV guarantee.

When W=0, substitute any fixed bounded answer at every read. Every resulting local discrepancy is finite, and each discrepancy's propagated coefficient b_s product_(l>s) a_l is zero. The same recurrence gives exact final output without any message. This reasoning uses the stipulated uniform local certificates and inherited absence of other raw-data channels; it is not a claim about arbitrary zero derivative computations.

## 2. One-way adaptive simulation and communication cost

For one complete bank, factorial-normalized monomial features give dimension

    (d+1) binom(m+k,k)

and Alice's averaged augmented moment has radius

    exp(R_k^2/2) sqrt(V^2+1),

independent of N and m. The Taylor plus net error is, uniformly for every bounded simulated query,

    e0 <= sqrt(V^2+1) exp(B) B^(m+1)/(m+1)!
          + exp(R_q^2/2) eta,
    B=R_q R_k.

The self contribution is evaluated exactly at the simulated state. The true averaged denominator is at least exp(-B). Choosing e0<=c delta, with a fixed c small enough, simultaneously preserves half this floor and makes the ratio error at most delta. Projection into the value ball cannot increase that error. All constants here depend only on the frozen attention norm bounds, not on a_s, b_s, W, H or D.

Since

    log(1/delta)=log(1/epsilon)+log(1+W)=t-2,
    t=U+log(1/epsilon)>=2,

one can choose eta at a fixed multiple of delta and the factorial tail target L=O(1+log(1/delta))=O(t). The reviewed factorial lemma supplies

    m+1=O(t/log(e+t)).

The monotonicity of x/log(e+x) justifies passage from L to t, including bounded t. The Euclidean ball net then costs O(t) bits per feature dimension. Thus one bank costs at most K(d+1)F_k(t), with ceilings absorbed because t>=2. There is no extra degree-dependent net radius or hidden log(m) loss. The B=0 endpoint has exact degree-zero expansion.

Alice can prepare every message before all queries because a complete bank consists of public token-local maps, including their position dependence, and does not depend on terminal answers. Bob adds his own-token contributions and recomputes terminal self K/V at each call. Repeated adaptive use of the same bank requires no new message: the approximation is deterministic and simultaneous over the query ball. There is no independence assumption, failure probability, union bound, or Bob-to-Alice transcript. Multiplying by J therefore proves the claimed sketch cost. Sending Alice's raw symbols instead gives the cap N.

For public fixed queries, one net index for an augmented weighted-sum vector per distinct complete (bank,query) pair proves the linear-in-t bound. Distinct public queries generally need distinct such vectors even with a shared bank. The candidate correctly distinguishes J_q from J. No finite-dictionary selection or off-trajectory rounding claim is needed for this fixed-public-query result.

All of this uses the inherited exact-real protocol semantics. It is not a finite-word neural implementation guarantee.

## 3. Risk inversion when J and W vary independently

Let

    v=2+log(1+W)+log(J+1),
    S=min{(J+1)F_k(v),N}.

For J>=1, v>=2 and v/log(e+v)>1, so S>=1 when N>=3. Consequently r=a/sqrt(S), with a<=1/256, ensures epsilon=r<=1 and 2r<=1/128. Further requiring a<= (1-2c)/16 suffices to place h=16r in the stationary interior testing class, in addition to h<=1/16. All these restrictions concern one fixed constant a.

Worst-history TV approximation implies the source-average guarantee under every tested source. The imported inequality therefore applies:

    4r^2 min(C+1,N) >= c0,
    c0=1/(16384 ln 2).

If S=N, its left side is at most 4a^2, without any communication estimate involving log N. This separate branch is correct and necessary for uniform finite-sample inversion.

If S=(J+1)F_k(v)<N, then

    log S <= log(J+1)+(k+1)log v <= C_k v.

Hence

    t=U+log(1/a)+(1/2)log S
      <= C'_k[1+log(1/a)]v.

Unlike the old D-based argument, t need not exceed v. The candidate handles both possibilities correctly. F_k is increasing, since both t and t/log(e+t) are increasing for t>0. Thus t<=v gives F_k(t)<=F_k(v); if t>v, the exact quotient gives

    F_k(t)/F_k(v)
      =(t/v)^(k+1)[log(e+v)/log(e+t)]^k
      <= (t/v)^(k+1).

It follows that C+1 is at most a fixed constant times

    [1+log(1/a)]^(k+1) S.

The fixed dimension d and the additive reserved bit are absorbed using S>=1. The testing left side is therefore at most a fixed constant times a^2[1+log(1/a)]^(k+1), which tends to zero as a decreases. One sufficiently small a contradicts the testing inequality in both branches, proving the displayed lower bound with no hidden dependence on J or W.

This is an advertised-envelope contradiction. No unknown actual risk was inserted into the simulator's accuracy or sketch description. Retaining log(J+1) is justified because no relation between J and W is assumed. The public-query variant is the same proof with J_q and F_0(t)=t. When W=0 the exact zero-message simulator gives a stronger positive constant lower bound directly.

## 4. Regimes and claimed consistency obstruction

For bounded gains a_s<=A, b_s<=b, A>=2, every read contribution is at most b A^D, hence W<=b H A^D. With H<=D and fixed A,b, U=O(D+1). Since J<=H<=D, v=O(D+1) too. Monotonicity and constant-factor scaling of F_k recover the earlier factorial resource bound and risk lower, up to fixed constants. This compatibility statement does not require W to attain its upper bound.

If every a_s<=1, then W<=bH. For fixed J and b, v is bounded above by a fixed multiple of 2+log(1+H). Therefore the general risk lower implies the stated weaker lower with F_k(2+log(1+H)). Away from the finite-N cap and as H grows, its reciprocal square root is proportional to

    (log log H)^(k/2) / (log H)^((k+1)/2).

For k=0 or a fixed number of public-query pairs this reduces to inverse square root of log H. These are necessary lower bounds, not assertions of attainable rates.

If each read has a_s<=rho<1, each nonread stage has a_s<=1, and b_s<=b, the contribution from the j-th read is at most b rho^(H-j). Thus

    W <= b sum_(j=1,...,H) rho^(H-j) <= b/(1-rho).

For fixed J,rho,b and fixed attention budgets, v and (J+1)F_k(v) are bounded uniformly in N,D,H. Since min{(J+1)F_k(v),N} is no larger than that fixed bound, the risk lower is uniformly positive. It follows correctly that more history or more such reads cannot produce uniform source-class consistency. The same conclusion holds for any uniformly bounded W and J, without requiring stagewise contraction. A growing J, unbounded injection gain, or growing key dimension is not covered by that fixed-budget conclusion.

Neither positive-epsilon LayerNorm nor bounded attention scores certify a_s<=1 for a full residual block. The candidate explicitly preserves this distinction and makes no automatic claim for standard PreLN or PostLN networks. The conclusion concerns the specified token-local-bank subclass only, not evolving all-row memory, an arbitrary streaming lower bound, optimization, or training.

## 5. Dependencies and evidence boundary

Read in full:

- `STABILITY_BUDGET.candidate.v1.md`.
- `../local_memory_factorial_refinement_20261105/FACTORIAL_REFINEMENT.candidate.v1.md` and its independent audit v1.
- `../local_memory_adaptive_reads_20261105/LOCAL_MEMORY_ADAPTIVE_READS.candidate.v3.md` and independent audits v2 and v3.
- `../source_average_simulation_20261105/SOURCE_AVERAGE_SIMULATION_BOUNDARY.candidate.v2.md` and its independent audit v2.

Also inspected the normalized stationary frontier v2, especially its complete architecture contract, global continuation bounds, interior witnesses and advertised-risk inversion. Its unrelated constructive upper is not a dependency of this verdict.

Freshly checked dependency SHA-256 values:

- Factorial refinement v1: `ba60fc18453626358c3c6d53124aaa23ec757c80d54f9d20cdb9ce8b38e27196`.
- Local-memory adaptive v3: `18a9be386641c2831e3f8cb7559c018a34451e7421772029fdf6005a5750c703`.
- Source-average simulation v2: `a16d5fbfa684efd32b75cfe3112acc501360cab67b82bbb01a78d56ec1d0cca4`.

The entropy-tensorization dependency inside the reviewed source-average theorem remains imported. No new primary-source verification of that external theorem, novelty search, authoritative-plan retrieval, or repository-status refresh is claimed by this audit. Those are not needed to verify the new conditional derivation.

Actions were local text reads, directory listing, SHA-256 binding, paper derivation and writing this audit. No scientific program, model run, simulation, numerical experiment, public write, upload, permission change, or candidate modification occurred.
