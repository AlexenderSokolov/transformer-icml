from pathlib import Path
import html
p=Path(__file__).resolve().parent
files=['STABILITY_BUDGET.candidate.v1.md','INDEPENDENT_STABILITY_BUDGET_AUDIT.v1.md','ENDPOINT_TRANSFER.candidate.v1.md','INDEPENDENT_ENDPOINT_TRANSFER_AUDIT.v1.md','RESEARCH_LOG.v1.md']
for f in files:
    assert (p/f).is_file(),f

def render(txt):
    out=[]
    for block in txt.split('\n\n'):
        if block.startswith('# '): out.append('<h2>'+html.escape(block[2:])+'</h2>')
        elif block.startswith('## '): out.append('<h3>'+html.escape(block[3:])+'</h3>')
        elif block.startswith('    '):out.append('<pre>'+html.escape(block)+'</pre>')
        else:out.append('<p>'+html.escape(block).replace('\n','<br>')+'</p>')
    return '\n'.join(out)
summary='''<h1>多次读取的资源账本与已有端点障碍</h1>
<p>v10 T1/T2 技术综合 · 2026 年 11 月 5 日</p>
<p><strong>主要结论：</strong>在非终端 K/V 仍逐 token 局部、终端 query 可以自适应的受限模型里，误差传播的实际权重 W 可以替代原通信证明中粗略的 H A<sup>D</sup>。但是，一个更早已成立的末位置读取障碍给出更强的必要条件：若要把预测风险降到固定小常数以下，必须有 W 与历史长度 N 同阶增长。非扩张的终端迭代因此至少需要线性于 N 的调用数，且不要求 bank 数固定。</p>
<p><strong>查重与降级：</strong>固定强混合二阶源上的端点障碍和对数深度启动门槛已存在于此前成果，本报告不将它们作为新发现。这里新增的只是把实际传播权重接到已有通信与端点论证的明确资源账本。一般 Lipschitz 递推、Taylor 摘要和条件风险论证均是承接的工具，创新性尚未认证。</p>
<pre>W = Σ（读取注入增益 × 后续阶段增益乘积）
通信代价：J · Fₖ(2 + log(1+W) + log(1/ε))，并截断于 N
Fₖ(t) = t [t/log(e+t)]ᵏ
端点风险：R ≥ q [h − 4 V exp(2B) W/(N+1)]₊
非扩张情形 W ≤ bH：固定小风险要求 H = Ω(N)</pre>
<p>两个候选分别经独立精确版本解析审查。独立 LLM 审查不是形式验证、外部同行评审或新颖性认证。原始待审标题保留，后附审查记录标明后续状态。</p>
<p>风险是同一历史末位置的期望 TV，再对未知平稳内部二阶源取上确界。端点下界甚至对一个固定源成立，主要限制是读到真实倒数第二项，不是学到未知规律。不能把这两种困难混为一谈。</p>
<p><strong>边界：</strong>不声称 LayerNorm 自动非扩张；不覆盖真正演化的全部历史 K/V；不证明训练可达性或有限浮点可靠性；不把该技术推论作为独立 T3 主线。没有新的公开写入、模型运行或投稿。</p>'''
body=summary+'\n'.join(render((p/f).read_text()) for f in files)
body+='''<h2>下一步</h2><p>主缺口仍是：超过已有端点启动门槛后，真正演化非终端记忆的多次 attention 是否具有由架构资源控制的源平均通信模拟，或存在严格反例。应优先解决这一结构/分布性义务，而不是再生产一般误差递推的推论。本报告不要求新增资源或投稿决定。</p><p>本文件仅做 HTML 源结构检查，未进行浏览器视觉验收。</p>'''
page='''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>v10：多次读取资源账本与端点障碍</title><style>body{max-width:960px;margin:40px auto;padding:0 24px;font:17px/1.65 system-ui,sans-serif;color:#18212b}h1{font-size:30px;line-height:1.3}h2{font-size:24px;margin-top:2em}h3{font-size:20px;margin-top:1.6em}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f8;padding:16px;font:15px/1.6 ui-monospace,monospace}p{overflow-wrap:anywhere}@media print{body{margin:0;font-size:11pt}h2,h3{break-after:avoid}}</style></head><body>'''+body+'</body></html>'
(p/'RESEARCH_REPORT.zh.html').write_text(page)
print('HTML assembled from exact candidate and audit files.')
