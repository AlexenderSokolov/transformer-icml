# Publication scope and preserved history

6 November 2026 UTC.

This release preserves the stability-budget and endpoint-transfer candidates, both exact-version analytical audits, the Chinese synthesis, research log, documentary generator and source checks. It also preserves primary comparison v1 and v2, the v1 audit, v2 addendum, and their hash bindings. Historical statements about no public upload describe the source documents' creation, not a subsequent release.

## Clarification of the Chinese summary

The historical Chinese report says W must grow “与历史长度 N 同阶增长.” The proved necessary condition is **W = Omega(N)** for the stated fixed nontrivial risk target and fixed norm budgets. No upper bound W = O(N), sufficiency, or matching Theta(N) statement follows. Read that summary as “W 至少按 N 线性增长.” The precise English theorem and its exact-version audit are unchanged.

## What the results establish

- Within the token-local nonterminal-bank contract and certified uniform off-trajectory terminal gains, the weighted propagation budget W sharpens the communication ledger. Its statistical-risk corollary retains log(J+1) and is conditional on the imported source-average testing result.
- The endpoint transfer reuses an earlier conditional-risk argument. Its necessary W = Omega(N), and H = Omega(N) under nonexpansive terminal dynamics with bounded read-injection gains, are restricted-model corollaries. Neither statement covers arbitrary evolving nonterminal memory.
- The primary comparison v2 corrects the Alman–Song locator and clarifies the Kozachinskiy SUM2/readout statement. Version 1 remains historical, with the error and corrective review visible.

## Dependencies and limitations

These increments are not a self-contained dependency closure. The adaptive-read v3 contract, factorial refinement, source-average testing package, normalized stationary framework, earlier terminal-context result, and matching-depth antecedent are separately referenced research materials. The entropy-tensorization theorem remains an imported external dependency. The local hash checks establish artifact identity, not proof correctness.

The reviews are analytical internal reviews, not formal verification, external peer review, empirical validation, exhaustive literature coverage, or novelty certification. No general repeated-self-attention frontier, training guarantee, finite-arithmetic guarantee, or new endpoint principle is claimed. HTML source reproducibility was checked; browser visual inspection was not performed.

## Release inspection

All 33 checked existing hash/archive bindings passed. The documentary HTML rebuild was byte-identical. The inspected text and ZIP members contained no identified credentials, sensitive personal information, absolute machine paths, or private-message links. Relative research-document references are retained for provenance. No source candidate, audit, or historical version was overwritten.
