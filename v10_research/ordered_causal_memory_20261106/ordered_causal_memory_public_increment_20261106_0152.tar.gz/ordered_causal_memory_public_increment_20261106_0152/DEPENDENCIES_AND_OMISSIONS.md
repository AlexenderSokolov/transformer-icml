# Dependencies and omissions

All 28 source-directory files are included, including every candidate revision, early failure review, final independent audit, HTML body/report, scripts, source bindings and QA. No available source file was omitted or modified. No missing version was invented.

Outside scope and not bundled: third-party paper full texts; external earlier research packages; unavailable screenshots, PDFs or numerical runs; any absent historical files. This package does not establish a complete earlier corpus or restore missing material.

Referenced proof dependencies remain open, including:
- Earlier suffix/count estimator, constant-width consistency and all-row count machinery (including terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md).
- Earlier lag-two source/terminal-context construction (terminal_context_obstruction_20261104_0822/BOUNDED_SCORE_TERMINAL_CONTEXT.md).
- Small-amplitude simulation, full-feature PreLN, padding/restoration and ordinary-softmax modules, including STANDARD_PRELN.candidate.v2.md and softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md.
- Existing one-way source-average testing, stability bounds and frozen primitive/resource contracts.
- Earlier current-frontier primary comparison and its other literature checks.

These are references, not a certified exhaustive transitive dependency graph. Their exact external bytes, proofs and complete review chains are not re-established here. The original PRIMARY_COMPARISON records what it inspected and inherited at its research date; packaging does not re-fetch or reverify those public papers. Embedded appendix hashes prove local text binding, not dependency closure.
