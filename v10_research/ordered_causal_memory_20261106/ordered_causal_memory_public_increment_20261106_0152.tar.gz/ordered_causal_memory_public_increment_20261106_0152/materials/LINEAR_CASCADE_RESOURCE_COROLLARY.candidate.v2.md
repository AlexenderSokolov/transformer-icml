# The existing square-root frontier extends to a public-linear cascade subclass

6 November 2026 UTC. Analytical candidate v2; v1 is preserved. Independent review requested after making the imported horizon restriction explicit. This is an elementary restriction/extension corollary of the prior one-way testing argument, not an unrestricted multiple-attention frontier or a new statistical rate.

## 1. Frozen subclass

Assume N>=3, the domain of the imported source-average testing theorem. Use N raw binary symbols, a synthetic public terminal, stationary interior unknown second-order class P_c, and the public-linear causal cascade of PUBLIC_LINEAR_CASCADE_COLLAPSE v2. All initial token-local vector norms and total retained terminal summary dimension v are fixed. Every data-dependent terminal input is included in those collapsed summaries. The remaining terminal decoder has at most D paid stages, each uniformly A-Lipschitz on the proof-side projected domain, for fixed A>=2. Count all actual attention and local network stages in the network's depth as well; using this larger D only weakens the lower. There are no uncharged terminal-context or source-kernel ports.

Public mixing matrices are source independent, nonnegative row-stochastic causal maps; their entire cascade has max-row gain at most one. The maps may encode public positions and lengths. Nonlinear data-dependent distributed row transforms between these mixing stages are outside this exact subclass.

## 2. Communication and risk lower

The final decoder gain is at most A^D, so the reviewed collapse simulator gives

    C<=min{N,K[D+1+log(1/epsilon)]}.

Let S=min{D+1,N}. Advertise a uniform predictor risk r=a/sqrt(S) and choose epsilon=r. If S=N, the imported testing product is at most 4a^2. Otherwise log(1/r)<=log(1/a)+(1/2)log(D+1), whence C+1<=K'(1+log(1/a))(D+1). Thus

    (2r)^2 min(C+1,N)<=K'' a^2(1+log(1/a)).

Choose a>0 sufficiently small, depending on c and fixed budgets, to contradict the accepted constant 1/(16384 ln 2), also ensuring 2r<=1/128 and 16r<=1-2c. Therefore

    R(Q)>=a_c/sqrt(min{D+1,N}).                          (1)

No number of public linear mixing steps changes the form of the summary cost; their paid depth is nevertheless included. This is the existing inverse-square-root resource order on a broader but still restricted attention-body class.

## 3. Approximate normalized realization

If a physical normalized network is uniformly zeta-close in output TV to a member Q of this class, the triangle inequality gives

    R(Q_phys)>=max{0,a_c/sqrt(min{D_ref+1,N})-zeta}.       (2)

Here D_ref is the ACTUAL charged depth controlling the reference decoder gain, not an unproved identification with the physical depth. If a separate compiler establishes D_phys=O(D_ref) and a reverse comparable upper D_ref=O(D_phys), the orders agree, but constants must be preserved. A small-amplitude reference comparison does not put physical nonlinear LN row maps into the exact public-linear class.

For the two-read ordered suffix route, the logical upper has D_ref=O(log N+b) and the already-existing risk O_c(b^(-1/2)). At b=Theta(log N), or more generally whenever b dominates the logarithmic preparation overhead, these orders match (1) up to fixed constants. A normalized extension with zeta=O(b^(-2)) preserves that order; its compiler proof must be independently accepted. This does not improve over the known one-read upper, and no claim about smaller head count, optimal coefficients or all nonlinear attention bodies follows.

## 4. Why this is relevant but limited

The homogeneous two-type surrogate loses ordered context and has a stronger constant obstruction. The present positional linear cascade can retain an ordered suffix and implement the actual unknown second-order estimator, so the lower concerns a statistically meaningful subclass. Its algebraic collapse avoids the distributed bank reconstruction barrier only because the body's dependence is public linear. Once intermediate nonlinear transformations or data-dependent attention weights are allowed, the collapse may fail and the general main problem remains open.
