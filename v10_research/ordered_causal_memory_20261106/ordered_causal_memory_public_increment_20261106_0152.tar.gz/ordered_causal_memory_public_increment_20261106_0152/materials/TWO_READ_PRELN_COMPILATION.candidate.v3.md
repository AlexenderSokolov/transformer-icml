# Positive-epsilon PreLN compilation of the ordered two-read program

6 November 2026 UTC. Analytical candidate v3; v1 and v2 are preserved. Independent review requested after fixing the order of full-state preparation and small-amplitude precision selection. This file attempts the exact-program obligation deliberately left open in TWO_READ_ORDERED_SUFFIX.candidate.v2.md. It claims no new estimator, rate, or compiler technique. All claims depend on the specified already-reviewed normalization/output compiler and the new logical program passing review.

## 1. Reference contract and desired conclusion

Fix c in (0,1/2), N>=6 and power-of-two 4<=b<=N-2. Start with the dyadic-coefficient version of TWO_READ_ORDERED_SUFFIX: two scalar zero-score full-prefix causal reads, constant width, O(log N+b) bounded affine/ReLU primitive stages, bounded complete states, and its exact final suffix probability q. All-row digit and count validity is guaranteed by its post-second-read synthetic gate. No physical equality of its decoded digits will be assumed below.

Proposed normalized conclusion: there is a source-independent constant-width raw-symbol causal PreLN network with EVERY LN having positive epsilon=1, gain=2, zero shift, ordinary affine vocabulary logits followed by ordinary vocabulary softmax, exactly two useful attention invocations, and

    D=O_c(log(N+1)+b),
    sup_{P in P_c} E TV(Q_phys,p_actual)
       <=13 sqrt(32/(b-1))+1/b+O_c(b^(-2)).               (1)

Every complete reachable state, full matrix, full bias and primitive Lipschitz bound lies in one finite c-dependent envelope independent of N,b. Width is constant for binary input. This is a PreLN claim, not a mandatory PostLN claim.

## 2. Extend the bounded logical program to bounded ordinary logits

Let a be the largest negative power of two not exceeding c, so a<=c and a<=1/4. Use the existing fixed-floor serial-log circuit from INTERIOR_SOFTMAX.candidate.v2.md and LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md to produce ell with

    ||ell-log(max(q,a))||_infinity <= zeta,
    zeta=min{1/1000,1/(100 b^2)}.

The max is componentwise. Its bounded logit range depends only on c. The serial piecewise-linear log approximation at error zeta costs O_c(zeta^(-1/2))=O_c(b) depth and constant width, with bounded per-primitive full norms. All probability/log computation is part of the reference program. Define Q_ref=softmax(ell) mathematically for comparison; the physical softmax will be the actual final head.

For binary p with p_1,p_2>=c>=a, clipping q to floor a and renormalizing moves its first probability toward p without overshooting p. Thus

    TV(softmax(log(max(q,a))),p)<=TV(q,p).

Binary softmax is Lipschitz in the two logits, so TV(Q_ref,p)<=TV(q,p)+zeta is a conservative bound. The core reference stage count before padding is m_core=O_c(log N+b). Before choosing any small-amplitude parameter, append ALL scaled-logit copies, norm-padding products/square-root microsteps and scratch clears described in Section 4. Denote the resulting FULL prepared reference length by m. Choose a common fixed widened tube radius Z and elementary max-row gain L>=2 for all three fully prepared programs (original and the two single-read ablations); the ablated references decode the all-default word and have legal counts. These tube/gain constants depend only on c and the frozen B=16, not N,b.

## 3. Paired small-amplitude implementation and both head errors

Use the already-reviewed paired-register construction, adding paired logical anchor 1 and raw-symbol/position shadows, and homogeneous representations of every affine bias through the preserved anchor. Represent logical z by physical h=eta z, eta=2^(-M). Paired coordinates imply mean zero. In an intermediate gain-one epsilon-one LN,

    LN(h)=eta s(z) z,  s(z)=(1+eta^2||z||^2/d)^(-1/2).

For each local homogeneous reference overwrite F, the bounded FFN implementing F-I gives exactly

    z_new=z+s(z)(F(z)-z).

On the fixed tube this differs from F(z) by at most C eta^2. All reference maps, including plateau classifiers, clipping, terminal gating and the restoring divider, are continuous bounded-gain affine/ReLU programs. The comparison proof does not assume perturbed physical digit/count states stay on the exact lattice: their total error is propagated through these actual continuous stages.

For EACH of the two zero-score attention reference steps

    z'_t=z_t+B_0 (1/t)sum_{i<=t} A_0 z_i,

the physical step gives

    z'_t=z_t+B_0 (1/t)sum_{i<=t} A_0 s(z_i) z_i.

Thus the max-row local error is <=||B_0||||A_0|| Z^3 eta^2/(2d), independently of N,t. The full-feature normalization factor depends on all coordinates and is not dropped; it is part of this error. Fresh destinations are included for the two reference reads. All local stages have dummy zero-attention sublayers and attention stages have zero FFNs, preserving the complete-block PreLN convention.

Here m includes the complete preparation just specified, NOT merely computation through the logit bank. With e_l the maximum-row logical-coordinate error,

    e_l<=L e_(l-1)+C eta^2,
    e_m<=C' eta^2 L^m.

Choose the smallest integer M>=1 for which this is <=xi and the fixed tube constraints hold. Later choose xi as a fixed constant multiple of zeta. Then M=O_c(m+log(1/zeta))=O_c(log N+b). Tube induction is valid uniformly for original and ablated references because their finitely many bounded tube constants were included. This is the explicit two-read recurrence, not an appeal to an unproved arbitrary attention compiler.

## 4. Final conventional output and uniform resources

Choose a fixed dyadic C_out large enough that v=ell/C_out has ||v||<=1 for the c-dependent bounded logit range. Append a copy of v into a paired bank, the reference norm-padding routine r≈sqrt(3d/2−1−||v||²) with accuracy kappa, and EVERY copy/clear microstep, leaving z_ref=(v,−v,1,−1,r,−r,0,...,0). The padding routine from STANDARD_PRELN v2 has O_c(1+log(1/kappa)) paid bounded primitives. Thus the FULL prepared reference length is m=m_core+O_c(1+log(1/kappa)). Only AFTER selecting kappa, fixing these complete reference programs and their tube constants, choose M by Section 3 to make the FULL prepared-vector error at most xi. In particular xi is NOT merely an error at the incoming logit bank. There are no later useful reads, so approximate clears enter the full-vector norm/error bound rather than an exact memory-support assumption.

Now apply the bounded-gain radial restoration, final LN and affine vocabulary head W=C_out times the output-bank projection from INTERIOR_SOFTMAX v2 Section 5. Its prerequisite is the actual full prepared vector z_tilde within xi of z_ref, which the preceding choice of M now supplies. The same complete padding/reference schedule and the same final physical routine are used for all three ablated/original networks.

With constants recalculated for this fixed enlarged width and tube, the sufficient final logit-error bound is

    C_out[2xi+7(C_pad kappa+C_norm xi)+2tau_restore] <= zeta.

Choose xi,kappa,tau_restore as the largest dyadic values not exceeding zeta/[100 C_out(1+C_pad+C_norm)] and the imported fixed-domain constraints. Select these tolerances BEFORE forming the full prepared reference program and choosing M. This removes any ambiguity about arbitrarily excessive precision. The preparation and restoration together have depth O_c(M+log(1/zeta)+b), which is O_c(log N+b). Its full state, matrix, bias and layernorm-gain bounds are fixed because the bounded logit range depends only on c; inverse eta amplification is implemented in paid bounded steps, never as one unbounded matrix.

Finally apply the exact gain reparameterization already audited in the weak composition: make each interior LN gain two and halve every consuming FFN first matrix and attention value matrix. Q/K are zero. Physical trajectories are unchanged; the final LN already uses the same epsilon-one/gain-two/zero-shift convention. No pair or suffix is supplied as an external feature.

The physical terminal logits differ from ell by at most zeta, hence TV(Q_phys,Q_ref)<=zeta. Combining with Section 2 and the inherited exact suffix risk proves (1), with a conservative total additive 2zeta. The public linear-collapse surrogate is Q_ref, not the physical intermediate row bank. Physical PreLN breaks exact linear row mixing, but this end-to-end uniform approximation gives

    sup_x TV(Q_phys(x),Q_ref(x))<=zeta.                    (2)

Here the log approximation was already included in Q_ref; no statistical averaging is needed for (2).

## 5. Terminal simulation, usefulness and precision ledger

The reference decoder receives only z_T from the second read after its exact terminal gate; other data registers are not read by that decoder. By public linear collapse its initial signal is one public weighted token-local sum. Its paid decoder has Lipschitz constant at most A^m for fixed A depending only on c. Therefore it has a source-independent one-way worst-history simulator using

    C=O_c(log N+b+log(1/epsilon))

bits, capped by N, at reference-output error epsilon. The SAME protocol approximates Q_phys to epsilon+zeta by (2). This is a direct terminal-specific simulator for a normalized network with genuinely updated nonterminal second-read values; it is not a row-reconstruction claim, nor an exact common-control factorization of physical K/V.

Both useful reads remain nontrivial after compilation. In the logical program, either single-read ablation produces the all-default estimator, while an all-symbol-2 suffix gives its opposite. Before flooring, their binary probabilities differ by 1-2/b>=1/2. Flooring at a<=1/4 does not reduce this separation below 1/2 (the worst endpoint is b=4). Log and physical errors totaling at most 2zeta per output preserve positive constant separation. The uniform reference/physical comparison was chosen for all three programs. This does not claim two heads are necessary: the old one-head estimator already solves the same task with the same order.

Per-coefficient binary description remains O_c(log N+b): it includes original geometric position coefficients, O(b) dyadic harmonic-ratio accuracy, small amplitude eta with M=O_c(log N+b), dyadic output tolerances and restoration approximations. No large exact harmonic rational is embedded. At constant width and D=O_c(log N+b), the untied TOTAL parameter description is O_c((log N+b)^2), not merely the per-coefficient precision. The claim is a sufficiently large fixed c-dependent full-norm envelope, not an unchecked identification with any preassigned numerical M_K. The layer arithmetic itself, LN square roots and attention averages remain exact-real semantics. A finite-precision execution would additionally need per-operation error control through O(D) stages and is not certified here.

All useful-head count, D, width, complete full norms, growing coefficient precision, O(N) distributed state and dense O(N^2+ND) work are visible. No training or numerical model execution was performed. This reproduces an existing rate via an additional structural route and adds no independent statistical estimation theorem.

## 6. Required proof dependencies and limits

Dependencies requiring exact review: new TWO_READ_ORDERED_SUFFIX v2 and PUBLIC_LINEAR_CASCADE_COLLAPSE v2; prior CONSTANT_WIDTH_CONSISTENCY v3 and its count/readout audits; INTERIOR_SOFTMAX v2 final output routine; LOW_RISK_WEAK_ANCHOR_COMPOSITION v4's small-amplitude, multi-uniform-head and gain-reparameterization arguments. The current file supplies the two-head recurrence and reference validity needed to reuse those routines; it does not claim novel normalization machinery.

Still absent are a better rate, an arbitrary nonlinear full-row simulation, a sharp lower for all multiple-attention networks, trained realization, mandatory PostLN compilation or executed finite-arithmetic reproduction. The linear-collapse identity is exact for the logical reference, while the physical normalized network uses (2); merging those two claims would be incorrect.
