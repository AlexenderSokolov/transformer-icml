# Independent exact-file audit: reversal-context obstruction

6 November 2026 UTC. Verdict: PASS within the stated symmetry and source-class scope.

Reviewed source: `REVERSAL_CONTEXT_OBSTRUCTION.candidate.v1.md`.
SHA-256: `4493b28b3b6b7ccf97a5e6a3f4485f4d362b2cc17a2e58e2eb3955b099bec3f6`.

## Mathematical checks

- The uniform initial pair is stationary for the displayed lag-two kernel. The two parity subsequences are independent stationary symmetric binary chains with one-step correlation theta. For theta>0 this is genuinely order two, and theta<=1-2c keeps every transition probability in [c,1-c].
- Reversal preserves the finite path product. The actual terminal target uses X_(N-1), while the reversed target uses X_2. The target probability gap is theta when these signs differ.
- Reversal invariance of the predictor makes its two expected losses equal. The triangle inequality therefore gives exactly (theta/2) Pr(X_(N-1)!=X_2), not theta times that probability.
- Opposite parity gives mismatch probability 1/2 for even N. For odd N>=5, mismatch probability is [1-theta^((N-3)/2)]/2. The uniform bound theta(1-theta)/4 is valid for every N>=4; the exceptional N=3 case is correctly excluded.
- Choosing theta=(1-2c)/2 yields a positive fixed witness constant. The proof remains valid for reversal-invariant conditional output kernels by integrating the scalar loss over that kernel; no pathwise invariance of an arbitrary seed representation is needed.
- Both the residual lower b_c-Delta and the quantitative asymmetry correction minus asym_N/2 follow directly from triangle inequalities and reversal of the source law.

## Scope

This is a depth-free obstruction for reversal-invariant predictors, including the homogeneous count-only surrogate. It does not apply to arbitrary position-dependent static bases, a paid terminal-context route, or every evolving-memory network. The witness and target mechanism are explicitly inherited; no fresh priority claim is supported or needed.

The audit used source reading and analytic derivation only. No scientific experiment, model execution, source-file edit, or upload was performed.
