# Ordered causal memory: primary-source contract comparison

6 November 2026 UTC. Targeted comparison, not a novelty certificate or an independent verification of all external or local proofs. Local target revisions are frozen below. Public primary passages were freshly retrieved read-only. No unpublished research text was sent to a search service, no model or scientific numerical test was run, and no upload or public repository mutation was performed.

## 1. Finding

Ordered empirical Markov prediction, source-independent same-history counting, constant representation width at fixed alphabet/order, and two useful attention invocations already have close primary antecedents. The new local package should not be framed as discovering any of those mechanisms or improving their minimum layer count.

The public-linear collapse is elementary composition of known linear maps followed by quantization of a bounded terminal statistic. The harmonic suffix program is a concrete re-encoding of an existing local estimator through that collapse, with useful bounded-gain and coefficient-description bookkeeping. Its positive-epsilon PreLN extension applies the existing local compiler to this exact program. None supplies a new statistical estimator or better rate. The reversal result is an elementary symmetry-risk obstruction for a restricted surrogate class, using an already existing local lag-two witness.

The complete frozen-resource conjunction remains an obligation not established by substituting the checked external constructions: all effective scores, complete states/matrices/biases and primitive gains must be bounded uniformly as N and accuracy change; positive epsilon must be fixed; all decoding and ordinary-softmax output work must be paid. This is a comparison boundary, not evidence of priority.

## 2. Freeze the four local targets

**L: PUBLIC_LINEAR_CASCADE_COLLAPSE.candidate.v2.md.** After token-local preparation, the cross-row evolution being collapsed consists of public, source-independent linear causal maps. There are no intervening data-dependent gates, score patterns, normalization factors or nonlinear maps. For nonnegative stochastic maps, the final row is a convex weighted sum of bounded token-local vectors. All retained terminal data channels must be counted. The one-way summary bound is capped by N and otherwise scales with summary dimension and log of downstream Lipschitz amplification, value radius and target inverse accuracy. This is not full-bank reconstruction, an implementation runtime bound, or a theorem for arbitrary evolving memories.

**O: TWO_READ_ORDERED_SUFFIX.candidate.v3.md.** Binary raw rows plus a synthetic terminal, fixed B=16, selected suffix length b, no supplied pairs/counts/cropped input. Two complete zero-score uniform causal reads transport a geometric suffix code. The second values are genuinely prefix-dependent. Harmonic-ratio decoding recovers the same suffix digits and count estimator as the earlier one-read construction. Width is constant; paid primitive depth is O(log N+b); the statistical bound is inherited. Dyadic coefficient accuracy is charged, while arithmetic remains exact-real. The new fixed norm envelope is sufficient and finite, not automatically the old numerical M_K.

**P: TWO_READ_PRELN_COMPILATION.candidate.v4.md.** A conditional exact-program compilation with fixed epsilon=1, gain=2, full-feature PreLN, and ordinary affine vocabulary logits/softmax. It prepares the entire reference state before choosing small amplitude, propagates errors through continuous digit/count/division circuitry, and includes both head perturbations and final restoration. The claimed risk adds O_c(b^-2) to the inherited suffix bound. Exact public-linear collapse applies to the logical reference, NOT the normalized physical memory; the latter is compared to the former by a uniform output error. It has two useful attention invocations but O_c(log N+b) paid depth, not two total primitive layers.

**S: REVERSAL_CONTEXT_OBSTRUCTION.candidate.v1.md.** For the fixed stationary lag-two source, exact reversal-invariant output laws have risk bounded below by theta(1-theta)/4. An approximate reversal-invariant surrogate cannot uniformly approximate a consistent predictor. This imposes symmetry, not a bound on depth, width or precision. Position-dependent bases or a paid terminal-context channel can break it.

The earlier `CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md` concerned a one-use normalized frontier plus restricted repeated-read extensions. It does not automatically establish L/O/P/S. Conversely, the new two-use construction does not strengthen that one-use frontier.

## 3. Fresh primary-paper checks

The following are summaries of the precise inspected locations, not claims about every theorem or possible corollary in each paper.

### Rajaraman et al., Transformers on Markov Data: Constant Depth Suffices

Primary: [arXiv:2407.17686v1](https://arxiv.org/html/2407.17686v1). Fresh checks: Section 2.2; Theorem 5.1/Remark 5.2; Section 5.1; Appendix C.1 and C.3, particularly equations (56), (59)-(60), (71)-(73).

Theorem 5.1 represents conditional k-grams using three layers, one head each, relative positions, layer normalization and O(S) embedding dimension. The construction stores ordered context codes, then matches contexts. Appendix C.1 uses paired signs and explicitly replaces LN by v/||v||. Query/key matrices and matching scores carry a sharpening parameter. Remark 5.2 discusses parameter precision but says its proof does not bound the finite-precision approximation error. The representation theorem is distinct from the reported training experiments.

**Implication for this comparison:** normalized ordered Markov circuits and sign pairing are antecedents. The checked statement is not a certificate for fixed-positive-epsilon, uniformly bounded effective scores/full norms, a fully paid ordinary-softmax decoder, or P's same-history expected-TV envelope. The local O program also pays growing decoding depth rather than providing a competing three-layer construction. Setting k=2 does not resolve those resource obligations; taking k=b would change the statistical target.

### Ekbote et al., What One Cannot, Two Can

Primary: [arXiv:2508.07208v2 PDF](https://arxiv.org/pdf/2508.07208v2). Fresh checks: Section 4, Theorem 3/Remark 2 and construction, printed pp. 7-8; Section 5, pp. 8-9; Appendix A.1, p. 16; Appendix C, Assumption 1 and reduced model, p. 33.

Theorem 3 has two attention layers, one head each, embedding dimension 6S+3, relative positions and LN. Its MLP reconstructs complementary ordered-context features between reads; context matching uses a sharpening limit. Appendix A.1 adopts v/||v|| normalization throughout. Remark 2 records length-dependent parameter count and a precision/error claim. Section 5 explicitly separates representation from optimization: its reduced first-order model assumes a correct MLP and trains positional scalars plus a second-layer attention scalar under stated kernel-prior assumptions.

**Implication:** two-read conditional k-gram representation is already established. O/P is neither a two-layer improvement nor a training theorem. The inspected construction does not directly certify P's frozen positive-epsilon/full-norm contract. An epsilon appearing in a training loss is not a LayerNorm epsilon. Its parameter-precision claim must not be substituted for a proof of O/P's rounded execution.

### D'Angelo et al., Induction Heads Interpolate N-Grams

Primary: [arXiv:2607.02800v1](https://arxiv.org/html/2607.02800v1). Fresh checks: Section 2.1, Proposition 3.1/equation (8), Sections 3.2.1 and 3.2.3, Appendix E introduction and Theorem E.1 setup.

Proposition 3.1 is pathwise for arbitrary strings: two layers, k copying heads followed by one context-matching head, with weighted partial-context counts and optional pseudo-counts. At order two this is three total head invocations. Its disentangled model uses concatenation and relative-position scores. Copying is justified by a hardening limit, while the final linear readout selects probability coordinates. Appendix E treats label-permutation symmetry of gradient flow, not general convergence to the estimator.

**Implication:** same-history ordered prediction and source-independent smoothed/interpolated counts overlap. Finite matching parameters do not make the copying scores uniformly bounded. This is not P's fixed-epsilon full-state/output contract. Nor does the paper's label symmetry imply reversal symmetry: relabeling symbols and reversing time are different transformations, and context-sensitive predictors can be label-equivariant while retaining order.

### Hahn, Theoretical Limitations of Self-Attention in Neural Sequence Models

Primary: [TACL 2020 PDF](https://aclanthology.org/2020.tacl-1.11.pdf). Fresh checks: Section 6, Lemma 5, Theorem 6 and the displayed proof setup, printed pp. 165-166.

Lemma 5 gives O(1/n) change of terminal activation after changing an earlier symbol, with parameter-dependent constants; Theorem 6 turns sensitivity limits into next-symbol cross-entropy limitations for formal-language examples. This is established sensitivity-to-loss reasoning for fixed model resources.

**Implication:** S is not that lemma with n renamed N. It imposes exact reversal symmetry and uses a stationary stochastic context witness, so its bound is independent of network depth. The argument is elementary orbit pairing plus the triangle inequality, not a new general attention lower-bound method. Hahn's separate proof-correction supplement was not freshly checked here; no proof step in this report relies on it.

## 4. What the new algebra actually adds

These are direct comparisons of the local formulas, not external-paper claims.

### 4.1 Public-linear collapse

Writing e_T^T P_H...P_1 f = sum_i w_i f_i is associativity/distributivity. Stochasticity bounds the summary radius without reconstructing every prefix. Quantizing after exact composition avoids paying H separate errors. However, decoder amplification still appears through log G, and G can grow exponentially in paid depth. Thus the absence of a literal H multiplier does not eliminate all depth dependence or prove a depth-free prediction theorem.

The condition applies to the two-read logical transport stage after its token-local preparation. It does not assert that all preceding rowwise computation is linear. A physical full-feature LN inserts data-dependent value factors and is outside the exact identity; P must use its separately proved approximation error. This restriction is central, not cosmetic.

### 4.2 Harmonic re-encoding

For the public prefix-average matrix, direct interchange of sums gives

    (P^2 f)_T = (1/T) sum_j [sum_(i=j)^T 1/i] f_j.

No new statistical information is created: O applies this known linear operation to the prior geometric code and compensates the known coefficients in its terminal digit recurrence. The synthetic self term is part of the harmonic coefficient. The bounded successive ratio and dyadic approximation margin are useful proof obligations, but the risk theorem, count accumulator and divider are inherited.

Algebraically the terminal signal is one public weighted token-local statistic. This does NOT by itself provide a cost-free one-head neural replacement: public weight generation, representation precision and decoder gains would still require a ledger. The separate earlier one-read suffix construction already establishes that two reads are unnecessary for the statistical task. Ablation distinguishes the two paths inside this particular program only.

Consequently, this route is best described as an elementary composition/example with complete accounting. It is not an independent estimation method, an attention-count separation, or evidence that general nonlinear evolving memories are compressible.

### 4.3 Positive-epsilon compilation

P's specific contribution to its own proof is checking that the inherited compiler covers both full-prefix averages, the exact terminal gate, all continuous decoder stages, the entire prepared vector and both ablations. The recurrence e_(l+1)<=L e_l+C eta^2 is ordinary stability bookkeeping. Paying restoration instead of inserting an unbounded 1/eta matrix is essential to the claimed resource class. These points can make a valid local theorem application without constituting a new compiler technique.

Its strongest defensible interpretation is a concrete normalized closure example using the cited compiler and new-program arguments. It is not a compiler from arbitrary attention networks, and this literature comparison does not independently discharge its proof dependencies or certify their reviews.

### 4.4 Reversal obstruction

The lag-two source and terminal-context mechanism already occur in `terminal_context_obstruction_20261104_0822/BOUNDED_SCORE_TERMINAL_CONTEXT.md`. S pairs a path with its reversal under an invariant source law and then applies the scalar triangle inequality. Its useful refinement is to state a depth-free exact-symmetry bound and a quantitative lower bound on surrogate discrepancy. It does not show that arbitrary fixed-rank positional summaries are reversal-invariant. The two-read weighted code is visibly positional, so there is no conflict with S.

## 5. Required cost-preserving reduction before claiming subsumption

Neither similarity of names nor one different assumption proves equivalence or separation. Any proposed reduction from a primary construction must account for:

1. Raw full-prefix input and the synthetic terminal, with no free suffix/pair port or hidden preprocessing.
2. Total useful head invocations, plus every paid local stage. Two attention layers and O(log N+b) primitive depth are different claims.
3. Effective attention scores including positional terms. Bounded content Q/K alone is insufficient when positional scores sharpen.
4. Complete vector, matrix and bias norms, not merely coordinate bounds or fixed representation width. Position tables and their descriptions must not become free inputs.
5. Fixed positive-epsilon full-feature normalization and its value-scale effects. Homogeneous direction normalization cannot be replaced silently.
6. Ordinary affine vocabulary-softmax output, all decoding/restoration work, and the decoder's end-to-end sensitivity.
7. One source-independent same-history predictor evaluated at the realized terminal pair. Representation error, empirical-estimator identity, expected-TV risk and prior-averaged training loss are distinct statements.
8. Parameter-description precision versus arithmetic precision, O(N) distributed state, and dense work. O(N^2+ND) assumes zero attention slots are skipped; dense evaluation of every full block costs O(N^2D) in the local ledger.

No faithful, resource-preserving reduction satisfying this full list was established in this pass. That absence is not a novelty claim. The high derivability risk of L/O/P/S is clear from their explicit elementary or inherited components even without such a reduction.

## 6. Provenance and limits

Fresh local reads: the four target revisions named above; `current_frontier_prior_art_20261105/CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md`; the earlier `terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`; `terminal_context_obstruction_20261104_0822/BOUNDED_SCORE_TERMINAL_CONTEXT.md`; and Sections 1-3 of `softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md`.

The earlier one-read rate, all-row estimator details and lag-two witness were therefore cross-checked locally, rather than inferred solely from the new candidates. Full statistical proofs, compiler dependencies and independent-review conclusions remain inherited; this pass did not reprove them. A separate 6 November review-status update reports acceptance of the final mathematical package; that acceptance is inherited status, not a finding of this literature pass. The accompanying resource corollary v2 was not one of this pass's four directly inspected targets. Other papers in the previous primary comparison, including streaming-attention and general communication results, were not freshly reopened and are not asserted as newly checked evidence here.

Primary access used public URLs and exact section/theorem locators. Some HTML cross-references and PDF equations extract imperfectly; no broken reference was treated as a theorem identifier. The versioned sources above are the actual inspected versions, not a claim that they are the latest available. No exhaustive literature/citation-graph search or proof certification was attempted.

Target snapshot SHA-256 values at inspection:

- L v2: 96a9193e64ce377e9dc6ed0da30f500701fd6b4e47dc9340ef8a1f0e7ca0d138
- O v3: 8447990d0957bab96b473a256cf108b2a13a9d2d397c65da13549d40a4d56c75
- P v4: a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2
- S v1: 4493b28b3b6b7ccf97a5e6a3f4485f4d362b2cc17a2e58e2eb3955b099bec3f6

Recommended scientific description: a restricted public-linear closure example preserving an existing ordered suffix estimator, its conditional bounded-resource PreLN compilation, and a complementary symmetry obstruction. Do not call it a new Markov estimator, a two-layer frontier, a learning guarantee, or a solution for arbitrary evolving causal memory.
