# Ordered causal memory and genuine second-order prediction

6 November 2026 UTC. Analytical package; no model training, scientific numerical experiment, finite-arithmetic reproduction, upload or submission occurred.

## Accepted mathematical versions

1. REVERSAL_CONTEXT_OBSTRUCTION.candidate.v1.md, audited by INDEPENDENT_REVERSAL_CONTEXT_AUDIT.v1.md. A fixed stationary genuinely second-order source gives a constant risk floor for reversal-invariant predictors, and a nonvanishing discrepancy requirement for any consistent predictor approximated by that class.
2. PUBLIC_LINEAR_CASCADE_COLLAPSE.candidate.v2.md, audited by INDEPENDENT_PUBLIC_LINEAR_COLLAPSE_AUDIT.v1.md. Public nonnegative linear causal mixing collapses exactly to a bounded token-local weighted terminal vector; communication depends on retained dimension and downstream gain, not reconstruction of all row states.
3. TWO_READ_ORDERED_SUFFIX.candidate.v3.md, audited by INDEPENDENT_TWO_READ_SUFFIX_AUDIT.v1.md. A concrete two-uniform-head program transports all existing suffix-estimator information through prefix-dependent values. Bounded variable-radix decoding, explicit coefficient precision and a terminal gate preserve true ordered context and all-row count validity. It returns the existing estimator with no improved rate.
4. TWO_READ_PRELN_COMPILATION.candidate.v4.md, audited by INDEPENDENT_TWO_READ_PRELN_AUDIT.v1.md. The full prepared-vector correction makes the two-head small-amplitude construction compatible with the existing norm-padding/restoration/ordinary-softmax module. It supplies the claimed positive-epsilon PreLN network in a sufficiently large fixed c-dependent envelope, exact-real semantics, with O(b^-2) terminal error against its linear reference. Physical memory is not asserted to be exactly linear.
5. LINEAR_CASCADE_RESOURCE_COROLLARY.candidate.v2.md, audited by INDEPENDENT_LINEAR_RESOURCE_COROLLARY_AUDIT.v1.md. Existing one-way testing yields the inverse-square-root depth-risk order on the fixed public-linear subclass, N>=3. Approximate physical transfer subtracts its certified output error and retains reference/physical depth distinctions.

All PASS statements are independent analytical text audits, not machine-verified proofs, external peer review, novelty certifications or empirical validation. Older candidates remain preserved; their creation-time pending status is superseded only by the matching exact-version review, not by edits to old records.

## Prior art and report

PRIMARY_COMPARISON.v1.md records fresh read-only primary passage checks for recent Markov/ngram papers and Hahn, separating directly inspected text from inherited local statements. The broad ordered/two-read estimator mechanism is prior art; public-linear composition and the reused suffix statistical rate are not claimed novel. Expression/representation does not establish optimization.

The Chinese RESEARCH_REPORT embeds exact final proofs, audits and the primary comparison with source hashes. Use a report version with a matching final text/privacy PASS. HTML parsing is not rendering or scientific execution; visual acceptance has not been established.

## Main gap

Arbitrary nonlinear full-row causal attention is outside the exact public-linear body. The current route does not improve the known one-read statistical rate, prove fewer necessary heads/layers, supply a trained model, or certify finite floating-point behavior. Full norm envelopes, growing coefficient precision, O(N) distributed state and both useful-only and all-dummy-dense work accounts are explicit. FAILED_ROUTES_AND_SCOPE.v1.md preserves the substantive full-prepared-vector compiler repair and other rejected shortcuts.
