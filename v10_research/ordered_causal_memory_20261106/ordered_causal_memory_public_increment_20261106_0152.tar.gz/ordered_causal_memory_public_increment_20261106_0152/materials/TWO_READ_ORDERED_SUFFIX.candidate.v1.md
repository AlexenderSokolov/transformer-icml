# A two-read causal prefix-memory route to the existing second-order suffix estimator

6 November 2026 UTC. Analytical candidate v1; independent review pending. The statistical estimator and its rate are existing v10 results. The local increment is an explicitly collapsed ordered two-read signal path, not a new estimation rate, minimum layer count, or training method.

## 1. Target and relation to prior constructions

Fix binary input, N>=6, T=N+1, and a power-of-two b with 4<=b<=N-2. All N raw rows and one synthetic zero-symbol terminal are supplied; there is no suffix crop, pair/triple port or supplied counts. Parameters depend on public N,b, not the unknown second-order kernel. Use B=16 and digit d_i in {1,2}.

The established CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md supplies bounded-width source position gates, geometric suffix weights, plateau digit decoding, exact sequential triple counts and paid restoring-division output. Its source-independent risk bound with G=b is

    sup_{P,mu} E TV(Q,p_actual)<=13 sqrt(32/(b-1))+1/b.       (1)

Here the supremum includes homogeneous binary second-order sources and arbitrary initial-pair laws. The present program returns EXACTLY the same suffix count estimator, but transports its information through TWO full-prefix uniform reads, with genuinely prefix-dependent values at the second read. It is not the previously constructed weak extra interaction added to an already completed predictor.

## 2. Two causal reads and their exact collapsed signal

Let s=N-b+1. Reuse the prior paid token-local geometric-weight program to write

    v_i=d_i B^(-(i-s+1)) for s<=i<=N, and v_i=0 otherwise.

It costs O(log N+b+log^2 b)=O(log N+b) depth and constant width with bounded primitive matrices/full biases/states, including the synthetic exclusion. Preserve exact raw onehot shadows and a synthetic-row marker.

Read 1, with zero Q/K and a fresh value destination, writes

    r_t=(1/t)sum_{j<=t}v_j.

Read 2, again zero Q/K into a different fresh destination, reads r_i and writes

    z_t=(1/t)sum_{i<=t}r_i.

At T this is exactly

    z_T=(1/T)sum_{j=s}^N a_j d_j B^(-(j-s+1)),
    a_j=sum_{i=j}^T 1/i.                                  (2)

The second read's nonterminal values depend on entire raw prefixes. Nonetheless (2) is a public position-weighted token-local sum; the linear-cascade collapse theorem applies with Delta=0 at the logical level. No first-layer row bank is reconstructed in the protocol.

Both attention steps are paid complete useful invocations. The values remain in [0,2/(B-1)] and their full-prefix scores are identically zero. The synthetic self r_T IS included in the second sum, as required by the mask; omitting it would give the wrong harmonic coefficients.

## 3. Terminal gate and bounded variable-radix decoding

After the second read, gate z_t to zero at every nonterminal row using the exact synthetic marker e_t=1-sum_c x_t(c). Since z_t<1, ReLU(z_t+e_t-1) equals z_T at T and zero otherwise. Raw shadows are retained until this gate. No input-dependent multiplication is required.

Scale the terminal signal by R=T B/a_s. Because a_s>=1/T and a_s<=T, 1<=R<=B T^2. Implement this with O(log N) doublings, one final coefficient in [1,2), and clipping to [0,3] after each step. At T the desired initial decoder state is

    h_1=d_s+sum_{l=1}^{b-1} d_{s+l}(a_{s+l}/a_s) B^(-l),

which lies in [1,2+2/(B-1)]<3, so no exact clipping occurs at T; all other rows stay zero.

At round j (position i=s+j-1), classify h_j with the existing plateau functions C_d(h), d=0,1,2. The exact h_j is digit d_i plus a tail in [0,2/(B-1)]. Set D_j=sum_d d C_d(h_j). For j<b update

    h_{j+1}=clip(R_j(h_j-D_j),0,3),
    R_j=B a_i/a_{i+1}.

Since i>=s>=3 and i<=N-1, a_{i+1} includes 1/(i+1)+1/(i+2), and

    1<=a_i/a_{i+1}
      =1+(1/i)/a_{i+1} <=2.

Thus B<=R_j<=2B: all per-primitive gains are fixed constants independent of N,b. The variable radix compensates the public harmonic coefficient exactly. Every terminal digit is its original suffix digit; other rows keep h=0 and use the prior convention that zero digits become default symbol 1 for counting while subtracting digit zero from h.

## 4. Finite coefficient descriptions without hidden harmonic precision

Exact harmonic rationals can have large denominator descriptions, so exact embedding of every R_j is NOT used for the finite-description claim. Choose dyadic approximations to R_j and to the final [1,2) factor of R, all within

    delta <= 1/[100 b (2B+1)^b].                          (3)

The dyadic doublings are exact network coefficients. The initial normalized code error is at most 3 delta. While the decoded digits agree, the next code error is at most (2B+1)e_j+3delta. Induction makes every error at most 1/100. The exact digit-plus-tail intervals lie strictly inside the original plateau [d-1/8,d+1/2], so all classifiers are still EXACT onehots. This closes the digit-agreement induction. Clip is nonexpansive relative to exact h_j in [0,3]. Nonterminal rows remain exactly zero before digit conversion.

Therefore O(b+log b) fractional bits for these bounded factors suffice; together with the earlier position/weight program, per-coefficient binary description is O(log N+b). This is robustness to the specified PARAMETER rounding in exact-real arithmetic, not an IEEE or edgewise-rounded execution guarantee. The harmful alternative of assuming exact harmonic coefficients for free is preserved as a rejected route.

## 5. True second-order statistics and all-row validity

Reuse the accepted sequential triple-count accumulator and paid restoring division, with G=b and Q=2^ceil(log2(b+2)). At T it obtains all suffix triple counts and the actual last pair; at every other row it processes the all-default b-word. Thus the readout's exact lattice precondition holds at every physical row, not just T. It outputs exactly the same normalized binary suffix estimator as the prior one-read construction. Every triple-count and probability operation is inside the paid stack.

This is genuinely second-order prediction: both unknown transition frequencies and the actual ordered terminal pair are recovered. It is not a predictor of the marginal symbol frequency. Equation (1) is inherited unchanged. For b=Theta(log N), risk O(1/sqrt(log N)) and depth O(log N) are exactly the EXISTING rate/depth orders, not improvements.

In the logical program, ablating either read output sets the only decoder input to zero, yielding the all-default suffix estimator. On an all-digit-2 suffix the nonablated output and all-default output differ by a fixed positive amount for b>=4. Thus both reads affect the implemented output by a nonvanishing amount on some histories. This is indispensability of these paths in this particular program, not necessity of two reads for the statistical task: the known one-read program is already better in invocation count.

## 6. Complete ledger and normalized-network scope

Logical exact-real affine/ReLU/attention program:
- useful full-prefix attention invocations: exactly 2, scalar values, zero Q/K;
- width: O(1) for binary input, including raw shadows, marker, two fresh attention destinations, digit/lag/count/readout registers;
- paid depth: O(log N+b+log^2 b+log(b+2)log b)=O(log N+b);
- complete state, matrix and full bias norms: fixed finite envelope, enlarged by fixed factors for clipping at 3, the marker gate and radix at most 2B+1;
- per-coefficient parameter/position description: O(log N+b) bits via (3), no exact harmonic table supplied to the network;
- physical rows: T=N+1, so constant per-row width is still O(N) distributed state;
- dense attention work: two full causal scalar heads cost O(N^2); local stack work O(ND). Sparse or specialized prefix-sum execution is not silently substituted;
- terminal readout: paid positive normalized probability coordinates, not yet an ordinary vocabulary softmax.

A complete positive-epsilon PreLN/ordinary-softmax version is a CONDITIONAL COMPILATION EXTENSION, not claimed proved by this file. The existing weak-anchor composition v4 explicitly derives a small-amplitude max-row error recurrence for three uniform heads and a final conventional output compiler. Its recurrence plausibly applies to this bounded two-head logical program, but the enlarged tube constants, terminal gate, restoring-division sensitivity and final logit tolerances must be rechecked on this exact program before claiming the normalized result. In particular physical PreLN inserts data-dependent value factors; the physical program would NOT have exact linear-collapse identity (2). It would inherit an approximate terminal collapse only after a uniform end-to-end error bound zeta is established.

No training algorithm, parameter-generation execution, numeric model test, quantized-arithmetic implementation or speedup is proved. This construction closes a specific architectural existence check in the logical exact-real contract; it does not close the entire current normalized v10 main model.

## 7. Comparison and remaining obligations

Prior one-read suffix packing already achieved (1), constant width and O(log N+b) depth. This construction spends an extra useful attention invocation to show that substantial ordered information can travel through genuinely updated nonterminal prefix values while a terminal-specific public-linear collapse remains available. It is a closure example, not a new estimator or improved frontier.

The existing nonlinear repeated-attention terminal obstruction is outside the public-linear condition; the homogeneous count surrogate is too symmetric for this task; and the prior weak-anchor composition only adds a vanishing perturbation after its predictor. All three distinctions concern structure, not literature priority. Recent n-gram representation papers in the prior primary comparison already establish genuine multi-layer Markov estimators; no minimum-layer novelty is claimed here.
