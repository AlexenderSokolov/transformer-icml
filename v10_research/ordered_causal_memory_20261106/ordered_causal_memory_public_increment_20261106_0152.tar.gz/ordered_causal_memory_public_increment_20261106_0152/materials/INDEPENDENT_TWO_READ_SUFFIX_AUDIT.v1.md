# Independent exact-file audit: ordered two-read suffix route

6 November 2026 UTC. Verdict: PASS in the stated logical exact-real affine/ReLU/attention contract.

Reviewed source: `TWO_READ_ORDERED_SUFFIX.candidate.v3.md`.
SHA-256: `8447990d0957bab96b473a256cf108b2a13a9d2d397c65da13549d40a4d56c75`.

Principal dependency checked: `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`, including its continuous plateau decoder, all-row lattice requirement, count accumulator, paid restoring division and existing suffix-risk statement.

## Mathematical checks

- The two uniform full-prefix reads produce the exact harmonic coefficients a_j=sum_(i=j)^T 1/i. The synthetic self r_T is included. The second bank genuinely depends on available suffix prefixes, although values outside the selected suffix contribute zero.
- The post-read synthetic-marker gate gives exactly zero decoder input at every nonterminal row. This is essential: without it, terminal harmonic coefficients would not generally decode valid words on earlier rows.
- The initial gain R=TB/a_s is at most BT^2 and is implemented with paid bounded doublings. All exact intermediate gains stay below the final terminal code, which is less than 3, so clipping does not distort that code.
- Since s>=3 and i<=N-1, the displayed two-term lower bound on a_(i+1) proves a_i/a_(i+1)<=2. The update gain lies in [B,2B] and exactly compensates the changing harmonic weight.
- Rounding the bounded factors at the stated dyadic accuracy gives initial error at most 3delta and recurrence e_(j+1)<=(2B+1)e_j+3delta while digits agree. The stated delta makes every error smaller than 1/100. This lies safely within the plateau margins, closing the digit-agreement induction without a discontinuous primitive.
- Nonterminal rows stay at code zero and decode the default word. Terminal rows recover exactly the original suffix. Consequently every row satisfies the imported exact count-lattice precondition, and the final estimator is exactly the old suffix estimator.
- Ablating either read sets the only decoder signal to zero. For an all-digit-2 suffix, original and ablated probabilities differ in TV by 1-2/b>=1/2. This proves usefulness of both paths in this program, not necessity of two reads for the task.

## Resources and resolved concerns

Depth O(log N+b), constant width, fixed finite full-state/full-matrix/full-bias envelopes, O(log N+b) per-coefficient descriptions and O((log N+b)^2) total untied descriptions are consistent with the serial implementation. This establishes existence of a sufficiently large fixed envelope, not containment in the old numerical M_K. Work distinguishes useful-head/local O(N^2+ND) from evaluating all dummy attention slots densely at O(N^2D).

The source file correctly leaves positive-epsilon PreLN and vocabulary softmax to a separately audited compilation. It does not establish a finite-arithmetic execution guarantee, a training method, a new estimation rate or an advantage over the existing one-read upper.

The audit used source reading and analytic derivation only. No scientific experiment, model execution, source-file edit, or upload was performed.
