# Independent exact-file audit: public linear causal collapse

6 November 2026 UTC. Verdict: PASS for the stated public-linear subclass.

Reviewed source: `PUBLIC_LINEAR_CASCADE_COLLAPSE.candidate.v2.md`.
SHA-256: `96a9193e64ce377e9dc6ed0da30f500701fd6b4e47dc9340ef8a1f0e7ca0d138`.

## Mathematical checks

- Associativity gives the exact terminal weights e_T^T P_H...P_1. Nonnegative row-stochastic matrices preserve nonnegativity and total weight one, independently of the number of mixing stages.
- Alice's partial weighted sum has radius at most the fixed initial value budget V. A Euclidean ball net at accuracy eta has bit cost O(v log(1+V/eta)); Bob adds his own terms and the public synthetic term exactly.
- With all data-carrying terminal summaries included in z, projection to the declared domain followed by a G-Lipschitz decoder gives output error at most epsilon for eta=epsilon/max(1,G). The displayed fixed-V communication bound and N-bit binary fallback follow.
- For two inclusive prefix averages, the coefficient of f_j is T^(-1) sum_(i=j)^T i^(-1). The upper limit T correctly includes the synthetic row's first-read value at the second read.
- This terminal statistic need not reconstruct the distributed prefix bank. It is therefore compatible with a separate large communication cost for reconstructing every row.

## Resolved review points and limits

Version 2 explicitly fixes three initially ambiguous points: binary inputs for the N-bit fallback, fixed V and its role in the hidden constant, and inclusion of every retained data channel in the summary dimension. Signed feature transforms require their own norm accounting; the row-stochastic estimate is not asserted for them without that accounting.

There is no intervening data-dependent normalization, nonlinear gate, key or query in the exact collapse condition. The result is elementary public linear algebra, not a general nonlinear-attention simulator or an assertion that all prefix states share a common controller.

The audit used source reading and analytic derivation only. No scientific experiment, model execution, source-file edit, or upload was performed.
