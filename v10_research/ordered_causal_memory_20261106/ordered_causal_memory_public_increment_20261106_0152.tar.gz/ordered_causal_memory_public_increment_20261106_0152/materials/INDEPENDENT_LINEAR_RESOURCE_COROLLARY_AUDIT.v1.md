# Independent exact-file audit: public-linear resource corollary

6 November 2026 UTC. Verdict: PASS for the declared frozen public-linear subclass and N>=3.

Reviewed source: `LINEAR_CASCADE_RESOURCE_COROLLARY.candidate.v2.md`.
SHA-256: `407e6d077afb95f849e6b919a378f54fca0e5f6c67a0a07bf511364757f988a5`.

Dependencies checked: public linear collapse v2; the accepted one-way testing formulation in `../local_memory_adaptive_reads_20261105/LOCAL_MEMORY_ADAPTIVE_READS.candidate.v3.md` and its anchored extension/audit; and the inversion structure in `../local_memory_stability_budget_20261105/STABILITY_BUDGET.candidate.v1.md`.

## Mathematical checks

- Fixed summary dimension and norm, with decoder gain at most A^D, reduce the communication bound to min{N,K[D+1+log(1/epsilon)]}. Every retained terminal data channel must be included; that condition is explicit.
- For advertised r=a/sqrt(S), S=min{D+1,N}, and epsilon=r, the S=N branch gives testing product at most 4a^2. When S=D+1<N, the logarithm is absorbed into K'(1+log(1/a))(D+1), giving the displayed vanishing-in-a bound.
- A sufficiently small fixed a meets both numerical/source-domain prerequisites: 2r<=1/128 and 16r<=1-2c. The contradiction with 1/(16384 ln 2) therefore proves the stated inverse-square-root lower. No unknown actual risk is inserted into a resource hypothesis.
- Version 2 now explicitly states N>=3, the horizon domain required by the imported testing theorem.
- Uniform TV approximation of a physical network to the reference gives the lower minus zeta by the triangle inequality. The proof correctly uses D_ref and does not silently identify it with D_phys.
- The suffix upper uses b sequential decoding rounds and total charged depth O(log N+b). When b dominates the logarithmic overhead, its old O(b^(-1/2)) rate matches this subclass lower up to fixed constants; zeta=O(b^(-2)) does not change that order.

## Scope

The conclusion concerns public row-stochastic linear cascades followed by a fixed-width bounded-gain terminal decoder, or explicitly close normalized realizations. It is not a lower for arbitrary data-dependent nonlinear full-row attention. Counting all mixing stages in D weakens but does not invalidate the lower. The statistical rate and one-read attaining construction already existed; this is a subclass extension/corollary rather than new estimation machinery.

The audit used source reading and analytic derivation only. No scientific experiment, model execution, source-file edit, or upload was performed.
