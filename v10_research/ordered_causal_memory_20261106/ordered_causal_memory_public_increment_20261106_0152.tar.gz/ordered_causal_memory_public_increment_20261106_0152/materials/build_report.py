from pathlib import Path
import html,hashlib,json
D=Path(__file__).parent
items=[('反转上下文障碍','REVERSAL_CONTEXT_OBSTRUCTION.candidate.v1.md'),('公开线性折叠','PUBLIC_LINEAR_CASCADE_COLLAPSE.candidate.v2.md'),('双读有序后缀','TWO_READ_ORDERED_SUFFIX.candidate.v3.md'),('规范化编译','TWO_READ_PRELN_COMPILATION.candidate.v4.md'),('受限资源下界','LINEAR_CASCADE_RESOURCE_COROLLARY.candidate.v2.md'),('反转独审','INDEPENDENT_REVERSAL_CONTEXT_AUDIT.v1.md'),('线性折叠独审','INDEPENDENT_PUBLIC_LINEAR_COLLAPSE_AUDIT.v1.md'),('后缀独审','INDEPENDENT_TWO_READ_SUFFIX_AUDIT.v1.md'),('规范化独审','INDEPENDENT_TWO_READ_PRELN_AUDIT.v1.md'),('资源下界独审','INDEPENDENT_LINEAR_RESOURCE_COROLLARY_AUDIT.v1.md'),('主文文献核查','PRIMARY_COMPARISON.v1.md')]
body=(D/'REPORT_BODY.zh.v1.html').read_text()
body+='<section id="appendix"><h2>九 完整证明与审阅原文</h2><p>以下保留精确原文及哈希，供离线核对。独立审阅不是形式化机器证明或外部同行评议。</p>'
bind={}
for title,name in items:
 data=(D/name).read_bytes(); h=hashlib.sha256(data).hexdigest();bind[name]=h
 body+=f'<details><summary>{html.escape(title)} · {html.escape(name)}</summary><p class="hash">SHA-256 {h}</p><pre>{html.escape(data.decode())}</pre></details>'
body+='</section><footer><p>中文报告 v1 · 2026 年 11 月 6 日 UTC。全部条件与未完成事项以精确版本原文为准。</p></footer>'
style='''body{font-family:system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;color:#171717;max-width:980px;margin:auto;padding:40px 24px;line-height:1.8}h1{font-size:2rem;line-height:1.4}h2{font-size:1.5rem;margin-top:2.6rem}p,li{font-size:1rem}nav{margin:24px 0}a{color:#145a88}.eq{font-family:Cambria,Georgia,serif;padding:12px 0;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%}td,th{border:1px solid #d9d9d9;padding:12px;text-align:left;vertical-align:top}th{background:#e8edf1}tr:nth-child(even){background:#f8f9fa}details{margin:22px 0}summary{cursor:pointer;font-weight:600;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.65 ui-monospace,monospace}.hash{overflow-wrap:anywhere;font-size:.85rem}footer{color:#555;margin-top:40px}@media(max-width:600px){body{padding:20px 16px}h1{font-size:1.6rem}td,th{padding:8px}}@media print{body{max-width:none;padding:0}nav{display:none}h2{break-after:avoid}tr{break-inside:avoid}a{color:inherit}}'''
html_doc='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>真实二阶预测中的有序因果记忆与终端模拟</title><style>'+style+'</style></head><body>'+body+'</body></html>'
(D/'RESEARCH_REPORT.zh.v1.html').write_text(html_doc)
(D/'REPORT_SOURCE_BINDINGS.v1.json').write_text(json.dumps(bind,indent=2,ensure_ascii=False)+'\n')
print(len(html_doc.encode()),hashlib.sha256(html_doc.encode()).hexdigest())
