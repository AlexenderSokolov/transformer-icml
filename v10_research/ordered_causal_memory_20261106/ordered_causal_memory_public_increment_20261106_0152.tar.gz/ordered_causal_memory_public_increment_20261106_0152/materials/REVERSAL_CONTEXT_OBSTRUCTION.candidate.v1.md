# Reversal-invariant closure cannot approximate a consistent second-order predictor

6 November 2026 UTC. Analytical candidate v1; independent review pending. This sharpens the scope diagnosis of the homogeneous two-type surrogate, not a general Transformer impossibility.

## 1. Source and precise symmetry

Use signed binary symbols and a fixed theta in (0,1-2c], with c in (0,1/2). Initialize (X_1,X_2) uniformly and let

    P_theta(X_t=x | X_{t-2}=a,X_{t-1}=b)=(1+theta a x)/2.

This is stationary, genuinely second-order, inside P_c and uniformly mixing. Its path probability is

    P_theta(x_1:N)=1/4 product_{t=3}^N (1+theta x_{t-2}x_t)/2.

Reversing x preserves the product, hence the history law. The actual next-symbol probability of +1 is p(x)=(1+theta x_{N-1})/2. Reversal changes that target to (1+theta x_2)/2.

Let Q_N(x) be a normalized binary predictor whose +1 probability g(x) is invariant under reversal. It may know theta, have arbitrary depth/width/precision, and use any order-sensitive statistics that happen to preserve reversal. Source-independent random coins are allowed if the predictor's conditional output law is reversal invariant; deterministic invariance is sufficient.

## 2. Exact lower bound

For deterministic g, reversal invariance of both g and the history law gives equal expectations of |g(X)-p(X)| and |g(X)-p(reverse X)|. The scalar triangle inequality therefore yields

    E TV(Q_N,p_actual)
       >= (theta/2) P_theta(X_{N-1} != X_2).               (1)

The two parity subsequences are independent stationary symmetric first-order chains with step correlation theta. Thus for N>=4:

    lower = theta/4                               if N is even,
    lower = theta(1-theta^((N-3)/2))/4             if N is odd.

In particular every N>=4 satisfies risk>=theta(1-theta)/4. For odd N>=5 the exponent is at least one; even N is stronger. Choosing theta=(1-2c)/2 supplies a fixed positive constant b_c=theta(1-theta)/4. Randomized conditional-output-law invariance gives the same statement by applying reversal to the joint law with an independent random seed, or by averaging the scalar loss over that output kernel.

This is terminal CONTEXT loss, not uncertainty about theta: even oracle knowledge of this fixed source does not remove the obstruction. It uses no communication theorem or approximation precision assumption.

## 3. Consequence for source-average closure

Suppose an actual predictor A_N and a reversal-invariant surrogate Q_N satisfy sup_{P in P_c} E TV(A_N,Q_N)<=Delta_N. Then, on this fixed witness,

    R(A_N)>=b_c-Delta_N.

More sharply, if R(A_N)<=r_N, then its source-average discrepancy from EVERY such surrogate must obey

    sup_{P in P_c} E TV(A_N,Q_N)>=b_c-r_N.               (2)

Hence a uniformly consistent genuine second-order predictor cannot have Delta_N->0 to the homogeneous two-type surrogate, regardless of the favorable Gamma^2 S_0=o(N) condition previously studied. That condition defines an impossibility subclass, not a route to consistency.

The same reasoning gives a quantitative symmetry test for arbitrary A. Write asym_N=E_theta TV(A(X),A(reverse X)). Two triangle inequalities and reversal of the source give

    R_theta(A)>= (theta/2)P_theta(X_{N-1}!=X_2)-asym_N/2.

Thus a low-risk model must preserve a definite order-sensitive output signal on this source. This is a necessary test, not a sufficient architectural construction.

## 4. Relation to existing work and escape routes

The homogeneous two-type common-control surrogate depends only on symbol counts, so it is reversal invariant. The fixed-rank general theorem does NOT require this: position-dependent token-local bases can retain ordered suffix information. A supplied exact terminal pair also breaks the symmetry and must be paid for under the raw-input contract.

The local BOUNDED_SCORE_TERMINAL_CONTEXT.md (4 November) already uses this lag-two source to show a fixed-depth bounded-score terminal-access obstruction via penultimate-token sensitivity. This note reuses that known witness and target mechanism; its distinct scope is a depth-free exact symmetry bound and a quantitative residual obstruction for the new closure. It is not a new source, a new generic information method, or a priority claim.

Closest checked sources remain Hahn's bounded-depth sensitivity work and the Markov-representation papers recorded in CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md. Their ordered copying/counting mechanisms explain why real second-order constructions cannot be represented by a mere homogeneous histogram closure. This note makes no fresh primary-literature novelty certification.

Failure preserved: the earlier informal statement 'count-only cannot recover the last pair' was not by itself a quantitative risk theorem. Equation (1) supplies that missing argument. Conversely, extending (1) to arbitrary positional bases or a paid terminal-context port would be false and is not asserted.
