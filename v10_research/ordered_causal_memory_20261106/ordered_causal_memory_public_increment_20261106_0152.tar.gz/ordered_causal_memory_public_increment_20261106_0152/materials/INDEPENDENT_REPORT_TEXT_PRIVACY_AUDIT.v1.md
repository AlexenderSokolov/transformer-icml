# Independent report claim, privacy and static-safety audit

6 November 2026 UTC. Verdict: PASS for mathematical claim fidelity, declared scope, appendix integrity, privacy review and static HTML safety. Visual rendering remains unverified and is not certified by this audit.

Exact report: `RESEARCH_REPORT.zh.v1.html`.
SHA-256: `456f6be8e031c9aa708f0860afad6aadaf14d05276ae7d1779fd294982dd2ed2`.

The audit directly read the Chinese body, the five final mathematical sources and their independent audits, the included `PRIMARY_COMPARISON.v1.md`, the source-binding manifest, and the report assembly/checking code. It also independently parsed the final HTML and compared every decoded appendix with its source bytes. These are document-integrity checks, not scientific numerical experiments or model execution.

## 1. Mathematical claims and scope

- The report preserves the real prediction target: an unknown homogeneous order-two source, the realized terminal context on the same observed history, and source-average expected TV risk. It supplies no free suffix, terminal pair, triples or counts.
- Horizon restrictions are correct: the imported testing lower uses N>=3; the symmetry constant uses N>=4 with the odd formula restricted to N>=5; the concrete construction uses N>=6 and power-of-two 4<=b<=N-2.
- The reversal lower has the correct theta/2 mismatch factor, parity formulas and positive fixed interior-source constant. It is restricted to reversal-invariant outputs and their approximants, not arbitrary positional summaries or all causal transformers.
- Public linear collapse is correctly limited to public source-independent row mixing without intervening data-dependent nonlinear or normalization operations. All retained terminal data channels and decoder amplification are charged. The report does not replace this terminal-only simulation with full-bank reconstruction.
- The two-read program includes the synthetic self term, paid terminal gate, bounded variable radix, dyadic coefficient error, and all-row default-word construction. It recovers exactly the old suffix estimator. Its two paths are useful in this program, but two heads are not claimed necessary.
- The ordinary-softmax PreLN account matches the accepted exact-program proof. It includes the complete scaled-logit/padding/copy/clear reference before selecting small amplitude, controls the prepared FULL vector, uses a fixed c-dependent envelope, and propagates errors through continuous circuits without asserting physical lattice exactness.
- All LN conventions are consistently epsilon=1, gain=2, shift=0 after reparameterization. The final output is conventional affine vocabulary logits followed by vocabulary softmax.
- Exact collapse belongs to the reference attention signal path. The physical normalized network is only uniformly zeta-close in output. The communication ledger correctly states physical simulation error epsilon+zeta, not an exact physical K/V factorization.
- The statistical upper, 13 sqrt(32/(b-1))+1/b+2zeta, is inherited plus compilation error. The inverse-square-root lower is limited to the frozen public-linear subclass, and its approximate transfer uses D_ref rather than an unjustified substitution of D_phys.
- Both work conventions are visible: O(N^2+ND) when identically zero attention slots are skipped, and O(N^2D) when every dummy slot is evaluated densely. Per-coefficient and total parameter descriptions are separately charged, as is O(N) distributed state.
- The report repeatedly and correctly disclaims a new estimator, improved rate, minimum-head result, training guarantee, finite-arithmetic execution guarantee, unrestricted nonlinear-memory frontier, or novelty certification.

The Chinese primary-literature summary agrees with the included targeted comparison: earlier three-layer and two-layer Markov representation results are acknowledged and representation is separated from optimization. This report audit did not independently retrieve those external papers again or certify their proofs. The scope of fresh versus inherited literature checking remains explicit in the comparison appendix.

## 2. Exact appendix bindings

The HTML has nine main sections and eleven appendices: five final proof files, five mathematical audits, and one primary-source comparison. For EVERY appendix, HTML-decoded preformatted text equals the corresponding source file byte-for-byte after UTF-8 encoding. Every source's current SHA-256 equals the displayed binding manifest value.

The five mathematical versions are exactly reversal v1, linear collapse v2, ordered suffix v3, PreLN compilation v4, and resource corollary v2. The failed or incomplete earlier compilation versions are not substituted as accepted proofs. The main body explains that candidate-header review status is frozen history and that the included final independent audit supplies the later acceptance status.

## 3. Privacy and static safety

Manual text review found no credentials, access tokens, account identifiers, private personal information, private correspondence, or copied assistant instructions. Public author names, paper URLs, mathematical source filenames and reproducibility hashes are relevant research content. There are no absolute local filesystem paths, private file-service URLs, or local-account paths in the HTML.

Independent parsing found no scripts, forms, iframes, objects, embeds, event-handler attributes, externally embedded assets, CSS URL/import/expression constructs, or unsafe link schemes. Links are fragment navigation or ordinary HTTPS primary-paper links. Appendix content is escaped text rather than executable HTML. No duplicate IDs, broken fragment links, mismatched nesting or unclosed tags were found.

This is a static-content assessment, not a guarantee about external sites reached after a reader voluntarily follows a paper link.

## 4. Remaining delivery limit

No browser rendering, screenshot inspection, PDF pagination or visual layout acceptance was attempted or established. The report explicitly states that limit. No attempt was made to restart a previously blocked rendering route. No upload or public repository action occurred during this audit.
