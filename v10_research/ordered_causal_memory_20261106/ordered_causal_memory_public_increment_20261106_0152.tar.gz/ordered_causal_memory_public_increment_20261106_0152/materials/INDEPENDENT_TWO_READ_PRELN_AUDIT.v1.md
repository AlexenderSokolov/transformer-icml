# Independent exact-file audit: two-read positive-epsilon PreLN compilation

6 November 2026 UTC. Verdict: PASS for the stated sufficiently large fixed c-dependent envelope and exact-real semantics.

Reviewed source: `TWO_READ_PRELN_COMPILATION.candidate.v4.md`.
SHA-256: `a7bde2d8f93b043f1fa8764add8098b4f3d8030963e106cf2e95de069b1e2cb2`.

Dependencies directly checked: the ordered suffix v3 and linear collapse v2 in this directory; `../standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md`; Section 5 and the serial-log circuit of `../softmax_interior_20261105_0031/INTERIOR_SOFTMAX.candidate.v2.md`; and `../local_memory_adaptive_reads_20261105/LOW_RISK_WEAK_ANCHOR_COMPOSITION.candidate.v4.md`.

## Substantive correction verified

The first compilation draft treated the final module too much like an input-error contract for an already-computed logit bank. The imported proof instead requires a small error on the COMPLETE prepared vector after scaled-logit copies, norm padding and all clears. Version 4 resolves this: every preparation microstep belongs to the full reference length m; tolerances and a common uniform tube for original and both ablated programs are fixed before M; eta is then chosen to control the entire prepared-vector error. Thus the premise actually needed by final radial restoration is established, rather than assumed.

## Mathematical checks

- Pairing makes the full mean exactly zero. Homogenizing each local affine/ReLU overwrite with preserved anchors gives the exact update z+s(z)(F(z)-z), with O(eta^2) local error on a fixed tube.
- Both zero-score full-prefix heads have the displayed source-row normalization factors. Their individual local max-row error is bounded by ||B_0||||A_0||Z^3 eta^2/(2d), with no length factor. Combining both with all local preparation stages gives e_m<=C' eta^2 L^m.
- The proof propagates continuous circuit errors through plateau classifiers and division. It does not incorrectly require physical digit/count states to remain on their exact reference lattice.
- The fixed scaling C_out ensures ||v||<=1. The imported padding routine then prepares the required full norm near 3. It applies to arbitrary paired logits; the zero-sum probability-bank invariant of the earlier projection readout is unnecessary here.
- The imported restoration and final zero-shift gain-two LN, followed by C_out times coordinate projection, give the stated full logit-error bound. The displayed dyadic tolerances suffice. The conventional vocabulary softmax supplies exact positivity and normalization.
- Halving every consuming interior FFN first matrix and attention value matrix when changing LN gain one to two leaves all trajectories unchanged. Q/K remain zero.
- The clipping-to-floor argument is pathwise valid for binary targets with coordinates at least c. Serial-log and physical errors add at most 2zeta to the inherited suffix risk.
- Original and both ablated networks use one common eta and unchanged preparation/restoration/output parameters. Their reference separation remains at least 1/2 after flooring at a<=1/4; the small log and physical errors preserve a positive constant separation.

## Scope and resources

The normalized physical rows do not satisfy the exact public-linear identity. The valid conclusion is the uniform end-to-end approximation to Q_ref, and hence the same terminal protocol at error epsilon+zeta. This is not reconstruction of the physical evolving row bank.

The fixed c-dependent envelopes, O_c(log N+b) depth and per-coefficient precision, O_c((log N+b)^2) total descriptions, O(N) distributed state, and separate useful-head/local versus fully dense dummy-slot work bounds are consistent. No containment in a preassigned numerical M_K, finite-word execution guarantee, PostLN result, training result, rate improvement or unrestricted nonlinear-memory theorem is certified.

The audit used source reading and analytic derivation only. No scientific experiment, model execution, source-file edit, or upload was performed.
