# Independent exact-version review: early PreLN drafts require revision

6 November 2026 UTC. Verdict for BOTH files below: REVISION REQUIRED. These exact versions are not certified PASS. This is a proof-premise failure, not a counterexample to the theorem repaired later.

- `TWO_READ_PRELN_COMPILATION.candidate.v1.md` SHA-256: `75781a763c921a3080641b9bf56120c8de1aeffbbb2f173a8963f0795bf0bb9a`.
- `TWO_READ_PRELN_COMPILATION.candidate.v2.md` SHA-256: `e2b896315e4307a19f3b12d58975010a459ba8683534a794c28a5c729e325fac`.

## Substantive gap

Both drafts select the small-amplitude exponent M after describing reference computation through the logit bank, then introduce padding/copies/clears in Section 4. Both state:

> Its input requirement is a bounded paired logit bank with computational error <=xi, not a particular source of those logits.

That is not the sufficient premise proved by the imported final-output module. `INTERIOR_SOFTMAX.candidate.v2.md` Section 5 and `STANDARD_PRELN.candidate.v2.md` Sections 3-5 require the ACTUAL COMPLETE prepared vector to be within xi of the reference vector after scaled-logit copying, norm padding and all clears. This full-vector bound controls both the retained logits and the data-dependent normalization denominator used during radial restoration.

An xi bound at an incoming logit bank alone does not establish that premise. Subsequent continuous padding stages can amplify existing errors and add further small-amplitude simulation errors. The stated recurrence does not close the required final bound unless all those stages are included before M is selected, or a separate sufficient error-transfer bound for them is supplied. Neither early file supplies that missing step. Their final output error, derived risk error and physical ablation separation therefore are not yet certified by these exact drafts.

## Required repair

Choose fixed C_out so v=ell/C_out has norm at most one; append every scaled-bank copy, padding arithmetic microstep and scratch clear to the reference program; select tolerances and one common uniform tube covering the full original and both ablated programs; then define total m and select M so the full prepared-vector error is <=xi. Apply one unchanged final physical restoration/output routine to all three networks.

Version 2 adds total parameter accounting and fixed-envelope scope, but its relevant Sections 2-4 are unchanged from version 1 and do not repair this gap. Both early drafts also label O(N^2+ND) as dense work without distinguishing evaluation of every dummy attention slot, which can cost O(N^2D).

The later v4 resolves these items and has a separate exact-file PASS audit. That later acceptance does not retroactively certify v1 or v2. The early files remain preserved unchanged.

Review method: direct source/dependency reading, comparison of the two early versions, and analytic error-accounting checks. No scientific experiment, model execution, source modification or upload was performed.
