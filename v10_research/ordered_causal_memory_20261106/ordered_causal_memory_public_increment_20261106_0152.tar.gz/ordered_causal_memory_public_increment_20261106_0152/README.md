# Ordered causal memory: public research increment

This new additive local package preserves every file available in ordered_causal_memory_20261106, without overwriting sources or publishing to GitHub. All 28 material files are exact-byte copies. The full Chinese report is materials/RESEARCH_REPORT.zh.v1.html; the matching text/privacy review is materials/INDEPENDENT_REPORT_TEXT_PRIVACY_AUDIT.v1.md. Read the historical README for the precise accepted versions. Earlier candidates and failures remain historical, not retroactively certified.

## Scientific boundaries

The result is a restricted public-linear closure example preserving the existing ordered suffix estimator, a conditional bounded-resource positive-epsilon PreLN compilation, and a complementary reversal-symmetry obstruction. It is not a new Markov estimator, a better rate, a two-layer frontier, a learning guarantee or a solution to arbitrary nonlinear evolving causal memory. Two useful attention invocations do not mean two total paid primitive layers. The exact public-linear collapse applies to the logical reference, not the normalized physical memory. The v4 PreLN claim uses exact-real semantics, the full prepared-vector repair and a sufficiently large fixed c-dependent norm envelope. It does not certify finite arithmetic.

All PASS labels are preserved independent analytical text audits, not formal proofs or external peer review. PreLN v1/v2 explicitly remain REVISION REQUIRED under their exact-version failure review. No model training, scientific numerical experiment, sampled diagnostic or finite-arithmetic reproduction was performed for this package. Reading, copying, parsing and hashing documents are not scientific reproduction.

Visual acceptance is NOT COMPLETED. Historical HTML parsing is not browser/screenshot/print validation. This packaging operation did not render or retry a browser. External proof dependencies remain OPEN and are not supplied by embedded local appendices. This is not a recovered full v10 corpus or a claim of complete research restoration.

## Privacy and third-party rights review

All included files were checked for secrets, sensitive personal information, private conversations and machine paths. No redaction was needed. PRIMARY_COMPARISON.v1.md and its embedded HTML appendix contain original research summaries, citations and mathematical comparisons, not third-party paper full texts. Public literature links are retained; no external paper PDF/HTML, licensed dataset or other third-party full-text document is redistributed. No new license or rights grant is added. This is a scoped content review, not a legal clearance certificate.

## Contents and verification

SOURCE_DERIVATION_MAP.json maps every source/public file, byte count and SHA-256. PACKAGING_QA.json separates new byte/HTML checks from immutable historical QA. independent_review/ holds the independent packaging review and index of historical reviews. SHA256SUMS covers every other package file. Run python verify_package.py for read-only integrity checks.

Existing materials/build_report.py and materials/check_report.py write outputs. Run them only in a disposable copy; do not overwrite frozen materials. They build/check documents and do not train or simulate a scientific model. Version labels and creation-time status statements remain historical evidence.
