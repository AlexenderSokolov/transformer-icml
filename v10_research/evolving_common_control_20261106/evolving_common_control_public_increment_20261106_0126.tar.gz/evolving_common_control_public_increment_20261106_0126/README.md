# Evolving common-control public increment

This is a new, additive local publication candidate. It does not overwrite earlier research or publish anything. All 64 source files are represented under `materials/`; consult the manifest for authoritative counts. Source filenames, historical version labels, conditional PASS/repair-required/pending labels, failed arguments and historical QA are retained. HTML v1–v5 and all extant build/check script versions are preserved. The latest narrative is materials/RESEARCH_REPORT.zh.v5.html; its original independent text audit is materials/INDEPENDENT_REPORT_TEXT_PRIVACY_AUDIT.v5.md.

## Scope and limitations

The seven final mathematical candidates have historical exact-file analytical reviews. These are conditional analytical reviews, not formal verification, external peer review, neural compilation, finite-precision verification, training evidence, new scientific experiments or novelty certification. Older invalid or incomplete versions remain historical artifacts, not promoted results. The unrestricted full-row causal repeated-attention frontier remains open. Follow the precise norm, gain, masking, homogeneous-position and source-interiority conditions in the candidates; notably 8(r+epsilon+Delta)<=1-2c remains required in the explicit testing inequality.

The HTML reports retain their restricted conditions and original source-binding hashes. Visual acceptance is NOT completed. The historical Chromium failure (socket/ptrace denial and read-only configuration) remains in a minimally neutralized log. No rendering retry, screenshot validation, browser-security change, or claim of visual PASS is made by this package.

## Not a recovered or dependency-closed research corpus

This package faithfully preserves the files available in the named source directory. It does not recover missing files, reconstruct omitted proofs, establish a complete earlier v10 corpus, or claim reproducibility of scientific results. Earlier adaptive-read, anchored-extension, factorial refinement, stability-budget, source-average testing and current-frontier comparison materials are referenced but not included here. The statistical conclusions depend on those pre-existing results; dependency closure remains OPEN. The historical reported public commit identifier is provenance only and has not been reverified in this packaging operation. Literature URLs are preserved as historical citations, not newly checked claims.

## Reproduction and versions

The existing build/check scripts package and parse documents only, not scientific simulations. They write report/QA files and therefore should be run only in a disposable copy of materials. Never run them against this frozen package. Their versioned names do not necessarily equal the report version they output; inspect the explicit output paths in each script. All original QA records remain historical evidence. New packaging checks are separate in PACKAGING_QA.json. Independent-review materials and an index are under independent_review/; historical audits remain in their original locations to retain bindings.

SOURCE_DERIVATION_MAP.json gives every source and public relative filename, byte count and SHA-256; changed items have granular replacement mappings using hashed original fragments rather than leaking machine paths. Only a render-failure log and internal provenance attribution were neutralized. No mathematical candidate, scientific label, HTML report, scientific audit or source binding was changed. SHA256SUMS covers all package files other than itself and provides the final public hashes.
