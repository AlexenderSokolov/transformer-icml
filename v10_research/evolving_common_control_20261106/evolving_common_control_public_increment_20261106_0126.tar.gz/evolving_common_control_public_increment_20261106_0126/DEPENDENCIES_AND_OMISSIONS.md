# Dependencies and omissions

No available file in the source directory is omitted. All historical versions present there are included, whether successful, failed, incomplete or superseded. Missing version numbers are not filled in: there is no REPORT_DOCUMENT_QA.v4.json or INDEPENDENT_REPORT_TEXT_PRIVACY_AUDIT.v4.md in the source snapshot; no extra build_report.v5.py/check_report.v5.py is invented (the unversioned files target v5).

Not included: raw private machine paths (replaced in public failure log), internal coordination attribution (neutrally rephrased), files outside this source directory, any missing originals, browser screenshots/PDF renderings that were not available, and external dependencies. No source files were deleted or changed.

External prior dependencies, not closed by this package:
- Adaptive-read theorem v3.
- ANCHORED_MEMORY_EXTENSION.candidate.v1.md and its earlier INDEX discussion.
- Stability-budget v1.
- Factorial refinement v1.
- Source-average testing README v3 and accepted binary stationary Markov inequalities.
- CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md and its primary literature checks.

These identifiers follow the preserved provenance; their external exact-byte identity and complete transitive proof graph are not established here. The five arXiv URLs in the reports are preserved, not re-fetched. HTML source bindings concern embedded local appendices only and do not establish dependency closure.
