# Two-type count compression sharpens the homogeneous prefix closure bound

6 November 2026 UTC. Analytical candidate v1; independent review pending. This refinement was identified during independent review of the Lipschitz closure. It does not alter the more general common-control theorem.

## 1. Strict additional condition

In the CAUSAL_PREFIX_LIPSCHITZ_CLOSURE family, the surrogate banks are kappa_s(X_i,M_N),nu_s(X_i,M_N), IDENTICAL across positions conditional on X_i and reconstructed control. More generally, allow any closed control y with banks kappa_s(X_i,y),nu_s(X_i,y) and fixed uniform norms. Thus there are only TWO nonterminal K/V types at any state, even if their values change with the entire transcript. Public initial state, full-prefix inclusive masking, self handling, stage gains a_s,b_s, normalized outputs and all off-trajectory requirements remain unchanged.

## 2. Single-scalar one-way simulation

Let T=N+1 and let n_A be Alice's public number of positions. Alice sends an eta-quantization of u_A=(number of her +1 symbols)/T, a scalar in [0,n_A/T]. A public grid clipped to this interval preserves nonnegative reconstructed type masses. Bob adds his exact positive count/T; negative mass is N/T minus positive mass. Their two mass errors are equal and opposite, each at most eta.

At simulated y, the exact averaged nonterminal augmented contribution is

    u exp(q dot kappa_s(+1,y)) (nu_s(+1,y),1)
      +(N/T-u) exp(q dot kappa_s(-1,y)) (nu_s(-1,y),1).

Using the quantized u changes this vector by at most 2 eta exp(beta) sqrt(V_0^2+1), uniformly over the full state domain. Bob then adds the exact terminal self term/T. The denominator floor exp(-beta), ratio estimate and the accepted W recurrence apply. Choosing eta=c epsilon/(1+W) therefore gives worst-history output TV error <=epsilon using

    C<=min{N, K[2+log(1+W)+log(1/epsilon)]}.               (1)

K depends only on fixed norm budgets and dimensions. Local computation remains exact-real. No Taylor feature approximation is necessary because the type sums can be evaluated exactly after the count is known. The two masses can be quantized to arbitrary precision, and one count index has logarithmic bit length. If W=0, use zero communication separately.

## 3. Statistical and residual consequence

Let S_0=min{2+log(1+W),N}. The same advertised-envelope inversion of the binary one-way source-average testing theorem gives a positive constant a_c, depending on the fixed resource budgets, such that

    R(surrogate)>=a_c/sqrt(S_0).

Indeed advertise r=a/sqrt(S_0), choose epsilon=r, and bound U+log(1/r)<=O((1+log(1/a))U) on the S_0<N branch, U=2+log(1+W). The N branch follows from the finite-sample cap. Shrink a for witness interiority as in the reviewed companion.

For the actual causal prefix-Lipschitz family, the previously proved residual estimate yields

    R(actual)>=max{0, a_c/sqrt(S_0)-3 Gamma sqrt(K_c/N)}.    (2)

Hence for fixed c, Gamma^2 S_0=o(N) suffices for negligible residual and eventual half-constant lower. This improves the valid but conservative F_2 formula in the Lipschitz-closure candidate; it does not invalidate it.

With individually bounded fixed startup gains and subsequent nonexpansive stages, uniformly bounded b_s and row sensitivities give W=O(1+H), Gamma=O(H). A sufficient condition becomes H^2[2+log(1+H)]=o(N). With a_s<=A>1 and H<=D, bounded b_s and row sensitivities give the conservative condition H^2 A^(2D)(D+log(H+1)+1)=o(N).

## 4. Limitations

Position-dependent bank functions can have N different types, so this two-count message does not simulate them. Local pair/triple types are not free under the AA/BB split. Even in this two-type subclass, the count bound is an upper on simulation cost and its statistical consequence need not be sharp: a stronger direct information argument might exist. No optimality, learned-parameter recovery, normalized neural compiler or trained predictor claim is made.
