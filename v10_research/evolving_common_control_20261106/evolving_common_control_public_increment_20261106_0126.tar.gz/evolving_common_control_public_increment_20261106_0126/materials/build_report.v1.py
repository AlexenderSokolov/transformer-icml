from pathlib import Path
import hashlib, html, json
D=Path(__file__).parent
body='''
<header><p class="meta">v10 研究报告 · 2026 年 11 月 6 日 · 中文 v1</p><h1>逐层更新记忆的条件模拟与源平均残差界</h1>
<p>本报告研究未知二阶过程下，多次注意力读取逐层变化的非终端键和值时，哪些可验证结构仍允许以有限通信模拟预测器。获得了三个相互衔接的条件性结果：闭合共享控制模拟、源平均残差转移，以及因果前缀均值的非空实例。</p>
<p><strong>主要边界：</strong>尚未解决任意因果全行自注意力的多次读取主资源界。没有证明新的最优预测率、完整规范化网络实现或训练收敛。独立审阅为分析性文本审阅，不是形式化验证或外部同行评议。</p></header>
<nav aria-label="报告目录"><a href="#contract">问题契约</a> · <a href="#result1">结果一</a> · <a href="#result2">结果二</a> · <a href="#result3">结果三</a> · <a href="#resources">资源账本</a> · <a href="#prior">先行工作</a> · <a href="#revisions">错误修订</a> · <a href="#limits">局限与下一步</a> · <a href="#appendices">完整证明与审阅</a></nav>
<section id="contract"><h2>一 问题契约与已有基础</h2>
<p>统计目标是同一条已观测历史上的预测：输入为 N 个原始二元符号，附加一个合成终端行；未知源属于平稳、齐次二阶 Markov 类 P<sub>c</sub>，所有下一符号条件概率位于 [c,1−c]，其中已知 c∈(0,1/2)，N≥3。损失为真实末端上下文的期望总变差，再对源取上确界。模型参数可以依赖 N，但不能编码未知转移核，也不获得独立训练样本或真实核作为输入。</p>
<p>通信模拟采用固定公开输入划分。统计下界使用既有 AA/BB 模四划分。Alice 只发送一次由自己符号决定的消息；Bob 拥有自己的符号并完成模拟。本报告先证明最坏历史的模拟保证，再通过源平均测试定理推出统计下界；二者不是同一种评价标准。</p>
<p>前期已完成 token-local 记忆的自适应终端读取、固定锚点依赖的可分离提升、阶乘尾部带来的对数改进，以及稳定性预算 W 的误差传播。本次没有把这些已有结果重新作为新方法。新增条件允许公共系数依赖整个先前读取轨迹，只要该轨迹形成可由接收方重建的闭合状态。</p>
<p>所有终端读取均是对 N 个非终端行及合成自项的全前缀含自身 softmax，得分为 q·k。任意额外的不可分离位置得分、更改掩码或隐藏输入通道不自动满足本报告的定理。实际非终端更新仍须遵守架构的因果可达性；数学上的共享控制不是免费广播原语。</p></section>
<section id="result1"><h2>二 闭合共享控制下的模拟定理</h2>
<h3>结构条件</h3><p>有 D 个付费阶段、H≤D 次读取、J 种静态提升记忆。第 j 种记忆中的 K<sub>j,i</sub>(X<sub>i</sub>)∈R<sup>p</sup>、V<sub>j,i</sub>(X<sub>i</sub>)∈R<sup>v</sup>只依赖本行原始符号和公开位置。真实读入的键和值可以在每次读取改变：</p>
<div class="eq">k<sub>s,i</sub>(y) = A<sub>s</sub>(y) K<sub>j(s),i</sub>(X<sub>i</sub>)<br>v<sub>s,i</sub>(y) = B<sub>s</sub>(y) V<sub>j(s),i</sub>(X<sub>i</sub>)</div>
<p>状态 y 从公共值开始，只通过这些读出与公开函数更新，不允许另有未传输的数据输入。A、B 的算子范数以及提升键、值和查询的全向量范数均有冻结上界。此条件须对所有原始历史及模拟器投影域成立，不能只测量一条轨迹的矩阵秩。自项由 Bob 在其模拟状态直接计算。</p>
<p>完整阶段在投影域上的 Lipschitz 上界记为 a<sub>s</sub>；同一状态的注意力答案扰动对阶段输出的增益记为 b<sub>s</sub>。必须计入全部数据坐标、系数变化、输出投影与后续同阶段计算。定义</p>
<div class="eq">W = Σ<sub>s 为读取</sub> b<sub>s</sub> ∏<sub>ℓ&gt;s</sub> a<sub>ℓ</sub><br>U = 2 + log(1+W) &nbsp;&nbsp; F<sub>p</sub>(t) = t [t / log(e+t)]<sup>p</sup></div>
<h3>结论与证明</h3><p>对 0&lt;ε≤1，存在源无关、确定性、单向协议，使最坏历史输出总变差误差不超过 ε，通信满足</p>
<div class="eq">C ≤ min{N, K J(v+1) F<sub>p</sub>(U+log(1/ε))}。</div>
<p>K 只依赖所声明的固定维数和范数预算，不隐含 N、D、H、J 或 W 的增长。H=0 或 W=0 时零通信足够。</p>
<ol><li>Alice 对每种静态记忆发送阶乘归一化多项式矩的量化索引。矩以 1/(N+1) 归一化，其半径与 N 无关。Bob 加上自己那部分的精确矩。</li><li>在当前模拟状态 y，Bob 取提升查询 u=A(y)<sup>T</sup>q(y)，再用 B(y) 收缩值矩。统一查询球上的确定性逼近同时覆盖所有反馈选择，无须提前知道真实 y、无需独立性、无需交互通信。</li><li>把真实自项单独加入分子和分母。全前缀含自身的掩码与有界得分保证平均分母至少为 exp(−β)。比值稳定性把增广矩误差转成注意力答案误差。</li><li>先比较同一模拟状态上的精确阶段与近似阶段，再比较精确阶段的两个输入。由 e<sub>s</sub>≤a<sub>s</sub>e<sub>s−1</sub>+b<sub>s</sub>δ 得最终误差≤Wδ。取 δ=ε/(1+W)，阶乘尾部给多项式次数 O(t/log(e+t))，量化位数贡献 O(t)。</li></ol>
<p>这属于精确实数通信语义：没有断言有限浮点误差已经验证。系数对先前读出的依赖是本次比固定锚点结果更广的部分；多项式矩方法本身已有先行工作。</p>
<h3>未知源上的条件资源下界</h3><div class="eq">z = 2+log(1+W)+log(J+1)<br>S = min{(J+1)F<sub>p</sub>(z), N}<br>R(Q) ≥ a<sub>c</sub>/√S。</div>
<p>常数 a<sub>c</sub>也依赖固定提升维数和范数。证明广告式地设定风险包络 r=a/√S，选择 ε=r，调用既有单向源平均测试不等式，再取足够小的固定 a；不是把未知实际风险塞入模拟资源假设。W=0 用零消息的常数风险论证。增加次数未必有效：若 J 与 W 一直有界，则这类模型不能获得源类一致性。</p>
<p><strong>证明状态：</strong>COMMON_CONTROL_SIMULATION v2 已获条件性分析审阅 PASS，依赖完整结构证书及既有源平均测试定理。</p></section>
<section id="result2"><h2>三 真实逐层记忆的源平均残差转移</h2>
<p>实际网络可以具有任意演化的非终端记忆。选取一个源无关的闭合共享控制替代计算，使二者初始终端状态相同、终端更新函数与自项相同，差异只通过规定的非终端读取进入。替代计算不必是已编译的神经网络，只需满足上述单向模拟证书。</p>
<p>在实际终端轨迹上，定义实际键和值与替代计算键和值的平均行距离 d<sup>k</sup><sub>s</sub>、d<sup>v</sup><sub>s</sub>，每个均以 N+1 归一化。查询范数上界 Q、值半径 V<sub>0</sub>及双侧得分界 β 必须覆盖两者及线性插值。</p>
<div class="eq">ρ<sub>s</sub>(X) = exp(2β)[d<sup>v</sup><sub>s</sub>(X)+2V<sub>0</sub>Q d<sup>k</sup><sub>s</sub>(X)]<br>B(X) = Σ<sub>s 为读取</sub> b<sub>s</sub>ρ<sub>s</sub>(X) ∏<sub>ℓ&gt;s</sub>a<sub>ℓ</sub><br>Δ = sup<sub>P∈P<sub>c</sub></sub> E<sub>P</sub>B(X)</div>
<p>在固定查询下对键和值做线性插值，softmax 权重不超过 exp(2β)/(N+1)。注意力答案的导数是值增量的加权平均，加上 (v<sub>i</sub>−o) 与键扰动的加权项；积分得到单次答案误差≤ρ<sub>s</sub>。再按替代计算的阶段增益传播，得到逐历史输出差≤B(X)，从而模拟实际网络的源平均误差≤ε+Δ。</p>
<div class="eq">R(实际网络) ≥ max{0, a<sub>c</sub>/√S − Δ}。</div>
<p>这里不用交换上确界与差：三角不等式直接给 R(替代计算)≤R(实际网络)+Δ。实际轨迹上的残差足够，因为递推先在实际状态比较两个阶段，再用替代阶段的统一 Lipschitz 界比较状态。</p>
<p>显式数值测试式为 (r+ε+Δ)<sup>2</sup>min(C+1,N)≥1/(16384 ln 2)，但必须同时满足 0&lt;r+ε+Δ≤1/128 和 <strong>8(r+ε+Δ)≤1−2c</strong>，以保证测试源仍在 P<sub>c</sub> 中。后一个条件是独立审阅发现并修复的遗漏。</p>
<p>Δ 是需要单独证明的结构残差，不是免费假设，更不能从期望得到的预测风险反推。要使转移有实质效力，须证明 Δ 小于 a<sub>c</sub>/√S。罕见历史可容许较大残差，但罕见性必须对未知源类统一成立；仅有混合性、常数状态维度或小的未加权误差都不够。</p>
<p><strong>证明状态：</strong>AVERAGE_DEFECT_TRANSFER v3 已获条件性分析审阅 PASS。</p></section>
<section id="result3"><h2>四 因果前缀均值的可核查实例</h2>
<p>令 X<sub>i</sub>∈{−1,1}。第一次零得分因果注意力让第 i 行保存 m<sub>i</sub>=i<sup>−1</sup>Σ<sub>t≤i</sub>X<sub>t</sub>。合成终端自项为零，它得到 N/(N+1) 倍的全样本均值；再用不超过 2 的付费缩放恢复 y=M<sub>N</sub>。</p>
<p>第二次终端读取仍为零得分，非终端值是各自的 m<sub>i</sub>，自项为 y。替代计算把所有非终端值改为 y。后者是常数静态基底乘以公共系数 y，满足闭合结构；前者有真正因果、逐行不同的非局部记忆。</p>
<div class="eq">B(X) ≤ L/(N+1) Σ<sub>i=1</sub><sup>N</sup>|m<sub>i</sub>−M<sub>N</sub>|。</div>
<p>如果平稳源满足 Var(Σ<sub>t=1</sub><sup>i</sup>X<sub>t</sub>)≤Ki，则利用公共均值 μ 作纯分析比较，E|m<sub>i</sub>−M<sub>N</sub>|≤√(K/i)+√(K/N)。模拟器不需要知道 μ。由 Σi<sup>−1/2</sup>≤2√N，得</p>
<div class="eq">Δ ≤ 3L√(K/N)。</div>
<p>对 P<sub>c</sub>，四状态 pair chain 的每个两步转移至少为 c²，因此具有权重 α=4c² 的统一 minorization。两步收缩给协方差界 2(1−α)<sup>⌊h/2⌋</sup>，可取</p>
<div class="eq">K<sub>c</sub> = 1+4Σ<sub>h≥1</sub>(1−4c²)<sup>⌊h/2⌋</sup> = 2/c²−3。</div>
<p>长正号块后接长负号块可以让最坏历史残差保持常数量级。因此这个例子具体展示了源平均路线比统一历史逼近更宽的适用范围。</p>
<p><strong>证明状态：</strong>CAUSAL_PREFIX_AVERAGE_EXAMPLE v1 作为注意力程序实例获 PASS。它没有估计全部四个二阶转移行，不是有效二阶预测器，也没有完成正 ε PreLN/PostLN 的严格编译。L 是共同后续计算的答案到输出增益；若它随资源增长，必须保留其增长。</p></section>
<section id="resources"><h2>五 资源账本与依赖关系</h2>
<table><thead><tr><th>资源或条件</th><th>本报告的计费与限制</th></tr></thead><tbody>
<tr><td>N 与数据</td><td>N 个原始符号；完整历史传输给 N 位上限；不提供未知核。</td></tr>
<tr><td>D、H、J</td><td>D 是付费阶段，H≤D 是读取数，J 是不同完整静态提升记忆数。共用权重并不自动代表同一种完整记忆。</td></tr>
<tr><td>p、v 与范数</td><td>提升键和值维数显式出现；常数对固定维数成立，不声称维数统一。低秩但系数范数爆炸不合格。</td></tr>
<tr><td>a、b、W</td><td>全部输入依赖坐标、残差与归一化增益均须计入；要求投影域上统一而非只沿精确轨迹。</td></tr>
<tr><td>ε 与通信</td><td>局部精度 ε/(1+W)；使用现有阶乘 Taylor 尾部、球网量化与分母稳定性。</td></tr>
<tr><td>Δ 与源类</td><td>对所有 P∈P_c 的加权平均残差上界；固定 c 的常数可随 c→0 恶化。</td></tr>
<tr><td>算术与实现</td><td>协议为精确实数、无局部计算限制；不是有限精度运行或神经元实现保证。</td></tr>
<tr><td>训练与实验</td><td>未训练、未采样源、未执行数值复现、未测模型；只进行了证明文本审阅与文档检查。</td></tr>
</tbody></table>
<p>证明依赖链：既有 token-local 模拟与锚点可分离提升 → 阶乘度数改进及稳定性预算 → 本次反馈闭合模拟 → 平均行扰动转移。统计部分独立依赖已审阅的二元单向源平均测试定理；例子另用有限状态链的两步 minorization 和方差恒等式。没有把一般交互式 Markov 信息不等式当成已知结果。</p></section>
<section id="prior"><h2>六 最接近先行工作与非新颖部分</h2>
<p>以下对照沿用已核查的 CURRENT_FRONTIER_PRIMARY_COMPARISON v2；本次不是新的全网查重或优先权认证。</p>
<ul><li><a href="https://arxiv.org/html/2302.13214v1">Alman 与 Song，Fast Attention Requires Bounded Entries</a>：多项式核分解与有界注意力逼近是直接技术前身。本报告不声称新的特征代数或运行时间最优界。</li>
<li><a href="https://arxiv.org/html/2606.07205v1">Chen 等，Towards Tight Bounds for Streaming Attention</a>：确定性 Taylor 矩摘要与有界查询球逼近已有基础。反馈查询由统一逼近覆盖，不构成首次“自适应注意力压缩”。</li>
<li><a href="https://arxiv.org/html/2610.41038v1">Akman 等的研究</a>：重复静态记忆 gatherers 已有先例。不能把重复静态读取本身作为本次贡献。</li>
<li><a href="https://arxiv.org/html/2407.17686v1">Rajaraman 等，Transformers on Markov Data Constant Depth Suffices</a>，以及 <a href="https://arxiv.org/pdf/2508.07208v2">Ekbote 等，What One Cannot Two Can</a>：已有少层 Markov 计数表达结果。表达性、最低层数与一般优化收敛是不同问题；这些构造不能未经资源审查直接代入本报告的冻结范数条件。</li></ul>
<p>本次有限增量在于：把固定锚点的公共系数换成可由先前读出重建的反馈系数，并把一般真实记忆与这一结构之间的差距写成显式加权源平均残差。残差传播、Taylor 特征和有限状态链混合均不是新的通用工具。</p></section>
<section id="revisions"><h2>七 失败路线与独立审阅修订</h2>
<ol><li><strong>COMMON_CONTROL v1：</strong>漏写全前缀含自身掩码及 Bob 添加自己精确矩的步骤。v2 明确补齐，v1 与对应修订要求审阅保留。</li>
<li><strong>AVERAGE_DEFECT v1 与 v2：</strong>显式测试式少写 P_c 内部性的幅度约束；c 接近 1/2 时原表述不成立。v3 补上 8(r+ε+Δ)≤1−2c，同时明确共同公共初态与覆盖两种答案域的增益。</li>
<li>不能让 Alice 直接摘要实际演化 K/V，因为其依赖跨方先前读出。修正后的协议只摘要静态提升基底。</li>
<li>不能从零得分因果注意力推断全局共享摘要，每行读取的前缀不同。前缀实例采用源平均残差，而非虚构精确公共广播。</li>
<li>不能从低状态维度推出少量信息，也不能以待证明的预测风险假定小残差。实际可达性、稳定性及残差都须另外核查。</li></ol>
<p>全部数学候选旧版本和对应独立审阅仍保留。本报告主文只采用通过审阅的 common-control v2、average-defect v3 和 prefix-example v1。完整原文与审阅附在文末，可离线核对；审阅并不等于正式机器证明或发表认可。</p></section>
<section id="limits"><h2>八 尚未解决的问题与后续研究判据</h2>
<ol><li>对一般全行因果自注意力，构造固定维数、固定范数的闭合控制证书，或证明其不存在。</li><li>对于真实有用的二阶预测网络，独立证明 Δ=o(1/√S)，而不是只给均值程序实例。</li><li>验证原始符号、付费层、正 ε 归一化与有限精度的完整实现。未经此步，不把抽象程序宣称为规范化 Transformer 构造。</li><li>寻找匹配上界与必要条件。目前只有充分条件和条件下界，指数与常数不主张最优。</li><li>训练问题另行建立：表达构造不证明梯度算法会找到它，先验未知源不等于源特定训练成功。</li></ol>
<p>研究流程未进行模型训练、科学数值实验、对外投稿、购买或公开仓库写入。本 HTML 为静态离线报告，无脚本、表单、追踪或外部字体；只有明确列出的文献超链接。生成与解析报告不属于科学复现。</p></section>
'''
files=[('完整证明一','COMMON_CONTROL_SIMULATION.candidate.v2.md'),('完整证明二','AVERAGE_DEFECT_TRANSFER.candidate.v3.md'),('完整例子','CAUSAL_PREFIX_AVERAGE_EXAMPLE.candidate.v1.md'),('独立审阅一','INDEPENDENT_COMMON_CONTROL_AUDIT.v2.md'),('独立审阅二','INDEPENDENT_AVERAGE_DEFECT_AUDIT.v3.md'),('独立审阅三','INDEPENDENT_CAUSAL_PREFIX_EXAMPLE_AUDIT.v1.md')]
body+='<section id="appendices"><h2>九 完整证明与独立审阅原文</h2><p>为避免翻译掩盖技术限定，以下附录保留通过审阅的英文技术原文及审阅文本。哈希用于精确版本核对。</p>'
bindings={}
for title,name in files:
    data=(D/name).read_bytes(); sha=hashlib.sha256(data).hexdigest(); bindings[name]=sha
    body+=f'<details><summary>{title} · {html.escape(name)}</summary><p class="hash">SHA-256 {sha}</p><pre>{html.escape(data.decode())}</pre></details>'
body+='</section><footer><p>报告版本 v1 · 2026 年 11 月 6 日 UTC · 所有结论以明确条件和原始证明为准。</p></footer>'
style='''body{font-family:system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;color:#171717;max-width:980px;margin:0 auto;padding:40px 24px;line-height:1.8;background:#fff}h1{font-size:2rem;line-height:1.4}h2{font-size:1.5rem;margin-top:2.6rem}h3{font-size:1.15rem;margin-top:1.8rem}p,li{font-size:1rem}.meta,footer{color:#555}.eq{padding:12px 0;font-family:Cambria,Georgia,serif;overflow-wrap:anywhere;line-height:1.9}nav{margin:28px 0}a{color:#145a88}table{border-collapse:collapse;width:100%;margin:20px 0}td,th{border:1px solid #d9d9d9;padding:12px;text-align:left;vertical-align:top}th{background:#e8edf1}tr:nth-child(even){background:#f8f9fa}details{margin:20px 0}summary{cursor:pointer;font-weight:600;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.65 ui-monospace,monospace}.hash{overflow-wrap:anywhere;font-size:.85rem}section{scroll-margin-top:20px}@media(max-width:600px){body{padding:20px 16px}h1{font-size:1.6rem}td,th{padding:8px}}@media print{body{max-width:none;padding:0}nav{display:none}h2,h3{break-after:avoid}tr{break-inside:avoid}details{display:block}summary{list-style:none}a{color:inherit}}'''
out='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>逐层更新记忆的条件模拟与源平均残差界</title><style>'+style+'</style></head><body>'+body+'</body></html>'
(D/'RESEARCH_REPORT.zh.v1.html').write_text(out)
(D/'REPORT_SOURCE_BINDINGS.v1.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2)+'\n')
print('HTML bytes',len(out.encode()))
