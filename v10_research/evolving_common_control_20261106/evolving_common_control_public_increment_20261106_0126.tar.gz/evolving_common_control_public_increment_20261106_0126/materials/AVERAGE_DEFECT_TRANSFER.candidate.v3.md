# Source-average residual certificate for evolving all-row memory

6 November 2026 UTC. Version 3 additionally imposes the interior-witness amplitude range and common initial state/answer domain after independent review. Version 2 explicitly aligns the mask contract with the independently corrected common-control theorem; v1 is preserved. Companion to COMMON_CONTROL_SIMULATION.candidate.v2.md. Analytical result awaiting independent review. No numerical or training evidence.

## 1. Actual network versus closed surrogate

Let an actual network have arbitrary evolving nonterminal K/V. Every declared terminal read in BOTH networks is full-prefix inclusive softmax over all N nonterminal rows and the synthetic self row, with scores q dot k and no extra nonseparable positional score. Isolate its terminal/control coordinates y_s. Assume each terminal update is G_s(y,attention_answer), with the same read-stage schedule and self K/V as a certified closed common-control surrogate from the companion. Both computations start at the SAME public initial terminal/control state. The gains b_s must hold for answer perturbations covering BOTH actual and surrogate answer balls. Nonread terminal updates must be identical; no extra history-dependent channel is allowed. Nonterminal memory can be arbitrary, but its only influence on y is through the declared reads. The surrogate need not be an implementable network: a publicly specified source-independent one-way simulable computation is enough for this argument.

Require uniform key/query/value bounds for the ACTUAL banks and surrogate banks, including the straight-line interpolations between their K/V at fixed y. Euclidean balls automatically satisfy this. Use common query q_s(y), ||q||<=Q, value radius V_0, and score absolute bound beta. Terminal self terms coincide at fixed y. At the actual trajectory y_{s-1}(X), define

    d^k_s(X)=(1/(N+1))sum_{i<=N} ||k_actual,s,i(X)-k_surrogate,s,i(X_i,y_{s-1}(X))||,
    d^v_s(X)=(1/(N+1))sum_{i<=N} ||v_actual,s,i(X)-v_surrogate,s,i(X_i,y_{s-1}(X))||,
    rho_s(X)=exp(2 beta)[d^v_s(X)+2 V_0 Q d^k_s(X)].

These are mathematical certificate quantities, not free features supplied to the predictor or simulator. They may be bounded by symbolic analysis, or checked on a finite set for that finite set only. A finite numerical check alone does not certify a uniform source-class assertion.

## 2. Attention perturbation lemma

For a fixed query and T=N+1 rows, interpolate keys and values linearly. At interpolation parameter t, attention weights obey alpha_i(t)<=exp(2 beta)/T. Differentiating the answer o(t) yields

    o'(t)=sum_i alpha_i(t) Delta v_i
          +sum_i alpha_i(t)(v_i(t)-o(t)) (q dot Delta k_i).

Since ||v_i(t)-o(t)||<=2V_0, integration gives ||o_actual-o_surrogate||<=rho_s. The self perturbation is zero, so summing only i<=N is valid. No independence assumption or hidden sqrt(N) term appears.

## 3. Pathwise and average transfer theorem

Let a_s be the surrogate exact stage Lipschitz constants and b_s the same-state continuation gains. These constants must hold on the projected domain containing both exact actual and surrogate terminal states. Define

    B(X)=sum_{s read} b_s rho_s(X) product_{l>s} a_l.

Then output TV(actual,surrogate)<=B(X). Proof: compare the actual stage on its actual y to the surrogate stage on THAT y using b_s rho_s; then use the surrogate stage's a_s-Lipschitz bound to compare actual y with surrogate y. The recurrence is e_s<=b_s rho_s(X)+a_s e_{s-1}. Only actual-path residuals are required because the recurrence is oriented this way. Final simplex projection fixes actual and surrogate probability outputs and gives the TV bound. Require both exact outputs to be normalized, or explicitly include their identical normalizing map in the paid terminal continuation and gain accounting.

Consequently, if

    Delta=sup_{P in P_c} E_P B(X),

then the companion's one-way simulator has source-average error <=epsilon+Delta against the ACTUAL network, with communication still given by (1) there. If actual worst-source prediction risk is r, testing yields

    (r+epsilon+Delta)^2 min(C+1,N)>=1/(16384 ln 2)

whenever 0<r+epsilon+Delta<=1/128 AND 8(r+epsilon+Delta)<=1-2c, so the lag-two testing witnesses remain within P_c. The latter condition cannot be omitted when c approaches 1/2. Alternatively, with S and a_c as in the companion, applying the resource lower to the surrogate and the triangle inequality gives the clean transfer

    R(actual) >= max{0, a_c/sqrt(S)-Delta}.                 (3)

The surrogate is source-independent and its structural simulation proof, not physical realizability, suffices for the testing lower. The inequality on sup risks follows from R(surrogate)<=R(actual)+Delta; no exchange of sup and difference is used.

## 4. What this resolves and does not resolve

Exact closed common-control factorization corresponds to Delta=0. A source-average defect certificate can tolerate large errors on rare histories, unlike uniform approximation, but the rarity must be proved uniformly over the unknown source class. Bounded norm, mixing, constant hidden dimension or small average UNWEIGHTED row perturbation alone does not control Delta after amplification: all later a_l are charged. A proposed useful transfer must establish Delta=o(1/sqrt(S)), or at least a smaller constant at that scale, without presupposing the desired prediction lower bound.

This gives an explicit sufficient target for actual evolving causal memory: produce a public closed surrogate and bound the weighted mean row defects. It neither asserts that every such network admits one nor establishes a favorable defect bound for general causal self-attention. The perturbation lemma and hybrid argument are standard stability tools, not a new technique claim. Closest approximation precedents and common-control novelty limits are in the companion; no additional external theorem is imported.
