# Independent exact-file audit: average defect v3

6 November 2026 UTC.

Reviewed candidate: `AVERAGE_DEFECT_TRANSFER.candidate.v3.md`.

SHA-256: `b5635587be993ddb209c5f0ea54c72ca7d362c13a57cc0b35b25dd654e92cd29`.

Companion: `COMMON_CONTROL_SIMULATION.candidate.v2.md`, SHA-256 `fd8024b004920fceaa91147cffed4216bbb13e29aba26d3ba9d54deb882c9c15`, accepted conditionally in its independent v2 audit.

**Verdict: PASS, conditional on the stated common-control, common-initialization, full-prefix, common-query/self, uniform norm and gain certificates. All issues identified in the v1/v2 reviews are repaired.**

This is an analytical review, not formal verification, empirical evidence, external peer review or novelty certification. The candidate was not edited.

## 1. Interpolated attention perturbation

Fix a raw history, a stage and its actual control state y. Set T=N+1 and interpolate actual and surrogate row keys and values, leaving q_s(y) and the coinciding self terms fixed. The uniform score bound gives

    alpha_i(t) = exp(score_i(t))/sum_j exp(score_j(t))
                 <= exp(2 beta)/T.

The full-prefix mask is necessary for this particular T-based estimate and is now explicit in both computations. Differentiating o(t)=sum_i alpha_i(t)v_i(t) gives exactly

    o'(t)=sum_i alpha_i(t) Delta v_i
           +sum_i alpha_i(t)(v_i(t)-o(t))(q dot Delta k_i).

Uniform value-ball membership implies ||v_i(t)-o(t)||<=2V_0, since o(t) is a convex combination. Apply the triangle and Cauchy-Schwarz inequalities to each summand, then integrate over t in [0,1]. The resulting bound is

    ||o_actual-o_surrogate||
      <=exp(2 beta)[d_s^v+2V_0 Q d_s^k]=rho_s.

The self differences vanish, so their omission from the defect sum is correct even though their weight remains in the denominator. No independence, average-zero residual, or hidden square-root-of-N estimate is used. Convex norm balls ensure the interpolation bounds from endpoint bounds; more general domains must separately establish them as stipulated.

## 2. Oriented pathwise comparison

At the actual y, the actual and surrogate terminal continuations use the same G_s and query/self functions. Their read answers differ by at most rho_s. The now explicit b_s domain covers both answer balls, so replacing the answer changes the local state by at most b_s rho_s.

Compare next with the surrogate stage evaluated at its own control state. The surrogate exact-stage Lipschitz certificate bounds that discrepancy by a_s e_(s-1). The recurrence is therefore

    e_s<=a_s e_(s-1)+1_(read s)b_s rho_s(X).

Both computations now explicitly start at the identical public state, so e_0=0. Iterating gives the candidate's B(X). Actual nonterminal memory need not be a function of the terminal state: at this comparison step it is evaluated only on its actual history, while the surrogate is evaluated on that same actual terminal state. This orientation explains why no off-actual-path residual is required. The surrogate gain certificate must still cover the actual terminal states used in the hybrid comparison.

All data entry outside the declared reads remains excluded. A sample-dependent initial terminal state, different nonread update, or hidden actual-memory input to G_s would introduce another error/source term and is not licensed. Both normalized outputs and all normalization continuation gains are explicitly charged. Final simplex projection is nonexpansive and converts the Euclidean bound into the stated binary TV bound.

## 3. Source-average simulation and testing

For every source P, pathwise triangle inequality followed by expectation gives

    E_P TV(Qhat_surrogate,Q_actual)<=epsilon+E_P B(X)
                                        <=epsilon+Delta.

The protocol is precisely the source-independent common-control simulator, so no cost is added for evaluating a residual, learning a source or communicating actual evolving memory. The defects are analysis quantities, not data supplied to the decoder. The communication remains that of the surrogate.

Let delta=r+epsilon+Delta. The lag-two testing witnesses have amplitude h=8 delta. The corrected conditions delta<=1/128 and 8 delta<=1-2c ensure both h<=1/16 and membership in P_c. This repairs the v1/v2 erroneous unqualified interior-class testing display. The universal numerical constant is then the one in the imported reviewed testing theorem.

The clean transfer requires only the accepted surrogate resource lower and the source-wise inequality

    E_P risk_surrogate<=E_P risk_actual+E_P B(X).

Taking supremums gives R(surrogate)<=R(actual)+Delta. Combining with R(surrogate)>=a_c/sqrt(S) and nonnegativity yields the displayed max{0,a_c/sqrt(S)-Delta}. There is no invalid exchange of supremum and difference and no missing restriction on delta for this separate c-dependent transfer formulation.

## 4. Scope

This is a standard attention perturbation plus hybrid-stability transfer applied to the locally certified common-control surrogate. It provides a concrete sufficient analytical target for a source-average compression proof of an actual evolving-memory architecture. It does not establish that the target is achieved for all such architectures.

An unweighted row-defect average is insufficient if the b_s or later a_l products grow. Useful asymptotic preservation of the lower requires Delta to be smaller than its resource-risk scale, as the candidate states. Rare histories can be tolerated only through a source-uniform expectation bound. Finite experimental checks cannot establish that quantifier.

The surrogate need not be a physically realizable causal network because the statistical testing theorem concerns source-independent output functions admitting one-way simulation. This analytical use does not grant free noncausal operations to the actual network or claim a normalized Transformer construction. No training, matching upper rate, general architecture theorem or literature novelty follows.

## 5. Inspected evidence and actions

Read average-defect v1, v2 and v3, common-control v1/v2 and the local source-average testing theorem. The latter's information-theoretic external dependency remains imported as previously reviewed. No new primary-literature search or novelty certification was performed.

Actions were local text/diff/hash inspection, paper derivation and writing audit files. No scientific experiment, model run, training, upload, public mutation or candidate modification occurred.
