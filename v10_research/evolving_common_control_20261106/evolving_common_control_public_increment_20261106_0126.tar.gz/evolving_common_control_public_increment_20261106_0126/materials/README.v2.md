# Final mathematical versions and follow-on result map

6 November 2026 UTC. All mathematical results below have exact-file independent analytical PASS audits; this is not formal verification, numeric reproduction, a neural compilation, external peer review, or a novelty certificate.

Original three results:
- COMMON_CONTROL_SIMULATION.candidate.v2.md; INDEPENDENT_COMMON_CONTROL_AUDIT.v2.md.
- AVERAGE_DEFECT_TRANSFER.candidate.v3.md; INDEPENDENT_AVERAGE_DEFECT_AUDIT.v3.md.
- CAUSAL_PREFIX_AVERAGE_EXAMPLE.candidate.v1.md; INDEPENDENT_CAUSAL_PREFIX_EXAMPLE_AUDIT.v1.md.

Follow-on results:
- CAUSAL_PREFIX_LIPSCHITZ_CLOSURE.candidate.v3.md; INDEPENDENT_PREFIX_LIPSCHITZ_AUDIT.v3.md. Position-homogeneous causal prefix-register updates have a fixed binary onehot lift and Delta<=3 Gamma sqrt(K_c/N).
- TWO_TYPE_COUNT_SIMULATION.candidate.v1.md; INDEPENDENT_TWO_TYPE_COUNT_AUDIT.v1.md. In that strictly homogeneous two-type subclass, scalar count quantization improves communication to O(2+log(1+W)+log(1/epsilon)). Put S_0=min{2+log(1+W),N}; Gamma^2 S_0=o(N) makes the defect negligible for fixed c.
- PREFIX_DEFECT_SHARPNESS.candidate.v1.md; INDEPENDENT_PREFIX_SHARPNESS_AUDIT.v1.md. Canonical unamplified residual obeys sqrt(N) E TV ->1/sqrt(2 pi), so its square-root scale is sharp.
- AMPLIFIED_PREFIX_DEFECT.candidate.v1.md; INDEPENDENT_AMPLIFIED_PREFIX_AUDIT.v1.md. O(log N) local clipped amplification keeps values bounded and scores zero, yet canonical replacement discrepancy tends to 1/4 on IID data.

Full Chinese report versions retain embedded exact candidates and independent reviews. v2 covers the original three results; v3 and later incorporate the follow-on results. Use the latest report accompanied by a matching PASS text/privacy audit. Source bindings and HTML QA records distinguish parse/hash checks from visual rendering. Chromium rendering was blocked by sandbox socket/ptrace restrictions; no screenshot validation is claimed.

All previous candidates and repair-required audits remain preserved. No public mutation, purchase, submission, training run, source simulation or scientific numerical experiment was performed. Build and parse scripts only package/check documents. The main unrestricted causal repeated-attention frontier remains open, and none of the illustrative programs is advertised as a useful unknown second-order estimator.
