# Preserved unsuccessful routes and duplication check

6 November 2026 UTC.

1. Rejected as duplicate: finite-anchor separable K/V lifting. ANCHORED_MEMORY_EXTENSION.candidate.v1.md already proves this. The new candidate uses feedback-reconstructed coefficients rather than a fixed anchor tuple and preserves all lifted norm/rank resources.
2. Rejected invalid proof: send moments of actual evolving K/V once. Alice cannot compute these from her input before learning previous cross-party answers. The corrected proof sends moments of STATIC lifted banks and reconstructs dynamic coefficients at the decoder's simulated state.
3. Rejected invalid extension: call causal uniform attention a global broadcast. Each row receives a different prefix average. A global shared summary cannot be supplied backwards through causal time without an actual authorized architectural construction.
4. Rejected unsupported inference: fixed state dimension implies a cheap shared-state description. The prior anchored INDEX example refutes that inference for abstract scalar controls; the new theorem requires control reconstruction and uniform bounded separable maps.
5. Rejected risk circularity: set approximation residual equal to observed prediction risk without proving it. The companion residual bound is a separate explicit quantity Delta; a useful consequence must verify it independently.
6. Rejected stability shortcut: evaluate coefficient derivatives only on exact states. The sketch decoder uses perturbed states; the full surrogate stage certificate must hold on the entire projected domain.
7. Rejected layer-count claim: a common-control attention program is not automatically a raw-token bounded-norm causal Transformer implementation. No implementation or rate improvement is claimed.

Read local dependencies: adaptive reads v3 and anchored extension v1; stability budget v1; factorial refinement v1; source-average README v3 and its stated accepted inequalities; current-frontier primary comparison v2. Historical provenance records reported current public main f5ad033f03a2b8fdfc3a5a8576ab9e7b7b253dcb, whose latest change is archival/terminology correction, not new mathematics. Directory is not a git working tree; no local git status claim is made. All source links are inherited from the checked local literature comparison, not newly fetched primary pages.

No failed mathematical theorem has been silently promoted to a result. All original local materials remain untouched. New files are analytical candidates until exact-file independent review is complete. No upload, public commit, purchase, submission, or scientific experiment was performed.

Independent review corrections preserved in revisions:
- COMMON_CONTROL v1 omitted explicit full-prefix inclusive masking and Bob's addition of his own exact partial moments. Both are explicit in v2; v1 remains archived as incomplete.
- AVERAGE_DEFECT v1/v2 stated the numerical testing inequality over P_c without the additional witness-interiority constraint 8(r+epsilon+Delta)<=1-2c. For c near 1/2 this is false. v3 restores that range, explicitly requires identical public initial states and gain bounds covering both answer domains. The c-dependent final risk-transfer inequality remains valid.

Follow-on research and further preserved repairs:
- CAUSAL_PREFIX_LIPSCHITZ_CLOSURE v1 initially requested nonexpansive gains for every stage, conflicting with the initial factor (N+1)/N>1. v2 allowed a bounded product of startup gains, but independent review correctly noted that an early zero gain can hide a later large gain after an error injection. v3 requires individual startup a_s,b_s bounds (or all relevant suffix products).
- The position-homogeneous binary subclass first used the valid but loose F_2 lift bound. Independent review identified that its one scalar positive-type mass suffices. TWO_TYPE_COUNT_SIMULATION v1 retains the tighter O(U+log(1/epsilon)) communication and S_0=min{U,N}; no claim is made for position-dependent banks.
- PREFIX_DEFECT_SHARPNESS v1 proves the canonical unamplified discrepancy has asymptotic constant 1/sqrt(2 pi) after multiplication by sqrt(N). Its S comparable to N discussion is a comparison scale, not an assertion that this fixed two-read program itself has growing S.
- AMPLIFIED_PREFIX_DEFECT v1 proves canonical replacement discrepancy tends to 1/4 after O(log N) bounded-gain clipping stages. This is not a lower against every simulator and not a low-risk model; no such stronger claim is licensed.
