# Evolving-memory research increment, 6 November 2026

## Results

1. COMMON_CONTROL_SIMULATION.candidate.v2.md: one-way, worst-history simulation of transcript-dependent evolving K/V when a public closed state controls bounded linear combinations of fixed token-local lifted banks. Communication is min{N,K J(v+1)F_p(2+log(1+W)+log(1/epsilon))}. The source-average minimax lower follows with the existing stationary binary testing theorem.
2. AVERAGE_DEFECT_TRANSFER.candidate.v3.md: a weighted mean-row key/value residual transfers the lower to actual evolving memory: R_actual>=max(0,a_c/sqrt(S)-Delta). It uses the surrogate's uniform stage gains, actual-path residuals, and the correct interior-source testing range.
3. CAUSAL_PREFIX_AVERAGE_EXAMPLE.candidate.v1.md: distinct causal prefix-mean rows violate exact token locality but admit a source-uniform Delta<=3L sqrt(K_c/N) certificate, with K_c=2/c^2-3 a sufficient loose covariance constant. This is an attention-program witness, not a normalized neural compiler or consistent order-two estimator.

The independent reviewer checked final versions and reported conditional analytical PASS for all three; exact hashes and formal audit text are supplied in the adjacent INDEPENDENT_* files. Earlier v1/v2 errors are preserved with their reviews, not overwritten. FAILED_ROUTES_AND_PROVENANCE.v1.md records failed routes, duplicate avoidance, and revisions.

## Remaining main gap

No small closed-control certificate or small weighted residual is proved for arbitrary evolving full-row causal self-attention. No unrestricted repeated-attention resource frontier, matching rate, training theorem, finite-precision implementation, or literature-priority claim follows. The prefix example demonstrates the theorem's scope but not a statistical advantage from another attention use.

## Scientific provenance

Uses the prior adaptive-read, anchored separable, factorial refinement, stability-budget and source-average testing packages. Closest checked literature links and contract differences are in the common-control candidate and the prior CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md. No fresh web priority search is claimed. Latest repository main reported by the coordinating researcher: f5ad033f03a2b8fdfc3a5a8576ab9e7b7b253dcb, archival/label changes only. No scientific executable, model run, purchase, submission, upload or public mutation was performed.
