# Causal row-update conditions giving a negligible source-average defect

6 November 2026 UTC. Follow-on analytical candidate v2; v1 is preserved. Independent review requested after clarifying startup gain and first-read value budgets. This extends the prefix-mean witness, not the unrestricted multiple-attention theorem. It does not assert a standard normalized Transformer compiler or training result.

## 1. Explicit sufficient causal condition

Let X_i in {-1,1} have a stationary interior binary order-two law P_c. A first causal uniform-attention computation produces m_i=i^(-1)sum_{t<=i}X_t at row i. The synthetic terminal recovers M_N=N^(-1)sum_i X_i by the paid bounded rescaling already specified in the reviewed prefix example.

At every subsequent useful terminal read s, suppose the actual nonterminal banks have the form

    k_{s,i}=kappa_s(X_i,m_i),  v_{s,i}=nu_s(X_i,m_i).

The maps are PUBLIC, SOURCE-INDEPENDENT and IDENTICAL ACROSS POSITIONS. They may differ across s and arise from many paid nonlinear tokenwise updates retaining (X_i,m_i) as registers. No terminal-to-past broadcast is needed in this actual computation. In particular local row dynamics u_i^{s+1}=G_s(X_i,m_i,u_i^s) are allowed if the resulting kappa_s,nu_s have the certificates below. The actual query may depend on the entire prior terminal read transcript.

For x in {-1,1} and z,z' in [-1,1], require

    ||kappa_s(x,z)-kappa_s(x,z')||<=L^k_s |z-z'|,
    ||nu_s(x,z)-nu_s(x,z')||<=L^v_s |z-z'|.

Require frozen full norm bounds ||kappa||<=R_k, ||nu||<=V_0, ||q||<=Q, fixed original key/value dimensions and full-prefix inclusive terminal masks. Bounds must hold on the complete projected domains. All original network computation remains paid; representability of arbitrary nonlinear maps by allowed primitives is not asserted. Composition of displayed local Lipschitz maps gives a syntactically checkable (possibly loose) L certificate. Constants may grow only if that growth is kept in the resource ledger.

This is a nontrivial causal all-row-update condition: each row depends on its whole own prefix through m_i, different rows carry different summaries, and the key/value functions can change nonlinearly at each paid stage. It excludes arbitrary new full-row mixing at every stage unless such mixing is separately proved to preserve this representation.

## 2. Fixed-rank closed surrogate for any such nonlinear maps

Replace every m_i in the read bank by the terminal's preserved M_N, leaving terminal initial state, update schedule, query and self maps unchanged. The surrogate is closed: M_N came from its identical first read, and all later data inputs enter through declared reads.

Use the STATIC two-dimensional onehot basis e(X_i), with e(-1)=(1,0), e(+1)=(0,1). Define

    A_s(z)=[kappa_s(-1,z), kappa_s(+1,z)],
    B_s(z)=[nu_s(-1,z), nu_s(+1,z)].

Then surrogate k=A_s(M_N)e(X_i), v=B_s(M_N)e(X_i), with ||A_s||op<=sqrt(2)R_k, ||B_s||op<=sqrt(2)V_0. These bounds do not grow with the nonlinear complexity of kappa_s or nu_s. The same basis handles the first read (signed value is [-1,+1]e(X_i)); therefore one static bank with p=v=2 and J=1 suffices. The common first-and-later-read value bound must be max(1,V_0); using this larger fixed bound in beta/perturbation constants is harmless. All coefficient dependence is reconstructed at the decoder, and original self contributions remain separate. Increasing local nonlinear depth may still increase the full-stage gains a_s, b_s and W; it does not disappear from accounting.

An arbitrary position dependence would break this fixed two-column certificate. It can be accommodated only by an explicitly bounded additional position basis or by keeping its cost; it is not included here.

## 3. Defect estimate and the exact negligible-defect criterion

Take a common absolute score bound beta and the same continuation gains b_s, surrogate stage gains a_s as in the reviewed transfer theorem. The first read has zero defect. For subsequent reads,

    d^k_s <= L^k_s/(N+1) sum_i |m_i-M_N|,
    d^v_s <= L^v_s/(N+1) sum_i |m_i-M_N|.

Define the weighted local-to-terminal influence

    Gamma=sum_{s after first read} b_s exp(2 beta)
                (L^v_s+2V_0 Q L^k_s) product_{l>s} a_l.

This is not automatically equal to W; the row-bank Lipschitz constants must be charged. The reviewed covariance argument gives, uniformly over P_c,

    Delta <= 3 Gamma sqrt(K_c/N),   K_c=2/c^2-3.

Let S=min{2F_2(2+log(1+W)+log 2),N}, where F_2(t)=t[t/log(e+t)]^2, for the J=1 surrogate. Any harmless fixed constants can instead be retained using the general companion formula. Then

    R(actual)>=max{0, a_c/sqrt(S)-3 Gamma sqrt(K_c/N)}.      (1)

For a family indexed by N and fixed c, the concrete sufficient criterion

    Gamma_N^2 S_N / N -> 0                                (2)

implies Delta_N=o(1/sqrt(S_N)). Thus eventually the defect costs less than half the surrogate lower: R(actual)>=a_c/(2sqrt(S_N)). This is a sufficient, not necessary, condition. If c changes, K_c must remain visible and (2) becomes K_c Gamma_N^2 S_N/N ->0; the statistical lower constant a_c also changes, so a relative-to-a_c condition is needed for the half-constant conclusion.

For the earlier two-read prefix witness, Gamma=L and the precise condition is L^2 S=o(N), not simply N->infinity. Fixed W,L makes S bounded and the condition automatic. At S comparable to N and fixed nonzero L, this estimate gives only a residual at the same N^(-1/2) scale, not little-o; it neither proves nor disproves a sharper residual estimate.

## 4. Interpretable depth and gain regimes

Allow a fixed number of startup stages with a uniformly bounded product of gains, including the necessary first-read rescaling by (N+1)/N<=2. If all subsequent a_s<=1 and the products b_s(L^v_s+2V_0 QL^k_s) are uniformly bounded, then Gamma=O(H) and W=O(1+H), provided b_s is also uniformly bounded. Therefore the sufficient criterion is

    H^2 F_2(2+log(1+H))/N ->0.

For example H=N^eta with any fixed 0<eta<1/2 satisfies this bound, because F_2(log H) grows only polylogarithmically. This is a conditional nonexpansive resource regime, not a claim that residual/LN Transformer blocks are nonexpansive. All paid stages AFTER that fixed startup, including nonread stages, must satisfy a_s<=1 for this particular conclusion; every startup gain is still included in the actual W. Gamma sums only reads after the identical first read, so the startup itself contributes no defect.

If a_s<=A>1, b_s and row Lipschitz constants are uniformly bounded, and H<=D, then Gamma=O(H A^D), W=O(H A^D), and S=O(F_2(D+log(H+1)+1)) away from its N cap. One sufficient condition is H^2 A^(2D) F_2(D+log(H+1)+1)=o(N). For H<=D and D=eta log N with eta<1/(2 log A), the polynomial-logarithmic factors are dominated and the condition holds. These are conservative gain-based sufficient regimes, not sharp frontiers.

## 5. Why this does not construct a useful order-two predictor

For the exact surrogate, all static moments depend only on the total counts of -1 and +1, while terminal self/control are recursively determined by those moments. Thus the surrogate is permutation invariant in the raw history. It cannot recover a specified last pair or all four transition rows just by repeatedly changing kappa,nu or the adaptive query.

The actual causal rows encode ordered prefix information; the small-defect condition says that this order-dependent contribution remains too weak at the final output to overcome the lower bound. This supplies an impossibility subclass inside the common unknown second-order prediction model, NOT a statistically competitive estimator for that model. Adding an uncharged terminal pair feature would change the contract; adding a paid route to it must be included and its simulation justified anew.

A fixed finite raw alphabet admits the same onehot factorization with dimension equal to alphabet size. Extending to local tuple features such as (X_{i-2},X_{i-1},X_i) is not free: those features cross AA/BB ownership boundaries and are not token-local under the binary one-way reduction. A true second-order-count construction therefore needs a new simulation argument or explicitly paid communication for those dependencies.

## 6. Preserved unsuccessful generalizations

- Counting one scalar prefix register as a cheap common state is invalid: m_i differs with i. Only the SOURCE-AVERAGE residual comparison justifies its replacement by M_N.
- Declaring arbitrary position-dependent maps rank two is invalid. The identical-across-position assumption is essential to the displayed static bank.
- Using only W without Gamma omits amplification within local row transformations.
- Writing Delta=o(N^(-1/2)) for the prefix example is unsupported; the proved bound is O(N^(-1/2)). Negligibility is relative to 1/sqrt(S), via (2).
- Importing lagged triples as local raw features would change the original input/ownership contract.

Proof dependencies: COMMON_CONTROL_SIMULATION v2, AVERAGE_DEFECT_TRANSFER v3, CAUSAL_PREFIX_AVERAGE_EXAMPLE v1 and their independent exact-file audits. No new external theorem, training run, numerical simulation or public mutation is used. Factorization by a finite onehot alphabet and Lipschitz composition are elementary, not new general techniques.
