# Independent exact-file audit: amplified prefix defect v1

6 November 2026 UTC.

Candidate: `AMPLIFIED_PREFIX_DEFECT.candidate.v1.md`.

SHA-256: `b9a2648c8e71743defbf69bb5b7296a3d14ee07abf548ccf17ae978f8141506f`.

**Verdict: PASS as an analytical counterexample to automatic vanishing discrepancy for the specified global-mean surrogate. The exact asymptotic expected TV discrepancy is 1/4.**

This is not a lower bound against every simulator, a useful predictor, a complete normalized Transformer construction, a numerical validation, or a novelty certification. The candidate was not edited.

## 1. Bounded primitive amplification

Let d=ceil(log_2 N) and L_N=2^d, so N≤L_N<2N. Repeatedly applying z→clip(2z,-1,1) d times is exactly clip(L_N z,-1,1): clipping cannot reverse the sign, and once saturated, later applications remain saturated. Every intermediate value lies in [-1,1], and every scalar primitive has Lipschitz gain at most two.

For integer S_i, a nonzero prefix mean has magnitude at least 1/i. Since L_N≥N≥i, the transformed value equals sgn(S_i), including the declared zero convention. The terminal transformed mean similarly equals sgn(S_N). First-read scaling and final affine normalization are paid bounded operations. All final scores are zero, and all final values have norm at most one. The depth claim is O(log N), while composed sensitivity is L_N, not a fixed constant.

The final surrogate bank uses a constant static value basis with public coefficient f_N(M_N). The entire computation also includes the identical first raw-value read, so its full bank family includes that initial basis or the equivalent binary onehot representation. The candidate's phrase about a constant basis describes the final substituted bank; it does not need or justify treating the first read as data free.

## 2. Exact discrepancy and tie contribution

Write sigma_i=sgn(S_i), b=sigma_N and a=(sum_i sigma_i+sigma_N)/(N+1). Then

    a-b=sum_i(sigma_i-sigma_N)/(N+1).

If S_N≠0, every summand has the same weak sign, so the absolute value equals the sum of absolute values. If S_N=0, equality may fail; both candidate expressions are bounded by two. Hence the absolute difference of their expectations is at most 2P(S_N=0).

For even N=2n, P(S_N=0)=binom(2n,n)/4^n=O(n^(-1/2)); for odd N it is zero. The final map a→((1+a)/2,(1-a)/2) has binary TV difference exactly |a-b|/2. Therefore equation (1), including its factor 1/[2(N+1)] and o(1) tie correction, is correct.

## 3. Pairwise Gaussian limit

For fixed t∈(0,1), put i=floor(Nt). Both i and N-i tend to infinity. The sums S_i and S_N-S_i are independent. Their normalized characteristic functions converge to independent standard Gaussian characteristic functions by the elementary cosine expansion, so

    (S_i/sqrt(i), S_N/sqrt(N))

converges to a standard bivariate Gaussian pair with correlation sqrt(t). The discontinuity set of the bounded absolute-sign-difference function is the union of the coordinate axes, which has limiting Gaussian measure zero. Its expectations therefore converge; no unjustified continuous mapping at a positive-probability atom is involved.

For a bivariate centered Gaussian with correlation rho, represent its two coordinates as projections of an isotropic two-dimensional standard Gaussian onto unit vectors meeting at angle arccos(rho). Uniform angular direction gives opposite-sign probability arccos(rho)/pi. Thus the limit of the absolute sign difference is 2 arccos(sqrt(t))/pi. Discrete zero-sign events are absorbed by the same almost-everywhere continuity argument.

## 4. Sum limit and the constant

Define the bounded step function using floor(Nt), with S_0=0 if needed. Its integral differs from the candidate's normalized finite sum by only endpoint and N-versus-(N+1) terms of order 1/N. The pointwise limit holds for every t∈(0,1), and the functions are bounded by two, so dominated convergence applies without any uniform CLT estimate.

The integral is checked directly by u=sqrt(t):

    integral_0^1 arccos(sqrt(t)) dt
      =integral_0^1 2u arccos(u) du
      =integral_0^1 u²/sqrt(1-u²) du
      =integral_0^(pi/2) sin²(theta) dtheta
      =pi/4.

Consequently the normalized expected absolute sign difference tends to (2/pi)(pi/4)=1/2. Multiplication by the final binary-TV factor 1/2 gives precisely 1/4. The candidate's stated constant is correct.

## 5. Scope and risk interpretation

The fair IID signed source belongs to every fixed P_c with 0<c<1/2, so a discrepancy bounded away from zero for this single source also prevents a vanishing uniform source-class discrepancy for this particular surrogate. This refutes the inference that bounded values, bounded scores, fixed primitive gains and mixing alone force replacement of each prefix mean by the global mean to be accurate after paid amplification.

It does not refute the existence of a different accurate source-average simulator or a different surrogate. The proof gives no communication lower for the actual attention program. It also does not bypass the full positive-epsilon normalization/primitive contract: the candidate explicitly remains an attention program.

The assertion that the program is not low risk on the fair source can be made rigorous using only the proved discrepancy. The surrogate output is an extreme binary distribution whenever S_N≠0, so its expected TV risk against the fair next-symbol law tends to 1/2. By triangle inequality, the actual risk has liminf at least 1/2-1/4=1/4. No further random-walk occupation theorem is needed for that conclusion.

The local row Lipschitz constant L_N grows at order N, so the earlier Gamma-based negligible-defect condition is not satisfied. All constants in the row norm and score bounds may remain fixed while the composed stability resource grows. This is exactly the distinction the counterexample illustrates.

## 6. Evidence and actions

Read the exact candidate and the previously reviewed causal prefix, average-defect and common-control documents. The limit was checked by analytical characteristic-function, Gaussian-angle, integral and expectation arguments. No stochastic process simulation, Monte Carlo estimate, numeric integration, model run, scientific execution, upload or public mutation occurred.
