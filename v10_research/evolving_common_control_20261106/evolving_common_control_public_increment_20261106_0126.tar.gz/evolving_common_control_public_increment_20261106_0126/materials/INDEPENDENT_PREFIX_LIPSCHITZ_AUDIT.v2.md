# Independent exact-file audit: prefix Lipschitz closure v2

6 November 2026 UTC.

Candidate: `CAUSAL_PREFIX_LIPSCHITZ_CLOSURE.candidate.v2.md`.

SHA-256: `c216d1b01c70a1f76febc4c646f33d750932aa1c98e0239583c47bdde816ef6e`.

**Verdict: CORE DERIVATION ACCEPTED; one remaining startup-gain condition requires repair.**

This revision correctly includes the first-read max(1,V_0) budget, allows a startup phase before nonexpansive later stages, and explains that Gamma sums only reads after the identical first read. However, bounding only the product of all startup a_s does not imply W=O(1+H).

Read errors are injected between stages and are multiplied by later suffix products, not the product of every startup gain. An early zero or small a_s can conceal an arbitrarily large later gain in the full product. For example a gain 1/N before a unit read injection and gain N afterward has bounded complete product but amplifies that injection by N. In the actual first-read computation an exact stage can even have a_s=0 because its output is independent of the initial public state; a full startup product containing this zero controls no later amplification at all.

Require instead either a fixed number of startup stages each with a uniformly bounded gain, or a uniform bound on the product of max{1,a_s}, or directly on all relevant startup suffix products. Keep b_s uniformly bounded. The actual bounded rescaling by at most two satisfies this repaired condition. The general resource/risk formula is unaffected; this change repairs only the illustrative asymptotic regime.

No candidate edit, scientific experiment, model execution, upload or public mutation occurred.
