# The unamplified prefix replacement has a sharp square-root residual scale

6 November 2026 UTC. Analytical candidate v1, independent review pending. This quantifies the earlier prefix example's exact limitation at the statistical N^(-1/2) scale; no experiment is used.

Under fair IID X_j in {-1,1}, let the actual terminal answer be a=(sum_{i=1}^N m_i+M_N)/(N+1), and the canonical surrogate answer b=M_N. Normalize both by Q(t)=((1+t)/2,(1-t)/2). Let H_n=sum_{i=1}^n 1/i and H_0=0. Then

    a-b=(1/(N+1)) sum_{j=1}^N w_{N,j} X_j,
    w_{N,j}=H_N-H_{j-1}-1.

Indeed each X_j appears in m_i with coefficient 1/i for i>=j, and subtracting N M_N removes coefficient 1 from every X_j inside the numerator.

Set a_j=H_N-H_{j-1}. Summing in the opposite order gives sum_j a_j=N. Furthermore

    sum_j a_j^2
      =sum_{i,k=1}^N min(i,k)/(ik)
      =sum_i 1/i + 2 sum_{k=1}^N (k-1)/k
      =2N-H_N.

Consequently sum_j w_{N,j}^2=N-H_N and

    Var(a-b)=(N-H_N)/(N+1)^2 ~ 1/N.

The maximum absolute weight is O(log N), so its ratio to sqrt(sum_j w_{N,j}^2) tends to zero. The normalized weighted Rademacher sum converges to a standard normal by the elementary triangular-array CLT. One can verify this directly from its characteristic function: expand log cos(u w_j/sqrt(sum w^2))=-u^2 w_j^2/(2 sum w^2)+O(u^4 w_j^4/(sum w^2)^2); the sum of fourth-order remainders is bounded by a constant times max_j w_j^2/sum w^2 and vanishes. Hence sqrt(N)(a-b) converges in distribution to a standard normal.

Its second moments are uniformly bounded, so its absolute values are uniformly integrable. Therefore

    sqrt(N) E TV(Q(a),Q(b)) -> (1/2) E|Normal(0,1)|
                              =1/sqrt(2 pi).             (1)

Thus this canonical source-average replacement has exact Theta(N^(-1/2)) discrepancy even on fair IID data. The previous O(N^(-1/2)) bound cannot generally be improved to little-o at fixed nonzero output gain merely by invoking mixing. It IS negligible relative to 1/sqrt(S) when S=o(N); at S comparable to N, (1) shows that particular surrogate discrepancy is not negligible.

This is a residual-sharpness statement for this explicit program/surrogate pair, not optimality of any architecture risk bound, not a lower bound against every communication simulator, and not a construction of a useful unknown-order-two predictor. The final value-to-probability gain here is exactly 1/2 in TV, not an unspecified growing L.
