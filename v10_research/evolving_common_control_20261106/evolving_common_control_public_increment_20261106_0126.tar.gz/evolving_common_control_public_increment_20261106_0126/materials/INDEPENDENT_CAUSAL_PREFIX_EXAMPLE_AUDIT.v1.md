# Independent exact-file audit: causal prefix-average example v1

6 November 2026 UTC.

Reviewed candidate: `CAUSAL_PREFIX_AVERAGE_EXAMPLE.candidate.v1.md`.

SHA-256: `12337b6ee7cd6321deec32a518f948e0c4886785b2814346769495941a390446`.

**Verdict: PASS as an attention-program witness for the reviewed average-defect transfer. No claim of a complete normalized Transformer implementation, low-risk order-two predictor, or general evolving-memory theorem is accepted or made.**

The candidate was not edited. This audit is analytical, not experimental, formal or external peer review.

## 1. Actual and surrogate computations

In a simultaneous first causal zero-score attention operation, each nonterminal row i averages raw values X_1,...,X_i and therefore outputs m_i. The synthetic terminal averages the N raw values and its zero self value, giving N M_N/(N+1). The paid scalar multiplication (N+1)/N recovers y=M_N with a uniform gain at most 2 for N>=1.

The second actual terminal read averages m_1,...,m_N and its self value y. The surrogate's second read averages N copies of y and its same self value y, so its answer is exactly y. The first terminal read and y agree exactly in both computations.

The surrogate has a finite collection of fixed token-local bases, X_i and 1, with zero keys. Its second value bank is B(y) times the static scalar 1 with B(y)=y, uniformly bounded on [-1,1]. Its common state begins publicly and receives raw data only through the first read. Thus it has the closed common-control certificate. One can use two fixed banks, or stack both value bases in a fixed-dimensional bank; no growing dimension, bank count or coefficient norm is required.

There is no key defect and beta=0. At the second read the exact answer difference is

    abs((sum_i m_i+y)/(N+1)-y)
      =abs(sum_i(m_i-M_N))/(N+1)
      <=sum_i abs(m_i-M_N)/(N+1).

A common bounded continuation with the stated answer-to-output gain L therefore gives the candidate's pathwise TV estimate. Any shared y-dependence in that continuation contributes no additional initial discrepancy because the first-stage y values are equal. Its output normalization and full gain must be included, as in the companion theorem.

## 2. Expected defect from the variance certificate

For a stationary source with mean mu, the stated partial-sum variance bound implies

    E abs(m_i-mu)<=sqrt(K/i),
    E abs(M_N-mu)<=sqrt(K/N).

Triangle inequality gives E abs(m_i-M_N)<=sqrt(K/i)+sqrt(K/N), without any independence between m_i and M_N. Summing and using sum_(i=1)^N i^(-1/2)<=2sqrt(N) gives

    E B(X)<=L sqrt(K)[2sqrt(N)+sqrt(N)]/(N+1)
            <=3L sqrt(K/N).

The unknown mean is an analysis-only centering device and is not used by the public surrogate or its simulator. Uniformity over a source class follows whenever K and L are uniform over that class.

## 3. Uniform stationary P_c covariance bound

Let Z_t=(X_(t-1),X_t) denote the four-state pair chain. Each two-step transition from (a,b) to a target pair (u,v) equals

    p(u|a,b) p(v|b,u)>=c^2.

Thus the two-step kernel minorizes alpha times the uniform four-state law with alpha=4c^2. The minorizing uniform law need not be the stationary law. Doeblin contraction still gives

    TV(Law(Z_(t+h)|Z_t=z),pi)<=(1-alpha)^floor(h/2)

for the stationary law pi, because total variation contracts by at most 1-alpha per two steps and by at most one on an additional step.

The spin observable has sup norm one, so the conditional expectation differs from its stationary mean by at most twice that TV distance. Since X_t is measurable with respect to Z_t,

    abs(Cov(X_t,X_(t+h)))
      =abs(E[X_t(E[X_(t+h)|Z_t]-mu)])
      <=2(1-alpha)^floor(h/2).

Expanding the variance and bounding Var(X_t)<=1 yields

    Var(sum_(t=1)^i X_t)
      <=i+4 sum_(h=1)^(i-1)(i-h)(1-alpha)^floor(h/2)
      <=i[1+4 sum_(h>=1)(1-alpha)^floor(h/2)].

The proposed K is therefore valid. Writing rho=1-alpha, the series is 1+2rho/(1-rho), so the displayed valid choice simplifies to K=8/alpha-3=2/c^2-3. This is a loose finite uniform bound for each fixed c in (0,1/2), not an optimal variance constant. Stationarity supplies the common mean and removes an initialization-bias term; no IID assumption was used.

## 4. Genuine but limited scope

The actual prefix means depend on previous raw tokens and violate exact token locality. They need not coincide with the common global sample mean even at a fixed position with a fixed own token. The example therefore supplies a nonempty source-average residual extension beyond an exactly common broadcast bank.

The absence of a vanishing worst-history bound is also real. For even N, take the first N/2 spins to be +1 and the rest -1. Then M_N=0, all m_i are nonnegative, and their average tends to log 2. Thus the row-average defect does not vanish uniformly over histories, while its source-uniform expected bound over fixed stationary P_c decays at N^(-1/2).

This does not establish a useful prediction algorithm for all four order-two transition contexts. With fixed L and fixed surrogate resources, the transferred lower is a constant resource obstruction minus O_c(N^(-1/2)), consistent with that limitation. The program includes explicit causal attention and a bounded rescaling, but its compilation into the full positive-epsilon PreLN/PostLN primitive contract remains a separate obligation. The candidate labels this correctly.

## 5. Evidence boundary

Read the exact example, average-defect v3, common-control v2 and the already inspected local statistical/stability dependencies. The minorization, covariance estimate and series were checked by paper derivation. No new external theorem beyond elementary finite-state Doeblin contraction was imported for the example.

Actions were local text/hash reads and writing this audit. No scientific execution, simulation, training, public mutation, upload or candidate modification occurred.
