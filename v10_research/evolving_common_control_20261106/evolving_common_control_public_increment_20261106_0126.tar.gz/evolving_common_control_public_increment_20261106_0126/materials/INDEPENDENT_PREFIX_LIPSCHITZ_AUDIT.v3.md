# Independent exact-file audit: prefix Lipschitz closure v3

6 November 2026 UTC.

Candidate: `CAUSAL_PREFIX_LIPSCHITZ_CLOSURE.candidate.v3.md`.

SHA-256: `274a6b4d0456ebb2f97725e61596cbd4b0f85e248484a3668918020c4fec5e85`.

**Verdict: PASS, conditional on the stated position-homogeneous prefix representation and the inherited common-control/average-defect certificates. The startup, first-read budget and summation clarifications requested for v1/v2 are sufficient.**

This audit does not accept a general causal-memory theorem, a normalized Transformer compiler, a training theorem or a novelty claim. The candidate was not edited.

## 1. Structural condition and the fixed lift

The representation kappa_s(X_i,m_i), nu_s(X_i,m_i) is a real causal restriction, not token locality: m_i carries the whole prefix ending at i. The first causal uniform layer supplies that prefix statistic, and later tokenwise updates may transform it nonlinearly provided the resulting composed maps have the stated uniform Lipschitz and norm certificates. Arbitrary subsequent full-row mixing does not preserve this representation automatically.

After replacing m_i by the terminal's preserved M_N, every position with the same raw sign uses the same K/V pair. The two columns of A_s(z) and B_s(z) therefore recover those pairs exactly from e(X_i). Their operator norms are at most their Frobenius norms, giving sqrt(2)R_k and sqrt(2)V_0. The static basis vectors have norm one. These estimates do not depend on nonlinear formula complexity or depth.

The same basis also represents the first raw signed value through [-1,+1]e(X_i), with operator norm sqrt(2). The corrected overall value budget max(1,V_0) covers that read. Thus p=v=2 and J=1 are valid for the entire surrogate, with original self terms separately handled. Off-trajectory coefficient/gain certificates, public initialization and exclusion of other terminal data channels remain necessary, as inherited from the companion results.

Position identity is essential: an arbitrary position-specific map need not be captured by the same two columns. A small raw alphabet alone does not make position-specific or lagged-neighbor banks a two-type bank. The onehot factorization is elementary finite-type algebra, not a new general technique.

## 2. Defect and negligible-scale criterion

At the actual control state, the global mean stored after the identical first read is the same M_N used by the surrogate comparison. Each row difference is bounded by L_s^k|m_i-M_N| or L_s^v|m_i-M_N|. Applying the reviewed attention perturbation estimate and the oriented surrogate-stage recurrence gives

    B(X)<=Gamma/(N+1) sum_i |m_i-M_N|.

Gamma includes only later read stages. The first read and its identical mean-recovery startup have zero defect. The factors L_s^k and L_s^v are composed row sensitivities, not merely the per-primitive gains, and must remain in Gamma even when all row values are bounded.

The reviewed stationary covariance calculation supplies E[(N+1)^(-1)sum_i|m_i-M_N|]<=3sqrt(K_c/N), uniformly over P_c, with K_c=2/c²-3. Hence Delta<=3Gamma sqrt(K_c/N). Combining with the valid general p=2,J=1 surrogate lower gives the candidate's inequality (1).

For fixed c and fixed norm/dimension budgets,

    [3Gamma sqrt(K_c/N)] sqrt(S)
      =3sqrt(K_c Gamma²S/N).

Thus Gamma²S/N→0 makes the displayed defect o(1/sqrt(S)), and eventually less than a_c/(2sqrt(S)). The condition is sufficient, not necessary; cancellation can make actual output discrepancy smaller than the rowwise upper. For variable c, both K_c and the c-dependent lower constant must be retained. In particular, the half-constant conclusion requires control relative to a_c, not merely absolute little-o against 1/sqrt(S).

The earlier two-read witness has Gamma=L, so L²S=o(N) is the correctly stated sufficient criterion. A uniform O(N^(-1/2)) bound is not a little-o guarantee at a comparison scale S comparable to N.

## 3. Startup and growth regimes

Version 3 explicitly bounds every individual a_s and b_s in a fixed-size startup, so every relevant error-propagation suffix product is uniformly bounded. This repairs v2: a bounded full startup product could hide a large later gain behind an earlier zero or small factor. The actual mean-extraction startup, including its rescaling by at most two, satisfies the corrected requirement. The described startup is identical in actual and surrogate computations and introduces no row-defect term.

If all later a_s≤1, later b_s are bounded and the displayed products b_s(L_s^v+2V_0 QL_s^k) are bounded, then each later read contributes O(1) to W and Gamma. The startup contributes O(1) to W, so W=O(1+H) and Gamma=O(H). The candidate's sufficient H²F_2(2+log(1+H))=o(N) condition follows by monotonicity and fixed-factor scaling of F_2. H=N^eta for fixed eta<1/2 satisfies it because the remaining factor is polylogarithmic.

If every stage gain is at most fixed A>1, every suffix product is at most A^D. Bounded b_s and row sensitivities give W,Gamma=O(H A^D), hence U=O(D+log(H+1)+1) and the displayed sufficient exponential-gain condition. For D=eta log N with eta<1/(2log A) and H≤D, N^(2eta log A) is sublinear by a fixed power, so the additional logarithmic factors do not prevent the condition. Natural logarithms are used in this depth statement.

These are conditional certificates, not claims that generic residual or positive-epsilon normalization blocks are nonexpansive. All paid nonread stages after startup remain part of the gain hypothesis. The general formula with actual W and Gamma is valid even when these simplified regimes fail.

## 4. Permutation invariance and limits

All surrogate static moments are functions of the total counts of the two raw signs. Its public initial state and recursive read/self/control updates consequently depend only on those counts and public architecture data. Permuting a raw history cannot change its output. Therefore this surrogate cannot recover a specified terminal pair or exact order-sensitive transition counts from repeated homogeneous single-symbol reads.

The actual prefix registers contain order information. The theorem concerns the subclass where its final effect is small in the quantified Gamma-weighted mean comparison. It does not construct an order-two estimator or show that all useful order-two networks satisfy that condition. Supplied terminal pairs, position-specific banks or raw pair/triple features would change the stated dataflow and communication contract.

The F_2 expression is conservative but valid. The separately written two-type count candidate can improve its resource accounting; that does not invalidate this frozen candidate or make the stronger statement part of this audit's bound.

## 5. Actions and dependencies

Read all three versions, the exact common-control v2, average-defect v3 and prefix-example v1, and their reviewed reasoning. The derivation is analytical. No new external theorem, scientific execution, model run, simulation, candidate modification, upload or public mutation occurred.
