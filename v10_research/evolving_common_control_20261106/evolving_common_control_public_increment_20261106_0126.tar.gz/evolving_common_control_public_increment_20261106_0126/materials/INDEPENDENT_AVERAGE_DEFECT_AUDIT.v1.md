# Independent exact-file audit: average defect v1

6 November 2026 UTC.

Reviewed candidate: `AVERAGE_DEFECT_TRANSFER.candidate.v1.md`.

SHA-256: `9875e5d53f872b4f54d3d9596deed79118c2fe7af5266953064376e280442ed8`.

**Verdict: REPAIR REQUIRED. The interpolation lemma and oriented pathwise transfer are sound under the intended completed contract; the standalone source-testing display lacks a necessary interior-source restriction.**

Required repairs:

1. Bind a repaired common-control theorem and explicitly require the same full-prefix inclusive softmax over all N+1 rows in both computations. The bound alpha_i<=exp(2 beta)/(N+1) uses precisely that contract.
2. State that actual and surrogate terminal states begin at the identical public value. Otherwise the recurrence has an omitted initial-error term. Make explicit that each b_s controls answer replacement over a domain containing both actual and surrogate answers, including any proof-side projection/continuation.
3. For delta=r+epsilon+Delta, the displayed testing inequality with its universal numerical constant needs both delta<=1/128 and 8 delta<=1-2c (with strictness if the definition of P_c requires it). The two witnesses p_theta=(1+theta ac)/2 must belong to P_c. The condition delta<=1/128 alone controls h<=1/16, not membership in an arbitrarily narrow interior class.

The third issue is substantive. For c close to 1/2 the constant predictor (1/2,1/2) has worst-source risk at most 1/2-c and admits an exact zero-message simulator. Taking this arbitrarily small risk as r would violate the displayed universal testing lower while meeting r<=1/128. The missing witness-membership condition prevents that invalid application.

The clean conclusion R(actual)>=max{0,a_c/sqrt(S)-Delta} is valid once the common-control lower has its properly c-dependent constant and the pathwise contract is explicit. It does not require a new universal testing constant for larger delta. The later repaired-version audit provides the detailed perturbation and transfer checks; it does not retroactively accept this exact v1 text.

No scientific experiment, execution of research code, upload, public write, or candidate edit was performed.
