# Bounded-value causal amplification can keep the closure defect nonvanishing

6 November 2026 UTC. Analytical candidate v1, independent review pending. This is a counterexample to an automatic SMALL-RESIDUAL inference, not a lower bound against every source-average simulator.

## 1. Attention program

Under the fair IID signed binary source, which belongs to every P_c with fixed 0<c<1/2, form causal prefix means m_i=S_i/i and terminal mean M_N=S_N/N as in the reviewed prefix witness. Let d=ceil(log_2 N), L_N=2^d and

    f_N(z)=clip(L_N z,-1,1).

Each row replaces its prefix register by f_N(m_i) through d repetitions of the bounded-gain local operation z <- clip(2z,-1,1). Each intermediate register remains in [-1,1]. The terminal preserves M_N in a register and can run the same operation for its self value. The zero-query, zero-key final terminal attention reads the transformed values, with transformed terminal self value f_N(M_N). All scores are zero and all values have norm at most one.

The canonical closed surrogate replaces each transformed prefix value f_N(m_i) by f_N(M_N). The static basis is constant; the only coefficient is f_N of the terminal's first-read mean. Local stages have gain at most 2, but the composed row sensitivity is L_N in [N,2N). The paid local depth is O(log N). This is an attention-program construction, not a proof of a full positive-epsilon normalized Transformer realization.

Since |S_i| is either zero or at least one and L_N>=N>=i,

    f_N(m_i)=sgn(S_i),   f_N(M_N)=sgn(S_N),

where sgn(0)=0. Map the final attention answer a in [-1,1] to the binary distribution ((1+a)/2,(1-a)/2) by a paid bounded affine map. The canonical surrogate uses answer b=sgn(S_N).

## 2. Exact expected discrepancy formula

Write a=(sum_{i=1}^N sgn(S_i)+sgn(S_N))/(N+1). When S_N is nonzero, all numbers sgn(S_i)-sgn(S_N) have the same weak sign. Therefore

    |a-b|=(1/(N+1))sum_{i=1}^N |sgn(S_i)-sgn(S_N)|.

When S_N=0 this equality may fail, but both sides lie in [0,2], so the error in their EXPECTATIONS is at most 2 P(S_N=0)=O(N^(-1/2)). The latter follows from the central binomial coefficient bound (and is zero for odd N). Thus

    E TV(Q_actual,Q_surrogate)
      = [1/(2(N+1))]sum_i E|sgn(S_i)-sgn(S_N)|+o(1).      (1)

For each fixed t in (0,1), set i=floor(Nt). The independent sums S_i and S_N-S_i, normalized by their own square-root lengths, converge to independent standard normals. This is the elementary Rademacher central limit theorem: characteristic functions cos(u/sqrt(n))^n converge to exp(-u^2/2). Consequently (S_i/sqrt(i),S_N/sqrt(N)) converges to a standard bivariate normal pair of correlation sqrt(t). The limiting Gaussian has no mass on either zero axis, so bounded sign disagreement expectations converge.

Rotational symmetry of two independent standard Gaussians gives probability of opposite signs equal to arccos(sqrt(t))/pi. Zero-sign events vanish. Hence

    E|sgn(S_floor(Nt))-sgn(S_N)| -> 2 arccos(sqrt(t))/pi.

Interpret the normalized sum as the integral of its step function on [0,1]; the single endpoint term is negligible. Dominated convergence applies because integrands lie in [0,2]. Since

    integral_0^1 arccos(sqrt(t)) dt = pi/4,

(1) converges to 1/4. Thus the source-average output discrepancy of this natural closed surrogate is bounded away from zero, despite uniformly bounded scores, row values and per-primitive gains and a strongly mixing IID source.

## 3. Correct interpretation

The condition Gamma^2 S/N ->0 in the Lipschitz-closure result is not implied by bounded values or scores. Here composed row sensitivity grows like N, so that condition fails; paid amplification destroys the earlier O(N^(-1/2)) unamplified residual guarantee. Depth O(log N) is enough for this example. Local per-primitive stability does not imply a fixed full-network stability budget.

This does NOT show that the actual program has no other accurate low-communication source-average simulator. It disproves only the assertion that replacing every causal prefix mean by the global mean always has vanishing output discrepancy under mixing and bounded ranges. It also is NOT a low-risk predictor: the source is fair IID and the program retains random sign-driven output; no useful second-order learning claim is made.

Analytical dependencies are the elementary Rademacher CLT, Gaussian rotational geometry, dominated convergence, the central binomial coefficient estimate, and the already-reviewed prefix attention program. No model run, Monte Carlo estimate or numeric validation was used; the value 1/4 is an exact asymptotic analytical limit.
