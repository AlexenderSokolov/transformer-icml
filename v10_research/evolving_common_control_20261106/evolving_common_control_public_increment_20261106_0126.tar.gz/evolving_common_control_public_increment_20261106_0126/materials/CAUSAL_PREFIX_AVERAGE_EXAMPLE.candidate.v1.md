# A nonzero all-row update with a source-average closure defect

6 November 2026 UTC. Conditional attention-program example, not a complete positive-epsilon normalized Transformer compiler or a good order-two predictor. Exact-file review pending.

Use signed raw tokens X_i in {-1,1}. A first zero-score causal attention layer produces m_i=i^(-1)sum_{t<=i}X_t at each nonterminal row, so the bank has genuine prefix-dependent evolving values. At the synthetic terminal, raw self value zero gives (N/(N+1)) M_N, M_N=N^(-1)sum_i X_i. A bounded paid rescaling by (N+1)/N<=2 recovers terminal control y=M_N. This rescaling is a program operation; no uncharged neural compilation is asserted.

A second full-prefix zero-score terminal read has nonterminal values m_i and terminal self value y. Its answer is (sum_i m_i+y)/(N+1). The surrogate instead gives every nonterminal row value y, with the same self y. This is a closed common-control bank: static value basis 1, coefficient B(y)=y, and key zero. Both stages can reuse the finite family of static bases X_i and 1. The first read and its control match exactly; only the second bank differs. Any shared bounded Lipschitz continuation with answer-to-output gain L gives a TV defect bound

    B(X)<=L/(N+1) sum_i |m_i-M_N|.

There is no attention-key perturbation and beta=0. A worst-history bound need not tend to zero (for example a string consisting of a long +1 block followed by a long -1 block).

For a stationary source with mean mu and a uniform covariance-sum certificate

    Var(sum_{t=1}^i X_t)<=K i for all i,

Cauchy-Schwarz gives E|m_i-M_N|<=sqrt(K/i)+sqrt(K/N). Since sum_{i=1}^N i^(-1/2)<=2sqrt(N),

    Delta<=3L sqrt(K/N).

The simulator never knows or uses mu; it computes y from the first read. mu appears only in the analysis of the residual.

For the stationary interior binary order-two class P_c, a K depending only on c exists directly: the pair chain has four states, and every two-step transition to any target pair has probability >=c^2. Hence its two-step transition dominates weight alpha=4c^2 times the uniform law. Coupling (or iteration of the minorization) gives pair-chain TV contraction at most (1-alpha)^floor(h/2). For bounded spins, |Cov(X_t,X_{t+h})|<=2(1-alpha)^floor(h/2) is a loose valid bound. Therefore

    K=1+4 sum_{h>=1}(1-alpha)^floor(h/2)<infinity

is sufficient after expanding the variance of the partial sum. No independent-sample assumption is used; stationary mean is constant. Constants deteriorate as c decreases, as expected.

Thus an actual all-row causal prefix-mean update can fail exact token locality yet satisfy the source-average closure certificate at O(N^(-1/2)). This demonstrates a nonempty scope of the residual theorem beyond exact common broadcast. It does not show that this network estimates all four transition rows, improves the main depth-risk frontier, or supplies a complete standard PreLN/PostLN realization. It is a checkable attention-program witness and an analytical certificate, not trained-model evidence.
