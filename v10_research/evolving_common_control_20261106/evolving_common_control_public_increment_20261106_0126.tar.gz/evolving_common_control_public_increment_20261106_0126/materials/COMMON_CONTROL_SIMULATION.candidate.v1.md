# Evolving memory with closed common control: a one-way simulation certificate

6 November 2026 UTC. Analytical candidate v1. No training, numerical experiment, public upload, or claim of an unrestricted causal-transformer theorem. Exact-file independent review pending.

## 1. Increment over the existing results

The token-local theorem forbids dependence of nonterminal K/V on previous terminal answers. The anchored separable extension permits common coefficients depending on a fixed raw anchor tuple, sent to the decoder. Here the coefficients may depend continuously on the ENTIRE previous read transcript, and thus need not be known to either party before communication. The one-way message nevertheless remains independent of that transcript. The new assumption is a closed, reconstructible control state, not merely low dimensionality of hidden vectors.

All conclusions are representation/resource necessities for source-independent predictors on the same observed history. They do not analyze fitting, gradient descent, independently trained parameters, or source-specific weights.

## 2. Checkable structural contract

There are N raw binary tokens and a synthetic terminal. A public computation has D paid stages and H<=D reads. Its dynamic control/terminal state y starts at a public value. Every data-carrying terminal input is either the result of these reads or a public function of current y. There is no uncommunicated initial aggregate or side channel. Each stage updates y from y and its own attention answer by a public map. Parameters may depend on N but not the unknown transition kernel.

There are J distinct static lifted banks. Bank j has public token-local maps

    K_{j,i}(X_i) in R^p,  V_{j,i}(X_i) in R^v,
    ||K_{j,i}||<=R, ||V_{j,i}||<=V.

A read s using j=j(s) has a common-control factorization

    k_{s,i}(y)=A_s(y) K_{j,i}(X_i),
    v_{s,i}(y)=B_s(y) V_{j,i}(X_i),   i<=N.

The matrices may change at every stage and depend on all earlier answers. Their operator norms are uniformly bounded by A_*,B_* on a declared projected state domain. The original query obeys ||q_s(y)||<=Q. Terminal self K/V are arbitrary bounded public functions of y and handled separately. Biases are permitted by adding a fixed 1 coordinate to the relevant lifted bank, with its norm charged. An affine key bias common only to nonterminal rows must NOT be canceled against the terminal self score: the lifted representation handles it correctly.

The full exact extended stage map F_s^X on y has a public history-uniform Lipschitz bound a_s on this domain, including dependence of A_s,B_s,q_s and self K/V on y. Replacing an attention answer at a fixed y by an error delta changes that stage's output by at most b_s delta. All data-carrying state coordinates must be included. Proof-side projections may enforce domains provided they fix exact trajectories. Set

    W=sum_{s read} b_s product_{l>s} a_l,
    U=2+log(1+W), F_p(t)=t[t/log(e+t)]^p.

The required certificate is a dataflow/factorization certificate for ALL raw histories and simulated states, not rank measured on one realized matrix. All network work computing rows and controls remains charged. Actual attention masks/availability must be verified separately; this theorem neither permits backward broadcasts in a causal architecture nor adds a global controller as a free network primitive.

## 3. Worst-history one-way theorem

For fixed p,v,R,V,A_*,B_*,Q and bounded original self K/V, there is a deterministic source-independent one-way simulator, for 0<epsilon<=1, with

    C <= min{N, K J(v+1) F_p(U+log(1/epsilon))},             (1)

and worst-history output TV error <=epsilon for normalized binary outputs. K depends only on the displayed fixed dimensions/norm budgets, not D,H,J,W,N or the unknown source. The supplied a_s,b_s appear through W. If H=0 or W=0, zero communication suffices. Formula (1) is only asserted with J>=1 in the nonzero case.

Proof. Alice sends one quantized averaged factorial-feature moment per static bank,

    Z_j=(1/(N+1)) sum_{i owned by Alice} phi_m(K_{j,i}) tensor (V_{j,i},1).

Its radius is exp(R^2/2)sqrt(V^2+1), independent of N,m. The feature dimension is (v+1) binom(m+p,p). At a simulated state y, Bob forms the adaptive lifted query

    u_s(y)=A_s(y)^T q_s(y),   ||u_s(y)||<=A_*Q,

and contracts the static moments with phi_m(u_s). This approximates the lifted nonterminal numerator and scalar denominator uniformly over EVERY permitted y; no distributional independence, union bound, or advance knowledge of y is needed. Bob transforms the approximate lifted numerator by B_s(y), and adds the exact original self numerator/denominator, each divided by N+1.

For beta=max(A_*QR, sup |q dot k_self|), the exact averaged denominator is >=exp(-beta). If augmented lifted approximation error is e, the transformed augmented error is <=max(1,B_*)e. The exact value average norm is bounded by max(B_*V,V_self). Hence the same ratio identity as the accepted local theorem gives answer error <=K_0 e once e is small enough to preserve half the denominator floor. Project approximate answers to the declared value ball.

The uniform error before transformation is at most

    sqrt(V^2+1) exp(A_*QR) (A_*QR)^(m+1)/(m+1)!
       + exp((A_*Q)^2/2) eta.

For delta=epsilon/(1+W), take e<=c delta. The accepted factorial lemma gives m+1=O(t/log(e+t)), eta=c' delta, t=U+log(1/epsilon). Net indices require O((v+1)F_p(t)) bits per bank. Their one-way preparation uses only X_i and static bank maps, even though the ORIGINAL K/V depend on previous answers. Bob reconstructs coefficients at his own simulated state, not at an unavailable exact state.

Compare the simulated stage at simulated y with the exact F_s^X at that same y, then with F_s^X at exact y. This gives e_s<=a_s e_{s-1}+b_s delta for reads and e_s<=a_s e_{s-1} otherwise. Thus final state error <=W delta<=epsilon. Projection to the binary simplex fixes the exact output, is nonexpansive, and TV is bounded by Euclidean error. Sending Alice's raw bits instead gives the N cap. All protocol local computation is unrestricted exact-real computation, not a floating-point implementation claim.

## 4. Unknown second-order source consequence

For N>=3 and stationary interior binary order-two class P_c, c in (0,1/2), import the independently reviewed AA/BB one-way source-average testing inequality. Set

    z=2+log(1+W)+log(J+1),
    S=min{(J+1)F_p(z),N}.

Then uniformly over this certified predictor subclass,

    sup_{P in P_c} E_P TV(Q_N,P(.|X_{N-1},X_N)) >= a_c/sqrt(S).  (2)

The constant includes fixed lifted dimensions and norm budgets. For W=0 use the zero-message constant-risk result. Proof is exactly the accepted stability-budget inversion with k replaced by p: advertise r=a/sqrt(S), use epsilon=r, and apply (2r)^2 min(C+1,N)>=1/(16384 ln 2). On S<N, log S<=O_p(z) and F_p(U+log(1/r))<=O_p((1+log(1/a))^(p+1)F_p(z)); one fixed sufficiently small a contradicts the testing bound. The S=N branch follows directly from 4a^2. No actual unknown risk is inserted into a simulation resource hypothesis.

This is a worst-history simulator implying a SOURCE-AVERAGE statistical lower. The statistical task is not worst-history prediction and the proof does not replace the stationary interior source class by arbitrary strings. For general bounded stage gains W<=bHA^D, (2) gives the previous factorial depth expression with lifted dimension p. Stable dynamics can give a smaller W. Repeated updates do not automatically yield smaller risk.

## 5. Concrete inclusion and concrete failure of the certificate

Inclusion at the computation level: choose static scalar keys x_i and values (x_i,1), bounded y in [-1,1], A_s(y)=y, and B_s(y)=(y,1-y). Then k_i=y x_i and v_i=y x_i+1-y truly vary with earlier reads whenever y does. A public Lipschitz clipped update of y from each answer gives the required closed control and finite gains. This is an abstract common-control attention program, not a newly constructed standard causal transformer. Realizing its broadcast/multiplication with the allowed raw-token primitives is a separate obligation.

Failure: even zero-score causal self-attention with values x_i has row-i output m_i=(1/i)sum_{t<=i}x_t. With k_i or v_i set to m_i, distinct rows carry different prefix summaries. It does not follow that a fixed-dimensional reconstructible COMMON state can generate these rows from x_i. Indeed for a fixed y independent of those raw prefixes, positions with identical own token can have different m_i under histories agreeing on x_i. This refutes token locality and the naive 'uniform attention means a single common summary' argument. It does NOT prove that no alternative clever finite certificate exists, nor a source-average lower for this network.

## 6. Scope and closest precedents

This is a closure extension of the local anchored finite-separable lift, not a new polynomial attention feature method. Fixed-anchor coefficients become feedback coefficients because the decoder can reconstruct the closed state. A missing raw-input side channel invalidates that step.

Closest sources already checked in CURRENT_FRONTIER_PRIMARY_COMPARISON.v2.md:
- Alman–Song, polynomial kernel factorization and bounded attention: https://arxiv.org/html/2302.13214v1 .
- Chen et al., deterministic Taylor moment summaries and streaming attention: https://arxiv.org/html/2606.07205v1 .
- Akman et al., repeated static-bank gatherers: https://arxiv.org/html/2610.41038v1 .
- Rajaraman et al., Markov representation in constant depth: https://arxiv.org/html/2407.17686v1 .
- Ekbote et al., two-layer Markov representation with separate reduced training result: https://arxiv.org/pdf/2508.07208v2 .
These are inherited primary-source comparisons, not a fresh literature-priority certification. The first two supply existing approximation ingredients. The latter representation constructions do not verify this closed-control factorization with frozen constants; absence from the checked local comparison is not a universal impossibility claim.

Still open: prove a small fixed-lift closed-state certificate for general evolving full-row CAUSAL self-attention, or replace it by a direct source-average argument; build a nontrivial strictly compliant causal implementation improving statistical rates; prove sharpness; analyze training. No unconditional multiple-attention main frontier has been established here.
