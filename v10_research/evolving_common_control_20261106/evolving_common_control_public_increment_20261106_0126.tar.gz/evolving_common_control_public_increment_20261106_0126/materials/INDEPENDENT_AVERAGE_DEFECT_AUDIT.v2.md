# Independent exact-file audit: average defect v2

6 November 2026 UTC.

Reviewed candidate: `AVERAGE_DEFECT_TRANSFER.candidate.v2.md`.

SHA-256: `2fd1d03341bc06cee5c4c5ba4bcd524a08cab56c133c76a52d06db7aa1bdb511`.

**Verdict: REPAIR REQUIRED. The mask/reference repair is accepted; the interior testing-range error from v1 remains.**

This exact revision explicitly imposes full-prefix inclusive softmax on both actual and surrogate reads and binds common-control v2. Those changes correctly repair the T=N+1 averaging and attention-weight bound. Common-control v2 has its own conditional PASS audit.

The source-testing display still asserts the universal numerical lower whenever 0<r+epsilon+Delta<=1/128, although it restricts sources to P_c. It must additionally require 8(r+epsilon+Delta)<=1-2c so that the lag-two testing alternatives lie in P_c. See the v1 audit for a constant-predictor counterexample to the current unqualified statement.

The common public initial control state and the answer-domain coverage of b_s should also be made explicit, as requested in the v1 audit. These repairs preserve the pathwise bound, communication expression and clean c-dependent risk-transfer result.

The candidate was not edited. This review involved local text/diff/hash reads and analytical reasoning only, without scientific execution, upload or public write.
