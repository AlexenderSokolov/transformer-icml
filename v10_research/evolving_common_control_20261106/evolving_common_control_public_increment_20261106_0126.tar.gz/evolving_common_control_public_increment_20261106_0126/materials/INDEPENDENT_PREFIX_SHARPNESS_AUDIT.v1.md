# Independent exact-file audit: prefix defect sharpness v1

6 November 2026 UTC.

Candidate: `PREFIX_DEFECT_SHARPNESS.candidate.v1.md`.

SHA-256: `2f7fed96f5f6717f73e055d505661a8c897ed0144e9568796272b178807f355e`.

**Verdict: PASS. For the stated unamplified program and canonical surrogate under fair IID signs, sqrt(N) times expected TV discrepancy converges to 1/sqrt(2pi).**

This is an exact residual-scale statement for that pair, not an optimal architecture-risk or communication lower. No experiment or candidate edit occurred.

## 1. Weights and variance identity

The answer difference is

    a-b=[sum_i m_i-NM_N]/(N+1).

Each X_j appears in the prefix-mean sum with coefficient a_j=sum_(i=j)^N 1/i=H_N-H_(j-1); subtracting NM_N removes one. Thus the displayed w_(N,j)=a_j-1 is exact.

Reversing summations gives sum_j a_j=N. For the squared sum, the number of j lying below both i and k is min(i,k), so

    sum_j a_j²=sum_(i,k) min(i,k)/(ik)
                =H_N+2sum_(k=1)^N(k-1)/k
                =2N-H_N.

Therefore sum_j w_(N,j)²=(2N-H_N)-2N+N=N-H_N. Independence and zero means of the fair signs give the claimed exact variance (N-H_N)/(N+1)². The degenerate N=1 case is irrelevant to the asymptotic statement; for N≥2 the normalizing variance is positive.

## 2. Triangular weighted CLT

The largest absolute weight is O(log N), while sigma_N²=N-H_N is asymptotic to N. Hence max_j|w_(N,j)|/sigma_N→0. For each fixed characteristic-function argument u, all individual arguments u w_(N,j)/sigma_N are eventually in a fixed neighborhood of zero where the real logarithm of cos is well defined and has the stated uniform expansion.

The quadratic terms sum to -u²/2. The absolute total fourth-order remainder is bounded by a constant depending on u times

    sum_j w_(N,j)^4/sigma_N^4
      <=max_j w_(N,j)^2/sigma_N²→0.

Thus the normalized weighted sign sum converges to a standard Gaussian. The prefactor sqrt(N)sigma_N/(N+1) tends to one, proving sqrt(N)(a-b) converges to the same Gaussian. No relation between different triangular-array rows is required for convergence in distribution; within each row the raw signs are independent.

## 3. Expected absolute value and TV factor

The second moment of Y_N=sqrt(N)(a-b) is N(N-H_N)/(N+1)²≤1. This supplies uniform integrability of |Y_N|, for example through E[|Y_N|1_(|Y_N|>M)]≤E[Y_N²]/M. Consequently convergence in distribution upgrades to E|Y_N|→sqrt(2/pi).

The map Q(t)=((1+t)/2,(1-t)/2) yields TV(Q(a),Q(b))=|a-b|/2 exactly. The candidate's constant is therefore (1/2)sqrt(2/pi)=1/sqrt(2pi), with no missing factor of two.

## 4. Meaning of the sharpness claim

Because the limit is strictly positive, the source-average discrepancy for this particular canonical replacement is Theta(N^(-1/2)) even on a maximally mixing fair IID source. Thus mixing alone cannot upgrade the earlier O(N^(-1/2)) bound to little-o for all such examples with the fixed specified affine output.

For any comparison resource scale S=o(N), this discrepancy is o(1/sqrt(S)); for S comparable to N, its ratio to that scale stays nonzero. This is a comparison of scales, not a claim that the fixed two-read program's own minimal W or S grows like N. Its natural fixed-resource certificate has bounded S, consistently with the earlier negligible-defect result.

The result does not exclude another better surrogate or simulator. Nor does it establish optimal statistical risk, optimal communication, a useful order-two estimator, training behavior or a full normalized Transformer realization. Those limitations are accurately stated in the candidate.

## 5. Evidence and actions

Read the exact candidate and the accepted prefix/transfer context. The summation identity, characteristic-function limit and uniform-integrability step were checked analytically. No numeric integration, random sampling, model execution, scientific experiment, upload, public mutation or candidate modification occurred.
