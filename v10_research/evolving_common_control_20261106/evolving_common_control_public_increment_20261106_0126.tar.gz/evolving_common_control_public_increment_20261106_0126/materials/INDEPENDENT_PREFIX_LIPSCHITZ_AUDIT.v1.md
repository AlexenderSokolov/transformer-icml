# Independent exact-file audit: prefix Lipschitz closure v1

6 November 2026 UTC.

Candidate: `CAUSAL_PREFIX_LIPSCHITZ_CLOSURE.candidate.v1.md`.

SHA-256: `d6c70c6482c9df805748602e4de31bbe249041306907b3a93ccf43c92d3336dc`.

**Verdict: CORE DERIVATION ACCEPTED; repair the stated nonexpansive regime before treating the entire standalone text as final.**

The position-identical binary onehot factorization, finite p=v=2 and J=1, mean row-defect bound, Gamma weighting, fixed-c negligible-defect condition Gamma²S/N→0, permutation-invariance argument and limited architecture scope are correct under the inherited common-control/average-defect certificates.

The fourth section requires every paid stage, including nonread stages, to have a_s≤1, although the stated first-read mean recovery uses a separate paid scaling by (N+1)/N>1. That restriction cannot be asserted of this startup primitive. A fixed number of uniformly bounded startup gains, followed by nonexpansive stages, preserves Gamma=O(H) and W=O(1+H). This is a regime clarification; the general W/Gamma formulas remain valid without it.

Also specify a shared first-and-later-read value radius at least max(1,V_0), because the first raw signed values have norm one even when the later bound V_0 is smaller. Clarify that the Gamma sum is over read stages after the first read, not all later stages. These fixed-budget changes do not alter the main asymptotic result.

The retained F_2 communication/risk expression is a valid conservative application of the general companion. Binary position-identical maps additionally permit a direct scalar count summary without Taylor features, but that stronger observation is not needed to accept the displayed bound and must be separately written and reviewed if claimed.

No candidate edit, scientific experiment, model execution, upload or public mutation occurred.
