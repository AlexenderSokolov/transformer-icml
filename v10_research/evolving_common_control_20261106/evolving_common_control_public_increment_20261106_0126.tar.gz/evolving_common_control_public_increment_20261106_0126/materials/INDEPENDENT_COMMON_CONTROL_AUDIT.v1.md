# Independent exact-file audit: common control v1

6 November 2026 UTC.

Reviewed candidate: `COMMON_CONTROL_SIMULATION.candidate.v1.md`.

SHA-256: `adb0c2cc7fd56e714c5080ce989f5d503a24717c6cf27e976a2120a4f8a3b6cd`.

**Verdict: REPAIR REQUIRED for the literal standalone statement. The feedback-dependent lifting argument and stability/risk calculations are sound once the following two omissions are repaired.**

1. The structural contract must explicitly require full-prefix inclusive softmax over all N raw rows and the synthetic self row, with score q dot k and no extra unrepresented pairwise positional term. The inherited local-memory theorem states this restriction; v1 does not explicitly inherit it. The displayed uniform denominator floor uses all N+1 terms divided by N+1. Arbitrary masks can invalidate that floor and can also make one static aggregate insufficient when different subsets are selected. The sentence requiring masks to be verified separately is not a replacement for specifying the theorem's permitted mask.
2. After Alice sends her partial moments, Bob must compute and add his own exact token-local partial moments, with the same 1/(N+1) normalization. The v1 proof mentions only contracting Alice's static moments and adding the self contribution. Omitting Bob's rows does not approximate the stated full-prefix read. This is an easy protocol repair, not a need for interaction or extra communication.

The public ownership split should also be stated, with AA/BB used for the statistical consequence. No change of the resource expressions is needed after these repairs.

The main positive finding is that feedback-dependent A_s(y), B_s(y) do not require Alice to learn the feedback. Alice's sketches depend only on the fixed local lifted banks. Their simultaneous bounded-query guarantee is evaluated by Bob at his own simulated state. Exact-map, same-state error comparison then yields the stated W recurrence. Self terms and common affine biases must be handled exactly as in the candidate, without canceling a bias against a self score that does not share it.

The source-risk inversion has the correct separate finite-N branch and log(J+1) term. Its c-dependent constant must be small enough that the imported lag-two witnesses remain inside P_c. The exact proof details and scope comparison are recorded in the subsequent exact-version audit of the repaired candidate; that later verdict does not retroactively accept this v1 text.

This was an analytical local-file review. No scientific experiment, execution of research code, upload, public write, or candidate edit was performed.
