# Independent exact-file audit: two-type count simulation v1

6 November 2026 UTC.

Candidate: `TWO_TYPE_COUNT_SIMULATION.candidate.v1.md`.

SHA-256: `b1a595e6018d8bd45a5d99e7d792c22686bff6f45b02fd88d5ccb2bd7b177979`.

**Verdict: PASS, conditional on exactly two position-homogeneous single-symbol types, closed public control and the inherited uniform attention/stability contract.**

This is a specialized count-summary refinement, not an improvement to the unrestricted common-control theorem or a claim of optimality. The candidate was not edited.

## 1. Message and positivity

The ownership split fixes Alice's number n_A of raw positions publicly. Her positive count divided by T=N+1 lies in [0,n_A/T]. A public grid with spacing at most eta, including or clipped to the endpoints, has O(1+1/eta) centers and can approximate this scalar within eta. Sending its index needs O(1+log(1/eta)) bits.

Bob's own positive count is known exactly. Adding it to Alice's decoded mass produces a total positive mass between zero and N/T. Defining the negative mass by subtraction from N/T preserves both nonnegativity and their exact total. Their errors are opposite scalars of magnitude at most eta. Alice's message is independent of all queries, feedback and the source; no interaction or transcript-dependent message is introduced.

## 2. Uniform read approximation

At fixed simulated y, let h_+(y) and h_-(y) denote the two augmented vectors exp(q dot kappa)(nu,1). Their norms are at most exp(beta)sqrt(V_0²+1). The count perturbation changes the combined nonterminal contribution by

    (uhat-u)[h_+(y)-h_-(y)],

whose norm is at most 2eta exp(beta)sqrt(V_0²+1). This estimate holds simultaneously over every permitted state, even if type values and queries change with the complete simulated transcript. The static count remains sufficient across every read and every nonlinear type map.

Bob adds the original self term exactly at the simulated state. The true averaged denominator is at least exp(-beta). In fact the reconstructed nonnegative type masses together with the self mass 1/T also sum to one, so their denominator has the same floor; the inherited small-error ratio argument is already sufficient. The resulting answer error is at most a fixed multiple of eta. Projecting to the declared value ball and using the accepted exact-map recurrence gives final error at most W times this local error.

Choose eta=c epsilon/(1+W) with fixed c small enough. The index cost is then at most K[2+log(1+W)+log(1/epsilon)]. Raw Alice-bit transmission supplies the alternative N cap. When W=0, the inherited zero-message argument applies exactly. Source independence, off-trajectory gains, normalized output and exact-real local computation are preserved.

No Taylor degree or p-dependent feature count is needed: all rows belong to two known types, so their sums are evaluated directly. This is why F_0 rather than F_2 suffices here, without altering the general common-control theorem.

## 3. Risk inversion and residual

Put U=2+log(1+W) and S_0=min(U,N). For fixed small a, advertise r=a/sqrt(S_0) and epsilon=r. Shrink a to meet both the testing small-error range and the interior witness condition for P_c.

If S_0=N, the testing left side is at most 4a². If S_0=U<N, then

    U+log(1/r)=U+log(1/a)+(1/2)log U
                <=K'[1+log(1/a)]U.

The reserved bit is absorbed because U≥2. Thus the testing left side is at most a fixed multiple of a²[1+log(1/a)], which tends to zero as a decreases. This proves the stated c-dependent lower uniformly in W and N. It is an advertised-envelope contradiction, not insertion of unknown risk into the structural assumptions.

Combining with the already accepted prefix residual gives inequality (2). For fixed c and fixed norm budgets, Gamma²S_0=o(N) makes the residual smaller than half the lower eventually. The nonexpansive and exponential-gain conditions follow from the previously reviewed bounds on W and Gamma, with the fixed startup's individual gains included.

## 4. Scope

The method depends on homogeneous maps of the single owned raw symbol. N different position-dependent types generally cannot be simulated by this one count; no claim is made for them. Local pairs and triples can cross the AA/BB ownership split and cannot be treated as free owned symbols.

The count-based communication upper and resulting source-risk lower need not be sharp. Neither statistical optimality nor a useful trained estimator follows. Finite-alphabet count compression is elementary; the result is a local refinement of the restricted source-independent simulation route.

## 5. Evidence and actions

Read the exact candidate and accepted common-control, average-defect and prefix-Lipschitz dependencies. This was paper verification of the grid, perturbation, recurrence and inversion. No scientific program, numerical experiment, model run, upload, public mutation or candidate edit occurred.
