from pathlib import Path
from html.parser import HTMLParser
import json,hashlib
D=Path(__file__).parent
class Check(HTMLParser):
 def __init__(self):
  super().__init__(); self.ids=[]; self.hrefs=[];self.active=[];self.tags={};self.external=[];self.stack=[];self.errors=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs);self.tags[tag]=self.tags.get(tag,0)+1
  if 'id' in a:self.ids.append(a['id'])
  if 'href' in a:self.hrefs.append(a['href'])
  if tag in ('script','iframe','form','object','embed'):self.active.append(tag)
  if 'src' in a:self.external.append(a['src'])
  for key in a:
   if key.startswith('on'):self.active.append(key)
  if tag not in ('meta','br','hr','img','input','link','wbr'):
   self.stack.append(tag)
 def handle_endtag(self,tag):
  if not self.stack or self.stack[-1]!=tag:self.errors.append('misnested '+tag)
  else:self.stack.pop()
p=D/'RESEARCH_REPORT.zh.v3.html'; c=Check();c.feed(p.read_text())
bind=json.loads((D/'REPORT_SOURCE_BINDINGS.v3.json').read_text())
r={'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'utf8_valid':True,'duplicate_ids':len(c.ids)!=len(set(c.ids)),'broken_fragment_links':[x for x in c.hrefs if x.startswith('#') and x[1:] not in c.ids],'active_elements':c.active,'external_embeds':c.external,'nesting_errors':c.errors,'unclosed_tags':c.stack,'source_hashes_match':all(hashlib.sha256((D/k).read_bytes()).hexdigest()==v for k,v in bind.items()),'h2_count':c.tags.get('h2'),'appendix_count':c.tags.get('details'),'visual_render':'Not completed: Chromium sandbox socket/ptrace restriction, see preserved failure log.','scientific_execution':False}
assert not any([r['duplicate_ids'],r['broken_fragment_links'],r['active_elements'],r['external_embeds'],r['nesting_errors'],r['unclosed_tags']])
assert r['source_hashes_match']
(D/'REPORT_HTML_QA.v3.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(r,ensure_ascii=False,indent=2))
