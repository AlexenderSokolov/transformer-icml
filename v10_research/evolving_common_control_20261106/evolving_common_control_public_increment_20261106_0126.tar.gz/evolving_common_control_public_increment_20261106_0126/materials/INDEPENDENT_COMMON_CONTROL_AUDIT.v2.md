# Independent exact-file audit: closed common control v2

6 November 2026 UTC.

Reviewed candidate: `COMMON_CONTROL_SIMULATION.candidate.v2.md`.

SHA-256: `fd8024b004920fceaa91147cffed4216bbb13e29aba26d3ba9d54deb882c9c15`.

**Verdict: PASS, conditional on the complete stated structural and uniform off-trajectory certificates, and on the imported reviewed source-average testing theorem. The two v1 omissions are explicitly repaired. No further mathematical correction is required.**

This is an independent analytical audit, not formal verification, an empirical validation, external peer review, or a literature-priority certification. The candidate was not edited.

## 1. One-way legitimacy under feedback

For fixed public architecture parameters, N and ownership split, Alice's message is a function only of her owned raw symbols and the token-local lifted maps. In particular it contains neither exact feedback coefficients nor a response to Bob's observations. Bob adds his own exact local moments before performing any read. Both partial sums use T=N+1 as their denominator, so their sum represents every nonterminal row.

At any simulated control state y, the equality q_s(y) dot A_s(y)K_i = [A_s(y)^T q_s(y)] dot K_i is exact. The lifted query norm is at most A_*Q. The feature approximation is simultaneous over that entire norm ball, rather than conditioned on one realized query. Bob can therefore choose queries and coefficients using all earlier simulated answers, without a union bound, independence hypothesis, or Bob-to-Alice message. Comparing with the exact stage at this same simulated y is essential. Comparing directly with coefficients at an unavailable exact state would not prove the claim.

The public initial state, closed updates and prohibition of other data channels ensure that Bob can execute every remaining operation. A low-dimensional hidden vector by itself does not provide this property. All data-bearing state coordinates must be included in the metric, and the factorization and gain bounds must hold off the exact trajectory on the declared simulator domain.

## 2. Augmented approximation, denominator and self term

Let T=N+1 and L=max(1,B_*). The exact augmented nonterminal average before applying B_s has Taylor-plus-net error at most

    e <= sqrt(V^2+1) exp(A_*QR) (A_*QR)^(m+1)/(m+1)!
         + exp((A_*Q)^2/2) eta.

The radius of Alice's moment is bounded by exp(R^2/2)sqrt(V^2+1), independently of T and degree. Bob's exact partial moment adds no quantization error. Multiplying the lifted numerator by B_s(y), while leaving the denominator coordinate unchanged, increases the joint error by at most L. Bob then adds the original self numerator and denominator, each divided by T. That term has zero approximation error at the fixed state being compared.

The repaired full-prefix inclusive contract supplies T scores, each at least -beta, so the true averaged denominator b is at least exp(-beta). Set Vbar=max(B_*V,V_self), so the exact answer a/b has norm at most Vbar. If Le<=exp(-beta)/2, then bhat>=exp(-beta)/2 and the ratio identity gives

    ||ahat/bhat-a/b|| <= 2 exp(beta) (1+Vbar) L e.

Thus a fixed choice e<=c delta preserves the denominator and gives answer error at most delta. Approximate weights need not be positive. Projection into the declared value ball fixes exact answers and cannot increase their error.

The key-bias warning is correct. A bias shared only by nonterminal scores cannot be canceled against the synthetic self score. A fixed coordinate in the lifted bank preserves the exact relative normalization, provided its norm and coefficient budget are charged. Arbitrary unrepresented positional scores or masks are outside this proof.

## 3. Precision, message length and W

Write t=2+log(1+W)+log(1/epsilon)>=2 and delta=epsilon/(1+W). Then log(1/delta)=t-2. The reviewed factorial degree estimate gives m+1=O(t/log(e+t)); the zero effective score endpoint permits degree zero. The full Euclidean feature-ball net has index length

    O((v+1) binom(m+p,p) log(1/eta))
      <= K(v+1) t[t/log(e+t)]^p

for eta a fixed multiple of delta. Its radius is degree independent, so no hidden log(m) precision loss is introduced. All fixed-dimension and norm constants may enter K, while J,D,H,W,N do not.

The same bank index can be reused at every bounded adaptive query into that bank. Multiplying by J and choosing raw Alice-bit transmission if cheaper gives the stated minimum with N. The cost is a mathematical exact-real communication bound, not a finite-word implementation bound.

For a fixed raw history, split each stage comparison through the exact map evaluated at the simulated input. The local discrepancy is at most b_s delta at a read and zero otherwise; the state discrepancy is at most a_s times the previous error. Starting at the shared public state yields

    e_D <= delta sum_(s read) b_s product_(l>s) a_l = delta W.

This argument uses exact-stage Lipschitz constants, not Lipschitz continuity of the quantized simulator. It permits zero gains without division. If W=0, replace all reads by any fixed bounded answers. Every finite local discrepancy has zero propagated coefficient, giving an exact zero-message final output. If H=0, the computation is public. Final Euclidean simplex projection fixes exact probability outputs and gives the claimed binary TV bound.

## 4. Source-average inversion

The worst-history simulator is source independent, so its guarantee holds in expectation under every tested stationary source. For

    z=2+log(1+W)+log(J+1),
    S=min{(J+1)F_p(z),N},
    r=a/sqrt(S),

take one constant a small enough that 2r<=1/128 and h=16r is a permitted stationary lag-two witness in P_c. This is possible uniformly because S>=1. The interior restriction belongs in the c-dependent constant, as the candidate intends.

When S=N, the imported testing left side is at most 4a^2, irrespective of the sketch cost. Otherwise log S<=log(J+1)+(p+1)log z<=C_p z. Hence the precision argument is bounded by C_p[1+log(1/a)]z. If that argument is below z, use monotonicity of F_p. If above z, use

    F_p(t)/F_p(z)
      =(t/z)^(p+1)[log(e+z)/log(e+t)]^p
      <=(t/z)^(p+1).

Consequently C+1<=K[1+log(1/a)]^(p+1)S. The testing left side is at most a fixed multiple of a^2[1+log(1/a)]^(p+1), tending to zero with a. A fixed sufficiently small a contradicts the testing inequality in both branches. The inversion keeps variable J and W explicit and never substitutes an unknown realized risk into the simulator's structural hypotheses.

## 5. Relation to the two earlier local results

Relative to the anchored finite-separable note, the algebraic lift and its bounded-query moment method are reused. The additional observation is closure: Bob can compute feedback coefficients from the simulated transcript even though neither party knew them before communication. No raw anchor tuple must be communicated when the public-initialization and read-only data-entry conditions hold.

This should not be read as a literal superset of every anchored model. The anchored theorem permits coefficients depending on designated raw anchors after paying Alice's anchor-bit cost. The present theorem requires a public initial control state and only the declared reads as data channels. An anchored model with a free raw-data initialization is not covered until that initialization is charged or produced through permitted reads. Conversely, genuinely transcript-dependent common control can fall outside dependence on a small fixed anchor tuple.

Relative to the stability-budget note, the W recurrence and F_p inversion are the same argument, now applied after the static lifted-bank reduction. The increment is a conditional structural extension, not a new feature method or stronger universal statistical testing theorem.

The scalar inclusion example is valid as an abstract attention computation. It does not implement backward causal broadcasts or multiplication in the frozen neural primitive set. The causal-prefix example correctly exposes the insufficiency of token locality: at a fixed position i, two histories can agree on X_i but have different prefix mean. Position-dependent local maps do not remove that discrepancy. The example does not rule out every possible alternative common-control certificate, which the candidate expressly acknowledges.

No certificate for arbitrary evolving full-row causal self-attention, matching constructive rate, sharpness result, training result, or unrestricted v10 main theorem follows. The local result is useful as a sufficient target whose dimensions, complete-bank count, norm bounds and stability gains must be independently proved for a proposed architecture.

## 6. Evidence boundary and actions

Read the exact common-control v1 and v2 texts; the anchored extension v1; stability-budget v1 and its independent audit; local-memory adaptive v3; source-average simulation v2; and the factorial-refinement independent audit. The one-way source-testing theorem, including its entropy-tensorization dependency, remains imported as previously reviewed, not freshly certified from external primary literature.

The cited literature URLs and priority comparisons were not independently refreshed. This audit verifies the local analytical derivation and scope, not the novelty of Taylor features, net arguments, separable lifting or perturbation recurrences.

Actions were local text reads, listing, diff and SHA-256 inspection, paper reasoning and writing audit files. No scientific experiment, training, simulation, upload, public write, or candidate edit occurred.
