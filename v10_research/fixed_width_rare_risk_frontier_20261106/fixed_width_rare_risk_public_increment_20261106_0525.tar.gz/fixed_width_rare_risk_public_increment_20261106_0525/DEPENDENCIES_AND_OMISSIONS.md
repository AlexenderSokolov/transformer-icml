# Dependencies and omissions

All 36 available source files are included unchanged: proof revisions, failures and ledgers, literature and independent audits, historical static extract, report and body revisions, QA and builders. No unavailable historical file or result is invented.

External dependencies remain OPEN: inherited rare conditional/mixed-estimator rates including clipped_joint_risk_derivation.v2.md section 6; suffix packing, paid division/logs, small-amplitude/full-state PreLN and fixed-width norm restoration; terminal-context influence and source testing; source-specific coupling/covariance inputs and cited primary statements. Full external proofs and implementations are not supplied by this increment.

Not included: third-party full papers, uninstantiated grid quantizer/evaluator, hardware or floating-point tests, training/model outputs, screenshots/visual validation or missing earlier v10 materials. The historical review extract is a report snapshot, not current scientific execution. Report adaptations have static source provenance, not byte-identical raw appendices. No matched multihead frontier, exhaustive novelty or complete dependency recovery is claimed.
