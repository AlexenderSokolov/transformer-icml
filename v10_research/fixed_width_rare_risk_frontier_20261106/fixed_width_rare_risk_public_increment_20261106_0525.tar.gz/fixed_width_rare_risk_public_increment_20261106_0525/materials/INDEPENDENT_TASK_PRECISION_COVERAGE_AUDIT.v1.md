# Independent exact-file audit: task precision and coverage revision 2

6 November 2026 UTC. Analytical review only. No experiments, source simulation, model run, parameter generation, upload, purchase, or public write.

## 1. Exact binding and verdict

Reviewed file: `TASK_DIRECTED_PRECISION_AND_COVERAGE.candidate.v2.md`.

SHA-256: `2f1515612adabdef57f623cf88563d4d6d1c0fad30e5417ea90017ef66b216f4`.

Verdict: **PASS for the displayed component bounds and revised combined maximum, under their explicit assumptions.** Revision 1 was read in full; the complete revision-1-to-revision-2 difference was then read. The approximate-interface issue identified in `INDEPENDENT_RARE_WASSERSTEIN_BRIDGE_AUDIT.v2.md` is resolved by the new separate unconditional epsilon and conditional eta_A assumptions. Revision 1 and that earlier audit remain preserved as evidence of the correction.

The transport dependency was checked separately at `RARE_ONE_READ_TRANSPORT.candidate.v2.md`, SHA-256 `43603343070bc1c40afc1b6edbc637cd0fe4248c17ff70ce422df1b577ecebe8`. Its complete independent joint-regeneration, full-vector covariance, and actual-terminal proof is in the two `INDEPENDENT_RARE_WASSERSTEIN_BRIDGE_AUDIT` reports.

Additional exact dependencies read:

- `../rare_statistical_resource_reset_20261106/RARE_INTERACTIVE_BITS.candidate.v1.md`, SHA-256 `d8310e69296d6d8b963b2c9903259dccf7714cd475520880861f5f7f7b54e934`.
- `../rare_attention_information_bridge_20261106/EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md`, SHA-256 `8a9de69799f6fa0463991bea53ab009d430b6574c1fb9b74c2b3944c448742e2`.

The existing terminal-parity information theorem is inherited through the communication result; this review does not claim a new independent exact-file audit of that older filter proof.

## 2. Task-directed geometric simulation is correctly shown empty

Alice's partial augmented mean lies in a radius-R Euclidean ball. A delta-net can have at most `(1+2R/delta)^k` centers, so the ceiling of its base-two logarithm pays for the full codeword. Bob's contribution and the synthetic self term are locally known. Perturbing this partial vector by at most delta perturbs the completed augmented vector by at most delta.

The exact denominator is at least exp(-S). If delta<=exp(-S)/2, the perturbed denominator is at least exp(-S)/2. Using the exact head output's norm bound V gives a ratio error at most `2 exp(S)(1+V) delta`. A globally L-Lipschitz continuation therefore gives the displayed simulator error K delta with K=2L exp(S)(1+V). The off-manifold domain and normalized scalar output are explicitly dealt with; the argument is not relying only on Lipschitzness between exact attained codes.

The communication lower supplies

    R(Q)>=a 2^(-B(delta))-K delta,
    a=c u/sqrt(1+m u^2).

For k>=1,

    2^(-B(delta)) <= [delta/(delta+2R)]^k
                   <=delta/(2R).

With R>=1, L>=1, K>=2, and a<1, the right-hand side is strictly negative for every positive admitted delta. The same calculation works for the conditional version with `a=c/sqrt(1+m u^2)`. Thus neither delta optimization nor merely charging approximation only on the task event repairs this particular net/bit combination. The statement is properly restricted to this reduction and its stated envelope; it is not an impossibility theorem for every task-adapted simulator.

## 3. Complete finite-terminal-state bound

Under the stated contract, fix all independent decoder/public coins. There are at most M output probability values, even though selection among them may depend arbitrarily on the source history. For a uniform parameter on an interval I of length a=1/4, absolute loss is bounded below pointwise by distance to this M-point output codebook.

Split I into nearest-center cells of lengths l_j. A cell of length l has integrated absolute distance at least l^2/4, even if its chosen center lies outside the cell. Summing and dividing by a gives

    average loss >=(1/(4a)) sum_j l_j^2
                  >=a/(4M)=1/(16M).

Conditioning on actual terminal A leaves this uniform parameter prior and the independent coins unchanged, since the event probability is u for every parameter. Averaging the fixed-coin bound is therefore valid. Multiplication by u gives the overall-risk term. The conversion M<=2^(Wp) explicitly requires the complete source-dependent visible state, with no uncounted tags, exponents, rereads, caches, or other channels. It does not follow from width or coefficient precision alone.

## 4. Full-history sampling term

The quoted conditional KL upper is explicitly present and proved by reversal plus an initialized-chain occupation bound in the exact dependency named in Section 1:

    KL(P_t^(X|A)||P_s^(X|A))<=60(1+Nu)(t-s)^2.

At separation h=1/[16sqrt(1+Nu)], Pinsker gives TV<=sqrt(30)/16. The direct two-point absolute-loss overlap inequality has maximum risk at least h(1-TV)/2. Consequently

    R_A(Q)>=[1-sqrt(30)/16]/[32sqrt(1+Nu)]
            >=1/[64sqrt(1+Nu)].

This remains valid for randomized predictors because their common randomization is a statistical channel. The lower is not obtained by dividing stationary path KL by u.

## 5. Same-source context threshold and output floor

The complete independent reconstruction of the context bound is in `INDEPENDENT_RARE_WASSERSTEIN_BRIDGE_AUDIT.v2.md`, Section 2. The same rare source makes the final raw bit fair on prefixes ending in 1, which have stationary probability 2w. The two resulting terminal targets C and D have gap `g_t=1/2-q_t>=21/44`. Changing only that bit changes a bounded-score head output by at most `4V exp(S)/(N+1)`. Thus, for the exact smooth interface Q_0,

    R_t(Q_0)>=w[g_t-4V exp(S)L/(N+1)]_+.

This is a same-source transfer of the old late-token mechanism. It forces order-N paid sensitivity for sufficiently small overall risk, including for a source-aware predictor. It does not apply as an order-N conditional-A estimation bound, because that task fixes both terminal bits to zero.

For the actual predictor Q, a complete binary-logit contrast bound B_out implies each predicted probability is at least beta=1/(1+exp(B_out)). At terminal C the correct zero probability is q_t=ut/w, so

    R_t(Q)>=[w beta-ut]_+.

The floor must be based on the actual output contract. A probability-register projection or arbitrary decoder cannot be substituted for a bounded ordinary-softmax head while retaining this conclusion.

## 6. Revision-2 approximation bookkeeping is correct

The final display now distinguishes actual Q from its smooth interface `Q_0=G(o(X))` and explicitly assumes both

    sup_t E_t TV(Q,Q_0)<=epsilon,
    sup_t E_t[TV(Q,Q_0)|A]<=eta_A.

Risk triangle inequality gives `R_t(Q)>=R_t(Q_0)-epsilon`. Taking the supremum and the nonnegative part yields exactly the corrected context term

    [sup_t w[g_t-4V exp(S)L/(N+1)]_+-epsilon]_+.

The transport term correctly loses 2eta_A inside its u/2 prefactor. A global epsilon alone gives only eta_A<=epsilon/u, which is explicitly retained. The finite-state and output-range hypotheses are imposed on actual Q, not silently transferred from Q_0. Therefore the five lower terms can indeed be combined by taking their maximum.

For a uniformly rounded head with error delta and the stated continuation bound, epsilon<=L delta is valid. The direct paired-history bound with bracket loss 2L delta is also valid; neither error allowance is a precision impossibility theorem by itself.

## 7. Correction and failed routes preserved

The earlier combined display could be read as applying the exact-interface context term to an approximate or rounded Q without subtracting its approximation error. Revision 2 resolves this by subtracting unconditional epsilon and keeping conditional eta_A separate. The component context proof itself was already correct.

The following negative conclusions are supported and must remain visible:

- The displayed generic bit/net simulation provides no positive lower at any admitted delta.
- Finite codebook cardinality gives a standard precision condition, not a new attention/depth theorem.
- The source-specific transport gain threshold is weaker than the transferred order-N context threshold for overall low risk; its remaining role is conditional-A estimation.
- The bounded-output floor can prevent the proposed vanishing overall rare rate before width/depth/precision questions arise.
- None of these separate necessary conditions is a matching joint statistical-resource frontier or a repeated-attention separation.

No unaddressed mathematical blocker was found in the exact revised file. Later byte changes require another binding and review.
