# Fixed-width rare-risk result registry

2026-11-06. Main artifact: RESEARCH_REPORT.zh.v2.html. No public write, training or scientific evaluation.

## Accepted proof artifacts

- FIXED_WIDTH_RARE_RISK_FRONTIER.candidate.v2.md: fixed-width one-read suffix construction with genuine zero-shift final LN and ordinary softmax. Preserves exact alpha range via inward margin. Conditional and full risk have separate suffix statistics, quotient grid G, range floor and implementation epsilon. Certified fixed-grid evaluator statement is conditional only. Accepted by INDEPENDENT_FIXED_WIDTH_SOFTMAX_AUDIT.v1.md.
- RARE_ONE_READ_TRANSPORT.candidate.v2.md: rare-source terminal-A Wasserstein coupling, full-vector bounds, paid decoder and conditional/unconditional interface errors. Single-head and simultaneous multihead charges explicit. Accepted by INDEPENDENT_RARE_WASSERSTEIN_BRIDGE_AUDIT.v2.md.
- TASK_DIRECTED_PRECISION_AND_COVERAGE.candidate.v2.md: generic bit/net composition is empty at every scale; standard finite-terminal-codebook lower; full-history sample lower; same-source late-token gain and softmax floor; exact/approximate interface contracts separated. Accepted by INDEPENDENT_TASK_PRECISION_COVERAGE_AUDIT.v1.md.

## Exact dependency limits

The 157 rare-A statistic and 1300 mixed-estimator statistic are old. The direct1300 calculation is bound to clipped_joint_risk_derivation.v2.md §6 (157+1104<1300), rather than relying on an indirect HTML citation. Suffix packing, restoring division, small-amplitude PreLN and fixed-width norm restoration are old mechanisms. The current mathematical obligation is the complete ordinary-softmax output contract with paid logs and exact alpha-range margin.

The transport variance is a standard regenerative covariance calculation; Paulin's Theorem3.7 can replace it at the same order. Rare-disagreement and terminal adaptation are source-specific. The resulting parameter-estimation gain threshold is dominated on the overall rare task by the transferred late-token gainOmega(N), and is not a new main depth frontier.

## Prior-art audit

PRIOR_ART_AND_CLAIM_BOUNDARY_AUDIT.v1.md and TRANSPORT_LOWER_PRIMARY_AUDIT.v1.md retain original-paper theorem locations, model/risk/precision distinctions, and which passages were newly inspected versus inherited from existing fulltext audits. No exhaustive priority certificate is asserted.

## Corrections and failed routes

All source v1 files are preserved. Upperv2 specifies the minimal Taylor truncation length, valid power-of-two suffix domain, G>=16 for epsilon=1/G, source-independent budget choices and direct1300 source. Transportv2 pays parallel head dimensions and records overall-context domination. Taskv2 corrects the combined approximate-interface statement: context loses unconditional epsilon, transport loses conditional2eta_A, and finite-state/range floors apply to the actual predictor.

SCOPE_AND_FAILED_SHORTCUTS.v1.md records unpaid division/logs, lost output mass, insufficient range margin, precision conflations and unknown-u budget adaptation failures. No finite-evaluator or floating-point run has been instantiated. The HTML appendices are sanitized adaptations, not byte-identical raw originals. Static checks performed; no visual-render retry.

## Remaining mother-problem gap

The constructive suffix depth is not proved necessary. The one-read gain bound does not cover repeated data-dependent reads. Finite terminal alphabet and evaluator fractional precision are different contracts. No matching joint history-depth-width-precision frontier or publishable novelty certificate follows from this package.

Reportv2 removes stale candidate-review metadata from adapted appendices and states directly beside the terminal-context inequality that it applies to the exact interface; a merely approximate actual predictor must pay unconditional comparison error. Reportv1 and its builder remain preserved.
