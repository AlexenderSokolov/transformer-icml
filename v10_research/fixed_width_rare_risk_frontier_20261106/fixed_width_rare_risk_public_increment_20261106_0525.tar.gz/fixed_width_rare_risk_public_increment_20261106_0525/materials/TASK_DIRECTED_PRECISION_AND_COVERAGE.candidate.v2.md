# Task-directed discretization does not close the rare-risk frontier

Private analytical candidate revision 2, 6 November 2026 UTC. Revision 1 is preserved. This revision explicitly charges approximate-interface error in the combined terminal-context term; the component proofs are unchanged. No simulation, training, upload, or publication. This note records an explicit empty reduction, a standard finite-terminal-state bound, and the prior terminal-context obstruction that dominates the new transport threshold on the overall prediction task. None is asserted to be a new sharp joint N,D,W,precision theorem.

## 1. Frozen risks and source

Use exactly the stationary binary rare family of RARE_ONE_READ_TRANSPORT.candidate.v2.md. Write

    R(Q)=sup_(t in [1/2,3/4]) E_t TV(Q(X),p_t(.|X_(N-1),X_N)),
    R_A(Q)=sup_t E_t[|Q(1)-t| | E], E={terminal pair A=00}.

Only R(Q)>=u times a suitable parameter-averaged conditional-A lower is used. In general R(Q)>=u R_A(Q) also holds because u is common to every t. A lower on R_A is not an upper on R and cannot repair output error on C.

## 2. Task-directed one-read quantization: a correct but empty inequality

The checked rare communication theorem gives, for a source-independent interactive b-bit protocol whose output is normalized,

    risk >= a_b := c u 2^(-b)/sqrt(1+m u^2),
    c=exp(-1/100)/(20000e),                         (1)

with Bob's entire parity observation and actual terminal pair supplied freely, m<=N. The proof already handles parameter-dependent Bob marginals and conditional terminal KL.

For a one public-query bounded-score read with d>=1 value coordinates, its augmented numerator-denominator partial sum belongs to a radius-R ball of dimension k=d+1, where

    R=exp(S)sqrt(V^2+1).

A public Euclidean delta-net transmits Alice's partial sum using

    B(delta)=ceil[k log2(1+2R/delta)]

bits. For delta<=exp(-S)/2, the denominator stays positive. If the terminal continuation is globally L-Lipschitz into binary TV, a safe uniform simulator error is

    epsilon(delta)<=K delta,
    K=2L exp(S)(1+V).                               (2)

The full off-manifold continuation is required here. If its output is not a normalized Bernoulli distribution, clip its next-one coordinate to [0,1]; the clipping preserves the scalar Lipschitz error to the actual valid network output. Equivalently take L as the globally Lipschitz scalar probability continuation. The already-free terminal pair adds no communication bit.

Combining (1)-(2) correctly yields

    R(Q) >= c u 2^(-B(delta))/sqrt(1+m u^2)-K delta. (3)

This is a source-average RISK inequality, not an exact-output-information assertion. But it is empty at EVERY admissible delta under the usual envelope L>=1. Indeed k>=1 and

    2^(-B(delta))
      <= [delta/(delta+2R)]^k
      <= delta/(2R).

Set a=c u/sqrt(1+m u^2). Then the right side of (3) is at most

    delta[a/(2R)-K] <=0,                            (4)

because R>=1, K>=2, and a<c/100<1. Optimizing delta or setting the simulation tolerance proportional to the advertised risk cannot change this sign. Replacing k=d+1 by the more favorable k=1 would still leave the same obstruction.

### 2.1 Charging error only on the task event does not cure it

If the comparison is made directly under E, the rare entropy argument gives conditional protocol loss >=c 2^(-b)/sqrt(1+m u^2). A conditional output approximation tolerance K delta therefore yields

    R_A(Q)>= c 2^(-B(delta))/sqrt(1+m u^2)-K delta.

It is still nonpositive by the same argument, now with a=c/sqrt(1+m u^2)<1. Hence the missing factor is not an accidental failure to multiply simulator error by u. Correct task-directed conditioning alone does not create a width/depth lower.

This is a boundary of THIS combination of the rare total-bit lower and a generic geometric simulation. It does not prove that no better architecture-dependent or task-dependent simulation exists. If a truly smaller source-average message radius or entropy is separately established, it must be analyzed rather than substituted without proof. The new transport note supplies such a direct source-specific comparison, not a claim of improved bit cardinality.

## 3. Finite visible terminal state: standard precision and sample-size bounds

Suppose the complete source-dependent information available to the final decoder takes at most M states. This includes EVERY visible terminal activation, exponent, branch/index tag, cached read, and any other source-dependent side channel. The decoder may depend on public N,u, network parameters, and independent randomness. It may not reread other rows or raw tokens. This assumption does not follow from width alone or from short coefficient descriptions.

Then

    R_A(Q)>=1/(16M),     R(Q)>=u/(16M).             (5)

Proof. Let t be uniform on I=[1/2,3/4], of length a=1/4. Conditioning on E does not change the prior because Pr_t(E)=u. Conditional on all independent decoder coins, at most M possible predicted next-one probabilities exist. Whatever source-dependent state selection occurs, absolute loss is at least distance to that M-point codebook. For any M real centers, the uniform average distance over an interval of length a is at least a/(4M): split into nearest-center cells of lengths l_j, use integral absolute distance >=l_j^2/4, and sum l_j^2>=a^2/M. Average over the independent coins and multiply by u. Public/decoder coins remain independent of t under E. This proves (5) without a false lossless-history decoding claim.

If each of W visible coordinates has at most 2^p states and there are no extra tags or side channels, M<=2^(Wp), so

    R(Q)>=u 2^(-Wp)/16.                            (6)

Consequently a full-history rare-rate envelope C u/sqrt(1+Nu) requires

    Wp >= (1/2)log2(1+Nu)-log2(16C).

This is ordinary finite-codebook quantization. It is architecture-independent, contains no D, permits an arbitrary paid or unpaid decoder, and must NOT be advertised as a new attention-resource theorem. A finite state at one internal cut need not limit a network that subsequently reads data again.

Independently, the established full-history conditional KL bound is

    KL(P_t^(X|E)||P_s^(X|E))<=60(1+Nu)(t-s)^2.

Take h=1/[16sqrt(1+Nu)] around midpoint 5/8. Pinsker bounds conditional TV by sqrt(30)/16. The two-point absolute-loss overlap bound gives

    R_A(Q)>= [1-sqrt(30)/16]/[32sqrt(1+Nu)]
           >=1/[64sqrt(1+Nu)],
    R(Q)>=u/[64sqrt(1+Nu)].                         (7)

This sample-size obstruction also applies to any randomized predictor by data processing. The conditional full-history KL is explicitly proved in EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md, Section 4.1. It is not derived by dividing stationary path KL by u.

## 4. The old terminal-context mechanism already forces gain Omega(N) here

The published-internal predecessor MATCHING_ORDER.v2.md proves a late-token influence obstruction using a different fixed noisy-XOR source. Its exact source is NOT the rare family. Nevertheless its elementary one-read mechanism transfers directly to this rare family, as follows.

Consider ONE bounded-score read with public terminal query, ||v_i||<=V, score range <=S, and a terminal continuation that is L-Lipschitz into binary TV. Fix any t in [1/2,3/4], even allowing the predictor to know t. Conditional on a prefix X_1:N-1 ending in symbol 1, the last symbol X_N is a fair bit: both applicable preceding pair rows B,D assign probability 1/2 to each next symbol.

If X_N=0 the actual terminal pair is C=10, whose next-one probability is 1-q_t. If X_N=1 the pair is D=11, whose next-one probability is 1/2. Their TV gap is

    g_t=1/2-q_t >=1/2-1/44=21/44.

The two histories differ only at raw position N. Every other pre-read row and the public terminal query are identical. The head outputs can be written

    o_b=(1-alpha_b)r+alpha_b v_b,

where r is the SAME normalized average of all other rows and ||r||,||v_b||<=V. Bounded score range on each history gives alpha_b<=exp(S)/(N+1). Therefore

    ||o_0-o_1||<=4V exp(S)/(N+1).                  (8)

The conditional fair-bit triangle inequality and stationary Pr(X_(N-1)=1)=2w give

    R_t(Q)>=w[g_t-4V exp(S)L/(N+1)]_+.            (9)

Thus any overall risk below, for example, w g_t/2 requires

    L >= (N+1)g_t/[8V exp(S)]=Omega(N).           (10)

The V=0 case simply cannot achieve that risk. A source-average approximation error epsilon to this smooth one-read interface weakens (9) by at most epsilon. Uniform rounding error delta before the same decoder weakens the inside bracket by at most 2L delta.

This is a short transfer of the prior late-token argument, not a new principal lower. It is valid on the exact rare family, without changing source, stationarity, or terminal query. It applies even to a source-aware predictor because the obstruction is acquiring the actual terminal context, not estimating t.

The new transport note's rare-parameter threshold is

    L=Omega(N/(1+sqrt(Nu))),

whose required scale N/(1+sqrt(Nu)) is no larger than N. Hence (10) dominates it for the overall low-risk task. When Nu is large, the domination is strict in order. The transport result's remaining content is the fixed-terminal-A conditional estimation task: the two sources have the SAME fixed terminal pair A, so (9)'s last-bit/context distinction is absent. No new main depth frontier should be claimed from the transport calculation.

## 5. Ordinary final softmax adds an independent existing floor

If the complete final binary logit contrast has magnitude at most B_out, both predicted probabilities are at least beta=1/(1+exp(B_out)). At terminal C, the true next-zero probability is q_t=ut/w. Thus, for every t,

    R_t(Q)>=w[beta-q_t]_+=[w beta-ut]_+.           (11)

For fixed B_out this remains positive as u tends to zero. In particular an overall envelope C u/sqrt(1+Nu), uniform over arbitrarily small u, is impossible before asking about depth, width, or precision. The frozen full-feature epsilon-positive PreLN and bounded affine final head must be audited to obtain B_out, rather than assuming it is absent. Conditional-A estimation remains meaningful because t lies in [1/2,3/4].

The ordinary final-softmax contract is not interchangeable with the older probability-register projection contract in STANDARD_PRELN.candidate.v2.md. That compiler explicitly excludes bounded-logit vocabulary softmax. Its upper cannot be silently used to remove (11).

## 6. An honest combined resource statement and stopping conclusion

To combine the terms without hiding quantization discontinuities, let Q_0=G(o(X)) be the smooth one-head interface, let L bound G into TV, and suppose

    sup_t E_t TV(Q,Q_0)<=epsilon,
    sup_t E_t[TV(Q,Q_0)|E]<=eta_A.

These are separate admissible bounds; a global epsilon alone only implies eta_A<=epsilon/u. For Q=Q_0 both may be zero. Apply the finite-state and output-range assumptions to the ACTUAL predictor Q. Under these hypotheses the independent lower terms may be combined by taking their maximum:

    R(Q) >= max{
      u/[64sqrt(1+Nu)],
      u/(16M),
      [sup_t w[g_t-4V exp(S)L/(N+1)]_+-epsilon]_+,
      sup_t [w beta-ut]_+,
      (u/2)[1/4-Lambda R(32+sqrt(2080 ceil(N/2)u))/(N+1)-2eta_A]_+
    }.

The context term must retain epsilon when Q is only an approximate or rounded version of Q_0. It may be set to zero only for an exact interface or a separately proved zero-error comparison. For a uniform rounded head with error delta, epsilon<=L delta is valid, while the direct two-history bound in Section 4 is another valid route.

Here M<=2^(Wp) only under the complete finite-visible-state contract; L<=C_0 M_0^D only under a fixed primitive envelope; Lambda=L exp(S)(1+V) for the bounded-score augmented sketch; beta applies only when the logit contrast bound is part of the contract; and the last term is the new source-specific transport comparison, with h=1/4. The M used for state cardinality and M_0 used for a primitive gain are different quantities.

This is explicit and reviewable, but it is NOT a sharp joint frontier. The positive finite-state term is standard. The task-directed bit/net reduction is empty. The new conditional-parameter transport threshold is dominated on the overall task by the transferred terminal-context threshold, and both are at most logarithmic necessities after substituting paid exponential sensitivity. The bounded-output floor may dominate all vanishing-rate discussions.

A defensible next claim would need a same-source risk lower that remains informative AFTER terminal context is paid, at allowed output range, and for L large enough to pass these thresholds; or a genuinely architecture-specific precision/decoding lower beyond finite codebook size. Neither is supplied here. Exact scalar injection invalidates exact-information shortcuts, and the wide one-read statistical witness prevents converting logarithmic required parameter information into a required number of useful invocations.
