# 固定宽 rare-A 风险候选：先行工作与主张边界审计

2026-11-06 UTC。独立先行审计，供后续候选定理逐式核验使用。没有运行模型、枚举、数值检查、参数生成、训练或任何科学实验；没有上传、购买、仓库写入或发布。此文不是候选新证明的独立 PASS，不认证优先权。已存在的候选/审查文件均未修改。

## 1. 结论先行

**可以继续的窄方向：** 给定 raw symbols、public normalized positions、synthetic terminal、一个 useful zero-score causal read、固定 model/FFN width、冻结完整范数，构造 stationary rare family 的真实 terminal-A 条件风险上界；完成固定宽 full-feature positive-epsilon PreLN、zero-shift final LN、bounded affine vocabulary head 和 ordinary softmax 的完整编译，并把每项 arithmetic、精度和所有物理 rows 的成本列明。

**不应当使用的主张：** 新的 rare-A 统计率、新的一个 read 保存上下文、首次固定宽对数深度 Markov predictor、新的 norm-padding 方法、新的 distortion/quantization lower、已经匹配的 depth–precision–risk frontier、普通浮点实现定理、整体 rare-family 风险已完成。

当前证据支持的分类是 **known composition with additional quantitative implementation obligations**。内部已有 fixed-width suffix packing、sequential local triple counts、paid restoring division、positive-epsilon PreLN small-amplitude simulation、fixed-width norm padding 和 bounded-gain restoration。外部文献亦已有相应大机制。新候选真正需要补齐的是最终输出合同的改变和完整联接后的统一资源账本，而非重新命名这些机制。

## 2. 冻结比较对象及原计划字段

建议在定理首段固定以下对象，不用同一个符号同时表示 suffix length 和 precision。

- 原始历史 X_1:N，n=N−2；stationary binary order-two rare family，A=00、B=01、C=10、D=11，π=(u,w,w,w)、w=(1−u)/3，0<u≤1/100、t∈[1/2,3/4]、q=ut/w。
- 所评估事件 E 是同一条完整历史的实际 terminal pair A，Pr_t(E)=u。损失为 E_t[|Q_N(1)−t| | E]。不换成独立 query，不在 raw input 供应 pair、counts、u 或 t。
- 一个 predictor 对全部 t 通用；若声称 u-blind，同一预定 b_N、G_N、ε_N 和权重族亦不依赖真实 u。允许 public N、目标精度或预先声明的参数范围依赖，不等于允许测试时使用真实参数。
- b_s 是实际使用的 suffix symbols 数量，观测到 b_s−2 个 suffix transitions。保持旧 packing 的 dyadic domain，或为任意 b_s 另行证明。所有 N+1 物理 rows 仍实际存在。
- actual blocks 为 positive-epsilon (=1)、gain-two、zero-shift、全特征 PreLN；self-inclusive causal ordinary softmax；一个 useful read，其余 attention 为零；model width 和每层 FFN width 均固定，不能只固定 residual width。
- 固定的是充分大的完整 state/value norm、矩阵 operator norm、全 bias-vector norm、head 数、value dimension 和 primitive Lipschitz envelope。整体 continuation sensitivity 可以随 paid depth 增长，必须列出。
- 输出是 final zero-shift LN 后 bounded affine head 和 ordinary vocabulary softmax。原概率坐标 projection 不是同一个合同。
- 精度至少分为 coefficient/input description bits、state alphabet/storage bits、absolute execution-error radius、指定 rounded primitive arithmetic 四类。没有推导不得替换。

原计划原文核对：

1. `plan_verification_20261104_2102/space_plan_0.md`，模型约定（原总计划第76行）：参数能否依赖 N、L、ε 及是否 tied 必须逐定理声明；它没有一概禁止 length-indexed untied family。
2. 原总计划 T1（第170行）冻结 effective attention gap，不靠 N/L-growing weights 或 hidden norms 逼近 hard matching。Zero scores 满足 attention 条件，但 positionwise arithmetic 和全网敏感性仍须收费。
3. 原总计划 T2（第198行）及第二计划 §5.3：不能用人为慢算法制造深度必要性；必须比较 direct correction 和强同预算基线。
4. 第二计划 §2.5 要求 extra heads、统计、positions、precision 付费或对照同享。§3.3 要求逐近邻记录 source/prior/observability/stationarity/order/query/loss/trajectory/N/depth/heads/width/positions/mask/normalization/training/known parameters/precision/upper-lower/proof/implication，而不只摘要。
5. 总计划 rare-family 部分明确区分 terminal-A 条件风险与 stationary 平均风险；A 事件向平均损失转换保留 u 因子。它也明确完整有限样本波动不能用 population means 抹去。
6. 两份计划允许声明概率投影和平滑。Ordinary softmax 是新候选选择的更严格输出合同，不能反称旧 projection 违反原总计划。

## 3. 内部直接前件：逐命题定位

### I1. 固定宽 suffix 程序已经存在

来源：`../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`，§§3–6；独立审查 `INDEPENDENT_CONSTANT_WIDTH_AUDIT.v2.md`。

它已经以一个 zero-score prefix mean 获得 packed suffix，在每个 row 顺序解码，局部形成 triple counts，用 O_K(1) 寄存器累积，再 paid restoring division。完整物理 rows 的 legal virtual-word invariant、边界 default symbols、complete-state bounds 和 source-independent public positions 已计入。

旧资源形状为

D_ref = O_K(log N + b_s + log² b_s + log(b_s+K) log G), W=O_K(1), useful reads=1。

旧输出为 positive probability coordinates projection，不是 vocabulary softmax。把统计目标换成 rare-A 并只保留 A-row counts 是简化/组合，不是新的一读 packing 或 local-binding 机制。

### I2. 此程序已有一份狭义 finite arithmetic 定理

来源：同目录 `PACKED_SUFFIX_PRECISION.candidate.v2.md`，§§2–6、9；独立审查 v2。

它规定 dyadic persistent registers、足够 integer temporaries、exact integer attention numerator accumulation 后一次 downward rounding，以及特定 floored square-product schedule，给出 F=O_K(log N+b_s+log G) fractional bits 并在每 row 得到同一 quantized probability output。它**没有** positive-epsilon LN/ordinary-softmax 的有限运算保证。其 exact word recovery collision、fixed-grid collapse、floating mean-rounding stress test 都针对特定 bottleneck/arithmetic。不可搬成新全模型风险下界。

### I3. 固定宽 positive-epsilon PreLN 与真实 norm padding 已存在

来源：`../standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md`，§§3–6、8；third review v1。不是 wide compiler。

已审机制包括 paired homogeneous representation h=ηz、anchors、每步真实误差递推 e_l≤L e_(l−1)+Cη²、所有 source-row LN factors、approximate clears、fixed-width square-root padding、public bounded-gain restoration。旧 prepared reference 为 (v,−v,1,−1,r,−r,0,…) 且 r≈√(3d/2−1−||v||²)，使 norm²/d≈3。它使用了 final LN 的非零 probability-offset shift β=π，然后 projection。

因此新 zero-shift/ordinary-softmax 不能原封不动引用旧 output theorem；但不应把 padding、restoration 或 small-amplitude idea 再称新方法。

### I4. rare-A 统计率与同端点处理均为旧成果

来源：`../u_blind_full_averaged_20261103_2147/full_averaged_tv_bound_v1.html`，§8 Eq.(8.5)、§10，及 `final_file_review_v1.md`；后续 `../rare_context_reconciliation_20261104_2104/RECONCILIATION.v2.md` §2。

旧 add-one A-row estimator 在 actual terminal A 上满足 min{1,157/√(1+n u)}。相同 source 的 full-history conditional minimax scale 为 (1+n u)^−1/2；平均风险 lower 乘 u。Suffix marginal 在 stationary source 下仍为该 stationary source，且其最后 pair 就是完整历史的最后 pair，所以把 n 换成 b_s−2 是合法的旧定理组合。不能用一般无条件频率估计直接替代 terminal-conditioned proof。

### I5. wide one-read statistical witness 已经实现 ordinary softmax

来源：`../rare_attention_information_bridge_20261106/ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md`，§§3–6、8–9。

它的 wide history bank 已在 terminal 内 locally triple-bind/count，从两读变一读；它把 A estimator clip 到 [1/2,3/4]，再付费 log preparation，最后 ordinary softmax。宽度 O(N) 和 growing log-interpolation lanes 被明示计费；其中 restoration 的小误差利用 d=Θ(N) 的 dimension dilution。该结论不能自动变成 fixed-width 上界。新候选必须替换这些增宽步骤，而不是省略其成本。

### I6. 精确 scalar injection 阻止无条件信息下界

来源：同目录 `EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md`、`SCALAR_INJECTION_PRIOR_AUDIT.v1.md`。

固定维精确实数并不提供 finite alphabet；短参数 descriptions 不等于短 activations。有限 terminal-state lower 必须把新量化/观察限制明确写进模型，而不能说其从 ordinary PreLN 自动产生。

## 4. 新上界的证明验收清单

候选风险的安全形状为

R_A ≤ min{1,157/√(1+(b_s−2)u)} + C/G + ε_impl。

这不是本审计已验收的新定理；仅在以下义务完成后可报告该上界。

1. **Suffix marginal 与 domain：** b_s≤N、有效 transitions=b_s−2、dyadic约束及短历史单独处理。Stationary 源的条件引用正确，不能悄悄放宽到 arbitrary starts。
2. **全 row 合法性：** unavailable suffix slots、zero digits、synthetic exclusion、lags/triples 边界以及所有负 preactivations/scratch 必须落入同一完整范数。
3. **Quantized ratio：** 若用旧 restoring division，输入 lattice 是旧 exact logical reference 的性质；physical PreLN 轨迹是连续近似，并不仍在 lattice 上。应用整个 continuous-program error recurrence，而不是对 physical states 免费 snap。
4. **剪裁：** 将估计 t clip 到 [1/2,3/4] 不增风险；相应 probability vector 的两项位于 [1/4,3/4]。它解决 A-conditional output range，不解决 C-row q=Θ(u) 的 overall 风险。
5. **真正 fixed-width paid log：** 宽 hinge bank 或查表的宽度不能漏记。一个简单、保守且可逐式实现的方案是 log p=−Σ_(k=1)^m (1−p)^k/k+tail，m=O(log(1/ε))；在 p∈[1/4,3/4]，tail≤4(3/4)^(m+1)。串行维护 power 和 sum，并用 bounded-domain multiplication 误差 δ=O(ε/m)，得到 O(log²(1/ε)) paid depth、固定寄存器、bounded coefficients/states。此处只是构造建议，不能在未写电路前算作独立 proof PASS。
6. **O(log 1/ε) log circuit 不能无证领取：** Yarotsky square/product theorem 本身不含该结论。若要更快 log，需独立 source theorem 或 accelerated circuit，逐项保留 fixed width、full norm、coefficient bits 和 stable tube。
7. **zero-shift norm padding：** 可以准备 paired logits (ℓ,−ℓ) 与 anchor、padding，而非 deviation simplex bank。若使用一维 log-odds ℓ=log[z/(1−z)]∈[0,log3]，可取 prepared vector (ℓ,−ℓ,1,−1,r,−r,0,…)，r≈√(3d/2−1−ℓ²)，固定 d 使被开方数远离零。旧 restoration 完成后 final gain-two/zero-shift LN 在目标 norm²/d=3 时近似 identity，affine head logits=(0,ℓ)，然后 ordinary softmax。必须把 padding 的算术误差、physical scratch 和 restoration 参数误差统合进 ε_impl。
8. **梯度/误差与概率：** 二元 softmax 是 sigmoid(logit difference)，其导数≤1/4。给出 exact mapping、logit uniform error 到 TV 的常数即可；不要用“近似概率总和为一”替代真正 softmax。
9. **资源：** 至少列 model/FFN/value width、实际 blocks、useful invocations、public positions、每参数最大 bitlength、全部 untied parameter bits、all-row states、dense score storage、local work 与 useful/dummy attention work。
10. **精度：** inherited compiler 可给 p_error-radius=O(D+log(1/ε_impl)) 的充分扰动指标，前提是全 actual blocks 共同 Lipschitz。它不是有限 state alphabet，也不是 LN/exp/accumulator rounding theorem。finite alphabet 下界与此上界不可直接拼成 matching precision theorem。
11. **u-blind 量词：** 对任意预选 public b_s 可得到一份点态 u-dependent bound；反解 b_s≈1/(u r²) 再选权重已依赖真实 u。若要这样调预算，必须声明 known u、known lower bound ρ 或新的合法自适应方案。

## 5. Lower 的正确分类与不能推出的结论

### 5.1 Finite terminal alphabet 是标准 distortion/quantization

假设最终输出只能使用一个完整 terminal statistic S，|range S|≤M，外加已声明且不携带 t 信息的 public metadata/独立 coins。所有 residual、历史的 terminal copies、其他 heads、精确 side ports 都必须包含在 S 内或证明对输出无用。有限 d 不足以给有限 M。

给 Θ 在 [1/2,3/4] 上均匀先验，长度 a=1/4。Pr_Θ(E)=u 独立于 Θ，所以条件 E 不改变该先验。Data processing 和 |S|≤M 给 I(Θ;Q|E)≤log M。标准 absolute-distortion entropy inequality 给

E[|Q(1)−Θ| | E] ≥ a/(2eM) = 1/(8eM)。

该 lower 允许任意编码、任何计算深度、随机 encoder/decoder（独立 coins 按条件处理）。这是 Xu–Raginsky Theorem 3 Eq.(39) 的直接参数代入，不是本研究创新。

若每个 complete terminal scalar 有 A_p 种值且 d fixed，M≤A_p^d；若每标量总 storage bits≤p，则 A_p≤2^p，得到 R_A≥c2^(−dp)。固定 bounded-range fractional grid 给 log A_p=O(p)，但 exact-real coefficient bits 或 error-radius p 不给这个结论。若输出允许读取整个 terminal transcript，而非最后 state，则需要重新计 M；若之后还能读取非terminal rows，也不是该 cut。

### 5.2 与 full-statistical lower 取 max 仍非 architecture frontier

同源旧 conditional full-history lower 与上式合成

R_A ≥ c max{(1+(N−2)u)^−1/2, M^−1}

（常数可取两者较小值）。这只是任意完整历史估计的 sampling lower 加上最终输出的 finite-message lower。

它不含 b_s，也不下界计算 depth 或 useful read 数。Suffix upper 使用 b_s≪N 时损失的信息是所选算法的代价，不能由 full-statistical lower 证明不可避免。把实现中 b_s≈D 倒代进 upper 不能得到 lower。b_s 只有在整个受限类已被证明/定义为只能看到该 suffix 时才进入 statistical lower；那又是更窄且不同模型。

M 的充分成本可能 O(D) bits，而 finite-message necessity 只有 log(1/r)。这没有 matching。一个 Θ(log(1/u)) 信息需求也不强迫多个 reads，一次高精度消息即足以承载。固定有限字母表 theorem 不依赖 evolving-row attention 结构，不能解决母问题中的 repeated useful attention lower。

### 5.3 强同预算 baseline

自由读取完整 raw history 的普通 streaming counter 可维护 A-row successes/departures 以及最后两个符号，使用 O(log N) integer bits，在 O(N) arithmetic steps 得到 full-data estimator；再用 O(log(1/r)) bits量化 final estimate。该算法是 statistical/storage baseline，不是免费嵌入 candidate Transformer。若比较总体计算成本，不能将其排除；若比较 architecture，必须明确它获得不同访问接口。

## 6. 外部 primary theorem comparison

下面保留核心强制字段；“NA”表示该表示/逼近定理没有统计源或训练风险对象。所有结论均只覆盖所列版本和定理，而不是 exhaustive non-subsumption。

### P1. Rajaraman et al., Transformers on Markov Data

Primary: https://arxiv.org/html/2407.17686v1 ，Theorem 5.1、Remark 5.2、§2.1、Architecture 0.2、Appendix C.1–C.3。

完全观测同一输入 string，actual final k-symbol context 的 empirical conditional k-gram；pathwise representation，不依赖 stationarity或特定 initialization，不是 uniform rare-A expected-TV theorem。三层、每层一 head、O(S) embedding，relative positions；有 LN，正文明确结论也适用于原 evaluated architecture。相关证明的 norm 没有固定正ε全特征 PreLN合同，attention sharpening 非冻结 score。Theorem 是 source-independent constructed weights，不是 training theorem。Remark 5.2 对 logarithmic-in-T/order bits 的 sufficiency 是讨论且明说 proof 未界 finite-bit approximation。**关系：** estimator、same-history、constant dimension、normalization 的强前件；缺少新的 simultaneous frozen architecture/arithmetic contract。不能靠“它不是统计率”一项宣称技术分离，representation 可以组合旧统计 lemma。

### P2. Ekbote et al., What One Cannot, Two Can

Primary: https://arxiv.org/pdf/2508.07208v2 ，printed p.7 Theorem 3 / Remark 2；§2.2；Appendix A.2.2、B。

同样是任何输入 string 的 conditional k-gram，actual terminal suffix，原始 symbol sequence；两层，每层一 head，dimension 6S+3，MLPs、relative positions 和 LN。实验 Dirichlet source/uniform initialization 不限制 pathwise theorem。ReLU output而非 ordinary final softmax；对 projected query/key normalization、无限 sharpening 等与 frozen full-feature positive-ε PreLN 不同。Remark 2 声称 sufficient Ω(log T+k) parameter precision，不是 necessity或全部内部算术 guarantee。**关系：** 更近 shallow constant-dimension nonlinear Markov representation；其 parameter-count项包含 T，不能只按 residual dimension 宣称总成本常数。

### P3. D’Angelo et al., Induction Heads Interpolate N-Grams

Primary: https://arxiv.org/html/2607.02800v1 ，Proposition 3.1 Eq.(8)、§§3.2.1–3.2.3、Corollary 4.1 Eq.(10)。本轮沿用先前 primary fulltext audit，未重审全文。

Pathwise actual-suffix weighted mask counts；两 disentangled layers，k heads再一 head，fixed alphabet/order 下维度常数，BOS additive smoothing 已有。固定β的 context weighting并不令全部 positional copying/suppression scores有界，它们另取 sharpening limits。Registers/readout不是本候选 full PreLN/ordinary-softmax合同；无本候选 finite-execution模型。**关系：** counting/smoothing/context mechanisms 已知，不能把添加统计界作为唯一新机制。

### P4. Akman et al., quantitative/quantized statistical prediction

Primary: https://arxiv.org/html/2610.41038v1 ，§5 preamble、Theorems 26–27 Eqs.(24)–(25)、Appendix C.6 Definition 32/Lemma 33。本轮沿用先前已核 primary passages。

一条训练轨迹而 independent test history，TV损失；gatherer/interpolator architecture，dimension 2M+R(s)+1，受保护 token/position coordinates与 supplied unmasked windows，ordinary final softmax。逐层 state Q_n 和 measure R_l 量化已经明确，不可称 exact-real-only predecessor；其 training/source依赖和误差入口不同于 unknown-kernel common in-context terminal estimator。**关系：** nearest genuine TV+quantization+softmax antecedent，不能直接代换成当前 same-history/error-policy theorem。

### P5. Yarotsky, fixed-width square/multiply arithmetic

Primary: https://arxiv.org/pdf/1610.01145v3 ，§3.1，Propositions 2–3，printed pp.7–8、Eq.(3)–(4)。本轮直接核正文。

NA for stochastic source/prior/prediction/training。Constructive ReLU uniform approximation on bounded domains；iterated tent squares与polarization乘法，depth/size O(log(1/δ))，参数可依赖目标精度。**关系：** packed-product/log-series/padding 所用基本 arithmetic 的直接前件；不能由此直接声称 zero-cost log、LN rounding、全 Transformer norm envelope或 statistical risk。

### P6. Ahvonen et al., norm-padding normalization simulation

Primary: https://arxiv.org/html/2605.07705v2 ，Appendix F.3 Theorems 19–20。此次重开定位核验。

有限 floating domain 的 logical expressivity，不是 Markov risk/training theorem。Theorem 20 明确 no-LN decoder layer 可由 pre/post-norm layer模拟；paired coordinates消均值，padding等范数，fixed gain和β=0使LN neutral。**关系：** zero-shift norm padding 本身也已有。它没有提供当前精度依赖下 fixed-width/bounded-complete-norm continuous padding微程序；Theorem 19 反向模拟用 sufficiently wide lookup MLP，不能借为固定宽 cost-free LN计算。

### P7. Merrill–Sabharwal, log-precision execution

Primary: https://arxiv.org/html/2210.02671v7 ，§2.1 Definitions 1–2、§3 Proposition 1、§4 Theorem 2、Appendices C–D。本轮沿用 `FINITE_PRECISION_PRIMARY_FULLTEXT_AUDIT.v1.md`。

Finite p-bit floats是实际 states/primitive outputs datatype，不是parameter descriptions。Uniform attention nearest-rounding collapse threshold为 log₂log₂N **total float bits**，不是log N fractional bits。Logical Boolean expressivity，非 rare-risk；displayed LN与ε=1合同不相同。**关系：** precision-sensitive expressivity已知，不支持本候选error-radius与storage alphabet混同。

### P8. Chakrabarti–Pitassi–Alman, Every Bit Counts

Primary: https://arxiv.org/pdf/2602.02707v1 ，Theorem 2.4、Appendix A Definitions A.7/A.10、A.3–A.4、B.2。本轮沿用上述 fulltext audit。

特殊 equality encoding，one layer/one head/d_v=1，p versus p−1 fixed-point exact computation，指定 operation order和rounding。不是raw stationary Markov prediction，也没有固定正ε PreLN/full norm。**关系：** finite-bit瓶颈方法前件；cannot transplant one-shot lower to arbitrary repeated evolving-row reads。其 floating appendix文字/证明不一致已记在旧审计，不作为干净 exact threshold引用。

### P9. Brösamle–Eckstein, layerwise rounding and denoising

Primary: https://proceedings.mlr.press/v306/brosamle26a.html ，PDF https://raw.githubusercontent.com/mlresearch/v306/main/assets/brosamle26a/brosamle26a.pdf ，Definition D.4、Remark D.5、Theorems D.16–D.17、Theorems 4.1–4.2。本轮沿用旧 fulltext audit。

正规语言/Turing-machine、argmax/CoT任务；无强制LN，width/depth及QK scale增长；指定 rounding points，中间高精度累加排除。包含显式layerwise error recurrence以及更强ReLU denoising。**关系：** stability recurrence不新；当前 candidate 的 bounded-score fixed-width calibrated-probability合同需另证。

### P10. Xu–Raginsky, distortion and quantized scalar estimation

Primary: https://arxiv.org/pdf/1607.00550v1 ，Theorem 3 Eq.(39)，Example 6/Corollary 7，Eqs.(100)–(103)。本轮直接核正文。

General Bayes estimation entropy inequality；该 scalar absolute-loss例为uniform Bernoulli-bias prior、IID raw observations、quantized sample mean，经有限消息预算；无需Transformer结构。Lower c2^(−bits)与upper sampling error+quantization以及half-log n摘要位数都已明确。**关系：** 当前terminal alphabet下界的直接数学代入，必须标为standard distortion/quantization，不得作为新核心定理。

## 7. 可以使用的结果描述与停止条件

安全描述：

“我们将已有固定宽 suffix 程序、rare-A 同端点统计界和 positive-epsilon PreLN compiler 连接，在明确支付 logit 准备、norm padding 与幅度恢复成本后，研究 ordinary-softmax 输出的固定宽条件风险实现。标准 finite-alphabet distortion bound 提供独立表示精度障碍；它尚未匹配计算深度或 useful-read 的必要性。”

若最终只剩上式风险上界和 max{sampling,quantization}下界，不将其升格为新架构最优前沿。继续研究应集中在真正 architecture-specific、覆盖所有 retained channels/evolved rows、且与上界同算术合同的必要性；或者将当前结果如实作为 implementation corollary结束。

## 8. 审计证据范围

本轮直接读取两份原计划相关段、上述内部候选/审查及 execution-contract primary audits；直接重开核查 Yarotsky、Rajaraman、Ekbote、Ahvonen、Xu–Raginsky 的指定 primary theorem passages。D’Angelo、Akman、Merrill、Chakrabarti、Brösamle条目明确继承现有 fulltext audit，并未虚称再次逐行复核。无全文缺失导致关键结论依赖猜测，但没有完成全部最新版本/引用图穷尽调查。检索未找到完整同合同结果不构成 novelty证据。
