# Independent exact-file audit: transport revision 2 and coverage additions

6 November 2026 UTC. Analytical review only; no scientific experiment, source simulation, model run, parameter generation, upload, purchase, or public write.

## Exact bindings and verdict

Primary reviewed file: `RARE_ONE_READ_TRANSPORT.candidate.v2.md`.

SHA-256: `43603343070bc1c40afc1b6edbc637cd0fe4248c17ff70ce422df1b577ecebe8`.

The complete independent reconstruction of its unchanged Sections 1–5 and the single-head sensitivity calculation is in `INDEPENDENT_RARE_WASSERSTEIN_BRIDGE_AUDIT.v1.md`, SHA-256 `908cfcbdc32ee4b4c290e16eee0f212570bac818ff8340119c4b6d622eae8dc4`. That report binds revision 1 of the candidate separately; both old files are preserved. The revision-1-to-revision-2 textual difference was inspected in full, and all newly added statements were checked below.

Verdict: **PASS for the exact revision-2 transport theorem, actual-terminal risk bridge, explicit parallel-head ledger, and same-source terminal-context comparison.** The single-head scope recommendation in the first audit has been resolved. No failure in the new mathematical proof was found.

The constants remain 40 for stationary joint mismatch, 8320 for the stationary full-vector second moment, and 32 for the conditioned-start transient. Their independent proofs and rejected shortcuts remain recorded in the first audit, rather than being discarded after revision.

## 1. Parallel-head norm accounting

For head h the augmented local vector is `(exp(score_h-self_h) v_h, exp(score_h-self_h))`. With score span at most S and full value bound V_h, concatenation over H heads gives

    ||a_i||^2 <= exp(2S) sum_h(V_h^2+1),
    R_H=exp(S)sqrt(sum_h V_h^2+H).

The ratio map acts independently on the H numerator/denominator blocks. Its per-block Lipschitz factor on reached sketches is at most exp(S)(1+V_h). Squaring the blockwise estimates and summing therefore bounds the full concatenated output difference by

    exp(S)(1+max_h V_h) times the augmented-sketch difference.

The following continuation's Lipschitz constant must be measured in this full concatenated Euclidean norm, including its output projection. The candidate does this explicitly. There is no omitted sqrt(H) in the ratio map and no missing H in the augmented feature radius. In particular, fixed per-head bounds do not imply a constant full radius as the number of heads grows.

This remains one simultaneous layer of public-query reads from local pre-read states. It does not cover sequential contextual reads by reusing this factorization unchanged.

## 2. Same-source late-token/context obstruction

The new comparison was also checked against `TASK_DIRECTED_PRECISION_AND_COVERAGE.candidate.v1.md`, SHA-256 `f2cfa4c846b543639cd299b3c66a8b6e830a324555be4395442c89d0476aaf7d`, Section 4.

Under the exact rare source, condition on any prefix through N-1 whose last symbol is 1. The current pair is B or D, and both transition rows emit the last raw bit fairly. If that bit is 0 the terminal pair is C; if it is 1 the terminal pair is D. Their true next-one probabilities are 1-q_t and 1/2. Since q_t<=1/44,

    g_t=1/2-q_t>=21/44.

The histories differ only at raw position N. With local pre-read processing and a public synthetic-terminal query, all other head values and scores are unchanged. Normalize their weighted average as r, common to both histories. Then

    o_b=(1-alpha_b)r+alpha_b v_b,
    ||r||,||v_b||<=V,
    alpha_b<=exp(S)/(N+1).

It follows directly that

    ||o_0-o_1||<=2V(alpha_0+alpha_1)
                 <=4V exp(S)/(N+1).

The fair-bit conditional average error is at least one half of `[g_t-L||o_0-o_1||]_+`. Stationarity gives `Pr(X_(N-1)=1)=2w`; hence

    R_t(Q)>=w[g_t-4V exp(S)L/(N+1)]_+.

No source replacement, independent terminal query, iid assumption, or unknown-parameter argument is needed. This works even when t is known, because its bottleneck is acquisition of the actual terminal context.

For an exact single-head smooth architecture, overall risk below w g_t/2 therefore requires L>=(N+1)g_t/[8V exp(S)] when V>0; V=0 cannot reach that risk. This order-N requirement dominates the transport threshold N/(1+sqrt(Nu)). The latter retains separate content only for the conditional-A task, where both compared terminal pairs are fixed at A.

Revision 2 correctly says this is transfer of an old mechanism, not a new main depth frontier. Its new transport statement is not a matching joint width/depth/precision or statistical rate theorem.

## 3. Additional companion checks and exact-interface caveat

The companion file named above was read in full for the following checks:

- The generic geometric-net subtraction is nonpositive for every admitted delta under its stated L>=1 envelope. The elementary inequality `2^(-B(delta)) <= delta/(2R)` is valid; replacing the augmented dimension by one does not repair its sign. The same empty subtraction holds after conditioning on the task event. This rejects only this particular reduction.
- The finite-visible-state codebook bound is correct: for a uniform parameter on an interval of length 1/4, any at-most-M-point prediction codebook has mean absolute error at least 1/(16M). Conditioning on all independent coins is legitimate because the actual-terminal-A event has t-independent probability u. Source-dependent tags or subsequent rereads cannot be omitted from the state contract.
- The quoted conditional full-history KL upper, 60(1+Nu)(t-s)^2, was checked in `EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md`, Section 4.1. Taking separation 1/[16sqrt(1+Nu)] and the two-point overlap bound gives the displayed conservative conditional risk 1/[64sqrt(1+Nu)].
- The ordinary-softmax floor is correct under an actual complete-logit contrast bound B_out: beta=1/(1+exp(B_out)), and the C-row contribution is `[w beta-ut]_+`.

One presentation caveat was sent to the author: the companion's Section 6 combined maximum writes the late-token term without approximation error while keeping eta_A in the transport term. This is valid when Q itself is the exact L-Lipschitz one-read continuation assumed in Section 4. If Q only approximates that smooth interface, the context term must also lose the unconditional approximation error epsilon, or the inside bracket must lose 2L delta for a uniformly perturbed head output. The companion already states these losses in Section 4; its combined display should explicitly preserve the distinction. This caveat does not invalidate the primary transport revision-2 file, which uses the context result only for the exact one-read architecture.

## 4. Final scope

The audited result is a valid source-specific Wasserstein-to-paid-decoder risk bridge on the actual terminal-A event. The proof is dimension-free because it assumes bounded full Euclidean feature norms and controls joint regeneration and vector covariance. It is not a fixed-width-only result, and no uncharged inverse, arbitrary exact-information bound, or complete finite-arithmetic theorem follows.

For the overall prediction problem, the same-source context-acquisition obstruction is stronger, and a bounded final ordinary-softmax range may impose a still more basic nonvanishing floor. These coverage facts must remain alongside any presentation of the narrower new conditional-A calculation.

This report binds only the exact bytes listed above. Later revisions require a fresh binding and review of their changes.
