# Fixed-width, one-read rare prediction with paid ordinary-softmax decoding

6 November 2026 UTC. Analytical candidate v2, preserving v1 unchanged; independent exact-file review pending. No scientific run, numerical fixture, parameter-generation run, model execution, training, upload or public write was performed. This is a composition and extension of existing exact-real arithmetic/PreLN mechanisms and existing statistical estimates. It claims neither a new statistical rate nor a width/depth/precision optimum.

## 1. Statement, including the output-range contract

Use the stationary binary rare family already fixed in `../rare_attention_information_bridge_20261106/ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md`: pair states A=00, B=01, C=10, D=11, stationary probabilities (u,w,w,w), w=(1-u)/3, 0<u<=1/100, t in [1/2,3/4], and C-row next-zero probability q=ut/w. The A-row next-one probability is t; B,D are fair. Inputs are N raw symbol onehots, scalar public position j/P with P=2^ceil(log2(N+1)), and one source-independent synthetic zero-symbol terminal T=N+1. There are no supplied counts, context features, suffix port, or encoded-history input.

Fix a declared dyadic 0<alpha<=1/4. Choose a power-of-two suffix length b with 8<=b<=N, a power-of-two denominator G>=8, and 0<epsilon<=1/16. These are public design budgets fixed without access to u,t or the realized history; the bounds hold simultaneously over the allowed u,t. Choosing b by inverting a target bound using u would require known u or a declared known lower rarity bound, and is not an unknown-u adaptive result. There is a source-independent, length-dependent untied family with:

- constant model width, FFN width and physical value width, independent of N,b,G,epsilon (a fixed binary register layout suffices);
- exactly one useful self-inclusive causal ordinary-softmax attention invocation, with one head and identically zero scores; every other attention output is zero;
- genuine full-feature PreLN residual blocks, every LN having epsilon_LN=1, coordinate gain 2 and zero shift, including the ordinary final LN;
- a bounded affine binary vocabulary head followed by ordinary softmax;
- one finite full-state/value/operator/full-bias/primitive-Lipschitz envelope C_alpha, fixed after alpha and before N,b,G,epsilon,u,t or the history vary;
- every exact-real physical output's next-zero probability in the EXACT interval [alpha,1-alpha].

Let Q_N denote the actual terminal output and E_A={actual terminal pair is A}. Then

    E[|Q_N(1)-t| | E_A]
      <= min{1,157/sqrt(1+(b-2)u)} + 1/G + epsilon.       (1)

For unconditional terminal TV risk R,

    R(Q_N) <= 1300u/sqrt(1+(b-2)u)
              + w(alpha-q)_+ + (u+w)/G + epsilon.        (2)

Both right sides may be capped at one. These estimates use the SAME model and the SAME actual terminal pair. In the same exact output-range contract, EVERY predictor, irrespective of its history processor, satisfies

    R >= w(alpha-q)_+.                                    (3)

Consequently the fixed-alpha floor and the achievable statistical/quantization/implementation terms are on one ledger. This does not remove the floor by letting alpha depend on u: that changes the declared norm/range resources.

Put H=ceil(log2(N+1)), h=ceil(log2(b+2)), g=log2 G, and L=1+log(1/epsilon), with logs in resource bounds in any fixed base. A sufficient paid primitive/standard-block depth is

    D = O_alpha(H + b + log^2(b+2) + h g + L^2).           (4)

Maximum rational/dyadic coefficient-description length is O_alpha(D), and conservative dense untied parameter-description length is O_alpha(D^2). These are description bounds, not execution-bit guarantees. Section 9 supplies a separate conditional finite-evaluator contract.

## 2. Existing packed suffix, now used for two row estimates

Import only Sections 3-4 of `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`. They give a continuous fixed-width affine/ReLU reference program with one uniform scalar read, paid depth

    O(H+b+log^2(b+2)),

and bounded whole states and primitives. The program positions base-B digits for the last b raw symbols, with B=16 for a binary alphabet, averages them over the full prefix, pays for recovering the prefix denominator, and sequentially decodes all b digits using continuous classifiers with a proved plateau margin. The packed-code approximation error is below B^(-b)/100 before digit decoding. Every public gain depending on N or b is factored into paid bounded stages. The input is not physically cropped.

Relabel raw symbol 0 by digit 1 and raw symbol 1 by digit 2. An unavailable decoded digit 0 is replaced, for counting only, by raw symbol 1. This harmless default differs from the old optional default and does not change subtraction from the packed residual. Thus EVERY physical row produces a legal virtual b-symbol word, and the synthetic terminal's word is precisely the actual suffix. Retain the two decoded lag onehots and accumulate the fixed-size binary triple table at scale 1/Q, Q=2^h>=b+2. All count mass is at most (b-2)/Q<1.

At T the final pair is the ACTUAL pair (X_(N-1),X_N). Local gates select each of the A and C count rows, independently of which row is final. The only extra count/output registers are constant in number. Keeping all four contexts or just A,C changes only a fixed factor.

All-row legality is important. It gives exact reference count lattices, bounded division domains, and valid final log/padding domains at every physical row, including early rows. The later physical PreLN simulation is not claimed to preserve these lattices exactly; its continuous full-program error is charged separately.

## 3. Fixed-width dyadic quotient, including C's exact zero fallback

The existing restoring-division comparator from `../shallow_readout_audit_20261104_1037/sources/proof.v3.md` is

    H_delta(x)=min(1,Q max(0,x+delta)), delta=1/Q.

It is implemented by one ReLU initialization and h clipped doublings, each gain at most two. On the delta lattice it equals 1{x>=0}. We use this exact-real reference fact, not a discontinuous comparator primitive or an assertion about perturbed inputs.

The following minor extension handles 0<=n<=d<=1, lattice n,d, and d=0. Compute

    z=H_delta(-d), d'=d+delta z,
    e=H_delta(n-d'), v=ReLU(d'+e-1),
    r=n-v, f=e.

On the legal domain, z=1 precisely at d=0, hence d'>=delta. Because n<=d', e=1 precisely at n=d'. The gate v equals e d'. Thus 0<=r<d' and f is the endpoint indicator. If n=d'>0, f=1 and r=0; otherwise f=0 and r=n. If d=0, then n=0, d'=delta, f=r=0.

For j=1,...,g, perform paid steps

    a=H_delta(2r-d'), v=ReLU(d'+a-1),
    r <- clip_[0,1](2r-v), f <- f+2^(-j) a.

On every reference row a is an exact bit, v=a d', and 0<=r<d'; the clipping is inactive on the valid recurrence. For n<d' standard induction gives

    f=floor(G n/d')/G,

while n=d' yields f=1 exactly. The d=0 case yields f=0. No large integer F, ceiling, division, floor or endpoint test occurs as a network primitive. All values and complete fixed-size states stay bounded. The extra initial comparator and gate cost O(h); the g rounds cost O(hg), with maximum coefficient description O(h+g).

Apply this algorithm to

    A: n=(C_A0+1)/Q, d=(J_A+2)/Q;
    C: n=C_C0/Q,     d=J_C/Q.

For A the ratio is strictly between zero and one. For C this computes

    r_C^G=floor(G C_C0/J_C)/G when J_C>0,
    r_C^G=0 when J_C=0,                              (5)

including exactly one at C_C0=J_C>0. Let r_A be the old A add-one estimate and r_C the old unsmoothed zero-fallback estimate. Then

    |r_A^G-r_A|<=1/G, |r_C^G-r_C|<=1/G.              (6)

Set the B,D estimates to exactly 1/2 and select the actual virtual final pair using its two internal lag onehots. This gives a scalar r^G in [0,1] at every row. At T it is a quantized version of the OLD mixed estimator, not an add-one replacement for the C branch. The maximum pathwise error against the old mixed estimator is 1/G and it is zero on B,D.

## 4. An inward margin gives the exact alpha range

Let mu be the largest power of two not exceeding epsilon/2, so epsilon/4<mu<=epsilon/2. Define

    p=clip_[alpha+mu,1-alpha-mu](r^G).

This is a paid fixed-size affine/ReLU operation. Since alpha<=1/4 and mu<=1/32, the interval is nonempty. Relative to the desired alpha-projected estimate p_alpha=clip_[alpha,1-alpha](r^G),

    |p-p_alpha|<=mu.                                 (7)

We will compile p to a physical ordinary-softmax output qhat with uniform error at most mu/2. Consequently, on EVERY legal raw history and physical row,

    alpha+mu/2 <= qhat <= 1-alpha-mu/2,
    |qhat-p_alpha| <= 3mu/2 <= 3epsilon/4.             (8)

Thus the exact physical output really is alpha-range restricted. This small reserved margin addresses the gap in the earlier wide construction, whose alpha was only the reference projection level and did not establish the exact realized range. No zero-error compiler or limiting network is assumed.

## 5. Paid logarithms at fixed width

A logarithm oracle or growing hinge bank is unnecessary. For x in [alpha,1], set y=1-x and use

    log x = -sum_(k=1)^r y^k/k - tail,
    0<=tail<= (1-alpha)^(r+1)/((r+1)alpha).

For a desired uniform log error delta_log>0, choose the public integer

    r = ceil(alpha^(-1) log(4/(alpha delta_log))).

Then the tail is at most delta_log/4. Starting from v_0=1, compute serially

    v_k=clip_[0,1](M_delta(v_(k-1),y)),
    s_k=clip_[0,C_0](s_(k-1)+v_k/k), s_0=0,

where M_delta is the existing fixed-width tent-square/polarization product with absolute error at most delta, and C_0 is a fixed power of two at least 1+log(1/alpha). Each product costs O(1+log(1/delta)) paid affine/ReLU primitives, with fixed scratch and bounded primitive coefficients. Take a public dyadic delta<=delta_log/(4r).

Inductively |v_k-y^k|<=k delta. True partial sums lie in [0,log(1/alpha)], so clipping the accumulator does not increase error. Therefore |s_r-sum y^k/k|<=r delta<=delta_log/4. The emitted ell=-s_r has error at most delta_log/2. Exact rational coefficients 1/k use O(log r) bits; alternatively rounded coefficients within delta_log/(4r) add at most delta_log/4. No partial sum exceeds C_0, and no r-wide bank is held.

Perform this twice for x=p and x=1-p, reusing product scratch. The paid log depth is

    O(r[1+log(r/delta_log)]) = O_alpha(log^2(1/delta_log)). (9)

Its width is constant. Choose delta_log sufficiently small, for example mu/64. The ideal ordinary softmax of the two prepared logits differs from (p,1-p) by at most a fixed small fraction of mu, by the bounded binary-softmax Jacobian. This is a deliberate conservative allocation, not a new logarithm complexity optimum.

## 6. Fixed-width norm padding for logits, with zero terminal shift

This section adapts the OLD actual-PreLN compiler from `../standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md`. That source alone proves a probability-register result with nonzero terminal shift. It does NOT by itself establish the ordinary-softmax theorem here.

Store v=(ell_0/C_0,ell_1/C_0), so ||v||^2<=2. Reserve a fixed physical dimension d>=8 large enough for all source, arithmetic, paired output, anchors and scratch registers; it is independent of N,b,G,mu. Using the old paid norm-padding arithmetic, compute

    r_*(v)=sqrt(3d/2-1-||v||^2), |r-r_*|<=kappa.

The relevant radicand is bounded away from zero. The bounded tent-square products and warmup/doubled-precision inverse-square-root Newton circuit of `../mandatory_post_layernorm_20261104_2210/MANDATORY_POST_LN.candidate.v4.md`, Section 5, give depth O(1+log(1/kappa)), fixed width, bounded complete states and coefficients. We import its LOGICAL arithmetic, not its post-LN physical implementation.

After paid clearing, the reference ends at

    z_ref=(v,-v,1,-1,r,-r,0,...,0),
    | ||z_ref||^2/d - 3 | <= C_pad kappa.            (10)

Every logical affine/ReLU/attention microstep, including log, padding and clears, is implemented inside a genuine PreLN block by the old small-amplitude compiler. Pair all rails, replace logical biases by anchor coefficients, initialize h=eta z with eta=2^(-M), and homogenize each overwrite F. With gain-one LN notation its actual residual update is

    z_new=z+s(z)(F(z)-z),
    s(z)=(1+eta^2||z||^2/d)^(-1/2).

The useful attention has its own source-row factors s(z_i); uniform averaging has no prefix-length penalty in max-row norm. On a fixed reference tube, the full-program error recurrence is

    e_l <= L_* e_(l-1)+C eta^2,
    e_l <= C' eta^2 L_*^m,                         (11)

for the entire m-step reference including the new arithmetic. Choose eta so this is <=xi. As in the old compiler, replace each interior gain-one LN by gain two and halve the consuming first FFN/value matrix. This is an exact reparameterization, not another approximation. All actual interior LN shifts are zero. The actual final prepared vector z_tilde is still sign-paired, its anchors are 1,-1 in analytical coordinates, and ||z_tilde-z_ref||<=xi. Approximate scratch clearing is INCLUDED in this full-vector norm error.

Use the OLD stable restoration schedule a_j=2^(j-M), j=0,...,M, with public dyadic k_j approximating sqrt(1+3a_j^2) to error <=tau a_j^2. Each paid ordinary PreLN block implements

    h_(j+1)=h_j+k_j LN_(1,1,0)(h_j),

or equivalently uses gain-two LN and half the branch coefficient. The old recurrence proves, when delta=C_pad kappa+C_norm xi is sufficiently small,

    h_M=r_M z_tilde, |r_M-1|<=3delta+tau.           (12)

Finally apply the ORDINARY full-feature LN_(1,2,0), with ZERO shift, and affine head C_0 P_out, followed by ordinary binary softmax. Unlike the probability-register source, add no pi and impose no probability-bank sum invariant. The extracted logits are

    ell_hat=C_0 g v_tilde,
    g=2r_M/sqrt(1+c r_M^2), c=||z_tilde||^2/d,
    |g-1|<=7delta+2tau.                            (13)

At the reference target c=3,r_M=1 this gain is exactly one. Hence

    ||ell_hat-ell||_2
       <=C_0[2xi+sqrt(2)(7delta+2tau)].             (14)

Select xi,kappa,tau as dyadic positive constants times mu, small enough for (14) and the log error from Section 5 to give binary TV error <=mu/2. Their negative logarithms are O_alpha(1+log(1/mu)). This proves (8).

This is fixed-width nonzero norm padding, of bounded norm because d is fixed. It does not use dimension-dilution, a width growing like 1/epsilon, a free inverse LN, a nonzero final shift, coordinate probability output, or an uncharged nonlinear vocabulary head. The vocabulary head is affine and its C_0 factor is a fixed alpha-dependent operator bound.

## 7. Statistical composition and the genuine read

Stationarity makes the last-b marginal exactly the same stationary rare-family length-b law. Its terminal pair is identically the original terminal pair, so conditioning on A is the SAME-history conditioning in the old theorem. No independent query, conditional-iid count argument or new initial-law assertion is needed.

The old actual-terminal A add-one lemma gives

    E[|r_A-(1-t)| | E_A]
       <=min{1,157/sqrt(1+(b-2)u)}.

The true A probability 1-t lies in [1/4,1/2] and thus in [alpha,1-alpha]. Projection is contractive toward it. Combining (6) and (8) proves (1).

The old mixed-estimator theorem gives

    R(r)<=1300u/sqrt(1+(b-2)u).

The explicit constant 1300 is proved in `../clipped_joint_risk_20261103_2217/clipped_joint_risk_derivation.v2.md`, Section 6: its C contribution is at most 1104u/sqrt(1+(b-2)u), and the A contribution is at most 157u/sqrt(1+(b-2)u). The earlier `../u_blind_full_averaged_20261103_2147/full_averaged_tv_bound_v1.html` supplies the underlying mixed-estimator and conditional-A analysis. This is not a new proof or a new constant. The quantizer changes only A,C and by at most 1/G, so expected error is at most (u+w)/G. Projection onto [alpha,1-alpha] adds at most w(alpha-q)_+: A and B,D targets lie inside, and C is the only possibly excluded target. Equation (8) then proves (2). Since the actual output is itself always in [alpha,1-alpha], conditioning on C proves (3) directly.

The single read is genuinely useful. Ablating its output leaves a recovered packed code within B^(-b)/100 of zero, so continuous plateau decoding returns only missing digits; our declared raw-1 default makes the virtual word all ones. Its final row is D and the mixed reference prediction is 1/2. On an all-zero input word, the intact terminal pair is A, r_A=(b-1)/b>=7/8, and the dyadic quotient is at least 3/4 for G>=8. Its inward-projected prediction is at least 3/4-mu. Apply the same fixed tube, eta and restoration schedule to intact and ablated reference programs. Their actual predictions differ by at least

    1/4-2mu >= 3/16.

This demonstrates usefulness of the implemented read; it is not a one-invocation lower bound or a matching communication protocol.

## 8. Resource ledger and a depth-budget corollary

Let r be the log-series length from Section 5 with delta_log=mu/64. A more explicit sufficient reference length is

    m <= C_alpha [H+b+log^2(b+2)+h(g+1)
                  + r(1+log(r/mu))+log(1/mu)+1].   (15)

The small-amplitude choice and stable restoration require

    M=O_alpha(m+log(1/mu)), D=O_alpha(m+M).

For fixed alpha this is (4). Original packing coefficients need O(H+b+g) bits, including the exponentially small base-B positions. Log/padding coefficients need O_alpha(log(r/mu)) bits. The shrink eta and prescribed public dyadic k_j need O_alpha(m+log(1/mu)) bits. Thus maximum coefficient descriptions are O_alpha(D). No offline constant generation is claimed to have been executed.

For the constant physical/FFN widths, conservative dense accounting is:

- coefficients O_alpha(D), parameter-description bits O_alpha(D^2);
- public scalar positions O(N log N) bits if separately stored;
- rolling all-row state O_alpha(N) real slots, not constant total memory;
- local affine/FFN real work O_alpha(ND);
- one useful dense attention operation O_alpha(N^2); evaluating all dummy attention slots densely gives O_alpha(DN^2);
- explicit attention score/mask storage O(N^2) if materialized; the mask is not free in that implementation.

No trained-weight claim, shared-parameter claim, efficient streaming claim, finite hardware benchmark or optimal parameter precision claim follows.

For example, for N>=8 set b=2^floor(log2(max{8,H})), G=max{16,b}, and epsilon=1/G. Then 8<=b<=N, b is comparable to log(N+1), G is comparable to b, and epsilon<=1/16. Then D=O_alpha(log N), maximum parameter-description bits O_alpha(log N), and

    conditional-A risk <= O(1/sqrt(1+u log N))+O(1/log N),
    overall risk <= O(u/sqrt(1+u log N))
                         +w(alpha-q)_+ +O(1/log N).

The constants 157 and 1300 remain available in (1)-(2); this display only summarizes order. When u log N is small, the conditional bound is correspondingly noninformative. To reach the full-b statistical regime, b must itself grow and its decoding cost and packed-code precision are paid. Taking b=N when N is a power of two, or the largest power of two at most N otherwise, gives b=Theta(N) and a linear-in-N upper decoder depth (up to the other stated terms). It does not give a fixed-width logarithmic-depth full-history statistical theorem.

More generally, solving (4) for a feasible b gives an ACHIEVABLE upper envelope under a depth budget. It does not prove that all fixed-width architectures must obey b<=O(D), or that packing/serial decoding is optimal.

## 9. Separate conditional execution/quantization contract

There are three distinct precisions: the intentional quotient denominator G; parameter descriptions (including eta and k_j); and finite execution error. They must not be identified.

### 9.1 Backend-independent perturbation statement

Each complete physical map has a finite alpha-dependent Lipschitz envelope on the relevant bounded tube. Uniform attention has no additional N factor in that norm. If each physical sublayer incurs adversarial additive full-row error at most delta, and the final ordinary softmax is exact, a conservative bound is

    TV(Q_perturbed,Q_exact)<=C_alpha delta A_alpha^(cD),

with fixed A_alpha>1 and c. Hence delta<=nu/(C_alpha A_alpha^(cD)) suffices for an added risk term nu. This is an error-radius theorem, not a claim that a named dtype satisfies it. It does not assume pairing or exact mean zero survives the perturbations.

### 9.2 A specified conditional fixed-grid evaluator

A stronger but still conditional finite-arithmetic result can be stated for the following evaluator:

1. Use a signed fixed grid of step Delta=2^(-p). Scalar parameters, inputs, and elementary arithmetic results are rounded to nearest grid point with a fixed tie rule, for example ties-to-even. Square root, division, and exp are correctly rounded, or come with a proved absolute error bound <=Delta. Exact zeros, Q=K=0, exp(0)=1 and the causal mask are preserved exactly. Integer/range capacity handles the prefix denominator t<=T and all accumulations without overflow.
2. LN is evaluated by mean, centering, nonnegative squared deviations, variance mean, add-one, certified sqrt and division. Epsilon one keeps its exact divisor away from zero. Fixed-width local substeps then have O_alpha(Delta) error on the fixed tube.
3. The sole useful zero-score attention uses sequential weight/value arithmetic, including the ordinary softmax denominator. Its local error is bounded by O_alpha(T Delta), provided T Delta is small. Dummy sublayers remain charged even if their zero outputs are exact.
4. The final bounded-logit ordinary softmax uses certified exp and division. Its local error is O_alpha(Delta), since its logits and exponentials lie in fixed alpha-dependent compact ranges with denominator bounded below.
5. For an EXACT binary simplex output format, round one computed next-zero probability to the Delta grid, clip that grid value to [0,1], and emit its complement by exact grid subtraction from one. Clipping cannot increase distance from the exact probability and ensures a legal simplex output. This is a declared finite OUTPUT ENCODING, not an inserted exact-real network layer, an unnoticed probability repair, a literal exact softmax output, or a claim that independent rounding of both probabilities preserves mass. All its operations and error are charged. A backend choosing independent output rounding obtains only vector closeness, not a legal-probability TV theorem.

With m computational blocks before restoration, the standard perturbation recurrence from `../preln_precision_analysis_20261105/ANALYTICAL_PRECISION.v1.md` gives

    E_comp<=C_alpha(T+1) A_alpha^m Delta.

The old restoration maps have global product Lipschitz bound <2/eta, including arbitrary nonpaired error. Consequently, after final LN, affine head, certified softmax and the declared output encoding,

    TV(Q_grid,Q_exact)
       <=C'_alpha(T+1)A_alpha^m 2^M Delta.          (16)

A sufficient condition for error <=nu is

    p >= M+m log2 A_alpha+log2(T+1)
                       +log2(1/nu)+log2 C'_alpha. (17)

It also closes the bounded-tube induction when nu is a sufficiently small fixed alpha-dependent constant. Add any independently imposed exact coefficient-storage requirement to (17); approximating coefficients is already charged in its error model. Integer/range bits are O(log T)+O_alpha(1) for the sequential attention sums/denominator and bounded local computations, in addition to the fractional bits. Certified square-root/exp/div implementations and their own bit-operation cost must still be supplied for a concrete machine theorem.

Thus a sufficient fractional-bit ORDER is

    p=O_alpha(D+log N+log(1/nu)),                   (18)

not a universal necessary order or an instantiated machine precision. At b=Theta(log N), G=Theta(b), epsilon=1/G, nu comparable to epsilon, this becomes O_alpha(log N). At general b, it pays the b-dependent decoding/representation sensitivity. Rounded eta collapsing raw-input distinctions cannot be repaired later.

If nu<=mu/2, (8) and (16) also keep the emitted complementary-grid probability in [alpha,1-alpha]. Under that extra inequality, (3) applies to the finite output too, and (1)-(2) acquire only the extra nu term. For larger nu the finite output may remain a simplex point but the exact alpha-floor lower must be weakened to its actually guaranteed range. A statement of small numerical vector error alone is not enough to assert the old exact simplex/range contract.

No evaluator has been instantiated or executed here. Conditions (1)-(5), constants, operation order, intermediate range, parameter conversion, output format and pre-run capture would require separate review before any numerical run. This note supplies an analytical contract and stopping boundary only.

## 10. Dependencies and nonclaims

Direct dependencies read for this derivation:

- `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`: fixed-width suffix packing and paid sequential count decoder.
- `../shallow_readout_audit_20261104_1037/sources/proof.v3.md`: paid lattice comparator/restoring division; this note adds explicit endpoints and zero fallback.
- `../standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md`: small-amplitude ordinary-PreLN simulation and stable fixed-width norm restoration, NOT its nonzero-shift probability readout.
- `../mandatory_post_layernorm_20261104_2210/MANDATORY_POST_LN.candidate.v4.md`, Section 5: logical multiplication/sqrt/norm-padding arithmetic only.
- `../rare_attention_information_bridge_20261106/ONE_READ_RARE_A_STATISTICAL_WITNESS.candidate.v1.md`: the inherited conditional-A statement and source binding.
- `../rare_attention_information_bridge_20261106/ONE_READ_CLIPPED_OVERALL_EXTENSION.candidate.v2.md`: the inherited mixed estimator and projection comparison.
- `../clipped_joint_risk_20261103_2217/clipped_joint_risk_derivation.v2.md`, Section 6: the direct explicit 1300 overall-TV constant, from 1104+157<1300.
- `../preln_precision_analysis_20261105/ANALYTICAL_PRECISION.v1.md`: conditional finite-grid propagation and exact-mass caution.

No novelty search or external literature-priority conclusion was performed. In particular this note does not prove a new statistical law, optimal fixed-width frontier, matching bit lower, finite-bit global impossibility, attention-count lower, trained realizability, executed scientific result, or that arbitrary-alpha resources are uniform.


## Revision 2 record

1. Fixed the public log-series length to its stated ceiling, so the claimed depth is an upper construction rather than a claim about every larger truncation.
2. Made the u-blind budget quantifiers explicit; repaired the b=N power-of-two wording and the G>=16 condition needed for epsilon=1/G in the specialization.
3. Bound the explicit 1300 constant to its direct existing derivation, which was read for this revision.
4. Specified nearest-grid rounding, a fixed tie rule and certified nonlinear scalar operations. Made the finite output encoding explicitly round-then-clip plus exact binary complement. This does not change the exact-real architecture or turn the conditional evaluator into an executed machine certificate.
