# 新 rare one-read transport lower：primary 定理蕴含审计

2026-11-06 UTC。目标为 `RARE_ONE_READ_TRANSPORT.candidate.v1.md` 的 (T)、(R)、(8)–(9)。只作先行工作与方法定位；候选常数及实现语义仍以独立数学审查为准。没有模型运行、数值实验、上传或公开写入。

## 1. 结论

**不是 Mitrophanov 或 Rudolf–Schweizer 所列 theorem 的直接裸参数代入，但其证明主要是标准 regeneration/perturbation、已知 Markov additive variance 和 Lipschitz testing 的 source-specific 组合。** 尤其 covariance 部分可由 Paulin Theorem 3.7 Eq.(3.20) 直接获得同阶结论，不必宣传为新 covariance 方法。

可以保留的窄增量是：针对这一个 rare source、actual terminal-A conditioning、任意位置依赖 bounded vector additive sketch，逐项证明 rare-disagreement coupling 和 endpoint transient，再把 transport closeness 接到付费 decoder 的风险。没有认证该 exact conjunction 的优先权；未完成引用图穷尽搜索。

Hahn 已提供 bounded soft-attention 的单符号 dilution/sensitivity 基础机制，但其 Lemma 5/Theorem 6 不直接给候选的 u-dependent source-average threshold。候选 W1 小也不意味着 exact output KL/TV 小，与 scalar injection兼容。

## 2. 候选对象不可扩大

- 同 stationary order-two source π=(u,w,w,w)，t∈[1/2,3/4]；E是真实terminal pair A，不是独立query；reverse law为从A开始的同源链。
- 一个 actual data-bearing read；其前所有 operations positionwise，所以 synthetic query和terminal residual public。Bounded-score读可化为 augmented numerator/denominator additive sketch，score零是其子类。
- a_i可依位置而变，full-vector norm≤R。维数可变；因此 lower本身不是一个 fixed-width专属结论。
- 之后唯一数据输入是此read及其派生值；后续 paid continuation Lipschitz常数Λ必须包含全部FFN、LN、残差、output head和softmax。不能再读取evolved raw-row memory。
- 目标 risk是conditional A 或乘u后的overall lower。Ordinary bounded-logit overall C-row floor可能更强；不要把这个lower说成已实现vanishing overall rare risk。

## 3. Mitrophanov 2005：直接覆盖的是 marginal perturbation

Primary full PDF：
https://www.cambridge.org/core/services/aop-cambridge-core/content/view/26A9854BCB8D103B3A63A9B272616EC0/S0021900200001066a.pdf/sensitivity_and_convergence_of_uniformly_ergodic_markov_chains.pdf

定位：§2，Theorem 3.1、Eqs.(3.2)–(3.3)，printed pp.1005–1006。已直接核正文。

对象是同状态空间两个homogeneous kernels的 n-step distributions，uniform ergodicity和operator TV perturbation E=\tilde P−P。其telescoping式把初始差异和one-step kernel差异沿ergodicity coefficients传播。不是统计估计loss，不含Transformer、training或storage精度。

**对本候选的蕴含：** common-atom contraction、扰动与mixing的关系为直接先行。仅给P_t、P_s代参数，至多约束pair marginal；这里二者stationary π完全相同，stationary distribution difference本来就是零。它不能仅凭这一点控制路径加法统计的分布，尤其不能直接产出 √(u h/N)。需要构建joint chain并保留路径差值。用更适合的weighted/augmented state将候选写成一般perturbation corollary并非不可能；本审计没有证明这种文献归约不存在。

## 4. Rudolf–Schweizer：Wasserstein 名称不等于路径统计结论

Primary： https://arxiv.org/pdf/1503.04123v3 ，23 February 2017版本；发表记录 https://doi.org/10.3150/17-BEJ938 。定位：§2 Eq.(2.1)、Assumption 2.1、§3.1 Theorem 3.1、Corollary 3.2 Eq.(3.6)、Remark 3.3。直接核完整PDF的对应段。

Theorem 3.1使用Wasserstein ergodicity、Lyapunov function和weighted one-step discrepancy，给n-step distribution的Wasserstein perturbation bound。Corollary 3.2以trivial Lyapunov function给C[ρ^n W(p0,\tilde p0)+(1−ρ^n)γ/(1−ρ)]，Remark 3.3以discrete metric恢复Mitrophanov类TV结果。

**对本候选的蕴含：** Wasserstein/coupling和Lipschitz duality是已知核心工具。原始pair process套用Corollary 3.2，不会自动得到带N^−1/2的additive-functional fluctuation gain。把累计和加入state也不免费：该augmented chain不因原pair chain mixing而自动具备同一uniform ergodicity常数。候选需要另外用shared marginals使difference mean zero，再做variance。此为应写清的归约工作，不是足以支持novelty的“不同任务”借口。

## 5. Paulin 2015/2018：covariance 部分已有直接同阶定理

Primary： https://arxiv.org/pdf/1212.2015v5 ，13 November 2018；论文为 Concentration inequalities for Markov chains by Marton couplings and spectral methods。定位：§3，Theorem 3.7，Eq.(3.20)，PDF printed p.16；proof §5.2。已直接核正文。

该定理对stationary nonreversible chain，pseudo spectral gap γ_ps>0，以及位置依赖f_1,…,f_m∈L²(ν)，给

Var[Σ_j f_j(Z_j)] ≤ (4/γ_ps) Σ_j Var_ν[f_j]。

因此“位置依赖functions”或“nonreversible chain”均不是与它的分离点。向vector extension只需逐坐标求和，若已有full-vector variance bound就没有额外dimension factor。

### 5.1 候选 joint regeneration 自动给适用的 gap

这一步是本审计写出的简单归约，不声称是Paulin印出的特例。设候选joint kernel

C(z,·)=γδ_o+(1−γ)H(z,·), γ=1/4,

stationary lawν满足ν=γδ_o+(1−γ)μ，μ=νH。对任意scalar f，

Var_ν(Cf)=(1−γ)² Var_ν(Hf)
          ≤(1−γ)² Var_μ(f)
          ≤(1−γ) Var_ν(f)。

第一不等式是conditional expectation的variance contraction；第二来自mixture variance identity

Var_ν(f)=(1−γ)Var_μ(f)+γ(1−γ)(f(o)−μ f)²。

于是centered L²(ν) operator norm平方≤1−γ，C* C的spectral gap≥γ，按pseudo gap定义取k=1即可得γ_ps≥γ。

### 5.2 直接代入 additive differences

候选stationary joint lawν具有两个相同marginal π，且p=ν{U≠V}≤40u h。令Y_j=F_j(U_j)−F_j(V_j)，||F_j||≤2R，则EνY_j=0且Eν||Y_j||²≤16R²p。

对每个coordinate使用Theorem3.7，再求和：

E||Σ_j Y_j||² ≤ (4/γ_ps)Σ_j E||Y_j||²
              ≤256mR²p
              ≤10240mR²u h。

与候选常数8320略不同，但同阶完全相同，并保留dimension-free和任意位置依赖。候选的直接common-atom covariance proof取得较好常数是有效的 elementary specialization，不是新general variance theorem。

随后由Jensen得到O(R√(m u h))。Couple非平稳(A,A)起点到stationary joint chain，首次common reset期望O(1/γ)，每期差值bounded，得到O(R) transient。最后除N+1即得(T)的同阶结构。最后两步也是标准regeneration/transient处理。

## 6. 稀有 disagreement 的新增核对究竟在哪里

在candidate的coupling构造给定后，stationary mismatch满足

p ≤ (1−γ)p + Eν[1{U=V} TV(K_t(U,·),K_s(U,·))]。

使用共同stationary marginal π及row perturbation的rare mass得到p=O(u h)，而不是sup-row O(h)。这是此source的有效细化，仍是经典stationarity-weighted perturbation/renewal accounting。

一个简便的辅助推导也说明它不是新的机制：令δ(x)=TV(P_t(x,·),P_s(x,·))，则πδ=uh+w(u/w)h=2uh。由kernel telescoping、TV contraction和πP_t=π，

Σ_x π(x)TV(P_t²(x,·),P_s²(x,·)) ≤2πδ=4u h。

因此同一stationary mismatch不等式甚至给p≤16u h，而candidate的40u h是保守可用常数。此观察无需改candidate常数，也不改变其scope；可作为其rare-factor依赖的独立逻辑检查。**注意：** 不能由π_t=π_s本身就推path laws接近。必须经过真实joint construction和per-step discrepancy。

原candidate若坚持full proof，需保留：同atom的residual maximal coupling确实给所写marginals；joint stationary law存在并具有所需π marginals；π_t=π_s在全部参数区间；odd-N最后pair extension不引入observed future；conditional reversal与F_j重排正确。以上不是通用perturbation论文自动代作者完成的source检查。

## 7. Hahn 的覆盖与非覆盖

Primary： https://aclanthology.org/2020.tacl-1.11.pdf ，Lemma 5、Theorem 6，printed pp.165–167；修正版 https://mhahn.info/files/transformers-proof.pdf ，§S2 Eqs.(34)–(35)。本轮重开核定位。

Lemma5在fixed soft-attention network中将一个非终端符号改变对terminal activation的影响界为O(1/N)，常数依赖parameter matrices。Theorem6再用于指定语言的cross-entropy。不提供本rare unknown-parameter source experiment、W1 sketch law或min{N,√(N/u)} decoder敏感性门槛。

可以从Hahn式pathwise influence加coupled Hamming distance得到一个较粗思路，但直接triangle summing O(Nu h+1) mismatches只给O(R[u h+1/N])。候选的√(u h/N)来自**中心化的加法差值在joint Markov chain上的方差**，不是单token sensitivity原句的直接重述。该方差加强本身已有上节标准工具。

在fixed u、固定条件精度下，把Λ≤M^D倒代得到D=Ω(log N)与大量既有bounded-sensitivity深度结论同阶；候选应强调source-specific u-dependence和完整visible-interface定量式，而不称新的general logarithmic-depth necessity。

修正的Hahn proof包含attention weights变化项。候选用实际numerator/denominator分解控制bounded-score ratio时已经保留该效应；不能引用未修正的单value差项推导任意attention。

## 8. Risk reduction 与最终定位

对于任何共同Λ-Lipschitz F，两个conditional target相差h，triangle inequality和transport coupling给

R_A(t)+R_A(s) ≥ h−ΛW1−2η_A。

这是标准two-target risk reduction；乘同一个terminal probability u然后取max给candidate的u/2。它不是KL contraction或exact-data-processing information loss。若η只无条件控制，conditional化须付1/u，candidate的−ε版本保留此点。

固定h=1/4得到ΛR必须至少常数乘N/(1+√(Nu))才能使conditional risk低于足够小固定阈值；o(u)overallrisk是另一充分要求来调用该lower。这个threshold不是sharp error curve，不证明upper匹配，不下界read次数，也不是固定宽下界。它允许value dimension增长，但收费full norm和decoder sensitivity。

**建议文字：** “使用共同再生耦合、标准Markov variance bound和Lipschitz testing，我们得到一个针对rare family和真实terminal conditioning的一读sketch敏感性必要条件。主要附加工作是同源参数变化下的rare disagreement和endpoint接口核对；不宣称新的通用coupling、Wasserstein或variance方法。”

## 9. 覆盖限度

Mitrophanov、Rudolf–Schweizer、Paulin、Hahn及其correction的指定正文已访问。Publisher的Rudolf–Schweizer PDF wrapper未直接提供正文，改用作者arXiv v3完整PDF，结论按此版本标注。没有使用摘要代替theorem结论。并未穷尽所有Markov perturbation/coupling/variance-reduction文献，未认证创新性。当前主要结论不依赖未访问的文献。
