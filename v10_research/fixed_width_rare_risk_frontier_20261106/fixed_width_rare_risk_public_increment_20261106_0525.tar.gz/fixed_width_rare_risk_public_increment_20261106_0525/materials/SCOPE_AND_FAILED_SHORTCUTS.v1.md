# Scope, failed shortcuts, and remaining gates

6 November 2026 UTC. Companion to `FIXED_WIDTH_RARE_RISK_FRONTIER.candidate.v1.md`. Analytical notes only; no scientific execution or public write.

## Quantifiers: the construction remains u-blind

Alpha, b, G, epsilon and any planned execution tolerance nu are declared public design budgets. The resulting parameters may depend on those budgets and N, but NOT on the source's u,t, its counts, or its realized history. The theorem's bounds then hold simultaneously for all allowed u,t. In particular, b=Theta(log N), G=Theta(b), epsilon=1/G is one u-blind design.

A design calculation such as b of order 1/(u r^2) to make the A conditional statistical term small assumes that u is known. Replacing u by a declared known lower bound rho is another permitted public-budget scenario, but changes the problem assumptions. Neither calculation is an unknown-u adaptive optimum or a universal parameter-selection theorem. When b u is small, the conditional estimate correctly remains weak.

## Shortcuts rejected during this derivation

1. **Reuse the old terminal probability registers as ordinary softmax.** The old standard-PreLN theorem ends with a nonzero shift and a coordinate probability projection. It does not implement logarithms or a zero-shift softmax head. The new candidate pays for logarithms, scales the logits before fixed-width norm padding, and uses a zero-shift gain-two final LN plus an affine logit head and ordinary softmax.

2. **Use increasing inert width to suppress LN distortion.** The prior wide compiler uses d large compared with 1/epsilon. That does not answer a fixed-width question. The new candidate uses the old stable target-variance-three norm-padding/restoration schedule with d fixed; its additional accuracy costs sequential depth and coefficient precision.

3. **Use a large parallel log-hinge bank at no width cost.** The wide log interpolation carries an accuracy-dependent number of hinges. The candidate instead serially evaluates a uniformly convergent logarithm series and pays each approximate multiplication. Its conservative log depth is O_alpha(log^2(1/epsilon)); no logarithmic optimum is claimed.

4. **Apply strict 0<n<d division to the C branch.** C can have n=0, n=d, or d=0. The candidate separately handles the endpoint equality and replaces only a zero denominator by the public lattice unit. It retains the zero-fallback unsmoothed C estimator. Replacing C with add-one would be a different estimator and cannot inherit the old mixed bound without proof.

5. **Give exact alpha range to an approximate implementation without a margin.** Approximating alpha-clipped probabilities alone permits excursions outside [alpha,1-alpha]. The candidate first clips inward by mu and makes the implementation error at most mu/2. This pays an additional at-most-mu approximation term, including the endpoint case alpha=1/4. Only then may the exact alpha range floor be asserted for the physical model.

6. **Assume ablation returns the wide model's empty-count default.** A zero packed code decodes missing digits that are converted into a complete virtual default word. The candidate declares raw-1 defaults and proves its ablated reference word is all ones, hence fair on D. The intact all-zero word then witnesses usefulness. Both reference programs must be in the common bounded tube used to choose eta.

7. **Turn coefficient bits into a hardware guarantee.** Packed digits require b-scale precision, and PreLN eta/restoration parameters depend on the ENTIRE reference depth, including h log G and the log-arithmetic stages. Maximum descriptions are safely O_alpha(D). Executing that network requires a separate model of input conversion, rounding, accumulators, sqrt/exp/division, output encoding and range. No named hardware/backend has been certified.

8. **Turn an additive state-error radius into a finite-state lower bound.** A radius is an accuracy guarantee, not automatically an alphabet size or transcript capacity. The candidate states both a perturbation-radius corollary and a separate conditional fixed-grid evaluator. Any comparison with a finite-bit lower needs the actual charged state/communication contract, not merely the letter p.

9. **Treat independently rounded softmax coordinates as an exact simplex.** They need not sum to one. The optional conditional evaluator declares a binary complementary-grid output encoding, which is charged separately from the exact-real ordinary-softmax architecture. Without that encoding or another independently proved format, only vector closeness is established.

10. **Infer an architecture-wide memory-depth optimum.** Serial packed decoding costs O(b) in this construction. That is an upper construction cost, not proof that every fixed-width architecture can use at most O(D) useful observations. Neither this note nor the scalar injection obstruction proves a matching risk-depth frontier.

## What is completed, and what is not

Completed analytically, subject to independent review: explicit reference estimates on all rows; fixed-width endpoint-safe dyadic quotient; fixed-width paid log arithmetic; ordinary zero-shift final-LN+softmax compilation with exact alpha range; statistical composition on the actual terminal event; sufficient depth/coefficient/execution-error ledgers.

Still required before a concrete numerical test: a complete instantiated register layout and parameter bundle, chosen alpha/b/G/epsilon/nu, actual constants, a frozen evaluator implementing the declared contract, conversion/range/rounding proof, compiler bitwork and transcendental-operation costs, exact capture schema, independent pre-run review. No such run is authorized or performed by these notes.

Still research questions: a tight risk-depth frontier at fixed width; optimal precision and communication charges; sharper paid logarithm complexity under the same envelopes; useful adaptation to unknown rarity without source-dependent budgets; a same-contract lower that matches this construction. These are not silently promoted to theorems.
