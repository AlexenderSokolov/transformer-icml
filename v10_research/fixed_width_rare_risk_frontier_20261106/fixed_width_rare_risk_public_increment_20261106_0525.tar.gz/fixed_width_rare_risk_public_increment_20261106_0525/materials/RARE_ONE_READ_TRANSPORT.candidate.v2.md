# A rare-source transport bound for a paid one-read decoder

Private analytical candidate revision 2, 6 November 2026 UTC. Revision 1 is preserved. This revision explicitly distinguishes one head from parallel heads, supplies the complete multihead norm ledger, and adds the same-source terminal-context coverage boundary. Exact-file independent review is required. No experiments, source simulation, upload, publication, or parameter-generation run. This is a one-actual-read sensitivity threshold, not a sharp fixed-width risk frontier or a repeated-attention theorem.

## 1. The source and the observation are unchanged

Use the stationary binary family already fixed in the rare-information notes. The pair states are A=00, B=01, C=10, D=11, with

    pi=(u,w,w,w), w=(1-u)/3, q_t=ut/w,
    P_t=[[1-t,t,0,0],[0,0,1/2,1/2],
         [q_t,1-q_t,0,0],[0,0,1/2,1/2]],
    0<u<=1/100, 1/2<=t<=3/4.

Let E={X_(N-1)=X_N=0} be the ACTUAL terminal event of the same trajectory, N>=3. Its probability is u for every t. The target next-one probability on E is t. Reversal of a stationary symbol trajectory conditional on E is exactly the same source initialized at A, as proved in RARE_TERMINAL_PARITY_INFORMATION.candidate.v2.md. This observation handles the terminal conditioning; no unconditional comparison is divided by u.

For any publicly fixed functions a_i:{0,1}->R^k with ||a_i(x)||<=R, define

    Z(X)=[a_*+sum_(i=1)^N a_i(X_i)]/(N+1),

where a_* is public. The dimension k can grow, and all norms here are full Euclidean norms. Positions can enter a_i arbitrarily. This covers one public-query, single-head actual bounded-score read via its weighted numerator and denominator, but not a later read from data-dependent memory. A simultaneous multihead extension with explicit aggregate costs is stated in Section 6.1.

Put m=ceil(N/2), h=|t-s|. Then there is a coupling of the terminal-conditioned experiments satisfying

    E ||Z(X^t)-Z(X^s)||
      <= R[32+sqrt(8320 m u h)]/(N+1).                 (T)

Thus (T) bounds their Wasserstein-1 distance. It does NOT bound exact KL or TV. In particular the exact scalar injection remains compatible with (T).

## 2. A uniform joint regeneration with rare disagreements

Write K_t=P_t^2. Directly,

    K_t(x,D)>=1/4 for every x and t.

Choose gamma=1/4 and define residual kernels

    H_t(x,.)=[K_t(x,.)-gamma delta_D]/(1-gamma).

Construct a joint kernel C for a t-chain and an s-chain as follows. With probability gamma, put both next states at D. Otherwise couple H_t(x,.) and H_s(y,.); if x=y use a maximal coupling. Each marginal is exactly K_t or K_s, and C has the common atom gamma delta_(D,D), including from off-diagonal states.

The elementary two-step difference bound is

    TV(K_t(x,.),K_s(x,.)) <= 2h 1{x=A}+8u h.        (1)

To verify it without a matrix calculation, write P_t^2-P_s^2=(P_t-P_s)P_s+P_t(P_t-P_s). The single-step row TV is h at A, (u/w)h at C, and zero at B,D. Here u/w<=100u/33, and q_t<=25u/11. For x=A the two terms sum to at most h+(1-t)h<=3h/2. For x=B,D they sum to at most (u/(2w))h. For x=C they sum to at most (u/w+q_t)h<6u h. These imply (1).

The finite joint chain C has a stationary law nu; the common atom makes it unique. Its marginals are pi because each marginal chain has the unique stationary law pi. If p=nu{x!=y}, then the coupling construction gives

    p <= (1-gamma)p + E_nu[1{x=y} TV(K_t(x,.),K_s(x,.))]
      <= (3/4)p + 2hu+8uh.

Consequently

    p<=40u h.                                         (2)

No false independence between the two parity subsequences is used. This is a coupling of two different parameter laws on the ORIGINAL pair chain.

## 3. The stationary additive-difference variance

Group the REVERSED symbol positions into consecutive pairs. Let F_j denote the sum of the one or two a_i terms assigned to pair j. The last group has one term if N is odd, and the source may be extended one unobserved symbol to define that final pair. Thus ||F_j(x)||<=2R for every j,x. The public a_* cancels.

Run the coupled pair chain in its stationary law nu, and put

    Y_j=F_j(U_j)-F_j(V_j).

The two pair marginals equal pi, so E Y_j=0 even though F_j varies with position. Moreover

    ||Y_j||<=4R 1{U_j!=V_j},
    E||Y_j||<=4Rp,
    E||Y_j||^2<=16R^2p.                              (3)

The common joint atom gives TV(C^l(z,.),nu)<=(3/4)^l. For j<k, vector-valued duality therefore gives

    ||E[Y_k | (U_j,V_j)=z]|| <=8R (3/4)^(k-j),
    |E <Y_j,Y_k>| <=32R^2 p (3/4)^(k-j).             (4)

The factor eight safely accounts for the two-probability-measure convention for TV and the bound ||Y_k||<=4R. Sum (3)-(4), using sum_(l>=1)(3/4)^l=3:

    E||sum_(j=1)^m Y_j||^2
      <=(16+64*3)mR^2p
      <=8320mR^2u h.                                 (5)

This full-vector estimate has no coordinatewise dimension factor. It uses shared stationary marginals and joint regeneration, not an iid variance formula.

## 4. The actual terminal initialization costs only a constant transient

Under E, reversal starts both compared pair chains at A. Run C from (A,A). Couple this joint chain with its stationary version using the same regeneration coin, and set their future paths equal after the first common reset to (D,D). Their expected number of differing time indices, including the initial index, is at most 1/gamma=4.

At any index the two versions of Y_j differ in norm by at most 8R. Therefore

    E||sum_j Y_j^(A,A)-sum_j Y_j^stationary||<=32R.  (6)

Combining (5), Jensen, and (6), then dividing by N+1, proves (T). The transient does not depend on u, h, or N. It is deliberately loose; h=0 can instead use the identical-path coupling.

## 5. Paid decoding, approximate interfaces, and actual risk

Let F be one fixed map on the reached sketch set into binary probability distributions with

    TV(F(z),F(z'))<=Lambda ||z-z'||.

Let Q be the actual predictor. Suppose its approximation error to this interface obeys

    sup_t E_t[ TV(Q(X),F(Z(X))) | E ] <= eta_A.       (7)

No worst-history approximation is required. Denote its full actual-terminal risk by R_t(Q). For every pair t,s at distance h,

    max{R_t(Q),R_s(Q)}
      >= (u/2)[h-Lambda R(32+sqrt(8320muh))/(N+1)-2eta_A]_+.
                                                               (R)

Proof: the two conditional target probabilities are t and s. Under the coupling of Section 4, triangle inequality gives

    E_t[|Q(1)-t||E]+E_s[|Q(1)-s||E]
      >= h-E|F(Z^t)(1)-F(Z^s)(1)|-2eta_A.

Use (T), then R_t(Q)>=u E_t[|Q(1)-t||E], and take the maximum. This is source-average risk at the real terminal, not a worst-history decoder-separation argument.

Alternatively, if the error in (7) is bounded only UNCONDITIONALLY by epsilon under every t, then the safe bound is

    max{R_t(Q),R_s(Q)}
      >= (u/2)[h-Lambda R(32+sqrt(8320muh))/(N+1)]-epsilon,

capped below by zero. Conditioning error cannot be left at epsilon without paying the factor u.

## 6. Application to one real single-head bounded-score attention read

All preceding operations must be positionwise, so the synthetic terminal query and pre-read state are public. Subtract its fixed self score. If the score range is at most S and full values have norm at most V, write

    a_i(x)=(exp(s_i(x)-s_* )v_i(x), exp(s_i(x)-s_*)),
    R=exp(S)sqrt(V^2+1), k=d+1.

The final scalar self weight and self value are public. The numerator-denominator sketch has z>=exp(-S), and each genuine attention output o=n/z has norm at most V. On two reached sketches,

    ||n/z-n'/z'|| <= exp(S)(1+V)|| (n,z)-(n',z') ||.

If the complete paid terminal continuation G is L-Lipschitz from head-output Euclidean distance to binary TV, take

    Lambda=L exp(S)(1+V).

It includes the output projection, residual processing, every FFN/LN, and the actual final head. Positive-epsilon full-feature PreLN is allowed because all pre-read row states remain local functions of their raw symbol and public metadata. An exact injection is allowed; no inverse is granted for free.

Set t=1/2,s=3/4. For an exact interface eta_A=0, (R) gives a nonzero rare-event risk threshold whenever

    L <= c N/(1+sqrt(Nu))

for a sufficiently small constant c depending on S,V. In particular, risk o(u) requires

    L >= c' N/(1+sqrt(Nu))
      = Omega(min{N,sqrt(N/u)}).                    (8)

If a fixed primitive envelope gives L<=C_0 M^D, M>1, this implies only

    D >= log_M[N/(1+sqrt(Nu))]-O(1).                (9)

A coefficient-description length is not used as an activation precision. Width does not appear in (8): the estimate is full-vector and dimension-free. Wide one-read O(log N)-depth constructions have sufficiently large polynomial L and are not excluded.

For a quantized actual head output with Euclidean error at most delta before the same L-Lipschitz G, set eta_A<=L delta. For d coordinates rounded with step zeta and no overflow, delta<=sqrt(d)zeta/2. This is an interface error assumption, not a theorem about finite arithmetic throughout all layers. Its error term weakens (R); it cannot be relabeled a precision lower by itself.

### 6.1 Parallel heads require an aggregate bound

If H heads read in parallel from the same pre-read local states and each query is public, concatenate the H weighted numerators and H denominators. If head h has full value bound V_h and all head score ranges are at most S, the full local augmented vector has bound

    R_H=exp(S)sqrt(sum_(h=1)^H V_h^2+H).

For the concatenated ratio outputs, a valid Lipschitz factor is exp(S)(1+max_h V_h). Thus (T) and (R) apply with R replaced by R_H and Lambda replaced by L exp(S)(1+max_h V_h), where L is the paid continuation bound in the full concatenated Euclidean norm, including the output projection. Both H and the total value dimension are charged. Merely per-head bounds do not make R_H constant when H grows. This extension permits one simultaneous physical attention layer; it does not permit sequential reads with data-dependent queries, intermediate memory mixing, or an uncharged later reread.

## 7. Coverage and limitations

The direct predecessor ingredients are bounded-score additive-sketch factorization, paid decoder sensitivity, the rare family's reversal and uniform two-step atom, and elementary regenerative covariance control. The old one-invocation rate lower uses a DIFFERENT stationary lag-two family and cannot simply be claimed on this rare subfamily. Conversely, for minimax risk over all stationary second-order sources its inverse-square-root depth theorem is much stronger than the logarithmic threshold (9). This result therefore does not improve that established global frontier.

For the current rare source the derivation adds a source-specific transport calculation and preserves actual terminal conditioning. It does not prove the desired sharp joint N,D,W,precision rate, a matching construction, an advantage of repeated reads, or a new general expressivity result. No literature novelty claim follows from this internal dependency comparison.

There is also a stronger same-source overall-risk obstruction using the OLD late-token mechanism. Conditional on a prefix ending in symbol 1, the last observed bit is fair; its two values lead to terminal C and D, whose target probabilities differ by g_t=1/2-q_t>=21/44. A one-head change of that sole last raw token changes the head output by at most 4V exp(S)/(N+1). Hence overall risk is at least w[g_t-4V exp(S)L/(N+1)]_+, as proved in TASK_DIRECTED_PRECISION_AND_COVERAGE.candidate.v1.md, Section 4. Thus overall low risk already requires L=Omega(N), which dominates (8). The new calculation retains a narrower content on the conditional-A task, where both compared terminal pairs are fixed at A and this context-acquisition distinction is absent. It is not a new main depth frontier.

Under a uniformly bounded final ordinary-softmax logit contrast, overall risk already has a C-row output floor. That separate obstruction can dominate (R) as u tends to zero; conditional-A claims must not be presented as a vanishing overall-risk theorem.

Read dependencies: rare_statistical_resource_reset_20261106/RARE_TERMINAL_PARITY_INFORMATION.candidate.v2.md; rare_attention_information_bridge_20261106/EXACT_PRELN_INFORMATION_OBSTRUCTION.candidate.v2.md; one_invocation_rate_lower_20261104/BOUNDED_SCORE_RATE_EXTENSION.candidate.v1.md; stationary_one_invocation_20261105/STATIONARY_ONE_INVOCATION_LOWER.candidate.v2.md. This proof supplies all new coupling and variance steps explicitly.
