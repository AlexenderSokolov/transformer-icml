# Independent exact-file audit: fixed-width rare prediction and ordinary softmax

6 November 2026 UTC.

Reviewed target: `FIXED_WIDTH_RARE_RISK_FRONTIER.candidate.v2.md`.

Target SHA-256: `6b86cc7eef0470f6d7156169788681df45c7d175bb1936231f0fccef6209905c`.

The complete v1 was read and analyzed, then the complete v1-to-v2 text diff was inspected and the v2 file hash freshly checked. Preserved v1 SHA-256: `7e389b9a11cc73b2ec0c7377f815350f31c77c2cf5841c9e328edc017e171723`.

Revision 2 correctly resolves the review's source/domain clarifications: the precise Taylor truncation ceiling, direct explicit-1300 source, source-independent budget quantifiers, power-of-two full-suffix convention, the G>=16 specialization boundary, and the conditional nearest-grid/clipped-complement output contract. Its explicit b=2^floor(log2(max{8,H})) choice obeys 8<=b<=N for N>=8 and is comparable to log(N+1).

## Verdict and scope

PASS for the exact-real fixed-width one-useful-read construction, its two displayed risk upper bounds, and its exact physical alpha-range lower bound. The separately stated finite-grid result passes only as a conditional evaluator/error-contract theorem. It does not certify a concrete fixed-point program, arithmetic implementation, parameter bundle, hardware format, or run.

This review used source reading, analytical derivation, text comparison, and checksum bookkeeping only. No scientific experiment, numerical fixture, parameter generation, model execution, training, upload, or public write was performed. Historical execution evidence for dependencies is not attributed to this composition.

The accepted new connection is a fully paid constant-width ordinary-PreLN and ordinary-vocabulary-softmax implementation of the inherited suffix statistical estimates, with a declared fixed output range. It is not a new statistical rate, a matching lower frontier, or a novel mechanism claim.

## 1. Packed suffix and all-row reference domains

The inherited binary packing has B=16, one scalar full-prefix uniform read, and error below B^(-b)/100 before sequential plateau decoding. The paid prefix-denominator multiplication and its H doublings are included. Its last b digits correspond to exactly the actual suffix at the synthetic terminal; at every earlier row they correspond to available suffix digits followed by missing digits. Changing only the counting default for a missing digit to raw symbol 1 does not change the weighted digit subtracted from the residual. Thus the resulting virtual word is legal on every row, without a free raw-history or suffix port.

The b sequential count updates produce an exact 1/Q lattice in the logical reference, where Q is the next power of two at least b+2. The total count mass is (b-2)/Q<1. Retaining both lag onehots makes the final pair internal to the same read/decoder. Both A and C count rows can be projected from a fixed-size binary table independently of the selected final pair. This only changes fixed full-state and operator factors, not width dependence on b.

These are statements about the continuous logical reference on legal raw histories. The physical normalized simulation need not preserve its lattice, onehots, zero denominators, or exact clears. The full-program Lipschitz comparison, rather than an unjustified exact-bit argument for the perturbed network, handles that difference.

## 2. Division endpoints and the zero fallback

The old restoring proof required 0<n<d. The candidate supplies the missing closed-endpoint proof instead of silently importing that premise.

For the exact delta lattice, z=H_delta(-d) is one exactly when d=0. Hence d'=d+delta z is positive and n<=d'<=1. Next e=H_delta(n-d') is the equality indicator because n<=d'. The ReLU gate max(d'+e-1,0) equals e d'. Consequently the initialization r=n-e d', f=e has 0<=r<d', including n=d' and d=0. At the upper endpoint the initialized f is one and every subsequent bit is zero. At the zero denominator n=0,d'=delta, the entire quotient remains zero.

Each binary step compares the correct delta-lattice value 2r-d', including ties, subtracts precisely the gated denominator, and leaves 0<=r<d'. The standard invariant gives floor(G n/d')/G below the upper endpoint and exactly one at the upper endpoint. The displayed C formula is therefore correct, including its genuine zero-count fallback. A uses add-one while C does not: no hidden C pseudocount appears.

The depth O(hg) pays all comparisons, with h bounded doubling stages per comparator and constant scratch. No count-sized integer, floor, reciprocal, or equality oracle is a primitive. The two scalar errors are each at most 1/G. Because B and D remain exactly fair before compilation, the overall expected quantization cost is correctly (u+w)/G, not a mistakenly rare-weighted bound for all rows.

## 3. Exact range and the inward-clip bias

The candidate reserves mu in (epsilon/4,epsilon/2] and projects the quantized probability to [alpha+mu,1-alpha-mu]. Relative to projection onto [alpha,1-alpha], this costs at most mu. Physical compilation is then allocated only mu/2. Their sum is at most 3epsilon/4, so the final epsilon in both upper bounds legitimately includes the inward bias.

This is necessary even on A: when alpha=1/4, the true next-zero probability can be exactly 1/4, so the inward projection need not be contractive toward that target. The proof does not make that mistake. It compares first to alpha projection, which is contractive on A, and then pays mu separately.

The physical next-zero probability lies in [alpha+mu/2,1-alpha-mu/2] on every physical row and legal history. Thus it lies in the exact requested range. Conditional on terminal C, every such prediction has error at least (alpha-q)_+, and stationarity weights this by w. This proves the displayed lower bound in the same realized-range contract as the upper, unlike the earlier wide approximation whose sharp physical range was not established.

The lower is a range obstruction. It is not by itself a tight statistical or architectural minimax lower for the entire displayed upper envelope.

## 4. Fixed-width paid logarithms

For x>=alpha and y=1-x, the geometric-series tail is at most (1-alpha)^(r+1)/((r+1)alpha). The chosen logarithmic r makes it at most delta_log/4. The fixed-width clipped power recurrence has |v_k-y^k|<=k delta. The kth sum contribution therefore differs by at most delta, so the total serial sum error is at most r delta. Clipping the running sum to [0,C_0] cannot enlarge error because every true partial sum lies in that interval.

With delta<=delta_log/(4r), the log error is at most delta_log/2. Two serial copies reuse scratch. The r multiplications, each with depth O(log(r/delta_log)), give O_alpha(log^2(1/delta_log)) paid depth. No r-wide probability/logarithm bank, free multiplication, or free logarithm is inserted.

All intermediate values and primitive norms are bounded by alpha-dependent constants. The rational coefficient 1/k costs O(log r) description bits; its magnitude does not grow. The optional rounded-coefficient route must retain its additional error allocation, as stated. The dependence on alpha is explicit and not uniform as alpha tends to zero.

## 5. Zero-shift final LN, full norms, and constant width

The logit bank is scaled to v=(ell_0/C_0,ell_1/C_0), so ||v||^2<=2 regardless of epsilon. This permits the old fixed-width logical padding computation r_*(v)=sqrt(3d/2-1-||v||^2) with d fixed and sufficiently large. For d>=8, the radicand is at least nine. The old bounded square and inverse-square-root Newton modules therefore operate on their certified compact domains. Their arithmetic is compiled microstep by microstep, not imported as a free nonlinear layer.

The prepared reference is fully sign-paired, includes the retained anchor and padding pairs, and clears all other logical registers through paid overwrites. Its full variance is 3 up to O(kappa). Approximate physical clearing is included in the complete-vector xi error, so no unnormalized scratch mask is being used.

For a homogeneous logical overwrite F, the gain-one notation gives z_new=z+s(z)(F(z)-z), with local defect O(eta^2). The useful attention has separate source-row factors, but averaging is a max-row-norm contraction; no hidden N or sqrt(N) factor appears. A common fixed reference tube gives the stated L_*^m propagation. Halving consuming maps when changing gain one to gain two is exact. All actual interior shifts remain zero.

The public norm-targeted restoration schedule, including its dyadic k_j approximation, has O(M) paid blocks and restores the direction up to the old 3delta+tau bound. With final epsilon-one gain-two zero-shift LN, the extracted logit bank is C_0 g v_tilde, where g=2r_M/sqrt(1+c r_M^2). At c=3,r_M=1, g=1 exactly. The stated derivative bound yields the displayed logit error and permits the mu/2 softmax allocation.

There is no probability-bank offset, probability-coordinate projection, inverse-LN oracle, or accuracy-dependent width dilution. The vocabulary head is the fixed-alpha affine projection C_0 P_out. All physical values, full biases, complete hidden states, and matrix/operator norms are bounded in the fixed-alpha envelope. A standard full-width head and its FFN intermediate layout remain fixed-width. Total all-row memory still grows linearly with N.

## 6. Statistical composition, blindness, and usefulness

Stationarity makes the last-b marginal exactly the same length-b rare-family law, with the identical actual terminal pair. Hence both conditional and overall old estimates apply with b-2 observed transitions. No independent terminal query, conditional-binomial argument, arbitrary-start extension, or missing terminal-state weighting is introduced.

The 157 conditional estimate is inherited from the same-history reverse-chain add-one proof. The explicit 1300 constant is justified by the separate clipped-joint-risk derivation: the C contribution is at most 1104u/sqrt(1+nu), and the A contribution at most 157u/sqrt(1+nu). Their sum is below 1300. The original full-averaged file alone states an unspecified universal overall constant, so the explicit-constant dependency must be retained.

Projection onto [alpha,1-alpha] cannot worsen A or fair-row error. The only possible target outside the interval is q at C, and its added error is at most (alpha-q)_+. Together with the weighted quotient error and inward/physical allocation, this proves the two displayed upper bounds for the same network.

Every parameter is determined by public N,b,G,epsilon,alpha and the fixed binary architecture, not unknown u,t. The source family informs the fixed fair B,D rows but supplies no unknown numerical parameter or terminal context port.

The default-symbol choice matters for usefulness. Ablating the read decodes an all-raw-one virtual word and therefore returns the fair D reference. The intact all-zero word has A next-zero add-one value (b-1)/b>=7/8. G>=8 leaves the floor quotient at least 3/4. Inward clipping leaves at least 3/4-mu, and the two physical errors total at most mu. The separation is consequently at least 1/4-2mu>=3/16. The common compilation constants can cover intact and ablated reference programs because both have the same bounded legal domains. This proves usefulness, not an attention-count lower bound.

## 7. Depth and description accounting

The terms H+b+log^2(b+2) pay packing/decoding and its source interpolation. The h g term pays the two serial divisions. The log-squared epsilon term pays the two serial logarithms. Padding is logarithmic in its tolerance and is dominated. Small-amplitude simulation and restoration have M=O_alpha(m+log(1/mu)), so the stated total D follows without suppressing restoration or clearing.

The shrinking eta and prescribed k_j coefficients inherit this full m dependence. Therefore O_alpha(D) is a justified maximum coefficient-description upper bound, rather than the older sharper description bound that would omit the new log-squared arithmetic depth. Constant-width untied dense parameters then cost O_alpha(D^2) description bits. This is storage/output size, not a compiler bit-operation theorem.

The b comparable to log N specialization with G comparable to b and epsilon=1/G has D=O_alpha(log N). The conditional statistical term can vanish for fixed u; the overall fixed-alpha floor generally remains. The depth-budget result is achievable only. It does not show b<=O(D) for arbitrary algorithms, optimal packing, or an optimal fixed-width risk curve.

## 8. Execution-error contract versus an actual fixed-point result

The backend-independent adversarial sublayer error recurrence is valid with full-vector positive-epsilon LN Lipschitz bounds. It does not rely on pairing surviving numerical errors. Its p=-log_2(error radius) interpretation must remain distinct from word length or coefficient bits.

The stronger Section 9.2 is conditional on explicit per-scalar absolute-error guarantees, exact zero query/key maps and mask semantics, sufficient integer range, nonnegative variance calculation, certified sqrt/exp/division, and the specified sequential attention arithmetic. At fixed width, local arithmetic costs O_alpha(Delta) error; the one sequential attention reduction costs O_alpha(T Delta). A max-row recurrence gives the stated computational error.

Each restoration map has Lipschitz constant at most 1+k_j<=2(1+a_j^2) on the full feature space, including nonpaired errors. The geometric product is below 2/eta. Local restoration roundoff is amplified by the same geometric factor and is absorbed by the stated constant. Final LN, affine head, and bounded-logit binary softmax have fixed-alpha Lipschitz envelopes. Thus the displayed sufficient p bound and its O_alpha(D+log N+log(1/nu)) order are supported under the stipulated evaluator contract.

The complementary-grid output encoding is an explicitly changed finite output representation. It makes the emitted pair a genuine simplex point; independent rounding of both softmax probabilities would not do so. If nu<=mu/2, the clean range margin also protects the finite alpha interval. The final round and exact complement operation must stay in the error budget. The main exact-real network still ends in ordinary softmax; the finite result must not be described as literal unrounded softmax output or as an already implemented backend.

Missing for an actual machine theorem are instantiated constants and layout, operation ordering and certified transcendental routines, rounded parameter and input formats, intermediate range and overflow proof, bit-operation costs, and independently reviewed execution capture. None has been run or is claimed by this audit.

## 9. Failed routes and corrections retained

- Reusing strict-input restoring division for C without endpoint and zero-denominator handling would fail. The candidate's explicit guard and initialization repair it.
- Reserving inward clipping but charging only physical implementation error would understate risk. The candidate pays both within epsilon.
- Reusing the wide broadcast's ablated uniform fallback for packed decoding would fail. The candidate declares the missing-digit default and proves its own witness.
- Appending the old nonzero-shift probability-register readout would not give the requested ordinary softmax architecture. Scaling bounded logits, paid norm padding, zero-shift final LN, and the affine vocabulary head supply the needed separate argument.
- Taking accuracy-dependent zero padding would invalidate the claimed fixed width. The construction uses bounded nonzero padding in one fixed dimension instead.
- A bounded error-radius or coefficient-description result is not an actual finite-word execution certificate. The finite claim remains conditional and charges complementary output encoding explicitly.

No remaining mathematical blocker was found for the accepted scope.

## 10. Fresh dependency bindings

The following local source files were read for this review and their hashes were freshly checked. These bind sources; they do not attribute old numerical runs to the new theorem.

- `../terminal_width_suffix_20261104_2003/CONSTANT_WIDTH_CONSISTENCY.candidate.v3.md`: `ea1c3788f4eed06ccba9e19db3ee0d9a3e792bda7d3d620c0326cc4a07cecbb6`.
- `../shallow_readout_audit_20261104_1037/sources/proof.v3.md`: `10ade8f417465969b2e5b10cafe9803b0964629bd3aec251bc657243d8842b76`.
- `../standard_preln_20261104_2344/STANDARD_PRELN.candidate.v2.md`: `b71f919d6ad1f9c5038270090a3ca724b4e7cb7f9074ecf060433a1961b737e5`.
- `../mandatory_post_layernorm_20261104_2210/MANDATORY_POST_LN.candidate.v4.md`: `2a9a322d685c1b1056dea56e957e6985d559f088f8a5e4fc0d9a98d9f725b5d4`.
- `../u_blind_full_averaged_20261103_2147/full_averaged_tv_bound_v1.html`: `459d6d842bc9d9d4c3df89a41891818bd967ab50cf9da1a84055dc76f587e049`.
- `../clipped_joint_risk_20261103_2217/clipped_joint_risk_derivation.v2.md`: `c43fce2854885c52a2f107bae106ee4ac67e6f6c63a29b6fae7919ec5b59055f`.
- `../preln_precision_analysis_20261105/ANALYTICAL_PRECISION.v1.md`: `2a955a2d0fb72220c3d6a6b5ab9ac7a379dfa2ff987df4bab6d4a352e17b6c92`.
