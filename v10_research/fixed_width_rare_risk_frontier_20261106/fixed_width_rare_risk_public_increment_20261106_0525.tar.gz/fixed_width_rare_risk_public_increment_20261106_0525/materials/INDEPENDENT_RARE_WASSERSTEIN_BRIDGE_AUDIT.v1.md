# Independent exact-file audit: rare-source one-read transport bridge

6 November 2026 UTC. Analytical review only. No scientific experiment, source simulation, model run, parameter-generation run, upload, purchase, or public write was performed.

## 1. Exact target and verdict

Reviewed file:

`RARE_ONE_READ_TRANSPORT.candidate.v1.md`

SHA-256:

`1a641f0c4f10e0b0f1c907e487c946ad3a6a6383e7521cf6f13f33bcb014fccd`

Verdict: **PASS for the stated additive-sketch transport and actual-terminal risk inequalities.** The constants 40, 8320, and 32 are valid, deliberately loose constants. The bounded-score application is justified for one head with a public terminal query and positionwise pre-read processing. Its scope should explicitly say single-head; a multihead extension must retain the full concatenated numerator/denominator norm and the complete decoder cost.

The proof gives a necessary paid continuation sensitivity of order

    N/(1+sqrt(Nu)) = Theta(min{N,sqrt(N/u)})

for sufficiently small fixed rare-conditional error. It does not give sqrt(N)/u, a sharp statistical risk frontier, a rounded-arithmetic precision lower bound, an arbitrary-attention lower bound, or a benefit of repeated reads. The review independently reconstructs the joint coupling rather than inferring joint mixing from two individually mixing chains.

## 2. Source and actual terminal conditioning

The source has pair states A=00, B=01, C=10, D=11 and

    pi=(u,w,w,w), w=(1-u)/3, q_t=ut/w.

Its stationarity can be checked directly: the A flow is u(1-t)+wq_t=u; the B flow is ut+w(1-q_t)=w; both C and D receive w/2+w/2=w. This stationary law is independent of t.

Reversal of the stationary raw-symbol trajectory is the same order-two source. For example the two nontrivial reversed triple flows are pi_A t=ut=pi_C q_t and pi_B/2=pi_D/2; the remaining triples are self-reversing or have the same equality. Equivalently, reverse the stationary pair chain and interchange B and C. Thus conditioning on the actual final two symbols 00 gives a reversed source initialized at A, exactly, with no parameter-dependent initialization and no approximation by stationarity. The event has probability u under both parameter laws.

This is essential: an unconditional sketch bound cannot simply be asserted after conditioning, and an unconditioned interface error must pay the rare-event factor when used conditionally.

## 3. Joint regeneration and stationary mismatch

Write b=u/w and h=|t-s|. The two-step kernels are

    K_t(A,.)=((1-t)^2,t(1-t),t/2,t/2),
    K_t(B,.)=K_t(D,.)=(bt/2,(1-bt)/2,1/4,1/4),
    K_t(C,.)=(bt(1-t),bt^2,(1-bt)/2,(1-bt)/2).

Every row has at least mass 1/4 at D. For A this is t/2>=1/4; for B and D it is exactly 1/4; for C it is (1-q_t)/2>1/4 on the stated parameter rectangle.

Subtract this SAME endpoint atom, and use one shared Bernoulli reset coin for the joint chain. On a reset both coordinates become D. Off reset use any coupling of the residual rows; use a maximal residual coupling whenever the current coordinates are equal. This is a time-homogeneous Markov kernel on the 16 pair-of-pair states. Its marginals are exactly K_t and K_s, and the joint kernel itself has the common atom (1/4) delta_(D,D).

Consequently its total-variation contraction coefficient is at most rho=3/4. It has a unique stationary law nu, and

    TV(C^l(z,.),nu)<=rho^l.

The two marginal laws of nu are stationary for K_t and K_s. These kernels have unique stationary law pi, so both marginals of nu equal pi. No independence of the two coordinates is asserted or needed.

For p=nu{U!=V}, an off-diagonal state has next mismatch probability at most 3/4. From a diagonal state x, maximal coupling of residuals has unconditional mismatch probability

    (3/4) TV(H_t(x,.),H_s(x,.))
       = TV(K_t(x,.),K_s(x,.)).

The candidate's row bound TV(K_t(x,.),K_s(x,.))<=2h 1{x=A}+8uh is correct. Its decomposition into two single-step differences gives at most 3h/2 from A, (b/2)h from B,D, and (b+q_t)h<6uh from C. Therefore

    p <= (3/4)p+2uh+8uh,
    p <= 40uh.

As an independent cross-check, the exact row variations are

    A: h;  B,D: bh/2;  C: b(t+s)h.

Their pi-weighted sum is u(2+t+s)h<=(7/2)uh, yielding the stronger p<=14uh. This tightening is unnecessary for the reviewed constants and is not used to silently repair the candidate.

## 4. The intermediate-symbol issue is resolved by endpoint pairs

Let R_1,... be the reversed raw symbols. The j-th consecutive raw-symbol block is the pair (R_(2j-1),R_(2j)). These blocks evolve by K_t. The first block is A after terminal conditioning.

From a starting pair (a,b) to the next pair (c,d), the intermediate pair is (b,c), but the two newly emitted RAW symbols are c,d. They are exactly the next endpoint pair. Thus equality of the two coupled endpoint pairs implies equality of both raw symbols in that block, even if the two starting pairs had different b coordinates. There is no uncharged or uncoupled intervening raw symbol.

Reversing position-dependent feature indices causes no problem: assign the original two feature maps to the two coordinates of this block. The resulting block map F_j has norm at most 2R. If N is odd, extend the reversed source by one unobserved symbol and give that extra coordinate the zero feature map. This leaves the original sketch law unchanged and yields exactly m=ceil(N/2) blocks.

The synthetic terminal contribution is public and cancels in the sketch difference. The initial conditioned 00 block also cancels in the actual t-versus-s difference, although it need not cancel in the stationary comparison used for the proof.

## 5. Full-vector stationary covariance and the constant 8320

In the stationary joint chain define

    Y_j=F_j(U_j)-F_j(V_j).

Since both marginal pair laws are pi, E Y_j=0, including when F_j changes arbitrarily with j. Also

    ||Y_j||<=4R 1{U_j!=V_j},
    E||Y_j||<=4Rp,
    E||Y_j||^2<=16R^2p.

For l=k-j>0, the conditional vector mean is C^l Y_k at the current joint state. Stationarity gives integral Y_k dnu=0. Euclidean duality and the usual TV convention yield

    ||C^l Y_k(z)||<=2 sup||Y_k|| TV(C^l(z,.),nu)
                 <=8R rho^l.

Hence

    |E <Y_j,Y_k>|<=E||Y_j|| 8R rho^l
                  <=32R^2p rho^l.

Summing the diagonal and twice the off-diagonal terms gives

    E||sum_(j=1)^m Y_j||^2
      <=16mR^2p+64mR^2p sum_(l>=1)rho^l
      =208mR^2p
      <=8320mR^2uh.

This is a Hilbert-space second-moment argument with a FULL Euclidean bound on each feature. It does not sum coordinatewise estimates and has no hidden factor depending on the feature dimension. A different arbitrary norm would require a separate argument.

## 6. The transient and the constant 32

Start the joint kernel from (A,A), and separately start a copy in nu. Couple these two JOINT chains by the same reset coin. At the first reset both joint states are (D,D); from that point use identical residual-transition randomness. Thus they stay together thereafter.

Count the initial index as potentially different. The expected number of indices before common reset is at most

    sum_(l>=0)(3/4)^l=4.

The two versions of one Y_j differ by at most 8R. Therefore the expected norm of the difference of their sums is at most 32R. This is a coupling of four marginal chains through a shared JOINT reset, not an appeal to separate marginal mixing.

The triangle inequality and Jensen's inequality now give

    E||sum_j Y_j^(A,A)||
      <=32R+sqrt(8320mR^2uh).

Dividing by N+1 proves the reviewed Wasserstein bound. Its h-independent transient is loose but valid. At h=0 a separate identical-path coupling gives W1=0; no continuity claim is extracted from the loose displayed constant.

## 7. Risk reduction and paid bounded-score decoding

For one common probability-valued decoder F with binary-TV Lipschitz constant Lambda, any coupling of the conditional sketches satisfies the pointwise two-target triangle inequality. Inserting actual predictor Q with conditional interface error at most eta_A under each parameter gives

    risk_t(Q)+risk_s(Q)
       >=u[h-Lambda R(32+sqrt(8320muh))/(N+1)-2eta_A].

Taking the maximum and the nonnegative part proves the candidate's (R). If only unconditional error epsilon is known, each conditional error is at most epsilon/u, so the final maximum-risk lower loses epsilon outside the u/2 factor. Both versions in the file are correct.

For one bounded-score head, append its scalar denominator to its vector numerator, after subtracting the public self score. A score span at most S and full value norm at most V give R=e^S sqrt(V^2+1). The self term is public. The normalized denominator is at least e^(-S), and every reached attention output has norm at most V. Therefore

    ||n/z-n'/z'||<=e^S(1+V)||(n,z)-(n',z')||.

Composing with the complete paid continuation gives Lambda=L e^S(1+V), as claimed. The pre-read locality assumption ensures the terminal query is public. Earlier data-dependent attention, contextual source values, or a free inverse decoder are not included.

Set h=1/4. If both full risks are at most epsilon u, eta_A=0, and epsilon<1/8 is a sufficiently small fixed constant, rearrangement gives

    Lambda R >=(1/4-2epsilon)(N+1)
                /[32+sqrt(2080m u)].

Thus the necessary gain is Omega(min{N,sqrt(N/u)}), with S,V fixed. A per-stage envelope L<=C_0 M^D converts this only into a logarithmic lower bound on paid depth. The file correctly avoids presenting an execution-error allowance as a precision lower bound.

## 8. Failed or excluded routes retained

1. **Two marginal chains mix, hence the coupling mixes.** Invalid in general. A coupling may preserve joint information absent from both marginals. The shared joint atom above is the required replacement.
2. **Replace terminal-conditioned history by stationarity.** Invalid without a transient bound. The exact reversed start A and the 32R comparison supply it.
3. **Bound unconditional risk or interface error and condition for free.** Invalid. The rare probability u must be retained, and unconditional epsilon produces a loss epsilon outside the prefactor in the final risk inequality.
4. **Ignore middle symbols of two-step transitions.** Not justified for arbitrary observations. Here it is valid only because each endpoint PAIR contains both newly emitted raw symbols; the argument is spelled out above.
5. **Use coordinatewise variance and suppress the dimension.** Invalid without a full-vector argument. The reviewed proof uses Euclidean inner products and the full-vector bound R.
6. **Infer TV, KL, or lack of exact injectivity from W1.** Invalid. A bounded scalar can injectively encode a finite history set while two laws are very close in W1. The paid Lipschitz decoder is indispensable.
7. **Read sqrt(N/u) as sqrt(N)/u.** Unsupported stronger scaling. The reviewed file uses the correct parenthesization.
8. **Promote the bound to a matching statistical frontier, repeated-read separation, or unrestricted-attention theorem.** Unsupported. It is one-read necessary sensitivity under the stated interface, and the existing ordinary-softmax C-row floor can dominate overall rare risk.
9. **Use rounded-output error L delta as a lower bound on needed precision.** Invalid by itself. This is an approximation-error charge and weakens the lower bound; it is not an arithmetic impossibility theorem.

## 9. Nonblocking wording recommendation

Make the Section 1 and Section 6 bounded-score application explicitly single-head. A multihead version is possible by concatenating each head's numerator and denominator, but its full concatenated feature radius and downstream Lipschitz constants must be charged. This does not change the additive-sketch theorem or the proof audited here.

Any later revision needs a new exact-file hash binding. This report certifies only the target bytes named in Section 1.
