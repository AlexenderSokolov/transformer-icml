# Fixed-width rare-risk frontier: transport progress and a strict stopping boundary

6 November 2026 UTC. Private analytical work. No simulation, upload, or public write.

- RARE_ONE_READ_TRANSPORT.candidate.v2.md proves a dimension-free, terminal-conditioned Wasserstein coupling for one actual public-query additive read. It gives a paid-decoder risk bound and the conditional-A gain threshold Omega(min{N,sqrt(N/u)}).
- TASK_DIRECTED_PRECISION_AND_COVERAGE.candidate.v2.md proves that the existing rare total-bit lower plus generic task-directed geometric discretization is empty at every scale; states the ordinary finite-visible-terminal-state precision lower; and directly transfers the old late-token mechanism to the SAME rare source, giving an overall-risk gain threshold Omega(N). It also retains the ordinary-softmax output floor.

The transport calculation concerns actual-terminal-A parameter estimation, not exact KL contraction. It is consistent with scalar exact injection and the wide one-read useful estimator. Its fixed-relative-error threshold is not a sharp fixed-width rate theorem and is dominated by context acquisition on the overall prediction task.

All claims require exact-file independent review. Earlier source/compiler/statistical lemmas are dependencies, not new contributions. No literature novelty certification or complete joint N,D,W,arithmetic-precision frontier is established.
