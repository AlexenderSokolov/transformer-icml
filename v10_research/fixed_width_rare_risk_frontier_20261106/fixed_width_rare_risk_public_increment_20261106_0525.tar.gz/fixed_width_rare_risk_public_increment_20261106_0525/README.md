# Fixed-width rare-risk frontier: public research increment

All 36 available source files are preserved byte-for-byte, including all proofs and old versions, failure/resource ledgers, primary-literature audits, independent reviews, source extraction used in review, report main v1-v5, HTML v1-v3, static QA and scripts. No source was overwritten and no GitHub action occurred. Open materials/RESEARCH_REPORT.zh.v3.html for the final report. Its five appendices are documented sanitized Markdown adaptations, not raw-byte embeddings. Historical static extracts and older reports retain their original snapshot scope.

## Conditional construction and precision contract

The fixed-width one-read suffix construction supplies the genuine zero-shift final LN and ordinary-softmax output, with paid logs/division/restoration and inward alpha-range margin. It inherits the 157 rare-A and 1300 mixed-estimator statistics; it is not a new statistical rate. Conditional and overall risks retain separate suffix statistics, quotient grid G, implementation epsilon and the output range floor.

The certified fixed-grid evaluator is a CONDITIONAL CONTRACT, not an implemented quantizer, a tested finite evaluator or a floating-point reliability result. The evaluator requires nu<=nu0(alpha), range preservation nu<=mu/2 and the stated full program margin/stability hypotheses. Coefficient description, fractional evaluator precision and finite terminal alphabet are different resources and cannot be substituted for each other.

Budget choices must be source-independent when u is unknown. An oracle choice tuned to true u does not certify the u-blind claim. Declared power-of-two suffix domains, minimal truncation length, G>=16 and implementation-error restrictions remain essential. Ordinary-output alpha floors must not be dropped when describing total risk or convergence across rare parameters.

## Lower-bound limits

The rare terminal-A Wasserstein argument is a source-specific one-read sensitivity/gain threshold, with full-vector, decoder and simultaneous-head costs. It does not apply automatically to repeated data-dependent reads or prove the constructive suffix depth necessary. On the overall rare prediction task, the parameter-estimation transport threshold is dominated by the transferred late-token/context gain requirement of order N. Thus it is not a matching multihead or joint history/depth/width/precision frontier.

Generic net/bit composition is empty at every scale under the stated calculations. Finite terminal codebook, full-history sample lower and actual softmax range floor retain their distinct contracts. Approximate interfaces pay unconditional epsilon in the context comparison and conditional 2*eta_A in transport; the terminal-state/range floors constrain the actual predictor. The exact-interface inequality must not be used for an approximate network without its error penalty.

## History, evidence and validation

All v1 errors/omissions and v2 corrections remain archived. Report v2 removes stale review metadata from adapted appendices and qualifies the exact interface; v3 adds evaluator domain, range and small conditional-error qualifications. These are documentary revisions, not new executed models. Classical covariance, coupling, finite-state and sensitivity tools are credited; prior work and theorem locators remain. Novelty and complete literature coverage are not certified.

No numerical evaluator, parameter generator, simulation, training or scientific experiment was run. Visual acceptance is NOT COMPLETED. Formal verification, external peer review, finite arithmetic and dependency closure remain unresolved. This is not recovery of a complete v10 corpus.

Scoped privacy/copyright review found no secrets, sensitive personal information, private conversations or machine paths requiring redaction. Papers are referenced and comparatively summarized, not reproduced in full. No new license is added; this is not legal clearance. Historical unpublished/pending labels describe their creation-time status; exact-version reviews and registry determine scoped current analytical acceptance.

SOURCE_DERIVATION_MAP.json records every source/public size/hash. PACKAGING_QA.json separates fresh static checks from historical records. independent_review/ contains review records. SHA256SUMS and python verify_package.py provide read-only integrity checks. Original build scripts write reports and must run only in disposable copies. External relative references may not resolve after relocation.
